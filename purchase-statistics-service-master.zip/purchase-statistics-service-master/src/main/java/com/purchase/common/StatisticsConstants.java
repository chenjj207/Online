package com.purchase.common;

import lombok.Data;

/**
 * @author jidonglin
 * @Description: 业务枚举值
 */
@Data
public class StatisticsConstants {


}
