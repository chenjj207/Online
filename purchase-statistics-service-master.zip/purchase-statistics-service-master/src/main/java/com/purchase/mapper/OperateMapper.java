package com.purchase.mapper;

import com.purchase.entity.Operate;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 慧采商城运营情况 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-02-01
 */
@Mapper
public interface OperateMapper extends BaseMapper<Operate> {

    int countCustNum();

    int countInquiryNum();

    int countSupplierApplyNum();

    int countSupplierPassNum();

    int countQuoteNum();

    int countNotQuoteNum();

    int countOrderNum();

    int countSupplierProductNum();
}
