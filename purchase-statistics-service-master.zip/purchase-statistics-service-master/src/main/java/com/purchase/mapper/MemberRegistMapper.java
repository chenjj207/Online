package com.purchase.mapper;

import com.purchase.entity.MemberRegist;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.StatisticsMemberDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-01-30
 */
@Mapper
public interface MemberRegistMapper extends BaseMapper<MemberRegist> {

    List<String> selectAllArea();

    int countMemberWithStateAndAreaName(@Param("state")String state, @Param("areaName")String areaName);
}
