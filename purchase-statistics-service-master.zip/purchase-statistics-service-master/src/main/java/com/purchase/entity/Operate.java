package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 慧采商城运营情况
* </p>
*
* @author jidonglin
* @since 2024-02-01
*/
@Data
@TableName("t_st_operate")
@Schema(title = "慧采商城运营情况")
public class Operate extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "统计周期 202401")
    @TableField("cycle")
    private String cycle;

    @Schema(description = "浏览数")
    @TableField("visit_num")
    private Integer visitNum;

    @Schema(description = "本月客户新增数量")
    @TableField("cust_num")
    private Integer custNum;

    @Schema(description = "本月询价单数量")
    @TableField("inquiry_num")
    private Integer inquiryNum;

    @Schema(description = "本月供应商申请数量")
    @TableField("supplier_apply_num")
    private Integer supplierApplyNum;

    @Schema(description = "本月供应商通过数量")
    @TableField("supplier_pass_num")
    private Integer supplierPassNum;

    @Schema(description = "本月报价单数量")
    @TableField("quote_num")
    private Integer quoteNum;

    @Schema(description = "本月超时未报价数量")
    @TableField("not_quote_num")
    private Integer notQuoteNum;

    @Schema(description = "本月下单数量")
    @TableField("order_num")
    private Integer orderNum;

    @Schema(description = "供应商发布商品数量")
    @TableField("supplier_product_num")
    private Integer supplierProductNum;




}
