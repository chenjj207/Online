package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 
* </p>
*
* @author jidonglin
* @since 2024-01-30
*/
@Data
@TableName("t_st_member_regist")
@Schema(title = "")
public class MemberRegist extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "统计周期 202401")
    @TableField("cycle")
    private String cycle;

    @Schema(description = "地区")
    @TableField("area_name")
    private String areaName;

    @Schema(description = "待审核")
    @TableField("pending_state")
    private Integer pendingState;

    @Schema(description = "通过")
    @TableField("pass_state")
    private Integer passState;

    @Schema(description = "未通过")
    @TableField("not_pass_state")
    private Integer notPassState;

    @Schema(description = "所有状态之和")
    @TableField("all_state")
    private Integer allState;




}
