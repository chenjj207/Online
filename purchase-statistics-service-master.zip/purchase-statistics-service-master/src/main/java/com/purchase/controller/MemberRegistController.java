package com.purchase.controller;


import com.purchase.service.MemberRegistService;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-01-30
 */
@RestController
@RequestMapping("/member-regist")
public class MemberRegistController {

    @Autowired
    MemberRegistService memberRegistService;

    @PostMapping(value = "/add")
    @Operation(summary = "联营慧会员注册情况")
    @Auth(value = AuthType.NONE)
    public void add(){
        memberRegistService.add();
    }
}
