package com.purchase.controller;


import com.purchase.service.OperateService;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 慧采商城运营情况 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-02-01
 */
@RestController
@RequestMapping("/operate")
public class OperateController {

    @Autowired
    OperateService operateService;

    @PostMapping(value = "/add")
    @Operation(summary = "慧采商城运营情况")
    @Auth(value = AuthType.NONE)
    public void add(){
        operateService.add();
    }
}
