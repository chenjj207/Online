package com.purchase.service.dto;

import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/1/30  14:06
 */
@Data
public class StatisticsMemberDTO {
    private String areaName;
    private String state;
    private int countNum;
}
