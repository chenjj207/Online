package com.purchase.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.purchase.entity.MemberRegist;
import com.purchase.mapper.MemberRegistMapper;
import com.purchase.service.MemberRegistService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.StatisticsMemberDTO;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-01-30
 */
@Service
public class MemberRegistServiceImpl extends ServiceImpl<MemberRegistMapper, MemberRegist> implements MemberRegistService {

    @Resource
    MemberRegistMapper memberRegistMapper;

    @Override
    public void add() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime previousDay = now.minusDays(1);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM");
        String cycle = previousDay.format(formatter);

        List<String> areaNameList = memberRegistMapper.selectAllArea();
        if (CollectionUtils.isEmpty(areaNameList)){
            return;
        }
        HashMap<String, MemberRegist> hashMap = new HashMap<>();
        for (String areaName : areaNameList) {
            MemberRegist memberRegist = new MemberRegist();
            memberRegist.setCycle(cycle);
            String area = StringUtils.isEmpty(areaName) ? "其他" : areaName;
            if (hashMap.containsKey(area)){
                memberRegist.setPendingState(memberRegistMapper.countMemberWithStateAndAreaName("0", areaName) + hashMap.get(area).getPendingState());
                memberRegist.setPassState(memberRegistMapper.countMemberWithStateAndAreaName("1", areaName) + hashMap.get(area).getPassState());
                memberRegist.setNotPassState(memberRegistMapper.countMemberWithStateAndAreaName("2", areaName) + hashMap.get(area).getNotPassState());
                memberRegist.setAllState(memberRegistMapper.countMemberWithStateAndAreaName(null, areaName) + hashMap.get(area).getAllState());
            }else {
                memberRegist.setPendingState(memberRegistMapper.countMemberWithStateAndAreaName("0", areaName));
                memberRegist.setPassState(memberRegistMapper.countMemberWithStateAndAreaName("1", areaName));
                memberRegist.setNotPassState(memberRegistMapper.countMemberWithStateAndAreaName("2", areaName));
                memberRegist.setAllState(memberRegistMapper.countMemberWithStateAndAreaName(null, areaName));
            }
            memberRegist.setAreaName(area);
            hashMap.put(area, memberRegist);
        }

        QueryWrapper<MemberRegist> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("cycle", cycle);
        List<MemberRegist> memberRegists = memberRegistMapper.selectList(queryWrapper);

        HashMap<String, MemberRegist> existMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(memberRegists)){
            for (MemberRegist m : memberRegists) {
                existMap.put(m.getAreaName(), m);
            }
        }

        List<MemberRegist> memberRegistsUpdate = new ArrayList<>();
        List<MemberRegist> memberRegistsAdd = new ArrayList<>();
        hashMap.forEach((key, value) -> {
            if (existMap.containsKey(key)){
                //更新
                MemberRegist memberRegist = existMap.get(key);
                BeanUtil.copyProperties(value, memberRegist, "id", "createdBy", "createdAt");
                memberRegist.setUpdatedAt(LocalDateTime.now());
                memberRegist.setUpdatedBy("qts");
                memberRegistsUpdate.add(memberRegist);
            }else {
                //添加
                MemberRegist memberRegist = value;
                memberRegist.setCreatedBy("qts");
                memberRegist.setCreatedAt(LocalDateTime.now());
                memberRegistsAdd.add(memberRegist);
            }
        });
        if (CollectionUtils.isNotEmpty(memberRegistsUpdate)){
            this.updateBatchById(memberRegistsUpdate);
        }
        if (CollectionUtils.isNotEmpty(memberRegistsAdd)){
            this.saveBatch(memberRegistsAdd);
        }
    }
}
