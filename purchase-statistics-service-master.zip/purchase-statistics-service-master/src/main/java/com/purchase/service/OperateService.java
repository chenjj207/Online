package com.purchase.service;

import com.purchase.entity.Operate;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 慧采商城运营情况 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-02-01
 */
public interface OperateService extends IService<Operate> {

    public void add();
}
