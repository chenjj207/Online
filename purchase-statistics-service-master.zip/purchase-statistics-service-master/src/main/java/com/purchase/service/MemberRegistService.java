package com.purchase.service;

import com.purchase.entity.MemberRegist;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-01-30
 */
public interface MemberRegistService extends IService<MemberRegist> {
    public void add();
}
