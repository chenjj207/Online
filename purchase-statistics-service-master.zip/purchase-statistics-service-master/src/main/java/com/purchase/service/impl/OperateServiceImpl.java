package com.purchase.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.purchase.entity.Operate;
import com.purchase.mapper.OperateMapper;
import com.purchase.service.OperateService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * <p>
 * 慧采商城运营情况 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-02-01
 */
@Service
public class OperateServiceImpl extends ServiceImpl<OperateMapper, Operate> implements OperateService {

    @Resource
    OperateMapper operateMapper;

    @Override
    public void add() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime previousDay = now.minusDays(1);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM");
        String cycle = previousDay.format(formatter);
        QueryWrapper<Operate> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("cycle", cycle);
        Operate operate = operateMapper.selectOne(queryWrapper);
        if (operate == null){
            operate = new Operate();
            operate.setCycle(cycle);
            operate.setVisitNum(0);
            operate.setCustNum(operateMapper.countCustNum());
            operate.setInquiryNum(operateMapper.countInquiryNum());
            operate.setSupplierApplyNum(operateMapper.countSupplierApplyNum());
            operate.setSupplierPassNum(operateMapper.countSupplierPassNum());
            operate.setQuoteNum(operateMapper.countQuoteNum());
            operate.setNotQuoteNum(operateMapper.countNotQuoteNum());
            operate.setOrderNum(operateMapper.countOrderNum());
            operate.setSupplierProductNum(operateMapper.countSupplierProductNum());
            operate.setCreatedAt(now);
            operate.setCreatedBy("qts");
            operateMapper.insert(operate);
        }else {
            operate.setCycle(cycle);
            operate.setVisitNum(0);
            operate.setCustNum(operateMapper.countCustNum());
            operate.setInquiryNum(operateMapper.countInquiryNum());
            operate.setSupplierApplyNum(operateMapper.countSupplierApplyNum());
            operate.setSupplierPassNum(operateMapper.countSupplierPassNum());
            operate.setQuoteNum(operateMapper.countQuoteNum());
            operate.setNotQuoteNum(operateMapper.countNotQuoteNum());
            operate.setOrderNum(operateMapper.countOrderNum());
            operate.setSupplierProductNum(operateMapper.countSupplierProductNum());
            operate.setUpdatedAt(now);
            operate.setUpdatedBy("qts");
            operateMapper.updateById(operate);
        }
    }
}
