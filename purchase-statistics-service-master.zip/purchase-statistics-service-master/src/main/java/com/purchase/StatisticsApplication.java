package com.purchase;

import com.github.ltsopensource.spring.boot.annotation.EnableTaskTracker;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author jidonglin
 * @Description: 慧采商城统计服务
 * @date 2024/1/30  10:41
 */
@SpringCloudApplication
@ServletComponentScan(basePackages = {"com.purchase.*", "com.zyd.*"})
@ComponentScan(basePackages = {"com.purchase.**", "com.zyd.**"})
@MapperScan("com.purchase.mapper")
@EnableFeignClients
@RefreshScope
@EnableHystrix
@EnableAsync
@EnableTaskTracker
public class StatisticsApplication {
    public static void main(String[] args) {
        SpringApplication.run(StatisticsApplication.class, args);
    }
}
