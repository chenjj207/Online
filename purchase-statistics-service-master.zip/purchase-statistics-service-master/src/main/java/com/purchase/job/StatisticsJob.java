package com.purchase.job;

import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.spring.boot.annotation.JobRunner4TaskTracker;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.github.ltsopensource.tasktracker.runner.JobRunner;
import com.purchase.service.MemberRegistService;
import com.purchase.service.OperateService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.helpers.MessageFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/1/30  11:40
 */
@Slf4j
@Component
@JobRunner4TaskTracker
public class StatisticsJob implements JobRunner {

    @Autowired
    MemberRegistService memberRegistService;
    @Autowired
    OperateService operateService;
    /**
     * 执行任务
     * 抛出异常则消费失败, 返回null则认为是消费成功
     *
     * @param jobContext
     */
    @Override
    public Result run(JobContext jobContext) throws Throwable {
        String type = jobContext.getJob().getParam("type");
        switch (type) {
            case "MEMBER_REGIST":
                memberRegistService.add();
                return  new Result(Action.EXECUTE_SUCCESS, "任务执行成功");
            case "OPERATE":
                operateService.add();
                return  new Result(Action.EXECUTE_SUCCESS, "任务执行成功");
            default:
                return new Result(Action.EXECUTE_EXCEPTION, MessageFormatter.format("非法执行命令: {}", type).getMessage());
        }
    }
}
