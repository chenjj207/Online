package com.purchase.feign;

import com.purchase.feign.param.CustomerAddDTO;
import com.purchase.feign.param.JsonResult;
import com.purchase.feign.param.SupplierDTO;
import com.zyd.framework.utils.response.CommonResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/24  15:42
 */
@FeignClient(value = "purchase-cust")
public interface CustomerClient {

    @PostMapping(value = "/customer/customer-add")
    public CommonResponse<Boolean> add(@RequestBody CustomerAddDTO customerAddDTO);
}
