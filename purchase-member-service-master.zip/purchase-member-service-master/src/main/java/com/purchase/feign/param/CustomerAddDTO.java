package com.purchase.feign.param;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/24  14:06
 */
@Data
public class CustomerAddDTO {
    @Schema(description = "会员id")
    private int memberId;
    @Schema(description = "创建人")
    private String createdBy;
    @Schema(description = "更新认")
    private String updatedBy;
}
