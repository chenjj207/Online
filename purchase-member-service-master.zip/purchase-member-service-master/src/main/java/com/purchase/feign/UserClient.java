package com.purchase.feign;

import com.purchase.feign.param.JsonResult;
import com.purchase.feign.param.SupplierDTO;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/24  15:42
 */
@FeignClient(value = "purchase-user", fallbackFactory = UserClient.UserClientHystrix.class)
public interface UserClient {

    @PostMapping(value = "/supplier/add")
    public JsonResult<SupplierDTO> add(@RequestBody SupplierDTO supplier);

    @Component
    @Slf4j
    class UserClientHystrix implements FallbackFactory<UserClient> {

        /**
         * Returns an instance of the fallback appropriate for the given cause.
         *
         * @param cause cause of an exception.
         * @return fallback
         */
        @Override
        public UserClient create(Throwable cause) {
            return new UserClient() {
                @Override
                public JsonResult<SupplierDTO> add(SupplierDTO supplier) {
                    return new JsonResult<>(false, cause.getMessage());
                }
            };
        }
    }
}
