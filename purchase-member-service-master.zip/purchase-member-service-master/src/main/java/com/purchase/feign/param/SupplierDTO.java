package com.purchase.feign.param;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class SupplierDTO {

    private String id;

    private String name;

    private String code;

    /**
     * 联营慧会员id
     */
    private Integer memberId;

    /**
     * 客户id
     */
    private Integer custId;

    /**
     * 类型（SUPPLIER_APPLY: 供应商申请、BACKGROUND_ADD: 后台新增）
     */
    private String type;

    /**
     * 状态（WAIT_AUDIT: 待审核、NO_PASS: 未通过、PASS: 已通过）
     */
    private String status;

    /**
     * 初始密码
     */
    private String password;

    /**
     * 账号状态(ENABLE: 启用、DISABLE: 停用)
     */
    private String accountStatus;

    /**
     * 数据类型(UNITE: 联营、SELF_SUPPORT: 自营)
     */
    private String dataType;

    private String contacts;

    private String identifyUmber;

    private Integer provinceId;

    private String provinceName;

    private Integer cityId;

    private String cityName;

    private Integer countyId;

    private String countyName;

    private String address;
    /**
     * 审核时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime;

    @Schema(description = "分公司编码")
    private String comBm;

    @Schema(description = "分公司简称")
    private String shortName;

    private boolean isSend;

    private String createdBy;

    private String updatedBy;

}
