package com.purchase.feign.param;

import lombok.Data;

/**
 * 前后台交互
 *
 * @param <T> 数据泛型
 * @author zhangyang@HF,niming
 */
@Data
public class JsonResult<T> {

    private boolean success = true;
    private T data;
    private String msg;
    private String errCode;

    public JsonResult() {
    }

    public JsonResult(boolean success, String msg) {
        this.success = success;
        this.msg = msg;
    }

    public JsonResult(boolean success, String msg, T data) {
        this.success = success;
        this.msg = msg;
        this.data = data;
    }

    public JsonResult(boolean success, String errCode, String msg, T data) {
        this.success = success;
        this.errCode = errCode;
        this.msg = msg;
        this.data = data;
    }

    public static JsonResult ok() {
        return new JsonResult();
    }

    public static JsonResult ok(String msg) {
        return new JsonResult(true, msg);
    }

    public static <T> JsonResult ok(String msg, T data) {
        return new JsonResult(true, msg, data);
    }

    public static JsonResult error() {
        return new JsonResult(false, null);
    }

    public static JsonResult error(String msg) {
        return new JsonResult(false, msg);
    }

    public static <T> JsonResult error(String errCode, String msg) {
        return new JsonResult(false, errCode, msg);
    }
}
