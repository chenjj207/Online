package com.purchase.feign;

import com.purchase.feign.param.AddStoreDTO;
import com.purchase.feign.param.JsonResult;
import com.purchase.feign.param.SupplierDTO;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/7/25  15:42
 */
@FeignClient(value = "purchase-config-service", fallbackFactory = ConfigClient.ConfigClientHystrix.class)
public interface ConfigClient {

    @PostMapping(value = "/purchase-store/store-add")
    public JsonResult add(@RequestBody AddStoreDTO addStoreDTO);

    @Component
    @Slf4j
    class ConfigClientHystrix implements FallbackFactory<ConfigClient> {

        /**
         * Returns an instance of the fallback appropriate for the given cause.
         *
         * @param cause cause of an exception.
         * @return fallback
         */
        @Override
        public ConfigClient create(Throwable cause) {
            return new ConfigClient() {
                @Override
                public JsonResult add(AddStoreDTO addStoreDTO) {
                    return new JsonResult(false, cause.getMessage());
                }
            };
        }
    }
}
