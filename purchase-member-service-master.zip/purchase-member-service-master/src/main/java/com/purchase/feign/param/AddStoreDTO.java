package com.purchase.feign.param;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Data
public class AddStoreDTO {
    @Pattern(regexp= "[\\u4e00-\\u9fa5_a-zA-Z0-9_]{1,15}",message = "店铺名称长度超出限制")
    @NotBlank(message = "请填写店铺名称")
    @Schema(description = "店铺名")
    private String storeName;

    @NotNull(message = "类型不能为空")
    @Schema(description = "店铺类型（0为自营，1为联营）")
    private Integer storeType;

    @Pattern(regexp= "(https?:[^:<>\"]*\\/)([^:<>\"]*)(\\.((png!thumbnail)|(png)|(jpg)|(gif)))",message = "上传格式有误")
    @NotBlank(message = "请上传店铺LOGO")
    @Schema(description = "店铺logo")
    private String storeLogo;

    @Schema(description = "省")
    private String province;

    @Schema(description = "市")
    private String city;

    @Schema(description = "区")
    private String area;

    @Min(value = 1,message ="排序从1开始" )
    @Schema(description = "店铺排序（从1开始）")
    private Integer storeSort;

    @Schema(description = "供应商id")
    private String supplierId;

    @Schema(description = "店铺地址")
    private String address;

    @NotBlank(message = "请填写联系人信息")
    @Schema(description = "联系人")
    private String linkMan;

    @NotBlank(message = "请填写联系电话")
    @Schema(description = "联系电话")
    private String linkPhone;

    @NotNull(message = "启用状态不能为空")
    @Schema(description = "启用状态（0为未启用，1为启用）")
    private Integer state;

    @Schema(description = "创建者")
    private String createdBy;
}
