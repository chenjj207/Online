package com.purchase.utils;

import com.alibaba.fastjson.JSONObject;
import com.purchase.client.QyWXClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/10  10:50
 */
@Component
public class NoticeUtils {

    private static Logger logger = LoggerFactory.getLogger(NoticeUtils.class);

    @Value("${qywx.agentId}")
    String agentId;
    @Value("${qywx.touser}")
    String touser;

    @Autowired
    TokenUtils tokenUtils;
    @Resource
    private QyWXClient qyWXClient;

    /**
     * 企业微信通知公共方法，发送失败不抛出异常，只打印错误信息
     * @param content
     */
    public void sendQywx(String content){
        String accessToken = tokenUtils.getQyWXToken();
        Map<String, Object> info = new HashMap<>();
        info.put("touser", touser);
        info.put("msgtype", "text");
        info.put("agentid", agentId);
        Map<String, String> contentMap = new HashMap<>();
        contentMap.put("content", content);
        info.put("text", contentMap);
        JSONObject jsonObject = qyWXClient.sendNoticeMessage(accessToken, info);
        if(jsonObject.containsKey("errcode")){
            if(jsonObject.get("errcode").toString().equals("0")){
                logger.info("发送企业微信消息成功");
            }else{
                if(jsonObject.containsKey("errmsg")){
                    logger.error("发送企业微信异常：" + jsonObject.get("errcode").toString() + " --- " + jsonObject.get("errmsg").toString());
                }else{
                    logger.error("发送企业微信异常：" + jsonObject.toJSONString());
                }
            }
        }else{
            logger.error("调用企业微信接口--异常");
        }
    }
}
