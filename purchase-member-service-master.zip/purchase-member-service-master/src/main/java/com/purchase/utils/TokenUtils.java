package com.purchase.utils;

import com.alibaba.fastjson.JSONObject;
import com.purchase.client.QyWXClient;
import com.purchase.client.WXClient;
import com.zyd.framework.utils.redis.RedisUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/3/20  15:58
 */
@Component
public class TokenUtils {

    @Resource
    private WXClient wxClient;
    @Resource
    private QyWXClient qyWXClient;

    @Value("${wx.appid}")
    String appid;
    @Value("${wx.secret}")
    String secret;
    @Value("${qywx.corpid}")
    String corpid;
    @Value("${qywx.corpSecret}")
    String corpSecret;
    @Value("${qywx.agentId}")
    String agentId;
    //【众业达业务协同系统】凭证密钥
    @Value("${qywx.corpSecret1}")
    String corpSecret1;
    //【众业达业务协同系统】id
    @Value("${qywx.agentId1}")
    String agentId1;


    public String getWXToken() {
        String accessToken = RedisUtil.StringOps.get("WX_AccessToken");
        if (StringUtils.isEmpty(accessToken)){
            JSONObject jsonObject = wxClient.getToken(appid, secret);
            String newAccessToken = jsonObject.getString("access_token");
            //设置为280秒
            RedisUtil.StringOps.setEx("WX_AccessToken", newAccessToken, 280, TimeUnit.SECONDS);
            accessToken = newAccessToken;
        }
        return accessToken;
    }

    public String getQyWXToken() {
        String accessToken = RedisUtil.StringOps.get("QYWX_AccessToken_" + agentId);
        if (StringUtils.isEmpty(accessToken)){
            JSONObject jsonObject = qyWXClient.getToken(corpid, corpSecret);
            String newAccessToken = jsonObject.getString("access_token");
            //设置为7000秒
            RedisUtil.StringOps.setEx("QYWX_AccessToken_" + agentId, newAccessToken, 7000, TimeUnit.SECONDS);
            accessToken = newAccessToken;
        }
        return accessToken;
    }

    public String getQyWXTokenBy1() {
        String accessToken = RedisUtil.StringOps.get("qywx_token");
        if (StringUtils.isEmpty(accessToken)){
            JSONObject jsonObject = qyWXClient.getToken(corpid, corpSecret1);
            String newAccessToken = jsonObject.getString("access_token");
            //设置为7000秒
            RedisUtil.StringOps.setEx("qywx_token", newAccessToken, 60, TimeUnit.SECONDS);
            accessToken = newAccessToken;
        }
        return accessToken;
    }

}
