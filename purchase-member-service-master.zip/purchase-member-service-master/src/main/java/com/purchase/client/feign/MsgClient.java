package com.purchase.client.feign;

import com.purchase.client.dto.TriggerMsgRequest;
import com.zyd.framework.utils.response.CommonResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;


/**
 * 搜索对外服务接口
 */
@FeignClient(value = "purchase-msg")
public interface MsgClient {

    /**
     * 业务消息发送
     * @return
     */
    @PostMapping("/trigger/business/msg")
    public CommonResponse triggerMsg(@RequestBody TriggerMsgRequest request);

    /**
     * 查询 用户是否已关注公众号
     * @return
     */
    @PostMapping("/wx-subscribe/query/subscribe")
    public CommonResponse<Boolean> queryWxSubscribeByUnionid(@RequestParam("unionid") String unionid);
}
