package com.purchase.client;

import com.alibaba.fastjson.JSONObject;
import com.dtflys.forest.annotation.*;

/**
 * @author jidonglin
 * @Description: 微信接口
 * @date 2023/2/10  11:13
 */
public interface WXClient {
    @Get("https://api.weixin.qq.com/sns/jscode2session?grant_type=authorization_code")
    JSONObject jscode2session(@Query("appid")String appid, @Query("secret")String secret, @Query("js_code")String js_code);

    @Get("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential")
    JSONObject getToken(@Query("appid")String appid, @Query("secret")String secret);

    @Post("https://api.weixin.qq.com/wxa/business/getuserphonenumber")
    JSONObject getuserphonenumber(@Query("access_token")String accessToken, @JSONBody("code") String code);

    @Post("https://api.weixin.qq.com/wxa/getwxacodeunlimit")
    byte[] getwxacodeunlimit(@Query("access_token")String accessToken, @JSONBody("scene") String scene, @JSONBody("page") String page, @JSONBody("env_version") String envVersion);
}
