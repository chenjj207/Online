package com.purchase;

import com.dtflys.forest.springboot.annotation.ForestScan;
import com.github.ltsopensource.spring.boot.annotation.EnableTaskTracker;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author jidonglin
 * @Description:
 * @date 2022/4/11  14:41
 */
@SpringCloudApplication
@ServletComponentScan(basePackages = {"com.purchase.*", "com.zyd.*"})
@ComponentScan(basePackages = {"com.purchase.**", "com.zyd.**"})
@MapperScan("com.purchase.mapper")
@EnableFeignClients
@RefreshScope
@EnableHystrix
@ForestScan(basePackages = "com.purchase.client")
@EnableTaskTracker
public class MemberApplication {
    public static void main(String[] args) {
        SpringApplication.run(MemberApplication.class, args);
        System.out.println("------------ Member服务 启动完成--------------");
    }
}
