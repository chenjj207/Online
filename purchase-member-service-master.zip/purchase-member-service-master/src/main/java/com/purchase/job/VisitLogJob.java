package com.purchase.job;

import cn.hutool.core.map.MapUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.spring.boot.annotation.JobRunner4TaskTracker;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.github.ltsopensource.tasktracker.runner.JobRunner;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.AssociateProtocol;
import com.purchase.entity.VisitLog;
import com.purchase.mapper.AssociateProtocolMapper;
import com.purchase.mapper.VisitLogMapper;
import com.purchase.service.AssociateProtocolService;
import com.purchase.service.VisitLogService;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.redis.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.helpers.MessageFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.prefs.BackingStoreException;
import java.util.stream.Collectors;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/6/28  14:27
 */
@Slf4j
@Component
@JobRunner4TaskTracker
public class VisitLogJob implements JobRunner {

    @Autowired
    VisitLogService visitLogService;
    @Resource
    AssociateProtocolMapper associateProtocolMapper;
    /**
     * 执行任务
     * 抛出异常则消费失败, 返回null则认为是消费成功
     *
     * @param jobContext
     */
    @Override
    public Result run(JobContext jobContext) throws Throwable {
        String type = jobContext.getJob().getParam("type");
        switch (type) {
            case "VISIT_LOG_SYNC":
                //浏览记录同步到MySQL
                String key = LocalDateTime.now().minusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                if(RedisUtil.KeyOps.hasKey(key)){
                    if(saveOrUpdateVisitLogs(key)){
                        RedisUtil.KeyOps.delete(key);
                    }
                    else {
                        return new Result(Action.EXECUTE_FAILED, MessageFormatter.format("非法执行命令: {}", PurchaseBusinessExceptionDesc.DATA_SYNCHRONIZATION_ERROR.getDesc()).getMessage());
                    }

                }
                //更新今天的数据
                String todayKey = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                saveOrUpdateVisitLogs(todayKey);

                return  new Result(Action.EXECUTE_SUCCESS, "任务执行成功");
            case "EXPIRE_ASSOCIATE_PROTOCOL":
                List<AssociateProtocol> list = associateProtocolMapper.selectLastSignTime("3");
                if (CollectionUtils.isNotEmpty(list)){
                    LocalDateTime now = LocalDateTime.now();
                    for (AssociateProtocol a : list) {
                        a.setState("3");
                        a.setUpdatedAt(now);
                        associateProtocolMapper.updateById(a);
                    }
                }
                return  new Result(Action.EXECUTE_SUCCESS, "任务执行成功");
            default:
                return new Result(Action.EXECUTE_EXCEPTION, MessageFormatter.format("非法执行命令: {}", type).getMessage());
        }
    }
    public Boolean saveOrUpdateVisitLogs(String key){
        Map<Object, Object> map =  RedisUtil.HashOps.hGetAll(key);
        List<VisitLog> visitLogs = new ArrayList<>();
        if(MapUtil.isNotEmpty(map)) {
            map.forEach((k,v)->{
                VisitLog visitLog = new VisitLog();
                visitLog.setIpAddress((String) k);
                visitLog.setVisitTimes(Integer.valueOf((String) v));
                visitLog.setAccessTime(key);
                visitLog.setCreatedAt(LocalDateTime.now());
                visitLogs.add(visitLog);
            });
        }
        QueryWrapper<VisitLog> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("access_time",key);
        List<VisitLog> visitLogList = visitLogService.list(queryWrapper);
        //获取需要更新和新增的数据
        List<VisitLog> updateOrSaveList = new ArrayList<>();
        if (visitLogList.size()>0){
            visitLogs.forEach(e->{
                List<VisitLog> list = visitLogList.stream().filter(f->f.getIpAddress().equals(e.getIpAddress())).collect(Collectors.toList());
                if(list.size()>0){
                    e.setId(list.get(0).getId());
                    if(e.getVisitTimes()!=list.get(0).getVisitTimes()){
                        updateOrSaveList.add(e);
                    }
                } else{
                    updateOrSaveList.add(e);
                }

            });
            if(updateOrSaveList.size()>0){
                return visitLogService.saveOrUpdateBatch(updateOrSaveList);
            }
            return true;
        } else {
            return visitLogService.saveBatch(visitLogs);
        }
    }
}
