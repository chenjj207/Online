package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 登录日志表
* </p>
*
* @author jidonglin
* @since 2023-06-27
*/
@Data
@TableName("t_mb_login_log")
@Schema(title = "登录日志表")
public class LoginLog extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "IP地址")
    @TableField("ip_address")
    private String ipAddress;

    @Schema(description = "公司名称")
    @TableField("company")
    private String company;

    @Schema(description = "手机号码")
    @TableField("linkphone")
    private String linkphone;

    @Schema(description = "联系人")
    @TableField("linkman")
    private String linkman;

    @Schema(description = "所属公司")
    @TableField("company_name")
    private String companyName;

    @Schema(description = "访问时间")
    @TableField("access_time")
    private LocalDateTime accessTime;




}
