package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 联营授权
* </p>
*
* @author jidonglin
* @since 2024-05-22
*/
@Data
@TableName("t_mb_associate_auth")
@Schema(title = "联营授权")
public class AssociateAuth extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "协议id")
    @TableField("protocol_id")
    private Integer protocolId;

    @Schema(description = "授权名称")
    @TableField("name")
    private String name;

    @Schema(description = "上传人")
    @TableField("upload_person")
    private String uploadPerson;

    @Schema(description = "文件地址")
    @TableField("url")
    private String url;

    @Schema(description = "源文件名")
    @TableField("file_name")
    private String fileName;




}
