package com.purchase.entity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class MemberExcelEntity {

    private String state;

    private String reason;

    private String company;

    private String linkman;

    private String linkphone;

    private String competence;

    private String isShow;

    private String promoter;

    private String industry;

    private String area;

    private String address;

    private String competenceInfo;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private LocalDateTime auditAt;

    private String companyName;

    private String areaName;

    private String remark;

    private String wxNickName;

}
