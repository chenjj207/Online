package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;


/**
 * <p>
 * 协作表
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Data
@Schema(title = "协作表")
@TableName("t_mb_cooperation")
public class Cooperation extends BaseEntity {

    @Schema(description = "标题")
    @TableField("title")
    private String title;

    @Schema(description = "联系方式")
    @TableField("linkphone")
    private String linkphone;

    @Schema(description = "图片路径")
    @TableField("team_url")
    private String teamUrl;

    @Schema(description = "协作类型(resource=资源，need=需求)")
    @TableField("type")
    private String type;

    @Schema(description = "资源类型(product=产品资源，service=服务资源)")
    @TableField("resource_type")
    private String resourceType;

    @Schema(description = "需求类型(serviceCooperate=服务协同)")
    @TableField("need_type")
    private String needType;

    @Schema(description = "协作描述")
    @TableField("team_info")
    private String teamInfo;

    @Schema(description = "所属会员id")
    @TableField("member_id")
    private Integer memberId;

    @Schema(description = "状态（0=已回复，1=未回复，默认为未回复）")
    @TableField("status")
    private Integer status;

    @Schema(description = "审核状态 0: 待审核 1：已通过 2：已拒绝")
    @TableField("audit_state")
    private Integer auditState;

    @Schema(description = "需求有效期")
    @TableField("expire_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime expireTime;

    @Schema(description = "拒绝原因")
    @TableField("reject_reason")
    private String rejectReason;

    @Schema(description = "资讯id")
    @TableField("real_news_id")
    private Integer realNewsId;
}
