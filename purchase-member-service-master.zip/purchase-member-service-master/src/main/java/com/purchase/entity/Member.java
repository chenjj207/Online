package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.purchase.service.vo.RecommendProductVO;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.Transient;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.List;


/**
 * <p>
 * 会员表
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Data
@Schema(title = "会员表")
@TableName("t_mb_member")
public class Member extends BaseEntity {

    @Schema(description = "会员公司")
    @TableField("company")
    private String company;

    @Schema(description = "对应服务行业")
    @TableField("industry")
    private String industry;

    @Schema(description = "核心能力")
    @TableField("competence")
    private String competence;

    @Schema(description = "核心能力描述")
    @TableField("competence_info")
    private String competenceInfo;

    @Schema(description = "联系人")
    @TableField("linkman")
    private String linkman;

    @Schema(description = "联系方式")
    @TableField("linkphone")
    private String linkphone;

    @Schema(description = "推广人")
    @TableField("promoter")
    private String promoter;

    @Schema(description = "省")
    @TableField("province")
    private String province;

    @Schema(description = "市")
    @TableField("city")
    private String city;

    @Schema(description = "区")
    @TableField("area")
    private String area;

    @Schema(description = "详细地址")
    @TableField("address")
    private String address;

    @Schema(description = "会员头像地址")
    @TableField("icon_url")
    private String iconUrl;

    @Schema(description = "是否在小程序通讯录显示（0=不显示，1= 显示）")
    @TableField("is_show")
    private Integer isShow;

    @Schema(description = "是否在小程序通讯录显示不通过原因（0=不显示，1= 显示）")
    @TableField("is_show_reason")
    private Integer isShowReason;

    @Schema(description = "未通过原因")
    @TableField("reason")
    private String reason;

    @Schema(description = "是否为内部人员(0为非内部人员，1为内部人员)")
    @TableField("is_inner")
    private Integer isInner;

    @Schema(description = "微信union_id")
    @TableField("union_id")
    private String unionId;

    @Schema(description = "微信用户在当前小程序的唯一标识")
    @TableField("open_id")
    private String openId;

    @Schema(description = "微信昵称")
    @TableField("wx_nick_name")
    private String wxNickName;

    @Schema(description = "状态（0=待审核，1=通过，2=未通过）")
    @TableField("state")
    private Integer state;

    @Schema(description = "图片地址")
    @TableField("member_url")
    private String memberUrl;

    @Schema(description = "推广人所属公司")
    @TableField("company_name")
    private String companyName;

    @Schema(description = "所属大区")
    @TableField("area_name")
    private String areaName;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;

    @Schema(description = "审核时间")
    @TableField("audit_at")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditAt;

    @Schema(description = "是否关注")
    @TableField(exist = false)
    private boolean subscribe;

    @Schema(description = "供应商id")
    @TableField(exist = false)
    private String supplierId;

    @Schema(description = "推荐商品列表")
    @TableField(exist = false)
    private List<RecommendProductVO> recommendProductVOS;

}
