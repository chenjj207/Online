package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * <p>
 * 会员消息表
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Data
@Schema(title = "会员消息表")
@TableName("t_mb_member_message")
public class MemberMessage extends BaseEntity {

    @Schema(description = "消息id")
    @TableField("notice_id")
    private Integer noticeId;

    @Schema(description = "消息接收者 会员id")
    @TableField("member_id")
    private Integer memberId;

    @Schema(description = "消息发送者 会员id")
    @TableField("send_member_id")
    private Integer sendMemberId;

    @Schema(description = "是否已读（0=未读，1=已读）")
    @TableField("is_read")
    private Integer isRead;

    @Schema(description = "伪删除（0：未删除，1：已删除）")
    @TableField("is_delete")
    private Integer isDelete;
}
