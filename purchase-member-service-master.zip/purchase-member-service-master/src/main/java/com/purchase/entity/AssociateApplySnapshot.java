package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 联营申请表
* </p>
*
* @author jidonglin
* @since 2024-05-15
*/
@Data
@TableName("t_mb_associate_apply_snapshot")
@Schema(title = "联营申请表")
public class AssociateApplySnapshot extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "微信在同一开放平台下的唯一身份标识")
    @TableField("union_id")
    private String unionId;

    @Schema(description = "微信用户在当前小程序的唯一身份标识")
    @TableField("open_id")
    private String openId;

    @Schema(description = "状态：1、待调研  2、调研未通过  3、待批复  4、同意签约  5、拒绝签约")
    @TableField("state")
    private String state;

    @Schema(description = "调研人员/当前操作调研的用户")
    @TableField("research_person")
    private String researchPerson;

    @Schema(description = "调研形式")
    @TableField("research_format")
    private String researchFormat;

    @Schema(description = "客户类型")
    @TableField("customer_type")
    private String customerType;

    @Schema(description = "调研结果")
    @TableField("research_result")
    private String researchResult;

    @Schema(description = "调研时间")
    @TableField("research_time")
    private LocalDateTime researchTime;

    @Schema(description = "拒绝签约原因")
    @TableField("reject_sign_reason")
    private String rejectSignReason;

    @Schema(description = "审批时间")
    @TableField("approval_time")
    private LocalDateTime approvalTime;

    @Schema(description = "联营合作诉求")
    @TableField("cooperation_demand")
    private String cooperationDemand;

    @Schema(description = "合作项目")
    @TableField("cooperation_project")
    private String cooperationProject;

    @Schema(description = "单位名称/客户名称")
    @TableField("company")
    private String company;

    @Schema(description = "联系人")
    @TableField("linkman")
    private String linkman;

    @Schema(description = "联系电话")
    @TableField("linkphone")
    private String linkphone;

    @Schema(description = "省")
    @TableField("province")
    private String province;

    @Schema(description = "市")
    @TableField("city")
    private String city;

    @Schema(description = "区")
    @TableField("area")
    private String area;

    @Schema(description = "详细地址")
    @TableField("address")
    private String address;

    @Schema(description = "公司人员数量")
    @TableField("user_num")
    private String userNum;

    @Schema(description = "基本资料-企业相关资料	如果申请合作项目选择仅为【渠道联营】才显示	")
    @TableField("basic_detail_info")
    private String basicDetailInfo;

    @Schema(description = "如果申请合作项目包含为“产线联营”才显示；")
    @TableField("cooperation_detail_info_url")
    private String cooperationDetailInfoUrl;

    @Schema(description = "公司主营业务")
    @TableField("main_business")
    private String mainBusiness;

    @Schema(description = "商品供应性质，修改选择项，如果申请合作项目选择包含“产线联营”才显示；")
    @TableField("working_type")
    private String workingType;

    @Schema(description = "公司年营业额")
    @TableField("year_turnover")
    private BigDecimal yearTurnover;

    @Schema(description = "公司经营性质，如果申请合作项目选择包含“渠道联营”才显示")
    @TableField("nature_operation")
    private String natureOperation;

    @Schema(description = "主营产品")
    @TableField("main_product")
    private String mainProduct;

    @Schema(description = "主营品牌")
    @TableField("main_brand")
    private String mainBrand;

    @Schema(description = "开户名称")
    @TableField("account_name")
    private String accountName;

    @Schema(description = "银行账号")
    @TableField("bank_account_num")
    private String bankAccountNum;

    @Schema(description = "开户银行")
    @TableField("opening_bank")
    private String openingBank;

    @Schema(description = "纳税人识别号")
    @TableField("tax_identification")
    private String taxIdentification;

    @Schema(description = "所属大区")
    @TableField("area_name")
    private String areaName;

    @Schema(description = "合作单位/子公司名称")
    @TableField("sub_company")
    private String subCompany;

    @Schema(description = "项目推广专员")
    @TableField("promotion_person")
    private String promotionPerson;

    @Schema(description = "签约推荐人")
    @TableField("business_person")
    private String businessPerson;

    @Schema(description = "去年合作采购金额”，如果申请合作项目选择包含“渠道联营”才显示")
    @TableField("last_year_purchase_zyd")
    private BigDecimal lastYearPurchaseZyd;

    @Schema(description = "今年计划采购金额”，如果申请合作项目选择包含“渠道联营”才显示")
    @TableField("this_year_sign_purchase_zyd")
    private BigDecimal thisYearSignPurchaseZyd;

    @Schema(description = "签约首单采购金额,如果申请合作项目选择包含“渠道联营”才显示；")
    @TableField("first_order_purchase")
    private BigDecimal firstOrderPurchase;

    @Schema(description = "全年指标")
    @TableField("annual_target")
    private BigDecimal annualTarget;

    @Schema(description = "第一季度指标")
    @TableField("first_quarter_target")
    private BigDecimal firstQuarterTarget;

    @Schema(description = "第二季度指标")
    @TableField("second_quarter_target")
    private BigDecimal secondQuarterTarget;

    @Schema(description = "第三季度指标")
    @TableField("third_quarter_target")
    private BigDecimal thirdQuarterTarget;

    @Schema(description = "第四季度指标")
    @TableField("fourth_quarter_target")
    private BigDecimal fourthQuarterTarget;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;
}
