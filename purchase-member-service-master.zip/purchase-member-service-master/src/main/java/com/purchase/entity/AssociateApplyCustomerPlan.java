package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 终端客户合作拓展计划
* </p>
*
* @author jidonglin
* @since 2024-03-25
*/
@Data
@TableName("t_mb_associate_apply_customer_plan")
@Schema(title = "终端客户合作拓展计划")
public class AssociateApplyCustomerPlan extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "申请id")
    @TableField("apply_id")
    private Integer applyId;

    @Schema(description = "终端客户名称")
    @TableField("cust_name")
    private String custName;

    @Schema(description = "主要推进项目/产品")
    @TableField("main_project")
    private String mainProject;

    @Schema(description = "协同推进计划")
    @TableField("promotion_plan")
    private String promotionPlan;

    @Schema(description = "预期推进结果")
    @TableField("expect_result")
    private String expectResult;




}
