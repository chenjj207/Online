package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


/**
 * 惠采公司表
 */
@Data
@Schema(title = "惠采公司表")
@TableName("t_purchase_company")
public class Company extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Schema(description = "公司id，从zydmall同步过来")
    @TableField("company_id")
    private Integer companyId;

    @Schema(description = "分公司编码")
    @TableField("com_bm")
    private String comBm;

    @Schema(description = "分公司名称")
    @TableField("com_name")
    private String comName;

    @Schema(description = "分公司简称")
    @TableField("short_name")
    private String shortName;

    @Schema(description = "所属大区")
    @TableField("area_name")
    private String areaName;

    @Schema(description = "所在地区编号")
    @TableField("area_bm")
    private String areaBm;

    @Schema(description = "开户银行号")
    @TableField("bank_name")
    private String bankName;

    @Schema(description = "开户帐号")
    @TableField("bank_account")
    private String bankAccount;

    @Schema(description = "开户公司名")
    @TableField("bank_com_name")
    private String bankComName;

    @Schema(description = "地址")
    @TableField("address")
    private String address;

    @Schema(description = "纳税人识别号")
    @TableField("tax_number")
    private String taxNumber;

    @Schema(description = "ifs域")
    @TableField("ifs_contract")
    private String ifsContract;

}
