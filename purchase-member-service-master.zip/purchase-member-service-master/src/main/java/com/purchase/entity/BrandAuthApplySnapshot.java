package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 品牌授权申请
* </p>
*
* @author jidonglin
* @since 2024-05-22
*/
@Data
@TableName("t_mb_brand_auth_apply_snapshot")
@Schema(title = "品牌授权申请")
public class BrandAuthApplySnapshot extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "微信在同一开放平台下的唯一身份标识")
    @TableField("union_id")
    private String unionId;

    @Schema(description = "微信用户在当前小程序的唯一身份标识")
    @TableField("open_id")
    private String openId;

    @Schema(description = "单位名称/客户名称")
    @TableField("company")
    private String company;

    @Schema(description = "联系人")
    @TableField("linkman")
    private String linkman;

    @Schema(description = "联系电话")
    @TableField("linkphone")
    private String linkphone;

    @Schema(description = "省")
    @TableField("province")
    private String province;

    @Schema(description = "市")
    @TableField("city")
    private String city;

    @Schema(description = "区")
    @TableField("area")
    private String area;

    @Schema(description = "详细地址")
    @TableField("address")
    private String address;

    @Schema(description = "所属大区")
    @TableField("area_name")
    private String areaName;

    @Schema(description = "合作单位/子公司名称")
    @TableField("sub_company")
    private String subCompany;

    @Schema(description = "签约推荐人")
    @TableField("business_person")
    private String businessPerson;

    @Schema(description = "项目推广专员")
    @TableField("promotion_person")
    private String promotionPerson;

    @Schema(description = "公司上年营业额")
    @TableField("last_year_turnover")
    private BigDecimal lastYearTurnover;

    @Schema(description = "品牌上年营业额，如：23年施耐德电气营业额")
    @TableField("brand_last_year_turnover")
    private BigDecimal brandLastYearTurnover;

    @Schema(description = "核心客户数量")
    @TableField("cust_num")
    private Integer custNum;

    @Schema(description = "员工人数")
    @TableField("user_num")
    private String userNum;

    @Schema(description = "终端（行业） 单位：%")
    @TableField("terminal")
    private String terminal;

    @Schema(description = "批发 单位：%")
    @TableField("wholesale")
    private String wholesale;

    @Schema(description = "中小项目 单位：%")
    @TableField("small_medium_project")
    private String smallMediumProject;

    @Schema(description = "OEM 单位：%")
    @TableField("oem")
    private String oem;

    @Schema(description = "门店 单位：%")
    @TableField("store")
    private String store;

    @Schema(description = "核心业务-其他 单位：%")
    @TableField("core_business_other")
    private String coreBusinessOther;

    @Schema(description = "低压配电 单位：%")
    @TableField("low_voltage")
    private String lowVoltage;

    @Schema(description = "工业自动化 单位：%")
    @TableField("industrial_auto")
    private String industrialAuto;

    @Schema(description = "面板开关 单位：%")
    @TableField("panel_switch")
    private String panelSwitch;

    @Schema(description = "主要业务-其他 单位：%")
    @TableField("main_business_other")
    private String mainBusinessOther;

    @Schema(description = "se")
    @TableField("se")
    private String se;

    @Schema(description = "abb")
    @TableField("abb")
    private String abb;

    @Schema(description = "Siemens")
    @TableField("siemens")
    private String siemens;

    @Schema(description = "合作品牌-其他")
    @TableField("cooperate_brand_other")
    private String cooperateBrandOther;

    @Schema(description = "国产")
    @TableField("domestic")
    private String domestic;

    @Schema(description = "增长类型：正增长 负增长")
    @TableField("growth_type")
    private String growthType;

    @Schema(description = "增长比例")
    @TableField("growth_rate")
    private String growthRate;

    @Schema(description = "原因")
    @TableField("growth_reason")
    private String growthReason;

    @Schema(description = "品牌形象")
    @TableField("brand_image")
    private String brandImage;

    @Schema(description = "品牌商城")
    @TableField("brand_mall")
    private String brandMall;

    @Schema(description = "数字化营销")
    @TableField("digital_market")
    private String digitalMarket;

    @Schema(description = "上游诉求")
    @TableField("upstream_demand")
    private String upstreamDemand;

    @Schema(description = "次终端诉求")
    @TableField("second_terminal_demand")
    private String secondTerminalDemand;

    @Schema(description = "上游分销商（线上）")
    @TableField("online_upstream_distributor")
    private String onlineUpstreamDistributor;

    @Schema(description = "上游分销商（线下）")
    @TableField("offline_upstream_distributor")
    private String offlineUpstreamDistributor;

    @Schema(description = "终端客户名称")
    @TableField("end_cust_name")
    private String endCustName;

    @Schema(description = "终端客户23年总采购额")
    @TableField("total_purchase_last_year")
    private BigDecimal totalPurchaseLastYear;

    @Schema(description = "授权需求")
    @TableField("auth_require")
    private String authRequire;

    @Schema(description = "备注（其他补充说明）")
    @TableField("demand_remark")
    private String demandRemark;

    @Schema(description = "上年合作采购额")
    @TableField("last_year_cooperate_purchase")
    private BigDecimal lastYearCooperatePurchase;

    @Schema(description = "上年施耐德采购额")
    @TableField("last_year_brand_purchase")
    private BigDecimal lastYearBrandPurchase;

    @Schema(description = "全年指标")
    @TableField("year_annual_indicators")
    private BigDecimal yearAnnualIndicators;

    @Schema(description = "第一季度指标")
    @TableField("one__indicators")
    private BigDecimal oneIndicators;

    @Schema(description = "第二季度指标")
    @TableField("two__indicators")
    private BigDecimal twoIndicators;

    @Schema(description = "第三季度指标")
    @TableField("three__indicators")
    private BigDecimal threeIndicators;

    @Schema(description = "	第四季度指标")
    @TableField("four__indicators")
    private BigDecimal fourIndicators;

    @Schema(description = "单位：（个工作日内）采购首批协议产品	")
    @TableField("after_sign_day")
    private Integer afterSignDay;

    @Schema(description = "计算关联带出，根据填写的【24全年指标*10%】得出，不可修改")
    @TableField("first_purchase_amount")
    private BigDecimal firstPurchaseAmount;

    @Schema(description = "开户名称")
    @TableField("account_name")
    private String accountName;

    @Schema(description = "银行账号")
    @TableField("bank_account_num")
    private String bankAccountNum;

    @Schema(description = "开户银行")
    @TableField("opening_bank")
    private String openingBank;

    @Schema(description = "纳税人识别号")
    @TableField("tax_identification")
    private String taxIdentification;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;

    @Schema(description = "状态：1、待审批  2、同意授权  3、拒绝授权  4、已存档 5、已发放  6、拒绝发放")
    @TableField("state")
    private String state;

    @Schema(description = "拒绝原因")
    @TableField("reject_reason")
    private String rejectReason;

    @Schema(description = "发放拒绝原因")
    @TableField("grant_reason")
    private String grantReason;

    @Schema(description = "年 如：2024")
    @TableField("year")
    private Integer year;

    @Schema(description = "授权期限 1、第一季度 2、第二季度 3、第三季度 4、第四季度")
    @TableField("auth_time")
    private String authTime;

    @Schema(description = "计划采购额")
    @TableField("plan_purchase")
    private BigDecimal planPurchase;

    @Schema(description = "协议地址")
    @TableField("protocol_url")
    private String protocolUrl;




}
