package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Digits;

/**
* <p>
* 计划合作产品基础信息
* </p>
*
* @author jidonglin
* @since 2024-03-14
*/
@Data
@TableName("t_mb_associate_apply_product_plan")
@Schema(title = "计划合作产品基础信息")
public class AssociateApplyProductPlan extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "申请id")
    @TableField("apply_id")
    private Integer applyId;

    @Schema(description = "产品名称")
    @TableField("product_name")
    private String productName;

    @Schema(description = "品牌")
    @TableField("brand")
    private String brand;

    @Schema(description = "国内市场容量（万）")
    @TableField("market_capacity")
    @Digits(integer=6, fraction=4, message = "国内市场容量错误，请重新输入")
    private BigDecimal marketCapacity;

    @Schema(description = "计划上线SKU数量（个）")
    @TableField("plan_sku_num")
    @Digits(integer=6, fraction=4, message = "计划上线SKU数量错误，请重新输入")
    private Integer planSkuNum;

    @Schema(description = "2023年本公司销售额（万）")
    @TableField("last_year_sale_volume")
    @Digits(integer=6, fraction=4, message = "全年销售额错误，请重新输入")
    private BigDecimal lastYearSaleVolume;





}
