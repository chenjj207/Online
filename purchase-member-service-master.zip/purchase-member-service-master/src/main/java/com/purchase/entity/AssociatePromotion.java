package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 项目推广专员配置表
* </p>
*
* @author jidonglin
* @since 2024-03-15
*/
@Data
@TableName("t_mb_associate_promotion")
@Schema(title = "项目推广专员配置表")
public class AssociatePromotion extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "公司名称")
    @TableField("company_name")
    private String companyName;

    @Schema(description = "项目推广专员")
    @TableField("promotion_person")
    private String promotionPerson;
;

    @Schema(description = "工号")
    @TableField("code")
    private String code;




}
