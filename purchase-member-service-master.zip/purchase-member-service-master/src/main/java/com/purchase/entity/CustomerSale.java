package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.purchase.service.vo.RecommendProductVO;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;


/**
 * 惠采客户销售金额
 */
@Data
@Schema(title = "惠采客户销售金额表")
@TableName("t_purchase_customer_sale")
public class CustomerSale {
    private static final long serialVersionUID = 1L;

    @Schema(description = "域")
    @TableField("ybm")
    private String ybm;

    @Schema(description = "公司简称")
    @TableField("gsjc")
    private String gsjc;

    @Schema(description = "客户编码")
    @TableField("khbm")
    private String khbm;

    @Schema(description = "客户名称")
    @TableField("khmc")
    private String khmc;

    @Schema(description = "施耐德品牌的第1季度销售额")
    @TableField("snd_s1_xsje")
    private BigDecimal sndS1Xsje;

    @Schema(description = "施耐德品牌的第2季度销售额")
    @TableField("snd_s2_xsje")
    private BigDecimal sndS2Xsje;

    @Schema(description = "施耐德品牌的第3季度销售额")
    @TableField("snd_s3_xsje")
    private BigDecimal sndS3Xsje;

    @Schema(description = "施耐德品牌的第4季度销售额")
    @TableField("snd_s4_xsje")
    private BigDecimal sndS4Xsje;

    @Schema(description = "施耐德品牌的全年销售")
    @TableField("snd_qn_xsje")
    private BigDecimal sndQnXsje;

    @Schema(description = "分销汇总的第1季度销售")
    @TableField("fxhz_s1_xsje")
    private BigDecimal fxhzS1Xsje;

    @Schema(description = "分销汇总的第2季度销售")
    @TableField("fxhz_s2_xsje")
    private BigDecimal fxhzS2Xsje;

    @Schema(description = "分销汇总的第3季度销售")
    @TableField("fxhz_s3_xsje")
    private BigDecimal fxhzS3Xsje;

    @Schema(description = "分销汇总的第4季度销售")
    @TableField("fxhz_s4_xsje")
    private BigDecimal fxhzS4Xsje;

    @Schema(description = "分销汇总的全年销售")
    @TableField("fxhz_qn_xsje")
    private BigDecimal fxhzQnXsje;

    @Schema(description = "年份")
    @TableField("nf")
    private String nf;

    @Schema(description = "数据日期")
    @TableField("sjrq")
    private String sjrq;

    @Schema(description = "")
    @TableField("sjcrsj")
    private String sjcrsj;

    @Schema(description = "创建者")
    @TableField("created_by")
    private String createdBy;

    @Schema(description = "创建时间")
    @TableField("created_at")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createdAt;

    @Schema(description = "更新者")
    @TableField("updated_by")
    private Integer updatedBy;

    @Schema(description = "更新时间")
    @TableField("updated_at")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updatedAt;

}
