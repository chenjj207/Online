package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 资讯表
* </p>
*
* @author jidonglin
* @since 2023-02-03
*/
@Data
@TableName("t_mb_real_news")
@Schema(title = "资讯表")
public class RealNews extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Schema(description = "资讯标题")
    @TableField("consult_title")
    private String consultTitle;

    @Schema(description = "资讯内容")
    @TableField("consult_info")
    private String consultInfo;

    @Schema(description = "资讯发布者")
    @TableField("publisher")
    private String publisher;

    @Schema(description = "主图")
    @TableField("first_pic")
    private String firstPic;

    @Schema(description = "发布页面： firstPage：首页   center：资讯中心")
    @TableField("page")
    private String page;

    @Schema(description = "是否显示(0为未发布,1为发布)")
    @TableField("is_show")
    private Integer isShow;

    @Schema(description = "是否开启感兴趣(0为未开启，1为开启)")
    @TableField("is_open_interested")
    private Integer isOpenInterested;

    @Schema(description = "浏览数")
    @TableField("browse_num")
    private Integer browseNum;

    @Schema(description = "资讯类型")
    @TableField("consult_type")
    private String consultType;

    @Schema(description = "资源类型(product=产品资源，service=服务资源)")
    @TableField("resource_type")
    private String resourceType;
}
