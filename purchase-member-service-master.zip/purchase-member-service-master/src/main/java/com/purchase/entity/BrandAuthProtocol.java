package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 品牌授权协议存档
* </p>
*
* @author jidonglin
* @since 2024-06-03
*/
@Data
@TableName("t_mb_brand_auth_protocol")
@Schema(title = "品牌授权协议存档")
public class BrandAuthProtocol extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "品牌授权id")
    @TableField("brand_auth_id")
    private Integer brandAuthId;

    @Schema(description = "文件名称")
    @TableField("name")
    private String name;

    @Schema(description = "上传人")
    @TableField("upload_person")
    private String uploadPerson;

    @Schema(description = "文件地址")
    @TableField("url")
    private String url;




}
