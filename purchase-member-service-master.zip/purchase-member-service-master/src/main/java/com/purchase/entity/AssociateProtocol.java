package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
* <p>
* 联营协议
* </p>
*
* @author jidonglin
* @since 2024-04-01
*/
@Data
@TableName("t_mb_associate_protocol")
@Schema(title = "联营协议")
public class AssociateProtocol extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "申请id")
    @TableField("apply_id")
    private Integer applyId;

    @Schema(description = "协议编号")
    @TableField("code")
    private String code;

    @Schema(description = "协议类型")
    @TableField("type")
    private String type;

    @Schema(description = "状态：1、待生效  2、已生效  3、已过期  4、已作废")
    @TableField("state")
    private String state;

    @Schema(description = "寄出时间")
    @TableField("sent_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class,as = LocalDateTime.class)
    private LocalDateTime sentTime;

    @Schema(description = "签约时间")
    @TableField("sign_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class,as = LocalDateTime.class)
    private LocalDateTime signTime;

    @Schema(description = "归档时间")
    @TableField("file_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class,as = LocalDateTime.class)
    private LocalDateTime fileTime;

    @Schema(description = "作废原因")
    @TableField("cancel_reason")
    private String cancelReason;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;

    @Schema(description = "小程序用户是否已读 0：否 1：是")
    @TableField("is_read")
    private String isRead;

    @Schema(description = "创建人")
    @TableField("created_person")
    private String createdPerson;

    @Schema(description = "协议链接")
    @TableField("protocol_url")
    private String protocolUrl;

    @Schema(description = "是否有授权 1：是 0：否")
    @TableField("auth")
    private String auth;

    @Schema(description = "申请年份")
    @TableField("apply_nf")
    private Integer applyNf;

    @Schema(description = "单位名称")
    @TableField(exist = false)
    private String company;

    @Schema(description = "项目推广专员")
    @TableField(exist = false)
    private String promotionPerson;

    @Schema(description = "子公司名称")
    @TableField(exist = false)
    private String subCompany;

    @Schema(description = "业务人员/签约推荐人")
    @TableField(exist = false)
    private String businessPerson;
}
