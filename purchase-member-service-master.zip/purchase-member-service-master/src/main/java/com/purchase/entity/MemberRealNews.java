package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
*
* </p>
*
* @author jidonglin
* @since 2023-04-12
*/
@Data
@TableName("t_mb_member_real_news")
@Schema(title = "会员资讯表")
public class MemberRealNews extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "资讯id")
    @TableField("real_news_id")
    private Integer realNewsId;

    @Schema(description = "会员id")
    @TableField("member_id")
    private Integer memberId;

    @Schema(description = "是否感兴趣： 1：感兴趣  0：不感兴趣")
    @TableField("interested")
    private Integer interested;




}
