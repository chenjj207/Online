package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


/**
 * <p>
 * 资讯分类表
 * </p>
 *
 * @author
 * @since 2023-02-10
 */
@Data
@Schema(title = "资讯分类表")
@TableName("t_mb_real_news_type")
public class RealNewsType extends BaseEntity {

    @Schema(description = "资讯分类名")
    @TableField("type_name")
    private String typeName;

    @Schema(description = "发布页面： firstPage：首页   center：资讯中心")
    @TableField("page")
    private String page;


}
