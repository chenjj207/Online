package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * <p>
 * 协作回复表
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Data
@Schema(title = "协作回复表")
@TableName("t_mb_cooperation_reply")
public class CooperationReply extends BaseEntity {

    @Schema(description = "协作id")
    @TableField("team_id")
    private Integer teamId;

    @Schema(description = "资讯id")
    @TableField("real_news_id")
    private Integer realNewsId;

    @Schema(description = "协作信息")
    @TableField("content")
    private String content;

    @Schema(description = "是否已读（0=未读，1=已读，默认为未读）")
    @TableField("is_read")
    private Integer isRead;

    @Schema(description = "会员id")
    @TableField("member_id")
    private Integer memberId;

    @Schema(description = "会员公司")
    @TableField(exist = false)
    private String company;

    @Schema(description = "联系人")
    @TableField(exist = false)
    private String linkman;

    @Schema(description = "联系方式")
    @TableField(exist = false)
    private String linkphone;

    @Schema(description = "会员头像地址")
    @TableField(exist = false)
    private String iconUrl;
}
