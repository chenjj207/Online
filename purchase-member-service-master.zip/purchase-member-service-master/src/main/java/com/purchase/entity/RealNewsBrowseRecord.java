package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 资讯浏览记录
* </p>
*
* @author jidonglin
* @since 2024-03-01
*/
@Data
@TableName("t_mb_real_news_browse_record")
@Schema(title = "资讯浏览记录")
public class RealNewsBrowseRecord extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "公司名称")
    @TableField("company_name")
    private String companyName;

    @Schema(description = "账号")
    @TableField("linkphone")
    private String linkphone;

    @Schema(description = "ip地址")
    @TableField("ip_address")
    private String ipAddress;

    @Schema(description = "资讯id")
    @TableField("real_news_id")
    private Integer realNewsId;
}
