package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * <p>
 * 消息表
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Data
@Schema(title = "消息表")
@TableName("t_mb_message")
public class Message extends BaseEntity {

    @Schema(description = "消息标题")
    @TableField("notice_title")
    private String noticeTitle;

    @Schema(description = "消息内容")
    @TableField("notice_info")
    private String noticeInfo;

    @Schema(description = "接收者类型")
    @TableField("receiver_type")
    private String receiverType;

    @Schema(description = "附件路径")
    @TableField("accessory_url")
    private String accessoryUrl;

}
