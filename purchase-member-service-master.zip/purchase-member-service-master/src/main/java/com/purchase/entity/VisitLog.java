package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 联营慧访问日志记录表
* </p>
*
* @author jidonglin
* @since 2023-06-29
*/
@Data
@TableName("t_mb_visit_log")
@Schema(title = "联营慧访问日志记录表")
public class VisitLog extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "记录时间")
    @TableField("access_time")
    private String accessTime;

    @Schema(description = "ip地址")
    @TableField("ip_address")
    private String ipAddress;

    @Schema(description = "访问次数")
    @TableField("visit_times")
    private Integer visitTimes;




}
