package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


/**
 * <p>
 * 客户搜索历史表
 * </p>
 *
 * @author
 * @since 2023-02-10
 */
@Data
@Schema(title = "客户搜索历史表")
@TableName("t_mb_member_search_history")
public class MemberSearchHistory extends BaseEntity {


    @Schema(description = "搜索关键字")
    @TableField("search_key")
    private String searchKey;

    @Schema(description = "所属会员id")
    @TableField("member_id")
    private Integer memberId;

}
