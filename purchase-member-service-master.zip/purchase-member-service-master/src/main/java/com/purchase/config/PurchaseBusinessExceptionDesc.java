package com.purchase.config;

import com.zyd.framework.utils.exception.BaseExceptionDesc;
import com.zyd.framework.utils.exception.BusinessExceptionDesc;

/**
 * @author jidonglin
 * @Description: 服务异常码
 * @date 2023/2/7  16:03
 */
public class PurchaseBusinessExceptionDesc extends BusinessExceptionDesc {
    public static BaseExceptionDesc SEND_SMS_ERROR = new BaseExceptionDesc(-20000, "短信发送异常");
    public static BaseExceptionDesc NOT_EXIST_PHONE = new BaseExceptionDesc(-20001, "该手机号码不存在，请先注册");
    public static BaseExceptionDesc NOT_EXIST_SMS_TYPE = new BaseExceptionDesc(-20002, "不存在此验证码类型");
    public static BaseExceptionDesc NOT_EXIST_COO = new BaseExceptionDesc(-20003, "协作不存在");
    public static BaseExceptionDesc WX_LOGIN_ERROR = new BaseExceptionDesc(-20004, "微信登录异常");
    public static BaseExceptionDesc ALI_SMS_ERROR = new BaseExceptionDesc(-20005, "验证码错误，请确认后重新输入");
    public static BaseExceptionDesc PHONE_OCCUPIED = new BaseExceptionDesc(-20006, "该手机号码已经被占用");
    public static BaseExceptionDesc USER_NOT_EXIST = new BaseExceptionDesc(-20007, "用户不存在");
    public static BaseExceptionDesc REAL_NEW_EXIST = new BaseExceptionDesc(-20008, "协作已存在");
    public static BaseExceptionDesc NOT_EXIST_COMPANY = new BaseExceptionDesc(-20009, "不存在此公司");
    public static BaseExceptionDesc NOT_EXIST_MEMBER = new BaseExceptionDesc(-20010, "接受对象不存在");
    public static BaseExceptionDesc ERROR_GET_WX_PHONE = new BaseExceptionDesc(-20011, "获取微信手机号异常");
    public static BaseExceptionDesc NOT_EXIST_REAL_NEWS = new BaseExceptionDesc(-20012, "资讯不存在");
    public static BaseExceptionDesc NEED_NOT_PASS_REASON = new BaseExceptionDesc(-20013, "请说明不通过原因");
    public static BaseExceptionDesc NOT_EXIST_MESSAGE = new BaseExceptionDesc(-20014, "消息不存在");
    public static BaseExceptionDesc NOT_VIEW_MEMBER = new BaseExceptionDesc(-20015, "会员信息不能查看");
    public static BaseExceptionDesc UN_ABLE_DELETE = new BaseExceptionDesc(-20016, "无法删除");
    public static BaseExceptionDesc EXIST_PHONE = new BaseExceptionDesc(-20017, "手机号码已注册");
    public static BaseExceptionDesc PHONE_WITH_OPENID = new BaseExceptionDesc(-20018, "该账号已有绑定微信号，请确认解绑微信号或者退出登录");
    public static BaseExceptionDesc OPENID_BIND_PHONE = new BaseExceptionDesc(-20019, "当前微信号已关联账号，请确认继续解绑微信号或者退出登录");
    public static BaseExceptionDesc FORMAL_ERROR = new BaseExceptionDesc(-20020, "联系方式格式错误，请重新输入");
    public static BaseExceptionDesc FORMAL_ERROR_CONTAINS_SPACES = new BaseExceptionDesc(-20021, "联系方式有误，不能含有空格");
    public static BaseExceptionDesc ERROR_ADD_CUSTOMER = new BaseExceptionDesc(-20022, "会员绑定客户失败");
    public static BaseExceptionDesc ERROR_MEMBER_STATE = new BaseExceptionDesc(-20023, "会员状态未通过");
    public static BaseExceptionDesc MEMBER_BIND_SUPPLIER = new BaseExceptionDesc(-20024, "该会员已有供应商账号，请重试");
    public static BaseExceptionDesc ERROR_BIND_SUPPLIER = new BaseExceptionDesc(-20024, "供应商创建失败");
    public static BaseExceptionDesc THE_CORE_COMPETENCE_DESCRIPTION_CANNOT_EXCEED = new BaseExceptionDesc(-20025, "核心能力描述不能超过300");
    public static BaseExceptionDesc THE_CORE_ADDRESS_DESCRIPTION_CANNOT_EXCEED = new BaseExceptionDesc(-20026, "地址不能超过30");
    public static BaseExceptionDesc DATA_SYNCHRONIZATION_ERROR = new BaseExceptionDesc(-20027, "数据同步错误");
    public static BaseExceptionDesc ERROR_STATISTICS_TYPE = new BaseExceptionDesc(-20028, "统计类型错误");
    public static BaseExceptionDesc ERROR_RESOURCE_TYPE = new BaseExceptionDesc(-20029, "资源类型错误");
    public static BaseExceptionDesc ERROR_NEED_TYPE = new BaseExceptionDesc(-20030, "需求类型错误");
    public static BaseExceptionDesc NOT_NULL_EXPIRE_TIME = new BaseExceptionDesc(-20031, "需求有效期不能为空");
    public static BaseExceptionDesc ERROR_AUDIT_COO = new BaseExceptionDesc(-20032, "审核协作失败");
    public static BaseExceptionDesc NOT_EXIST_RESOURCE_TYPE = new BaseExceptionDesc(-20033, "不存在此协作类型");
    public static BaseExceptionDesc ERROR_AUDIT_STATE = new BaseExceptionDesc(-20034, "审核状态错误");
    public static BaseExceptionDesc HAS_AUDIT = new BaseExceptionDesc(-20035, "协作已审核");
    public static BaseExceptionDesc EXPIRE_NEED_SERVICE = new BaseExceptionDesc(-20036, "服务协同需求协作已过期");
    public static BaseExceptionDesc ERROR_AFTER_NOW = new BaseExceptionDesc(-20037, "服务协同需求协作有效期要大于当前时间");
    public static BaseExceptionDesc ERROR_AUDIT_STATUS = new BaseExceptionDesc(-20038, "审核状态未通过");
    public static BaseExceptionDesc NOT_EXIST_NEED_TAB = new BaseExceptionDesc(-20039, "不存在此需求tab");
    public static BaseExceptionDesc ERROR_SEND_MESSAGE = new BaseExceptionDesc(-20040, "留言失败");
    public static BaseExceptionDesc ERROR_COO_TO_REPLY = new BaseExceptionDesc(-20041, "当前协作类型不支持回复");
    public static BaseExceptionDesc NOT_NULL_MEMBER_ID = new BaseExceptionDesc(-20042, "会员id不能为空");
    public static BaseExceptionDesc NOT_NULL_NEED_BRAND = new BaseExceptionDesc(-20043, "品牌不能为空");
    public static BaseExceptionDesc EXIST_OPENID_ASSOCIATE = new BaseExceptionDesc(-20044, "当前用户已申请合作项目, 请重新处理");
    public static BaseExceptionDesc EXIST_COMPANY_ASSOCIATE = new BaseExceptionDesc(-20045, "该公司已提交申请，请重新处理");
    public static BaseExceptionDesc COOPERATION_INCOMPLETE_PARAMETERS = new BaseExceptionDesc(-20046, "计划合作产品基础信息参数不全");
    public static BaseExceptionDesc NOT_EXIST_PROMOTION = new BaseExceptionDesc(-20047, "不存在项目推广专员");
    public static BaseExceptionDesc NO_LOGIN = new BaseExceptionDesc(-20048, "未登录");
    public static BaseExceptionDesc NOT_EXIST_ASSOCIATE = new BaseExceptionDesc(-20049, "不存在联营签约申请");
    public static BaseExceptionDesc MUST_ASSOCIATE_REJECT_REASON = new BaseExceptionDesc(-20050, "请填写拒绝签约的原因");
    public static BaseExceptionDesc NOT_NULL_FILE_INFO = new BaseExceptionDesc(-20051, "文件资料不能为空");
    public static BaseExceptionDesc NOT_NULL_COOPERATION_PROJECT = new BaseExceptionDesc(-20052, "企业相关资料不能为空");
    public static BaseExceptionDesc NOT_NULL_WORKING_TYPE = new BaseExceptionDesc(-20053, "商品供应性质不能为空");
    public static BaseExceptionDesc NOT_NULL_NATURE_OPERATION = new BaseExceptionDesc(-20054, "公司经营性质不能为空");
    public static BaseExceptionDesc NOT_NULL_LAST_YEAR_PURCHASE = new BaseExceptionDesc(-20055, "上年合作采购金额不能为空");
    public static BaseExceptionDesc NOT_NULL_THIS_YEAR_PURCHASE = new BaseExceptionDesc(-20056, "今年计划采购金额不能为空");
    public static BaseExceptionDesc NOT_NULL_FIRST_ORDER_PURCHASE = new BaseExceptionDesc(-20057, "签约首单采购金额不能为空");
    public static BaseExceptionDesc CUST_PLAN_INCOMPLETE_PARAMETERS = new BaseExceptionDesc(-20058, "终端客户合作拓展计划信息参数不全");
    public static BaseExceptionDesc TARGET_INCOMPLETE_PARAMETERS = new BaseExceptionDesc(-20059, "年度采购计划分解表参数不全");
    public static BaseExceptionDesc ERROR_NUM_CUST_PLAN = new BaseExceptionDesc(-20060, "终端客户合作拓展计划个数错误");
    public static BaseExceptionDesc NOT_NULL_ASSOCIATE_PROTOCOL = new BaseExceptionDesc(-20061, "联营协议不存在");
    public static BaseExceptionDesc NOT_NULL_CANCEL_REASON = new BaseExceptionDesc(-20062, "作废原因不能为空");
    public static BaseExceptionDesc EXIST_OPENID_BRAND_AUTH = new BaseExceptionDesc(-20063, "再次续签需保证单位名称相同");
    public static BaseExceptionDesc EXIST_COMPANY_BRAND_AUTH = new BaseExceptionDesc(-20064, "该公司已提交品牌授权，请重新处理");
    public static BaseExceptionDesc NOT_EXIST_BRAND_AUTH_APPLY = new BaseExceptionDesc(-20065, "不存在品牌授权");
    public static BaseExceptionDesc NOT_NULL_PLANPURCHASE = new BaseExceptionDesc(-20066, "下季度计划采购额必填");
    public static BaseExceptionDesc NOT_NULL_REJECT_REASON = new BaseExceptionDesc(-20067, "请填写拒绝原因");
    public static BaseExceptionDesc NOT_RENEWAL = new BaseExceptionDesc(-20068, "当前季度无法续约，需重新申请");
    public static BaseExceptionDesc ERROR_CREATE_CX_PROTOCOL = new BaseExceptionDesc(-20069, "产线协议生成异常");
    public static BaseExceptionDesc ERROR_CREATE_QD_PROTOCOL = new BaseExceptionDesc(-20070, "渠道协议生成异常");
    public static BaseExceptionDesc ERROR_ASSOCIATE_COMPANY = new BaseExceptionDesc(-20071, "单位名称不支持修改");
    public static BaseExceptionDesc ERROR_BRAND_AUTH_COMPANY = new BaseExceptionDesc(-20072, "单位名称不支持修改");
    public static BaseExceptionDesc NOT_EXIST_ASSOCIATE_PROTOCOL = new BaseExceptionDesc(-20073, "不存在联营协议");
    public static BaseExceptionDesc FORWARDING_ORDER_GENERATION_FAILED = new BaseExceptionDesc(-20074, "转发订单生成失败");
    public static BaseExceptionDesc NOT_EDIT_ASSOCIATE_BRAND = new BaseExceptionDesc(-20075, "状态已更新，禁止修改");
    public static BaseExceptionDesc ERROR_EQUAL_ANNUAL_TARGET = new BaseExceptionDesc(-20076, "拆分季度的指标不等于全年指标，请重新填写");
    public static BaseExceptionDesc NOT_EDIT_MINI_COOPERATIONPROJECT = new BaseExceptionDesc(-20077, "申请合作项目暂不支持修改");
    public static BaseExceptionDesc NOT_EDIT_ADMIN_BRAND_AUTH_APPLY = new BaseExceptionDesc(-20078, "当前申请不能修改");
    public static BaseExceptionDesc CAN_NOT_SENT = new BaseExceptionDesc(-20079, "当前状态无法修改为待生效");
    public static BaseExceptionDesc ERROR_COUNT_CUST_NAME = new BaseExceptionDesc(-20080, "服务终端数量必须≥5家");
}

