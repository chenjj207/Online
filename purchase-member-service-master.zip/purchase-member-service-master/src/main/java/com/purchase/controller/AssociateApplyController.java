package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.AssociateApply;
import com.purchase.service.AssociateApplyService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CommonCountVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 联营申请表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-14
 */
@RestController
@RequestMapping("/associate-apply")
public class AssociateApplyController {

    @Autowired
    AssociateApplyService associateApplyService;

    @PostMapping("/add")
    @Operation(summary = "添加联营申请表")
    @Auth(value = AuthType.NONE)
    public String add(@Valid @RequestBody AssociateApplyAddDTO associateApplyAddDTO){
        return associateApplyService.add(associateApplyAddDTO);
    }

    @PostMapping("/queryByJsCode")
    @Operation(summary = "根据jscode查询联营申请表")
    @Auth(value = AuthType.NONE)
    public AssociateApply queryByJsCode(@Valid @RequestBody AssociateApplyQueryDTO associateApplyQueryDTO){
        return associateApplyService.queryByJsCode(associateApplyQueryDTO);
    }

    @PostMapping("/queryById")
    @Operation(summary = "根据id查询联营申请表")
    @Auth(value = AuthType.NONE)
    public AssociateApply queryById(@Valid @RequestBody QueryIdDTO queryIdDTO){
        return associateApplyService.queryById(queryIdDTO);
    }

    @PostMapping("/queryByOpenId")
    @Operation(summary = "根据id查询联营申请表")
    @Auth(value = AuthType.NONE)
    public List<AssociateApply> queryByOpenId(@Valid @RequestBody OpenIdDTO openIdDTO){
        return associateApplyService.queryByOpenId(openIdDTO);
    }

    @PostMapping("/queryPurchaseCompany")
    @Operation(summary = "查询所属子公司列表")
    @Auth(value = AuthType.NONE)
    public List<PurchaseCompanyDTO> queryPurchaseCompany(){
        return associateApplyService.queryPurchaseCompany();
    }

    @PostMapping("/edit")
    @Operation(summary = "惠采后台 --编辑")
    @Auth(value = AuthType.NONE)
    public Boolean edit(@Valid @RequestBody AssociateApplyEditDTO associateApplyEditDTO){
        return associateApplyService.edit(associateApplyEditDTO);
    }

    @PostMapping("/edit/mini")
    @Operation(summary = "惠采后台/联营慧 --编辑")
    @Auth(value = AuthType.NONE)
    public String editMini(@Valid @RequestBody AssociateApplyEditDTO associateApplyEditDTO){
        return associateApplyService.editMini(associateApplyEditDTO);
    }

    @PostMapping("/page")
    @Operation(summary = "惠采后台--查询联营申请表分页")
    @Auth(value = AuthType.NONE)
    public Page<AssociateApply> queryList(@RequestBody AssociateApplyPageDTO associateApplyPageDTO){
        return associateApplyService.queryList(associateApplyPageDTO);
    }

    @PostMapping("/count")
    @Operation(summary = "惠采后台--数量统计")
    @Auth(value = AuthType.NONE)
    public List<CommonCountVO> countNum(@Valid @RequestBody AssociateApplyCountDTO associateApplyCountDTO){
        return associateApplyService.countNum(associateApplyCountDTO);
    }

    @PostMapping("/edit/research")
    @Operation(summary = "惠采后台--审核调研")
    @Auth(value = AuthType.NONE)
    public Boolean editResearch(@Valid @RequestBody AssociateApplyEditResearchDTO associateApplyEditResearchDTO){
        return associateApplyService.editResearch(associateApplyEditResearchDTO);
    }

    @PostMapping("/edit/approval")
    @Operation(summary = "惠采后台--审批")
    @Auth(value = AuthType.NONE)
    public Boolean editApproval(@Valid @RequestBody AssociateApplyEditApprovalDTO associateApplyEditApprovalDTO){
        return associateApplyService.editApproval(associateApplyEditApprovalDTO);
    }
}
