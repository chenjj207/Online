package com.purchase.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.service.dto.*;
import com.purchase.service.impl.CooperationServiceImpl;
import com.purchase.service.vo.CooperationInfoVO;
import com.purchase.service.vo.CooperationPageVO;
import com.purchase.service.vo.MemberCooperationVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


/**
 * <p>
 * 协作表 前端控制器
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@RestController
@RequestMapping("/cooperation")
public class CooperationController {

    @Autowired
    CooperationServiceImpl cooperationService;

    @PostMapping("/page")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "联营慧管理端---查询协作列表分页列表")
    public Page<CooperationPageVO> search(@RequestBody CooperationPageDTO cooperationPageDTO){
        return cooperationService.search(cooperationPageDTO);
    }

    @PostMapping("/add")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "联营慧小程序 -- 新增协作")
    public Boolean add(@Valid @RequestBody CooperationAddDTO cooperationAddDTO){
        return cooperationService.add(cooperationAddDTO, true);
    }

    @PostMapping("/inquire")
    @Operation(summary = "获取当前用户的协作与回复的查看状态")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<MemberCooperationVO> inquire(@RequestBody MemberCooperationDTO memberCooperationDTO) {
        return cooperationService.inquire(memberCooperationDTO);
    }

    @PostMapping("/query")
    @Operation(summary = "联营慧管理端---根据协作id,查询协作详情")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public CooperationInfoVO queryInfo(@Valid @RequestBody QueryIdDTO queryIdDTO){
        return cooperationService.queryInfo(queryIdDTO);
    }

    @PostMapping("/mall/add")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "联营慧协同PC -- 新增协作")
    public Boolean cooperateAdd(@Valid @RequestBody CooperationMallAddDTO cooperationMallAddDTO){
        return cooperationService.mallAdd(cooperationMallAddDTO);
    }

    @PostMapping("/audit")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "联营慧管理端 -- 审核协作")
    public Boolean audit(@Valid @RequestBody CooperationAuditDTO cooperationAuditDTO){
        return cooperationService.audit(cooperationAuditDTO);
    }

}
