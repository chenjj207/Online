package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.RealNewsBrowseRecord;
import com.purchase.service.RealNewsBrowseRecordService;
import com.purchase.service.dto.RealNewsBrowseRecordPageDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 资讯浏览记录 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-01
 */
@RestController
@RequestMapping("/real-news-browse-record")
public class RealNewsBrowseRecordController {

    @Autowired
    RealNewsBrowseRecordService realNewsBrowseRecordService;

    @PostMapping(value = "/page")
    @Operation(summary  = "联营慧管理端---资讯浏览记录", description = "资讯浏览记录分页")
    @Auth(value = AuthType.NONE)
    public Page<RealNewsBrowseRecord> search(@RequestBody RealNewsBrowseRecordPageDTO realNewsBrowseRecordPageDTO) {
        return realNewsBrowseRecordService.search(realNewsBrowseRecordPageDTO);
    }
}
