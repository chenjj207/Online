package com.purchase.controller;

import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.service.MemberService;
import com.purchase.service.dto.*;
import com.purchase.entity.Member;
import com.purchase.service.impl.MemberExcelService;
import com.purchase.service.vo.*;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@RestController
@RequestMapping("/member")
public class MemberController {

    @Autowired
    MemberService memberService;

    @Autowired
    MemberExcelService memberExcelService;

    @PostMapping("/check")
    @Operation(summary = "当前微信用户 对应的会员信息")
    @Auth(value = AuthType.NONE)
    public Member check(@Valid @RequestBody MemberCheckDTO memberCheckDTO){
        return memberService.check(memberCheckDTO);
    }


    @PostMapping("/regist")
    @Operation(summary = "会员注册")
    @Auth(value = AuthType.NONE)
    public Boolean regist(@Valid @RequestBody MemberRegisterDTO memberRegisterDTO){
        return memberService.regist(memberRegisterDTO);
    }

    @PostMapping("/login/check")
    @Operation(summary = "登录校验")
    @Auth(value = AuthType.NONE)
    public Member loginCheck(@Valid @RequestBody MemberLoginCheckDTO memberLoginCheckDTO){
        return memberService.loginCheck(memberLoginCheckDTO);
    }

    @PostMapping(value = "wx/login")
    @Operation(summary = "微信用户一键登录")
    @Auth(value = AuthType.NONE)
    public String wxlogin(@Valid @RequestBody MemberWXLoginDTO memberWXLoginDTO, HttpServletRequest request){
        return memberService.wxlogin(memberWXLoginDTO,request);
    }

    @PostMapping(value = "login")
    @Operation(summary = "会员登录")
    @Auth(value = AuthType.NONE)
    public String login(@Valid @RequestBody MemberLoginDTO memberLoginDTO,HttpServletRequest request){
        return memberService.login(memberLoginDTO,request);
    }

    @PostMapping(value = "loginOut")
    @Operation(summary = "会员退出登录")
    @Auth(value = AuthType.NONE)
    public Boolean loginOut(){
        memberService.loginOut();
        return true;
    }

    @PostMapping("/query")
    @Operation(summary = "根据token查询单个会员详情")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Member queryInfoByToken(){
        return memberService.queryInfoByToken();
    }

    @PostMapping("/add")
    @Operation(summary = "添加会员")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean add(@Valid @RequestBody MemberRegisterDTO memberRegisterDTO){
        return memberService.add(memberRegisterDTO);
    }

    @PostMapping("/page")
    @Operation(summary = "查询会员列表分页")
    @Auth(value = AuthType.NONE)
    public Page<Member> queryList(@RequestBody MemberWxPageDTO memberWxPageDTO){
        return memberService.selectList(memberWxPageDTO);
    }

    @PostMapping("/webQuery")
    @Operation(summary = "联营慧管理端---根据id查询单个会员详情")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Member webQuery(@Valid @RequestBody QueryIdDTO queryIdDTO){
        return memberService.getById(queryIdDTO.getId());
    }

    @PostMapping("/queryInfo")
    @Operation(summary = "联营慧PC---根据id查询单个会员详情")
    @Auth(value = AuthType.NONE)
    public Member queryInfo(@Valid @RequestBody QueryIdDTO queryIdDTO){
        return memberService.queryInfo(queryIdDTO);
    }

    @PostMapping("/state/edit")
    @Operation(summary = "联营慧管理端---根据id修改会员状态")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean updateStatus(@RequestBody @Valid MemberEditStateDTO memberEditStateDTO){
        return memberService.updateState(memberEditStateDTO);
    }

    @PostMapping("/delete")
    @Operation(summary = "联营慧管理端---根据传入id删除会员")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean delete(@RequestBody DisposeIdListDTO disposeIdListDTO){
//        return memberService.removeByIds(disposeIdListDTO.getId());
        return false;
    }

    @PostMapping("/num/query")
    @Operation(summary = "联营慧管理端---查询各状态会员总数")
    @Auth(value = AuthType.NONE)
    public List<MemberStateVO> countNum(@RequestBody MemberNumDTO memberNumDTO){
        return memberService.countNum(memberNumDTO);
    }

    @PostMapping(value = "/sms/code/send")
    @Operation(summary = "【验证】 发送短信验证码")
    @Auth(value = AuthType.NONE)
    public Boolean sendSmsCode(@Valid @RequestBody SendSmsCodeDTO sendSmsCodeDTO){
        return memberService.sendSmsCode(sendSmsCodeDTO);
    }

    @PostMapping("/company/query")
    @Operation(summary = "公司名称查询")
    @Auth(value = AuthType.NONE)
    public List<CompanyInfoSearchVO> queryCompany(@Valid @RequestBody MemberCompanyDTO memberCompanyDTO){
        return memberService.queryCompany(memberCompanyDTO);
    }

    @PostMapping("/company/check")
    @Operation(summary = "公司名称校验")
    @Auth(value = AuthType.NONE)
    public Boolean checkCompany(@Valid @RequestBody MemberCompanyDTO memberCompanyDTO){
        return memberService.checkCompany(memberCompanyDTO);
    }


    @PostMapping("/export")
    @Operation(summary = "联营慧管理端---会员信息导出")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public void export(HttpServletResponse response,@RequestBody MemberExportDTO memberExportDTO) throws IOException {
        memberExcelService.memberExportExcel(response,memberExportDTO);
    }


    @PostMapping("/wx/phone/get")
    @Operation(summary = "获取微信手机号")
    @Auth(value = AuthType.NONE)
    public String getPhoneNum(@Valid @RequestBody WXPhoneDTO wxPhoneDTO){
        return memberService.getPhone(wxPhoneDTO.getJsCode());
    }

    @PostMapping("/count")
    @Operation(summary = "获取会员协作数与未读消息数")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public MemberCountVO getCount(){
        return memberService.getCount();
    }

    @PostMapping("/admin/page")
    @Operation(summary = "联营慧管理端---会员分页列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<MemberPageVo> query(@RequestBody MemberPageDTO memberPageDTO){
        return memberService.selectPage(memberPageDTO);
    }

    @PostMapping("/wxQuery")
    @Operation(summary = "根据id查询单个会员详情")
    @Auth(value = AuthType.NONE)
    public Member queryWxInfo(@Valid @RequestBody QueryIdDTO queryIdDTO){
        return memberService.queryWxInfo(queryIdDTO);
    }

    @PostMapping("/wxEdit")
    @Operation(summary = "修改用户头像")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean editWxIcon(@Valid @RequestBody MemberIconDTO memberIconDTO){
        return memberService.editIcon(memberIconDTO);
    }

    @PostMapping("/edit")
    @Operation(summary = "联营慧小程序端---编辑会员信息接口 即 重新认证")
    public Boolean edit(@Valid @RequestBody MemberEditDTO memberEditDTO){
        return memberService.edit(memberEditDTO);
    }

    @PostMapping("/admin/edit")
    @Operation(summary = "联营慧管理端---编辑会员信息接口 即 后台修改")
    public Boolean adminEdit(@Valid @RequestBody MemberAdminEditDTO memberAdminEditDTO){
        return memberService.adminEdit(memberAdminEditDTO);
    }

    @PostMapping("/queryCompanyName")
    @Operation(summary = "联营慧管理端---查询推广人所属公司列表")
    public List<String> queryCompanyName(){
        return memberService.queryDistinctCompanyName();
    }

    @PostMapping("/countIndustry")
    @Operation(summary = "联营慧小程序---统计会员信息中各服务行业的数量")
    public Map<String, Integer> countIndustry(){
        return memberService.countIndustry();
    }

    @PostMapping("/inferCompanyName")
    @Operation(summary = "联营慧管理端---查询所属大区下的公司列表")
    public Map<String,List<String>> inferCompanyName (){
        return memberService.inferCompanyName();
    }

    @PostMapping("/countCompetence")
    @Operation(summary = "联营慧小程序---统计会员核心能力计数")
    public Map<String, Integer> countCompetence(){
        return memberService.countCompetence();
    }

    @PostMapping("/referMemberCooperation")
    @Operation(summary = "联营慧小程序---未通过会员是否发布协作")
    public IsIssueVO referMemberCooperation(){
        return memberService.referMemberCooperation();
    }

    @PostMapping("/statistics")
    @Operation(summary = "联营慧协同PC--根据类型统计会员数据")
    @Auth(value = AuthType.NONE)
    public List<StatisticsMemberVO> statistics(@RequestBody StatisticsMemberDTO statisticsMemberDTO){
        return memberService.statistics(statisticsMemberDTO);
    }

    @PostMapping("/mall/page")
    @Operation(summary = "联营慧协同PC--会员通讯录")
    @Auth(value = AuthType.NONE)
    public Page<MemberPageVo> mallPage(@RequestBody MemberPageDTO memberPageDTO){
        return memberService.selectMallPage(memberPageDTO);
    }

    @PostMapping("/mall/invite")
    @Operation(summary = "联营慧协同PC--邀约聊天")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean invite(@RequestBody MemberInviteDTO memberInviteDTO){
        return memberService.invite(memberInviteDTO);
    }
}
