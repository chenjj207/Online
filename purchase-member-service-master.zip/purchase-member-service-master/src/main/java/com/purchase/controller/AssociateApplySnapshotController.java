package com.purchase.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 联营申请表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-15
 */
@RestController
@RequestMapping("/associate-apply-snapshot")
public class AssociateApplySnapshotController {

}
