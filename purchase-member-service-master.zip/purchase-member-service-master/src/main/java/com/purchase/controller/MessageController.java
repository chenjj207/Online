package com.purchase.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Message;
import com.purchase.service.dto.MemberMessageAddDTO;
import com.purchase.service.dto.MessageMallAddDTO;
import com.purchase.service.dto.MessagePageDTO;
import com.purchase.service.dto.MessageQueryDTO;
import com.purchase.service.impl.MemberMessageServiceImpl;
import com.purchase.service.impl.MessageServiceImpl;
import com.purchase.service.vo.MessagePageVO;
import com.purchase.service.vo.MessageWxPageVO;
import com.zyd.framework.boot.config.base.PageDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * <p>
 * 消息表 前端控制器
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@RestController
@RequestMapping("/message")
public class MessageController {

    @Autowired
    MemberMessageServiceImpl memberMessageService;

    @Autowired
    MessageServiceImpl messageService;

    @PostMapping("/add")
    @Operation(summary = "联营慧管理端---新增公告")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean add(@Valid @RequestBody MemberMessageAddDTO memberMessageAddDTO){
        return memberMessageService.add(memberMessageAddDTO);
    }

    @PostMapping(value = "/query")
    @Operation(summary = "联营慧管理端（与小程序端共用）---获取公告详情")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Message queryMessage(@RequestBody @Valid MessageQueryDTO messageQueryDTO) {
        return messageService.getIdInfo(messageQueryDTO);
    }

    @PostMapping(value = "/page")
    @Operation(summary = "联营慧管理端---公告列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<MessagePageVO> queryMessage(@RequestBody MessagePageDTO messagePageDTO) {
        return messageService.pageList(messagePageDTO);
    }

    @PostMapping(value = "/wxPage")
    @Operation(summary = "小程序端公告列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<MessageWxPageVO> wxPageList(@RequestBody PageDTO pageDTO) {
        return messageService.wxPageList(pageDTO);
    }

    @PostMapping("/mall/add")
    @Operation(summary = "联营慧PC --- 留言")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean mallAdd(@RequestBody MessageMallAddDTO messageMallAddDTO){
        return memberMessageService.mallAdd(messageMallAddDTO);
    }

    @PostMapping(value = "/mall/page")
    @Operation(summary = "联营慧PC --- 留言列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<MessagePageVO> mallPage(@RequestBody MessagePageDTO messagePageDTO) {
        return messageService.mallPage(messagePageDTO);
    }

}
