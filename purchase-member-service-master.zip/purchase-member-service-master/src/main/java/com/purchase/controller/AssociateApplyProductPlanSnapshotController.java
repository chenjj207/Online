package com.purchase.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 计划合作产品基础信息 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-15
 */
@RestController
@RequestMapping("/associate-apply-product-plan-snapshot")
public class AssociateApplyProductPlanSnapshotController {

}
