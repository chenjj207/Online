package com.purchase.controller;


import com.purchase.service.AssociatePromotionService;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 项目推广专员配置表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-15
 */
@RestController
@RequestMapping("/associate-promotion")
public class AssociatePromotionController {

    @Autowired
    AssociatePromotionService associatePromotionService;

    @PostMapping("/queryAll")
    @Operation(summary = "查询所有的项目推广专员")
    @Auth(value = AuthType.NONE)
    public List<String> queryAll(){
        return associatePromotionService.queryAll();
    }
}
