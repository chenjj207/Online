package com.purchase.controller;

import com.purchase.entity.CustomerSale;
import com.purchase.service.CustSaleService;
import com.purchase.service.dto.*;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * 客户销售金额-控制器
 */
@RestController
@RequestMapping("/custSale")
public class CustSaleController {

    @Autowired
    CustSaleService custSaleService;

    @PostMapping("/getCustSaleData")
    @Operation(summary = "获取客户销售数据")
    @Auth(value = AuthType.NONE)
    public CustomerSale getCustSaleData(@Valid @RequestBody CustSaleQueryDTO param){
        return custSaleService.getCustSaleData(param);
    }

}
