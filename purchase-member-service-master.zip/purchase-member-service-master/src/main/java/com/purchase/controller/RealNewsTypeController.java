package com.purchase.controller;

import com.purchase.entity.RealNewsType;
import com.purchase.service.RealNewsTypeService;
import com.purchase.service.dto.QueryTypeDTO;
import com.purchase.service.dto.RealNewsTypeAddDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 资讯分类表 前端控制器
 * </p>
 *
 * @author
 * @since 2023-02-10
 */
@RestController
@RequestMapping("/real-news-type")
public class RealNewsTypeController {

    @Autowired
    RealNewsTypeService realNewsTypeService;

    @PostMapping("/add")
    @Operation(summary = "联营慧管理端---新增资讯分类")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean add(@RequestBody RealNewsTypeAddDTO realNewsTypeAddDTO){
        return realNewsTypeService.add(realNewsTypeAddDTO);
    }

    @PostMapping("/query")
    @Operation(summary = "联营慧管理端---查询资讯分类")
    @Auth(value = AuthType.NONE)
    public List<RealNewsType> queryStatus(){
        return realNewsTypeService.list();
    }


    @PostMapping("/queryType")
    @Operation(summary = "联营慧管理端---根据发布页查询资讯分类")
    @Auth(value = AuthType.NONE)
    public List<RealNewsType> queryType(@Validated @RequestBody QueryTypeDTO queryTypeDTO){
        return realNewsTypeService.queryType(queryTypeDTO);
    }
}
