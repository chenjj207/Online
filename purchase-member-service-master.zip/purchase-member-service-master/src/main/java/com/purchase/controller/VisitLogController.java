package com.purchase.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 联营慧访问日志记录表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-06-29
 */
@RestController
@RequestMapping("/visit-log")
public class VisitLogController {

}
