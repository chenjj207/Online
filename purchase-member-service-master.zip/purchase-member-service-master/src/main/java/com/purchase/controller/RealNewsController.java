package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.RealNews;
import com.purchase.service.RealNewsService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.InterestListVO;
import com.purchase.service.vo.RealNewsVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * <p>
 * 资讯表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-02-03
 */
@RestController
@RequestMapping("/realNews")
public class RealNewsController {

    @Autowired
    RealNewsService realNewsService;

    @PostMapping(value = "/page")
    @Operation(summary  = "联营慧管理端---资讯分页", description = "资讯分页")
    @Auth(value = AuthType.NONE)
    public Page<RealNews> search(@RequestBody RealNewsPageDTO realNewsPageDTO) {
        return realNewsService.search(realNewsPageDTO);
    }

    @PostMapping("/add")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "联营慧管理端---新增资讯", description = "资讯分页")
    public boolean addRealNews(@Valid @RequestBody RealNewsAddDTO RealNewsAddDTO) {
        return realNewsService.save(RealNewsAddDTO);
    }

    @PostMapping("/edit")
    @Operation(summary = "联营慧管理端---编辑资讯", description = "编辑资讯")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public boolean editRealNews(@Valid @RequestBody RealNewsEditDTO realNewsEditDTO) {
        return realNewsService.edit(realNewsEditDTO);
    }

    @PostMapping(value = "/pcQuery")
    @Auth(value = AuthType.NONE)
    @Operation(summary = "惠采管理后台 根据id获取资讯", description = "根据id获取资讯")
    public RealNews queryRealNews(@Valid @RequestBody QueryIdDTO queryIdDTO) {
        return realNewsService.pcInfo(queryIdDTO);
    }

    @PostMapping(value = "/query")
    @Auth(value = AuthType.NONE)
    @Operation(summary = "小程序端 根据id获取资讯", description = "根据id获取资讯")
    public RealNews queryRealNews(@Valid @RequestBody WxQueryIdDTO wxqueryIdDTO, HttpServletRequest httpServletRequest) {
        return realNewsService.info(wxqueryIdDTO, httpServletRequest);
    }

    @PostMapping(value = "/mall/query")
    @Auth(value = AuthType.NONE)
    @Operation(summary = " 联营慧PC端 共用根据id获取资讯", description = "根据id获取资讯")
    public RealNews mallQueryRealNews(@Valid @RequestBody WxQueryIdDTO wxqueryIdDTO, HttpServletRequest httpServletRequest) {
        return realNewsService.mallInfo(wxqueryIdDTO, httpServletRequest);
    }

    @PostMapping(value = "/delete")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "联营慧管理端---根据传入的Id，删除数据")
    public boolean batchDelete(@RequestBody DisposeIdListDTO disposeIdListDTO) {
        return realNewsService.removeByIds(disposeIdListDTO.getId());
    }

    @PostMapping(value = "/wxPage")
    @Operation(summary  = "小程序---资讯分页", description = "资讯分页")
    @Auth(value = AuthType.NONE)
    public Page<RealNews> pageSearch(@RequestBody RealNewsWXPageDTO realNewsWXPageDTO) {
        return realNewsService.pageSearch(realNewsWXPageDTO);
    }

    @PostMapping(value = "/preview")
    @Operation(summary  = "联营慧管理端---资讯预览二维码", description = "资讯预览二维码")
    @Auth(value = AuthType.NONE)
    public String preview(@RequestBody RealNewsSenceDTO realNewsSenceDTO){
        return realNewsService.preview(realNewsSenceDTO);
    }

    @PostMapping(value = "/realNewsPage")
    @Operation(summary  = "联营慧管理端---资讯分页", description = "资讯分页")
    @Auth(value = AuthType.NONE)
    public Page<RealNewsVO> realNewsPage(@RequestBody RealNewsPageDTO realNewsPageDTO){
        return realNewsService.searchPage(realNewsPageDTO);
    }

    @PostMapping(value = "/interestList")
    @Operation(summary  = "联营慧管理端---对资讯感兴趣名单", description = "对资讯感兴趣名单")
    @Auth(value = AuthType.NONE)
    public Page<InterestListVO> interestList(@RequestBody InterestDTO interestDTO){
        return realNewsService.interestList(interestDTO);
    }

    @PostMapping(value = "/mall/resource/page")
    @Operation(summary  = "联营慧协同PC---资源列表", description = "资源列表")
    @Auth(value = AuthType.NONE)
    public Page<RealNews> mallResourcePage(@RequestBody RealNewsResourceDTO realNewsResourceDTO) {
        return realNewsService.mallResourcePage(realNewsResourceDTO);
    }

    @PostMapping(value = "/mall/need/page")
    @Operation(summary  = "联营慧协同PC---需求列表", description = "需求列表")
    @Auth(value = AuthType.NONE)
    public Page<RealNews> mallNeedPage(@RequestBody RealNewsNeedDTO realNewsNeedDTO) {
        return realNewsService.mallNeedPage(realNewsNeedDTO);
    }
}
