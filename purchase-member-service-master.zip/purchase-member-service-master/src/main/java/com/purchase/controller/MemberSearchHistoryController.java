package com.purchase.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.MemberSearchHistory;
import com.purchase.service.dto.MemberSearchHistoryAddDTO;
import com.purchase.service.dto.QueryIdDTO;
import com.purchase.service.impl.MemberSearchHistoryServiceImpl;
import com.zyd.framework.boot.config.base.PageDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * <p>
 * 客户搜索历史表 前端控制器
 * </p>
 *
 * @author
 * @since 2023-02-10
 */
@RestController
@RequestMapping("/member-search-history")
public class MemberSearchHistoryController {

    @Autowired
    MemberSearchHistoryServiceImpl memberSearchHistoryService;
    @PostMapping("/add")
    @Operation(summary = "搜索历史增加")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean add(@Valid @RequestBody MemberSearchHistoryAddDTO memberSearchHistoryAddDTO){
       return memberSearchHistoryService.add(memberSearchHistoryAddDTO);
    }

    @PostMapping("/page")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "当前用户的历史搜索记录的分页")
    public Page<MemberSearchHistory> add(@RequestBody PageDTO pageDTO){
        return memberSearchHistoryService.pageList(pageDTO);
    }

    @PostMapping("/delete")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "删除当前用户的历史搜索记录")
    public Boolean delete(@Valid @RequestBody QueryIdDTO queryIdDTO){
        return memberSearchHistoryService.deleted(queryIdDTO);
    }

    @PostMapping("/allDelete")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "删除当前用户的所有历史搜索记录")
    public Boolean allDelete(){
        return memberSearchHistoryService.allDeleted();
    }
}
