package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.BrandAuthApply;
import com.purchase.service.BrandAuthApplyService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.BrandAuthApplyDetailVO;
import com.purchase.service.vo.BrandAuthRenewalVO;
import com.purchase.service.vo.BrandAuthTimeVO;
import com.purchase.service.vo.CommonCountVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 品牌授权申请 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-04-11
 */
@RestController
@RequestMapping("/brand-auth-apply")
public class BrandAuthApplyController {

    @Autowired
    BrandAuthApplyService brandAuthApplyService;

    @PostMapping("/add")
    @Operation(summary = "添加/续约/再次续约 品牌授权申请")
    @Auth(value = AuthType.NONE)
    public Integer add(@Valid @RequestBody BrandAuthApplyAddDTO brandAuthApplyAddDTO){
        return brandAuthApplyService.add(brandAuthApplyAddDTO);
    }

    @PostMapping("/edit")
    @Operation(summary = "品牌授权申请 编辑")
    @Auth(value = AuthType.NONE)
    public Integer edit(@Valid @RequestBody BrandAuthApplyEditDTO brandAuthApplyEditDTO){
        return brandAuthApplyService.edit(brandAuthApplyEditDTO);
    }

    @PostMapping("/edit/admin")
    @Operation(summary = "品牌授权申请 编辑")
    @Auth(value = AuthType.NONE)
    public Integer editAdmin(@Valid @RequestBody BrandAuthApplyEditAdminDTO brandAuthApplyEditAdminDTO){
        return brandAuthApplyService.editAdmin(brandAuthApplyEditAdminDTO);
    }

    @PostMapping("/renewal")
    @Operation(summary = "续约查询接口， 传已有最新的品牌授权id")
    @Auth(value = AuthType.NONE)
    public BrandAuthRenewalVO renewal(@Valid @RequestBody QueryIdDTO queryIdDTO){
        return brandAuthApplyService.renewal(queryIdDTO);
    }

    @PostMapping("/queryById")
    @Operation(summary = "查看品牌授权申请")
    @Auth(value = AuthType.NONE)
    public BrandAuthApply queryById(@Valid @RequestBody QueryIdDTO queryIdDTO){
        return brandAuthApplyService.queryById(queryIdDTO);
    }

    @PostMapping("/queryByOpenId")
    @Operation(summary = "查看品牌授权申请")
    @Auth(value = AuthType.NONE)
    public List<BrandAuthApply> queryByOpenId(@Valid @RequestBody OpenIdDTO openIdDTO){
        return brandAuthApplyService.queryByOpenId(openIdDTO);
    }

    @PostMapping("/page")
    @Operation(summary = "惠采后台--查询授权申请分页")
    @Auth(value = AuthType.NONE)
    public Page<BrandAuthApply> queryList(@RequestBody BrandAuthApplyPageDTO brandAuthApplyPageDTO){
        return brandAuthApplyService.queryList(brandAuthApplyPageDTO);
    }

    @PostMapping("/count")
    @Operation(summary = "惠采后台--数量统计")
    @Auth(value = AuthType.NONE)
    public List<CommonCountVO> countNum(@Valid @RequestBody BrandAuthApplyCountDTO brandAuthApplyCountDTO){
        return brandAuthApplyService.countNum(brandAuthApplyCountDTO);
    }

    @PostMapping("/export")
    @Operation(summary = "导出")
    @Auth(value = AuthType.NONE)
    public void export(@RequestBody BrandAuthApplyCountDTO brandAuthApplyCountDTO, HttpServletResponse response){
        brandAuthApplyService.export(brandAuthApplyCountDTO, response);
    }

    @PostMapping("/detail")
    @Operation(summary = "惠采后台--查看详情")
    @Auth(value = AuthType.NONE)
    public BrandAuthApplyDetailVO detail(@Valid @RequestBody QueryIdDTO queryIdDTO){
        return brandAuthApplyService.detail(queryIdDTO);
    }

    @PostMapping("/approve")
    @Operation(summary = "惠采后台--审批")
    @Auth(value = AuthType.NONE)
    public Boolean approve(@Valid @RequestBody BrandAuthApplyApproveDTO brandAuthApplyApproveDTO){
        return brandAuthApplyService.approve(brandAuthApplyApproveDTO);
    }

    @PostMapping("/grant/file")
    @Operation(summary = "惠采后台--发放和存档")
    @Auth(value = AuthType.NONE)
    public Boolean grant(@Valid @RequestBody BrandAuthApplyGrantFileDTO brandAuthApplyGrantFileDTO){
        return brandAuthApplyService.grant(brandAuthApplyGrantFileDTO);
    }

    @PostMapping("/auth/time")
    @Operation(summary = "惠采后台--时间列表返回")
    @Auth(value = AuthType.NONE)
    public List<BrandAuthTimeVO> authTime(){
        return brandAuthApplyService.authTime();
    }

}
