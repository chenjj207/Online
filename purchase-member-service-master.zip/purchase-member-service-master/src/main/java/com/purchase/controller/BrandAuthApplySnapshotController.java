package com.purchase.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 品牌授权申请 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-22
 */
@RestController
@RequestMapping("/brand-auth-apply-snapshot")
public class BrandAuthApplySnapshotController {

}
