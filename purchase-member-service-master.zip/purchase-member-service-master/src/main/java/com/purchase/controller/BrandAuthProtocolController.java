package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.BrandAuthProtocol;
import com.purchase.service.BrandAuthProtocolService;
import com.purchase.service.dto.BrandAuthProtocolAddDTO;
import com.purchase.service.dto.BrandAuthProtocolPageDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * <p>
 * 品牌授权协议存档 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-06-03
 */
@RestController
@RequestMapping("/brand-auth-protocol")
public class BrandAuthProtocolController {


    @Autowired
    BrandAuthProtocolService brandAuthProtocolService;

    @PostMapping("/add")
    @Operation(summary = "添加品牌授权协议归档")
    @Auth(value = AuthType.NONE)
    public Integer add(@Valid @RequestBody BrandAuthProtocolAddDTO brandAuthProtocolAddDTO){
        return brandAuthProtocolService.add(brandAuthProtocolAddDTO);
    }

    @PostMapping("/page")
    @Operation(summary = "惠采后台--品牌授权协议归档")
    @Auth(value = AuthType.NONE)
    public Page<BrandAuthProtocol> queryList(@RequestBody BrandAuthProtocolPageDTO brandAuthProtocolPageDTO){
        return brandAuthProtocolService.queryList(brandAuthProtocolPageDTO);
    }
}
