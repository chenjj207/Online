package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.AssociateProtocol;
import com.purchase.service.AssociateProtocolService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.AssociateProtocoReadVO;
import com.purchase.service.vo.AssociateProtocolCountVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 联营协议 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-04-01
 */
@RestController
@RequestMapping("/associate-protocol")
public class AssociateProtocolController {

    @Autowired
    AssociateProtocolService associateProtocolService;

    @PostMapping("/page")
    @Operation(summary = "惠采后台--查询联营协议分页")
    @Auth(value = AuthType.NONE)
    public Page<AssociateProtocol> queryList(@RequestBody AssociateProtocolPageDTO associateProtocolPageDTO){
        return associateProtocolService.queryList(associateProtocolPageDTO);
    }

    @PostMapping("/count")
    @Operation(summary = "惠采后台--数量统计")
    @Auth(value = AuthType.NONE)
    public List<AssociateProtocolCountVO> countNum(@Valid @RequestBody AssociateProtocolCountDTO associateApplyCountDTO){
        return associateProtocolService.countNum(associateApplyCountDTO);
    }

    @PostMapping("/queryByJsCode")
    @Operation(summary = "小程序--根据jscode查询联营协议表")
    @Auth(value = AuthType.NONE)
    public List<AssociateProtocol> queryByJsCode(@Valid @RequestBody AssociateProtocolQueryDTO associateProtocolQueryDTO){
        return associateProtocolService.queryByJsCode(associateProtocolQueryDTO);
    }

    @PostMapping("/queryRead")
    @Operation(summary = "小程序--查询数量和是否已读")
    @Auth(value = AuthType.NONE)
    public AssociateProtocoReadVO queryRead(@Valid @RequestBody AssociateProtocolQueryDTO associateProtocolQueryDTO){
        return associateProtocolService.queryRead(associateProtocolQueryDTO);
    }

    @PostMapping("/edit/state")
    @Operation(summary = "惠采后台--作废、归档")
    @Auth(value = AuthType.NONE)
    public Boolean editState(@Valid @RequestBody AssociateProtocolEditStateDTO associateProtocolEditStateDTO){
        return associateProtocolService.editState(associateProtocolEditStateDTO);
    }
}
