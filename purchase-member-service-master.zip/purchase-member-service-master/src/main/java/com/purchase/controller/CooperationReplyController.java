package com.purchase.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.CooperationReply;
import com.purchase.service.dto.*;
import com.purchase.service.impl.CooperationReplyServiceImpl;
import com.purchase.service.vo.CooperationInfoVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * <p>
 * 协作回复表 前端控制器
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@RestController
@RequestMapping("/cooperation-reply")
public class CooperationReplyController {

    @Autowired
    CooperationReplyServiceImpl cooperationReplyService;

    @PostMapping("/add")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "联营慧管理端---新增回复协作")
    public Boolean add(@Valid @RequestBody CooperationReplyAddDTO cooperationReplyAddDTO){
        return cooperationReplyService.add(cooperationReplyAddDTO);
    }

    @PostMapping("/query")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "小程序查询协作回复详情")
    public CooperationInfoVO queryInfo(@Valid @RequestBody QueryIdDTO queryIdDTO){
        return cooperationReplyService.queryInfo(queryIdDTO);
    }

    @PostMapping("/mall/add")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "联营慧PC --- 服务协同 新增回复")
    public Boolean mallAdd(@Valid @RequestBody CooperationReplyMallAddDTO cooperationReplyMallAddDTO){
        return cooperationReplyService.mallAdd(cooperationReplyMallAddDTO);
    }

    @PostMapping("/mall/page")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "联营慧PC --- 查询协作回复详情")
    public Page<CooperationReply> queryInfo(@Valid @RequestBody CooperationReplyPageDTO cooperationReplyPageDTO){
        return cooperationReplyService.mallPage(cooperationReplyPageDTO);
    }

    @PostMapping("/page")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "管理端 --- 查询协作回复详情")
    public Page<CooperationReply> page(@Valid @RequestBody CooperationReplyPageDTO cooperationReplyPageDTO){
        return cooperationReplyService.page(cooperationReplyPageDTO);
    }

    @PostMapping("/delete")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "惠采管理端 --- 删除协作回复")
    public Boolean delete(@Valid @RequestBody CooperationReplyDeleteDTO cooperationReplyPageDTO){
        return cooperationReplyService.delete(cooperationReplyPageDTO);
    }
}
