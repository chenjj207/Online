package com.purchase.controller;

import com.purchase.service.MemberService;
import com.purchase.service.dto.MemberSupplierOpenDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author jidonglin
 * @Description: 会员供应商接口
 * @date 2023/4/25  13:45
 */
@RestController
@RequestMapping("/supplier")
public class MemberSupplierController {

    @Autowired
    MemberService memberService;

    @PostMapping("/open")
    @Operation(summary = "慧采后台--开通供应商")
    @Auth(value = AuthType.NONE)
    public Boolean open(@Valid @RequestBody MemberSupplierOpenDTO memberSupplierOpenDTO){
        return memberService.open(memberSupplierOpenDTO);
    }
}
