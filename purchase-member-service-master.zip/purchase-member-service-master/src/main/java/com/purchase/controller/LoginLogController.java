package com.purchase.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 登录日志表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-06-27
 */
@RestController
@RequestMapping("/login-log")
public class LoginLogController {

}
