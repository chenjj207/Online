package com.purchase.controller;


import com.purchase.service.MemberRealNewsService;
import com.purchase.service.dto.RealNewsUpvoteDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-12
 */
@RestController
@RequestMapping("/member-realNews")
public class MemberRealNewsController {

    @Autowired
    MemberRealNewsService tMbMemberRealNewsService;

    @PostMapping("/upvote")
    @Operation(summary = "小程序端资讯点赞接口")
    @Auth(value = AuthType.AUTH)
    public Boolean upvote(@RequestBody RealNewsUpvoteDTO realNewsUpvoteDTO){
        return tMbMemberRealNewsService.upvote(realNewsUpvoteDTO);
    }

}
