package com.purchase.controller;


import com.purchase.service.CommonService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.WxVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * <p>
 * 公共 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-04-10
 */
@RestController
@RequestMapping("/common")
public class CommonController {

    @Autowired
    CommonService commonService;

    @PostMapping("/getOpenId")
    @Operation(summary = "小程序--获取openId")
    @Auth(value = AuthType.NONE)
    public WxVO getOpeId(@Valid @RequestBody JsCodeDTO jsCodeDTO){
        return commonService.getOpeId(jsCodeDTO);
    }

}
