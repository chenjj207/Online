package com.purchase.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 终端客户合作拓展计划 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-25
 */
@RestController
@RequestMapping("/associate-apply-customer-plan")
public class AssociateApplyCustomerPlanController {

}
