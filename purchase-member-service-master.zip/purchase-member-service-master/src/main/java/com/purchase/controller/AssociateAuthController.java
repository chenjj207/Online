package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.AssociateAuth;
import com.purchase.service.AssociateAuthService;
import com.purchase.service.dto.AssociateApplyAddDTO;
import com.purchase.service.dto.AssociateAuthAddDTO;
import com.purchase.service.dto.AssociateAuthPageDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * <p>
 * 联营授权 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-22
 */
@RestController
@RequestMapping("/associate-auth")
public class AssociateAuthController {

    @Autowired
    AssociateAuthService associateAuthService;

    @PostMapping("/add")
    @Operation(summary = "添加联营授权")
    @Auth(value = AuthType.NONE)
    public Integer add(@Valid @RequestBody AssociateAuthAddDTO associateAuthAddDTO){
        return associateAuthService.add(associateAuthAddDTO);
    }

    @PostMapping("/page")
    @Operation(summary = "惠采后台--查询联营授权")
    @Auth(value = AuthType.NONE)
    public Page<AssociateAuth> queryList(@RequestBody AssociateAuthPageDTO associateApplyPageDTO){
        return associateAuthService.queryList(associateApplyPageDTO);
    }
}
