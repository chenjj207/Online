package com.purchase.controller;

import com.purchase.service.dto.DisposeIdListDTO;
import com.purchase.service.impl.MemberMessageServiceImpl;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 会员消息表 前端控制器
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@RestController
@RequestMapping("/member-message")
public class MemberMessageController {

    @Autowired
    MemberMessageServiceImpl memberMessageService;

    @PostMapping("/delete")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "根据公告id，批量删除公告")
    public Boolean delete(@RequestBody DisposeIdListDTO dto){
        return memberMessageService.delete(dto);
    }

    @PostMapping("/edit")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "根据传入id，批量编辑公告状态为已读")
    public Boolean edit(@RequestBody DisposeIdListDTO dto){
        return memberMessageService.edit(dto);
    }

    @PostMapping("/allDelete")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "小程序端，删除会员接收到的所有公告")
    public Boolean allDelete(){
        return memberMessageService.allDelete();
    }

    @PostMapping("/allEdit")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "小程序端，将会员所有公告状态为已读")
    public Boolean allEdit(){
        return memberMessageService.allEdit();
    }

}
