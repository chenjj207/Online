package com.purchase.controller;

import com.purchase.client.WXClient;
import com.purchase.utils.TokenUtils;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Base64;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/5/20  9:49
 */
@RestController
@RequestMapping("/temp")
public class TempController {

    @Resource
    private WXClient wxClient;
    @Autowired
    private TokenUtils tokenUtils;

    @GetMapping(value = "/")
    @Operation(summary  = "临时接口", description = "临时接口")
    @Auth(value = AuthType.NONE)
    public String temp(@RequestParam("page")String page, @RequestParam("scene")String scene){
        String wxToken = tokenUtils.getWXToken();
        byte[] result = wxClient.getwxacodeunlimit(wxToken, scene, page, "trial");
        return Base64.getEncoder().encodeToString(result);
    }
}
