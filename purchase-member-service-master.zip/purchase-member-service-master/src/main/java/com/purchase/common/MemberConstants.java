package com.purchase.common;

import lombok.Data;

/**
 * @author jidonglin
 * @Description: 业务枚举值
 * @date 2023/2/8  9:16
 */
@Data
public class MemberConstants {
    public enum SmsCodeType{
        LOGIN(1, "登录类型"),
        REGIST(2, "注册类型"),
        ASSOCIATE_APPLY(3, "联营申请表"),
        BRAND_AUTH_APPLY(4, "品牌授权"),
        ;

        public int code;
        public String message;
        SmsCodeType(int code, String message) {
            this.code = code;
            this.message = message;
        }
        public int getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum CooperationReplyRead{
        UN_READ(0,"未读"),
        READ(1,"已读");
        public Integer code;
        public String message;

        CooperationReplyRead(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum CooperationStatus{
        REVERT(0,"已回复"),
        UN_REVERT(1,"未回复");
        public Integer code;
        public String message;
        CooperationStatus(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum CooperationType{
        RESOURCE("resource","资源"),
        NEED("need","需求");
        public String code;
        public String value;
        CooperationType(String code, String value) {
            this.code = code;
            this.value = value;
        }
        public String getCode() {
            return code;
        }
        public String getValue() {
            return value;
        }
    }


    public enum MemberState{
        ALL(-1,"全部"),
        CHECK(0,"待审核"),
        PASS(1,"通过"),
        REFER(2,"未通过");

        public Integer code;
        public String message;
        MemberState(Integer code, String message) {
            this.code = code;
            this.message = message;
        }

        public static String getValue(Integer code) {
            for (MemberConstants.MemberState e : MemberConstants.MemberState.values()) {
                if (e.code.equals(code)) {
                    return e.message;
                }
            }
            return null;
        }

        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum RealNewShow{

        ISSUE(0,"发布"),
        UN_ISSUE(1,"未发布");

        public Integer code;
        public String message;
        RealNewShow(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum MemberMessageRead{
        UN_READ(0,"未读"),
        READ(1,"已读");
        public Integer code;
        public String message;

        MemberMessageRead(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum MessageReceiverType{
        ALL( "All","全部"),
        MULTIPLE("Multiple","部分"),
        SINGLE("Single","单个");
        public String code;
        public String message;

        MessageReceiverType(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum MemberIsDelete{
        NO( 0,"未删除"),
        YES(1,"已删除");
        public Integer code;
        public String message;

        MemberIsDelete(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum RealNewsIsInterest{
        NO( 0,"未开启"),
        YES(1,"开启");
        public Integer code;
        public String message;

        RealNewsIsInterest(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum IsInterset{
        NO( 0,"感兴趣"),
        YES(1,"不感兴趣");
        public Integer code;
        public String message;

        IsInterset(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }
    public enum IsShowReason{
        NO( 0,"不显示"),
        YES(1,"显示");
        public Integer code;
        public String message;

        IsShowReason(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }
    public enum IsShow{
        NO( 0,"隐藏"),
        YES(1,"显示");
        public Integer code;
        public String message;

        IsShow(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }

        public static String getValue(Integer code) {
            for (MemberConstants.IsShow e : MemberConstants.IsShow.values()) {
                if (e.code.equals(code)) {
                    return e.message;
                }
            }
            return null;
        }
    }

    public enum IsInner {
        NO( 0,"非内部人员"),
        YES(1,"内部人员");
        public Integer code;
        public String message;

        IsInner(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }

        public static String getValue(Integer code) {
            for (MemberConstants.IsShow e : MemberConstants.IsShow.values()) {
                if (e.code.equals(code)) {
                    return e.message;
                }
            }
            return null;
        }
    }

    public enum SupplierSourceType{
        BACKGROUND_ADD("BACKGROUND_ADD", "后台新增"),
        SUPPLIER_APPLY("SUPPLIER_APPLY", "供应商申请"),
        ASSOCIATE_PROTOCOL("ASSOCIATE_PROTOCOL", "产线协议"),
        ;

        public String code;
        public String message;
        SupplierSourceType(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum SupplierAccountStatus {
        ENABLE("ENABLE", "启用"),
        DISABLE("DISABLE", "禁用"),
        ;

        public String code;
        public String message;
        SupplierAccountStatus(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum AreaType{
        CENTRALANDEASTCHINA("CentralAndEastChina", "华东华中"),
        WESTSOUTHCHINA("westSouthChina", "华南西部"),
        NORTHEASTNORTHCHINA("NortheastNorthChina", "华北东北"),
        OTHER("Other", "其他"),
        All("All", "全部"),
        ;

        public String code;
        public String message;
        AreaType(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum Record{
        NO(0, "不记录"),
        YES(1, "记录"),

        ;

        public Integer code;
        public String message;
        Record(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }


    public enum StatisticsType{
        INDUSTRY("1", "会员服务行业"),
        COMPETENCE("2", "会员核心能力"),
        ;

        public String code;
        public String message;
        StatisticsType(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum ResourceType{
        PRODUCT("product", "产品资源"),
        SERVICE("service", "服务资源"),
        ;

        public String code;
        public String message;
        ResourceType(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum NeedType{
        SERVICECOOPERATE("serviceCooperate", "服务协同"),
        ;

        public String code;
        public String message;
        NeedType(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum CooperationAuditState{
        PENDING(0,"待审核"),
        PASS(1,"已通过"),
        REJECT(2,"已拒绝"),
        NOT_AUDIT(3,"不需要审核（小程序）");
        public int code;
        public String value;
        CooperationAuditState(int code, String value) {
            this.code = code;
            this.value = value;
        }
        public int getCode() {
            return code;
        }
        public String getValue() {
            return value;
        }
    }

    public enum ResourceTabType{
        PRODUCT("1","产品资源"),
        SERVICE("2","服务资源"),
        PUBLISH_SELF("3","我发布的资源");
        public String code;
        public String value;
        ResourceTabType(String code, String value) {
            this.code = code;
            this.value = value;
        }
        public String getCode() {
            return code;
        }
        public String getValue() {
            return value;
        }
    }

    public enum NeedBrand{
        Y("1","是"),
        N("0","否");
        public String code;
        public String value;
        NeedBrand(String code, String value) {
            this.code = code;
            this.value = value;
        }
        public String getCode() {
            return code;
        }
        public String getValue() {
            return value;
        }
    }

    public enum AssociateApplyState{
        PENDING_RESEARCH("1","待调研"),
        NOT_PASS_RESEARCH("2","调研未通过"),
        PENDING_APPROVAL("3","待批复"),
        AGREE_SIGN("4","同意签约"),
        REFUSE_SIGN("5","拒绝签约");
        public String code;
        public String value;
        AssociateApplyState(String code, String value) {
            this.code = code;
            this.value = value;
        }
        public String getCode() {
            return code;
        }
        public String getValue() {
            return value;
        }
    }

    public enum AssociateProtocolState{
        BE_SENT("0", "待寄出"),
        BE_EFFECTIVE("1","待生效"),
        EFFECTIVE("2","已生效"),
        EXPIRED("3","已过期"),
        VOIDED("4","已作废");

        public String code;
        public String value;
        AssociateProtocolState(String code, String value) {
            this.code = code;
            this.value = value;
        }
        public String getCode() {
            return code;
        }
        public String getValue() {
            return value;
        }
    }

    public enum BrandAuthApply{
        PENDING_APPROVAL("1","待审批"),
        AGREE_AUTH("2","同意授权"),
        REFUSE_AUTH("3","拒绝授权"),
        ARCHIVED("4","已存档"),
        ISSUED("5","已发放"),
        REFUSE_ISSUED("6","拒绝发放");
        public String code;
        public String value;
        BrandAuthApply(String code, String value) {
            this.code = code;
            this.value = value;
        }
        public String getCode() {
            return code;
        }
        public String getValue() {
            return value;
        }
    }
}
