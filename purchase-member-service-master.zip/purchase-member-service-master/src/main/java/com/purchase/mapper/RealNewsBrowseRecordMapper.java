package com.purchase.mapper;

import com.purchase.entity.RealNewsBrowseRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 资讯浏览记录 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-01
 */
@Mapper
public interface RealNewsBrowseRecordMapper extends BaseMapper<RealNewsBrowseRecord> {

}
