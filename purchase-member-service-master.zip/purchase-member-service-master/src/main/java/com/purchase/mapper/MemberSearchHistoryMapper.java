package com.purchase.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.entity.MemberSearchHistory;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 客户搜索历史表 Mapper 接口
 * </p>
 *
 * @author
 * @since 2023-02-10
 */
@Mapper
public interface MemberSearchHistoryMapper extends BaseMapper<MemberSearchHistory> {

}
