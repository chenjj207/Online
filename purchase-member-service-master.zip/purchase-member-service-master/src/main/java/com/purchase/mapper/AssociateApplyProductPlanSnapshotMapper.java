package com.purchase.mapper;

import com.purchase.entity.AssociateApplyProductPlanSnapshot;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 计划合作产品基础信息 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-15
 */
@Mapper
public interface AssociateApplyProductPlanSnapshotMapper extends BaseMapper<AssociateApplyProductPlanSnapshot> {

}
