package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.AssociateProtocol;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.AssociateProtocolCountDTO;
import com.purchase.service.dto.AssociateProtocolPageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 联营协议 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-04-01
 */
@Mapper
public interface AssociateProtocolMapper extends BaseMapper<AssociateProtocol> {

    Page<AssociateProtocol> page (@Param("dto") AssociateProtocolPageDTO dto , Page page);

    int countByState(@Param("dto") AssociateProtocolCountDTO associateProtocolCountDTO);

    String maxCode(@Param("type")String type);

    List<AssociateProtocol> selectLastSignTime(@Param("state") String state);

    int countRead(@Param("applyId") Integer applyId, @Param("isRead") String isRead);
}
