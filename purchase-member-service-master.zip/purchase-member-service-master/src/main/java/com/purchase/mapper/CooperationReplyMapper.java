package com.purchase.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.CooperationReply;
import com.purchase.service.dto.CooperationReplyPageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 协作回复表 Mapper 接口
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Mapper
public interface CooperationReplyMapper extends BaseMapper<CooperationReply> {

    Page<CooperationReply> page(@Param("dto")CooperationReplyPageDTO cooperationReplyPageDTO, Page buildPage);
}
