package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.RealNews;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.InterestDTO;
import com.purchase.service.dto.RealNewsNeedDTO;
import com.purchase.service.dto.RealNewsPageDTO;
import com.purchase.service.dto.RealNewsResourceDTO;
import com.purchase.service.vo.InterestListVO;
import com.purchase.service.vo.RealNewsVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 资讯表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-02-03
 */
@Mapper
public interface RealNewsMapper extends BaseMapper<RealNews> {

    Page<RealNewsVO> searchPage(@Param("realNewsPageDTO") RealNewsPageDTO realNewsPageDTO, Page buildPage);

    Page<InterestListVO> interestList(@Param("interestDTO")InterestDTO interestDTO, Page buildPage);

    List<String> memberList(Integer id);

    Integer selectBrowseNum(@Param("id")Integer id);

    Page<RealNews> resourcePage(@Param("dto")RealNewsResourceDTO realNewsResourceDTO, Page buildPage);

    Page<RealNews> resourcePublishSelfPage(@Param("dto")RealNewsResourceDTO realNewsResourceDTO, Page buildPage);

    Page<RealNews> needInPage(@Param("dto") RealNewsNeedDTO realNewsNeedDTO, Page buildPage);

    Page<RealNews> needNotInPage(@Param("dto") RealNewsNeedDTO realNewsNeedDTO, Page buildPage);

    Page<RealNews> needExpirePage(@Param("dto") RealNewsNeedDTO realNewsNeedDTO, Page buildPage);

    Page<RealNews> needPublishSelfPage(@Param("dto") RealNewsNeedDTO realNewsNeedDTO, Page buildPage);
}
