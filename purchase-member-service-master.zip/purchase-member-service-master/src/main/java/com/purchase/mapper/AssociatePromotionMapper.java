package com.purchase.mapper;

import com.purchase.entity.AssociatePromotion;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 项目推广专员配置表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-15
 */
@Mapper
public interface AssociatePromotionMapper extends BaseMapper<AssociatePromotion> {

    List<String> selectPromotionGroup();

    List<String> selectPromotionCode();

    String selectCodeByName(@Param("name")String name);
}
