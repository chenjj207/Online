package com.purchase.mapper;

import com.purchase.entity.MemberRealNews;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-12
 */
@Mapper
public interface MemberRealNewsMapper extends BaseMapper<MemberRealNews> {

}
