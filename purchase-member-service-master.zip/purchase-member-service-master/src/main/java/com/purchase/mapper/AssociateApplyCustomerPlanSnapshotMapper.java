package com.purchase.mapper;

import com.purchase.entity.AssociateApplyCustomerPlanSnapshot;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 终端客户合作拓展计划 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-15
 */
@Mapper
public interface AssociateApplyCustomerPlanSnapshotMapper extends BaseMapper<AssociateApplyCustomerPlanSnapshot> {

}
