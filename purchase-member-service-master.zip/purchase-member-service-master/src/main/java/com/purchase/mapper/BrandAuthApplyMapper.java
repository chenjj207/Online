package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.BrandAuthApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.BrandAuthApplyCountDTO;
import com.purchase.service.dto.BrandAuthApplyPageDTO;
import com.purchase.service.vo.BrandAuthTimeVO;
import com.purchase.service.vo.CustSaleVO;
import com.purchase.service.vo.SubCompanyVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 品牌授权申请 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-04-11
 */
@Mapper
public interface BrandAuthApplyMapper extends BaseMapper<BrandAuthApply> {
    Page<BrandAuthApply> page (@Param("dto") BrandAuthApplyPageDTO dto , Page page);

    int countByState(@Param("dto") BrandAuthApplyCountDTO brandAuthApplyCountDTO);

    List<BrandAuthApply> allList(@Param("dto") BrandAuthApplyCountDTO brandAuthApplyCountDTO);

    BigDecimal sumAnnualIndicators(@Param("year")Integer year,  @Param("company")String company);
    BrandAuthApply selectQnPlanPurchase(@Param("year")Integer year,  @Param("company")String company);

    BrandAuthApply selectPlanPurchase(@Param("year")Integer year,  @Param("company")String company, @Param("authTime")String authTime);

    BrandAuthApply selectByOne(@Param("year")Integer year, @Param("authTime")String authTime, @Param("company")String company);

    SubCompanyVO selectAddressBySubCompany(@Param("shortName")String shortName);

    List<BrandAuthTimeVO> selectAuthTime();

    List<CustSaleVO> selectCustSaleByYear(@Param("year")Integer year, @Param("company")String company, @Param("subCompany")String subCompany);

    List<CustSaleVO> selectCustSaleByLastYear(@Param("year")Integer year, @Param("company")String company, @Param("subCompany")String subCompany);
}
