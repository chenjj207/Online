package com.purchase.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Cooperation;
import com.purchase.service.dto.CooperationPageDTO;
import com.purchase.service.dto.MemberCooperationDTO;
import com.purchase.service.vo.CooperationPageVO;
import com.purchase.service.vo.MemberCooperationVO;
import com.zyd.framework.boot.config.base.PageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 协作表 Mapper 接口
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Mapper
public interface CooperationMapper extends BaseMapper<Cooperation> {
    Page<MemberCooperationVO> list (@Param("dto")MemberCooperationDTO dto,@Param("id")String id ,Page page);

    Integer cooperationNum(@Param("id")Integer id);

    Page<CooperationPageVO> page (@Param("dto")CooperationPageDTO dto , Page page);
}
