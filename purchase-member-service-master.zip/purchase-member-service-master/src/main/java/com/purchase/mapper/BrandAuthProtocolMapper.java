package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.BrandAuthProtocol;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.BrandAuthProtocolPageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 品牌授权协议存档 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-06-03
 */
@Mapper
public interface BrandAuthProtocolMapper extends BaseMapper<BrandAuthProtocol> {

    Page<BrandAuthProtocol> page (@Param("dto") BrandAuthProtocolPageDTO dto , Page page);
}
