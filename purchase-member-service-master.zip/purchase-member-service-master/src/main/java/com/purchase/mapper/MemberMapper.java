package com.purchase.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Member;
import com.purchase.service.dto.MemberPageDTO;
import com.purchase.service.vo.*;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Mapper
public interface MemberMapper extends BaseMapper<Member> {

    List<String> selectCompanyByPromoter(String promoter);

    List<String> selectAllCompanyName();

    List<Map<String, Integer>> countIndustry();

    MemberSupplierOpenVO selectByIdWithCustomer(int id);

    Page<MemberPageVo> getPage(@Param("dto") MemberPageDTO memberPageDTO, Page buildPage);

    List<InferCompanyVO> inferCompanyName();

    String inferAreaName(@Param("key")String companyName);

    List<MemberStateNumVO> selectStateNumCount(@Param("item")List<Integer> ids);

    @MapKey("competence")
    List<Map<String, Integer>> countCompetence();

    List<String> otherAreaNameCompanyName(@Param("item")List<String> list);

    List<StatisticsMemberVO> statisticsIndustry();

    List<StatisticsMemberVO> statisticsCompetence();

    Page<MemberPageVo> selectMallPage(@Param("dto") MemberPageDTO memberPageDTO, Page buildPage);

    Page<MemberPageVo> selectMallPageNotLogin(@Param("dto") MemberPageDTO memberPageDTO, Page buildPage);

    Member queryInfo(@Param("id")Integer id);

    List<RecommendProductVO> selectRecommendProduct(@Param("supplierId")String supplierId);

    List<String> selectByArea(@Param("area")String area);
}
