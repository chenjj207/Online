package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.AssociateAuth;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.AssociateAuthPageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 联营授权 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-22
 */
@Mapper
public interface AssociateAuthMapper extends BaseMapper<AssociateAuth> {

    int selectCountName(@Param("protocolId")Integer protocolId);

    Page<AssociateAuth> page (@Param("dto") AssociateAuthPageDTO dto , Page page);
}
