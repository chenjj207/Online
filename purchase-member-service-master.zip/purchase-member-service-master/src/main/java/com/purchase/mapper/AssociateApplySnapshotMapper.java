package com.purchase.mapper;

import com.purchase.entity.AssociateApplySnapshot;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 联营申请表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-15
 */
@Mapper
public interface AssociateApplySnapshotMapper extends BaseMapper<AssociateApplySnapshot> {

}
