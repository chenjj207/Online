package com.purchase.mapper;

import com.purchase.entity.VisitLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 联营慧访问日志记录表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-06-29
 */
@Mapper
public interface VisitLogMapper extends BaseMapper<VisitLog> {

}
