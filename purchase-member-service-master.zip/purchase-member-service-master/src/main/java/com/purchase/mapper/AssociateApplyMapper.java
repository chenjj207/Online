package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.AssociateApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.AssociateApplyCountDTO;
import com.purchase.service.dto.AssociateApplyPageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 联营申请表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-14
 */
@Mapper
public interface AssociateApplyMapper extends BaseMapper<AssociateApply> {

    Page<AssociateApply> page (@Param("dto") AssociateApplyPageDTO dto , Page page);

    int countByState(@Param("dto") AssociateApplyCountDTO associateApplyCountDTO);

    String selectUserCode(@Param("code")String code);

    String selectUserEmail(@Param("name")String name, @Param("companyName")String companyName);
}
