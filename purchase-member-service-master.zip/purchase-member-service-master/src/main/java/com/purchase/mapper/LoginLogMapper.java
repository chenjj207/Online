package com.purchase.mapper;

import com.purchase.entity.LoginLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 登录日志表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-06-27
 */
@Mapper
public interface LoginLogMapper extends BaseMapper<LoginLog> {

}
