package com.purchase.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Message;
import com.purchase.service.dto.MessagePageDTO;
import com.purchase.service.dto.MessageQueryDTO;
import com.purchase.service.vo.MessageInfoVO;
import com.purchase.service.vo.MessagePageVO;
import com.purchase.service.vo.MessageWxPageVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 消息表 Mapper 接口
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Mapper
public interface MessageMapper extends BaseMapper<Message> {

    Page<MessagePageVO> page (@Param("dto") MessagePageDTO dto , Page page);

    MessageInfoVO info(@Param("dto") MessageQueryDTO dto);

    Page<MessageWxPageVO> wxPage(@Param("id")String id, Page buildPage);

    Page<MessagePageVO> mallPage (@Param("dto") MessagePageDTO dto , Page page);
}
