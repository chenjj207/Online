package com.purchase.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.entity.RealNewsType;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 资讯分类表 Mapper 接口
 * </p>
 *
 * @author
 * @since 2023-02-10
 */
@Mapper
public interface RealNewsTypeMapper extends BaseMapper<RealNewsType> {

}
