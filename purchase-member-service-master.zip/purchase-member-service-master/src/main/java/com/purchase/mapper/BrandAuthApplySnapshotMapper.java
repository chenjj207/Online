package com.purchase.mapper;

import com.purchase.entity.BrandAuthApplySnapshot;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 品牌授权申请 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-22
 */
@Mapper
public interface BrandAuthApplySnapshotMapper extends BaseMapper<BrandAuthApplySnapshot> {

}
