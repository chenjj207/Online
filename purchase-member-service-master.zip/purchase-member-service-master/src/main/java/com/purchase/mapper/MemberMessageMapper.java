package com.purchase.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.entity.MemberMessage;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 会员消息表 Mapper 接口
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Mapper
public interface MemberMessageMapper extends BaseMapper<MemberMessage> {

    Integer unReadNum(@Param("id") Integer id);
}
