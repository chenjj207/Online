package com.purchase.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.entity.Company;
import com.purchase.entity.CustomerSale;
import org.apache.ibatis.annotations.Mapper;

/**
 * 客户销售金额 Mapper 接口
 */
@Mapper
public interface CompanyMapper extends BaseMapper<Company> {


}
