package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
* <p>
* 联营授权
* </p>
*
* @author jidonglin
* @since 2024-05-22
*/
@Data
@Schema(title = "联营授权")
public class AssociateAuthAddDTO{

    @Schema(description = "协议id")
    @NotNull(message = "协议id不能为空")
    private Integer protocolId;

    @Schema(description = "文件地址")
    @NotEmpty(message = "文件地址不能为空")
    private String url;

    @Schema(description = "源文件名")
    @NotEmpty(message = "源文件名不能为空")
    private String fileName;
}
