package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/13  15:51
 */
@Data
public class RealNewsSenceDTO {

    @NotNull(message = "场景信息不能为空")
    @Schema(description = "场景信息")
    private String scene;
}
