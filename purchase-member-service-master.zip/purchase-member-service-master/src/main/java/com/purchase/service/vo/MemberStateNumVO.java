package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MemberStateNumVO {

    @Schema(description = "待审核状态会员数量")
    private Integer checkNum;
    @Schema(description = "通过状态会员数量")
    private Integer passNum;
    @Schema(description = "未通过状态会员数量")
    private Integer referNum;
    @Schema(description = "所属公司")
    private String companyName;
    @Schema(description = "所属大区")
    private String areaName;
}
