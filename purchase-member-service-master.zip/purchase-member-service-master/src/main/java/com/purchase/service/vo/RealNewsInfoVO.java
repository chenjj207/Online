package com.purchase.service.vo;

import com.purchase.entity.RealNews;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class RealNewsInfoVO extends RealNews {
    @Schema(description = "是否点赞")
    private Boolean isInterest;
}
