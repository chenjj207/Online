package com.purchase.service.impl;

import com.purchase.entity.BrandAuthApplySnapshot;
import com.purchase.mapper.BrandAuthApplySnapshotMapper;
import com.purchase.service.BrandAuthApplySnapshotService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 品牌授权申请 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-22
 */
@Service
public class BrandAuthApplySnapshotServiceImpl extends ServiceImpl<BrandAuthApplySnapshotMapper, BrandAuthApplySnapshot> implements BrandAuthApplySnapshotService {

}
