package com.purchase.service.vo;

import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/1/11  15:28
 */
@Data
public class RecommendProductVO {
    private Long productId;

    private String supplierId;

    private String brandImgUrl;

    private String brandName;

    private String productImgUrl;
}
