package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.RealNewsBrowseRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.RealNewsBrowseRecordPageDTO;

/**
 * <p>
 * 资讯浏览记录 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-01
 */
public interface RealNewsBrowseRecordService extends IService<RealNewsBrowseRecord> {


    public Page<RealNewsBrowseRecord> search(RealNewsBrowseRecordPageDTO realNewsBrowseRecordPageDTO);
}
