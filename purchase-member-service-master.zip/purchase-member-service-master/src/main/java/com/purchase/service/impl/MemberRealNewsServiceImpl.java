package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.purchase.common.MemberConstants;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.MemberRealNews;
import com.purchase.entity.RealNews;
import com.purchase.mapper.MemberRealNewsMapper;
import com.purchase.service.CommonService;
import com.purchase.service.MemberRealNewsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.RealNewsService;
import com.purchase.service.dto.RealNewsUpvoteDTO;
import com.purchase.utils.NoticeUtils;
import com.zyd.framework.utils.constant.UserSession;
import com.zyd.framework.utils.exception.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-12
 */
@Service
public class MemberRealNewsServiceImpl extends ServiceImpl<MemberRealNewsMapper, MemberRealNews> implements MemberRealNewsService {

    @Resource
    MemberRealNewsMapper memberRealNewsMapper;

    @Autowired
    RealNewsService realNewsService;

    @Autowired
    NoticeUtils noticeUtils;
    @Autowired
    CommonService commonService;
    @Override
    public Boolean upvote(RealNewsUpvoteDTO realNewsUpvoteDTO) {
        RealNews realNews = realNewsService.getById(realNewsUpvoteDTO.getRealNewsId());
        //资讯不存在报错
        if(BeanUtil.isEmpty(realNews)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_REAL_NEWS);
        }
        String memberId = null;
        if (realNewsUpvoteDTO.isPc()){
            memberId = commonService.memberId();
        }else {
            memberId = StpUtil.getLoginIdAsString();
        }
        //判断资讯是否为开启兴趣模式
        if(Objects.equals(realNews.getIsOpenInterested(), MemberConstants.RealNewsIsInterest.YES.getCode())){
            QueryWrapper<MemberRealNews> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("real_news_id",realNewsUpvoteDTO.getRealNewsId())
                    .eq("member_id", memberId);
            //如果不为空，则更新
            MemberRealNews realNew = memberRealNewsMapper.selectOne(queryWrapper);
            if(BeanUtil.isNotEmpty(realNew)){
                UpdateWrapper<MemberRealNews> updateWrapper = new UpdateWrapper<>();
                updateWrapper
                        .eq("real_news_id",realNewsUpvoteDTO.getRealNewsId())
                        .eq("member_id", memberId)
                        .set("updated_at", LocalDateTime.now());
                if (realNew.getInterested().equals(MemberConstants.IsInterset.YES.getCode())){
                    updateWrapper.set("interested",MemberConstants.IsInterset.NO.getCode());
                }else {
                    updateWrapper.set("interested",MemberConstants.IsInterset.YES.getCode());
                }
                return update(null,updateWrapper);
            }
            MemberRealNews memberRealNews = new MemberRealNews();
            BeanUtil.copyProperties(realNewsUpvoteDTO, memberRealNews);
            memberRealNews.setMemberId(Integer.parseInt(memberId));
            memberRealNews.setInterested(MemberConstants.RealNewsIsInterest.YES.getCode());
            memberRealNews.setCreatedAt(LocalDateTime.now());
            if (save(memberRealNews)){
                JSONObject member = (JSONObject) JSONObject.toJSON(StpUtil.getSession().getModel(UserSession.INFO, JSONObject.class));
               noticeUtils.sendQywx("联营慧会员【"+member.getString("company") +"】对"+"“"+realNews.getConsultType()+"”"+"的"+"“"+realNews.getConsultTitle()+"”"+"感兴趣，请进行查看");
                return true;
            }
        }
        return false;
    }

}
