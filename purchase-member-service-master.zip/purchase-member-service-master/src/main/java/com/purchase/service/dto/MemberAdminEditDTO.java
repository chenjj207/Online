package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;

@Data
public class MemberAdminEditDTO {

    @NotNull(message = "会员id")
    @Schema(description = "会员id")
    private Integer id;

    @Schema(description = "会员公司")
    private String company;

    @Schema(description = "对应服务行业")
    private String industry;

    @Schema(description = "核心能力")
    private String competence;

    @Schema(description = "联系人")
    private String linkman;

    @Length(max = 8, message = "推广人最大长度为8")
    @Schema(description = "推广人")
    private String promoter;

    @Schema(description = "推广人所属公司")
    @Length(max = 7, message = "备注最大长度为7")
    private String companyName;

    @Schema(description = "是否在小程序通讯录显示（0=不显示，1= 显示）")
    private Integer isShow;

    @Schema(description = "是否在小程序通讯录显示不通过原因（0=不显示，1= 显示）")
    private Integer isShowReason;

    @Schema(description = "未通过原因")
    private String reason;

    @Schema(description = "省")
    private String province;

    @Schema(description = "市")
    private String city;

    @Schema(description = "区")
    private String area;

    @Schema(description = "核心能力描述")
    private String competenceInfo;

    @Length(max = 30, message = "详细地址最大长度为30")
    @Schema(description = "详细地址")
    private String address;

    @Schema(description = "图片地址")
    private String memberUrl;


    @Length(max = 1000, message = "备注最大长度为1000")
    @Schema(description = "备注")
    private String remark;


}
