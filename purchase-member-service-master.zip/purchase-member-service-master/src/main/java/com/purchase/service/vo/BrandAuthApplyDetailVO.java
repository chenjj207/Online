package com.purchase.service.vo;

import com.purchase.entity.BrandAuthApply;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * @author jidonglin
 * @Description: 合作申请详情
 * @date 2024/4/15  14:09
 */
@Data
@Schema(description = "合作申请详情")
public class BrandAuthApplyDetailVO {

    @Schema(description = "品牌授权申请")
    private BrandAuthApply brandAuthApply;

    @Schema(description = "合作详情与申请计划")
    private List<BrandAuthApplyVO> brandAuthApplyVOList;
}
