package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
* <p>
* 品牌授权协议存档
* </p>
*
* @author jidonglin
* @since 2024-06-03
*/
@Data
@Schema(title = "品牌授权协议存档")
public class BrandAuthProtocolAddDTO{

    @Schema(description = "品牌授权id")
    @NotNull(message = "品牌授权id不能为空")
    private Integer brandAuthId;

    @Schema(description = "文件名称")
    @NotEmpty(message = "文件名称不能为空")
    private String name;

    @Schema(description = "文件地址")
    @NotEmpty(message = "文件地址不能为空")
    private String url;

}
