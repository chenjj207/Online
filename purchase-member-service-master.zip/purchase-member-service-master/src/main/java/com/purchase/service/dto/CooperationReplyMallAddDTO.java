package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;


@Data
public class CooperationReplyMallAddDTO {

    @Schema(description = "资讯id")
    @NotNull(message = "资讯id不能为空")
    private Integer realNewsId;

    @NotBlank(message = "信息不能为空")
    @Schema(description = "响应内容")
    private String content;
}
