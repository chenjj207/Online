package com.purchase.service;

import com.purchase.entity.AssociateApplyCustomerPlan;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 终端客户合作拓展计划 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-25
 */
public interface AssociateApplyCustomerPlanService extends IService<AssociateApplyCustomerPlan> {

}
