package com.purchase.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.client.WXClient;
import com.purchase.common.MemberConstants;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.AssociateApply;
import com.purchase.entity.AssociateProtocol;
import com.purchase.feign.ConfigClient;
import com.purchase.feign.UserClient;
import com.purchase.feign.param.AddStoreDTO;
import com.purchase.feign.param.JsonResult;
import com.purchase.feign.param.SupplierDTO;
import com.purchase.mapper.AssociateApplyMapper;
import com.purchase.mapper.AssociatePromotionMapper;
import com.purchase.mapper.AssociateProtocolMapper;
import com.purchase.service.AssociateProtocolService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.CommonService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.AssociateProtocoReadVO;
import com.purchase.service.vo.AssociateProtocolCountVO;
import com.zyd.framework.utils.exception.BaseExceptionDesc;
import com.zyd.framework.utils.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 联营协议 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-04-01
 */
@Service
@Slf4j
public class AssociateProtocolServiceImpl extends ServiceImpl<AssociateProtocolMapper, AssociateProtocol> implements AssociateProtocolService {

    @Resource
    AssociateProtocolMapper associateProtocolMapper;
    @Resource
    AssociatePromotionMapper associatePromotionMapper;
    @Resource
    AssociateApplyMapper associateApplyMapper;
    @Autowired
    CommonService commonService;
    @Value("${associateApplyAllAuth}")
    String associateApplyAllAuth;

    @Resource
    private WXClient wxClient;
    @Value("${wx.appid}")
    String appid;
    @Value("${wx.secret}")
    String secret;
    @Resource
    UserClient userClient;
    @Resource
    ConfigClient configClient;

    @Override
    public Page<AssociateProtocol> queryList(AssociateProtocolPageDTO associateProtocolPageDTO) {
        //数据权限
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        List<String> promotionList = associatePromotionMapper.selectPromotionCode();
        List<String> list = Arrays.asList(associateApplyAllAuth.split(","));
        if (list.contains(code)){
            //配置的看所有
        }else if (promotionList.contains(code)){
            //项目推广人只查自己的
            associateProtocolPageDTO.setPromotionPerson(name);
        }else {
            //其他看不到数据
            return new Page<>();
        }
        return associateProtocolMapper.page(associateProtocolPageDTO, associateProtocolPageDTO.buildPage());
    }

    @Override
    public List<AssociateProtocolCountVO> countNum(AssociateProtocolCountDTO associateProtocolCountDTO) {
        //数据权限
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        List<String> promotionList = associatePromotionMapper.selectPromotionCode();
        List<String> list = Arrays.asList(associateApplyAllAuth.split(","));
        if (list.contains(code)){
            //配置的看所有
        }else if (promotionList.contains(code)){
            //项目推广人只查自己的
            associateProtocolCountDTO.setPromotionPerson(name);
        }else {
            //其他看不到数据
            return new ArrayList<>();
        }

        List<AssociateProtocolCountVO> associateProtocolCountVOS = new ArrayList<>();
        AssociateProtocolCountVO associateApplyCountVO0 = new AssociateProtocolCountVO();
        associateApplyCountVO0.setState("0");
        associateProtocolCountDTO.setState("0");
        associateApplyCountVO0.setCount(associateProtocolMapper.countByState(associateProtocolCountDTO));
        AssociateProtocolCountVO associateApplyCountVO1 = new AssociateProtocolCountVO();
        associateApplyCountVO1.setState("1");
        associateProtocolCountDTO.setState("1");
        associateApplyCountVO1.setCount(associateProtocolMapper.countByState(associateProtocolCountDTO));
        AssociateProtocolCountVO associateApplyCountVO2 = new AssociateProtocolCountVO();
        associateApplyCountVO2.setState("2");
        associateProtocolCountDTO.setState("2");
        associateApplyCountVO2.setCount(associateProtocolMapper.countByState(associateProtocolCountDTO));
        AssociateProtocolCountVO associateApplyCountVO3 = new AssociateProtocolCountVO();
        associateApplyCountVO3.setState("3");
        associateProtocolCountDTO.setState("3");
        associateApplyCountVO3.setCount(associateProtocolMapper.countByState(associateProtocolCountDTO));
        AssociateProtocolCountVO associateApplyCountVO4 = new AssociateProtocolCountVO();
        associateApplyCountVO4.setState("4");
        associateProtocolCountDTO.setState("4");
        associateApplyCountVO4.setCount(associateProtocolMapper.countByState(associateProtocolCountDTO));

        associateProtocolCountVOS.add(associateApplyCountVO0);
        associateProtocolCountVOS.add(associateApplyCountVO1);
        associateProtocolCountVOS.add(associateApplyCountVO2);
        associateProtocolCountVOS.add(associateApplyCountVO3);
        associateProtocolCountVOS.add(associateApplyCountVO4);
        return associateProtocolCountVOS;
    }

    @Override
    public List<AssociateProtocol> queryByJsCode(AssociateProtocolQueryDTO associateProtocolQueryDTO) {
        //get请求 https://api.weixin.qq.com/sns/jscode2session 获取session_key，unionid，openid等数据
//        JSONObject jsonObject = wxClient.jscode2session(appid, secret, associateProtocolQueryDTO.getJsCode());
//        if (jsonObject.containsKey("errcode") && jsonObject.getInteger("errcode") != 0){
//            log.error(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getCode() + ": " +
//                    PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getDesc() + ": " + jsonObject.getString("errmsg"));
//            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR);
//        }
//        String openid = jsonObject.getString("openid");
//        String unionid = jsonObject.getString("unionid");
        String openid = associateProtocolQueryDTO.getOpenId();
        QueryWrapper<AssociateApply> associateApplyQueryWrapper1 = new QueryWrapper<>();
        associateApplyQueryWrapper1.eq("open_id", openid);
        List<AssociateApply> associateApplyList1 = associateApplyMapper.selectList(associateApplyQueryWrapper1);
        if (CollectionUtil.isEmpty(associateApplyList1)){
            return null;
        }
        AssociateApply associateApply = associateApplyList1.get(0);

        QueryWrapper<AssociateProtocol> associateProtocolQueryWrapper = new QueryWrapper<>();
        associateProtocolQueryWrapper.eq("apply_id", associateApply.getId());
        List<AssociateProtocol> list = this.list(associateProtocolQueryWrapper);
        if (CollectionUtils.isEmpty(list)){
            return null;
        }
        for (AssociateProtocol a : list) {
            a.setCompany(associateApply.getCompany());
        }
        UpdateWrapper<AssociateProtocol> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("is_read", 1)
                .eq("apply_id", associateApply.getId());
        this.update(updateWrapper);
        return list;
    }

    @Override
    @Transactional
    public Boolean editState(AssociateProtocolEditStateDTO associateProtocolEditStateDTO) {
        AssociateProtocol associateProtocol = this.getById(associateProtocolEditStateDTO.getId());
        if (associateProtocol == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_ASSOCIATE_PROTOCOL);
        }
        if (StringUtils.equals(associateProtocolEditStateDTO.getState(), MemberConstants.AssociateProtocolState.VOIDED.code)){
            if (StringUtils.isEmpty(associateProtocolEditStateDTO.getCancelReason())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_CANCEL_REASON);
            }
        }
        if (StringUtils.equals(associateProtocolEditStateDTO.getState(), MemberConstants.AssociateProtocolState.BE_EFFECTIVE.code)){
            if (!StringUtils.equals(associateProtocol.getState(), MemberConstants.AssociateProtocolState.BE_SENT.code)){
                //修改为待生效的前提是，当前状态为待寄出
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.CAN_NOT_SENT);
            }
        }
        LocalDateTime now = LocalDateTime.now();
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        UpdateWrapper<AssociateProtocol> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("state", associateProtocolEditStateDTO.getState())
                .set(StringUtils.isNotEmpty(associateProtocolEditStateDTO.getCancelReason()), "cancel_reason", associateProtocolEditStateDTO.getCancelReason())
                .set(StringUtils.isNotEmpty(associateProtocolEditStateDTO.getRemark()), "remark", associateProtocolEditStateDTO.getRemark())
                .set("updated_at", now)
                .set("updated_by", code)
                .set(StringUtils.equals(associateProtocolEditStateDTO.getState(), MemberConstants.AssociateProtocolState.EFFECTIVE.code), "file_time", now)
                .set(StringUtils.equals(associateProtocolEditStateDTO.getState(), MemberConstants.AssociateProtocolState.BE_EFFECTIVE.code), "sent_time", now)
                .set(StringUtils.equals(associateProtocolEditStateDTO.getState(), MemberConstants.AssociateProtocolState.EFFECTIVE.code), "file_person", name)
                .eq("id", associateProtocolEditStateDTO.getId());
        boolean result = this.update(updateWrapper);
//        2024/11/21 https://zentao-gz.zyd.cn/index.php?m=story&f=view&storyID=2668&version=11&param=913#app=execution  备注：对现在操作【归档】后，暂停短信通知供应商账号和初始密码的短信；
//        if (result && StringUtils.equals(associateProtocolEditStateDTO.getState(), "2") && StringUtils.equals("产线联营", associateProtocol.getType())){
//
//            AssociateApply associateApply = associateApplyMapper.selectById(associateProtocol.getApplyId());
//            //更新成功，并且为【已生效】， 并且为产线联营
//            SupplierDTO supplierDTO = new SupplierDTO();
//            supplierDTO.setName(associateApply.getCompany());
//            supplierDTO.setCode(associateApply.getLinkphone());
//            supplierDTO.setType(MemberConstants.SupplierSourceType.ASSOCIATE_PROTOCOL.code);
//            supplierDTO.setSend(true);
//            supplierDTO.setCreatedBy(code);
//            supplierDTO.setUpdatedBy(code);
//            //添加供应商、用户及发送短信
//            JsonResult<SupplierDTO> jsonResult = userClient.add(supplierDTO);
//            if (jsonResult.isSuccess()){
//                //新增供应商店铺
//                AddStoreDTO addStoreDTO = new AddStoreDTO();
//                addStoreDTO.setStoreName(associateApply.getCompany());
//                addStoreDTO.setStoreType(1);
//                addStoreDTO.setProvince(associateApply.getProvince());
//                addStoreDTO.setCity(associateApply.getCity());
//                addStoreDTO.setArea(associateApply.getArea());
//                addStoreDTO.setAddress(associateApply.getAddress());
//                addStoreDTO.setLinkMan(associateApply.getLinkman());
//                addStoreDTO.setLinkPhone(associateApply.getLinkphone());
//                addStoreDTO.setSupplierId(jsonResult.getData().getId());
//                addStoreDTO.setState(1);
//                addStoreDTO.setCreatedBy(code);
//                JsonResult jsonResult1 = configClient.add(addStoreDTO);
//                log.info("店铺添加： " + jsonResult1.toString());
//                return true;
//            }else {
//                BaseExceptionDesc baseExceptionDesc = new BaseExceptionDesc(PurchaseBusinessExceptionDesc.ERROR_BIND_SUPPLIER.getCode(), jsonResult.getMsg());
//                throw BusinessException.newInstance(baseExceptionDesc);
//            }
//        }
        return result;
    }

    @Override
    public AssociateProtocoReadVO queryRead(AssociateProtocolQueryDTO associateProtocolQueryDTO) {
        AssociateProtocoReadVO associateProtocoReadVO = new AssociateProtocoReadVO();
//        JSONObject jsonObject = wxClient.jscode2session(appid, secret, associateProtocolQueryDTO.getJsCode());
//        if (jsonObject.containsKey("errcode") && jsonObject.getInteger("errcode") != 0){
//            log.error(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getCode() + ": " +
//                    PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getDesc() + ": " + jsonObject.getString("errmsg"));
//            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR);
//        }
//        String openid = jsonObject.getString("openid");
        String openid = associateProtocolQueryDTO.getOpenId();
        QueryWrapper<AssociateApply> associateApplyQueryWrapper1 = new QueryWrapper<>();
        associateApplyQueryWrapper1.eq("open_id", openid);
        List<AssociateApply> associateApplyList1 = associateApplyMapper.selectList(associateApplyQueryWrapper1);
        if (CollectionUtil.isEmpty(associateApplyList1)){
            return associateProtocoReadVO;
        }
        AssociateApply associateApply = associateApplyList1.get(0);
        associateProtocoReadVO.setCount(associateProtocolMapper.countRead(associateApply.getId(), null));
        associateProtocoReadVO.setExistNotRead(associateProtocolMapper.countRead(associateApply.getId(), "0") > 0);
        return associateProtocoReadVO;
    }

}
