package com.purchase.service;

import com.purchase.entity.AssociateApplyProductPlanSnapshot;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 计划合作产品基础信息 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-15
 */
public interface AssociateApplyProductPlanSnapshotService extends IService<AssociateApplyProductPlanSnapshot> {

}
