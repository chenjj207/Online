package com.purchase.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.URLUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.PutObjectRequest;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dtflys.forest.Forest;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.client.feign.MsgClient;
import com.purchase.common.MemberConstants;
import com.purchase.config.OssConf;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.AssociatePromotion;
import com.purchase.entity.BrandAuthApply;
import com.purchase.entity.BrandAuthApplySnapshot;
import com.purchase.entity.BrandAuthProtocol;
import com.purchase.mapper.AssociatePromotionMapper;
import com.purchase.mapper.BrandAuthApplyMapper;
import com.purchase.mapper.BrandAuthApplySnapshotMapper;
import com.purchase.mapper.BrandAuthProtocolMapper;
import com.purchase.service.BrandAuthApplyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.CommonService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.*;
import com.purchase.utils.TokenUtils;
import com.zyd.framework.utils.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDFontDescriptor;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * <p>
 * 品牌授权申请 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-04-11
 */
@Service
@Slf4j
public class BrandAuthApplyServiceImpl extends ServiceImpl<BrandAuthApplyMapper, BrandAuthApply> implements BrandAuthApplyService {

    @Autowired
    AliSmsService aliSmsService;
    @Resource
    private MsgClient msgClient;
    @Resource
    AssociatePromotionMapper associatePromotionMapper;
    @Resource
    BrandAuthApplyMapper brandAuthApplyMapper;
    @Resource
    BrandAuthApplySnapshotMapper brandAuthApplySnapshotMapper;
    @Resource
    BrandAuthProtocolMapper brandAuthProtocolMapper;
    @Autowired
    CommonService commonService;
    @Value("${associateApplyAllAuth}")
    String associateApplyAllAuth;

    @Value("${odsUrl}")
    String odsUrl;
    @Value("${fontPath}")
    String fontPath;
    @Value("${brandAuthProtocol}")
    String brandAuthProtocol;
    @Value("${brandAuthPath}")
    String brandAuthPath;

    @Autowired
    OssConf ossConfig;
    @Autowired
    TokenUtils tokenUtils;

    @Override
    @Transactional
    public Integer add(BrandAuthApplyAddDTO brandAuthApplyAddDTO) {
        QueryWrapper<BrandAuthApply> associateApplyQueryWrapper1 = new QueryWrapper<>();
        associateApplyQueryWrapper1.eq("open_id", brandAuthApplyAddDTO.getOpenId());
        List<BrandAuthApply> associateApplyList1 = this.list(associateApplyQueryWrapper1);
        if (CollectionUtil.isNotEmpty(associateApplyList1)){
            BrandAuthApply brandAuthApply = associateApplyList1.get(0);
            if (!StringUtils.equals(brandAuthApply.getCompany(), brandAuthApplyAddDTO.getCompany())){
                //当前用户申请过的公司 与 已存在的公司不一致，无法申请
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_BRAND_AUTH_COMPANY);
            }
        }
        LocalDate currentDate = LocalDate.now();
        YearMonth yearMonth = YearMonth.from(currentDate);
        int year = yearMonth.getYear();
        int month = yearMonth.getMonthValue();
        String authTime = null;
        BigDecimal planPurchase = BigDecimal.ZERO;
        if (month >=1 && month <= 3){
            authTime = "2";
            planPurchase = brandAuthApplyAddDTO.getTwoIndicators();
        }else if (month >=4 && month <= 6){
            authTime = "3";
            planPurchase = brandAuthApplyAddDTO.getThreeIndicators();
        }else if (month >=7 && month <= 9){
            authTime = "4";
            planPurchase = brandAuthApplyAddDTO.getFourIndicators();
        }else if (month >=10 && month <= 12){
            //第四季度申请下一年第一季度的数据，需要重新填写申请表数据。接口以填写为准
            year = year + 1;
            authTime = "1";
            planPurchase = brandAuthApplyAddDTO.getOneIndicators();
        }
        //判断当前公司是否提交过品牌授权申请
        QueryWrapper<BrandAuthApply> associateApplyQueryWrapper2 = new QueryWrapper<>();
        associateApplyQueryWrapper2.eq("company", brandAuthApplyAddDTO.getCompany())
                .eq("year", year)
                .eq("auth_time", authTime);
        List<BrandAuthApply> associateApplyList2 = this.list(associateApplyQueryWrapper2);
        if (CollectionUtil.isNotEmpty(associateApplyList2)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.EXIST_COMPANY_BRAND_AUTH);
        }

        //初始化 新签
        String signType = "1";

        int yearQuery = year;
        int authTimeQuery = Integer.parseInt(authTime);
        if (StringUtils.equals(authTime, "1")){
            authTimeQuery = 4;
            yearQuery = yearQuery - 1;
        }else {
            authTimeQuery = authTimeQuery - 1;
        }

        //查询上一季度的品牌授权
        QueryWrapper<BrandAuthApply> associateApplyQueryWrapper4 = new QueryWrapper<>();
        associateApplyQueryWrapper4.eq("company", brandAuthApplyAddDTO.getCompany())
                .eq("year", yearQuery).eq("auth_time", authTimeQuery).eq("state", "5");
        List<BrandAuthApply> associateApplyList4 = this.list(associateApplyQueryWrapper4);
        if (CollectionUtils.isNotEmpty(associateApplyList4)){
            //如果上个季度存在，就是续签
            signType = "2";
        }

        //查询上年度的品牌授权
        QueryWrapper<BrandAuthApply> associateApplyQueryWrapper3 = new QueryWrapper<>();
        associateApplyQueryWrapper3.eq("company", brandAuthApplyAddDTO.getCompany())
                .eq("year", year);
        List<BrandAuthApply> associateApplyList3 = this.list(associateApplyQueryWrapper3);

        String archive = "0";
        List<BrandAuthProtocol> brandAuthProtocols = null;
        if (CollectionUtils.isNotEmpty(associateApplyList3)){
            //说明是续约，修改计划采购额为入参
            if (brandAuthApplyAddDTO.getPlanPurchase() == null){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_PLANPURCHASE);
            }
            planPurchase = brandAuthApplyAddDTO.getPlanPurchase();
            for (BrandAuthApply b : associateApplyList3) {
                //存在已发放的品牌授权，签约类型为 续签
//                if (StringUtils.equals(b.getState(), "5")){
//                    signType = "2";
//                }
                if (StringUtils.equals(b.getArchive(), "1")){
                    archive = "1";
                    QueryWrapper<BrandAuthProtocol> queryWrapper = new QueryWrapper<>();
                    queryWrapper.eq("brand_auth_id", b.getId());
                    brandAuthProtocols = brandAuthProtocolMapper.selectList(queryWrapper);
                }
            }
        }else {
            //首次申请才校验验证码
            //校验验证码
            aliSmsService.valid("BRAND_AUTH_APPLY", brandAuthApplyAddDTO.getLinkphone(), brandAuthApplyAddDTO.getSmsCode());
        }

        //查询项目推广专员
        QueryWrapper<AssociatePromotion> associatePromotionQueryWrapper = new QueryWrapper<>();
        associatePromotionQueryWrapper.eq("company_name", brandAuthApplyAddDTO.getSubCompany());
        List<AssociatePromotion> associatePromotions = associatePromotionMapper.selectList(associatePromotionQueryWrapper);
        if (CollectionUtil.isEmpty(associatePromotions)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PROMOTION);
        }

        LocalDateTime now = LocalDateTime.now();
        BrandAuthApply brandAuthApply = BeanUtil.copyProperties(brandAuthApplyAddDTO, BrandAuthApply.class);
        brandAuthApply.setPromotionPerson(associatePromotions.get(0).getPromotionPerson());
        brandAuthApply.setYear(year);
        brandAuthApply.setCreatedAt(now);
        brandAuthApply.setCreatedBy(brandAuthApply.getOpenId());

        brandAuthApply.setState(MemberConstants.BrandAuthApply.PENDING_APPROVAL.code);
        brandAuthApply.setAuthTime(authTime);
        brandAuthApply.setYear(year);
        brandAuthApply.setPlanPurchase(planPurchase);
        brandAuthApply.setSignType(signType);
        brandAuthApply.setArchive(archive);
        boolean result = this.save(brandAuthApply);
        if (result && StringUtils.equals(archive, "1") && CollectionUtils.isNotEmpty(brandAuthProtocols)){
            //默认生成上传一个授权记录
            for (BrandAuthProtocol b : brandAuthProtocols) {
                BrandAuthProtocol brandAuthProtocol1 = new BrandAuthProtocol();
                BeanUtil.copyProperties(b, brandAuthProtocol1, "id", "brandAuthId");
                brandAuthProtocol1.setBrandAuthId(brandAuthApply.getId());
                brandAuthProtocolMapper.insert(brandAuthProtocol1);
            }
        }

        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("brandAuth");
        triggerMsgRequest.setScene("brandAuthApplypromotion");
        JSONObject qywxParam = new JSONObject();
        qywxParam.put("msgtype", "template_card");

        JSONObject templateCard = new JSONObject();
        templateCard.put("card_type", "text_notice");

        JSONObject mainTitle = new JSONObject();
        mainTitle.put("title", "品牌授权待审批");
        mainTitle.put("desc", "");
        templateCard.put("main_title", mainTitle);

        List<JSONObject> horizontalContentList = new ArrayList<>();
        JSONObject keyName1 = new JSONObject();
        keyName1.put("keyname", "客户");
        keyName1.put("value", brandAuthApplyAddDTO.getCompany());
        horizontalContentList.add(keyName1);
        JSONObject keyName2 = new JSONObject();
        keyName2.put("keyname", "联系人");
        keyName2.put("value", brandAuthApplyAddDTO.getLinkman());
        horizontalContentList.add(keyName2);
        JSONObject keyName3 = new JSONObject();
        keyName3.put("keyname", "提交时间");
        keyName3.put("value", DateUtil.format(brandAuthApply.getCreatedAt(), "yyyy/MM/dd HH:mm:ss"));
        horizontalContentList.add(keyName3);
        JSONObject keyName4 = new JSONObject();
        keyName4.put("keyname", "备注");
        keyName4.put("value", "客户提交了品牌授权申请，点击查看详情并等待领导审批。");
        horizontalContentList.add(keyName4);
        templateCard.put("horizontal_content_list", horizontalContentList);

        List<JSONObject> jumpList = new ArrayList<>();
        JSONObject jumpList1 = new JSONObject();
        jumpList1.put("type", 1);
        jumpList1.put("title", "跳转惠采");
        jumpList1.put("url", odsUrl + "/#/purchase-sign/brand-authorize?key=" + URLUtil.encode(brandAuthApplyAddDTO.getCompany()));
        jumpList.add(jumpList1);
        templateCard.put("jump_list", jumpList);

        JSONObject cardAction = new JSONObject();
        cardAction.put("type", 1);
        cardAction.put("url",  odsUrl + "/#/purchase-sign/brand-authorize?key=" + URLUtil.encode(brandAuthApplyAddDTO.getCompany()));
        templateCard.put("card_action", cardAction);
        qywxParam.put("template_card", templateCard);

        //同步消息通知项目推广专员
        qywxParam.put("noticeUser", associatePromotions.get(0).getCode());

        triggerMsgRequest.setQywxParam(qywxParam);
        msgClient.triggerMsg(triggerMsgRequest);
        return brandAuthApply.getId();
    }

    @Override
    public Integer edit(BrandAuthApplyEditDTO brandAuthApplyEditDTO) {
        BrandAuthApply brandAuthApply = brandAuthApplyMapper.selectById(brandAuthApplyEditDTO.getId());
        if (brandAuthApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_BRAND_AUTH_APPLY);
        }
        if (StringUtils.equals(brandAuthApply.getState(), "2") || StringUtils.equals(brandAuthApply.getState(), "4")
                || StringUtils.equals(brandAuthApply.getState(), "5") || StringUtils.equals(brandAuthApply.getState(), "6")){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EDIT_ASSOCIATE_BRAND);
        }
        LocalDate currentDate = LocalDate.now();
        YearMonth yearMonth = YearMonth.from(currentDate);
        int year = yearMonth.getYear();
        int month = yearMonth.getMonthValue();
        String authTime = null;
        BigDecimal planPurchase = BigDecimal.ZERO;
        if (month >=1 && month <= 3){
            authTime = "2";
            planPurchase = brandAuthApplyEditDTO.getTwoIndicators();
        }else if (month >=4 && month <= 6){
            authTime = "3";
            planPurchase = brandAuthApplyEditDTO.getThreeIndicators();
        }else if (month >=7 && month <= 9){
            authTime = "4";
            planPurchase = brandAuthApplyEditDTO.getFourIndicators();
        }else if (month >=10 && month <= 12){
            //第四季度申请下一年第一季度的数据，需要重新填写申请表数据。接口以填写为准
            year = year + 1;
            authTime = "1";
            planPurchase = brandAuthApplyEditDTO.getOneIndicators();
        }

        QueryWrapper<BrandAuthApply> associateApplyQueryWrapper1 = new QueryWrapper<>();
        associateApplyQueryWrapper1.eq("open_id", brandAuthApplyEditDTO.getOpenId());
        List<BrandAuthApply> associateApplyList1 = this.list(associateApplyQueryWrapper1);
        if (CollectionUtil.isNotEmpty(associateApplyList1)){
            BrandAuthApply authApply = associateApplyList1.get(0);
            if (!StringUtils.equals(authApply.getCompany(), brandAuthApplyEditDTO.getCompany())){
                //当前用户申请过的公司 与 已存在的公司不一致，无法申请
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_BRAND_AUTH_COMPANY);
            }
        }

        //校验验证码
        aliSmsService.valid("BRAND_AUTH_APPLY", brandAuthApplyEditDTO.getLinkphone(), brandAuthApplyEditDTO.getSmsCode());
        //查询项目推广专员
        QueryWrapper<AssociatePromotion> associatePromotionQueryWrapper = new QueryWrapper<>();
        associatePromotionQueryWrapper.eq("company_name", brandAuthApplyEditDTO.getSubCompany());
        List<AssociatePromotion> associatePromotions = associatePromotionMapper.selectList(associatePromotionQueryWrapper);
        if (CollectionUtil.isEmpty(associatePromotions)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PROMOTION);
        }

        BeanUtil.copyProperties(brandAuthApplyEditDTO, brandAuthApply);
        brandAuthApply.setPlanPurchase(planPurchase);
        brandAuthApply.setYear(year);
        brandAuthApply.setAuthTime(authTime);
        brandAuthApply.setGrantReason(null);
        brandAuthApply.setRejectReason(null);
        brandAuthApply.setState(MemberConstants.BrandAuthApply.PENDING_APPROVAL.code);
        brandAuthApply.setPromotionPerson(associatePromotions.get(0).getPromotionPerson());
        brandAuthApply.setUpdatedAt(LocalDateTime.now());
        brandAuthApply.setUpdatedBy(brandAuthApply.getOpenId());

        brandAuthApplyMapper.updateById(brandAuthApply);

        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("brandAuth");
        triggerMsgRequest.setScene("brandAuthApply");
        JSONObject qywxParam = new JSONObject();
        qywxParam.put("msgtype", "template_card");

        JSONObject templateCard = new JSONObject();
        templateCard.put("card_type", "text_notice");

        JSONObject mainTitle = new JSONObject();
        mainTitle.put("title", "品牌授权待审批");
        mainTitle.put("desc", "");
        templateCard.put("main_title", mainTitle);

        List<JSONObject> horizontalContentList = new ArrayList<>();
        JSONObject keyName1 = new JSONObject();
        keyName1.put("keyname", "客户");
        keyName1.put("value", brandAuthApplyEditDTO.getCompany());
        horizontalContentList.add(keyName1);
        JSONObject keyName2 = new JSONObject();
        keyName2.put("keyname", "联系人");
        keyName2.put("value", brandAuthApplyEditDTO.getLinkman());
        horizontalContentList.add(keyName2);
        JSONObject keyName3 = new JSONObject();
        keyName3.put("keyname", "提交时间");
        keyName3.put("value", DateUtil.format(brandAuthApply.getUpdatedAt(), "yyyy/MM/dd HH:mm:ss"));
        horizontalContentList.add(keyName3);
        JSONObject keyName4 = new JSONObject();
        keyName4.put("keyname", "备注");
        keyName4.put("value", "客户提交了品牌授权申请，赶紧去查看并审核吧。");
        horizontalContentList.add(keyName4);
        templateCard.put("horizontal_content_list", horizontalContentList);

        List<JSONObject> jumpList = new ArrayList<>();
        JSONObject jumpList1 = new JSONObject();
        jumpList1.put("type", 1);
        jumpList1.put("title", "跳转惠采");
        jumpList1.put("url", odsUrl + "/#/purchase-sign/brand-authorize?key=" + URLUtil.encode(brandAuthApplyEditDTO.getCompany()));
        jumpList.add(jumpList1);
        templateCard.put("jump_list", jumpList);

        JSONObject cardAction = new JSONObject();
        cardAction.put("type", 1);
        cardAction.put("url",  odsUrl + "/#/purchase-sign/brand-authorize?key=" + URLUtil.encode(brandAuthApplyEditDTO.getCompany()));
        templateCard.put("card_action", cardAction);
        qywxParam.put("template_card", templateCard);
        triggerMsgRequest.setQywxParam(qywxParam);
        msgClient.triggerMsg(triggerMsgRequest);
        return brandAuthApply.getId();
    }

    @Override
    public Integer editAdmin(BrandAuthApplyEditAdminDTO brandAuthApplyEditAdminDTO) {
        BrandAuthApply brandAuthApply = this.getById(brandAuthApplyEditAdminDTO.getId());
        if (brandAuthApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_BRAND_AUTH_APPLY);
        }
        if (!StringUtils.equals(brandAuthApply.getSignType(), "1") || StringUtils.isNotEmpty(brandAuthApply.getProtocolUrl())){
            //不是首签 或者 补充协议不为空
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EDIT_ADMIN_BRAND_AUTH_APPLY);
        }
        //查询项目推广专员
        QueryWrapper<AssociatePromotion> associatePromotionQueryWrapper = new QueryWrapper<>();
        associatePromotionQueryWrapper.eq("company_name", brandAuthApplyEditAdminDTO.getSubCompany());
        List<AssociatePromotion> associatePromotions = associatePromotionMapper.selectList(associatePromotionQueryWrapper);
        if (CollectionUtil.isEmpty(associatePromotions)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PROMOTION);
        }
        BeanUtil.copyProperties(brandAuthApplyEditAdminDTO, brandAuthApply, "id", "createdAt", "createdBy", "updatedBy", "updatedAt");
        brandAuthApply.setUpdatedAt(LocalDateTime.now());
        brandAuthApply.setPromotionPerson(associatePromotions.get(0).getPromotionPerson());
        String code = (String) commonService.getUserInfo().get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        brandAuthApply.setUpdatedBy(code);
        brandAuthApplyMapper.updateById(brandAuthApply);
        return brandAuthApplyEditAdminDTO.getId();
    }

    @Override
    public BrandAuthRenewalVO renewal(QueryIdDTO queryIdDTO) {
        BrandAuthApply brandAuthApply = this.getById(queryIdDTO.getId());
        if (brandAuthApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_BRAND_AUTH_APPLY);
        }
        LocalDate currentDate = LocalDate.now();
        YearMonth yearMonth = YearMonth.from(currentDate);
        int year = yearMonth.getYear();
        int month = yearMonth.getMonthValue();
        String authTime = null;
        BigDecimal planPurchase = BigDecimal.ZERO;
        if (month >=1 && month <= 3){
            authTime = "2";
        }else if (month >=4 && month <= 6){
            authTime = "3";
        }else if (month >=7 && month <= 9){
            authTime = "4";
        }else if (month >=10 && month <= 12){
            //第四季度申请下一年第一季度的数据，需要重新填写申请表数据。接口以填写为准
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_RENEWAL);
        }
        BrandAuthRenewalVO brandAuthRenewalVO = new BrandAuthRenewalVO();
        brandAuthRenewalVO.setBrandAuthApply(brandAuthApply);
        List<CustSaleVO> custSaleVOS = brandAuthApplyMapper.selectCustSaleByYear(year, brandAuthApply.getCompany(), brandAuthApply.getSubCompany());
        if (CollectionUtils.isNotEmpty(custSaleVOS)){
            //正常就一条数据
            CustSaleVO custSaleVO = custSaleVOS.get(0);
            //不对有第一季度的续约
            if (StringUtils.equals(authTime, "2")){
                brandAuthRenewalVO.setThisQuarterPurchasePrice(custSaleVO.getSndS1Xsje());
            }else if (StringUtils.equals(authTime, "3")){
                brandAuthRenewalVO.setThisQuarterPurchasePrice(custSaleVO.getSndS2Xsje());
            }else if (StringUtils.equals(authTime, "4")){
                brandAuthRenewalVO.setThisQuarterPurchasePrice(custSaleVO.getSndS3Xsje());
            }
            brandAuthRenewalVO.setThisQuarterFinishStatus(calculatePercentage(brandAuthRenewalVO.getThisQuarterPurchasePrice(), brandAuthApply.getPlanPurchase()));
            brandAuthRenewalVO.setThisYearPurchasePrice(custSaleVO.getSndQnXsje());
            brandAuthRenewalVO.setThisYearFinishStatus(calculatePercentage(custSaleVO.getSndQnXsje(), brandAuthApply.getYearAnnualIndicators()));
        }
        return brandAuthRenewalVO;
    }

    /**
     * 计算占比
     * @param num1
     * @param num2
     * @return
     */
    public static BigDecimal calculatePercentage(BigDecimal num1, BigDecimal num2) {
        if (num1 == null || num2 == null || num2.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        BigDecimal percentage = num1.divide(num2, 4, BigDecimal.ROUND_DOWN).multiply(new BigDecimal("100"));
        return percentage.setScale(2, BigDecimal.ROUND_DOWN);
    }

    @Override
    public BrandAuthApply queryById(QueryIdDTO queryIdDTO) {
        BrandAuthApply brandAuthApply = this.getById(queryIdDTO.getId());
        if (brandAuthApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_BRAND_AUTH_APPLY);
        }
        return brandAuthApply;
    }

    @Override
    public List<BrandAuthApply> queryByOpenId(OpenIdDTO openIdDTO) {
        QueryWrapper<BrandAuthApply> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("open_id", openIdDTO.getOpenId()).orderByDesc("year", "auth_time");
        List<BrandAuthApply> brandAuthApplies = this.list(queryWrapper);
        if (CollectionUtils.isEmpty(brandAuthApplies)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_BRAND_AUTH_APPLY);
        }
        for (BrandAuthApply brandAuthApply : brandAuthApplies) {
            List<CustSaleVO> custSaleVOS = brandAuthApplyMapper.selectCustSaleByYear(brandAuthApply.getYear(), brandAuthApply.getCompany(), brandAuthApply.getSubCompany());
            if (CollectionUtils.isNotEmpty(custSaleVOS)){
                CustSaleVO custSaleVO = custSaleVOS.get(0);
                if (StringUtils.equals(brandAuthApply.getAuthTime(), "1")){
                    brandAuthApply.setRealityPurchase(custSaleVO.getSndS1Xsje());
                }else if (StringUtils.equals(brandAuthApply.getAuthTime(), "2")){
                    brandAuthApply.setRealityPurchase(custSaleVO.getSndS2Xsje());
                }else if (StringUtils.equals(brandAuthApply.getAuthTime(), "3")){
                    brandAuthApply.setRealityPurchase(custSaleVO.getSndS3Xsje());
                }else if (StringUtils.equals(brandAuthApply.getAuthTime(), "4")){
                    brandAuthApply.setRealityPurchase(custSaleVO.getSndS4Xsje());
                }
                brandAuthApply.setFinishStatus(calculatePercentage(brandAuthApply.getRealityPurchase(), brandAuthApply.getPlanPurchase()));
            }
        }
        return brandAuthApplies;
    }

    @Override
    public Page<BrandAuthApply> queryList(BrandAuthApplyPageDTO brandAuthApplyPageDTO) {
        //数据权限
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        List<String> promotionList = associatePromotionMapper.selectPromotionCode();
        List<String> list = Arrays.asList(associateApplyAllAuth.split(","));
        if (list.contains(code)){
            //配置的看所有
        }else if (promotionList.contains(code)){
            //项目推广人只查自己的
            brandAuthApplyPageDTO.setPromotionPerson(name);
        }else {
            //其他看不到数据
            return new Page<>();
        }
        return brandAuthApplyMapper.page(brandAuthApplyPageDTO, brandAuthApplyPageDTO.buildPage());
    }

    @Override
    public List<CommonCountVO> countNum(BrandAuthApplyCountDTO brandAuthApplyCountDTO) {
        //数据权限
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        List<String> promotionList = associatePromotionMapper.selectPromotionCode();
        List<String> list = Arrays.asList(associateApplyAllAuth.split(","));
        if (list.contains(code)){
            //配置的看所有
        }else if (promotionList.contains(code)){
            //项目推广人只查自己的
            brandAuthApplyCountDTO.setPromotionPerson(name);
        }else {
            //其他看不到数据
            return new ArrayList<>();
        }
        List<CommonCountVO> commonCountVOS = new ArrayList<>();
        CommonCountVO commonCountVO1 = new CommonCountVO();
        commonCountVO1.setState("1");
        brandAuthApplyCountDTO.setState("1");
        commonCountVO1.setCount(brandAuthApplyMapper.countByState(brandAuthApplyCountDTO));
        CommonCountVO commonCountVO2 = new CommonCountVO();
        commonCountVO2.setState("2");
        brandAuthApplyCountDTO.setState("2");
        commonCountVO2.setCount(brandAuthApplyMapper.countByState(brandAuthApplyCountDTO));
        CommonCountVO commonCountVO3 = new CommonCountVO();
        commonCountVO3.setState("3");
        brandAuthApplyCountDTO.setState("3");
        commonCountVO3.setCount(brandAuthApplyMapper.countByState(brandAuthApplyCountDTO));
        CommonCountVO commonCountVO4 = new CommonCountVO();
        commonCountVO4.setState("4");
        brandAuthApplyCountDTO.setState("4");
        commonCountVO4.setCount(brandAuthApplyMapper.countByState(brandAuthApplyCountDTO));
        CommonCountVO commonCountVO5 = new CommonCountVO();
        commonCountVO5.setState("5");
        brandAuthApplyCountDTO.setState("5");
        commonCountVO5.setCount(brandAuthApplyMapper.countByState(brandAuthApplyCountDTO));
        CommonCountVO commonCountVO6 = new CommonCountVO();
        commonCountVO6.setState("6");
        brandAuthApplyCountDTO.setState("6");
        commonCountVO6.setCount(brandAuthApplyMapper.countByState(brandAuthApplyCountDTO));

        commonCountVOS.add(commonCountVO1);
        commonCountVOS.add(commonCountVO2);
        commonCountVOS.add(commonCountVO3);
        commonCountVOS.add(commonCountVO4);
        commonCountVOS.add(commonCountVO5);
        commonCountVOS.add(commonCountVO6);
        return commonCountVOS;
    }

    @Override
    public void export(BrandAuthApplyCountDTO brandAuthApplyCountDTO, HttpServletResponse response) {
        //数据权限
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        List<String> promotionList = associatePromotionMapper.selectPromotionCode();
        List<String> list = Arrays.asList(associateApplyAllAuth.split(","));
        if (list.contains(code)){
            //配置的看所有
        }else if (promotionList.contains(code)){
            //项目推广人只查自己的
            brandAuthApplyCountDTO.setPromotionPerson(code);
        }else {
            //其他看不到数据
            return;
        }
        List<BrandAuthApply> brandAuthApplyPageRecords = brandAuthApplyMapper.allList(brandAuthApplyCountDTO);

        // 设置 Content-Type 头部信息
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        // 设置 Content-Disposition 头部信息，指定文件名
        try {
            response.setHeader("Content-Disposition", "attachment; filename="+ URLEncoder.encode("施耐德次终端牌照申请基础信息表","UTF8")+".xlsx");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        if (CollectionUtils.isNotEmpty(brandAuthApplyPageRecords)){
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            ClassPathResource resource = new ClassPathResource("template/brandApplyTemplate.xlsx");
            XSSFWorkbook workbook = null;
            try {
                InputStream is = resource.getInputStream();
                workbook = new XSSFWorkbook(is);
                XSSFCellStyle style = workbook.createCellStyle();
                style.setBorderBottom(BorderStyle.THIN);
                style.setBorderTop(BorderStyle.THIN);
                style.setBorderLeft(BorderStyle.THIN);
                style.setBorderRight(BorderStyle.THIN);
                style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
                style.setTopBorderColor(IndexedColors.BLACK.getIndex());
                style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
                style.setRightBorderColor(IndexedColors.BLACK.getIndex());
                XSSFSheet sheet = workbook.getSheetAt(0);
                for (int i = 0; i < brandAuthApplyPageRecords.size(); i++) {
                    int j = 2 + i;
                    Row row = sheet.createRow(j);
                    Cell companyCell = row.createCell(0);
                    companyCell.setCellValue(brandAuthApplyPageRecords.get(i).getCompany());
                    companyCell.setCellStyle(style);
                    Cell linkmanCell = row.createCell(1);
                    linkmanCell.setCellValue(brandAuthApplyPageRecords.get(i).getLinkman());
                    linkmanCell.setCellStyle(style);
                    Cell linkphoneCell = row.createCell(2);
                    linkphoneCell.setCellValue(brandAuthApplyPageRecords.get(i).getLinkphone());
                    linkphoneCell.setCellStyle(style);
                    Cell addressCell = row.createCell(3);
                    String province = StringUtils.isEmpty(brandAuthApplyPageRecords.get(i).getProvince()) ? "" : brandAuthApplyPageRecords.get(i).getProvince();
                    String city = StringUtils.isEmpty(brandAuthApplyPageRecords.get(i).getCity()) ? "" : brandAuthApplyPageRecords.get(i).getCity();
                    String area = StringUtils.isEmpty(brandAuthApplyPageRecords.get(i).getArea()) ? "" : brandAuthApplyPageRecords.get(i).getArea();
                    String address = StringUtils.isEmpty(brandAuthApplyPageRecords.get(i).getAddress()) ? "" : brandAuthApplyPageRecords.get(i).getAddress();
                    addressCell.setCellValue(province + city + area + address);
                    addressCell.setCellStyle(style);
                    Cell businessAddressCell = row.createCell(4);
                    String businessProvince = StringUtils.isEmpty(brandAuthApplyPageRecords.get(i).getBusinessProvince()) ? "" : brandAuthApplyPageRecords.get(i).getBusinessProvince();
                    String businessCity = StringUtils.isEmpty(brandAuthApplyPageRecords.get(i).getBusinessCity()) ? "" : brandAuthApplyPageRecords.get(i).getBusinessCity();
                    String businessArea = StringUtils.isEmpty(brandAuthApplyPageRecords.get(i).getBusinessArea()) ? "" : brandAuthApplyPageRecords.get(i).getBusinessArea();
                    String businessAddress = StringUtils.isEmpty(brandAuthApplyPageRecords.get(i).getBusinessAddress()) ? "" : brandAuthApplyPageRecords.get(i).getBusinessAddress();
                    businessAddressCell.setCellValue(businessProvince + businessCity + businessArea + businessAddress);
                    businessAddressCell.setCellStyle(style);

                    Cell lastYearTurnoverCell = row.createCell(5);
                    lastYearTurnoverCell.setCellValue(brandAuthApplyPageRecords.get(i).getLastYearTurnover().stripTrailingZeros().toPlainString() + "万");
                    lastYearTurnoverCell.setCellStyle(style);
                    Cell brandLastYearTurnoverCell = row.createCell(6);
                    brandLastYearTurnoverCell.setCellValue(brandAuthApplyPageRecords.get(i).getBrandLastYearTurnover().stripTrailingZeros().toPlainString() + "万");
                    brandLastYearTurnoverCell.setCellStyle(style);
                    Cell custNumCell = row.createCell(7);
                    custNumCell.setCellValue(brandAuthApplyPageRecords.get(i).getCustNum());
                    custNumCell.setCellStyle(style);
                    Cell userNumCell = row.createCell(8);
                    userNumCell.setCellValue(brandAuthApplyPageRecords.get(i).getUserNum());
                    userNumCell.setCellStyle(style);
                    Cell terminalCell = row.createCell(9);
                    terminalCell.setCellValue(brandAuthApplyPageRecords.get(i).getTerminal() + "%");
                    terminalCell.setCellStyle(style);
                    Cell wholesaleCell = row.createCell(10);
                    wholesaleCell.setCellValue(brandAuthApplyPageRecords.get(i).getWholesale() + "%");
                    wholesaleCell.setCellStyle(style);
                    Cell smallMediumProjectCell = row.createCell(11);
                    smallMediumProjectCell.setCellValue(brandAuthApplyPageRecords.get(i).getSmallMediumProject() + "%");
                    smallMediumProjectCell.setCellStyle(style);
                    Cell oemCell = row.createCell(12);
                    oemCell.setCellValue(brandAuthApplyPageRecords.get(i).getOem() + "%");
                    oemCell.setCellStyle(style);
                    Cell storeCell = row.createCell(13);
                    storeCell.setCellValue(brandAuthApplyPageRecords.get(i).getStore() + "%");
                    storeCell.setCellStyle(style);
                    Cell coreBusinessOtherCell = row.createCell(14);
                    coreBusinessOtherCell.setCellValue(brandAuthApplyPageRecords.get(i).getCoreBusinessOther() + "%");
                    coreBusinessOtherCell.setCellStyle(style);
                    Cell lowVoltageCell = row.createCell(15);
                    lowVoltageCell.setCellValue(brandAuthApplyPageRecords.get(i).getLowVoltage() + "%");
                    lowVoltageCell.setCellStyle(style);
                    Cell industrialAutoCell = row.createCell(16);
                    industrialAutoCell.setCellValue(brandAuthApplyPageRecords.get(i).getIndustrialAuto() + "%");
                    industrialAutoCell.setCellStyle(style);
                    Cell panelSwitchCell = row.createCell(17);
                    panelSwitchCell.setCellValue(brandAuthApplyPageRecords.get(i).getPanelSwitch() + "%");
                    panelSwitchCell.setCellStyle(style);
                    Cell mainBusinessOtherCell = row.createCell(18);
                    mainBusinessOtherCell.setCellValue(brandAuthApplyPageRecords.get(i).getMainBusinessOther() + "%");
                    mainBusinessOtherCell.setCellStyle(style);
                    Cell seCell = row.createCell(19);
                    seCell.setCellValue(brandAuthApplyPageRecords.get(i).getSe() + "%");
                    seCell.setCellStyle(style);
                    Cell abbCell = row.createCell(20);
                    abbCell.setCellValue(brandAuthApplyPageRecords.get(i).getAbb() + "%");
                    abbCell.setCellStyle(style);
                    Cell siemensCell = row.createCell(21);
                    siemensCell.setCellValue(brandAuthApplyPageRecords.get(i).getSiemens() + "%");
                    siemensCell.setCellStyle(style);
                    Cell cooperateBrandOtherCell = row.createCell(22);
                    cooperateBrandOtherCell.setCellValue(brandAuthApplyPageRecords.get(i).getCooperateBrandOther() + "%");
                    cooperateBrandOtherCell.setCellStyle(style);
                    Cell domesticCell = row.createCell(23);
                    domesticCell.setCellValue(brandAuthApplyPageRecords.get(i).getDomestic() + "%");
                    domesticCell.setCellStyle(style);
                    Cell growthTypeCell = row.createCell(24);
                    growthTypeCell.setCellValue(brandAuthApplyPageRecords.get(i).getGrowthType());
                    growthTypeCell.setCellStyle(style);
                    Cell growthRateCell = row.createCell(25);
                    growthRateCell.setCellValue(brandAuthApplyPageRecords.get(i).getGrowthRate() + "%");
                    growthRateCell.setCellStyle(style);
                    Cell growthReasonCell = row.createCell(26);
                    growthReasonCell.setCellValue(brandAuthApplyPageRecords.get(i).getGrowthReason());
                    growthReasonCell.setCellStyle(style);
                    Cell brandImageCell = row.createCell(27);
                    brandImageCell.setCellValue(brandAuthApplyPageRecords.get(i).getBrandImage());
                    brandImageCell.setCellStyle(style);
                    Cell brandMallCell = row.createCell(28);
                    brandMallCell.setCellValue(brandAuthApplyPageRecords.get(i).getBrandMall());
                    brandMallCell.setCellStyle(style);
                    Cell digitalMarketCell = row.createCell(29);
                    digitalMarketCell.setCellValue(brandAuthApplyPageRecords.get(i).getDigitalMarket());
                    digitalMarketCell.setCellStyle(style);
                    Cell upstreamDemandCell = row.createCell(30);
                    upstreamDemandCell.setCellValue(brandAuthApplyPageRecords.get(i).getUpstreamDemand());
                    upstreamDemandCell.setCellStyle(style);
                    Cell secondTerminalDemandCell = row.createCell(31);
                    secondTerminalDemandCell.setCellValue(brandAuthApplyPageRecords.get(i).getSecondTerminalDemand());
                    secondTerminalDemandCell.setCellStyle(style);
                    Cell distributorCell = row.createCell(32);
                    distributorCell.setCellValue("线上："+brandAuthApplyPageRecords.get(i).getOnlineUpstreamDistributor()+"，线下：" +brandAuthApplyPageRecords.get(i).getOfflineUpstreamDistributor());
                    distributorCell.setCellStyle(style);
                    Cell endCustNameCell = row.createCell(33);
                    endCustNameCell.setCellValue(brandAuthApplyPageRecords.get(i).getEndCustName());
                    endCustNameCell.setCellStyle(style);
                    Cell totalPurchaseLastYearCell = row.createCell(34);
                    totalPurchaseLastYearCell.setCellValue(brandAuthApplyPageRecords.get(i).getTotalPurchaseLastYear().stripTrailingZeros().toPlainString() + "万");
                    totalPurchaseLastYearCell.setCellStyle(style);
                    Cell authRequireCell = row.createCell(35);
                    authRequireCell.setCellValue(brandAuthApplyPageRecords.get(i).getAuthRequire());
                    authRequireCell.setCellStyle(style);
                    Cell demandRemarkCell = row.createCell(36);
                    demandRemarkCell.setCellValue(brandAuthApplyPageRecords.get(i).getDemandRemark());
                    demandRemarkCell.setCellStyle(style);
                }
                OutputStream outputStream = response.getOutputStream();
                workbook.write(outputStream);
                outputStream.flush();
            }catch (Exception e){
                e.printStackTrace();
                log.error("导出异常：" + e.getMessage());
            }
        }
    }

    @Override
    public BrandAuthApplyDetailVO detail(QueryIdDTO queryIdDTO) {
        BrandAuthApply brandAuthApply = this.getById(queryIdDTO.getId());
        if (brandAuthApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_BRAND_AUTH_APPLY);
        }
        BrandAuthApplyDetailVO brandAuthApplyDetailVO = new BrandAuthApplyDetailVO();
        brandAuthApplyDetailVO.setBrandAuthApply(brandAuthApply);
        List<BrandAuthApplyVO> brandAuthApplyVOList = new ArrayList<>();

        //上一年的数据
        BrandAuthApplyVO lastYearBrandAuthApplyVO = new BrandAuthApplyVO();
        lastYearBrandAuthApplyVO.setYear(brandAuthApply.getYear() - 1);
        //lastYearBrandAuthApplyVO.setPlanPurchase(brandAuthApplyMapper.sumAnnualIndicators(brandAuthApply.getYear() - 1, brandAuthApply.getCompany()));
        BrandAuthApply lastQnBrandAuthApply = brandAuthApplyMapper.selectQnPlanPurchase(brandAuthApply.getYear() - 1, brandAuthApply.getCompany());
        lastYearBrandAuthApplyVO.setPlanPurchase(lastQnBrandAuthApply == null ? null: lastQnBrandAuthApply.getYearAnnualIndicators());
        List<CustSaleVO> lastYearCustSaleVOS = brandAuthApplyMapper.selectCustSaleByLastYear(brandAuthApply.getYear() - 1, brandAuthApply.getCompany(), brandAuthApply.getSubCompany());
        if (CollectionUtils.isNotEmpty(lastYearCustSaleVOS)) {
            CustSaleVO custSaleVO = lastYearCustSaleVOS.get(0);
            lastYearBrandAuthApplyVO.setRealityPurchase(custSaleVO.getSndQnXsje());
            lastYearBrandAuthApplyVO.setFinishStatus(calculatePercentage(lastYearBrandAuthApplyVO.getRealityPurchase(), lastYearBrandAuthApplyVO.getPlanPurchase()));
            lastYearBrandAuthApplyVO.setAllBrandRealityPurchase(custSaleVO.getFxhzQnXsje());
        }
        lastYearBrandAuthApplyVO.setRejectReason(lastQnBrandAuthApply == null ? null: lastQnBrandAuthApply.getRejectReason());
        lastYearBrandAuthApplyVO.setGrantReason(lastQnBrandAuthApply == null ? null: lastQnBrandAuthApply.getGrantReason());
        brandAuthApplyVOList.add(lastYearBrandAuthApplyVO);

        //上一年的第四季度
        BrandAuthApply lastYearBrandAuthApply4 = brandAuthApplyMapper.selectByOne(brandAuthApply.getYear() - 1, "4", brandAuthApply.getCompany());
        BrandAuthApplyVO lastYearBrandAuthApplyVO4 = new BrandAuthApplyVO();
        if (lastYearBrandAuthApply4 != null){
            BeanUtil.copyProperties(lastYearBrandAuthApply4, lastYearBrandAuthApplyVO4);
            lastYearBrandAuthApplyVO4.setProtocolUrl(lastYearBrandAuthApply4.getProtocolUrl());
        }
        lastYearBrandAuthApplyVO4.setYear(brandAuthApply.getYear() - 1);
        lastYearBrandAuthApplyVO4.setAuthTime("4");
        BrandAuthApply currentBrandAuthApply = brandAuthApplyMapper.selectPlanPurchase(brandAuthApply.getYear() - 1, brandAuthApply.getCompany(), "4");
        lastYearBrandAuthApplyVO4.setPlanPurchase(currentBrandAuthApply == null ? BigDecimal.ZERO : currentBrandAuthApply.getPlanPurchase());
        if (CollectionUtils.isNotEmpty(lastYearCustSaleVOS)) {
            CustSaleVO custSaleVO = lastYearCustSaleVOS.get(0);
            lastYearBrandAuthApplyVO4.setRealityPurchase(custSaleVO.getSndS4Xsje());
            lastYearBrandAuthApplyVO4.setFinishStatus(calculatePercentage(lastYearBrandAuthApplyVO4.getRealityPurchase(), lastYearBrandAuthApplyVO4.getPlanPurchase()));
            lastYearBrandAuthApplyVO4.setAllBrandRealityPurchase(custSaleVO.getFxhzS4Xsje());
        }
        lastYearBrandAuthApplyVO4.setRejectReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getRejectReason());
        lastYearBrandAuthApplyVO4.setGrantReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getGrantReason());
        brandAuthApplyVOList.add(lastYearBrandAuthApplyVO4);

        //本年的总采购额
        BrandAuthApplyVO thisYearBrandAuthApplyVO = new BrandAuthApplyVO();
        thisYearBrandAuthApplyVO.setYear(brandAuthApply.getYear());
        //thisYearBrandAuthApplyVO.setPlanPurchase(brandAuthApplyMapper.sumAnnualIndicators(brandAuthApply.getYear(), brandAuthApply.getCompany()));
        BrandAuthApply qnBrandAuthApply = brandAuthApplyMapper.selectQnPlanPurchase(brandAuthApply.getYear(), brandAuthApply.getCompany());
        thisYearBrandAuthApplyVO.setPlanPurchase(qnBrandAuthApply == null ? null: qnBrandAuthApply.getYearAnnualIndicators());
        List<CustSaleVO> thisYearCustSaleVOS = brandAuthApplyMapper.selectCustSaleByYear(brandAuthApply.getYear(), brandAuthApply.getCompany(), brandAuthApply.getSubCompany());
        if (CollectionUtils.isNotEmpty(thisYearCustSaleVOS)) {
            CustSaleVO custSaleVO = thisYearCustSaleVOS.get(0);
            thisYearBrandAuthApplyVO.setRealityPurchase(custSaleVO.getSndQnXsje());
            thisYearBrandAuthApplyVO.setFinishStatus(calculatePercentage(thisYearBrandAuthApplyVO.getRealityPurchase(), thisYearBrandAuthApplyVO.getPlanPurchase()));
            thisYearBrandAuthApplyVO.setAllBrandRealityPurchase(custSaleVO.getFxhzQnXsje());
        }
        thisYearBrandAuthApplyVO.setRejectReason(qnBrandAuthApply == null ? null: qnBrandAuthApply.getRejectReason());
        thisYearBrandAuthApplyVO.setGrantReason(qnBrandAuthApply == null ? null: qnBrandAuthApply.getGrantReason());
        brandAuthApplyVOList.add(thisYearBrandAuthApplyVO);


        //今年 第一季度
        BrandAuthApplyVO thisYearBrandAuthApplyVO1 = new BrandAuthApplyVO();
        thisYearBrandAuthApplyVO1.setYear(brandAuthApply.getYear());
        thisYearBrandAuthApplyVO1.setAuthTime("1");
        currentBrandAuthApply = brandAuthApplyMapper.selectPlanPurchase(brandAuthApply.getYear(), brandAuthApply.getCompany(), "1");
        thisYearBrandAuthApplyVO1.setPlanPurchase(currentBrandAuthApply == null ? brandAuthApply.getOneIndicators() : currentBrandAuthApply.getPlanPurchase());
        thisYearBrandAuthApplyVO1.setState(currentBrandAuthApply == null ? null: currentBrandAuthApply.getState());
        if (CollectionUtils.isNotEmpty(thisYearCustSaleVOS)) {
            CustSaleVO custSaleVO = thisYearCustSaleVOS.get(0);
            thisYearBrandAuthApplyVO1.setRealityPurchase(custSaleVO.getSndS1Xsje());
            thisYearBrandAuthApplyVO1.setFinishStatus(calculatePercentage(thisYearBrandAuthApplyVO1.getRealityPurchase(), thisYearBrandAuthApplyVO1.getPlanPurchase()));
            thisYearBrandAuthApplyVO1.setAllBrandRealityPurchase(custSaleVO.getFxhzS1Xsje());
            thisYearBrandAuthApplyVO1.setProtocolUrl(currentBrandAuthApply == null ? "" : currentBrandAuthApply.getProtocolUrl());
        }
        thisYearBrandAuthApplyVO1.setRejectReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getRejectReason());
        thisYearBrandAuthApplyVO1.setGrantReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getGrantReason());
        brandAuthApplyVOList.add(thisYearBrandAuthApplyVO1);

        if (StringUtils.equals(brandAuthApply.getAuthTime(), "2")){
            //第二季度
            BrandAuthApplyVO thisYearBrandAuthApplyVO2 = new BrandAuthApplyVO();
            thisYearBrandAuthApplyVO2.setYear(brandAuthApply.getYear());
            thisYearBrandAuthApplyVO2.setAuthTime("2");
            currentBrandAuthApply = brandAuthApplyMapper.selectPlanPurchase(brandAuthApply.getYear(), brandAuthApply.getCompany(), "2");
            thisYearBrandAuthApplyVO2.setPlanPurchase(currentBrandAuthApply == null ? brandAuthApply.getTwoIndicators() : currentBrandAuthApply.getPlanPurchase());
            thisYearBrandAuthApplyVO2.setState(currentBrandAuthApply == null ? null: currentBrandAuthApply.getState());
            thisYearBrandAuthApplyVO2.setProtocolUrl(currentBrandAuthApply == null ? "" : currentBrandAuthApply.getProtocolUrl());
            if (CollectionUtils.isNotEmpty(thisYearCustSaleVOS)) {
                CustSaleVO custSaleVO = thisYearCustSaleVOS.get(0);
                thisYearBrandAuthApplyVO2.setRealityPurchase(custSaleVO.getSndS2Xsje());
                thisYearBrandAuthApplyVO2.setFinishStatus(calculatePercentage(thisYearBrandAuthApplyVO2.getRealityPurchase(), thisYearBrandAuthApplyVO2.getPlanPurchase()));
                thisYearBrandAuthApplyVO2.setAllBrandRealityPurchase(custSaleVO.getFxhzS2Xsje());
            }
            thisYearBrandAuthApplyVO2.setRejectReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getRejectReason());
            thisYearBrandAuthApplyVO2.setGrantReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getGrantReason());
            brandAuthApplyVOList.add(thisYearBrandAuthApplyVO2);

        }else if (StringUtils.equals(brandAuthApply.getAuthTime(), "3")){
            //第二季度
            BrandAuthApplyVO thisYearBrandAuthApplyVO2 = new BrandAuthApplyVO();
            thisYearBrandAuthApplyVO2.setYear(brandAuthApply.getYear());
            thisYearBrandAuthApplyVO2.setAuthTime("2");
            currentBrandAuthApply = brandAuthApplyMapper.selectPlanPurchase(brandAuthApply.getYear(), brandAuthApply.getCompany(), "2");
            thisYearBrandAuthApplyVO2.setPlanPurchase(currentBrandAuthApply == null ? brandAuthApply.getTwoIndicators() : currentBrandAuthApply.getPlanPurchase());
            thisYearBrandAuthApplyVO2.setState(currentBrandAuthApply == null ? null: currentBrandAuthApply.getState());
            thisYearBrandAuthApplyVO2.setProtocolUrl(currentBrandAuthApply == null ? "" : currentBrandAuthApply.getProtocolUrl());
            if (CollectionUtils.isNotEmpty(thisYearCustSaleVOS)) {
                CustSaleVO custSaleVO = thisYearCustSaleVOS.get(0);
                thisYearBrandAuthApplyVO2.setRealityPurchase(custSaleVO.getSndS2Xsje());
                thisYearBrandAuthApplyVO2.setFinishStatus(calculatePercentage(thisYearBrandAuthApplyVO2.getRealityPurchase(), thisYearBrandAuthApplyVO2.getPlanPurchase()));
                thisYearBrandAuthApplyVO2.setAllBrandRealityPurchase(custSaleVO.getFxhzS2Xsje());
            }
            thisYearBrandAuthApplyVO2.setRejectReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getRejectReason());
            thisYearBrandAuthApplyVO2.setGrantReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getGrantReason());
            brandAuthApplyVOList.add(thisYearBrandAuthApplyVO2);

            //第三季度
            BrandAuthApplyVO thisYearBrandAuthApplyVO3 = new BrandAuthApplyVO();
            thisYearBrandAuthApplyVO3.setYear(brandAuthApply.getYear());
            thisYearBrandAuthApplyVO3.setAuthTime("3");
            currentBrandAuthApply = brandAuthApplyMapper.selectPlanPurchase(brandAuthApply.getYear(), brandAuthApply.getCompany(), "3");
            thisYearBrandAuthApplyVO3.setPlanPurchase(currentBrandAuthApply == null ? brandAuthApply.getThreeIndicators() : currentBrandAuthApply.getPlanPurchase());
            thisYearBrandAuthApplyVO3.setState(currentBrandAuthApply == null ? null: currentBrandAuthApply.getState());
            thisYearBrandAuthApplyVO3.setProtocolUrl(currentBrandAuthApply == null ? "" : currentBrandAuthApply.getProtocolUrl());
            if (CollectionUtils.isNotEmpty(thisYearCustSaleVOS)) {
                CustSaleVO custSaleVO = thisYearCustSaleVOS.get(0);
                thisYearBrandAuthApplyVO3.setRealityPurchase(custSaleVO.getSndS3Xsje());
                thisYearBrandAuthApplyVO3.setFinishStatus(calculatePercentage(thisYearBrandAuthApplyVO3.getRealityPurchase(), thisYearBrandAuthApplyVO3.getPlanPurchase()));
                thisYearBrandAuthApplyVO3.setAllBrandRealityPurchase(custSaleVO.getFxhzS3Xsje());
            }
            thisYearBrandAuthApplyVO3.setRejectReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getRejectReason());
            thisYearBrandAuthApplyVO3.setGrantReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getGrantReason());
            brandAuthApplyVOList.add(thisYearBrandAuthApplyVO3);

        }else if (StringUtils.equals(brandAuthApply.getAuthTime(), "4")){
            //第二季度
            BrandAuthApplyVO thisYearBrandAuthApplyVO2 = new BrandAuthApplyVO();
            thisYearBrandAuthApplyVO2.setYear(brandAuthApply.getYear());
            thisYearBrandAuthApplyVO2.setAuthTime("2");
            currentBrandAuthApply = brandAuthApplyMapper.selectPlanPurchase(brandAuthApply.getYear(), brandAuthApply.getCompany(), "2");
            thisYearBrandAuthApplyVO2.setPlanPurchase(currentBrandAuthApply == null ? brandAuthApply.getTwoIndicators() : currentBrandAuthApply.getPlanPurchase());
            thisYearBrandAuthApplyVO2.setState(currentBrandAuthApply == null ? null: currentBrandAuthApply.getState());
            thisYearBrandAuthApplyVO2.setProtocolUrl(currentBrandAuthApply == null ? "" : currentBrandAuthApply.getProtocolUrl());
            if (CollectionUtils.isNotEmpty(thisYearCustSaleVOS)) {
                CustSaleVO custSaleVO = thisYearCustSaleVOS.get(0);
                thisYearBrandAuthApplyVO2.setRealityPurchase(custSaleVO.getSndS2Xsje());
                thisYearBrandAuthApplyVO2.setFinishStatus(calculatePercentage(thisYearBrandAuthApplyVO2.getRealityPurchase(), thisYearBrandAuthApplyVO2.getPlanPurchase()));
                thisYearBrandAuthApplyVO2.setAllBrandRealityPurchase(custSaleVO.getFxhzS2Xsje());
            }
            thisYearBrandAuthApplyVO2.setRejectReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getRejectReason());
            thisYearBrandAuthApplyVO2.setGrantReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getGrantReason());
            brandAuthApplyVOList.add(thisYearBrandAuthApplyVO2);

            //第三季度
            BrandAuthApplyVO thisYearBrandAuthApplyVO3 = new BrandAuthApplyVO();
            thisYearBrandAuthApplyVO3.setYear(brandAuthApply.getYear());
            thisYearBrandAuthApplyVO3.setAuthTime("3");
            currentBrandAuthApply = brandAuthApplyMapper.selectPlanPurchase(brandAuthApply.getYear(), brandAuthApply.getCompany(), "3");
            thisYearBrandAuthApplyVO3.setPlanPurchase(currentBrandAuthApply == null ? brandAuthApply.getThreeIndicators() : currentBrandAuthApply.getPlanPurchase());
            thisYearBrandAuthApplyVO3.setState(currentBrandAuthApply == null ? null: currentBrandAuthApply.getState());
            thisYearBrandAuthApplyVO3.setProtocolUrl(currentBrandAuthApply == null ? "" : currentBrandAuthApply.getProtocolUrl());
            if (CollectionUtils.isNotEmpty(thisYearCustSaleVOS)) {
                CustSaleVO custSaleVO = thisYearCustSaleVOS.get(0);
                thisYearBrandAuthApplyVO3.setRealityPurchase(custSaleVO.getSndS3Xsje());
                thisYearBrandAuthApplyVO3.setFinishStatus(calculatePercentage(thisYearBrandAuthApplyVO3.getRealityPurchase(), thisYearBrandAuthApplyVO3.getPlanPurchase()));
                thisYearBrandAuthApplyVO3.setAllBrandRealityPurchase(custSaleVO.getFxhzS3Xsje());
            }
            thisYearBrandAuthApplyVO3.setRejectReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getRejectReason());
            thisYearBrandAuthApplyVO3.setGrantReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getGrantReason());
            brandAuthApplyVOList.add(thisYearBrandAuthApplyVO3);

            //第四季度
            BrandAuthApplyVO thisYearBrandAuthApplyVO4 = new BrandAuthApplyVO();
            thisYearBrandAuthApplyVO4.setYear(brandAuthApply.getYear());
            thisYearBrandAuthApplyVO4.setAuthTime("4");
            currentBrandAuthApply = brandAuthApplyMapper.selectPlanPurchase(brandAuthApply.getYear(), brandAuthApply.getCompany(), "4");
            thisYearBrandAuthApplyVO4.setPlanPurchase(currentBrandAuthApply == null ? brandAuthApply.getFourIndicators() : currentBrandAuthApply.getPlanPurchase());
            thisYearBrandAuthApplyVO4.setState(currentBrandAuthApply == null ? null: currentBrandAuthApply.getState());
            thisYearBrandAuthApplyVO4.setProtocolUrl(currentBrandAuthApply == null ? "" : currentBrandAuthApply.getProtocolUrl());
            if (CollectionUtils.isNotEmpty(thisYearCustSaleVOS)) {
                CustSaleVO custSaleVO = thisYearCustSaleVOS.get(0);
                thisYearBrandAuthApplyVO4.setRealityPurchase(custSaleVO.getSndS4Xsje());
                thisYearBrandAuthApplyVO4.setFinishStatus(calculatePercentage(thisYearBrandAuthApplyVO4.getRealityPurchase(), thisYearBrandAuthApplyVO4.getPlanPurchase()));
                thisYearBrandAuthApplyVO4.setAllBrandRealityPurchase(custSaleVO.getFxhzS4Xsje());
            }
            thisYearBrandAuthApplyVO4.setRejectReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getRejectReason());
            thisYearBrandAuthApplyVO4.setGrantReason(currentBrandAuthApply == null ? null: currentBrandAuthApply.getGrantReason());
            brandAuthApplyVOList.add(thisYearBrandAuthApplyVO4);
        }

        brandAuthApplyDetailVO.setBrandAuthApplyVOList(brandAuthApplyVOList);
        return brandAuthApplyDetailVO;
    }


    @Override
    public Boolean approve(BrandAuthApplyApproveDTO brandAuthApplyApproveDTO) {
        if (StringUtils.equals(brandAuthApplyApproveDTO.getState(), "3")){
            if (StringUtils.isEmpty(brandAuthApplyApproveDTO.getRejectReason())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_REJECT_REASON);
            }
        }
        BrandAuthApply brandAuthApply = this.getById(brandAuthApplyApproveDTO.getId());
        if (brandAuthApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_BRAND_AUTH_APPLY);
        }
        QueryWrapper<BrandAuthApply> associateApplyQueryWrapper2 = new QueryWrapper<>();
        associateApplyQueryWrapper2.eq("company", brandAuthApply.getCompany())
                .eq("year", brandAuthApply.getYear());
        List<BrandAuthApply> brandAuthApplyList = this.list(associateApplyQueryWrapper2);
        String protocolUrl = null;
        if (CollectionUtil.isNotEmpty(brandAuthApplyList)){
            for (BrandAuthApply b : brandAuthApplyList) {
                if (StringUtils.isNotEmpty(b.getProtocolUrl())){
                    protocolUrl = b.getProtocolUrl();
                }
            }
        }
        LocalDateTime now = LocalDateTime.now();
        String urlPath = null;
        boolean isSend = false;
        if (StringUtils.equals(brandAuthApplyApproveDTO.getState(), "2")){
            //同意授权

            if (StringUtils.isEmpty(protocolUrl)){
                //生成协议
                isSend = true;
                try {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    PDDocument document = PDDocument.load(new File(brandAuthProtocol));
//                    PDDocument document = PDDocument.load(new File("D:\\Users\\User\\Desktop\\brandAuthProtocol.pdf"));
                    //定义字体
                    PDFont font = PDType0Font.load(document, new File(fontPath));
//                    PDFont font = PDType0Font.load(document, new File("C:\\Windows\\Fonts\\simhei.ttf"));

//                    PDPage page0 = document.getPage(0); // 获取第一页
//                    // 创建一个用于添加内容的内容流
//                    PDPageContentStream contentStream = new PDPageContentStream(document, page0, PDPageContentStream.AppendMode.APPEND, true, true);
//                    // 设置字体和字体大小
//                    contentStream.setFont(font, 12);
//                    // x, y 坐标表示填写文本的位置，这里填写在页面的左上角
//                    // 定义一个列表来保存要填充的文本位置及内容
//                    List<TextPosition> textPositions = new ArrayList<>();
//                    //甲方 联系信息
//                    SubCompanyVO subCompanyVO = brandAuthApplyMapper.selectAddressBySubCompany(brandAuthApply.getSubCompany());
//                    String subCompany1 = brandAuthApply.getSubCompany();
//                    if (StringUtils.isNotEmpty(subCompany1) && subCompany1.length() > 12){
//                        textPositions.add(new TextPosition(120, 680, subCompany1.substring(0, 12)));
//                        textPositions.add(new TextPosition(120, 664, subCompany1.substring(12, subCompany1.length())));
//                    }else {
//                        textPositions.add(new TextPosition(120, 672, subCompany1));
//                    }
//
//                    String address1 = subCompanyVO.getAddress();
//                    if (StringUtils.isNotEmpty(address1) && address1.length() > 12){
//                        textPositions.add(new TextPosition(120, 585, address1.substring(0, 12)));
//                        textPositions.add(new TextPosition(120, 570, address1.substring(12, address1.length())));
//                    }else {
//                        textPositions.add(new TextPosition(120, 578, address1));
//                    }
//
//                    textPositions.add(new TextPosition(140, 483, DateUtil.format(now, "yyyy-MM-dd")));
//                    //乙方 联系信息
//                    String subCompany2 = brandAuthApply.getCompany();
//                    if (StringUtils.isNotEmpty(subCompany2) && subCompany2.length() > 12){
//                        textPositions.add(new TextPosition(340, 680, subCompany2.substring(0, 12)));
//                        textPositions.add(new TextPosition(340, 664, subCompany2.substring(12, subCompany2.length())));
//                    }else {
//                        textPositions.add(new TextPosition(340, 672, subCompany2));
//                    }
//                    String address2 = brandAuthApply.getProvince() + brandAuthApply.getCity() + brandAuthApply.getArea() + brandAuthApply.getAddress();
//                    if (StringUtils.isNotEmpty(address2) && address2.length() > 12){
//                        textPositions.add(new TextPosition(340, 585, address2.substring(0, 12)));
//                        textPositions.add(new TextPosition(340, 570, address2.substring(12, address2.length())));
//                    }else {
//                        textPositions.add(new TextPosition(340, 578, address2));
//                    }
//                    textPositions.add(new TextPosition(360, 484, DateUtil.format(now, "yyyy-MM-dd")));
//                    //甲方 开户资料
//                    String bankComName1 = subCompanyVO.getBankComName();
//                    if (StringUtils.isNotEmpty(bankComName1) && bankComName1.length() > 12){
//                        textPositions.add(new TextPosition(140, 400, bankComName1.substring(0, 12)));
//                        textPositions.add(new TextPosition(140, 384, bankComName1.substring(12, bankComName1.length())));
//                    }else {
//                        textPositions.add(new TextPosition(140, 392, bankComName1));
//                    }
//                    textPositions.add(new TextPosition(140, 345, subCompanyVO.getBankAccount()));
//                    String bankName1 = subCompanyVO.getBankName();
//                    if (StringUtils.isNotEmpty(bankName1) && bankName1.length() > 12){
//                        textPositions.add(new TextPosition(130, 306, bankName1.substring(0, 12)));
//                        textPositions.add(new TextPosition(130, 290, bankName1.substring(12, bankName1.length())));
//                    }else {
//                        textPositions.add(new TextPosition(130, 298, bankName1));
//                    }
//                    textPositions.add(new TextPosition(160, 252, subCompanyVO.getTaxNumber()));
//                    //乙方 开户资料
//                    String bankComName2 = brandAuthApply.getAccountName();
//                    if (StringUtils.isNotEmpty(bankComName2) && bankComName2.length() > 12){
//                        textPositions.add(new TextPosition(355, 400, bankComName2.substring(0, 12)));
//                        textPositions.add(new TextPosition(355, 384, bankComName2.substring(12, bankComName2.length())));
//                    }else {
//                        textPositions.add(new TextPosition(355, 392, bankComName2));
//                    }
//                    textPositions.add(new TextPosition(355, 345, brandAuthApply.getBankAccountNum()));
//                    String bankName2 = brandAuthApply.getOpeningBank();
//                    if (StringUtils.isNotEmpty(bankName2) && bankName2.length() > 12){
//                        textPositions.add(new TextPosition(350, 306, bankName2.substring(0, 12)));
//                        textPositions.add(new TextPosition(350, 290, bankName2.substring(12, bankName2.length())));
//                    }else {
//                        textPositions.add(new TextPosition(350, 298, bankName2));
//                    }
//                    textPositions.add(new TextPosition(375, 252, brandAuthApply.getTaxIdentification()));
//                    // 遍历文本位置列表，并在每个位置填写文本
//                    for (TextPosition position : textPositions) {
//                        contentStream.beginText();
//                        contentStream.newLineAtOffset(position.getX(), position.getY());
//                        contentStream.showText(position.getText());
//                        contentStream.endText();
//                    }
//                    contentStream.close(); // 关闭内容流

//                    PDPage page1 = document.getPage(1); // 获取第一页
//                    // 创建一个用于添加内容的内容流
//                    PDPageContentStream contentStream1 = new PDPageContentStream(document, page1, PDPageContentStream.AppendMode.APPEND, true, true);
//                    // 设置字体和字体大小
//                    contentStream1.setFont(font, 12);
//                    // x, y 坐标表示填写文本的位置，这里填写在页面的左上角
//                    // 定义一个列表来保存要填充的文本位置及内容
//                    List<TextPosition> textPositions1 = new ArrayList<>();
//                    textPositions1.add(new TextPosition(380, 479, brandAuthApply.getYearAnnualIndicators().stripTrailingZeros().toPlainString()));
//                    textPositions1.add(new TextPosition(240, 432, String.valueOf(brandAuthApply.getAfterSignDay())));
//                    textPositions1.add(new TextPosition(230, 415, brandAuthApply.getFirstPurchaseAmount().stripTrailingZeros().toPlainString()));
//
//                    textPositions1.add(new TextPosition(180, 288, brandAuthApply.getYearAnnualIndicators().stripTrailingZeros().toPlainString()));
//                    textPositions1.add(new TextPosition(250, 288, brandAuthApply.getOneIndicators().stripTrailingZeros().toPlainString()));
//                    textPositions1.add(new TextPosition(320, 288, brandAuthApply.getTwoIndicators().stripTrailingZeros().toPlainString()));
//                    textPositions1.add(new TextPosition(390, 288, brandAuthApply.getThreeIndicators().stripTrailingZeros().toPlainString()));
//                    textPositions1.add(new TextPosition(460, 288, brandAuthApply.getFourIndicators().stripTrailingZeros().toPlainString()));
//                    // 遍历文本位置列表，并在每个位置填写文本
//                    for (TextPosition position : textPositions1) {
//                        contentStream1.beginText();
//                        contentStream1.newLineAtOffset(position.getX(), position.getY());
//                        contentStream1.showText(position.getText());
//                        contentStream1.endText();
//                    }
//                    contentStream1.close();

                    PDPage page1 = document.getPage(1); // 获取第一页
                    PDPageContentStream contentStream1 = new PDPageContentStream(document, page1, PDPageContentStream.AppendMode.APPEND, true, true);
                    contentStream1.setFont(font, 12);
                    TextPosition textPosition = new TextPosition(360, 78, brandAuthApply.getYearAnnualIndicators().stripTrailingZeros().toPlainString());
                    contentStream1.beginText();
                    contentStream1.newLineAtOffset(textPosition.getX(), textPosition.getY());
                    contentStream1.showText(textPosition.getText());
                    contentStream1.endText();
                    contentStream1.close(); // 关闭内容流

                    PDPage page2 = document.getPage(2); // 获取第一页
                    // 创建一个用于添加内容的内容流
                    PDPageContentStream contentStream2 = new PDPageContentStream(document, page2, PDPageContentStream.AppendMode.APPEND, true, true);
                    // 设置字体和字体大小
                    contentStream2.setFont(font, 12);
                    // x, y 坐标表示填写文本的位置，这里填写在页面的左上角
                    // 定义一个列表来保存要填充的文本位置及内容
                    List<TextPosition> textPositions = new ArrayList<>();
                    //甲方 联系信息
                    textPositions.add(new TextPosition(185, 655, brandAuthApply.getYearAnnualIndicators().stripTrailingZeros().toPlainString()));
                    textPositions.add(new TextPosition(255, 655, brandAuthApply.getOneIndicators().stripTrailingZeros().toPlainString()));
                    textPositions.add(new TextPosition(325, 655, brandAuthApply.getTwoIndicators().stripTrailingZeros().toPlainString()));
                    textPositions.add(new TextPosition(395, 655, brandAuthApply.getThreeIndicators().stripTrailingZeros().toPlainString()));
                    textPositions.add(new TextPosition(465, 655, brandAuthApply.getFourIndicators().stripTrailingZeros().toPlainString()));

                    BigDecimal result = brandAuthApply.getYearAnnualIndicators().multiply(new BigDecimal("0.2")).setScale(2, RoundingMode.HALF_UP);
                    textPositions.add(new TextPosition(430, 622, result.stripTrailingZeros().toPlainString()));
                    // 遍历文本位置列表，并在每个位置填写文本
                    for (TextPosition position : textPositions) {
                        contentStream2.beginText();
                        contentStream2.newLineAtOffset(position.getX(), position.getY());
                        contentStream2.showText(position.getText());
                        contentStream2.endText();
                    }
                    contentStream2.close(); // 关闭内容流

                    document.save(byteArrayOutputStream);
                    ByteArrayInputStream byteArrayInput = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                    urlPath = "purchase/brandAuthApply/" +
                            brandAuthApply.getOpenId() + "/" + brandAuthApply.getYear() + "/" +"众业达品牌授权合作补充协议（施耐德）.pdf";
                    //同步到oss
                    OSS ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
                    ossClient.putObject(new PutObjectRequest(ossConfig.getBucketName(), urlPath, byteArrayInput));
                    //https://zyd-online-test-20211122.oss-cn-shenzhen.aliyuncs.com/purchase/brandAuthApply/ogUDz5SH9U83NiH3SfDWxyEX9C1o/2024/%E4%BC%97%E4%B8%9A%E8%BE%BE%E5%93%81%E7%89%8C%E6%8E%88%E6%9D%83%E5%90%88%E4%BD%9C%E8%A1%A5%E5%85%85%E5%8D%8F%E8%AE%AE%EF%BC%88%E6%96%BD%E8%80%90%E5%BE%B7%EF%BC%89.pdf
                    protocolUrl = ossConfig.getOssUrl() + urlPath;
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else {
                urlPath = protocolUrl.replace(ossConfig.getOssUrl(), "");
            }
        }

        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        UpdateWrapper<BrandAuthApply> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("state", brandAuthApplyApproveDTO.getState())
                .set(StringUtils.isNotEmpty(brandAuthApplyApproveDTO.getRejectReason()), "reject_reason", brandAuthApplyApproveDTO.getRejectReason())
                .set("protocol_url", protocolUrl)
                .set("updated_at", now)
                .set("updated_by", code)
                .eq("id", brandAuthApplyApproveDTO.getId());
        boolean result = this.update(updateWrapper);
        if(result){
            if (StringUtils.equals(brandAuthApplyApproveDTO.getState(), "2") && isSend){
                //同意，并且是首签
                //查询项目推广专员
                QueryWrapper<AssociatePromotion> associatePromotionQueryWrapper = new QueryWrapper<>();
                associatePromotionQueryWrapper.eq("company_name", brandAuthApply.getSubCompany());
                List<AssociatePromotion> associatePromotions = associatePromotionMapper.selectList(associatePromotionQueryWrapper);
                if (CollectionUtil.isEmpty(associatePromotions)){
                    throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PROMOTION);
                }
                //通知
                TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
                triggerMsgRequest.setBusiness("brandAuth");
                triggerMsgRequest.setScene("brandAuthProtocolPass");
                JSONObject qywxParam = new JSONObject();
                qywxParam.put("msgtype", "template_card");
                qywxParam.put("noticeUser", associatePromotions.get(0).getCode());

                JSONObject templateCard = new JSONObject();
                templateCard.put("card_type", "text_notice");

                JSONObject mainTitle = new JSONObject();
                mainTitle.put("title", "品牌授权审批通过");
                mainTitle.put("desc", "");
                templateCard.put("main_title", mainTitle);

                List<JSONObject> horizontalContentList = new ArrayList<>();
                JSONObject keyName1 = new JSONObject();
                keyName1.put("keyname", "客户");
                keyName1.put("value", brandAuthApply.getCompany());
                horizontalContentList.add(keyName1);
                JSONObject keyName2 = new JSONObject();
                keyName2.put("keyname", "联系人");
                keyName2.put("value", brandAuthApply.getLinkman());
                horizontalContentList.add(keyName2);
                JSONObject keyName3 = new JSONObject();
                keyName3.put("keyname", "审批时间");
                keyName3.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
                horizontalContentList.add(keyName3);
                JSONObject keyName4 = new JSONObject();
                keyName4.put("keyname", "备注");
                keyName4.put("value", "品牌授权审批通过，赶快跟进盖章签约《众业达品牌授权合作补充协议》和《施耐德品牌授权承诺函》吧。");
                horizontalContentList.add(keyName4);
                templateCard.put("horizontal_content_list", horizontalContentList);

                List<JSONObject> jumpList = new ArrayList<>();
                JSONObject jumpList1 = new JSONObject();
                jumpList1.put("type", 1);
                jumpList1.put("title", "跳转惠采");
                jumpList1.put("url", odsUrl + "/#/purchase-sign/brand-authorize?key=" + URLUtil.encode(brandAuthApply.getCompany()));
                jumpList.add(jumpList1);
                templateCard.put("jump_list", jumpList);

                JSONObject cardAction = new JSONObject();
                cardAction.put("type", 1);
                cardAction.put("url",  odsUrl + "/#/purchase-sign/brand-authorize?key=" + URLUtil.encode(brandAuthApply.getCompany()));
                templateCard.put("card_action", cardAction);
                qywxParam.put("template_card", templateCard);
                triggerMsgRequest.setQywxParam(qywxParam);
                msgClient.triggerMsg(triggerMsgRequest);

                String token = tokenUtils.getQyWXTokenBy1();
                //发送文件1
                OSS ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
                OSSObject object = ossClient.getObject(ossConfig.getBucketName(), urlPath);
                InputStream inputStream = object.getObjectContent();

                Forest.post("https://qyapi.weixin.qq.com/cgi-bin/media/upload").addQuery("access_token", token).addQuery("type", "file")
                        // 指定请求体为Multipart格式
                        .contentTypeMultipartFormData()
                        // 添加InputStream对象
                        .addFile("file", inputStream, brandAuthApply.getCompany()+ "众业达品牌授权合作补充协议（施耐德）.pdf")
                        .onSuccess(((data, req, res) -> {
                            JSONObject jsonObject = JSON.parseObject(data.toString());
                            if(!jsonObject.containsKey("media_id")){
                                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.FORWARDING_ORDER_GENERATION_FAILED);
                            }

                            TriggerMsgRequest triggerMsgRequest1 = new TriggerMsgRequest();
                            triggerMsgRequest1.setBusiness("brandAuth");
                            triggerMsgRequest1.setScene("brandAuthProtocolPass");
                            JSONObject qywxParam1 = new JSONObject();
                            qywxParam1.put("msgtype", "file");
                            qywxParam1.put("noticeUser", associatePromotions.get(0).getCode());

                            qywxParam1.put("mediaId", jsonObject.getString("media_id"));
                            triggerMsgRequest1.setQywxParam(qywxParam1);
                            msgClient.triggerMsg(triggerMsgRequest1);
                        }))
                        // onError回调函数: 请求失败时被调用
                        .onError(((ex, req, res) -> {
                            log.info("企业微信上传临时素材异常" + ex.getMessage());
                            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_SMS_TYPE);
                        }))
                        // 执行请求，请求成功则执行onSuccess, 失败则执行onError
                        .execute();

                //发送文件2
                object = ossClient.getObject(ossConfig.getBucketName(), brandAuthPath);
                inputStream = object.getObjectContent();
                Forest.post("https://qyapi.weixin.qq.com/cgi-bin/media/upload").addQuery("access_token", token).addQuery("type", "file")
                        // 指定请求体为Multipart格式
                        .contentTypeMultipartFormData()
                        // 添加InputStream对象
                        .addFile("file", inputStream, "施耐德品牌授权承诺函.pdf")
                        .onSuccess(((data, req, res) -> {
                            JSONObject jsonObject = JSON.parseObject(data.toString());
                            if(!jsonObject.containsKey("media_id")){
                                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.FORWARDING_ORDER_GENERATION_FAILED);
                            }

                            TriggerMsgRequest triggerMsgRequest1 = new TriggerMsgRequest();
                            triggerMsgRequest1.setBusiness("brandAuth");
                            triggerMsgRequest1.setScene("brandAuthProtocolPass");
                            JSONObject qywxParam1 = new JSONObject();
                            qywxParam1.put("msgtype", "file");
                            qywxParam1.put("noticeUser", associatePromotions.get(0).getCode());

                            qywxParam1.put("mediaId", jsonObject.getString("media_id"));
                            triggerMsgRequest1.setQywxParam(qywxParam1);
                            msgClient.triggerMsg(triggerMsgRequest1);
                        }))
                        // onError回调函数: 请求失败时被调用
                        .onError(((ex, req, res) -> {
                            log.info("企业微信上传临时素材异常" + ex.getMessage());
                            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_SMS_TYPE);
                        }))
                        // 执行请求，请求成功则执行onSuccess, 失败则执行onError
                        .execute();
            }else {
                //3：拒绝授权，增加快照
                BrandAuthApply brandAuthApply1 = this.getById(brandAuthApplyApproveDTO.getId());
                BrandAuthApplySnapshot brandAuthApplySnapshot = BeanUtil.copyProperties(brandAuthApply1, BrandAuthApplySnapshot.class, "id", "created_at", "created_by", "updated_at", "updated_by");
                brandAuthApplySnapshot.setCreatedAt(now);
                brandAuthApplySnapshot.setCreatedBy(name);
                brandAuthApplySnapshotMapper.insert(brandAuthApplySnapshot);
            }
        }
        return result;
    }

//    public static void main(String[] args) {
//        try {
////                    PDDocument document = PDDocument.load(new File(brandAuthProtocol));
//            PDDocument document = PDDocument.load(new File("D:\\Users\\User\\Desktop\\brandAuthProtocol.pdf"));
//            //定义字体
////                    PDFont font = PDType0Font.load(document, new File(fontPath));
//            PDFont font = PDType0Font.load(document, new File("C:\\Windows\\Fonts\\SIMFANG.TTF"));
//            PDFontDescriptor descriptor = font.getFontDescriptor();
//            descriptor.setFontWeight(1500);
//            ((PDType0Font) font).getFontDescriptor().getCOSObject().addAll(descriptor.getCOSObject());
//
//            PDPage page0 = document.getPage(0); // 获取第一页
//            // 创建一个用于添加内容的内容流
//            PDPageContentStream contentStream = new PDPageContentStream(document, page0, PDPageContentStream.AppendMode.APPEND, true, true);
//            // 设置字体和字体大小
//            contentStream.setFont(font, 12);
//            // x, y 坐标表示填写文本的位置，这里填写在页面的左上角
//            // 定义一个列表来保存要填充的文本位置及内容
//            List<TextPosition> textPositions = new ArrayList<>();
//            //甲方 联系信息
//            textPositions.add(new TextPosition(120, 672, "上海众业达电器有限公司"));
//            textPositions.add(new TextPosition(120, 585, "石家庄市众业达电气自动化"));
//            textPositions.add(new TextPosition(120, 570, "有限公司11"));
//            textPositions.add(new TextPosition(140, 483, DateUtil.format(LocalDateTime.now(), "yyyy-MM-dd")));
//            // 遍历文本位置列表，并在每个位置填写文本
//            for (TextPosition position : textPositions) {
//                contentStream.beginText();
//                contentStream.newLineAtOffset(position.getX(), position.getY());
//                contentStream.showText(position.getText());
//                contentStream.endText();
//            }
//            contentStream.close(); // 关闭内容流
//
//            document.save("D:\\Users\\User\\Desktop\\众业达品牌授权合作补充协议（施耐德）.pdf");
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    @Override
    public Boolean grant(BrandAuthApplyGrantFileDTO brandAuthApplyGrantFileDTO) {
        if (StringUtils.equals(brandAuthApplyGrantFileDTO.getState(), "6")){
            if (StringUtils.isEmpty(brandAuthApplyGrantFileDTO.getGrantReason())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_REJECT_REASON);
            }
        }
        BrandAuthApply brandAuthApply = this.getById(brandAuthApplyGrantFileDTO.getId());
        if (brandAuthApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_BRAND_AUTH_APPLY);
        }
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        LocalDateTime now = LocalDateTime.now();
        UpdateWrapper<BrandAuthApply> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("state", brandAuthApplyGrantFileDTO.getState())
                .set(StringUtils.isNotEmpty(brandAuthApplyGrantFileDTO.getGrantReason()), "grant_reason", brandAuthApplyGrantFileDTO.getGrantReason())
                .set("updated_at", now)
                .set("updated_by", code)
                .eq("id", brandAuthApplyGrantFileDTO.getId());
        boolean result = this.update(updateWrapper);
        if(result){
            if (StringUtils.equals(brandAuthApplyGrantFileDTO.getState(), "5")){
                //查询项目推广专员
                QueryWrapper<AssociatePromotion> associatePromotionQueryWrapper = new QueryWrapper<>();
                associatePromotionQueryWrapper.eq("company_name", brandAuthApply.getSubCompany());
                List<AssociatePromotion> associatePromotions = associatePromotionMapper.selectList(associatePromotionQueryWrapper);
                if (CollectionUtil.isEmpty(associatePromotions)){
                    throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PROMOTION);
                }
                //通知
                TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
                triggerMsgRequest.setBusiness("brandAuth");
                triggerMsgRequest.setScene("brandAuthProtocolGrant");
                JSONObject qywxParam = new JSONObject();
                qywxParam.put("msgtype", "template_card");
                qywxParam.put("noticeUser", associatePromotions.get(0).getCode());

                JSONObject templateCard = new JSONObject();
                templateCard.put("card_type", "text_notice");

                JSONObject mainTitle = new JSONObject();
                mainTitle.put("title", "品牌授权已发放");
                mainTitle.put("desc", "");
                templateCard.put("main_title", mainTitle);

                List<JSONObject> horizontalContentList = new ArrayList<>();
                JSONObject keyName1 = new JSONObject();
                keyName1.put("keyname", "客户");
                keyName1.put("value", brandAuthApply.getCompany());
                horizontalContentList.add(keyName1);
                JSONObject keyName2 = new JSONObject();
                keyName2.put("keyname", "联系人");
                keyName2.put("value", brandAuthApply.getLinkman());
                horizontalContentList.add(keyName2);
                JSONObject keyName3 = new JSONObject();
                keyName3.put("keyname", "发放时间");
                keyName3.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
                horizontalContentList.add(keyName3);
                JSONObject keyName4 = new JSONObject();
                keyName4.put("keyname", "备注");
                keyName4.put("value", "品牌方已发放品牌授权，赶快通知客户前往查看并下载吧。");
                horizontalContentList.add(keyName4);
                templateCard.put("horizontal_content_list", horizontalContentList);

                List<JSONObject> jumpList = new ArrayList<>();
                JSONObject jumpList1 = new JSONObject();
                jumpList1.put("type", 1);
                jumpList1.put("title", "跳转惠采");
                jumpList1.put("url", odsUrl + "/#/purchase-sign/brand-authorize?key=" + URLUtil.encode(brandAuthApply.getCompany()));
                jumpList.add(jumpList1);
                templateCard.put("jump_list", jumpList);

                JSONObject cardAction = new JSONObject();
                cardAction.put("type", 1);
                cardAction.put("url",  odsUrl + "/#/purchase-sign/brand-authorize?key=" + URLUtil.encode(brandAuthApply.getCompany()));
                templateCard.put("card_action", cardAction);
                qywxParam.put("template_card", templateCard);
                triggerMsgRequest.setQywxParam(qywxParam);
                msgClient.triggerMsg(triggerMsgRequest);
            }
            if (StringUtils.equals(brandAuthApplyGrantFileDTO.getState(), "6")){
                //拒绝发放
                BrandAuthApply brandAuthApply1 = this.getById(brandAuthApplyGrantFileDTO.getId());
                BrandAuthApplySnapshot brandAuthApplySnapshot = BeanUtil.copyProperties(brandAuthApply1, BrandAuthApplySnapshot.class, "id", "created_at", "created_by", "updated_at", "updated_by");
                brandAuthApplySnapshot.setCreatedAt(now);
                brandAuthApplySnapshot.setCreatedBy(name);
                brandAuthApplySnapshotMapper.insert(brandAuthApplySnapshot);
            }
        }
        return result;
    }

    @Override
    public List<BrandAuthTimeVO> authTime() {
        return brandAuthApplyMapper.selectAuthTime();
    }

    // 一个简单的类来表示文本位置
    static class TextPosition {
        private float x;
        private float y;
        private String text;

        public TextPosition(float x, float y, String text) {
            this.x = x;
            this.y = y;
            this.text = text;
        }

        public float getX() {
            return x;
        }

        public float getY() {
            return y;
        }

        public String getText() {
            return text;
        }
    }

    public static byte[] streamToByteArray(InputStream is) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();//创建输出流对象
        byte[] b = new byte[1024];
        int len;
        while ((len = is.read(b)) != -1) {
            bos.write(b, 0, len);
        }
        byte[] array = bos.toByteArray();
        bos.close();
        return array;
    }

}
