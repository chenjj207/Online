package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
* <p>
* 联营申请表
* </p>
* @author jidonglin
* @since 2024-03-14
*/
@Data
@Schema(title = "联营申请表")
public class AssociateApplyQueryDTO {

    @NotEmpty(message = "openId不能为空")
    @Schema(description = "openId")
    private String openId;


}
