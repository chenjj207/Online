package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class RealNewsTypeVO {

    @Schema(description = "资讯id")
    private Integer id;

    @Schema(description = "资讯分类名")
    private String name;
}
