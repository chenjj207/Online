package com.purchase.service.impl;


import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.client.feign.MsgClient;
import com.purchase.common.MemberConstants;
import com.purchase.config.AliSmsProperties;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.Member;
import com.purchase.entity.MemberMessage;
import com.purchase.entity.Message;
import com.purchase.mapper.MemberMapper;
import com.purchase.mapper.MemberMessageMapper;
import com.purchase.mapper.MessageMapper;
import com.purchase.service.CommonService;
import com.purchase.service.MemberMessageService;
import com.purchase.service.dto.DisposeIdListDTO;
import com.purchase.service.dto.MemberMessageAddDTO;
import com.purchase.service.dto.MessageMallAddDTO;
import com.zyd.framework.utils.exception.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 会员消息表 服务实现类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Service
public class MemberMessageServiceImpl extends ServiceImpl<MemberMessageMapper, MemberMessage> implements MemberMessageService {

    @Resource
    MessageMapper messageMapper;
    @Resource
    MemberMapper memberMapper;
    @Autowired
    CommonService commonService;
    @Resource
    MsgClient msgClient;
    @Resource
    AliSmsProperties aliSmsProperties;
    @Override
    @Transactional
    public Boolean add(MemberMessageAddDTO memberMessageAddDTO) {
        //创建公告
        Message message = new Message();
        BeanUtil.copyProperties(memberMessageAddDTO,message,"memberId");
        message.setCreatedAt(LocalDateTime.now());
        messageMapper.insert(message);
        List<MemberMessage> list =new ArrayList<>();
        //判断公告接收对象
        if(memberMessageAddDTO.getReceiverType().equals(MemberConstants.MessageReceiverType.ALL.code)){
            List<Integer> idList = new ArrayList<>();
            memberMapper.selectList(null).forEach(e->{
                idList.add(e.getId());
            });
            memberMessageAddDTO.setMemberId(idList);
        }
        //如果接收对象为空，抛出异常
        if (ObjectUtil.isNull(memberMessageAddDTO.getMemberId())){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_MEMBER);
        }
        memberMessageAddDTO.getMemberId().forEach(e->{
            MemberMessage memberMessage =new MemberMessage();
            memberMessage.setNoticeId(message.getId());
            memberMessage.setMemberId(e);
            memberMessage.setCreatedAt(LocalDateTime.now());
            list.add(memberMessage);
        });
        return  saveBatch(list);
    }

    @Override
    public Boolean edit(DisposeIdListDTO dto) {
        UpdateWrapper<MemberMessage> wrapper = new UpdateWrapper<>();
        wrapper.in("notice_id",dto.getId())
                .eq("member_id",StpUtil.getLoginId())
                .set("updated_at",LocalDateTime.now())
                .set("is_read", MemberConstants.MemberMessageRead.READ.code);
        return saveOrUpdate(null,wrapper);
    }

    @Override
    public Boolean delete(DisposeIdListDTO dto) {
        UpdateWrapper<MemberMessage> wrapper = new UpdateWrapper<>();
        wrapper.in("notice_id",dto.getId())
                .eq("member_id",StpUtil.getLoginId())
                .set("updated_at",LocalDateTime.now())
                .set("is_delete", MemberConstants.MemberIsDelete.YES.code);
        return saveOrUpdate(null,wrapper);
    }

    //批量设置为已读
    @Override
    public Boolean allEdit() {
        UpdateWrapper<MemberMessage> wrapper = new UpdateWrapper<>();
        wrapper.eq("member_id",StpUtil.getLoginId())
                .eq("is_delete",MemberConstants.MemberIsDelete.NO.code)
                .eq("is_read",MemberConstants.MemberMessageRead.UN_READ.code)
                .set("updated_at",LocalDateTime.now())
                .set("is_read", MemberConstants.MemberMessageRead.READ.code);
        return saveOrUpdate(null,wrapper);
    }

    //批量删除
    @Override
    public Boolean allDelete() {
        UpdateWrapper<MemberMessage> wrapper = new UpdateWrapper<>();
        wrapper.eq("member_id",StpUtil.getLoginId())
                .eq("is_delete",MemberConstants.MemberIsDelete.NO.code)
                .set("updated_at",LocalDateTime.now())
                .set("is_delete", MemberConstants.MemberIsDelete.YES.code);
        return saveOrUpdate(null,wrapper);
    }

    @Override
    @Transactional
    public Boolean mallAdd(MessageMallAddDTO messageMallAddDTO) {
        Member member = memberMapper.selectById(messageMallAddDTO.getMemberId());
        if (member == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_MEMBER);
        }
        JSONObject jsonObject = commonService.getCustInfo();
        Integer currentMemberId = jsonObject.getInteger("memberId");
        String currentCompany = jsonObject.getString("company");
        LocalDateTime now = LocalDateTime.now();
        Message message = new Message();
        message.setNoticeTitle("留言");
        message.setNoticeInfo(messageMallAddDTO.getNoticeInfo());
        message.setReceiverType(MemberConstants.MessageReceiverType.SINGLE.code);
        message.setCreatedAt(now);
        message.setCreatedBy(currentCompany);
        int count = messageMapper.insert(message);
        if (count != 1){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_SEND_MESSAGE);
        }

        MemberMessage memberMessage = new MemberMessage();
        memberMessage.setNoticeId(message.getId());
        memberMessage.setMemberId(member.getId());
        memberMessage.setIsRead(MemberConstants.MemberMessageRead.UN_READ.code);
        memberMessage.setIsDelete(MemberConstants.MemberIsDelete.NO.code);
        memberMessage.setSendMemberId(currentMemberId);
        memberMessage.setCreatedAt(now);
        memberMessage.setCreatedBy(currentCompany);
        boolean result = save(memberMessage);
        if (!result){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_SEND_MESSAGE);
        }
        //留言埋点
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("notify");
        triggerMsgRequest.setScene("memberMessageLeave");
        JSONObject smsParam = new JSONObject();
        smsParam.put("company", currentCompany);
        smsParam.put("phone", member.getLinkphone());
        triggerMsgRequest.setSmsParam(smsParam);

        JSONObject wxpfParam = new JSONObject();
        wxpfParam.put("noticeInfo", messageMallAddDTO.getNoticeInfo());
        wxpfParam.put("time", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
        wxpfParam.put("page", "pages/mine-message/index");
        triggerMsgRequest.setWxpfParam(wxpfParam);
        msgClient.triggerMsg(triggerMsgRequest);
        return true;
    }
}
