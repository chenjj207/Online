package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.BrandAuthProtocol;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.BrandAuthProtocolAddDTO;
import com.purchase.service.dto.BrandAuthProtocolPageDTO;

/**
 * <p>
 * 品牌授权协议存档 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-06-03
 */
public interface BrandAuthProtocolService extends IService<BrandAuthProtocol> {

    public Integer add(BrandAuthProtocolAddDTO brandAuthProtocolAddDTO);

    public Page<BrandAuthProtocol> queryList(BrandAuthProtocolPageDTO brandAuthProtocolPageDTO);
}
