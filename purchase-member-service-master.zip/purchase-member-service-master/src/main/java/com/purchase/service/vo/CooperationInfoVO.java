package com.purchase.service.vo;

import com.purchase.entity.Cooperation;
import com.purchase.entity.CooperationReply;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
public class CooperationInfoVO {
    @Schema(description = "协作内容")
    Cooperation cooperation;

    @Schema(description = "协作的所有回复信息")
    List<CooperationReply> cooperationReplyList;

    @Schema(description = "协作所属会员头像")
    private String iconUrl;

    @Schema(description = "会员所属公司")
    private String company;
}
