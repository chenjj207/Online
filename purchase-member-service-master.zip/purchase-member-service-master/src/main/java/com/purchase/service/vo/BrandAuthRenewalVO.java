package com.purchase.service.vo;

import com.purchase.entity.BrandAuthApply;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author jidonglin
 * @Description: 续约 查询实体
 * @date 2024/4/19  14:04
 */
@Data
@Schema(title = "续约 查询实体")
public class BrandAuthRenewalVO {

    @Schema(description = "品牌授权实体")
    private BrandAuthApply brandAuthApply;

    @Schema(description = "本季度累计施耐德采购金额")
    private BigDecimal thisQuarterPurchasePrice;

    @Schema(description = "本季度完成情况")
    private BigDecimal thisQuarterFinishStatus;

    @Schema(description = "本年度累计施耐德采购金额")
    private BigDecimal thisYearPurchasePrice;

    @Schema(description = "本年度完成情况")
    private BigDecimal thisYearFinishStatus;
}
