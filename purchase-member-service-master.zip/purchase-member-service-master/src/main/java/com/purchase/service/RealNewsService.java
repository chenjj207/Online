package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.RealNews;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.InterestListVO;
import com.purchase.service.vo.RealNewsVO;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * <p>
 * 资讯表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-02-03
 */
public interface RealNewsService extends IService<RealNews> {

    public Page<RealNews> search(RealNewsPageDTO realNewsPageDTO);

    public boolean save(RealNewsAddDTO realNewsAddDTO);

    public boolean edit(RealNewsEditDTO realNewsAddDTO);

    RealNews info(WxQueryIdDTO wxqueryIdDTO, HttpServletRequest httpServletRequest);

    RealNews mallInfo(WxQueryIdDTO wxqueryIdDTO, HttpServletRequest httpServletRequest);

    Page<RealNews> pageSearch(RealNewsWXPageDTO realNewsWXPageDTO);

    String preview(RealNewsSenceDTO realNewsSenceDTO);

    Page<RealNewsVO> searchPage(RealNewsPageDTO realNewsPageDTO);

    Page<InterestListVO> interestList(InterestDTO interestDTO);

    RealNews pcInfo(QueryIdDTO queryIdDTO);

    Page<RealNews> mallResourcePage(RealNewsResourceDTO realNewsResourceDTO);

    Page<RealNews> mallNeedPage(RealNewsNeedDTO realNewsNeedDTO);
}
