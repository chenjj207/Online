package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


@Data
public class QueryTypeDTO {

    @Schema(description = "资讯的页面类型")
    private String queryType;
}
