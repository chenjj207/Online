package com.purchase.service;

import com.purchase.entity.AssociatePromotion;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 项目推广专员配置表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-15
 */
public interface AssociatePromotionService extends IService<AssociatePromotion> {

    public List<String> queryAll();

}
