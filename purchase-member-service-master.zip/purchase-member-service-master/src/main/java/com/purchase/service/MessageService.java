package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.entity.Message;
import com.purchase.service.dto.MessageMallAddDTO;
import com.purchase.service.dto.MessagePageDTO;
import com.purchase.service.dto.MessageQueryDTO;
import com.purchase.service.vo.MessagePageVO;
import com.purchase.service.vo.MessageWxPageVO;
import com.zyd.framework.boot.config.base.PageDTO;

/**
 * <p>
 * 消息表 服务类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
public interface MessageService extends IService<Message> {

    Message getIdInfo(MessageQueryDTO messageQueryDTO);

    Page<MessagePageVO> pageList(MessagePageDTO messagePageDTO);

    Page<MessageWxPageVO> wxPageList(PageDTO pageDTO);

    Page<MessagePageVO> mallPage(MessagePageDTO messagePageDTO);
}
