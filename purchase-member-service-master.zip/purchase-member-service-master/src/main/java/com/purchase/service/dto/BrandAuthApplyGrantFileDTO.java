package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author jidonglin
 * @Description: 合作详情与申请计划
 * @date 2024/4/15  14:12
 */
@Data
public class BrandAuthApplyGrantFileDTO {
    @Schema(description = "id")
    @NotNull(message = "id不能为空")
    private Integer id;

    @Schema(description = "状态：1、待审批  2、同意授权  3、拒绝授权  4、已存档 5、已发放  6、拒绝发放")
    @Pattern(regexp = "4|5|6",message = "状态参数错误   4、已存档 5、已发放  6、拒绝发放")
    private String state;

    @Schema(description = "原因")
    private String grantReason;
}
