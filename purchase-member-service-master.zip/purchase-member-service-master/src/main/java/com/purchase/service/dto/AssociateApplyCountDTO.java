package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Pattern;
import java.util.Date;
import java.util.List;

@Data
public class AssociateApplyCountDTO{

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "开始时间")
    private Date beginTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "结束时间")
    private Date endTime;

    @Schema(description = "状态")
    private String state;

    @Schema(description = "联营合作诉求")
    private String cooperationDemand;

    @Schema(description = "合作项目")
    private String cooperationProject;

    @Schema(description = "项目推广专员")
    private String promotionPerson;

    @Schema(description = "调研形式")
    private String researchFormat;

    @Schema(description = "客户类型")
    private String customerType;

    @Schema(description = "子公司名称")
    private List<String> subCompany;

    @Schema(description = "模糊查询 调研人员/客户名称/联系人/联系方式")
    private String key;

    @Schema(description = "申请年份")
    private String applyNf;
}
