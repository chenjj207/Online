package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class MessageQueryDTO {

    @NotNull(message = "公告id不能为空")
    @Schema(description = "公告id")
    private Integer noticeId;

}
