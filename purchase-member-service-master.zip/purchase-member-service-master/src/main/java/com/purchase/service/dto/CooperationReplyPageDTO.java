package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class CooperationReplyPageDTO extends PageDTO {

    @Schema(description = "资讯id")
    @NotNull(message = "资讯id不能为空")
    private Integer realNewsId;

    @Schema(description = "会员id")
    private Integer memberId;

    @Schema(description = "协作id")
    private Integer cooperationId;
}
