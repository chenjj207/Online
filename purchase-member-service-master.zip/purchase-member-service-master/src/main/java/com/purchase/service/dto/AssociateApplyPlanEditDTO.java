package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/3/19  9:12
 */
@Data
@Schema(title = "合作产品")
public class AssociateApplyPlanEditDTO {

    @Schema(description = "主键")
    private Integer id;

    @Schema(description = "申请id")
    private Integer applyId;

    @Schema(description = "产品类目/名称")
    private String productName;

    @Schema(description = "计划合作产品基础信息-品牌")
    private String brand;

    @Schema(description = "国内市场容量（万）")
    @Digits(integer=6, fraction=4, message = "国内市场容量错误，请重新输入")
    private BigDecimal marketCapacity;

    @Schema(description = "计划上线SKU数量（个）")
    @Digits(integer=6, fraction=4, message = "计划上线SKU数量错误，请重新输入")
    private Integer planSkuNum;

    @Schema(description = "去年全年销售额（万）")
    @Digits(integer=6, fraction=4, message = "全年销售额错误，请重新输入")
    private BigDecimal lastYearSaleVolume;
}
