package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigDecimal;

/**
* <p>
* 联营申请表
* </p>
* @author jidonglin
* @since 2024-03-14
*/
@Data
@Schema(title = "联营申请表")
public class AssociateApplyEditResearchDTO {

    private static final long serialVersionUID = 1L;


    @NotNull(message = "id不能为空")
    @Schema(description = "id")
    private Integer id;

    @Schema(description = "调研形式")
//    @NotEmpty(message = "请填写调研形式")
    private String researchFormat;

    @Schema(description = "客户类型")
//    @NotEmpty(message = "请填写客户类型")
    private String customerType;

    @Schema(description = "调研结果")
    @NotEmpty(message = "请填写调研结果")
    private String researchResult;

    @Schema(description = "状态")
    @NotEmpty(message = "状态不能为空")
    @Pattern(regexp = "2|3",message = "状态参数错误  2：调研通过 3：调研未通过")
    private String state;


}
