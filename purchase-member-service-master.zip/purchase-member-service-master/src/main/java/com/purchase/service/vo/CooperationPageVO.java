package com.purchase.service.vo;

import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CooperationPageVO extends BaseEntity {

    @Schema(description = "标题")
    private String title;

    @Schema(description = "会员所属公司")
    private String company;

    @Schema(description = "状态（0=已回复，1=未回复，默认为未回复）")
    private Integer status;

    @Schema(description = "审核状态 0: 待审核 1：已通过 2：已拒绝")
    private Integer auditState;

    @Schema(description = "联系方式")
    private String linkphone;

    @Schema(description = "协作类型(resource=资源，need=需求)")
    private String type;

    @Schema(description = "协作描述")
    private String teamInfo;

    @Schema(description = "联系人")
    private String linkman;

    @Schema(description = "资源类型(product=产品资源，service=服务资源)")
    private String resourceType;

    @Schema(description = "需求类型(serviceCooperate=服务协同)")
    private String needType;

    @Schema(description = "拒绝原因")
    private String rejectReason;
}
