package com.purchase.service.impl;

import com.purchase.entity.VisitLog;
import com.purchase.mapper.VisitLogMapper;
import com.purchase.service.VisitLogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 联营慧访问日志记录表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-06-29
 */
@Service
public class VisitLogServiceImpl extends ServiceImpl<VisitLogMapper, VisitLog> implements VisitLogService {

}
