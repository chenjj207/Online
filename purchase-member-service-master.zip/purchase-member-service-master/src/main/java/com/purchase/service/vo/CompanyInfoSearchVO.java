package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/2/13  14:08
 */
@Data
public class CompanyInfoSearchVO {

    @Schema(description = "公司名称")
    private String name;
    @Schema(description = "高亮的公司名称")
    private String nameLight;
}
