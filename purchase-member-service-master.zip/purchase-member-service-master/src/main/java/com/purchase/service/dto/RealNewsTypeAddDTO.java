package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
public class RealNewsTypeAddDTO {

    @NotBlank(message = "类型名不能为空")
    @Schema(description = "资讯类型名称")
    private String typeName;

    @Pattern(regexp = "firstPage|center",message = "参数错误")
    @Schema(description = "发布页面： firstPage：首页   center：资讯中心")
    private String page;

    @Schema(description = "创建者")
    private String createdBy;
}
