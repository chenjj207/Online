package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/10/10  9:32
 */
@Data
public class StatisticsMemberVO {
    @Schema(description = "会员服务行业")
    private String industry;
    @Schema(description = "会员核心能力")
    private String competence;
    @Schema(description = "数量")
    private int num;
}
