package com.purchase.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.entity.MemberMessage;
import com.purchase.service.dto.*;

/**
 * <p>
 * 会员消息表 服务类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
public interface MemberMessageService extends IService<MemberMessage> {

    Boolean add(MemberMessageAddDTO memberMessageAddDTO);

    Boolean edit(DisposeIdListDTO dto);

    Boolean delete(DisposeIdListDTO dto);

    Boolean allEdit();

    Boolean allDelete();

    Boolean mallAdd(MessageMallAddDTO messageMallAddDTO);
}
