package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.date.DateUtil;
import cn.hutool.extra.servlet.ServletUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.ObjectUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.client.feign.MsgClient;
import com.purchase.config.AliSmsProperties;
import com.purchase.feign.CustomerClient;
import com.purchase.feign.UserClient;
import com.purchase.feign.param.CustomerAddDTO;
import com.purchase.feign.param.JsonResult;
import com.purchase.feign.param.SupplierDTO;
import com.purchase.service.CommonService;
import com.purchase.service.LoginLogService;
import com.purchase.utils.NoticeUtils;
import com.purchase.utils.TokenUtils;
import com.purchase.client.ICClient;
import com.purchase.client.WXClient;
import com.purchase.common.MemberConstants;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.service.dto.MemberNumDTO;
import com.purchase.entity.Cooperation;
import com.purchase.entity.MemberMessage;
import com.purchase.mapper.CooperationMapper;
import com.purchase.mapper.MemberMessageMapper;
import com.purchase.service.dto.*;
import com.purchase.mapper.MemberMapper;
import com.purchase.entity.Member;
import com.purchase.service.MemberService;
import com.purchase.service.vo.*;
import com.zyd.framework.utils.constant.UserSession;
import com.zyd.framework.utils.exception.BaseExceptionDesc;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.response.CommonResponse;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Service
public class MemberServiceImpl extends ServiceImpl<MemberMapper, Member> implements MemberService {

    private static Logger logger = LoggerFactory.getLogger(MemberServiceImpl.class);

    @Autowired
    AliSmsService aliSmsService;
    @Resource
    MemberMapper memberMapper;
    @Resource
    CooperationMapper cooperationMapper;
    @Resource
    MemberMessageMapper memberMessageMapper;
    @Autowired
    LoginLogService loginLogService;
    @Autowired
    CommonService commonService;
    @Resource
    private WXClient wxClient;
    @Resource
    private ICClient icClient;
    @Resource
    private UserClient userClient;
    @Resource
    CustomerClient customerClient;
    @Resource
    MsgClient msgClient;

    @Value("${app.ali.sms.code.phoneLogin}")
    String phoneLogin;
    @Value("${app.ali.sms.code.register}")
    String register;

    @Value("${ic.token}")
    String icToken;

    @Value("${wx.appid}")
    String appid;
    @Value("${wx.secret}")
    String secret;

    @Value("${commonoss.ossUrl}")
    String commonOssUrl;

    @Value("${isReferMemberCooperation}")
    Boolean isReferMemberCooperation;

    @Autowired
    TokenUtils tokenUtils;
    @Autowired
    NoticeUtils noticeUtils;

    @Resource
    public StringRedisTemplate stringRedisTemplate;
    @Resource
    AliSmsProperties aliSmsProperties;

    @Override
    public Boolean add(MemberRegisterDTO memberRegisterDTO) {
        Member member =new Member();
        BeanUtil.copyProperties(memberRegisterDTO,member,true);
        member.setCreatedAt(LocalDateTime.now());
        return save(member);
    }

    @Override
    public Page<Member> selectList(MemberWxPageDTO memberWxPageDTO) {
        if(memberWxPageDTO.buildPage().getCurrent() > 1){
            StpUtil.checkLogin();
        }
        QueryWrapper<Member> wrapper = new QueryWrapper<>();
        wrapper.eq("state",MemberConstants.MemberState.PASS.code)
                .eq(StringUtils.isNotBlank(memberWxPageDTO.getIndustry()),"industry",memberWxPageDTO.getIndustry())
                .gt(!ObjectUtils.isEmpty(memberWxPageDTO.getBeginTime()),"created_at",memberWxPageDTO.getBeginTime())
                .lt(!ObjectUtils.isEmpty(memberWxPageDTO.getEndTime()),"created_at",memberWxPageDTO.getEndTime())
                .eq(StringUtils.isNotBlank(memberWxPageDTO.getCompetence()),"competence",memberWxPageDTO.getCompetence())
                //微信小程序端搜索参数
                .and(StringUtils.isNotBlank(memberWxPageDTO.getKey()),i->i
                        .or().like("company",memberWxPageDTO.getKey())
                        .or().like("competence",memberWxPageDTO.getKey())
                        .or().like("competence_info",memberWxPageDTO.getKey())
                        .or().like("area",memberWxPageDTO.getKey())
                        .or().like("city",memberWxPageDTO.getKey())
                        .or().like("province",memberWxPageDTO.getKey())
                        .or().like("industry",memberWxPageDTO.getKey())
                )
                .eq("is_show",MemberConstants.IsShow.YES.code)
                //选择需要映射的参数
                .select("id ,company,industry,member_url,province,city,area,competence_info as competenceInfo,competence,icon_url, reason")
                .orderByDesc("created_at");
        return memberMapper.selectPage(memberWxPageDTO.buildPage(),wrapper);
    }


    @Override
    @Transactional
    public Boolean updateState(MemberEditStateDTO memberEditStateDTO) {
        //当编辑状态为不通过时，需要理由
        Member member = memberMapper.selectById(memberEditStateDTO.getId());
        if (member == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_MEMBER);
        }
       if (Objects.equals(memberEditStateDTO.getState(), MemberConstants.MemberState.REFER.code)&&BeanUtil.isEmpty(memberEditStateDTO.getReason())){
           throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NEED_NOT_PASS_REASON);
        }
        LocalDateTime now = LocalDateTime.now();
        UpdateWrapper<Member> updateWrapper= new UpdateWrapper<>();
        updateWrapper
                .set(BeanUtil.isNotEmpty(memberEditStateDTO.getState()),"state", memberEditStateDTO.getState())
                .set("updated_at", now)
                .set("audit_at", now)
                .set(BeanUtil.isNotEmpty(memberEditStateDTO.getIsShow()),"is_show",memberEditStateDTO.getIsShow())
                .set(StringUtils.isNotBlank(memberEditStateDTO.getRemark()),"remark",memberEditStateDTO.getRemark())
                .set(StringUtils.isNotEmpty(memberEditStateDTO.getUpdatedBy()), "updated_by", memberEditStateDTO.getUpdatedBy())
                .eq("id", memberEditStateDTO.getId());
        if(BeanUtil.isNotEmpty(memberEditStateDTO.getState())){
            updateWrapper
                    //设置会员不通过时，需要理由
                    .set(memberEditStateDTO.getState().equals(MemberConstants.MemberState.REFER.code),"reason", memberEditStateDTO.getReason())
                    //设置会员通过时，不通过理由去除
                    .set(memberEditStateDTO.getState().equals(MemberConstants.MemberState.PASS.code),"reason",null);
        }
        boolean result = false;
        if (MemberConstants.MemberState.PASS.code.intValue() == memberEditStateDTO.getState().intValue()){
            //审核状态为1 并且 修改成功
            CustomerAddDTO customerAddDTO = new CustomerAddDTO();
            customerAddDTO.setMemberId(memberEditStateDTO.getId());
            customerAddDTO.setCreatedBy(memberEditStateDTO.getCreatedBy());
            customerAddDTO.setUpdatedBy(memberEditStateDTO.getUpdatedBy());
            CommonResponse<Boolean> commonResponse = customerClient.add(customerAddDTO);
            if (commonResponse.getCode() != 0){
                log.error(PurchaseBusinessExceptionDesc.ERROR_ADD_CUSTOMER.getDesc());
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_ADD_CUSTOMER, commonResponse.getMessage());
            }
            result =  update(null, updateWrapper);
            // MSG 审核通过埋点
            TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
            triggerMsgRequest.setBusiness("member");
            triggerMsgRequest.setScene("memberApplyPass");
            JSONObject smsParam = new JSONObject();
            smsParam.put("phone", member.getLinkphone());
            smsParam.put("company", member.getCompany());
            triggerMsgRequest.setSmsParam(smsParam);

            JSONObject wxpfParam = new JSONObject();
            wxpfParam.put("unionid", member.getUnionId());
            wxpfParam.put("appid", appid);
            wxpfParam.put("pagepath", "pages/mine-profile/index");

            JSONObject k1 = new JSONObject();
            JSONObject thing6 = new JSONObject();
            thing6.put("value", "工业终端贸易联营慧");
            k1.put("thing6", thing6);
            JSONObject thing7 = new JSONObject();
            thing7.put("value", member.getCompany());
            k1.put("thing7", thing7);
            JSONObject time3 = new JSONObject();
            time3.put("value", DateUtil.format(now, "yyyy年MM月dd日 HH:mm:ss"));
            k1.put("time3", time3);

            wxpfParam.put("data", k1);
            triggerMsgRequest.setWxpfParam(wxpfParam);
            msgClient.triggerMsg(triggerMsgRequest);
        }else {
            result =  update(null, updateWrapper);
            // MSG 审核不通过埋点
            TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
            triggerMsgRequest.setBusiness("member");
            triggerMsgRequest.setScene("memberApplyReject");
            JSONObject smsParam = new JSONObject();
            smsParam.put("phone", member.getLinkphone());
            smsParam.put("company", member.getCompany());
            triggerMsgRequest.setSmsParam(smsParam);

//            JSONObject wxpfParam = new JSONObject();
//            wxpfParam.put("result", "未通过");
//            wxpfParam.put("time", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
//            wxpfParam.put("page", "pages/mine-profile/index");
//            triggerMsgRequest.setWxpfParam(wxpfParam);
            msgClient.triggerMsg(triggerMsgRequest);
        }
        return result;
    }

    @Override
    public Boolean sendSmsCode(SendSmsCodeDTO sendSmsCodeDTO) {
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        String tempCode = "";
        if (MemberConstants.SmsCodeType.LOGIN.getCode() == sendSmsCodeDTO.getType()){
            QueryWrapper<Member> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("linkphone", sendSmsCodeDTO.getPhone());
            Member member = memberMapper.selectOne(queryWrapper);
            if((null == member || !Objects.equals(member.getLinkphone(), sendSmsCodeDTO.getPhone()))) {
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PHONE);
            }
            tempCode = "LOGIN";
            triggerMsgRequest.setBusiness("login");
            triggerMsgRequest.setScene("memberLoginCode");
        }else if (MemberConstants.SmsCodeType.REGIST.getCode() == sendSmsCodeDTO.getType()){
            QueryWrapper<Member> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("linkphone", sendSmsCodeDTO.getPhone());
            Member member = memberMapper.selectOne(queryWrapper);
            if (member != null){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.EXIST_PHONE);
            }
            tempCode = "REGIST";
            triggerMsgRequest.setBusiness("regist");
            triggerMsgRequest.setScene("memberRegistCode");
        }else if (MemberConstants.SmsCodeType.ASSOCIATE_APPLY.getCode() == sendSmsCodeDTO.getType()){
            tempCode = "ASSOCIATE_APPLY";
            triggerMsgRequest.setBusiness("associate");
            triggerMsgRequest.setScene("associateCode");
        }else if (MemberConstants.SmsCodeType.BRAND_AUTH_APPLY.getCode() == sendSmsCodeDTO.getType()){
            tempCode = "BRAND_AUTH_APPLY";
            triggerMsgRequest.setBusiness("brandAuth");
            triggerMsgRequest.setScene("brandAuthCode");
        }else {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_SMS_TYPE);
        }
        String random = aliSmsService.getRandomCode();
        JSONObject smsParam = new JSONObject();
        smsParam.put("phone", sendSmsCodeDTO.getPhone());
        smsParam.put("code", random);
        triggerMsgRequest.setSmsParam(smsParam);
        CommonResponse<Boolean> commonResponse = msgClient.triggerMsg(triggerMsgRequest);
        if(commonResponse.getData()){
            //缓存验证码10分钟有效期
            String key = String.format("ZYD_ONLINE_CAPTCHA_%s_%s", tempCode, sendSmsCodeDTO.getPhone());
            stringRedisTemplate.opsForValue().set(key, random, 10, TimeUnit.MINUTES);
        }
        return commonResponse.getData();
    }

    /**
     * wx unionid登录
     * @param memberWXLoginDTO
     * @param request
     * @return
     */
    @Override
    public String wxlogin(MemberWXLoginDTO memberWXLoginDTO, HttpServletRequest request) {
        //get请求 https://api.weixin.qq.com/sns/jscode2session 获取session_key，unionid，openid等数据
        JSONObject jsonObject = wxClient.jscode2session(appid, secret, memberWXLoginDTO.getJsCode());
        if (jsonObject.containsKey("errcode") && jsonObject.getInteger("errcode") != 0){
            logger.error(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getCode() + ": " +
                    PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getDesc() + ": " + jsonObject.getString("errmsg"));
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR);
        }
        String openid = jsonObject.getString("openid");
        String unionid = jsonObject.getString("unionid");
        QueryWrapper<Member> wrapper = new QueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(openid),"open_id", openid);
        Member memberResultOld = memberMapper.selectOne(wrapper);
        if (memberResultOld == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.USER_NOT_EXIST);
        }

        UpdateWrapper<Member> updateWrapper= new UpdateWrapper<>();
        updateWrapper
                .set("updated_at", LocalDateTime.now())
                .set("open_id", openid)
                .set("union_id", unionid)
                .eq("id",memberResultOld.getId());
        memberMapper.update(null, updateWrapper);
        //设置角色，默认ALL
        Set roles = new HashSet();
        roles.add("ALL");

        //设置权限，默认ALL
        Set permissions = new HashSet();
        permissions.add("ALL");

        StpUtil.login(memberResultOld.getId(),"MINI_PROGRAM");
        StpUtil.getSession().set(UserSession.INFO,  (JSONObject) JSONObject.toJSON(memberResultOld));
        StpUtil.getSession().set(UserSession.ROLES,roles);
        StpUtil.getSession().set(UserSession.PERMISSIONS,permissions);
        //获取ip记录登录日志
        String ip = ServletUtil.getClientIP(request,null);
        loginLogService.saveLoginLog(memberResultOld,ip);
        return StpUtil.getTokenValue();
    }

    @Override
    public void loginOut() {
        StpUtil.logout();
    }


    /**
     * 账号再用手机验证码登录
     * @param memberLoginDTO
     * @param request
     * @return
     */
    @Override
    public String login(MemberLoginDTO memberLoginDTO, HttpServletRequest request) {
        //校验手机号是否存在
        QueryWrapper<Member> wrapper = new QueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(memberLoginDTO.getLinkphone()),"linkphone", memberLoginDTO.getLinkphone());
        Member memberResult = memberMapper.selectOne(wrapper);
        if (memberResult == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PHONE);
        }
        //校验验证码
        aliSmsService.valid("LOGIN", memberLoginDTO.getLinkphone(), memberLoginDTO.getSmsCode());

        //get请求 https://api.weixin.qq.com/sns/jscode2session 获取session_key，unionid，openid等数据
        JSONObject jsonObject = wxClient.jscode2session(appid, secret, memberLoginDTO.getJsCode());
        if (jsonObject.containsKey("errcode") && jsonObject.getInteger("errcode") != 0){
            logger.error(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getCode() + ": " +
                    PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getDesc() + ": " + jsonObject.getString("errmsg"));
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR);
        }
        String openid = jsonObject.getString("openid");
        String unionid = jsonObject.getString("unionid");
        QueryWrapper<Member> wrapper1 = new QueryWrapper<>();
        wrapper1.eq(StringUtils.isNotBlank(openid),"open_id", openid);
        Member memberResultOld = memberMapper.selectOne(wrapper1);
        if (memberResultOld != null){
            if (!memberResultOld.getLinkphone().equals(memberLoginDTO.getLinkphone())){
                //提示解绑，清空旧手机号的unionId和openId
                UpdateWrapper<Member> updateWrapper= new UpdateWrapper<>();
                updateWrapper
                        .set("updated_at", LocalDateTime.now())
                        .set("union_id", null)
                        .set("open_id", null)
                        .eq("id",memberResultOld.getId());
                memberMapper.update(null, updateWrapper);
            }
        }
        //更新入参手机号的unionId和openId
        UpdateWrapper<Member> updateWrapper= new UpdateWrapper<>();
        updateWrapper
                .set("updated_at", LocalDateTime.now())
                .set("open_id", openid)
                .set("union_id", unionid)
                .eq("id",memberResult.getId());
        memberMapper.update(null, updateWrapper);


        //设置角色，默认ALL
        Set roles = new HashSet();
        roles.add("ALL");

        //设置权限，默认ALL
        Set permissions = new HashSet();
        permissions.add("ALL");

        //获取ip记录登录日志
        String ip = ServletUtil.getClientIP(request,null);
        loginLogService.saveLoginLog(memberResult,ip);

        StpUtil.login(memberResult.getId(),"MINI_PROGRAM");
        StpUtil.getSession().set(UserSession.INFO,  (JSONObject) JSONObject.toJSON(memberMapper.selectById(memberResult.getId())));
        StpUtil.getSession().set(UserSession.ROLES,roles);
        StpUtil.getSession().set(UserSession.PERMISSIONS,permissions);

        return StpUtil.getTokenValue();
    }

    @Override
    public Boolean regist(MemberRegisterDTO memberRegisterDTO){
        //验证长度
        if(memberRegisterDTO.getCompetenceInfo().length()>300){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.THE_CORE_COMPETENCE_DESCRIPTION_CANNOT_EXCEED);
        }

        if(memberRegisterDTO.getAddress().length()>30){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.THE_CORE_ADDRESS_DESCRIPTION_CANNOT_EXCEED);
        }

        //校验验证码
        aliSmsService.valid("REGIST", memberRegisterDTO.getLinkphone(), memberRegisterDTO.getSmsCode());
        //判断注册账号是否已经存在
        QueryWrapper<Member> wrapper = new QueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(memberRegisterDTO.getLinkphone()),"linkphone", memberRegisterDTO.getLinkphone());
        Member memberResult = memberMapper.selectOne(wrapper);
        if (memberResult != null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.PHONE_OCCUPIED);
        }

        String openid = memberRegisterDTO.getOpenId();
        QueryWrapper<Member> wrapper1 = new QueryWrapper<>();
        wrapper1.eq(StringUtils.isNotBlank(openid),"open_id", openid);
        List<Member> memberResultOld = memberMapper.selectList(wrapper1);
        if (!CollectionUtils.isEmpty(memberResultOld)){
            for (Member m : memberResultOld) {
                //提示解绑，清空旧手机号的unionId和openId
                UpdateWrapper<Member> updateWrapper= new UpdateWrapper<>();
                updateWrapper
                        .set("updated_at", LocalDateTime.now())
                        .set("union_id", null)
                        .set("open_id", null)
                        .eq("id",m.getId());
                memberMapper.update(null, updateWrapper);
            }
        }

        Member member = new Member();
        BeanUtil.copyProperties(memberRegisterDTO, member,true);
        member.setCreatedAt(LocalDateTime.now());
        member.setIsShow(MemberConstants.IsShow.NO.code);
        member.setIsInner(MemberConstants.IsInner.NO.code);
        member.setIsShowReason(MemberConstants.IsShowReason.YES.code);
        if (StringUtils.isNotEmpty(member.getPromoter())){
            String promoterNoWhiteSpace = StringUtils.deleteWhitespace(member.getPromoter());
            List<String> companyNames = memberMapper.selectCompanyByPromoter(promoterNoWhiteSpace);
            if (!companyNames.isEmpty() && companyNames.size() == 1){
                member.setCompanyName(companyNames.get(0));
            }
            member.setPromoter(promoterNoWhiteSpace);
        }
        //当修改所属公司时，根据所属公司推出所属大区
        if(BeanUtil.isNotEmpty(member.getCompanyName())){
            member.setAreaName(memberMapper.inferAreaName(member.getCompanyName()));
            //如果是未记录的公司
            if(BeanUtil.isEmpty(member.getAreaName())){
                member.setAreaName(MemberConstants.AreaType.OTHER.getMessage());
            }
        }
        boolean isSuccess = save(member);

        if (isSuccess){
            String content = "联营慧会员【"+ memberRegisterDTO.getCompany()  +"】提交申请资料，请到会员管理进行查看";
            noticeUtils.sendQywx(content);


            TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
            triggerMsgRequest.setBusiness("regist");
            triggerMsgRequest.setScene("memberRegistApply");
            JSONObject qywxParam = new JSONObject();
            qywxParam.put("msgtype", "template_card");

            JSONObject templateCard = new JSONObject();
            templateCard.put("card_type", "text_notice");

            JSONObject mainTitle = new JSONObject();
            mainTitle.put("title", "会员待审核");
            mainTitle.put("desc", "会员管理");
            templateCard.put("main_title", mainTitle);

            List<JSONObject> horizontalContentList = new ArrayList<>();
            JSONObject keyName1 = new JSONObject();
            keyName1.put("keyname", "客户");
            keyName1.put("value", member.getCompany());
            horizontalContentList.add(keyName1);
            JSONObject keyName2 = new JSONObject();
            keyName2.put("keyname", "账号");
            keyName2.put("value", member.getLinkphone());
            horizontalContentList.add(keyName2);
            JSONObject keyName3 = new JSONObject();
            keyName3.put("keyname", "提交时间");
            keyName3.put("value", DateUtil.format(LocalDateTime.now(), "yyyy/MM/dd HH:mm:ss"));
            horizontalContentList.add(keyName3);
            JSONObject keyName4 = new JSONObject();
            keyName4.put("keyname", "备注");
            keyName4.put("value", "您有一个新客户提交资料申请，赶快去查看并审核吧。");
            horizontalContentList.add(keyName4);
            templateCard.put("horizontal_content_list", horizontalContentList);

            List<JSONObject> jumpList = new ArrayList<>();
            JSONObject jumpList1 = new JSONObject();
            jumpList1.put("type", 1);
            jumpList1.put("title", "跳转惠采");
            jumpList1.put("url", "https://huicai.zydonline.com/admin/#/purchase-member/member");
            jumpList.add(jumpList1);
            templateCard.put("jump_list", jumpList);

            JSONObject cardAction = new JSONObject();
            cardAction.put("type", 1);
            cardAction.put("url",  "https://huicai.zydonline.com/admin/#/purchase-member/member");
            templateCard.put("card_action", cardAction);
            qywxParam.put("template_card", templateCard);
            triggerMsgRequest.setQywxParam(qywxParam);

            JSONObject smsParam = new JSONObject();
            smsParam.put("phone", member.getLinkphone());
            triggerMsgRequest.setSmsParam(smsParam);
            msgClient.triggerMsg(triggerMsgRequest);
        }

        return isSuccess;
    }

    @Override
    public Member check(MemberCheckDTO memberCheckDTO) {
        //注册时获取unionid和openid
        JSONObject jsonObject = wxClient.jscode2session(appid, secret, memberCheckDTO.getJsCode());
        if (jsonObject.containsKey("errcode") && jsonObject.getInteger("errcode") != 0){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR);
        }
        String openid = jsonObject.getString("openid");
        String unionid = jsonObject.getString("unionid");

        QueryWrapper<Member> wrapper = new QueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(openid),"open_id", openid);
        Member memberResultOld = memberMapper.selectOne(wrapper);
        if (memberResultOld == null){
            Member m = new Member();
            m.setOpenId(openid);
            m.setUnionId(unionid);
            return m;
        }
        return memberResultOld;
    }

    @Override
    public Member loginCheck(MemberLoginCheckDTO memberLoginCheckDTO) {
        //注册时获取unionid和openid
        JSONObject jsonObject = wxClient.jscode2session(appid, secret, memberLoginCheckDTO.getJsCode());
        if (jsonObject.containsKey("errcode") && jsonObject.getInteger("errcode") != 0){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR);
        }
        String currentOpenId = jsonObject.getString("openid");

        QueryWrapper<Member> wrapper = new QueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(memberLoginCheckDTO.getLinkphone()),"linkphone", memberLoginCheckDTO.getLinkphone());
        Member memberResult = memberMapper.selectOne(wrapper);
        if (memberResult == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PHONE);
        }
        String openId = memberResult.getOpenId();

        QueryWrapper<Member> wrapper1 = new QueryWrapper<>();
        wrapper1.eq(StringUtils.isNotBlank(currentOpenId),"open_id", currentOpenId);
        Member memberResultOld = memberMapper.selectOne(wrapper1);

        if (StringUtils.isEmpty(openId) && memberResultOld == null){
            //手机号没有绑定任何微信，并且当前微信号没有绑定手机
            return memberResult;
        }

        if (!currentOpenId.equalsIgnoreCase(openId)){
            if (memberResultOld == null){
                //手机号对应的微信号不一致，并且微信号没有其他账号，提示“该账号已有绑定微信号，请确认解绑微信号或者退出登录”
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.PHONE_WITH_OPENID);
            }else {
                //手机号对应的微信号不一致，并且微信号有其他账号
                if (!StringUtils.equalsIgnoreCase(memberResultOld.getLinkphone(), memberLoginCheckDTO.getLinkphone())){
                    //微信号对应的手机号不一致
                    BusinessException be = new BusinessException();
                    be.setCode(PurchaseBusinessExceptionDesc.OPENID_BIND_PHONE.getCode());
                    be.setDesc("当前微信号已关联账号【"+ memberResultOld.getLinkphone()  +"】，请确认继续解绑微信号或者退出登录");
                    throw be;
                }else {
                    //微信号对应的手机号一致，正常返回
                }
            }
        }
        return memberResult;
    }

    @Override
    public List<CompanyInfoSearchVO> queryCompany(MemberCompanyDTO memberCompanyDTO) {
        JSONObject jsonObject = icClient.search(icToken, memberCompanyDTO.getWord());
        JSONObject result = JSON.parseObject(jsonObject.getString("result"));
        if (result == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_COMPANY);
        }
        JSONArray jsonArray = result.getJSONArray("items");
        List<CompanyInfoSearchVO> companyInfoSearchVOS = new ArrayList<>();
        jsonArray.forEach(x ->{
            Set<String> set = Sets.newLinkedHashSet(memberCompanyDTO.getWord().split(""));
            JSONObject j = (JSONObject)x;
            String name = j.getString("name");
            String[] names = (name.length() > 100 ? name.substring(0, 100) : name).split("");
            String str = "";
            if (names.length < name.length()) {
                str = "...";
            }
            boolean temp = false;
            for (int i = 0; i < names.length; i++) {
                //判断是否存在
                if (set.contains(names[i])) {
                    if (!temp) {
                        names[i] = "<span class=\"cust-name-light\" style=\"color: " + memberCompanyDTO.getHighlightColor() + ";\">" + names[i];
                        temp = true;
                    }
                } else {
                    if (temp) {
                        names[i] = "</span>" + names[i];
                        temp = false;
                    }
                }
            }
            if (temp) {
                names[names.length - 1] = names[names.length - 1] + "</span>";
            }
            CompanyInfoSearchVO companyInfoSearchVO = new CompanyInfoSearchVO();
            companyInfoSearchVO.setNameLight(StringUtils.join(names) + str);
            companyInfoSearchVO.setName(name);
            companyInfoSearchVOS.add(companyInfoSearchVO);
        });
        return companyInfoSearchVOS;
    }

    @Override
    public Boolean checkCompany(MemberCompanyDTO memberCompanyDTO) {
        JSONObject jsonObject = icClient.search(icToken, memberCompanyDTO.getWord());
        JSONObject result = JSON.parseObject(jsonObject.getString("result"));
        if (result == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_COMPANY);
        }
        JSONArray jsonArray = result.getJSONArray("items");
        boolean isExist = false;
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONObject j = (JSONObject)jsonArray.get(i);
            String creditCode = j.getString("creditCode");
            String name = j.getString("name");
            if (StringUtils.isNotBlank(creditCode) && StringUtils.equalsIgnoreCase(name, memberCompanyDTO.getWord())){
                isExist = true;
            }
        }
        return isExist;
    }

    @Override
    public String getPhone(String code) {
        String accessToken = tokenUtils.getWXToken();
        JSONObject jsonObject = wxClient.getuserphonenumber(accessToken, code);
        if (jsonObject.getIntValue("errcode") == 0){
            return jsonObject.getJSONObject("phone_info").getString("phoneNumber");
        }else {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_GET_WX_PHONE);
        }
    }



    @Override
    public MemberCountVO getCount() {
        MemberCountVO memberCountVO = new MemberCountVO();
        //获取当前用户的token,获取相关信息
        JSONObject json = StpUtil.getSession().getModel(UserSession.INFO,JSONObject.class);
        String id = json.getString("id");
        //获取当前用户的协作数
        QueryWrapper<Cooperation> wrapper = new QueryWrapper<>();
        wrapper.eq("member_id",id);
        memberCountVO.setCooperationNum(Math.toIntExact(cooperationMapper.selectCount(wrapper)));
        //获取当前用户的未读信息数
        QueryWrapper<MemberMessage> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("member_id",id)
                    .eq("is_read",MemberConstants.MemberMessageRead.UN_READ.code)
                    .eq("is_delete",MemberConstants.MemberIsDelete.NO.code);
        memberCountVO.setUnReadNum(Math.toIntExact(memberMessageMapper.selectCount(queryWrapper)));
        return memberCountVO;
    }

    @Override
    public Member queryInfoByToken() {
        Member member = memberMapper.selectById(Integer.parseInt((String) StpUtil.getLoginId()));
        if(MemberConstants.IsShowReason.NO.code.equals(member.getIsShowReason())){
            member.setReason(null);
        }
        if (StringUtils.isNotEmpty(member.getUnionId())){
            CommonResponse<Boolean> commonResponse = msgClient.queryWxSubscribeByUnionid(member.getUnionId());
            if (commonResponse.getData()){
                member.setSubscribe(true);
            }
        }
        return member;
    }

    @Override
    public Page<MemberPageVo> selectPage(MemberPageDTO memberPageDTO) {
        return memberMapper.getPage(memberPageDTO,memberPageDTO.buildPage());
    }

    @Override
    public Member queryWxInfo(QueryIdDTO queryIdDTO) {
        Member member = getById(queryIdDTO.getId());
        if (member.getState().equals(MemberConstants.MemberState.PASS.code)){
            return member;
        }
        throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_VIEW_MEMBER);
    }

    @Override
    public Boolean editIcon(MemberIconDTO memberIconDTO) {
        UpdateWrapper<Member> wrapper =new UpdateWrapper<>();
        wrapper.eq("id",StpUtil.getLoginId())
                .set("icon_url",memberIconDTO.getIconUrl());
        boolean result = update(wrapper);
        //更新redis数据
        StpUtil.getSession().set(UserSession.INFO,  (JSONObject) JSONObject.toJSON(memberMapper.selectById(Integer.parseInt((String)StpUtil.getLoginId()))));
        return result;
    }

    @Override
    public Boolean edit(MemberEditDTO memberEditDTO) {
        Member member = new Member();
        BeanUtil.copyProperties(memberEditDTO, member,true);
        member.setId(Integer.parseInt((String)StpUtil.getLoginId()));
        //重新编辑设置为待审核，原因清空
        member.setState(MemberConstants.MemberState.CHECK.code);
        member.setReason("");
        if (StringUtils.isEmpty(memberEditDTO.getPromoter())){
            member.setPromoter("");
            member.setCompanyName("");
        }else {
            List<String> companyNames = memberMapper.selectCompanyByPromoter(member.getPromoter());
            if (!companyNames.isEmpty() && companyNames.size() == 1){
                member.setCompanyName(companyNames.get(0));
            }else {
                member.setCompanyName("");
            }
        }
        if (memberMapper.updateById(member) == 1){
            //更新redis数据
            StpUtil.getSession().set(UserSession.INFO,  (JSONObject) JSONObject.toJSON(memberMapper.selectById(Integer.parseInt((String)StpUtil.getLoginId()))));
            return true;
        }
        return false;
    }

    @Override
    public Boolean adminEdit(MemberAdminEditDTO memberAdminEditDTO) {
        if(BeanUtil.isNotEmpty(memberAdminEditDTO.getCompetenceInfo())){
            if(memberAdminEditDTO.getCompetenceInfo().length()>300){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.THE_CORE_COMPETENCE_DESCRIPTION_CANNOT_EXCEED);
            }
        }
        Member member = new Member();
        BeanUtil.copyProperties(memberAdminEditDTO, member,new CopyOptions().setIgnoreCase(true).ignoreNullValue());
        //当修改所属公司时，根据所属公司推出所属大区
        if(BeanUtil.isNotEmpty(member.getCompanyName())){
            member.setAreaName(memberMapper.inferAreaName(member.getCompanyName()));
            //如果是未记录的公司
            if(BeanUtil.isEmpty(member.getAreaName())){
                member.setAreaName(MemberConstants.AreaType.OTHER.getMessage());
            }
        }
        member.setId(memberAdminEditDTO.getId());
        member.setUpdatedAt(LocalDateTime.now());
        if (memberMapper.updateById(member) == 1){
            return true;
        }
        return false;
    }

    @Override
    public List<String> queryDistinctCompanyName() {
        return memberMapper.selectAllCompanyName();
    }

    @Override
    public Map<String, Integer> countIndustry() {
        List<Map<String, Integer>> mapList = memberMapper.countIndustry();
        Map<String, Integer> countMap = new HashMap<>(mapList.size());
        mapList.forEach(
                item -> {
                    countMap.put(String.valueOf(item.get("industry")), Integer.parseInt(String.valueOf(item.get("count"))));
                }
        );
        return countMap;
    }

    @Override
    public Boolean open(MemberSupplierOpenDTO memberSupplierOpenDTO) {
        MemberSupplierOpenVO  memberSupplierOpenVO = memberMapper.selectByIdWithCustomer(memberSupplierOpenDTO.getId());
        if (memberSupplierOpenVO == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.USER_NOT_EXIST);
        }
        if (memberSupplierOpenVO.getState().intValue() != MemberConstants.MemberState.PASS.code){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_MEMBER_STATE);
        }
        if (memberSupplierOpenVO.getSupplierId() != null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.MEMBER_BIND_SUPPLIER);
        }
        SupplierDTO supplierDTO = new SupplierDTO();
        supplierDTO.setName(memberSupplierOpenVO.getCompany());
        supplierDTO.setCode(memberSupplierOpenVO.getLinkphone());
        supplierDTO.setCustId(memberSupplierOpenVO.getCustId());
        supplierDTO.setMemberId(memberSupplierOpenVO.getId());
        supplierDTO.setType(MemberConstants.SupplierSourceType.BACKGROUND_ADD.code);
        supplierDTO.setSend(memberSupplierOpenDTO.isSend());
        supplierDTO.setCreatedBy(memberSupplierOpenDTO.getCreatedBy());
        supplierDTO.setUpdatedBy(memberSupplierOpenDTO.getUpdatedBy());
        //添加供应商、用户及发送短信
        JsonResult<SupplierDTO> jsonResult = userClient.add(supplierDTO);
        if (jsonResult.isSuccess()){
            return true;
        }else {
            BaseExceptionDesc baseExceptionDesc = new BaseExceptionDesc(PurchaseBusinessExceptionDesc.ERROR_BIND_SUPPLIER.getCode(), jsonResult.getMsg());
            throw BusinessException.newInstance(baseExceptionDesc);
        }
    }

    @Override
    public Map<String,List<String>> inferCompanyName() {
        //获取公司表各所属大区下所属公司
        List<InferCompanyVO> inferCompanyName = memberMapper.inferCompanyName();
        Map<String,List<String>> map = new LinkedHashMap<>();
        inferCompanyName.forEach(e->{
            if(map.containsKey(e.getAreaName())){
                map.get(e.getAreaName()).add(e.getCompanyName());
            }else {
                List<String> list = new ArrayList<>();
                list.add(e.getCompanyName());
                map.put(e.getAreaName(),list);
            }
        });
        return map;
    }

    @Override
    public Map<String, Integer> countCompetence() {
        List<Map<String, Integer>> countMap = memberMapper.countCompetence();
        Map<String, Integer> competenceMap = new HashMap<>();
        countMap.forEach(e->{
            competenceMap.put(String.valueOf(e.get("competence")),e.get("count"));

        });
        return competenceMap;
    }

    @Override
    public IsIssueVO referMemberCooperation() {
        IsIssueVO isIssueVO = new IsIssueVO();
        isIssueVO.setIsIssue(isReferMemberCooperation);
        return isIssueVO;
    }

    @Override
    public List<StatisticsMemberVO> statistics(StatisticsMemberDTO statisticsMemberDTO) {
        if (StringUtils.equals(statisticsMemberDTO.getType(), MemberConstants.StatisticsType.INDUSTRY.code)){
            return memberMapper.statisticsIndustry();
        }else if (StringUtils.equals(statisticsMemberDTO.getType(), MemberConstants.StatisticsType.COMPETENCE.code)){
            return memberMapper.statisticsCompetence();
        }else {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.DATA_SYNCHRONIZATION_ERROR);
        }
    }

    @Override
    public Boolean invite(MemberInviteDTO memberInviteDTO) {
        Member member = memberMapper.selectById(memberInviteDTO.getMemberId());
        if (member == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_MEMBER);
        }
        JSONObject jsonObject = commonService.getCustInfo();
        String company = jsonObject.getString("company");
        String linkman = jsonObject.getString("linkman");
        String linkphone = jsonObject.getString("linkphone");
        //客户【烟台林德电气有限公司-张瑞-13259785881】发起对【都江堰市海天电器商行-刘易弘-15881063665】邀约聊天申请，请及时跟进处理
        noticeUtils.sendQywx("客户【" + company + "-" + linkman + "-" + linkphone + "】发起对【" + member.getCompany() + "-" + member.getLinkman() + "-" + member.getLinkphone() + "】邀约聊天申请，请及时跟进处理");

        //邀约聊天埋点
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("notify");
        triggerMsgRequest.setScene("memberInviteChat");
        JSONObject qywxParam = new JSONObject();
        qywxParam.put("msgtype", "template_card");

        JSONObject templateCard = new JSONObject();
        templateCard.put("card_type", "text_notice");

        JSONObject mainTitle = new JSONObject();
        mainTitle.put("title", "邀约聊天申请");
        mainTitle.put("desc", "企微拉群");
        templateCard.put("main_title", mainTitle);

        List<JSONObject> horizontalContentList = new ArrayList<>();
        JSONObject keyName1 = new JSONObject();
        keyName1.put("keyname", "发起会员");
        keyName1.put("value", company);
        horizontalContentList.add(keyName1);
        JSONObject keyName2 = new JSONObject();
        keyName2.put("keyname", "邀约会员");
        keyName2.put("value", member.getCompany());
        horizontalContentList.add(keyName2);
        JSONObject keyName3 = new JSONObject();
        keyName3.put("keyname", "提交时间");
        keyName3.put("value", DateUtil.format(LocalDateTime.now(), "yyyy/MM/dd HH:mm:ss"));
        horizontalContentList.add(keyName3);
        templateCard.put("horizontal_content_list", horizontalContentList);

        List<JSONObject> jumpList = new ArrayList<>();
        JSONObject jumpList1 = new JSONObject();
        jumpList1.put("type", 1);
        jumpList1.put("title", "跳转惠采");
        jumpList1.put("url", "https://huicai.zydonline.com/admin/#/purchase-member/cooperation");
        jumpList.add(jumpList1);
        templateCard.put("jump_list", jumpList);

        JSONObject cardAction = new JSONObject();
        cardAction.put("type", 1);
        cardAction.put("url",  "https://huicai.zydonline.com/admin/#/purchase-member/cooperation");
        templateCard.put("card_action", cardAction);

        qywxParam.put("template_card", templateCard);
        triggerMsgRequest.setQywxParam(qywxParam);
        msgClient.triggerMsg(triggerMsgRequest);
        return true;
    }

    @Override
    public Page<MemberPageVo> selectMallPage(MemberPageDTO memberPageDTO) {
        if (StpUtil.isLogin()){
            JSONObject jsonObject = commonService.getCustInfo();
            memberPageDTO.setMemberId(jsonObject.getInteger("memberId"));
            return memberMapper.selectMallPage(memberPageDTO, memberPageDTO.buildPage());
        }else {
            return memberMapper.selectMallPageNotLogin(memberPageDTO, memberPageDTO.buildPage());
        }
    }

    @Override
    public Member queryInfo(QueryIdDTO queryIdDTO) {
        Member member = memberMapper.queryInfo(queryIdDTO.getId());
        if (member != null && StringUtils.isNotEmpty(member.getSupplierId())){
            List<RecommendProductVO> recommendProductVOS = memberMapper.selectRecommendProduct(member.getSupplierId());
            if (!CollectionUtils.isEmpty(recommendProductVOS)){
                for (RecommendProductVO r : recommendProductVOS) {
                    if (StringUtils.isEmpty(r.getBrandImgUrl())){
                        StringBuilder brandImgUrl = new StringBuilder();
                        brandImgUrl.append(commonOssUrl).append("product/brand/").append(r.getBrandName() + "/").append(r.getBrandName() + "logo.png");
                        r.setBrandImgUrl(brandImgUrl.toString());
                    }
                }
                member.setRecommendProductVOS(recommendProductVOS);
            }
        }
        return member;
    }

    @Override
    public List<MemberStateVO> countNum(MemberNumDTO memberNumDTO) {
        List<MemberStateVO> list = new ArrayList<>();
        for(MemberConstants.MemberState e:MemberConstants.MemberState.values()){
            MemberStateVO memberStateVO = new MemberStateVO();
            memberStateVO.setState(String.valueOf(e.code));
            memberStateVO.setMemberStateNum(count(e.code, memberNumDTO));
            list.add(memberStateVO);
        }
        return list;
    }

    public Integer count(Integer code, MemberNumDTO memberNumDTO){
        QueryWrapper<Member> wrapper = new QueryWrapper<>();
        wrapper.eq(!Objects.equals(code, MemberConstants.MemberState.ALL.code),"state",code)
                .eq("is_inner", MemberConstants.IsInner.NO.code)
                .and(StringUtils.isNotBlank(memberNumDTO.getKey()), i-> i
                        .or().like("company", memberNumDTO.getKey())
                        .or().like("linkman", memberNumDTO.getKey())
                        .or().like("linkphone", memberNumDTO.getKey())
                        .or().like("promoter", memberNumDTO.getKey())
                        .or().like("wx_nick_name", memberNumDTO.getKey())
                )
                .eq(BeanUtil.isNotEmpty(memberNumDTO.getIsShow()),"is_show",memberNumDTO.getIsShow())
                .eq(StringUtils.isNotBlank(memberNumDTO.getIndustry()),"industry", memberNumDTO.getIndustry())
                .eq(StringUtils.isNotBlank(memberNumDTO.getCompetence()),"competence", memberNumDTO.getCompetence())
                .and(BeanUtil.isNotEmpty(memberNumDTO.getCompanyName())&&memberNumDTO.getCompanyName().size()>0,i->i
                        .in("company_name",memberNumDTO.getCompanyName())
                        .or(memberNumDTO.getCompanyName().contains("")).isNull(memberNumDTO.getCompanyName().contains(""),"company_name")
                )
                .gt(!ObjectUtils.isEmpty(memberNumDTO.getBeginTime()),"created_at", memberNumDTO.getBeginTime())
                .lt(!ObjectUtils.isEmpty(memberNumDTO.getEndTime()),"created_at", memberNumDTO.getEndTime());
        return Math.toIntExact(memberMapper.selectCount(wrapper));
    }
}
