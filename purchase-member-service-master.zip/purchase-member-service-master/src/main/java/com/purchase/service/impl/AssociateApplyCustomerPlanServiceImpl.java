package com.purchase.service.impl;

import com.purchase.entity.AssociateApplyCustomerPlan;
import com.purchase.mapper.AssociateApplyCustomerPlanMapper;
import com.purchase.service.AssociateApplyCustomerPlanService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 终端客户合作拓展计划 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-25
 */
@Service
public class AssociateApplyCustomerPlanServiceImpl extends ServiceImpl<AssociateApplyCustomerPlanMapper, AssociateApplyCustomerPlan> implements AssociateApplyCustomerPlanService {

}
