package com.purchase.service.vo;

import com.purchase.entity.Message;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class MessageInfoVO extends Message {

    @Schema(description = "接收对象")
    private String companyList;
}
