package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class MemberCooperationDTO extends PageDTO  {


    @Schema(description = "协作类型(resource=资源，need=需求)")
    private String type;
}
