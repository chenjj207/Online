package com.purchase.service.vo;

import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class MessagePageVO extends BaseEntity {


    @Schema(description = "公告标题")
    private String noticeTitle;

    @Schema(description = "公告详情")
    private String noticeInfo;


    @Schema(description = "附件路径")
    private String accessoryUrl;


    @Schema(description = "接收对象")
    private String companyList;

    @Schema(description = "当前用户id")
    private Integer memberId;

    @Schema(description = "会员公司")
    private String company;

    @Schema(description = "会员头像地址")
    private String iconUrl;

    @Schema(description = "发送方 当前用户id")
    private Integer sendMemberId;

    @Schema(description = "发送方 会员公司")
    private String sendCompany;

    @Schema(description = "发送方 会员头像地址")
    private String sendIconUrl;
}
