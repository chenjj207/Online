package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.entity.CooperationReply;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CooperationInfoVO;

import java.util.List;


/**
 * <p>
 * 协作回复表 服务类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
public interface CooperationReplyService extends IService<CooperationReply> {

    Boolean add(CooperationReplyAddDTO cooperationReplyAddDTO);

    List<CooperationReply> selectList(Integer id);

    CooperationInfoVO queryInfo(QueryIdDTO queryIdDTO);

    Boolean mallAdd(CooperationReplyMallAddDTO cooperationReplyMallAddDTO);

    Page<CooperationReply> mallPage(CooperationReplyPageDTO cooperationReplyPageDTO);

    Page<CooperationReply> page(CooperationReplyPageDTO cooperationReplyPageDTO);

    Boolean delete(CooperationReplyDeleteDTO cooperationReplyDeleteDTO);
}
