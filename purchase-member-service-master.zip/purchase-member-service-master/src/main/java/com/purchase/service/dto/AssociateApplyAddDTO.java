package com.purchase.service.dto;

import com.purchase.entity.AssociateApplyCustomerPlan;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.util.List;

/**
* <p>
* 联营申请表
* </p>
* @author jidonglin
* @since 2024-03-14
*/
@Data
@Schema(title = "联营申请表")
public class AssociateApplyAddDTO{

    private static final long serialVersionUID = 1L;


    @NotEmpty(message = "openId不能为空")
    @Schema(description = "openId")
    private String openId;

    @NotEmpty(message = "联营合作诉求不能为空")
    @Schema(description = "联营合作诉求")
    private String cooperationDemand;

    @NotEmpty(message = "合作项目不能为空")
    @Schema(description = "合作项目 产线联营、渠道联营、渠道联营+产线联营")
    private String cooperationProject;

    @NotEmpty(message = "公司名称不能为空")
    @Schema(description = "公司名称")
    private String company;

    @NotEmpty(message = "联系人不能为空")
    @Schema(description = "联系人")
    private String linkman;

    @NotEmpty(message = "手机号不能为空")
    @Schema(description = "手机号")
    private String linkphone;

    @NotEmpty(message = "短信验证码不能为空")
    @Schema(description = "短信验证码")
    private String smsCode;

    @NotEmpty(message = "省不能为空")
    @Schema(description = "省")
    private String province;

    @NotEmpty(message = "市不能为空")
    @Schema(description = "市")
    private String city;

    @NotEmpty(message = "区不能为空")
    @Schema(description = "区")
    private String area;

    @NotEmpty(message = "详细地址不能为空")
    @Schema(description = "详细地址")
    private String address;

    @NotEmpty(message = "员工数量不能为空")
    @Schema(description = "员工数量")
    private String userNum;

    @Schema(description = "基本资料-企业相关资料 如果申请合作项目选择仅为“渠道联营”才显示（json格式，多个@隔开：{\"license\":\"\",\"companyImage\":\"\",\"officeImage\":\"\"}）")
    /*
     * {
     *  "license": "",
     *  "companyImage": "",
     *  "officeImage": ""
     * }
     *
     */
    private String basicDetailInfo;

    @Schema(description = "企业相关资料-如果申请合作项目包含为“产线联营”才显示（json格式，多个@隔开：{\"license\":\"\",\"brandAgency\":\"\",\"trademarkRegistration\":\"\",\"productionLicense\":\"\",\"qualityManagement\":\"\",\"environmentalManagement\":\"\",\"threeCCertification\":\"\",\"nationalReport\":\"\",\"companyImage\":\"\",\"officeImage\":\"\",\"workshopImage\":\"\",\"otherFile\":\"\"}）")
    /*
     * {
     * 	"license": "",
     * 	"brandAgency": "",
     * 	"trademarkRegistration": "",
     * 	"productionLicense": "",
     * 	"qualityManagement": "",
     * 	"environmentalManagement": "",
     * 	"threeCCertification": "",
     * 	"nationalReport": "",
     * 	"companyImage": "",
     * 	"officeImage": "",
     * 	"workshopImage": "",
     * 	"otherFile": ""
     * }
     */
    private String cooperationDetailInfoUrl;

    @Schema(description = "公司主营业务")
    @NotEmpty(message = "公司主营业务不能为空")
    private String mainBusiness;

    @Schema(description = "商品供应性质")
    private String workingType;

    @NotNull(message = "公司年营业额不能为空")
    @Schema(description = "公司年营业额")
    @Digits(integer=6, fraction=4, message = "公司年营业额错误，请重新输入")
    private BigDecimal yearTurnover;

    @Schema(description = "公司经营性质")
    private String natureOperation;

    @NotEmpty(message = "主营产品不能为空")
    @Schema(description = "主营产品")
    private String mainProduct;

    @NotEmpty(message = "主营品牌不能为空")
    @Schema(description = "主营品牌")
    private String mainBrand;

    @Schema(description = "开户名称")
    @NotEmpty(message = "开户名称不能为空")
    private String accountName;

    @Schema(description = "银行账号")
    @NotEmpty(message = "银行账号不能为空")
    private String bankAccountNum;

    @Schema(description = "开户银行")
    @NotEmpty(message = "开户银行不能为空")
    private String openingBank;

    @Schema(description = "纳税人识别号")
    @NotEmpty(message = "纳税人识别号不能为空")
    private String taxIdentification;

    @NotEmpty(message = "所属大区不能为空")
    @Schema(description = "所属大区")
    private String areaName;

    @NotEmpty(message = "合作单位不能为空")
    @Schema(description = "合作单位")
    private String subCompany;

    @NotEmpty(message = "签约推荐人不能为空")
    @Schema(description = "签约推荐人")
    private String businessPerson;

    @Schema(description = "合作采购金额")
    @Digits(integer=6, fraction=4, message = "合作采购金额错误，请重新输入")
    private BigDecimal lastYearPurchaseZyd;

    @Schema(description = "计划采购金额")
    @Digits(integer=6, fraction=4, message = "计划采购金额错误，请重新输入")
    private BigDecimal thisYearSignPurchaseZyd;

    @Schema(description = "签约首单采购金额,如果申请合作项目选择包含“渠道联营”才显示")
    @Digits(integer=6, fraction=4, message = "签约首单采购金额错误，请重新输入")
    private BigDecimal firstOrderPurchase;

    @Schema(description = "全年指标")
    @Digits(integer=6, fraction=4, message = "全年指标金额错误，请重新输入")
    private BigDecimal annualTarget;

    @Schema(description = "第一季度指标")
    @Digits(integer=6, fraction=4, message = "第一季度指标金额错误，请重新输入")
    private BigDecimal firstQuarterTarget;

    @Schema(description = "第二季度指标")
    @Digits(integer=6, fraction=4, message = "第二季度指标金额错误，请重新输入")
    private BigDecimal secondQuarterTarget;

    @Schema(description = "第三季度指标")
    @Digits(integer=6, fraction=4, message = "第三季度指标金额错误，请重新输入")
    private BigDecimal thirdQuarterTarget;

    @Schema(description = "第四季度指标")
    @Digits(integer=6, fraction=4, message = "第四季度指标金额错误，请重新输入")
    private BigDecimal fourthQuarterTarget;

    @Schema(description = "合作计划")
    @Valid
    private List<AssociateApplyPlanAddDTO> associateApplyPlanAddDTOS;

    @Schema(description = "终端客户合作拓展计划")
    @Valid
    private List<AssociateApplyCustomerPlan> associateApplyCustomerPlans;

}
