package com.purchase.service.vo;

import com.purchase.entity.Message;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class MessageWxPageVO extends Message {
    @Schema(description = "信息是否已读，0未读,1已读")
    private String isRead;
}
