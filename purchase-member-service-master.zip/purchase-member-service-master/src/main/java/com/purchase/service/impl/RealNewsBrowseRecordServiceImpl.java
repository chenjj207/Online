package com.purchase.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.ObjectUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.RealNewsBrowseRecord;
import com.purchase.mapper.RealNewsBrowseRecordMapper;
import com.purchase.service.RealNewsBrowseRecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.RealNewsBrowseRecordPageDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * 资讯浏览记录 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-01
 */
@Service
public class RealNewsBrowseRecordServiceImpl extends ServiceImpl<RealNewsBrowseRecordMapper, RealNewsBrowseRecord> implements RealNewsBrowseRecordService {

    @Resource
    RealNewsBrowseRecordMapper realNewsBrowseRecordMapper;

    @Override
    public Page<RealNewsBrowseRecord> search(RealNewsBrowseRecordPageDTO realNewsBrowseRecordPageDTO) {
        QueryWrapper<RealNewsBrowseRecord> queryWrapper = new QueryWrapper<>();
        queryWrapper
                .eq(realNewsBrowseRecordPageDTO.getRealNewsId() != null,"real_news_id", realNewsBrowseRecordPageDTO.getRealNewsId())
                .orderByDesc("created_at");
        return realNewsBrowseRecordMapper.selectPage(realNewsBrowseRecordPageDTO.buildPage(), queryWrapper);
    }
}
