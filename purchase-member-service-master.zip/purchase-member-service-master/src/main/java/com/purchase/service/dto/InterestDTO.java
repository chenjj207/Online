package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
public class InterestDTO extends PageDTO {
    @NotEmpty(message = "id不能为空")
    @Schema(description = "资讯id")
   private   Integer id;
}
