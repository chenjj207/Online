package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
* <p>
* 联营协议表
* </p>
* @author jidonglin
* @since 2024-04-02
*/
@Data
@Schema(title = "联营协议 作废 归档")
public class AssociateProtocolEditStateDTO {


    @NotNull(message = "id不能为空")
    @Schema(description = "id")
    private Integer id;

    @Schema(description = "备注")
    private String remark;

    @Schema(description = "作废原因")
    private String cancelReason;

    @Schema(description = "状态 1、待生效 2、已生效   4、已作废")
    @NotEmpty(message = "状态 错误")
    @Pattern(regexp = "1|2|4",message = "状态参数错误")
    private String state;

}
