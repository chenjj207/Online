package com.purchase.service;

import com.purchase.entity.VisitLog;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 联营慧访问日志记录表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-06-29
 */
public interface VisitLogService extends IService<VisitLog> {

}
