package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class MessagePageDTO extends PageDTO {

    @Schema(description = "关键字")
    private String key;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "开始时间")
    private LocalDateTime beginTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "结束时间")
    private LocalDateTime endTime;

    @Schema(description = "会员Id")
    private Integer memberId;

    @Schema(description = "发送方 会员Id")
    private Integer sendMemberId;
}
