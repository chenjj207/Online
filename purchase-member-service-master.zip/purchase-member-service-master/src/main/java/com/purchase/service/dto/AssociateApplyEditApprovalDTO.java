package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
* <p>
* 联营申请表
* </p>
* @author jidonglin
* @since 2024-03-18
*/
@Data
@Schema(title = "联营申请表")
public class AssociateApplyEditApprovalDTO {

    private static final long serialVersionUID = 1L;


    @NotNull(message = "id不能为空")
    @Schema(description = "id")
    private Integer id;

    @Schema(description = "拒绝原因")
    private String rejectSignReason;

    @Schema(description = "状态")
    @NotEmpty(message = "状态不能为空")
    @Pattern(regexp = "4|5",message = "状态参数错误  4：同意签约 5：拒绝签约")
    private String state;


}
