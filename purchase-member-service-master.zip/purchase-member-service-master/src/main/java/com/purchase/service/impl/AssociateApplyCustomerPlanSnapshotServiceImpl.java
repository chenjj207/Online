package com.purchase.service.impl;

import com.purchase.entity.AssociateApplyCustomerPlanSnapshot;
import com.purchase.mapper.AssociateApplyCustomerPlanSnapshotMapper;
import com.purchase.service.AssociateApplyCustomerPlanSnapshotService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 终端客户合作拓展计划 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-15
 */
@Service
public class AssociateApplyCustomerPlanSnapshotServiceImpl extends ServiceImpl<AssociateApplyCustomerPlanSnapshotMapper, AssociateApplyCustomerPlanSnapshot> implements AssociateApplyCustomerPlanSnapshotService {

}
