package com.purchase.service.impl;

import com.purchase.entity.AssociateApplyProductPlanSnapshot;
import com.purchase.mapper.AssociateApplyProductPlanSnapshotMapper;
import com.purchase.service.AssociateApplyProductPlanSnapshotService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 计划合作产品基础信息 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-15
 */
@Service
public class AssociateApplyProductPlanSnapshotServiceImpl extends ServiceImpl<AssociateApplyProductPlanSnapshotMapper, AssociateApplyProductPlanSnapshot> implements AssociateApplyProductPlanSnapshotService {

}
