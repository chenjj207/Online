package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.AssociateAuth;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.AssociateAuthAddDTO;
import com.purchase.service.dto.AssociateAuthPageDTO;

/**
 * <p>
 * 联营授权 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-22
 */
public interface AssociateAuthService extends IService<AssociateAuth> {

    public Integer add(AssociateAuthAddDTO associateAuthAddDTO);

    public Page<AssociateAuth> queryList(AssociateAuthPageDTO associateAuthPageDTO);
}
