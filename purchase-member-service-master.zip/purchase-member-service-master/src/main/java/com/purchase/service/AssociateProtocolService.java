package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.AssociateProtocol;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.AssociateProtocoReadVO;
import com.purchase.service.vo.AssociateProtocolCountVO;

import java.util.List;

/**
 * <p>
 * 联营协议 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-04-01
 */
public interface AssociateProtocolService extends IService<AssociateProtocol> {

    public Page<AssociateProtocol> queryList(AssociateProtocolPageDTO associateProtocolPageDTO);

    public List<AssociateProtocolCountVO> countNum(AssociateProtocolCountDTO associateApplyCountDTO);

    public List<AssociateProtocol> queryByJsCode(AssociateProtocolQueryDTO associateProtocolQueryDTO);

    public Boolean editState(AssociateProtocolEditStateDTO associateProtocolEditStateDTO);

    public AssociateProtocoReadVO queryRead(AssociateProtocolQueryDTO associateProtocolQueryDTO);
}
