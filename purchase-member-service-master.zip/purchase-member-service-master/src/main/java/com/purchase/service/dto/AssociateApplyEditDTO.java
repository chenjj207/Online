package com.purchase.service.dto;

import com.purchase.entity.AssociateApplyCustomerPlan;
import com.purchase.entity.AssociateApplyProductPlan;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigDecimal;
import java.util.List;

/**
* <p>
* 联营申请表
* </p>
* @author jidonglin
* @since 2024-03-18
*/
@Data
@Schema(title = "联营申请表")
public class AssociateApplyEditDTO {

    private static final long serialVersionUID = 1L;


    @NotNull(message = "id不能为空")
    @Schema(description = "id")
    private Integer id;

    @Schema(description = "备注")
    private String remark;

    @Schema(description = "联营合作诉求")
    private String cooperationDemand;

    @Schema(description = "合作项目 产线联营、渠道联营、渠道联营+产线联营")
    private String cooperationProject;

    @Schema(description = "公司名称")
    private String company;

    @Schema(description = "联系人")
    private String linkman;

    @Schema(description = "手机号")
    private String linkphone;

    @Schema(description = "短信验证码")
    private String smsCode;

    @Schema(description = "省")
    private String province;

    @Schema(description = "市")
    private String city;

    @Schema(description = "区")
    private String area;

    @Schema(description = "详细地址")
    private String address;

    @Schema(description = "员工数量")
    private String userNum;

    @Schema(description = "基本资料-企业相关资料 如果申请合作项目选择仅为“渠道联营”才显示")
    private String basicDetailInfo;

    @Schema(description = "企业相关资料-如果申请合作项目包含为“产线联营”才显示")
    private String cooperationDetailInfoUrl;

    @Schema(description = "公司主营业务")
    @NotEmpty(message = "公司主营业务不能为空")
    private String mainBusiness;

    @Schema(description = "商品供应性质")
    private String workingType;

    @Schema(description = "公司年营业额")
    @Digits(integer=6, fraction=4, message = "公司年营业额错误，请重新输入")
    private BigDecimal yearTurnover;

    @Schema(description = "公司经营性质")
    private String natureOperation;

    @Schema(description = "主营产品")
    private String mainProduct;

    @Schema(description = "主营品牌")
    private String mainBrand;

    @Schema(description = "开户名称")
    private String accountName;

    @Schema(description = "银行账号")
    private String bankAccountNum;

    @Schema(description = "开户银行")
    private String openingBank;

    @Schema(description = "纳税人识别号")
    private String taxIdentification;

    @Schema(description = "所属大区")
    private String areaName;

    @Schema(description = "合作单位")
    private String subCompany;

    @Schema(description = "签约推荐人")
    private String businessPerson;

    @Schema(description = "合作采购金额")
    @Digits(integer=6, fraction=4, message = "合作采购金额错误，请重新输入")
    private BigDecimal lastYearPurchaseZyd;

    @Schema(description = "计划采购金额")
    @Digits(integer=6, fraction=4, message = "计划采购金额错误，请重新输入")
    private BigDecimal thisYearSignPurchaseZyd;

    @Schema(description = "签约首单采购金额,如果申请合作项目选择包含“渠道联营”才显示")
    @Digits(integer=6, fraction=4, message = "签约首单采购金额错误，请重新输入")
    private BigDecimal firstOrderPurchase;

    @Schema(description = "全年指标")
    @Digits(integer=6, fraction=4, message = "全年指标金额错误，请重新输入")
    private BigDecimal annualTarget;

    @Schema(description = "第一季度指标")
    @Digits(integer=6, fraction=4, message = "第一季度指标金额错误，请重新输入")
    private BigDecimal firstQuarterTarget;

    @Schema(description = "第二季度指标")
    @Digits(integer=6, fraction=4, message = "第二季度指标金额错误，请重新输入")
    private BigDecimal secondQuarterTarget;

    @Schema(description = "第三季度指标")
    @Digits(integer=6, fraction=4, message = "第三季度指标金额错误，请重新输入")
    private BigDecimal thirdQuarterTarget;

    @Schema(description = "第四季度指标")
    @Digits(integer=6, fraction=4, message = "第四季度指标金额错误，请重新输入")
    private BigDecimal fourthQuarterTarget;

    @Schema(description = "合作计划")
    @Valid
    private List<AssociateApplyPlanEditDTO> associateApplyProductPlans;

    @Schema(description = "终端客户合作拓展计划")
    @Valid
    private List<AssociateApplyCustomerPlan> associateApplyCustomerPlans;
}
