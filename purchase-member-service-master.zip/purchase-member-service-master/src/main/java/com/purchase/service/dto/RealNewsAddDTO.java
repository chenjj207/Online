package com.purchase.service.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.purchase.entity.RealNews;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/2/3  15:54
 */
@Data
public class RealNewsAddDTO extends BaseEntity {

    @Schema(description = "资讯标题")
    @NotEmpty(message = "资讯标题必填")
    private String consultTitle;

    @Schema(description = "资讯内容")
    @NotEmpty(message = "资讯内容必填")
    private String consultInfo;

    @Schema(description = "是否显示(0为发布，1为未发布)")
    @NotNull(message = "是否显示必填")
    private Integer isShow;

    @NotBlank(message = "资讯发布者必填")
    @Schema(description = "资讯发布者")
    private String publisher;

    @Schema(description = "主图")
    private String firstPic;

    @NotNull(message = "参数不能为空")
    @Schema(description = "是否开启感兴趣(0为未开启，1为开启)")
    private Integer isOpenInterested;

    @NotBlank(message = "不能为空")
    @Schema(description = "发布页面")
    private String page;

    @Schema(description = "资讯类型")
    @NotEmpty(message = "资讯类型必填")
    private String consultType;

    @Schema(description = "慧资源 类型明细")
    private String resourceType;

}
