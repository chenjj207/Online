package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
* <p>
* 品牌授权协议存档
* </p>
*
* @author jidonglin
* @since 2024-06-03
*/
@Data
@Schema(title = "品牌授权协议存档")
public class BrandAuthProtocolPageDTO  extends PageDTO {

    @Schema(description = "品牌授权id")
    @NotNull(message = "品牌授权id不能为空")
    private Integer brandAuthId;

}
