package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;


@Data
public class CooperationReplyAddDTO {

    @Schema(description = "协作id")
    private Integer teamId;

    @NotBlank(message = "创建者不能为空")
    @Schema(description = "创建者")
    private String createdBy;

    @NotBlank(message = "信息不能为空")
    @Schema(description = "协作信息")
    private String content;

    @Schema(description = "会员id")
    private Integer memberId;
}
