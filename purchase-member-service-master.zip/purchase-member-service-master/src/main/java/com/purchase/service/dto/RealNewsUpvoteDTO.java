package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
public class RealNewsUpvoteDTO {
    @NotEmpty(message = "id不能为空")
    @Schema(description = "资讯id")
    private Integer realNewsId;

    @Schema(description = "是否PC端")
    private boolean isPc = false;
}
