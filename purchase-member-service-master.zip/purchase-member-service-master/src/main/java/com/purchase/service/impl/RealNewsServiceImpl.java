package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.net.NetUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.ObjectUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.client.WXClient;
import com.purchase.common.MemberConstants;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.RealNews;
import com.purchase.entity.RealNewsBrowseRecord;
import com.purchase.mapper.CooperationMapper;
import com.purchase.mapper.RealNewsBrowseRecordMapper;
import com.purchase.mapper.RealNewsMapper;
import com.purchase.service.CommonService;
import com.purchase.service.RealNewsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.*;
import com.purchase.service.vo.InterestListVO;
import com.purchase.service.vo.RealNewsInfoVO;
import com.purchase.service.vo.RealNewsVO;
import com.purchase.utils.TokenUtils;
import com.zyd.framework.boot.config.log.CommonLog;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;

/**
 * <p>
 * 资讯表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-02-03
 */
@Service
public class RealNewsServiceImpl extends ServiceImpl<RealNewsMapper, RealNews> implements RealNewsService {

    @Resource
    private RealNewsMapper realNewsMapper;
    @Resource
    private CooperationMapper cooperationMapper;
    @Resource
    RealNewsBrowseRecordMapper realNewsBrowseRecordMapper;
    @Resource
    private WXClient wxClient;
    @Autowired
    private TokenUtils tokenUtils;
    @Autowired
    private CommonService commonService;

    @Override
    public Page<RealNews> search(RealNewsPageDTO realNewsPageDTO) {
        QueryWrapper<RealNews> queryWrapper = new QueryWrapper<>();
        queryWrapper
                .eq(!ObjectUtil.isEmpty(realNewsPageDTO.getIsShow()),"is_show", realNewsPageDTO.getIsShow())
                .eq(StringUtils.isNotBlank(realNewsPageDTO.getConsultType()),"consult_type",realNewsPageDTO.getConsultType())
                .and(StringUtils.isNotBlank(realNewsPageDTO.getKey()),i->i
                        .or().like("created_by",realNewsPageDTO.getKey())
                        .or().like("consult_title", realNewsPageDTO.getKey()))
                .gt(!ObjectUtils.isEmpty(realNewsPageDTO.getBeginTime()),"created_at",realNewsPageDTO.getBeginTime())
                .lt(!ObjectUtils.isEmpty(realNewsPageDTO.getEndTime()),"created_at",realNewsPageDTO.getEndTime())
                .orderByDesc("created_at");
        return realNewsMapper.selectPage(realNewsPageDTO.buildPage(), queryWrapper);
    }

    @Override
    public boolean save(RealNewsAddDTO realNewsAddDTO) {
        RealNews realNews = new RealNews();
        BeanUtil.copyProperties(realNewsAddDTO, realNews);
        if(!StringUtils.equals(realNewsAddDTO.getConsultType(), "慧资源")){
            realNews.setResourceType(null);
        }
        realNews.setCreatedAt(LocalDateTime.now());
        return realNewsMapper.insert(realNews) == 1 ? true : false;
    }

    @Override
    public boolean edit(RealNewsEditDTO realNewsEditDTO) {
        RealNews realNews = new RealNews();
        BeanUtil.copyProperties(realNewsEditDTO, realNews);
        realNews.setUpdatedAt(LocalDateTime.now());
        return realNewsMapper.updateById(realNews) == 1 ? true : false;
    }

    @Override
    @Transactional(rollbackFor = Exception.class,isolation = Isolation.REPEATABLE_READ)
    public RealNews info(WxQueryIdDTO wxQueryIdDTO, HttpServletRequest httpServletRequest) {
        RealNews realNews = getById(wxQueryIdDTO.getId());
        if(ObjectUtil.isAllEmpty(realNews)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_REAL_NEWS);
        }
        if(BeanUtil.isEmpty(wxQueryIdDTO.getIsRecord())||MemberConstants.Record.YES.code.equals(wxQueryIdDTO.getIsRecord())){
            updateBrowseNum(wxQueryIdDTO.getId(), httpServletRequest);
        }
        if (StpUtil.isLogin()){
            RealNewsInfoVO realNewsInfoVO = new RealNewsInfoVO();
            BeanUtil.copyProperties(realNews,realNewsInfoVO);
            List<String> memberInterestList = realNewsMapper.memberList(wxQueryIdDTO.getId());
            realNewsInfoVO.setIsInterest(CollUtil.contains(memberInterestList, StpUtil.getLoginId()));
            return realNewsInfoVO;
        }
        return realNews;
    }

    @Override
    public RealNews mallInfo(WxQueryIdDTO wxqueryIdDTO, HttpServletRequest httpServletRequest) {
        RealNews realNews = getById(wxqueryIdDTO.getId());
        if(ObjectUtil.isAllEmpty(realNews)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_REAL_NEWS);
        }
        if(BeanUtil.isEmpty(wxqueryIdDTO.getIsRecord())||MemberConstants.Record.YES.code.equals(wxqueryIdDTO.getIsRecord())){
            updateBrowseNum(wxqueryIdDTO.getId(), httpServletRequest);
        }
        if (StpUtil.isLogin()){
            RealNewsInfoVO realNewsInfoVO = new RealNewsInfoVO();
            BeanUtil.copyProperties(realNews,realNewsInfoVO);
            List<String> memberInterestList = realNewsMapper.memberList(wxqueryIdDTO.getId());
            realNewsInfoVO.setIsInterest(CollUtil.contains(memberInterestList, commonService.memberId()));
            return realNewsInfoVO;
        }
        return realNews;
    }


    public void updateBrowseNum(Integer id, HttpServletRequest httpServletRequest) {
        Integer browseNum = realNewsMapper.selectBrowseNum(id);
        UpdateWrapper<RealNews> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id",id).set("browse_num",browseNum+1);
        update(updateWrapper);

        //增加浏览记录
        RealNewsBrowseRecord realNewsBrowseRecord = new RealNewsBrowseRecord();
        if (StpUtil.isLogin()){
            realNewsBrowseRecord.setCompanyName(commonService.getCustInfo().getString("company"));
            realNewsBrowseRecord.setLinkphone(commonService.getCustInfo().getString("linkphone"));
        }
        realNewsBrowseRecord.setIpAddress(CommonLog.getIpAddress(httpServletRequest));
        realNewsBrowseRecord.setCreatedAt(LocalDateTime.now());
        realNewsBrowseRecord.setCreatedBy("system");
        realNewsBrowseRecord.setRealNewsId(id);
        realNewsBrowseRecordMapper.insert(realNewsBrowseRecord);
    }


    @Override
    public Page<RealNews> pageSearch(RealNewsWXPageDTO realNewsWXPageDTO) {
        QueryWrapper<RealNews> queryWrapper = new QueryWrapper<>();
        queryWrapper
                .eq("is_show", MemberConstants.RealNewShow.ISSUE.code)
                .eq(StringUtils.isNotBlank(realNewsWXPageDTO.getConsultType()),"consult_type",realNewsWXPageDTO.getConsultType())
                .orderByDesc("created_at");
        return realNewsMapper.selectPage(realNewsWXPageDTO.buildPage(), queryWrapper);
    }

    @Override
    public String preview(RealNewsSenceDTO realNewsSenceDTO) {
        String wxToken = tokenUtils.getWXToken();
        byte[] result = wxClient.getwxacodeunlimit(wxToken, realNewsSenceDTO.getScene(), "pages/info-view/index", "release");
        return Base64.getEncoder().encodeToString(result);
    }

    @Override
    public Page<RealNewsVO> searchPage(RealNewsPageDTO realNewsPageDTO) {
        return realNewsMapper.searchPage(realNewsPageDTO,realNewsPageDTO.buildPage());
    }

    @Override
    public Page<InterestListVO> interestList(InterestDTO interestDTO) {
        return realNewsMapper.interestList(interestDTO,interestDTO.buildPage());
    }

    @Override
    public RealNews pcInfo(QueryIdDTO queryIdDTO) {
        RealNews realNews = getById(queryIdDTO.getId());
        if(ObjectUtil.isAllEmpty(realNews)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_REAL_NEWS);
        }
        return realNews;
    }

    @Override
    public Page<RealNews> mallResourcePage(RealNewsResourceDTO realNewsResourceDTO) {
        if (StringUtils.equals(realNewsResourceDTO.getTabType(), MemberConstants.ResourceTabType.PRODUCT.code)){
            realNewsResourceDTO.setResourceType(MemberConstants.ResourceType.PRODUCT.code);
            return realNewsMapper.resourcePage(realNewsResourceDTO, realNewsResourceDTO.buildPage());
        }else if (StringUtils.equals(realNewsResourceDTO.getTabType(), MemberConstants.ResourceTabType.SERVICE.code)){
            realNewsResourceDTO.setResourceType(MemberConstants.ResourceType.SERVICE.code);
            return realNewsMapper.resourcePage(realNewsResourceDTO, realNewsResourceDTO.buildPage());
        }else if (StringUtils.equals(realNewsResourceDTO.getTabType(), MemberConstants.ResourceTabType.PUBLISH_SELF.code)){
            JSONObject jsonObject = commonService.getCustInfo();
            realNewsResourceDTO.setMemberId(jsonObject.getInteger("memberId"));
            return realNewsMapper.resourcePublishSelfPage(realNewsResourceDTO, realNewsResourceDTO.buildPage());
        }else {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_RESOURCE_TYPE);
        }
    }

    @Override
    public Page<RealNews> mallNeedPage(RealNewsNeedDTO realNewsNeedDTO) {
        if (StringUtils.equals(realNewsNeedDTO.getTabType(), "1")){
            //未参与未过期
            if (StpUtil.isLogin()){
                JSONObject jsonObject = commonService.getCustInfo();
                realNewsNeedDTO.setMemberId(jsonObject.getInteger("memberId"));
            }
            return realNewsMapper.needNotInPage(realNewsNeedDTO, realNewsNeedDTO.buildPage());
        }else if (StringUtils.equals(realNewsNeedDTO.getTabType(), "2")){
            //已参与
            if (!StpUtil.isLogin()){
                //未登录
                return new Page<>();
            }
            JSONObject jsonObject = commonService.getCustInfo();
            realNewsNeedDTO.setMemberId(jsonObject.getInteger("memberId"));
            return realNewsMapper.needInPage(realNewsNeedDTO, realNewsNeedDTO.buildPage());
        }else if (StringUtils.equals(realNewsNeedDTO.getTabType(), "3")){
            if (!StpUtil.isLogin()){
                //未登录
                return new Page<>();
            }
            //未参与已过期
            JSONObject jsonObject = commonService.getCustInfo();
            realNewsNeedDTO.setMemberId(jsonObject.getInteger("memberId"));
            return realNewsMapper.needExpirePage(realNewsNeedDTO, realNewsNeedDTO.buildPage());
        }else if (StringUtils.equals(realNewsNeedDTO.getTabType(), "4")){
            JSONObject jsonObject = commonService.getCustInfo();
            realNewsNeedDTO.setMemberId(jsonObject.getInteger("memberId"));
            return realNewsMapper.needPublishSelfPage(realNewsNeedDTO, realNewsNeedDTO.buildPage());
        }else {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_NEED_TAB);
        }
    }

}
