package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
public class MemberMessageEditDTO {


    @Schema(description = "需要编辑的公告id")
    private List<Integer> messageIdList;
}
