package com.purchase.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.core.util.URLUtil;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.PutObjectRequest;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.client.WXClient;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.client.feign.MsgClient;
import com.purchase.common.MemberConstants;
import com.purchase.config.OssConf;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.*;
import com.purchase.feign.UserClient;
import com.purchase.feign.param.JsonResult;
import com.purchase.feign.param.SupplierDTO;
import com.purchase.mapper.*;
import com.purchase.service.*;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CommonCountVO;
import com.purchase.service.vo.SubCompanyVO;
import com.zyd.framework.utils.exception.BaseExceptionDesc;
import com.zyd.framework.utils.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.time.LocalDateTime;
import java.util.*;

/**
 * <p>
 * 联营申请表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-14
 */
@Service
@Slf4j
public class AssociateApplyServiceImpl extends ServiceImpl<AssociateApplyMapper, AssociateApply> implements AssociateApplyService {

    @Resource
    AssociateApplyProductPlanMapper associateApplyProductPlanMapper;
    @Resource
    AssociateApplyCustomerPlanMapper associateApplyCustomerPlanMapper;
    @Resource
    AssociateApplyMapper associateApplyMapper;
    @Resource
    AssociatePromotionMapper associatePromotionMapper;
    @Resource
    MemberMapper memberMapper;
    @Resource
    AssociateProtocolMapper associateProtocolMapper;
    @Resource
    BrandAuthApplyMapper brandAuthApplyMapper;
    @Resource
    AssociateApplySnapshotMapper associateApplySnapshotMapper;
    @Autowired
    AssociateApplyCustomerPlanSnapshotService associateApplyCustomerPlanSnapshotService;
    @Autowired
    AssociateApplyProductPlanSnapshotService associateApplyProductPlanSnapshotService;
    @Autowired
    CommonService commonService;
    @Autowired
    AssociateApplyProductPlanService associateApplyProductPlanService;
    @Autowired
    AssociateApplyCustomerPlanService associateApplyCustomerPlanService;
    @Resource
    private WXClient wxClient;
    @Resource
    private MsgClient msgClient;

    @Resource
    UserClient userClient;

    @Autowired
    OssConf ossConfig;

    @Value("${wx.appid}")
    String appid;
    @Value("${wx.secret}")
    String secret;
    @Value("${associateApplyAllAuth}")
    String associateApplyAllAuth;
    @Value("${odsUrl}")
    String odsUrl;

    @Value("${fontPath}")
    String fontPath;
    @Value("${cxProtocol}")
    String cxProtocol;
    @Value("${qdProtocol}")
    String qdProtocol;
    @Value("${associateApplyOnlyProduction}")
    String associateApplyOnlyProduction;

    @Autowired
    AliSmsService aliSmsService;

    @Override
    @Transactional
    public String add(AssociateApplyAddDTO associateApplyAddDTO) {
        if (StringUtils.equals("渠道联营", associateApplyAddDTO.getCooperationProject())){
            if (StringUtils.isEmpty(associateApplyAddDTO.getBasicDetailInfo())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_FILE_INFO);
            }
            try {
                JSONObject o = JSONObject.parseObject(associateApplyAddDTO.getBasicDetailInfo());
                if (o.get("license") == null || o.get("companyImage") == null || o.get("officeImage") == null) {
                    throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_FILE_INFO);
                }
            } catch (Exception e) {
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_FILE_INFO, "参数格式有误");
            }
        }

        if (StrUtil.contains( associateApplyAddDTO.getCooperationProject(), "产线联营")){
            if (StringUtils.isEmpty(associateApplyAddDTO.getCooperationDetailInfoUrl())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_COOPERATION_PROJECT);
            }
            if (StringUtils.isEmpty(associateApplyAddDTO.getWorkingType())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_WORKING_TYPE);
            }

            if (CollectionUtil.isEmpty(associateApplyAddDTO.getAssociateApplyPlanAddDTOS())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.COOPERATION_INCOMPLETE_PARAMETERS);
            }
            if (StringUtils.isEmpty(associateApplyAddDTO.getCooperationDetailInfoUrl())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_FILE_INFO);
            }
            try {
                JSONObject o = JSONObject.parseObject(associateApplyAddDTO.getCooperationDetailInfoUrl());
                if (o.get("license") == null || o.get("productionLicense") == null || o.get("qualityManagement") == null || o.get("environmentalManagement") == null || o.get("threeCCertification") == null || o.get("nationalReport") == null || o.get("companyImage") == null || o.get("officeImage") == null || o.get("officeImage") == null || o.get("workshopImage") == null) {
                    throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_FILE_INFO);
                }
            } catch (Exception e) {
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_FILE_INFO, "参数格式有误");
            }
            boolean existNull = false;
            for (AssociateApplyPlanAddDTO a : associateApplyAddDTO.getAssociateApplyPlanAddDTOS()) {
                if (StringUtils.isEmpty(a.getBrand()) || StringUtils.isEmpty(a.getProductName()) || a.getLastYearSaleVolume() == null || a.getMarketCapacity() == null || a.getPlanSkuNum() == null){
                    existNull = true;
                    break;
                }
            }
            if (existNull){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.COOPERATION_INCOMPLETE_PARAMETERS);
            }
        }

        if (StrUtil.contains( associateApplyAddDTO.getCooperationProject(), "渠道联营")){
            if (StringUtils.isEmpty(associateApplyAddDTO.getNatureOperation())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_NATURE_OPERATION);
            }
            if (associateApplyAddDTO.getLastYearPurchaseZyd() == null){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_LAST_YEAR_PURCHASE);
            }
            if (associateApplyAddDTO.getThisYearSignPurchaseZyd() == null){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_THIS_YEAR_PURCHASE);
            }
            if (associateApplyAddDTO.getFirstOrderPurchase() == null){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_FIRST_ORDER_PURCHASE);
            }
            if (associateApplyAddDTO.getAnnualTarget() == null || associateApplyAddDTO.getFirstQuarterTarget() == null || associateApplyAddDTO.getSecondQuarterTarget() == null || associateApplyAddDTO.getThirdQuarterTarget() == null || associateApplyAddDTO.getFourthQuarterTarget() == null){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.TARGET_INCOMPLETE_PARAMETERS);
            }

            if (CollectionUtils.isEmpty(associateApplyAddDTO.getAssociateApplyCustomerPlans()) || associateApplyAddDTO.getAssociateApplyCustomerPlans().size() > 8){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_NUM_CUST_PLAN);
            }
            boolean existNull = false;
            for (AssociateApplyCustomerPlan a : associateApplyAddDTO.getAssociateApplyCustomerPlans()) {
                if (StringUtils.isEmpty(a.getCustName()) || StringUtils.isEmpty(a.getExpectResult()) || StringUtils.isEmpty(a.getMainProject()) || StringUtils.isEmpty(a.getPromotionPlan())){
                    existNull = true;
                    break;
                }
            }
            if (existNull){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.CUST_PLAN_INCOMPLETE_PARAMETERS);
            }
        }
        //get请求 https://api.weixin.qq.com/sns/jscode2session 获取session_key，unionid，openid等数据
//        JSONObject jsonObject = wxClient.jscode2session(appid, secret, associateApplyAddDTO.getJsCode());
//        if (jsonObject.containsKey("errcode") && jsonObject.getInteger("errcode") != 0){
//            log.error(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getCode() + ": " +
//                    PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getDesc() + ": " + jsonObject.getString("errmsg"));
//            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR);
//        }
//        String openid = jsonObject.getString("openid");
//        String unionid = jsonObject.getString("unionid");
        String openid = associateApplyAddDTO.getOpenId();
        String unionid = "";
        //校验验证码
        aliSmsService.valid("ASSOCIATE_APPLY", associateApplyAddDTO.getLinkphone(), associateApplyAddDTO.getSmsCode());
        LocalDateTime now = LocalDateTime.now();
        int year = now.getYear();
        int applyNf = now.getYear();
        int month = now.getMonthValue();
        int dayOfMonth = now.getDayOfMonth();
        if (month < 12){
            //如果小于12月，那么申请的年份是当年
        }else {
            //如果大于等于12月，那么申请的年份就是明年
            applyNf = year + 1;
        }

        //查询项目推广专员
        QueryWrapper<AssociatePromotion> associatePromotionQueryWrapper = new QueryWrapper<>();
        associatePromotionQueryWrapper.eq("company_name", associateApplyAddDTO.getSubCompany());
        List<AssociatePromotion> associatePromotions = associatePromotionMapper.selectList(associatePromotionQueryWrapper);
        if (CollectionUtil.isEmpty(associatePromotions)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PROMOTION);
        }
        AssociateApply associateApply = new AssociateApply();
        QueryWrapper<AssociateApply> associateApplyQueryWrapper1 = new QueryWrapper<>();
        associateApplyQueryWrapper1.eq("open_id", openid);
        List<AssociateApply> associateApplyList1 = this.list(associateApplyQueryWrapper1);

        if (CollectionUtil.isNotEmpty(associateApplyList1)){
            for (AssociateApply  a : associateApplyList1) {
                if (!StringUtils.equals(a.getCompany(), associateApplyAddDTO.getCompany())){
                    throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_ASSOCIATE_COMPANY);
                }
                if (StringUtils.equals(a.getCooperationDemand(), associateApplyAddDTO.getCooperationProject())){
                    //如果同一年份存在相同的合作项目，则抛出异常
                    if (applyNf == a.getApplyNf()){
                        throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.EXIST_COMPANY_ASSOCIATE);
                    }
                }
            }
        }
        //新增
        QueryWrapper<AssociateApply> associateApplyQueryWrapper2 = new QueryWrapper<>();
        associateApplyQueryWrapper2.eq("company", associateApplyAddDTO.getCompany());
        associateApplyQueryWrapper2.eq("cooperation_project", associateApplyAddDTO.getCooperationProject());
        associateApplyQueryWrapper2.eq("apply_nf", applyNf);
        List<AssociateApply> associateApplyList2 = this.list(associateApplyQueryWrapper2);
        if (CollectionUtil.isNotEmpty(associateApplyList2)){
            //判断【公司+合作项目】是否已存在申请
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.EXIST_COMPANY_ASSOCIATE);
        }

        // 申请id，现在同时只能申请一种渠道
        Integer associateApplyId = null;
        //分开两个联营申请添加
        boolean qudao = false;
        if (StrUtil.contains(associateApplyAddDTO.getCooperationProject(), "渠道联营")){
            if (associateApplyAddDTO.getAnnualTarget()
                    .compareTo(associateApplyAddDTO.getFirstQuarterTarget().add(associateApplyAddDTO.getSecondQuarterTarget()).add(associateApplyAddDTO.getThirdQuarterTarget()).add(associateApplyAddDTO.getFourthQuarterTarget())) != 0){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_EQUAL_ANNUAL_TARGET);
            }
            associateApply = BeanUtil.copyProperties(associateApplyAddDTO, AssociateApply.class, "id", "createdAt", "updatedAt");
            associateApply.setOpenId(openid);
            associateApply.setUnionId(unionid);
            associateApply.setApplyNf(applyNf);
            associateApply.setPromotionPerson(associatePromotions.get(0).getPromotionPerson());
            associateApply.setCooperationProject("渠道联营");
            associateApply.setWorkingType(null);
            associateApply.setCooperationDetailInfoUrl(null);
            associateApply.setState(MemberConstants.AssociateApplyState.PENDING_RESEARCH.code);
            associateApply.setCreatedAt(now);
            associateApply.setCreatedBy(openid);
            this.save(associateApply);
            associateApplyId = associateApply.getId();
            qudao = true;

            List<AssociateApplyCustomerPlan> customerPlanList = new ArrayList<>();
            if (StrUtil.contains(associateApplyAddDTO.getCooperationProject(), "渠道联营") && CollectionUtil.isNotEmpty(associateApplyAddDTO.getAssociateApplyCustomerPlans())){
                for (AssociateApplyCustomerPlan a : associateApplyAddDTO.getAssociateApplyCustomerPlans()) {
                    AssociateApplyCustomerPlan associateApplyCustomerPlan = BeanUtil.copyProperties(a, AssociateApplyCustomerPlan.class, "id", "createdAt", "updatedAt");
                    associateApplyCustomerPlan.setApplyId(associateApply.getId());
                    associateApplyCustomerPlan.setCreatedAt(now);
                    associateApplyCustomerPlan.setCreatedBy(openid);
                    customerPlanList.add(associateApplyCustomerPlan);
                }
            }
            associateApplyCustomerPlanService.saveBatch(customerPlanList);
        }

        boolean chanxian = false;
        if (StrUtil.contains(associateApplyAddDTO.getCooperationProject(), "产线联营")){
            associateApply = BeanUtil.copyProperties(associateApplyAddDTO, AssociateApply.class, "id", "createdAt", "updatedAt");
            associateApply.setOpenId(openid);
            associateApply.setUnionId(unionid);
            associateApply.setApplyNf(applyNf);
            associateApply.setPromotionPerson(associatePromotions.get(0).getPromotionPerson());
            associateApply.setCooperationProject("产线联营");
            associateApply.setNatureOperation(null);
            associateApply.setLastYearPurchaseZyd(null);
            associateApply.setThisYearSignPurchaseZyd(null);
            associateApply.setFirstOrderPurchase(null);
            associateApply.setAnnualTarget(null);
            associateApply.setFirstQuarterTarget(null);
            associateApply.setSecondQuarterTarget(null);
            associateApply.setThirdQuarterTarget(null);
            associateApply.setFourthQuarterTarget(null);
            associateApply.setBasicDetailInfo(null);
            associateApply.setState(MemberConstants.AssociateApplyState.PENDING_RESEARCH.code);
            associateApply.setCreatedAt(now);
            associateApply.setCreatedBy(openid);
            this.save(associateApply);
            associateApplyId = associateApply.getId();
            chanxian = true;

            List<AssociateApplyProductPlan> associateApplyProductPlanList = new ArrayList<>();
            if (StrUtil.contains(associateApplyAddDTO.getCooperationProject(), "产线联营") && CollectionUtil.isNotEmpty(associateApplyAddDTO.getAssociateApplyPlanAddDTOS())){
                for (AssociateApplyPlanAddDTO a : associateApplyAddDTO.getAssociateApplyPlanAddDTOS()) {
                    AssociateApplyProductPlan associateApplyProductPlan = BeanUtil.copyProperties(a, AssociateApplyProductPlan.class, "id", "createdAt", "updatedAt");
                    associateApplyProductPlan.setApplyId(associateApply.getId());
                    associateApplyProductPlan.setCreatedAt(now);
                    associateApplyProductPlan.setCreatedBy(openid);
                    associateApplyProductPlanList.add(associateApplyProductPlan);
                }
            }
            associateApplyProductPlanService.saveBatch(associateApplyProductPlanList);

        }
        if (qudao){
            sendQdMsg(associatePromotions.get(0).getCode(), associateApply.getCompany(), associateApply.getLinkman());
        }

        if (chanxian){
//            sendCxMsg(associateApply.getCompany(), associateApply.getLinkman(), now);
            sendCxMsg1(associatePromotions.get(0).getCode(), associateApply.getCompany(), associateApply.getLinkman(), now);
        }
        return associateApplyId + "";
    }

    private void sendCxMsg(String company, String linkman, LocalDateTime now) {
        //通过
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("associate");
        triggerMsgRequest.setScene("associateResearchPass");
        JSONObject qywxParam = new JSONObject();
        qywxParam.put("msgtype", "template_card");

        JSONObject templateCard = new JSONObject();
        templateCard.put("card_type", "text_notice");

        JSONObject mainTitle = new JSONObject();
        mainTitle.put("title", "产线联营待调研");
        mainTitle.put("desc", "联营签约_客户审核");
        templateCard.put("main_title", mainTitle);

        List<JSONObject> horizontalContentList = new ArrayList<>();
        JSONObject keyName1 = new JSONObject();
        keyName1.put("keyname", "客户");
        keyName1.put("value", company);
        horizontalContentList.add(keyName1);
        JSONObject keyName2 = new JSONObject();
        keyName2.put("keyname", "联系人");
        keyName2.put("value", linkman);
        horizontalContentList.add(keyName2);
        JSONObject keyName3 = new JSONObject();
        keyName3.put("keyname", "提交时间");
        keyName3.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
        horizontalContentList.add(keyName3);
        JSONObject keyName4 = new JSONObject();
        keyName4.put("keyname", "备注");
        keyName4.put("value", "客户提交产线联营合作申请，请前往查看并审批。");
        horizontalContentList.add(keyName4);
        templateCard.put("horizontal_content_list", horizontalContentList);

        List<JSONObject> jumpList = new ArrayList<>();
        JSONObject jumpList1 = new JSONObject();
        jumpList1.put("type", 1);
        jumpList1.put("title", "跳转惠采");
        jumpList1.put("url", odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(company));
        jumpList.add(jumpList1);
        templateCard.put("jump_list", jumpList);

        JSONObject cardAction = new JSONObject();
        cardAction.put("type", 1);
        cardAction.put("url",  odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(company));
        templateCard.put("card_action", cardAction);
        qywxParam.put("template_card", templateCard);
        triggerMsgRequest.setQywxParam(qywxParam);
        msgClient.triggerMsg(triggerMsgRequest);
    }

    private void sendCxMsg1(String promotionCode, String company, String linkman, LocalDateTime now) {
        //通过
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("associate");
        triggerMsgRequest.setScene("cxAssociateApply");
        JSONObject qywxParam = new JSONObject();
        qywxParam.put("msgtype", "template_card");
        qywxParam.put("noticeUser", promotionCode);

        JSONObject templateCard = new JSONObject();
        templateCard.put("card_type", "text_notice");

        JSONObject mainTitle = new JSONObject();
        mainTitle.put("title", "产线联营待调研");
        mainTitle.put("desc", "产线联营申请");
        templateCard.put("main_title", mainTitle);

        List<JSONObject> horizontalContentList = new ArrayList<>();
        JSONObject keyName1 = new JSONObject();
        keyName1.put("keyname", "客户");
        keyName1.put("value", company);
        horizontalContentList.add(keyName1);
        JSONObject keyName2 = new JSONObject();
        keyName2.put("keyname", "联系人");
        keyName2.put("value", linkman);
        horizontalContentList.add(keyName2);
        JSONObject keyName3 = new JSONObject();
        keyName3.put("keyname", "提交时间");
        keyName3.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
        horizontalContentList.add(keyName3);
        JSONObject keyName4 = new JSONObject();
        keyName4.put("keyname", "备注");
        keyName4.put("value", "客户提交产线联营合作申请，请前往查看核对信息。");
        horizontalContentList.add(keyName4);
        templateCard.put("horizontal_content_list", horizontalContentList);

        List<JSONObject> jumpList = new ArrayList<>();
        JSONObject jumpList1 = new JSONObject();
        jumpList1.put("type", 1);
        jumpList1.put("title", "跳转惠采");
        jumpList1.put("url", odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(company));
        jumpList.add(jumpList1);
        templateCard.put("jump_list", jumpList);

        JSONObject cardAction = new JSONObject();
        cardAction.put("type", 1);
        cardAction.put("url",  odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(company));
        templateCard.put("card_action", cardAction);
        qywxParam.put("template_card", templateCard);
        triggerMsgRequest.setQywxParam(qywxParam);
        msgClient.triggerMsg(triggerMsgRequest);
    }

    private void sendQdMsg(String promotionCode, String company, String linkman) {
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("associate");
        triggerMsgRequest.setScene("qdAssociateApply");
        JSONObject qywxParam = new JSONObject();
        qywxParam.put("msgtype", "template_card");
        qywxParam.put("noticeUser", promotionCode);

        JSONObject templateCard = new JSONObject();
        templateCard.put("card_type", "text_notice");

        JSONObject mainTitle = new JSONObject();
        mainTitle.put("title", "联营签约客户待调研");
        mainTitle.put("desc", "渠道联营申请");
        templateCard.put("main_title", mainTitle);

        List<JSONObject> horizontalContentList = new ArrayList<>();
        JSONObject keyName1 = new JSONObject();
        keyName1.put("keyname", "客户");
        keyName1.put("value", company);
        horizontalContentList.add(keyName1);
        JSONObject keyName2 = new JSONObject();
        keyName2.put("keyname", "联系人");
        keyName2.put("value", linkman);
        horizontalContentList.add(keyName2);
        JSONObject keyName3 = new JSONObject();
        keyName3.put("keyname", "提交时间");
        keyName3.put("value", DateUtil.format(LocalDateTime.now(), "yyyy/MM/dd HH:mm:ss"));
        horizontalContentList.add(keyName3);
        JSONObject keyName4 = new JSONObject();
        keyName4.put("keyname", "备注");
        keyName4.put("value", "客户提交了联营签约申请，赶紧去查看并调研吧。");
        horizontalContentList.add(keyName4);
        templateCard.put("horizontal_content_list", horizontalContentList);

        List<JSONObject> jumpList = new ArrayList<>();
        JSONObject jumpList1 = new JSONObject();
        jumpList1.put("type", 1);
        jumpList1.put("title", "跳转惠采");
        jumpList1.put("url", odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(company));
        jumpList.add(jumpList1);
        templateCard.put("jump_list", jumpList);

        JSONObject cardAction = new JSONObject();
        cardAction.put("type", 1);
        cardAction.put("url",  odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(company));
        templateCard.put("card_action", cardAction);
        qywxParam.put("template_card", templateCard);
        triggerMsgRequest.setQywxParam(qywxParam);
        msgClient.triggerMsg(triggerMsgRequest);
    }

    @Override
    public AssociateApply queryByJsCode(AssociateApplyQueryDTO associateApplyQueryDTO) {
        //get请求 https://api.weixin.qq.com/sns/jscode2session 获取session_key，unionid，openid等数据
//        JSONObject jsonObject = wxClient.jscode2session(appid, secret, associateApplyQueryDTO.getJsCode());
//        if (jsonObject.containsKey("errcode") && jsonObject.getInteger("errcode") != 0){
//            log.error(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getCode() + ": " +
//                    PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getDesc() + ": " + jsonObject.getString("errmsg"));
//            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR);
//        }
        String openid = associateApplyQueryDTO.getOpenId();
//        String unionid = jsonObject.getString("unionid");
        QueryWrapper<AssociateApply> associateApplyQueryWrapper1 = new QueryWrapper<>();
        associateApplyQueryWrapper1.eq("open_id", openid);
        List<AssociateApply> associateApplyList1 = this.list(associateApplyQueryWrapper1);
        if (CollectionUtil.isEmpty(associateApplyList1)){
            return null;
        }
        AssociateApply associateApply = associateApplyList1.get(0);

        QueryWrapper<AssociateApplyProductPlan> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("apply_id", associateApply.getId());
        List<AssociateApplyProductPlan> associateApplyProductPlans = associateApplyProductPlanMapper.selectList(queryWrapper);
        associateApply.setAssociateApplyProductPlans(associateApplyProductPlans);

        QueryWrapper<AssociateApplyCustomerPlan> customerPlanQueryWrapper = new QueryWrapper<>();
        customerPlanQueryWrapper.eq("apply_id", associateApply.getId());
        List<AssociateApplyCustomerPlan> associateApplyCustomerPlans = associateApplyCustomerPlanMapper.selectList(customerPlanQueryWrapper);
        associateApply.setAssociateApplyCustomerPlans(associateApplyCustomerPlans);
        return associateApply;
    }

    @Override
    public List<PurchaseCompanyDTO> queryPurchaseCompany() {
        List<String> area1 = memberMapper.selectByArea("华东华中");
        List<String> area2 = memberMapper.selectByArea("华南西部");
        area2.remove("汕头达源");
        List<String> area3 = memberMapper.selectByArea("华北东北");
        List<String> area4 = new ArrayList<>();
        area4.add("上海供应链公司");

        PurchaseCompanyDTO purchaseCompanyDTO1 = new PurchaseCompanyDTO();
        purchaseCompanyDTO1.setAreaName("华东华中");
        purchaseCompanyDTO1.setCompanyName(area1);
        PurchaseCompanyDTO purchaseCompanyDTO2 = new PurchaseCompanyDTO();
        purchaseCompanyDTO2.setAreaName("华南西部");
        purchaseCompanyDTO2.setCompanyName(area2);
        PurchaseCompanyDTO purchaseCompanyDTO3 = new PurchaseCompanyDTO();
        purchaseCompanyDTO3.setAreaName("华北东北");
        purchaseCompanyDTO3.setCompanyName(area3);
        PurchaseCompanyDTO purchaseCompanyDTO4 = new PurchaseCompanyDTO();
        purchaseCompanyDTO4.setAreaName("上海供应链");
        purchaseCompanyDTO4.setCompanyName(area4);
        List<PurchaseCompanyDTO> purchaseCompanyDTOS = new ArrayList<>();
        purchaseCompanyDTOS.add(purchaseCompanyDTO1);
        purchaseCompanyDTOS.add(purchaseCompanyDTO2);
        purchaseCompanyDTOS.add(purchaseCompanyDTO3);
        purchaseCompanyDTOS.add(purchaseCompanyDTO4);
        return purchaseCompanyDTOS;
    }

    @Override
    public Boolean edit(AssociateApplyEditDTO associateApplyEditDTO) {
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        AssociateApply associateApply = this.getById(associateApplyEditDTO.getId());
        if (associateApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_ASSOCIATE);
        }


        LocalDateTime now = LocalDateTime.now();
        CopyOptions options = CopyOptions.create()
                .setIgnoreNullValue(true)  // 忽略源对象属性为空的情况
                .setIgnoreError(true);
        BeanUtil.copyProperties(associateApplyEditDTO, associateApply, options);
        //查询项目推广专员
        if (StringUtils.isNotEmpty(associateApplyEditDTO.getSubCompany())){
            QueryWrapper<AssociatePromotion> associatePromotionQueryWrapper = new QueryWrapper<>();
            associatePromotionQueryWrapper.eq("company_name", associateApplyEditDTO.getSubCompany());
            List<AssociatePromotion> associatePromotions = associatePromotionMapper.selectList(associatePromotionQueryWrapper);
            if (CollectionUtil.isEmpty(associatePromotions)){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PROMOTION);
            }
            associateApply.setPromotionPerson(associatePromotions.get(0).getPromotionPerson());
        }

        associateApply.setUpdatedBy(code);
        associateApply.setUpdatedAt(now);
        boolean result = this.updateById(associateApply);

        if (CollectionUtils.isNotEmpty(associateApplyEditDTO.getAssociateApplyProductPlans())){
            //合作计划
            for (AssociateApplyPlanEditDTO a : associateApplyEditDTO.getAssociateApplyProductPlans()) {
                QueryWrapper<AssociateApplyProductPlan> associateApplyProductPlanQueryWrapper = new QueryWrapper<>();
                associateApplyProductPlanQueryWrapper.eq("id", a.getId()).eq("apply_id", a.getApplyId());
                AssociateApplyProductPlan associateApplyProductPlan = associateApplyProductPlanMapper.selectOne(associateApplyProductPlanQueryWrapper);
                if (associateApplyProductPlan != null){
                    BeanUtil.copyProperties(a, associateApplyProductPlan, options);
                    associateApplyProductPlan.setUpdatedBy(code);
                    associateApplyProductPlan.setUpdatedAt(now);
                    associateApplyProductPlanMapper.updateById(associateApplyProductPlan);
                }
            }
        }

        if (CollectionUtils.isNotEmpty(associateApplyEditDTO.getAssociateApplyCustomerPlans())){
            //终端客户合作拓展计划
            for (AssociateApplyCustomerPlan a : associateApplyEditDTO.getAssociateApplyCustomerPlans()) {
                QueryWrapper<AssociateApplyCustomerPlan> customerPlanQueryWrapper = new QueryWrapper<>();
                customerPlanQueryWrapper.eq("id", a.getId()).eq("apply_id", a.getApplyId());
                AssociateApplyCustomerPlan associateApplyCustomerPlan = associateApplyCustomerPlanMapper.selectOne(customerPlanQueryWrapper);
                if (associateApplyCustomerPlan != null){
                    BeanUtil.copyProperties(a, associateApplyCustomerPlan, options);
                    associateApplyCustomerPlan.setUpdatedBy(code);
                    associateApplyCustomerPlan.setUpdatedAt(now);
                    associateApplyCustomerPlanMapper.updateById(associateApplyCustomerPlan);
                }
            }
        }
        return result;
    }

    @Override
    @Transactional
    public String editMini(AssociateApplyEditDTO associateApplyEditDTO) {
        AssociateApply associateApply = this.getById(associateApplyEditDTO.getId());
        if (associateApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_ASSOCIATE);
        }
        QueryWrapper<AssociateApply> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("company", associateApply.getCompany());
        List<AssociateApply> associateApplies = associateApplyMapper.selectList(queryWrapper);
        if (associateApplies.size() >= 2){
            //只能单独修改，并且不能修改合作项
            if (!StringUtils.equals(associateApply.getCooperationProject(), associateApplyEditDTO.getCooperationProject())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EDIT_MINI_COOPERATIONPROJECT);
            }
            //修改
            aliSmsService.valid("ASSOCIATE_APPLY", associateApplyEditDTO.getLinkphone(), associateApplyEditDTO.getSmsCode());
            LocalDateTime now = LocalDateTime.now();
            CopyOptions options = CopyOptions.create()
                    .setIgnoreNullValue(true)  // 忽略源对象属性为空的情况
                    .setIgnoreError(true);
            BeanUtil.copyProperties(associateApplyEditDTO, associateApply, options);
            //查询项目推广专员
            String promotionCode = null;
            if (StringUtils.isNotEmpty(associateApplyEditDTO.getSubCompany())){
                QueryWrapper<AssociatePromotion> associatePromotionQueryWrapper = new QueryWrapper<>();
                associatePromotionQueryWrapper.eq("company_name", associateApplyEditDTO.getSubCompany());
                List<AssociatePromotion> associatePromotions = associatePromotionMapper.selectList(associatePromotionQueryWrapper);
                if (CollectionUtil.isEmpty(associatePromotions)){
                    throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PROMOTION);
                }
                associateApply.setPromotionPerson(associatePromotions.get(0).getPromotionPerson());
                promotionCode = associatePromotions.get(0).getCode();
            }
            associateApply.setUpdatedBy(associateApply.getOpenId());
            associateApply.setUpdatedAt(now);
            boolean result = this.updateById(associateApply);

            if (CollectionUtils.isNotEmpty(associateApplyEditDTO.getAssociateApplyProductPlans())){
                //合作计划
                for (AssociateApplyPlanEditDTO a : associateApplyEditDTO.getAssociateApplyProductPlans()) {
                    QueryWrapper<AssociateApplyProductPlan> associateApplyProductPlanQueryWrapper = new QueryWrapper<>();
                    associateApplyProductPlanQueryWrapper.eq("id", a.getId()).eq("apply_id", a.getApplyId());
                    AssociateApplyProductPlan associateApplyProductPlan = associateApplyProductPlanMapper.selectOne(associateApplyProductPlanQueryWrapper);
                    if (associateApplyProductPlan != null){
                        BeanUtil.copyProperties(a, associateApplyProductPlan, options);
                        associateApplyProductPlan.setUpdatedBy(associateApply.getOpenId());
                        associateApplyProductPlan.setUpdatedAt(now);
                        associateApplyProductPlanMapper.updateById(associateApplyProductPlan);
                    }
                }
            }

            if (CollectionUtils.isNotEmpty(associateApplyEditDTO.getAssociateApplyCustomerPlans())){
                //终端客户合作拓展计划
                for (AssociateApplyCustomerPlan a : associateApplyEditDTO.getAssociateApplyCustomerPlans()) {
                    QueryWrapper<AssociateApplyCustomerPlan> customerPlanQueryWrapper = new QueryWrapper<>();
                    customerPlanQueryWrapper.eq("id", a.getId()).eq("apply_id", a.getApplyId());
                    AssociateApplyCustomerPlan associateApplyCustomerPlan = associateApplyCustomerPlanMapper.selectOne(customerPlanQueryWrapper);
                    if (associateApplyCustomerPlan != null){
                        BeanUtil.copyProperties(a, associateApplyCustomerPlan, options);
                        associateApplyCustomerPlan.setUpdatedBy(associateApply.getOpenId());
                        associateApplyCustomerPlan.setUpdatedAt(now);
                        associateApplyCustomerPlanMapper.updateById(associateApplyCustomerPlan);
                    }
                }
            }
            if (associateApplyEditDTO.getCooperationProject().contains("渠道联营")){
                sendQdMsg(promotionCode, associateApply.getCompany(), associateApply.getLinkman());
            }
            if (associateApplyEditDTO.getCooperationProject().contains("产线联营")){
//                sendCxMsg(associateApply.getCompany(), associateApply.getLinkman(), now);
                sendCxMsg1(promotionCode, associateApply.getCompany(), associateApply.getLinkman(), now);
            }
            return String.valueOf(associateApply.getId());
        }else {
            associateApplyMapper.deleteById(associateApplyEditDTO.getId());
            QueryWrapper<AssociateApplyProductPlan>  productPlanQueryWrapper = new QueryWrapper<>();
            productPlanQueryWrapper.eq("apply_id", associateApplyEditDTO.getId());
            associateApplyProductPlanMapper.delete(productPlanQueryWrapper);

            QueryWrapper<AssociateApplyCustomerPlan>  customerPlanQueryWrapper = new QueryWrapper<>();
            customerPlanQueryWrapper.eq("apply_id", associateApplyEditDTO.getId());
            associateApplyCustomerPlanMapper.delete(customerPlanQueryWrapper);

            AssociateApplyAddDTO associateApplyAddDTO = BeanUtil.copyProperties(associateApplyEditDTO, AssociateApplyAddDTO.class);
            associateApplyAddDTO.setOpenId(associateApply.getOpenId());
            associateApplyAddDTO.setAssociateApplyCustomerPlans(BeanUtil.copyToList(associateApplyEditDTO.getAssociateApplyCustomerPlans(), AssociateApplyCustomerPlan.class));
            associateApplyAddDTO.setAssociateApplyPlanAddDTOS(BeanUtil.copyToList(associateApplyEditDTO.getAssociateApplyProductPlans(), AssociateApplyPlanAddDTO.class));
            return add(associateApplyAddDTO);
        }
    }

    @Override
    public Page<AssociateApply> queryList(AssociateApplyPageDTO associateApplyPageDTO) {
        //数据权限
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        List<String> promotionList = associatePromotionMapper.selectPromotionCode();
        List<String> list = Arrays.asList(associateApplyAllAuth.split(","));
        List<String> productionList = Arrays.asList(associateApplyOnlyProduction.split(","));
        if (list.contains(code)){
            //配置的看所有
        }else if (promotionList.contains(code)){
            //项目推广人只查自己的
            associateApplyPageDTO.setPromotionPerson(name);
        }else {
            //其他看不到数据
            return new Page<>();
        }
        // 仅能看到产线联营的数据
        if (productionList.contains(code)) {
            associateApplyPageDTO.setCooperationProject("产线联营");
            if (StringUtils.isBlank(associateApplyPageDTO.getCooperationProject())) {
                associateApplyPageDTO.setCooperationProject("产线联营");
            } else if (!associateApplyPageDTO.getCooperationProject().equals("产线联营")) {
                return new Page<>();
            }
        }
        return associateApplyMapper.page(associateApplyPageDTO, associateApplyPageDTO.buildPage());
    }

    @Override
    public List<CommonCountVO> countNum(AssociateApplyCountDTO associateApplyCountDTO) {
        //数据权限
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        List<String> promotionList = associatePromotionMapper.selectPromotionCode();
        List<String> list = Arrays.asList(associateApplyAllAuth.split(","));
        List<String> productionList = Arrays.asList(associateApplyOnlyProduction.split(","));
        if (list.contains(code)){
            //配置的看所有
        }else if (promotionList.contains(code)){
            //项目推广人只查自己的
            associateApplyCountDTO.setPromotionPerson(name);
        }else {
            //其他看不到数据
            return new ArrayList<>();
        }
        // 仅能看到产线联营的数据
        if (productionList.contains(code)) {
            associateApplyCountDTO.setCooperationProject("产线联营");
            if (StringUtils.isBlank(associateApplyCountDTO.getCooperationProject())) {
                associateApplyCountDTO.setCooperationProject("产线联营");
            } else if (!associateApplyCountDTO.getCooperationProject().equals("产线联营")) {
                return new ArrayList<>();
            }
        }

        List<CommonCountVO> commonCountVOS = new ArrayList<>();
        CommonCountVO commonCountVO1 = new CommonCountVO();
        commonCountVO1.setState("1");
        associateApplyCountDTO.setState("1");
        commonCountVO1.setCount(associateApplyMapper.countByState(associateApplyCountDTO));
        CommonCountVO commonCountVO2 = new CommonCountVO();
        commonCountVO2.setState("2");
        associateApplyCountDTO.setState("2");
        commonCountVO2.setCount(associateApplyMapper.countByState(associateApplyCountDTO));
        CommonCountVO commonCountVO3 = new CommonCountVO();
        commonCountVO3.setState("3");
        associateApplyCountDTO.setState("3");
        commonCountVO3.setCount(associateApplyMapper.countByState(associateApplyCountDTO));
        CommonCountVO commonCountVO4 = new CommonCountVO();
        commonCountVO4.setState("4");
        associateApplyCountDTO.setState("4");
        commonCountVO4.setCount(associateApplyMapper.countByState(associateApplyCountDTO));
        CommonCountVO commonCountVO5 = new CommonCountVO();
        commonCountVO5.setState("5");
        associateApplyCountDTO.setState("5");
        commonCountVO5.setCount(associateApplyMapper.countByState(associateApplyCountDTO));

        commonCountVOS.add(commonCountVO1);
        commonCountVOS.add(commonCountVO2);
        commonCountVOS.add(commonCountVO3);
        commonCountVOS.add(commonCountVO4);
        commonCountVOS.add(commonCountVO5);
        return commonCountVOS;
    }

    @Override
    public AssociateApply queryById(QueryIdDTO queryIdDTO) {
        AssociateApply associateApply = this.getById(queryIdDTO.getId());
        if (associateApply == null){
            return null;
        }
        QueryWrapper<AssociateApplyProductPlan> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("apply_id", associateApply.getId());
        List<AssociateApplyProductPlan> associateApplyProductPlans = associateApplyProductPlanMapper.selectList(queryWrapper);
        associateApply.setAssociateApplyProductPlans(associateApplyProductPlans);

        QueryWrapper<AssociateApplyCustomerPlan> customerPlanQueryWrapper = new QueryWrapper<>();
        customerPlanQueryWrapper.eq("apply_id", associateApply.getId());
        List<AssociateApplyCustomerPlan> associateApplyCustomerPlans = associateApplyCustomerPlanMapper.selectList(customerPlanQueryWrapper);
        associateApply.setAssociateApplyCustomerPlans(associateApplyCustomerPlans);

        QueryWrapper<AssociateProtocol> associateProtocolQueryWrapper = new QueryWrapper<>();
        associateProtocolQueryWrapper.eq("apply_id",  associateApply.getId());
        associateProtocolQueryWrapper.eq("type", associateApply.getCooperationProject());
        List<AssociateProtocol> associateProtocols = associateProtocolMapper.selectList(associateProtocolQueryWrapper);
        associateApply.setAssociateProtocols(associateProtocols);
        return associateApply;
    }

    @Override
    public List<AssociateApply> queryByOpenId(OpenIdDTO openIdDTO) {
        QueryWrapper<AssociateApply> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("open_id", openIdDTO.getOpenId()).orderByDesc("created_at");
        List<AssociateApply> associateApplies = this.list(queryWrapper1);
        if (CollectionUtils.isEmpty(associateApplies)){
            return null;
        }
        for (AssociateApply a : associateApplies) {
            QueryWrapper<AssociateApplyProductPlan> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("apply_id", a.getId());
            List<AssociateApplyProductPlan> associateApplyProductPlans = associateApplyProductPlanMapper.selectList(queryWrapper);
            a.setAssociateApplyProductPlans(associateApplyProductPlans);

            QueryWrapper<AssociateApplyCustomerPlan> customerPlanQueryWrapper = new QueryWrapper<>();
            customerPlanQueryWrapper.eq("apply_id", a.getId());
            List<AssociateApplyCustomerPlan> associateApplyCustomerPlans = associateApplyCustomerPlanMapper.selectList(customerPlanQueryWrapper);
            a.setAssociateApplyCustomerPlans(associateApplyCustomerPlans);

            QueryWrapper<AssociateProtocol> associateProtocolQueryWrapper = new QueryWrapper<>();
            associateProtocolQueryWrapper.eq("apply_id",  a.getId());
            associateProtocolQueryWrapper.eq("type", a.getCooperationProject());
            List<AssociateProtocol> associateProtocols = associateProtocolMapper.selectList(associateProtocolQueryWrapper);
            a.setAssociateProtocols(associateProtocols);
        }

        return associateApplies;
    }

    @Override
    public Boolean editResearch(AssociateApplyEditResearchDTO associateApplyEditResearchDTO) {
        AssociateApply associateApply = this.getById(associateApplyEditResearchDTO.getId());
        if (associateApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_ASSOCIATE);
        }

        LocalDateTime now = LocalDateTime.now();
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }
        UpdateWrapper<AssociateApply> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("research_person", name)
                .set("research_format", associateApplyEditResearchDTO.getResearchFormat())
                .set("customer_type", associateApplyEditResearchDTO.getCustomerType())
                .set("customer_type", associateApplyEditResearchDTO.getCustomerType())
                .set("research_result", associateApplyEditResearchDTO.getResearchResult())
                .set("state", associateApplyEditResearchDTO.getState())
                .set("research_time", now)
                .set("updated_at", now)
                .set("updated_by", code)
                .eq("id", associateApplyEditResearchDTO.getId());
        boolean result = this.update(updateWrapper);
        if (result){
            if (StringUtils.equals(associateApplyEditResearchDTO.getState(), MemberConstants.AssociateApplyState.PENDING_APPROVAL.code)){
                //通过
                TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
                triggerMsgRequest.setBusiness("associate");
                triggerMsgRequest.setScene("associateResearchPass");
                JSONObject qywxParam = new JSONObject();
                qywxParam.put("msgtype", "template_card");

                JSONObject templateCard = new JSONObject();
                templateCard.put("card_type", "text_notice");

                JSONObject mainTitle = new JSONObject();
                mainTitle.put("title", "联营签约客户待批复");
                if (StringUtils.equals(associateApply.getCooperationProject(), "渠道联营")){
                    mainTitle.put("desc", "渠道联营申请");
                }else if (StringUtils.equals(associateApply.getCooperationProject(), "产线联营")){
                    mainTitle.put("desc", "产线联营申请");
                }
                templateCard.put("main_title", mainTitle);

                List<JSONObject> horizontalContentList = new ArrayList<>();
                JSONObject keyName1 = new JSONObject();
                keyName1.put("keyname", "客户");
                keyName1.put("value", associateApply.getCompany());
                horizontalContentList.add(keyName1);
                JSONObject keyName2 = new JSONObject();
                keyName2.put("keyname", "联系人");
                keyName2.put("value", associateApply.getLinkman());
                horizontalContentList.add(keyName2);
                JSONObject keyName3 = new JSONObject();
                keyName3.put("keyname", "调研时间");
                keyName3.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
                horizontalContentList.add(keyName3);
                JSONObject keyName4 = new JSONObject();
                keyName4.put("keyname", "备注");
                keyName4.put("value", "客户已通过调研，赶快去查看并审批吧。");
                horizontalContentList.add(keyName4);
                templateCard.put("horizontal_content_list", horizontalContentList);

                List<JSONObject> jumpList = new ArrayList<>();
                JSONObject jumpList1 = new JSONObject();
                jumpList1.put("type", 1);
                jumpList1.put("title", "跳转惠采");
                jumpList1.put("url", odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(associateApply.getCompany()));
                jumpList.add(jumpList1);
                templateCard.put("jump_list", jumpList);

                JSONObject cardAction = new JSONObject();
                cardAction.put("type", 1);
                cardAction.put("url",  odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(associateApply.getCompany()));
                templateCard.put("card_action", cardAction);
                qywxParam.put("template_card", templateCard);
                triggerMsgRequest.setQywxParam(qywxParam);
                msgClient.triggerMsg(triggerMsgRequest);
            }else {
                AssociateApply associateApply1 = this.getById(associateApplyEditResearchDTO.getId());
                AssociateApplySnapshot associateApplySnapshot = BeanUtil.copyProperties(associateApply1, AssociateApplySnapshot.class, "id", "created_at", "created_by", "updated_at", "updated_by");
                associateApplySnapshot.setCreatedAt(now);
                associateApplySnapshot.setCreatedBy(name);
                associateApplySnapshotMapper.insert(associateApplySnapshot);

                QueryWrapper<AssociateApplyCustomerPlan> customerPlanQueryWrapper = new QueryWrapper<>();
                customerPlanQueryWrapper.eq("apply_id", associateApply1.getId());
                List<AssociateApplyCustomerPlan> associateApplyCustomerPlans = associateApplyCustomerPlanMapper.selectList(customerPlanQueryWrapper);
                if (CollectionUtils.isNotEmpty(associateApplyCustomerPlans)){
                    for (AssociateApplyCustomerPlan a : associateApplyCustomerPlans) {
                        AssociateApplyCustomerPlanSnapshot customerPlanSnapshot = BeanUtil.copyProperties(a, AssociateApplyCustomerPlanSnapshot.class, "id", "created_at", "created_by", "updated_at", "updated_by");
                        customerPlanSnapshot.setCreatedAt(now);
                        customerPlanSnapshot.setCreatedBy(name);
                        associateApplyCustomerPlanSnapshotService.save(customerPlanSnapshot);
                    }
                }


                QueryWrapper<AssociateApplyProductPlan> productPlanQueryWrapper = new QueryWrapper<>();
                productPlanQueryWrapper.eq("apply_id", associateApply1.getId());
                List<AssociateApplyProductPlan> associateApplyProductPlans = associateApplyProductPlanMapper.selectList(productPlanQueryWrapper);
                if (CollectionUtils.isNotEmpty(associateApplyProductPlans)){
                    for (AssociateApplyProductPlan a : associateApplyProductPlans) {
                        AssociateApplyProductPlanSnapshot productPlanSnapshot = BeanUtil.copyProperties(a, AssociateApplyProductPlanSnapshot.class, "id", "created_at", "created_by", "updated_at", "updated_by");
                        productPlanSnapshot.setCreatedAt(now);
                        productPlanSnapshot.setCreatedBy(name);
                        associateApplyProductPlanSnapshotService.save(productPlanSnapshot);
                    }
                }
            }
        }
        return result;
    }

//    public static void main(String[] args) {
//        AssociateProtocol associateProtocol = new AssociateProtocol();
//        associateProtocol.setSignTime(LocalDateTime.now());
//        AssociateApply associateApply = new AssociateApply();
//        associateApply.setCompany("苏州泰安科技有限公司");
//        associateApply.setProvince("广东省");
//        associateApply.setCity("汕头市");
//        associateApply.setArea("龙湖区");
//        associateApply.setAddress("珠津工业区珠津一横街1号");
//        associateApply.setAccountName("江苏弘历电气有限公司");
//        associateApply.setBankAccountNum("16465656495462323565");
//        associateApply.setOpeningBank("中国银行");
//        associateApply.setTaxIdentification("7896451348651");
//        associateApply.setWorkingType("品牌生产工厂");
//        associateApply.setMainBrand("ABB、施耐德、西门子、ABB、施耐德、西门子");
//        associateApply.setMainProduct("abb、施耐德、西门子等品牌产品、西门子等品牌产品");
//        associateApply.setAnnualTarget(new BigDecimal("1012"));
//        associateApply.setFirstQuarterTarget(new BigDecimal("12"));
//        associateApply.setSecondQuarterTarget(new BigDecimal("23"));
//        associateApply.setThirdQuarterTarget(new BigDecimal("34"));
//        associateApply.setFourthQuarterTarget(new BigDecimal("45"));
//        AssociateApplyServiceImpl associateApplyService = new AssociateApplyServiceImpl();
//        SubCompanyVO subCompanyVO = new SubCompanyVO();
//        subCompanyVO.setComName("上海众业达电器有限公司");
//        subCompanyVO.setAddress("上海市静安区止园路295号");
//        subCompanyVO.setBankName("农业银行上海市闸北区宝山路支行");
//        subCompanyVO.setBankAccount("0335 9700 0400 14072");
//        subCompanyVO.setBankComName("上海众业达电器有限公司");
//        subCompanyVO.setTaxNumber("91310106134686191W");
//        associateApplyService.createQdUrl(associateProtocol, associateApply, subCompanyVO);
//        associateApplyService.createCxUrl(associateProtocol, associateApply);
//    }

    /**
     * 产线协议
     * @return
     */
    public String createCxUrl(AssociateProtocol associateProtocol, AssociateApply associateApply){
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            PDDocument document = PDDocument.load(new File(cxProtocol));
//            PDDocument document = PDDocument.load(new File("D:\\Users\\User\\Desktop\\cxProtocol.pdf"));
            PDFont font = PDType0Font.load(document, new File(fontPath));
//            PDFont font = PDType0Font.load(document, new File("C:\\Windows\\Fonts\\SIMFANG.TTF"));

            PDPage page0 = document.getPage(1); // 获取第二页
            PDPageContentStream contentStream = new PDPageContentStream(document, page0, PDPageContentStream.AppendMode.APPEND, true, true);
            contentStream.setFont(font, 12);
            List<BrandAuthApplyServiceImpl.TextPosition> textPositions = new ArrayList<>();
            textPositions.add(new BrandAuthApplyServiceImpl.TextPosition(130, 420, String.valueOf(associateProtocol.getSignTime().getYear())));
            textPositions.add(new BrandAuthApplyServiceImpl.TextPosition(195, 420, String.valueOf(associateProtocol.getSignTime().getMonthValue())));
            textPositions.add(new BrandAuthApplyServiceImpl.TextPosition(240, 420, String.valueOf(associateProtocol.getSignTime().getDayOfMonth())));

            for (BrandAuthApplyServiceImpl.TextPosition position : textPositions) {
                contentStream.beginText();
                contentStream.newLineAtOffset(position.getX(), position.getY());
                contentStream.showText(position.getText());
                contentStream.endText();
            }
            contentStream.close(); // 关闭内容流


            PDPage page1 = document.getPage(2); // 获取第三页
            PDPageContentStream contentStream1 = new PDPageContentStream(document, page1, PDPageContentStream.AppendMode.APPEND, true, true);
            contentStream1.setFont(font, 12);
            List<BrandAuthApplyServiceImpl.TextPosition> textPositions1 = new ArrayList<>();
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(160, 733, associateApply.getCompany()));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(100, 682, associateApply.getProvince()+ associateApply.getCity() + associateApply.getArea() + associateApply.getAddress()));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(135, 486, String.valueOf(associateProtocol.getSignTime().getYear())));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(200, 486, String.valueOf(associateProtocol.getSignTime().getMonthValue())));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(245, 486, String.valueOf(associateProtocol.getSignTime().getDayOfMonth())));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(120, 365, associateApply.getAccountName()));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(120, 318, associateApply.getBankAccountNum()));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(120, 272, associateApply.getOpeningBank()));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(150, 225, associateApply.getTaxIdentification()));

            for (BrandAuthApplyServiceImpl.TextPosition position : textPositions1) {
                contentStream1.beginText();
                contentStream1.newLineAtOffset(position.getX(), position.getY());
                contentStream1.showText(position.getText());
                contentStream1.endText();
            }
            contentStream1.close(); // 关闭内容流

            PDPage page2 = document.getPage(3); // 获取第四页
            PDPageContentStream contentStream2 = new PDPageContentStream(document, page2, PDPageContentStream.AppendMode.APPEND, true, true);
            contentStream2.setFont(font, 12);
            List<BrandAuthApplyServiceImpl.TextPosition> textPositions2 = new ArrayList<>();
            if (StringUtils.equals(associateApply.getWorkingType(), "品牌生产工厂")){
                textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(195, 178, "√"));
            }else {
                textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(310, 178, "√"));
            }
            String mainBrand = associateApply.getMainBrand();
            if (StringUtils.isNotEmpty(mainBrand) && mainBrand.length() > 12){
                textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(210, 158, mainBrand.substring(0, 12)));
                textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(210, 142, mainBrand.substring(12, mainBrand.length())));
            }else {
                textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(210, 143, mainBrand));
            }

            String mainProduct = associateApply.getMainProduct();
            if (StringUtils.isNotEmpty(mainProduct) && mainProduct.length() > 12){
                textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(210, 122, mainProduct.substring(0, 12)));
                textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(210, 106, mainProduct.substring(12, mainProduct.length())));
            }else {
                textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(210, 110, mainProduct));
            }



            for (BrandAuthApplyServiceImpl.TextPosition position : textPositions2) {
                contentStream2.beginText();
                contentStream2.newLineAtOffset(position.getX(), position.getY());
                contentStream2.showText(position.getText());
                contentStream2.endText();
            }
            contentStream2.close(); // 关闭内容流

            PDPage page3 = document.getPage(4); // 获取第五页
            PDPageContentStream contentStream3 = new PDPageContentStream(document, page3, PDPageContentStream.AppendMode.APPEND, true, true);
            contentStream3.setFont(font, 12);
            List<BrandAuthApplyServiceImpl.TextPosition> textPositions3 = new ArrayList<>();
            textPositions3.add(new BrandAuthApplyServiceImpl.TextPosition(243, 143, String.valueOf(associateProtocol.getSignTime().getYear())));
            textPositions3.add(new BrandAuthApplyServiceImpl.TextPosition(286, 143, String.valueOf(associateProtocol.getSignTime().getMonthValue())));
            textPositions3.add(new BrandAuthApplyServiceImpl.TextPosition(315, 143, String.valueOf(associateProtocol.getSignTime().getDayOfMonth())));

            for (BrandAuthApplyServiceImpl.TextPosition position : textPositions3) {
                contentStream3.beginText();
                contentStream3.newLineAtOffset(position.getX(), position.getY());
                contentStream3.showText(position.getText());
                contentStream3.endText();
            }
            contentStream3.close(); // 关闭内容流

//            document.save("D:\\Users\\User\\Desktop\\2024-“众业达在线”产线联营合作协议.pdf");
//            return null;
            document.save(byteArrayOutputStream);
            ByteArrayInputStream byteArrayInput = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            String urlPath = "purchase/cx/" + associateApply.getId() + "/" + associateApply.getApplyNf() + "-“众业达在线”产线联营合作协议.pdf";
            //同步到oss
            OSS ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
            ossClient.putObject(new PutObjectRequest(ossConfig.getBucketName(), urlPath, byteArrayInput));
            String protocolUrl = ossConfig.getOssUrl() + urlPath;
            return protocolUrl;
        }catch (Exception e){
            log.error("产线协议生成异常：" + e.getMessage());
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_CREATE_CX_PROTOCOL);
        }
    }

    public String createQdUrl(AssociateProtocol associateProtocol, AssociateApply associateApply, SubCompanyVO subCompanyVO){
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            PDDocument document = PDDocument.load(new File(qdProtocol));
//            PDDocument document = PDDocument.load(new File("D:\\Users\\User\\Desktop\\qdProtocol.pdf"));
            PDFont font = PDType0Font.load(document, new File(fontPath));
//            PDFont font = PDType0Font.load(document, new File("C:\\Windows\\Fonts\\SIMFANG.TTF"));
            PDPage page0 = document.getPage(1); // 获取第二页
            PDPageContentStream contentStream = new PDPageContentStream(document, page0, PDPageContentStream.AppendMode.APPEND, true, true);
            contentStream.setFont(font, 12);
            List<BrandAuthApplyServiceImpl.TextPosition> textPositions = new ArrayList<>();
            textPositions.add(new BrandAuthApplyServiceImpl.TextPosition(130, 420, String.valueOf(associateProtocol.getSignTime().getYear())));
            textPositions.add(new BrandAuthApplyServiceImpl.TextPosition(195, 420, String.valueOf(associateProtocol.getSignTime().getMonthValue())));
            textPositions.add(new BrandAuthApplyServiceImpl.TextPosition(240, 420, String.valueOf(associateProtocol.getSignTime().getDayOfMonth())));

            for (BrandAuthApplyServiceImpl.TextPosition position : textPositions) {
                contentStream.beginText();
                contentStream.newLineAtOffset(position.getX(), position.getY());
                contentStream.showText(position.getText());
                contentStream.endText();
            }
            contentStream.close(); // 关闭内容流

            PDPage page1 = document.getPage(2); // 获取第三页
            PDPageContentStream contentStream1 = new PDPageContentStream(document, page1, PDPageContentStream.AppendMode.APPEND, true, true);
            contentStream1.setFont(font, 12);
            List<BrandAuthApplyServiceImpl.TextPosition> textPositions1 = new ArrayList<>();
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(160, 733, associateApply.getCompany()));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(100, 682, associateApply.getProvince()+ associateApply.getCity() + associateApply.getArea() + associateApply.getAddress()));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(135, 483, String.valueOf(associateProtocol.getSignTime().getYear())));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(200, 483, String.valueOf(associateProtocol.getSignTime().getMonthValue())));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(245, 483, String.valueOf(associateProtocol.getSignTime().getDayOfMonth())));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(120, 365, associateApply.getAccountName()));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(120, 318, associateApply.getBankAccountNum()));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(120, 272, associateApply.getOpeningBank()));
            textPositions1.add(new BrandAuthApplyServiceImpl.TextPosition(150, 225, associateApply.getTaxIdentification()));

            for (BrandAuthApplyServiceImpl.TextPosition position : textPositions1) {
                contentStream1.beginText();
                contentStream1.newLineAtOffset(position.getX(), position.getY());
                contentStream1.showText(position.getText());
                contentStream1.endText();
            }
            contentStream1.close(); // 关闭内容流

            PDPage page2 = document.getPage(3); // 获取第四页
            PDPageContentStream contentStream2 = new PDPageContentStream(document, page2, PDPageContentStream.AppendMode.APPEND, true, true);
            contentStream2.setFont(font, 12);
            List<BrandAuthApplyServiceImpl.TextPosition> textPositions2 = new ArrayList<>();
            textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(180, 733, subCompanyVO.getComName()));
            textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(100, 682, subCompanyVO.getAddress()));
            String email = associateApplyMapper.selectUserEmail(associateApply.getBusinessPerson(), associateApply.getSubCompany());
//            String email = "email@qq.com";
            textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(130, 513,  StringUtils.isEmpty(email) ? "" : email));
            textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(135, 483, String.valueOf(associateProtocol.getSignTime().getYear())));
            textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(200, 483, String.valueOf(associateProtocol.getSignTime().getMonthValue())));
            textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(245, 483, String.valueOf(associateProtocol.getSignTime().getDayOfMonth())));
            textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(120, 365, subCompanyVO.getBankComName()));
            textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(120, 318, subCompanyVO.getBankAccount()));
            textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(120, 272, subCompanyVO.getBankName()));
            textPositions2.add(new BrandAuthApplyServiceImpl.TextPosition(150, 225, subCompanyVO.getTaxNumber()));

            for (BrandAuthApplyServiceImpl.TextPosition position : textPositions2) {
                contentStream2.beginText();
                contentStream2.newLineAtOffset(position.getX(), position.getY());
                contentStream2.showText(position.getText());
                contentStream2.endText();
            }
            contentStream2.close(); // 关闭内容流

            PDPage page3 = document.getPage(5); // 获取第六页
            PDPageContentStream contentStream3 = new PDPageContentStream(document, page3, PDPageContentStream.AppendMode.APPEND, true, true);
            contentStream3.setFont(font, 12);
            List<BrandAuthApplyServiceImpl.TextPosition> textPositions3 = new ArrayList<>();
            textPositions3.add(new BrandAuthApplyServiceImpl.TextPosition(422, 583, associateApply.getAnnualTarget().stripTrailingZeros().toPlainString()));
            textPositions3.add(new BrandAuthApplyServiceImpl.TextPosition(160, 350, associateApply.getAnnualTarget().stripTrailingZeros().toPlainString()));
            textPositions3.add(new BrandAuthApplyServiceImpl.TextPosition(250, 350, associateApply.getFirstQuarterTarget().stripTrailingZeros().toPlainString()));
            textPositions3.add(new BrandAuthApplyServiceImpl.TextPosition(330, 350, associateApply.getSecondQuarterTarget().stripTrailingZeros().toPlainString()));
            textPositions3.add(new BrandAuthApplyServiceImpl.TextPosition(410, 350, associateApply.getThirdQuarterTarget().stripTrailingZeros().toPlainString()));
            textPositions3.add(new BrandAuthApplyServiceImpl.TextPosition(490, 350, associateApply.getFourthQuarterTarget().stripTrailingZeros().toPlainString()));

            for (BrandAuthApplyServiceImpl.TextPosition position : textPositions3) {
                contentStream3.beginText();
                contentStream3.newLineAtOffset(position.getX(), position.getY());
                contentStream3.showText(position.getText());
                contentStream3.endText();
            }
            contentStream3.close(); // 关闭内容流

            PDPage page4 = document.getPage(6); // 获取第7页
            PDPageContentStream contentStream4 = new PDPageContentStream(document, page4, PDPageContentStream.AppendMode.APPEND, true, true);
            contentStream4.setFont(font, 12);
            List<BrandAuthApplyServiceImpl.TextPosition> textPositions4 = new ArrayList<>();
            textPositions4.add(new BrandAuthApplyServiceImpl.TextPosition(243, 425, String.valueOf(associateProtocol.getSignTime().getYear())));
            textPositions4.add(new BrandAuthApplyServiceImpl.TextPosition(295, 425, String.valueOf(associateProtocol.getSignTime().getMonthValue())));
            textPositions4.add(new BrandAuthApplyServiceImpl.TextPosition(328, 425, String.valueOf(associateProtocol.getSignTime().getDayOfMonth())));

            for (BrandAuthApplyServiceImpl.TextPosition position : textPositions4) {
                contentStream4.beginText();
                contentStream4.newLineAtOffset(position.getX(), position.getY());
                contentStream4.showText(position.getText());
                contentStream4.endText();
            }
            contentStream4.close(); // 关闭内容流

//            document.save("D:\\Users\\User\\Desktop\\2024-“众业达在线”渠道联营合作协议.pdf");
//            return null;
            document.save(byteArrayOutputStream);
            ByteArrayInputStream byteArrayInput = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            String urlPath = "purchase/qd/" + associateApply.getId() + "/" + associateApply.getApplyNf() + "-“众业达在线”渠道联营合作协议.pdf";
            //同步到oss
            OSS ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
            ossClient.putObject(new PutObjectRequest(ossConfig.getBucketName(), urlPath, byteArrayInput));
            String protocolUrl = ossConfig.getOssUrl() + urlPath;
            return protocolUrl;
        }catch (Exception e){
            log.error("渠道协议生成异常：" + e.getMessage());
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_CREATE_QD_PROTOCOL);
        }
    }

    private AssociateProtocol createAssociateProtocol(LocalDateTime now, Integer applyId, String type, String createPerson, String code, Integer applyNf){
        String associateCode = associateProtocolMapper.maxCode(type);
        if (StringUtils.isEmpty(associateCode)){
            associateCode = (StringUtils.equals(type, "渠道联营") ? "QD-" : "CX-") + DateUtil.format(new Date(), DatePattern.PURE_DATE_PATTERN) + "-001";
        }else {
            int codeNum = Integer.valueOf(associateCode.split("-")[2]);
            String formattedNumber = String.format("%03d", codeNum+1);
            associateCode = (StringUtils.equals(type, "渠道联营") ? "QD-" : "CX-") + DateUtil.format(new Date(), DatePattern.PURE_DATE_PATTERN) + "-" + formattedNumber;
        }
        AssociateProtocol associateProtocol = new AssociateProtocol();
        associateProtocol.setApplyId(applyId);
        associateProtocol.setCode(associateCode);
        associateProtocol.setType(type);
        associateProtocol.setState(MemberConstants.AssociateProtocolState.BE_SENT.code);
        associateProtocol.setIsRead("0");
        associateProtocol.setSignTime(now);
        associateProtocol.setAuth("0");
        associateProtocol.setApplyNf(applyNf);
        //固定
        associateProtocol.setCreatedPerson(createPerson);
        associateProtocol.setCreatedAt(now);
        associateProtocol.setCreatedBy(code);
        return associateProtocol;
    }

    @Override
    @Transactional
    public Boolean editApproval(AssociateApplyEditApprovalDTO associateApplyEditApprovalDTO) {
        AssociateApply associateApply = this.getById(associateApplyEditApprovalDTO.getId());
        if (associateApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_ASSOCIATE);
        }
        if (StringUtils.equals(MemberConstants.AssociateApplyState.REFUSE_SIGN.code, associateApplyEditApprovalDTO.getState())){
            if (StringUtils.isEmpty(associateApplyEditApprovalDTO.getRejectSignReason())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.MUST_ASSOCIATE_REJECT_REASON);
            }
        }
        if (StringUtils.equals(associateApplyEditApprovalDTO.getState(), associateApply.getState())){
            //做好幂等处理。状态与数据库的一致，则不进行修改
            return true;
        }

        LocalDateTime now = LocalDateTime.now();
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String name = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(name)){
            name = name.substring(1, name.length() - 1);
        }

        UpdateWrapper<AssociateApply> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set(StringUtils.isNotEmpty(associateApplyEditApprovalDTO.getRejectSignReason()),"reject_sign_reason", associateApplyEditApprovalDTO.getRejectSignReason())
                .set("state", associateApplyEditApprovalDTO.getState())
                .set("approval_time", now)
                .set("updated_at", now)
                .set("updated_by", code)
                .eq("id", associateApplyEditApprovalDTO.getId());
        boolean result = this.update(updateWrapper);
        if (result){
            if (StringUtils.equals(associateApplyEditApprovalDTO.getState(), "4")){
                if (StringUtils.equals(associateApply.getCooperationProject(), "渠道联营")){
                    QueryWrapper<AssociateProtocol> associateProtocolQueryWrapper = new QueryWrapper<>();
                    associateProtocolQueryWrapper.eq("apply_id",  associateApply.getId()).eq("type", "渠道联营");
                    List<AssociateProtocol> list = associateProtocolMapper.selectList(associateProtocolQueryWrapper);
                    if (CollectionUtils.isEmpty(list)){
                        SubCompanyVO subCompanyVO = brandAuthApplyMapper.selectAddressBySubCompany(associateApply.getSubCompany());
                        AssociateProtocol associateProtocol = createAssociateProtocol(now, associateApply.getId(), "渠道联营", name, code, associateApply.getApplyNf());
                        associateProtocol.setProtocolUrl(createQdUrl(associateProtocol, associateApply, subCompanyVO));
                        associateProtocolMapper.insert(associateProtocol);
                    }
                    passAssociateApprovalMsg(associateApply, now);
                    protocolMsg(associateApply, now);
                }else if (StringUtils.equals(associateApply.getCooperationProject(), "产线联营")){
                    QueryWrapper<AssociateProtocol> associateProtocolQueryWrapper = new QueryWrapper<>();
                    associateProtocolQueryWrapper.eq("apply_id",  associateApply.getId()).eq("type", "产线联营");
                    List<AssociateProtocol> list = associateProtocolMapper.selectList(associateProtocolQueryWrapper);
                    if (CollectionUtils.isEmpty(list)){
                        AssociateProtocol associateProtocol = createAssociateProtocol(now, associateApply.getId(), "产线联营", name, code, associateApply.getApplyNf());
                        if (StringUtils.equals(associateApply.getSubCompany(), "上海供应链公司")){
                            //合作推荐单位属于“上海供应链公司”，才生成 协议数据
                            //https://zentao-gz.zyd.cn/index.php?m=bug&f=view&bugID=16339#app=execution
                            associateProtocol.setProtocolUrl(createCxUrl(associateProtocol, associateApply));
                            associateProtocolMapper.insert(associateProtocol);
                        }

                        QueryWrapper<AssociateApply> associateApplyQueryWrapper1 = new QueryWrapper<>();
                        associateApplyQueryWrapper1.eq("cooperation_project","产线联营")
                                .eq("linkphone", associateApply.getLinkphone()).eq("state", "4").ne("id", associateApplyEditApprovalDTO.getId());
                        List<AssociateApply> list1 = associateApplyMapper.selectList(associateApplyQueryWrapper1);
                        if (CollectionUtils.isEmpty(list1)){
                            //如果手机号不存在已经签约的联营申请
                            //则不添加供应商
                            addSupplier(associateProtocol, code, associateApply.getSubCompany());
                        }


                        passAssociateApprovalMsg(associateApply, now);
                        if (StringUtils.equals(associateApply.getSubCompany(), "上海供应链公司")){
                            protocolMsg(associateApply, now);
                        }
                    }
                }
//                else if (StringUtils.equals(associateApply.getCooperationProject(), "渠道联营+产线联营")){
//                    QueryWrapper<AssociateProtocol> associateProtocolQueryWrapper = new QueryWrapper<>();
//                    associateProtocolQueryWrapper.eq("apply_id",  associateApply.getId()).eq("type", "渠道联营");
//                    List<AssociateProtocol> list = associateProtocolMapper.selectList(associateProtocolQueryWrapper);
//                    if (CollectionUtils.isEmpty(list)){
//                        SubCompanyVO subCompanyVO = brandAuthApplyMapper.selectAddressBySubCompany(associateApply.getSubCompany());
//                        AssociateProtocol associateProtocol1 = createAssociateProtocol(now, associateApply.getId(), "渠道联营", name, code);
//                        associateProtocol1.setProtocolUrl(createQdUrl(associateProtocol1, associateApply, subCompanyVO));
//                        associateProtocolMapper.insert(associateProtocol1);
//                    }
//
//                    QueryWrapper<AssociateProtocol> associateProtocolQueryWrapper1 = new QueryWrapper<>();
//                    associateProtocolQueryWrapper1.eq("apply_id",  associateApply.getId()).eq("type", "产线联营");
//                    List<AssociateProtocol> list1 = associateProtocolMapper.selectList(associateProtocolQueryWrapper1);
//                    if (CollectionUtils.isEmpty(list1)){
//                        AssociateProtocol associateProtocol = createAssociateProtocol(now, associateApply.getId(), "产线联营", name, code);
//                        if (StringUtils.equals(associateApply.getSubCompany(), "上海供应链公司")) {
//                            //合作推荐单位属于“上海供应链公司”，才生成 协议数据
//                            associateProtocol.setProtocolUrl(createCxUrl(associateProtocol, associateApply));
//                            associateProtocolMapper.insert(associateProtocol);
//                        }
//                        addSupplier(associateProtocol, code, associateApply.getSubCompany());
//                    }
//                }



            }else if (StringUtils.equals(associateApplyEditApprovalDTO.getState(), "5")){
                //审批不通过
                TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
                triggerMsgRequest.setBusiness("associate");
                triggerMsgRequest.setScene("associateApprovalReject");
                JSONObject qywxParam = new JSONObject();
                qywxParam.put("msgtype", "template_card");
                qywxParam.put("noticeUser", associatePromotionMapper.selectCodeByName(associateApply.getPromotionPerson()));

                JSONObject templateCard = new JSONObject();
                templateCard.put("card_type", "text_notice");

                JSONObject mainTitle = new JSONObject();
                mainTitle.put("title", "拒绝联营客户签约");
                if (StringUtils.equals(associateApply.getCooperationProject(), "渠道联营")){
                    mainTitle.put("desc", "渠道联营申请");
                }else if (StringUtils.equals(associateApply.getCooperationProject(), "产线联营")){
                    mainTitle.put("desc", "产线联营申请");
                }
                templateCard.put("main_title", mainTitle);

                List<JSONObject> horizontalContentList = new ArrayList<>();
                JSONObject keyName1 = new JSONObject();
                keyName1.put("keyname", "客户");
                keyName1.put("value", associateApply.getCompany());
                horizontalContentList.add(keyName1);
                JSONObject keyName2 = new JSONObject();
                keyName2.put("keyname", "联系人");
                keyName2.put("value", associateApply.getLinkman());
                horizontalContentList.add(keyName2);
                JSONObject keyName3 = new JSONObject();
                keyName3.put("keyname", "审批时间");
                keyName3.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
                horizontalContentList.add(keyName3);
                JSONObject keyName4 = new JSONObject();
                keyName4.put("keyname", "备注");
                keyName4.put("value", "客户已拒绝签约，赶快去查看吧。");
                horizontalContentList.add(keyName4);
                templateCard.put("horizontal_content_list", horizontalContentList);

                List<JSONObject> jumpList = new ArrayList<>();
                JSONObject jumpList1 = new JSONObject();
                jumpList1.put("type", 1);
                jumpList1.put("title", "跳转惠采");
                jumpList1.put("url", odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(associateApply.getCompany()));
                jumpList.add(jumpList1);
                templateCard.put("jump_list", jumpList);

                JSONObject cardAction = new JSONObject();
                cardAction.put("type", 1);
                cardAction.put("url",  odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(associateApply.getCompany()));
                templateCard.put("card_action", cardAction);
                qywxParam.put("template_card", templateCard);
                triggerMsgRequest.setQywxParam(qywxParam);
                msgClient.triggerMsg(triggerMsgRequest);

                AssociateApply associateApply1 = this.getById(associateApplyEditApprovalDTO.getId());
                AssociateApplySnapshot associateApplySnapshot = BeanUtil.copyProperties(associateApply1, AssociateApplySnapshot.class, "id", "created_at", "created_by", "updated_at", "updated_by");
                associateApplySnapshot.setCreatedAt(now);
                associateApplySnapshot.setCreatedBy(name);
                associateApplySnapshotMapper.insert(associateApplySnapshot);

                QueryWrapper<AssociateApplyCustomerPlan> customerPlanQueryWrapper = new QueryWrapper<>();
                customerPlanQueryWrapper.eq("apply_id", associateApply1.getId());
                List<AssociateApplyCustomerPlan> associateApplyCustomerPlans = associateApplyCustomerPlanMapper.selectList(customerPlanQueryWrapper);
                if (CollectionUtils.isNotEmpty(associateApplyCustomerPlans)){
                    for (AssociateApplyCustomerPlan a : associateApplyCustomerPlans) {
                        AssociateApplyCustomerPlanSnapshot customerPlanSnapshot = BeanUtil.copyProperties(a, AssociateApplyCustomerPlanSnapshot.class, "id", "created_at", "created_by", "updated_at", "updated_by");
                        customerPlanSnapshot.setCreatedAt(now);
                        customerPlanSnapshot.setCreatedBy(name);
                        associateApplyCustomerPlanSnapshotService.save(customerPlanSnapshot);
                    }
                }


                QueryWrapper<AssociateApplyProductPlan> productPlanQueryWrapper = new QueryWrapper<>();
                productPlanQueryWrapper.eq("apply_id", associateApply1.getId());
                List<AssociateApplyProductPlan> associateApplyProductPlans = associateApplyProductPlanMapper.selectList(productPlanQueryWrapper);
                if (CollectionUtils.isNotEmpty(associateApplyProductPlans)){
                    for (AssociateApplyProductPlan a : associateApplyProductPlans) {
                        AssociateApplyProductPlanSnapshot productPlanSnapshot = BeanUtil.copyProperties(a, AssociateApplyProductPlanSnapshot.class, "id", "created_at", "created_by", "updated_at", "updated_by");
                        productPlanSnapshot.setCreatedAt(now);
                        productPlanSnapshot.setCreatedBy(name);
                        associateApplyProductPlanSnapshotService.save(productPlanSnapshot);
                    }
                }
            }
        }
        return result;
    }

    private void protocolMsg(AssociateApply associateApply, LocalDateTime now) {
        //联营协议发送
        TriggerMsgRequest triggerMsgRequest1 = new TriggerMsgRequest();
        triggerMsgRequest1.setBusiness("associate");
        triggerMsgRequest1.setScene("associateProtocol");
        JSONObject qywxParam1 = new JSONObject();
        qywxParam1.put("msgtype", "template_card");

        JSONObject templateCard1 = new JSONObject();
        templateCard1.put("card_type", "text_notice");

        JSONObject mainTitle1 = new JSONObject();
        mainTitle1.put("title", "联营协议待处理");
        mainTitle1.put("desc", associateApply.getCooperationProject() + "合作协议");
        templateCard1.put("main_title", mainTitle1);

        List<JSONObject> horizontalContentList1 = new ArrayList<>();
        JSONObject keyName11 = new JSONObject();
        keyName11.put("keyname", "客户名称");
        keyName11.put("value", associateApply.getCompany());
        horizontalContentList1.add(keyName11);
        JSONObject keyName21 = new JSONObject();
        keyName21.put("keyname", "联系人");
        keyName21.put("value", associateApply.getLinkman());
        horizontalContentList1.add(keyName21);
        JSONObject keyName31 = new JSONObject();
        keyName31.put("keyname", "审批时间");
        keyName31.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
        horizontalContentList1.add(keyName31);
        JSONObject keyName41 = new JSONObject();
        keyName41.put("keyname", "备注");
        keyName41.put("value", "合作协议已生成，赶快查看并跟进处理吧。");
        horizontalContentList1.add(keyName41);
        templateCard1.put("horizontal_content_list", horizontalContentList1);

        List<JSONObject> jumpList11 = new ArrayList<>();
        JSONObject jumpList111 = new JSONObject();
        jumpList111.put("type", 1);
        jumpList111.put("title", "跳转惠采");
        jumpList111.put("url", odsUrl + "/#/purchase-sign/protocol?key=" + URLUtil.encode(associateApply.getCompany()));
        jumpList11.add(jumpList111);
        templateCard1.put("jump_list", jumpList11);

        JSONObject cardAction1 = new JSONObject();
        cardAction1.put("type", 1);
        cardAction1.put("url",  odsUrl + "/#/purchase-sign/protocol?key=" + URLUtil.encode(associateApply.getCompany()));
        templateCard1.put("card_action", cardAction1);
        qywxParam1.put("template_card", templateCard1);
        triggerMsgRequest1.setQywxParam(qywxParam1);
        msgClient.triggerMsg(triggerMsgRequest1);
    }

    private void passAssociateApprovalMsg(AssociateApply associateApply, LocalDateTime now) {
        //审批通过
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("associate");
        triggerMsgRequest.setScene("associateApprovalPass");
        JSONObject qywxParam = new JSONObject();
        qywxParam.put("msgtype", "template_card");
        qywxParam.put("noticeUser", associatePromotionMapper.selectCodeByName(associateApply.getPromotionPerson()));

        JSONObject templateCard = new JSONObject();
        templateCard.put("card_type", "text_notice");

        JSONObject mainTitle = new JSONObject();
        mainTitle.put("title", "同意联营客户签约");
        if (StringUtils.equals(associateApply.getCooperationProject(), "渠道联营")){
            mainTitle.put("desc", "渠道联营申请");
        }else if (StringUtils.equals(associateApply.getCooperationProject(), "产线联营")){
            mainTitle.put("desc", "产线联营申请");
        }
        templateCard.put("main_title", mainTitle);

        List<JSONObject> horizontalContentList = new ArrayList<>();
        JSONObject keyName1 = new JSONObject();
        keyName1.put("keyname", "客户");
        keyName1.put("value", associateApply.getCompany());
        horizontalContentList.add(keyName1);
        JSONObject keyName2 = new JSONObject();
        keyName2.put("keyname", "联系人");
        keyName2.put("value", associateApply.getLinkman());
        horizontalContentList.add(keyName2);
        JSONObject keyName3 = new JSONObject();
        keyName3.put("keyname", "审批时间");
        keyName3.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
        horizontalContentList.add(keyName3);
        JSONObject keyName4 = new JSONObject();
        keyName4.put("keyname", "备注");
        keyName4.put("value", "客户已同意签约，赶快去查看吧。");
        horizontalContentList.add(keyName4);
        templateCard.put("horizontal_content_list", horizontalContentList);

        List<JSONObject> jumpList = new ArrayList<>();
        JSONObject jumpList1 = new JSONObject();
        jumpList1.put("type", 1);
        jumpList1.put("title", "跳转惠采");
        jumpList1.put("url", odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(associateApply.getCompany()));
        jumpList.add(jumpList1);
        templateCard.put("jump_list", jumpList);

        JSONObject cardAction = new JSONObject();
        cardAction.put("type", 1);
        cardAction.put("url",  odsUrl + "/#/purchase-sign/apply?key=" + URLUtil.encode(associateApply.getCompany()));
        templateCard.put("card_action", cardAction);
        qywxParam.put("template_card", templateCard);
        triggerMsgRequest.setQywxParam(qywxParam);
        msgClient.triggerMsg(triggerMsgRequest);
    }

    public void addSupplier(AssociateProtocol associateProtocol, String code, String subCompany){
        AssociateApply associateApply = associateApplyMapper.selectById(associateProtocol.getApplyId());
            //更新成功，并且为【已生效】， 并且为产线联营
        SupplierDTO supplierDTO = new SupplierDTO();
        supplierDTO.setName(associateApply.getCompany());
        supplierDTO.setCode(associateApply.getLinkphone());
        supplierDTO.setType(MemberConstants.SupplierSourceType.ASSOCIATE_PROTOCOL.code);
        supplierDTO.setShortName(subCompany);
        supplierDTO.setSend(false);
        supplierDTO.setCreatedBy(code);
        supplierDTO.setUpdatedBy(code);
        //添加供应商、用户及发送短信
        JsonResult<SupplierDTO> jsonResult = userClient.add(supplierDTO);
        if (!jsonResult.isSuccess()){
            BaseExceptionDesc baseExceptionDesc = new BaseExceptionDesc(PurchaseBusinessExceptionDesc.ERROR_BIND_SUPPLIER.getCode(), jsonResult.getMsg());
            throw BusinessException.newInstance(baseExceptionDesc);
        }
    }
}
