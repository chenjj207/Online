package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.entity.Cooperation;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CooperationInfoVO;
import com.purchase.service.vo.CooperationPageVO;
import com.purchase.service.vo.MemberCooperationVO;


/**
 * <p>
 * 协作表 服务类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
public interface CooperationService extends IService<Cooperation> {

    Page<CooperationPageVO> search(CooperationPageDTO cooperationPageDTO);

    Boolean add(CooperationAddDTO cooperationAddDTO, boolean isMiniProgram);

    Page<MemberCooperationVO> inquire(MemberCooperationDTO memberCooperationDTO );

    CooperationInfoVO queryInfo(QueryIdDTO queryIdDTO);

    Boolean mallAdd(CooperationMallAddDTO cooperationMallAddDTO);

    Boolean audit(CooperationAuditDTO cooperationAuditDTO);
}
