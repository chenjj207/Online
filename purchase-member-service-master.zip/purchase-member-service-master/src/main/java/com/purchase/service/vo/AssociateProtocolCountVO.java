package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/3/18  10:46
 */
@Data
public class AssociateProtocolCountVO {
    @Schema(description = "状态")
    private String state;
    @Schema(description = "数量")
    private int count;
}
