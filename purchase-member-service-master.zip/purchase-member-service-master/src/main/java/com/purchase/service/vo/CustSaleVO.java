package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/4/19  13:32
 */
@Data
@Schema(title = "客户销售数据")
public class CustSaleVO {

    @Schema(description = "客户公司名称")
    private String company;

    @Schema(description = "子公司名称")
    private String subCompany;

    @Schema(description = "施耐德第一季度销售金额")
    private BigDecimal sndS1Xsje;

    @Schema(description = "施耐德第二季度销售金额")
    private BigDecimal sndS2Xsje;

    @Schema(description = "施耐德第三季度销售金额")
    private BigDecimal sndS3Xsje;

    @Schema(description = "施耐德第四季度销售金额")
    private BigDecimal sndS4Xsje;

    @Schema(description = "施耐德全年销售金额 /  本年度施耐德累计采购额")
    private BigDecimal sndQnXsje;

    @Schema(description = "分销汇总的第1季度销售")
    private BigDecimal fxhzS1Xsje;

    @Schema(description = "分销汇总的第2季度销售")
    private BigDecimal fxhzS2Xsje;

    @Schema(description = "分销汇总的第3季度销售")
    private BigDecimal fxhzS3Xsje;

    @Schema(description = "分销汇总的第4季度销售")
    private BigDecimal fxhzS4Xsje;

    @Schema(description = "分销汇总的全年销售")
    private BigDecimal fxhzQnXsje;

    @Schema(description = "年份")
    private String nf;

    @Schema(description = "数据日期")
    private String sjrq;

}
