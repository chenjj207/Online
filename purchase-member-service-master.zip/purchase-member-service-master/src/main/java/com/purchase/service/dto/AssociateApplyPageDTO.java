package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Pattern;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Data
public class AssociateApplyPageDTO extends PageDTO {

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    @Schema(description = "开始时间")
    private LocalDateTime beginTime;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    @Schema(description = "结束时间")
    private LocalDateTime endTime;

    @Schema(description = "状态")
    @Pattern(regexp = "1|2|3|4|5",message = "状态参数错误")
    private String state;

    @Schema(description = "联营合作诉求")
    private String cooperationDemand;

    @Schema(description = "合作项目")
    private String cooperationProject;

    @Schema(description = "项目推广专员")
    private String promotionPerson;

    @Schema(description = "调研形式")
    private String researchFormat;

    @Schema(description = "客户类型")
    private String customerType;

    @Schema(description = "子公司名称")
    private List<String> subCompany;

    @Schema(description = "模糊查询 调研人员/客户名称/联系人/联系方式")
    private String key;

    @Schema(description = "申请年份")
    private String applyNf;
}
