package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/2/3  13:56
 */
@Data
public class RealNewsPageDTO extends PageDTO {


    @Schema(description = "是否显示(0为发布，1为未发布)")
    private Integer isShow;

    @Schema(description = "资讯类型")
    private String consultType;

    @Schema(description = "关键字")
    private String key;

    @Schema(description = "发布页面： firstPage：首页   center：资讯中心")
    private String page;

    @Schema(description = "是否开启感兴趣(0为未开启，1为开启)")
    private Integer isOpenInterested;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "起始时间")
    private Date beginTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "结束时间")
    private Date endTime;
}
