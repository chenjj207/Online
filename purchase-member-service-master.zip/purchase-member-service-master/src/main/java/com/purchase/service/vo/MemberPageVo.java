package com.purchase.service.vo;

import com.purchase.entity.Member;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class MemberPageVo extends Member {

    @Schema(description = "是否开通供应商")
    private Boolean isSuppiler;
    @Schema(description = "未读消息数")
    private Integer notReadNum;
}
