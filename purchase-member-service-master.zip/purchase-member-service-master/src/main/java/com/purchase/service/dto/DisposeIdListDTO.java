package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
public class DisposeIdListDTO {

    @Schema(description = "需要处理id数组")
    List<Integer> id;
}
