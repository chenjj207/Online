package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;


@Data
public class MemberLoginCheckDTO {
    @NotEmpty(message = "微信js码不能为空")
    @Schema(description = "微信登录时获取的code")
    private String jsCode;

    @NotEmpty(message = "手机号码不能为空")
    @Pattern(regexp = "^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\\d{8}$",message = "手机格式错误")
    @Schema(description = "联系方式")
    private String linkphone;


}
