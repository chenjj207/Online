package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import javax.validation.constraints.NotEmpty;


@Data
public class CustSaleQueryDTO {

    @Schema(description = "分公司简称")
    @NotEmpty(message = "分公司简称不能为空")
    private String shortName;

    @Schema(description = "年份")
    @NotEmpty(message = "年份不能为空")
    private String nf;

    @Schema(description = "客户名称")
    @NotEmpty(message = "客户名称不能为空")
    private String khmc;

}
