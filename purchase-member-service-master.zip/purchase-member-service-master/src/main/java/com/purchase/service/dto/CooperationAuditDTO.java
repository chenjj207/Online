package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Data
public class CooperationAuditDTO extends BaseEntity {
    @Schema(description = "协作id")
    @NotNull(message = "协作id不能为空")
    private Integer id;

    @Schema(description = "审核状态")
    @NotNull(message = "审核状态不能为空")
    private Integer auditState;

    @Schema(description = "拒绝原因")
    private String rejectReason;
}
