package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class MemberCountVO {

    @Schema(description = "会员协作数")
    private Integer CooperationNum;

    @Schema(description = "会员未读信息数")
    private Integer UnReadNum;
}
