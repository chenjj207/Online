package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.AssociateApply;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CommonCountVO;

import java.util.List;

/**
 * <p>
 * 联营申请表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-14
 */
public interface AssociateApplyService extends IService<AssociateApply> {

    public String add(AssociateApplyAddDTO associateApplyAddDTO);

    public AssociateApply queryByJsCode(AssociateApplyQueryDTO associateApplyQueryDTO);

    public List<PurchaseCompanyDTO> queryPurchaseCompany();

    public Boolean edit(AssociateApplyEditDTO associateApplyEditDTO);

    public String editMini(AssociateApplyEditDTO associateApplyEditDTO);

    public Page<AssociateApply> queryList(AssociateApplyPageDTO associateApplyPageDTO);

    public List<CommonCountVO> countNum(AssociateApplyCountDTO associateApplyCountDTO);

    public AssociateApply queryById(QueryIdDTO queryIdDTO);

    public List<AssociateApply> queryByOpenId(OpenIdDTO openIdDTO);

    public Boolean editResearch(AssociateApplyEditResearchDTO associateApplyEditResearchDTO);

    public Boolean editApproval(AssociateApplyEditApprovalDTO associateApplyEditApprovalDTO);
}
