package com.purchase.service;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.util.URLUtil;
import com.alibaba.fastjson.JSONObject;
import com.purchase.client.WXClient;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.service.dto.JsCodeDTO;
import com.purchase.service.vo.WxVO;
import com.zyd.framework.utils.constant.UserSession;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.redis.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/1  10:31
 */
@Service
@Slf4j
public class CommonService {

    @Resource
    private WXClient wxClient;
    @Value("${wx.appid}")
    String appid;
    @Value("${wx.secret}")
    String secret;

    public WxVO getOpeId(JsCodeDTO jsCodeDTO){
        //get请求 https://api.weixin.qq.com/sns/jscode2session 获取session_key，unionid，openid等数据
        JSONObject jsonObject = wxClient.jscode2session(appid, secret, jsCodeDTO.getJsCode());
        if (jsonObject.containsKey("errcode") && jsonObject.getInteger("errcode") != 0){
            log.error(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getCode() + ": " +
                    PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR.getDesc() + ": " + jsonObject.getString("errmsg"));
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR);
        }
        String openid = jsonObject.getString("openid");
        String unionid = jsonObject.getString("unionid");
        WxVO wxVO = new WxVO();
        wxVO.setOpenid(openid);
        wxVO.setUnionid(unionid);
        return wxVO;
    }


    //获取慧采商城端客户id
    public String loginId(){
        String[] loginIds = StpUtil.getLoginIdAsString().split("-");
        String custId = loginIds[1];
        if (StringUtils.equalsIgnoreCase(custId, "NULL")){
            //客户不存在
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.USER_NOT_EXIST);
        }
        return custId;
    }

    //联营慧PC端获取登录用户 会员id
    public String memberId(){
        String[] loginIds = StpUtil.getLoginIdAsString().split("-");
        String memberId = loginIds[2];
        return memberId;
    }

    //获取登录客户信息
    public JSONObject getCustInfo(){
        JSONObject json = StpUtil.getSession().getModel(UserSession.INFO,JSONObject.class);
        return json;
    }

    public Map<Object,Object> getUserInfo()  {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String token = URLUtil.decode(request.getHeader("sessionid"), StandardCharsets.UTF_8);
        try {
            return RedisUtil.HashOps.hGetAll(token);
        }catch (IllegalArgumentException e){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NO_LOGIN);
        }

    }
}
