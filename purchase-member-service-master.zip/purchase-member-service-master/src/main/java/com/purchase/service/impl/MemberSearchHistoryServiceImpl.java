package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.MemberSearchHistory;
import com.purchase.mapper.MemberSearchHistoryMapper;
import com.purchase.service.MemberSearchHistoryService;
import com.purchase.service.dto.MemberSearchHistoryAddDTO;
import com.purchase.service.dto.QueryIdDTO;
import com.zyd.framework.boot.config.base.PageDTO;
import com.zyd.framework.utils.exception.BusinessException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;

/**
 * <p>
 * 客户搜索历史表 服务实现类
 * </p>
 *
 * @author
 * @since 2023-02-10
 */
@Service
public class MemberSearchHistoryServiceImpl extends ServiceImpl<MemberSearchHistoryMapper, MemberSearchHistory> implements MemberSearchHistoryService {

    @Resource
    MemberSearchHistoryMapper memberSearchHistoryMapper;

    @Override
    public Boolean add(MemberSearchHistoryAddDTO memberSearchHistoryAddDTO) {
        //判定是否登录，登录则再进行判定将关键字是否存入数据库
        if(ObjectUtil.isNotNull(StpUtil.getLoginIdDefaultNull())){
            QueryWrapper<MemberSearchHistory> wrapper = new QueryWrapper<>();
            String memberId = (String) StpUtil.getLoginId();
            //判断该会员是否已有该关键字
            wrapper.eq("search_key",memberSearchHistoryAddDTO.getSearchKey())
                    .eq("member_id",StpUtil.getLoginId());
            if (memberSearchHistoryMapper.selectCount(wrapper)>0){
                return true;
            }
            //没有则把关键字加入数据库
            MemberSearchHistory memberSearchHistory =new MemberSearchHistory();
            memberSearchHistory.setMemberId(Integer.valueOf(memberId) );
            BeanUtil.copyProperties(memberSearchHistoryAddDTO,memberSearchHistory);
            memberSearchHistory.setCreatedAt(LocalDateTime.now());
            return save(memberSearchHistory);
        }
        return null;
    }

    @Override
    public Page<MemberSearchHistory> pageList(PageDTO pageDTO) {
        QueryWrapper<MemberSearchHistory> wrapper = new QueryWrapper<>();
        wrapper.eq("member_id", StpUtil.getLoginId())
                .orderByDesc("created_at");;
        return memberSearchHistoryMapper.selectPage(pageDTO.buildPage(),wrapper);
    }

    @Override
    public Boolean deleted(QueryIdDTO queryIdDTO) {
        QueryWrapper<MemberSearchHistory> wrapper = new QueryWrapper<>();
        wrapper.eq("id",queryIdDTO.getId())
                .eq("member_id",StpUtil.getLoginId());
       //判断会员是否拥有相关历史搜索记录
        if (ObjectUtil.isAllEmpty( memberSearchHistoryMapper.selectOne(wrapper))){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.UN_ABLE_DELETE);
        }
        return removeById(queryIdDTO.getId());
    }

    @Override
    public Boolean allDeleted() {
        QueryWrapper<MemberSearchHistory> wrapper = new QueryWrapper<>();
        wrapper.eq("member_id",StpUtil.getLoginId());
        return remove(wrapper);
    }
}
