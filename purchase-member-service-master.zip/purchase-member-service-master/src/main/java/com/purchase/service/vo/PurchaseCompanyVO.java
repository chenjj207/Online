package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PurchaseCompanyVO {

    @Schema(description = "所属公司")
    private String companyName;

    @Schema(description = "所属大区")
    private String areaName;
}
