package com.purchase.service;

import com.purchase.entity.BrandAuthApplySnapshot;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 品牌授权申请 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-22
 */
public interface BrandAuthApplySnapshotService extends IService<BrandAuthApplySnapshot> {

}
