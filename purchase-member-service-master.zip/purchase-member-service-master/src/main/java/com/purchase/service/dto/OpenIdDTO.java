package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
* <p>
* openId换取
* </p>
* @author jidonglin
* @since 2024-03-18
*/
@Data
@Schema(title = "openId换取")
public class OpenIdDTO {

    @NotEmpty(message = "openId不能为空")
    @Schema(description = "openId")
    private String openId;


}
