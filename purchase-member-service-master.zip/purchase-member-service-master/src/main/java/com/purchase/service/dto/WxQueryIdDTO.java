package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;


@Data
public class WxQueryIdDTO {

    @NotNull(message = "参数id不能为空")
    @Schema(description = "需要查询详情的id")
    private Integer id;

    @Schema(description = "是否记录浏览数")
    private Integer isRecord;
}
