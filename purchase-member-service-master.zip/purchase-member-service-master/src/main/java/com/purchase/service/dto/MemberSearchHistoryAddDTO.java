package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MemberSearchHistoryAddDTO {

    @NotBlank(message = "关键字不能为空")
    @Schema(description = "关键字")
    private String searchKey;

}
