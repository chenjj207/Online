package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/3/15  10:29
 */
@Data
public class PurchaseCompanyDTO {

    @Schema(description = "地区")
    private String areaName;

    @Schema(description = "子公司名称")
    private List<String> companyName;
}
