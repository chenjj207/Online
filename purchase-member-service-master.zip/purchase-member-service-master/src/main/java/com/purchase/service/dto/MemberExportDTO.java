package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class MemberExportDTO {

    @Schema(description = "联系人")
    private String linkman;

    @Schema(description = "联系方式")
    private String linkphone;

    @Schema(description = "状态（0=待审核，1=通过，2=未通过）")
    private Integer state;

    @Schema(description = "管理端搜索关键字")
    private String Key;

    @Schema(description = "会员公司")
    private String company;

    @Schema(description = "对应服务行业")
    private String industry;

    @Schema(description = "所属公司")
    private List<String> companyName;

    @Schema(description = "核心能力")
    private String competence;

    @Schema(description = "是否在小程序通讯录显示（0=不显示，1= 显示）")
    private Integer isShow;

    @Schema(description = "核心能力描述")
    private String competenceInfo;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "开始时间")
    private Date beginTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "结束时间")
    private Date endTime;
}
