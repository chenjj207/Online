package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CooperationReplyDeleteDTO {

    @Schema(description = "协作id")
    private Integer cooperationId;
}
