package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/4/19  9:12
 */
@Data
@Schema(description = "品牌授权时间")
public class BrandAuthTimeVO {

    @Schema(description = "授权期限 1、第一季度 2、第二季度 3、第三季度 4、第四季度")
    private String authTime;

    @Schema(description = "年 如：2024")
    private Integer year;
}
