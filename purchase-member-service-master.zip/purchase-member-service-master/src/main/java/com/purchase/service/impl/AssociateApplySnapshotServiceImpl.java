package com.purchase.service.impl;

import com.purchase.entity.AssociateApplySnapshot;
import com.purchase.mapper.AssociateApplySnapshotMapper;
import com.purchase.service.AssociateApplySnapshotService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 联营申请表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-15
 */
@Service
public class AssociateApplySnapshotServiceImpl extends ServiceImpl<AssociateApplySnapshotMapper, AssociateApplySnapshot> implements AssociateApplySnapshotService {

}
