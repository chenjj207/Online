package com.purchase.service;

import com.purchase.entity.MemberRealNews;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.RealNewsUpvoteDTO;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-12
 */
public interface MemberRealNewsService extends IService<MemberRealNews> {

    Boolean upvote(RealNewsUpvoteDTO realNewsUpvoteDTO);
}
