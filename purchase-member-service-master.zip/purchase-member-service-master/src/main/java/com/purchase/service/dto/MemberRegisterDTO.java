package com.purchase.service.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;


@Data
public class MemberRegisterDTO  {

    @NotEmpty(message = "会员公司不能为空")
    @Schema(description = "会员公司")
    private String company;

    @NotEmpty(message = "对应服务行业不能为空")
    @Schema(description = "对应服务行业")
    private String industry;

    @NotEmpty(message = "核心能力不能为空")
    @Schema(description = "核心能力")
    private String competence;

    @NotEmpty(message = "核心能力描述不能为空")
    @Schema(description = "核心能力描述")
    private String competenceInfo;

    @NotEmpty(message = "联系人不能为空")
    @Schema(description = "联系人")
    private String linkman;

    @Schema(description = "推广人")
    private String promoter;

    @NotBlank(message = "短信验证码不能为空")
    @Schema(description = "短信验证码")
    private String smsCode;

    @NotEmpty(message = "联系方式不能为空")
    @Pattern(regexp = "^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\\d{8}$",message = "手机格式错误")
    @Schema(description = "联系方式")
    private String linkphone;

    @NotEmpty(message = "省不能为空")
    @Schema(description = "省")
    private String province;

    @NotEmpty(message = "市不能为空")
    @Schema(description = "市")
    private String city;

    @NotEmpty(message = "区不能为空")
    @Schema(description = "区")
    private String area;

    @Schema(description = "会员头像地址")
    private String iconUrl;


    @Schema(description = "详细地址")
    private String address;

    @Schema(description = "微信union_id")
    private String unionId;

    @NotEmpty(message = "微信用户标识不能为空")
    @Schema(description = "微信用户在当前小程序的唯一标识")
    private String openId;

    @Schema(description = "微信昵称")
    private String wxNickName;

    @Schema(description = "图片地址")
    private String memberUrl;

}
