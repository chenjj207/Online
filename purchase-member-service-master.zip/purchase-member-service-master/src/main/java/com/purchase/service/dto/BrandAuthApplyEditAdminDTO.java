package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
* <p>
* 品牌授权申请
* </p>
*
* @author jidonglin
* @since 2024-04-11
*/
@Data
@Schema(title = "品牌授权申请 修改")
public class BrandAuthApplyEditAdminDTO {

    @Schema(description = "主键")
    @NotNull(message = "主键不能为空")
    private Integer id;

    @Schema(description = "单位名称/客户名称")
    @NotEmpty(message = "单位名称不能为空")
    private String company;

    @Schema(description = "联系人")
    @NotEmpty(message = "联系人不能为空")
    private String linkman;

    @Schema(description = "联系电话")
    @NotEmpty(message = "联系电话不能为空")
    private String linkphone;

    @Schema(description = "注册地址的省")
    @NotEmpty(message = "注册地址的省不能为空")
    private String province;

    @Schema(description = "注册地址的市")
    @NotEmpty(message = "注册地址的市不能为空")
    private String city;

    @Schema(description = "注册地址的区")
    @NotEmpty(message = "注册地址的区不能为空")
    private String area;

    @Schema(description = "注册地址的详细地址")
    @NotEmpty(message = "注册地址的详细地址不能为空")
    private String address;

    @Schema(description = "营业地址省")
    @NotEmpty(message = "营业地址的省不能为空")
    private String businessProvince;

    @Schema(description = "营业地址市")
    @NotEmpty(message = "营业地址的市不能为空")
    private String businessCity;

    @Schema(description = "营业地址区")
    @NotEmpty(message = "营业地址的区不能为空")
    private String businessArea;

    @Schema(description = "营业地址详细地址")
    @NotEmpty(message = "营业地址的详细地址不能为空")
    private String businessAddress;

    @Schema(description = "所属大区")
    @NotEmpty(message = "所属大区不能为空")
    private String areaName;

    @Schema(description = "合作单位/子公司名称")
    @NotEmpty(message = "合作单位不能为空")
    private String subCompany;

    @Schema(description = "签约推荐人")
    @NotEmpty(message = "签约推荐人不能为空")
    private String businessPerson;

    @Schema(description = "公司上年营业额")
    @NotNull(message = "公司营业额错误不能为空")
    @Digits(integer=10, fraction=4, message = "公司营业额错误，请重新输入")
    private BigDecimal lastYearTurnover;

    @Schema(description = "品牌上年营业额，如：23年施耐德电气营业额")
    @NotNull(message = "施耐德电气营业额不能为空")
    @Digits(integer=10, fraction=4, message = "施耐德电气营业额错误，请重新输入")
    private BigDecimal brandLastYearTurnover;

    @Schema(description = "核心客户数量")
    @NotNull(message = "核心客户数量不能为空")
    @Max(value = 999999, message = "核心客户数量长度有误，请重新输入")
    private Integer custNum;

    @Schema(description = "员工人数")
    @NotEmpty(message = "员工人数不能为空")
    private String userNum;

    @Schema(description = "终端（行业） 单位：%")
    @NotEmpty(message = "终端（行业）不能为空")
    private String terminal;

    @Schema(description = "批发 单位：%")
    @NotEmpty(message = "批发不能为空")
    private String wholesale;

    @Schema(description = "中小项目 单位：%")
    @NotEmpty(message = "中小项目不能为空")
    private String smallMediumProject;

    @Schema(description = "OEM 单位：%")
    @NotEmpty(message = "oem不能为空")
    private String oem;

    @Schema(description = "门店 单位：%")
    @NotEmpty(message = "门店不能为空")
    private String store;

    @Schema(description = "核心业务-其他 单位：%")
    @NotEmpty(message = "其他核心业务不能为空")
    private String coreBusinessOther;

    @Schema(description = "低压配电 单位：%")
    @NotEmpty(message = "低压配电不能为空")
    private String lowVoltage;

    @Schema(description = "工业自动化 单位：%")
    @NotEmpty(message = "工业自动化不能为空")
    private String industrialAuto;

    @Schema(description = "面板开关 单位：%")
    @NotEmpty(message = "面板开关不能为空")
    private String panelSwitch;

    @Schema(description = "主要业务-其他 单位：%")
    @NotEmpty(message = "其他主要业务不能为空")
    private String mainBusinessOther;

    @Schema(description = "se")
    @NotEmpty(message = "se不能为空")
    private String se;

    @Schema(description = "abb")
    @NotEmpty(message = "abb不能为空")
    private String abb;

    @Schema(description = "Siemens")
    @NotEmpty(message = "Siemens不能为空")
    private String siemens;

    @Schema(description = "合作品牌-其他")
    @NotEmpty(message = "合作品牌不能为空")
    private String cooperateBrandOther;

    @Schema(description = "国产")
    @NotEmpty(message = "国产不能为空")
    private String domestic;

    @Schema(description = "增长类型：正增长 负增长")
    @NotEmpty(message = "增长类型不能为空")
    private String growthType;

    @Schema(description = "增长比例")
    @NotEmpty(message = "增长比例不能为空")
    private String growthRate;

    @Schema(description = "原因")
    @NotEmpty(message = "原因不能为空")
    @Length(max = 100, message = "原因长度有误")
    private String growthReason;

    @Schema(description = "品牌形象")
    @NotEmpty(message = "品牌形象不能为空")
    private String brandImage;

    @Schema(description = "品牌商城")
    @NotEmpty(message = "品牌商城不能为空")
    private String brandMall;

    @Schema(description = "数字化营销")
    @NotEmpty(message = "数字化营销不能为空")
    private String digitalMarket;

    @Schema(description = "上游诉求")
    @NotEmpty(message = "上游诉求不能为空")
    @Length(max = 100, message = "上游诉求长度有误，请重新输入")
    private String upstreamDemand;

    @Schema(description = "次终端诉求")
    @NotEmpty(message = "次终端诉求不能为空")
    @Length(max = 100, message = "次终端诉求长度有误，请重新输入")
    private String secondTerminalDemand;

    @Schema(description = "上游分销商（线上）")
    @NotEmpty(message = "上游分销商（线上）不能为空")
    @Length(max = 100, message = "上游分销商（线上）长度有误，请重新输入")
    private String onlineUpstreamDistributor;

    @Schema(description = "上游分销商（线下）")
    @NotEmpty(message = "上游分销商（线下）不能为空")
    @Length(max = 100, message = "上游分销商（线下）长度有误，请重新输入")
    private String offlineUpstreamDistributor;

    @Schema(description = "终端客户名称")
    @NotEmpty(message = "终端客户名称不能为空")
    @Length(max = 100, message = "终端客户名称长度有误")
    private String endCustName;

    @Schema(description = "终端客户23年总采购额")
    @NotNull(message = "终端客户总采购额错误不能为空")
    @Digits(integer=10, fraction=4, message = "终端客户总采购额错误，请重新输入")
    private BigDecimal totalPurchaseLastYear;

    @Schema(description = "授权需求")
    @NotEmpty(message = "授权需求不能为空")
    @Length(max = 100, message = "授权需求长度有误")
    private String authRequire;

    @Schema(description = "备注（其他补充说明）")
    @Length(max = 100, message = "备注长度有误")
    private String demandRemark;

    @Schema(description = "上年合作采购额")
    @NotNull(message = "合作采购额不能为空")
    @Digits(integer=10, fraction=4, message = "合作采购额错误，请重新输入")
    private BigDecimal lastYearCooperatePurchase;

    @Schema(description = "施耐德采购额")
    @NotNull(message = "施耐德采购额不能为空")
    @Digits(integer=10, fraction=4, message = "施耐德采购额错误，请重新输入")
    private BigDecimal lastYearBrandPurchase;

    @Schema(description = "全年施耐德采购指标")
    @NotNull(message = "全年施耐德采购指标不能为空")
    @Digits(integer=10, fraction=4, message = "全年施耐德采购指标错误， 请重新输入")
    private BigDecimal yearAnnualIndicators;

    @Schema(description = "第一季度指标")
    @NotNull(message = "第一季度指标不能为空")
    @Digits(integer=10, fraction=4, message = "第一季度指标错误，请重新输入")
    private BigDecimal oneIndicators;

    @Schema(description = "第二季度指标")
    @NotNull(message = "第二季度指标不能为空")
    @Digits(integer=10, fraction=4, message = "第二季度指标错误，请重新输入")
    private BigDecimal twoIndicators;

    @Schema(description = "第三季度指标")
    @NotNull(message = "第三季度指标不能为空")
    @Digits(integer=10, fraction=4, message = "第三季度指标错误，请重新输入")
    private BigDecimal threeIndicators;

    @Schema(description = "	第四季度指标")
    @NotNull(message = "第四季度指标不能为空")
    @Digits(integer=10, fraction=4, message = "第四季度指标错误，请重新输入")
    private BigDecimal fourIndicators;

    @Schema(description = "单位：（个工作日内）采购首批协议产品	")
    @NotNull(message = "协议签订后不能为空")
    @Max(value = 999999, message = "协议签订后长度有误，请重新输入")
    private Integer afterSignDay;

    @Schema(description = "计算关联带出，根据填写的【24全年指标*10%】得出，不可修改")
    @NotNull(message = "签约首单采购金额不低于不能为空")
    private BigDecimal firstPurchaseAmount;

    @Schema(description = "开户名称")
    @NotEmpty(message = "开户名称不能为空")
    @Length(max = 50, message = "开户名称长度有误，请重新输入")
    private String accountName;

    @Schema(description = "银行账号")
    @NotEmpty(message = "银行账号不能为空")
    @Length(max = 50, message = "银行账号长度有误，请重新输入")
    private String bankAccountNum;

    @Schema(description = "开户银行")
    @NotEmpty(message = "开户银行不能为空")
    @Length(max = 50, message = "开户银行长度有误，请重新输入")
    private String openingBank;

    @Schema(description = "纳税人识别号")
    @NotEmpty(message = "纳税人识别号不能为空")
    @Length(max = 50, message = "纳税人识别号长度有误，请重新输入")
    private String taxIdentification;

    @Schema(description = "计划采购额, 首次申请可不传，续约时必传")
    @Digits(integer=10, fraction=4, message = "计划采购额错误，请重新输入")
    private BigDecimal planPurchase;



}
