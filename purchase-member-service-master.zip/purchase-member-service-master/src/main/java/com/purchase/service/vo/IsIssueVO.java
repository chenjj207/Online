package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class IsIssueVO {

    @Schema(description = "是否发布协作")
    private Boolean IsIssue;
}
