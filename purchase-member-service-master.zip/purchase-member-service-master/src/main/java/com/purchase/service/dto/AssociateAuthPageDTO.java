package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@Schema(title = "联营授权分页查询")
public class AssociateAuthPageDTO extends PageDTO {

    @Schema(description = "协议id")
    @NotNull(message = "协议id不能为空")
    private Integer protocolId;
}
