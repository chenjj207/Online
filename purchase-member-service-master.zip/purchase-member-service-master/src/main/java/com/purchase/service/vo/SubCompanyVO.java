package com.purchase.service.vo;

import com.purchase.entity.BrandAuthApply;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author jidonglin
 * @Description: 续约 查询实体
 * @date 2024/4/19  14:04
 */
@Data
@Schema(title = "子公司实体")
public class SubCompanyVO {

    @Schema(description = "分公司编码")
    private String comBm;
    @Schema(description = "分公司名称")
    private String comName;
    @Schema(description = "分公司简称")
    private String shortName;
    @Schema(description = "所属大区")
    private String areaName;
    @Schema(description = "开户银行号")
    private String bankName;
    @Schema(description = "开户帐号")
    private String bankAccount;
    @Schema(description = "开户公司名")
    private String bankComName;
    @Schema(description = "地址")
    private String address;
    @Schema(description = "纳税人识别号")
    private String taxNumber;
    @Schema(description = "ifs域")
    private String ifsContract;
}
