package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.client.feign.MsgClient;
import com.purchase.common.MemberConstants;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.Cooperation;
import com.purchase.entity.Member;
import com.purchase.entity.RealNews;
import com.purchase.mapper.CooperationMapper;
import com.purchase.service.CommonService;
import com.purchase.service.CooperationService;
import com.purchase.service.RealNewsService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CooperationInfoVO;
import com.purchase.service.vo.CooperationPageVO;
import com.purchase.service.vo.MemberCooperationVO;
import com.purchase.utils.NoticeUtils;
import com.zyd.framework.utils.constant.UserSession;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * 协作表 服务实现类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Service
public class CooperationServiceImpl extends ServiceImpl<CooperationMapper, Cooperation> implements CooperationService {

    @Resource
    CooperationMapper cooperationMapper;

    @Autowired
    CooperationReplyServiceImpl cooperationReplyService;

    @Autowired
    RealNewsService realNewsService;

    @Autowired
    NoticeUtils noticeUtils;

    @Autowired
    MemberServiceImpl memberService;

    @Autowired
    CommonService commonService;

    @Resource
    MsgClient msgClient;

    @Override
    public Page<CooperationPageVO> search(CooperationPageDTO cooperationPageDTO) {
        return cooperationMapper.page(cooperationPageDTO,cooperationPageDTO.buildPage());
    }

    @Override
    public Boolean add(CooperationAddDTO cooperationAddDTO, boolean isMiniProgram) {
        String regex = "(^1(3[0-9]|5[0-3,5-9]|7[1-3,5-8]|8[0-9])\\d{8}$)|(^[A-Za-z0-9\\u4e00-\\u9fa5]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$)|(\\d{5,11})";
        if(!cooperationAddDTO.getLinkphone().matches("^\\S*$")){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.FORMAL_ERROR_CONTAINS_SPACES);
        }else if(!cooperationAddDTO.getLinkphone().matches(regex)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.FORMAL_ERROR);
        }
        String company = null;
        Cooperation cooperation = new Cooperation();
        //拿到协作的相关信息
        BeanUtil.copyProperties(cooperationAddDTO,cooperation);
        if (cooperationAddDTO.getMemberId() == null){
            //从session中拿到用户信息
            JSONObject member = StpUtil.getSession().getModel(UserSession.INFO, JSONObject.class) ;
            //获取用户的id，作为协作所属会员
            cooperation.setMemberId(StpUtil.getLoginIdAsInt());
            cooperation.setCreatedBy(StpUtil.getLoginIdAsString());
            company = member.getString("company");
        }else {
            cooperation.setMemberId(cooperationAddDTO.getMemberId());
            cooperation.setCreatedBy(cooperationAddDTO.getMemberId().toString());
            company = cooperationAddDTO.getCompany();
        }
        cooperation.setCreatedAt(LocalDateTime.now());
        if (isMiniProgram){
            cooperation.setAuditState(MemberConstants.CooperationAuditState.NOT_AUDIT.code);
        }else {
            cooperation.setAuditState(MemberConstants.CooperationAuditState.PENDING.code);
        }
        if (StringUtils.equals(cooperationAddDTO.getType(), "need") && StringUtils.isEmpty(cooperationAddDTO.getNeedType())){
            cooperation.setNeedType(MemberConstants.NeedType.SERVICECOOPERATE.code);
        }else if (StringUtils.equals(cooperationAddDTO.getType(), "resource")  && StringUtils.isEmpty(cooperationAddDTO.getResourceType())){
            cooperation.setResourceType(MemberConstants.ResourceType.PRODUCT.code);
        }
        boolean isSuccess = save(cooperation);
        if (isSuccess){
            TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
            triggerMsgRequest.setBusiness("notify");

            JSONObject qywxParam = new JSONObject();
            qywxParam.put("msgtype", "template_card");

            JSONObject templateCard = new JSONObject();
            templateCard.put("card_type", "text_notice");

            List<JSONObject> horizontalContentList = new ArrayList<>();
            JSONObject keyName1 = new JSONObject();
            keyName1.put("keyname", "客户");
            keyName1.put("value", company);
            horizontalContentList.add(keyName1);
            JSONObject keyName2 = new JSONObject();
            keyName2.put("keyname", "账号");
            keyName2.put("value", cooperation.getLinkphone());
            horizontalContentList.add(keyName2);
            JSONObject keyName3 = new JSONObject();
            keyName3.put("keyname", "提交时间");
            keyName3.put("value", DateUtil.format(cooperation.getCreatedAt(), "yyyy/MM/dd HH:mm:ss"));
            horizontalContentList.add(keyName3);


            List<JSONObject> jumpList = new ArrayList<>();
            JSONObject jumpList1 = new JSONObject();
            jumpList1.put("type", 1);
            jumpList1.put("title", "跳转惠采");
            jumpList1.put("url", "https://huicai.zydonline.com/admin/#/purchase-member/cooperation");
            jumpList.add(jumpList1);
            templateCard.put("jump_list", jumpList);

            JSONObject cardAction = new JSONObject();
            cardAction.put("type", 1);
            cardAction.put("url",  "https://huicai.zydonline.com/admin/#/purchase-member/cooperation");
            templateCard.put("card_action", cardAction);


            //保存成功发送企业微信通知
            if (cooperationAddDTO.getType().equals(MemberConstants.CooperationType.NEED.code)){
                noticeUtils.sendQywx("联营慧会员【"+ company +"】发布需求消息，请到协作管理进行查看");

                triggerMsgRequest.setScene("memberAddCooNeed");
                JSONObject mainTitle = new JSONObject();
                mainTitle.put("title", "会员新需求审核");
                mainTitle.put("desc", "需求审核");
                templateCard.put("main_title", mainTitle);

                JSONObject keyName4 = new JSONObject();
                keyName4.put("keyname", "备注");
                keyName4.put("value", "您有一个新会员发布需求申请，赶快去查看并审核吧。");
                horizontalContentList.add(keyName4);
                templateCard.put("horizontal_content_list", horizontalContentList);

            }
            if (cooperationAddDTO.getType().equals(MemberConstants.CooperationType.RESOURCE.code)){
                noticeUtils.sendQywx("联营慧会员【"+ company +"】发布资源消息，请到协作管理进行查看");

                triggerMsgRequest.setScene("memberAddCooResource");
                JSONObject mainTitle = new JSONObject();
                mainTitle.put("title", "会员新资源审核");
                mainTitle.put("desc", "资源审核");
                templateCard.put("main_title", mainTitle);

                JSONObject keyName4 = new JSONObject();
                keyName4.put("keyname", "备注");
                keyName4.put("value", "您有一个新会员发布资源申请，赶快去查看并审核吧。");
                horizontalContentList.add(keyName4);
                templateCard.put("horizontal_content_list", horizontalContentList);

            }
            qywxParam.put("template_card", templateCard);
            triggerMsgRequest.setQywxParam(qywxParam);
            msgClient.triggerMsg(triggerMsgRequest);
        }
        return isSuccess;
    }


    @Override
    public Page<MemberCooperationVO> inquire(MemberCooperationDTO memberCooperationDTO) {
        String memberId= (String) StpUtil.getLoginId();
        return cooperationMapper.list(memberCooperationDTO,memberId, memberCooperationDTO.buildPage());
    }

    @Override
    public CooperationInfoVO queryInfo(QueryIdDTO queryIdDTO) {
        CooperationInfoVO cooperationInfoVO = new CooperationInfoVO();
        //获取协作回复信息并写入
        cooperationInfoVO.setCooperationReplyList(cooperationReplyService.selectList(queryIdDTO.getId()));
        //获取协作信息并写入
        Cooperation cooperation = cooperationMapper.selectById(queryIdDTO.getId());
        cooperationInfoVO.setCooperation(cooperation);
        //通过协作信息获取公司名和会员头像
         Member member = memberService.getById(cooperation.getMemberId());
         BeanUtil.copyProperties(member,cooperationInfoVO);
        return cooperationInfoVO;
    }

    @Override
    public Boolean mallAdd(CooperationMallAddDTO cooperationMallAddDTO) {
        if (StringUtils.equals(cooperationMallAddDTO.getType(), MemberConstants.CooperationType.RESOURCE.code)){
            if (!StringUtils.equals(cooperationMallAddDTO.getResourceType(), MemberConstants.ResourceType.PRODUCT.code) &&
                 !StringUtils.equals(cooperationMallAddDTO.getResourceType(), MemberConstants.ResourceType.SERVICE.code)){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_RESOURCE_TYPE);
            }
        }
        if (StringUtils.equals(cooperationMallAddDTO.getType(), MemberConstants.CooperationType.NEED.code)){
            if (!StringUtils.equals(cooperationMallAddDTO.getNeedType(), MemberConstants.NeedType.SERVICECOOPERATE.code)){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_NEED_TYPE);
            }
            if (cooperationMallAddDTO.getExpireTime() == null){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_EXPIRE_TIME);
            }
            if (cooperationMallAddDTO.getExpireTime().isBefore(LocalDateTime.now())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_AFTER_NOW);
            }
        }
        CooperationAddDTO cooperationAddDTO = new CooperationAddDTO();
        BeanUtil.copyProperties(cooperationMallAddDTO, cooperationAddDTO);
        cooperationAddDTO.setLinkphone(commonService.getCustInfo().getString("linkphone"));
        cooperationAddDTO.setMemberId(Integer.parseInt(commonService.memberId()));
        cooperationAddDTO.setCompany(commonService.getCustInfo().getString("company"));
        return add(cooperationAddDTO, false);
    }

    @Override
    @Transactional
    public Boolean audit(CooperationAuditDTO cooperationAuditDTO) {
        Cooperation cooperation = this.getById(cooperationAuditDTO.getId());
        if (cooperation == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_COO);
        }
        LocalDateTime now = LocalDateTime.now();
        if (cooperation.getExpireTime() != null && cooperation.getExpireTime().isBefore(now)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.EXPIRE_NEED_SERVICE);
        }
        if (cooperation.getAuditState().intValue() == 1){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.HAS_AUDIT);
        }
        if (cooperationAuditDTO.getAuditState().intValue() != 1 && cooperationAuditDTO.getAuditState().intValue() != 2){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_AUDIT_STATE);
        }
        boolean result = false;
        //如果为已通过，才进行绑定协作id
        Integer realNewsId = null;
        if(cooperationAuditDTO.getAuditState().intValue() == MemberConstants.CooperationAuditState.PASS.code){
            RealNews realNews = new RealNews();
            realNews.setConsultTitle(cooperation.getTitle());
            StringBuilder stringBuilder = new StringBuilder();
            if (StringUtils.isNotEmpty(cooperation.getTeamUrl())){
                String[] urls = cooperation.getTeamUrl().split("@");
                for (String url : urls) {
                    stringBuilder.append("<p><img src=\"");
                    stringBuilder.append(url);
                    stringBuilder.append("\" data-type=\""+cooperation.getType()+"\" alt=\"\" /></p>");
                }
            }
            stringBuilder.append("<p>" + cooperation.getTeamInfo() + "</p>");
            realNews.setConsultInfo(stringBuilder.toString());
            if (StringUtils.equals(cooperation.getType(), MemberConstants.CooperationType.RESOURCE.code)){
                realNews.setConsultType("慧资源");
                realNews.setIsOpenInterested(1);
                realNews.setResourceType(cooperation.getResourceType());
            }else if (StringUtils.equals(cooperation.getType(), MemberConstants.CooperationType.NEED.code)){
                realNews.setConsultType("慧需求");
                realNews.setIsOpenInterested(0);
            }
            realNews.setPublisher(memberService.getById(cooperation.getMemberId()).getCompany());
            realNews.setPage("firstPage");
            realNews.setIsShow(1);
            realNews.setCreatedAt(now);
            realNews.setCreatedBy(cooperationAuditDTO.getCreatedBy());
            result = realNewsService.save(realNews);
            if (!result){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_AUDIT_COO);
            }
            realNewsId = realNews.getId();
        }
        cooperation.setUpdatedAt(now);
        cooperation.setAuditState(cooperationAuditDTO.getAuditState());
        cooperation.setRejectReason(cooperationAuditDTO.getRejectReason());
        cooperation.setRealNewsId(realNewsId);
        result = this.updateById(cooperation);
        if (!result){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_AUDIT_COO);
        }
        return result;
    }

}
