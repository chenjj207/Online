package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


@Data
public class MemberSupplierOpenDTO extends BaseEntity {
    @NotNull(message = "会员id不能为空")
    @Schema(description = "会员id")
    private Integer id;

    @Schema(description = "是否发送短信通知，默认发送")
    private boolean isSend = true;
}
