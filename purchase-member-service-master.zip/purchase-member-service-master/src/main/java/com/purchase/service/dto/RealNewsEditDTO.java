package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/2/3  15:54
 */
@Data
public class RealNewsEditDTO extends BaseEntity {

    @NotNull(message = "id必填")
    private Integer id;

    @Schema(description = "主图")
    private String firstPic;

    @Schema(description = "资讯标题")
    private String consultTitle;

    @Schema(description = "资讯内容")
    private String consultInfo;

    @Schema(description = "资讯发布者")
    private String publisher;

    @Schema(description = "是否显示(0为发布，1为未发布)")
    private Integer isShow;

    @Schema(description = "是否开启感兴趣(0为未开启，1为开启)")
    private Integer isOpenInterested;

    @Schema(description = "发布页面")
    private String page;

    @Schema(description = "资讯类型")
    private String consultType;

}
