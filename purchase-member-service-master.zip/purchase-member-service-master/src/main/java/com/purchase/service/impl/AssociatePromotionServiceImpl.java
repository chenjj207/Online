package com.purchase.service.impl;

import com.purchase.entity.AssociatePromotion;
import com.purchase.mapper.AssociatePromotionMapper;
import com.purchase.service.AssociatePromotionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 项目推广专员配置表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-15
 */
@Service
public class AssociatePromotionServiceImpl extends ServiceImpl<AssociatePromotionMapper, AssociatePromotion> implements AssociatePromotionService {

    @Resource
    AssociatePromotionMapper associatePromotionMapper;

    @Override
    public List<String> queryAll() {
        return associatePromotionMapper.selectPromotionGroup();
    }
}
