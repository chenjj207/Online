package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;


@Data
public class MemberCheckDTO {
    @NotEmpty(message = "微信js码不能为空")
    @Schema(description = "微信登录时获取的code")
    private String jsCode;
}
