package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class MemberStateVO {

    @Schema(description = "状态名")
    private String state;

    @Schema(description = "相应状态会员数量")
    private Integer memberStateNum;

}
