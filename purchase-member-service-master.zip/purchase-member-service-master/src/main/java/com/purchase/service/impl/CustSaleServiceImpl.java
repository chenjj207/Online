package com.purchase.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.Company;
import com.purchase.entity.CustomerSale;
import com.purchase.mapper.CompanyMapper;
import com.purchase.mapper.CustSaleMapper;
import com.purchase.service.CustSaleService;
import com.purchase.service.dto.CustSaleQueryDTO;
import com.zyd.framework.utils.exception.BusinessException;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;

/**
 * 客户销售金额 服务实现类
 */
@Service
public class CustSaleServiceImpl extends ServiceImpl<CustSaleMapper, CustomerSale> implements CustSaleService {

    @Resource
    CustSaleMapper custSaleMapper;
    @Resource
    CompanyMapper comMapper;


    @Override
    public CustomerSale getCustSaleData(CustSaleQueryDTO param) {
        String ifsContract = null;
        List<Company> comList = comMapper.selectList(
                new QueryWrapper<Company>()
                        .eq("short_name", param.getShortName())
        );
        if (comList != null && comList.size()>0 && comList.get(0) != null && comList.get(0).getIfsContract()!= null){
            ifsContract = comList.get(0).getIfsContract();
        }else{
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_MEMBER);
        }

        List<CustomerSale> re = custSaleMapper.selectList(
                new QueryWrapper<CustomerSale>()
                        .eq("ybm", ifsContract)
                        .eq("nf", param.getNf())
                        .eq("khmc", param.getKhmc()));

        return null==re||0==re.size()?null:re.get(0);
    }
}
