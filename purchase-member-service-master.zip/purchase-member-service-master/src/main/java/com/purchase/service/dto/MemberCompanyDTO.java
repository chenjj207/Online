package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

/**
 * @author jidonglin
 * @Description: 公司名称查询
 * @date 2023/2/13  11:38
 */
@Data
public class MemberCompanyDTO {

    @NotEmpty(message = "请输入关键字")
    @Schema(description = "关键字")
    @Size(min = 4, message = "请输入4个以上关键字进行查询")
    private String word;

    @Schema(description = "高亮颜色,十六进制颜色码")
    private String highlightColor = "#3e217e";
}
