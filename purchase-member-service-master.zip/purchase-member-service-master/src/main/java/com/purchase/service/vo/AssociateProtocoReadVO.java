package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/4/10  10:46
 */
@Data
public class AssociateProtocoReadVO {
    @Schema(description = "数量")
    private int count;
    @Schema(description = "是否存在未读")
    private boolean isExistNotRead;
}
