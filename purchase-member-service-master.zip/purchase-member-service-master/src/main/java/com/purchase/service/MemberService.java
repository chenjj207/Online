package com.purchase.service;

import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.MemberNumDTO;
import com.purchase.entity.Member;
import com.purchase.service.dto.*;
import com.purchase.service.vo.*;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
public interface MemberService extends IService<Member> {

    public Boolean add(@RequestBody MemberRegisterDTO memberRegisterDTO);

    public Page<Member> selectList(@RequestBody MemberWxPageDTO memberWxPageDTO);

    public Boolean updateState(@RequestBody MemberEditStateDTO memberEditStateDTO);

    public Boolean sendSmsCode(SendSmsCodeDTO dto);

    List<MemberStateVO> countNum(@RequestBody MemberNumDTO memberNumDTO);

    public String login(MemberLoginDTO memberLoginDTO, HttpServletRequest request);

    public String wxlogin(MemberWXLoginDTO memberLoginDTO, HttpServletRequest request);

    public void loginOut();

    Boolean regist(MemberRegisterDTO memberRegisterDTO);

    Member check(MemberCheckDTO memberCheckDTO);

    Member loginCheck(MemberLoginCheckDTO memberLoginCheckDTO);

    List<CompanyInfoSearchVO> queryCompany(MemberCompanyDTO memberCompanyDTO);

    Boolean checkCompany(MemberCompanyDTO memberCompanyDTO);

    String getPhone(String code);

    MemberCountVO getCount();

    Member queryInfoByToken();

    Page<MemberPageVo> selectPage(MemberPageDTO memberPageDTO);

    Member queryWxInfo(QueryIdDTO queryIdDTO);

    Boolean editIcon(MemberIconDTO memberIconDTO);

    Boolean edit(MemberEditDTO memberEditDTO);

    Boolean adminEdit(MemberAdminEditDTO memberAdminEditDTO);

    List<String> queryDistinctCompanyName();

    Map<String, Integer> countIndustry();

    Boolean open(MemberSupplierOpenDTO memberSupplierOpenDTO);

    Map<String,List<String>> inferCompanyName();

    Map<String, Integer> countCompetence();

    IsIssueVO referMemberCooperation();

    List<StatisticsMemberVO> statistics(StatisticsMemberDTO statisticsMemberDTO);

    Boolean invite(MemberInviteDTO memberInviteDTO);

    Page<MemberPageVo> selectMallPage(MemberPageDTO memberPageDTO);

    Member queryInfo(QueryIdDTO queryIdDTO);
}
