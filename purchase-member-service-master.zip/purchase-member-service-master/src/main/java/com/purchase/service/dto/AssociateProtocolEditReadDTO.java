package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
* <p>
* 联营协议表
* </p>
* @author jidonglin
* @since 2024-04-10
*/
@Data
@Schema(title = "联营协议 已读")
public class AssociateProtocolEditReadDTO {

    @Schema(description = "申请id")
    @NotNull(message = "申请id 错误")
    private Integer applyId;


}
