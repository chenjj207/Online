package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author jidonglin
 * @Description: 合作详情与申请计划
 * @date 2024/4/15  14:12
 */
@Data
public class BrandAuthApplyVO {
    @Schema(description = "id")
    private Integer id;

    @Schema(description = "年 如：2024")
    private Integer year;

    @Schema(description = "授权期限 1、第一季度 2、第二季度 3、第三季度 4、第四季度 为空表示一整年")
    private String authTime;

    @Schema(description = "计划采购额")
    private BigDecimal planPurchase;

    @Schema(description = "实际采购额")
    private BigDecimal realityPurchase;

    @Schema(description = "完成情况 %")
    private BigDecimal finishStatus;

    @Schema(description = "所有品牌合作总采购额")
    private BigDecimal allBrandRealityPurchase;

    @Schema(description = "状态：1、待审批  2、同意授权  3、拒绝授权  4、已存档 5、已发放  6、拒绝发放")
    private String state;

    @Schema(description = "授权拒绝原因")
    private String rejectReason;

    @Schema(description = "发放拒绝原因")
    private String grantReason;

    @Schema(description = "协议地址")
    private String protocolUrl;
}
