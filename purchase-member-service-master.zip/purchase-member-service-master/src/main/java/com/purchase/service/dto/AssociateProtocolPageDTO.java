package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Pattern;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Data
public class AssociateProtocolPageDTO extends PageDTO {

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    @Schema(description = "开始时间")
    private LocalDateTime beginTime;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    @Schema(description = "结束时间")
    private LocalDateTime endTime;

    @Schema(description = "状态")
    @Pattern(regexp = "0|1|2|3|4",message = "状态参数错误")
    private String state;

    @Schema(description = "协议类型")
    private String type;

    @Schema(description = "项目推广专员")
    private String promotionPerson;

    @Schema(description = "客户类型")
    private String customerType;

    @Schema(description = "子公司名称")
    private List<String> subCompany;

    @Schema(description = "模糊查询 协议编号/客户名称/创建人")
    private String key;

    @Schema(description = "申请年份")
    private Integer applyNf;

    @Schema(description = "是否有授权 1：是 0：否")
    private String auth;
}
