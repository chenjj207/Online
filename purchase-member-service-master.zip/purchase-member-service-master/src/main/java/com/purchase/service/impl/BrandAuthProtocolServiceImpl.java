package com.purchase.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.BrandAuthApply;
import com.purchase.entity.BrandAuthProtocol;
import com.purchase.mapper.BrandAuthApplyMapper;
import com.purchase.mapper.BrandAuthProtocolMapper;
import com.purchase.service.BrandAuthProtocolService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.CommonService;
import com.purchase.service.dto.BrandAuthProtocolAddDTO;
import com.purchase.service.dto.BrandAuthProtocolPageDTO;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 品牌授权协议存档 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-06-03
 */
@Service
public class BrandAuthProtocolServiceImpl extends ServiceImpl<BrandAuthProtocolMapper, BrandAuthProtocol> implements BrandAuthProtocolService {

    @Resource
    BrandAuthProtocolMapper brandAuthProtocolMapper;
    @Resource
    BrandAuthApplyMapper brandAuthApplyMapper;
    @Autowired
    CommonService commonService;

    @Override
    public Integer add(BrandAuthProtocolAddDTO brandAuthProtocolAddDTO) {
        BrandAuthApply brandAuthApply = brandAuthApplyMapper.selectById(brandAuthProtocolAddDTO.getBrandAuthId());
        if (brandAuthApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_BRAND_AUTH_APPLY);
        }
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String uploadPerson = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(uploadPerson)){
            uploadPerson = uploadPerson.substring(1, uploadPerson.length() - 1);
        }
        LocalDateTime now = LocalDateTime.now();
        Integer returnId = null;

        QueryWrapper<BrandAuthApply> associateApplyQueryWrapper3 = new QueryWrapper<>();
        associateApplyQueryWrapper3.eq("company", brandAuthApply.getCompany())
                .eq("year", brandAuthApply.getYear());
        List<BrandAuthApply> brandAuthApplyList = brandAuthApplyMapper.selectList(associateApplyQueryWrapper3);
        if (CollectionUtils.isNotEmpty(brandAuthApplyList)){
            for (BrandAuthApply b : brandAuthApplyList) {
                BrandAuthProtocol brandAuthProtocol = new BrandAuthProtocol();
                BeanUtil.copyProperties(brandAuthProtocolAddDTO, brandAuthProtocol);
                brandAuthProtocol.setBrandAuthId(b.getId());
                brandAuthProtocol.setUploadPerson(uploadPerson);
                brandAuthProtocol.setCreatedAt(now);
                brandAuthProtocol.setCreatedBy(code);
                boolean result = this.save(brandAuthProtocol);
                if (b.getId() == brandAuthApply.getId()){
                    returnId = brandAuthProtocol.getId();
                }
                if (result){
                    b.setArchive("1");
                    b.setUpdatedAt(now);
                    b.setUpdatedBy(code);
                    brandAuthApplyMapper.updateById(b);
                }
            }
        }

        return returnId;
    }

    @Override
    public Page<BrandAuthProtocol> queryList(BrandAuthProtocolPageDTO brandAuthProtocolPageDTO) {
        return brandAuthProtocolMapper.page(brandAuthProtocolPageDTO, brandAuthProtocolPageDTO.buildPage());
    }
}
