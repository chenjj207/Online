package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.BrandAuthApply;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.BrandAuthApplyDetailVO;
import com.purchase.service.vo.BrandAuthRenewalVO;
import com.purchase.service.vo.BrandAuthTimeVO;
import com.purchase.service.vo.CommonCountVO;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 品牌授权申请 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-04-11
 */
public interface BrandAuthApplyService extends IService<BrandAuthApply> {

    public Integer add(BrandAuthApplyAddDTO brandAuthApplyAddDTO);

    public Integer edit(BrandAuthApplyEditDTO brandAuthApplyEditDTO);

    public Integer editAdmin(BrandAuthApplyEditAdminDTO brandAuthApplyEditAdminDTO);

    public BrandAuthRenewalVO renewal(QueryIdDTO queryIdDTO);

    public BrandAuthApply queryById(QueryIdDTO queryIdDTO);

    public List<BrandAuthApply> queryByOpenId(OpenIdDTO openIdDTO);

    public Page<BrandAuthApply> queryList(BrandAuthApplyPageDTO brandAuthApplyPageDTO);

    public List<CommonCountVO> countNum(BrandAuthApplyCountDTO brandAuthApplyCountDTO);

    public void export( BrandAuthApplyCountDTO brandAuthApplyCountDTO, HttpServletResponse response);

    public BrandAuthApplyDetailVO detail(QueryIdDTO queryIdDTO);

    public Boolean approve(BrandAuthApplyApproveDTO brandAuthApplyApproveDTO);

    public Boolean grant(BrandAuthApplyGrantFileDTO brandAuthApplyGrantFileDTO);

    public List<BrandAuthTimeVO> authTime();

}
