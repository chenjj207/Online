package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/10/16  13:56
 */
@Data
public class RealNewsNeedDTO extends PageDTO {

    @Schema(description = "tab类型：1、未参与 2、已参与 3、已过期 4、我发布的")
    @NotNull(message = "tab条件不能为空")
    private String tabType;


    @Schema(description = "会员id")
    private Integer memberId ;
}
