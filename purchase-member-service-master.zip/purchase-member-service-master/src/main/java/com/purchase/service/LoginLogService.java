package com.purchase.service;

import com.purchase.entity.LoginLog;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.entity.Member;

/**
 * <p>
 * 登录日志表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-06-27
 */
public interface LoginLogService extends IService<LoginLog> {

    void saveLoginLog(Member memberResultOld, String ip);
}
