package com.purchase.service;

import com.purchase.entity.AssociateApplySnapshot;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 联营申请表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-15
 */
public interface AssociateApplySnapshotService extends IService<AssociateApplySnapshot> {

}
