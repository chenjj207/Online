package com.purchase.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.URLUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.OSSObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dtflys.forest.Forest;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.client.feign.MsgClient;
import com.purchase.config.OssConf;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.AssociateApply;
import com.purchase.entity.AssociateAuth;
import com.purchase.entity.AssociatePromotion;
import com.purchase.entity.AssociateProtocol;
import com.purchase.mapper.AssociateApplyMapper;
import com.purchase.mapper.AssociateAuthMapper;
import com.purchase.mapper.AssociatePromotionMapper;
import com.purchase.mapper.AssociateProtocolMapper;
import com.purchase.service.AssociateAuthService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.CommonService;
import com.purchase.service.dto.AssociateAuthAddDTO;
import com.purchase.service.dto.AssociateAuthPageDTO;
import com.purchase.utils.TokenUtils;
import com.zyd.framework.utils.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 联营授权 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-22
 */
@Service
@Slf4j
public class AssociateAuthServiceImpl extends ServiceImpl<AssociateAuthMapper, AssociateAuth> implements AssociateAuthService {

    @Resource
    AssociateAuthMapper associateAuthMapper;
    @Autowired
    CommonService commonService;
    @Resource
    AssociateProtocolMapper associateProtocolMapper;
    @Resource
    AssociateApplyMapper associateApplyMapper;
    @Resource
    AssociatePromotionMapper associatePromotionMapper;
    @Value("${odsUrl}")
    String odsUrl;
    @Resource
    private MsgClient msgClient;

    @Autowired
    TokenUtils tokenUtils;
    @Autowired
    OssConf ossConfig;

    @Override
    public Integer add(AssociateAuthAddDTO associateAuthAddDTO) {
        AssociateProtocol associateProtocol = associateProtocolMapper.selectById(associateAuthAddDTO.getProtocolId());
        if (associateProtocol == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_ASSOCIATE_PROTOCOL);
        }
        AssociateApply associateApply = associateApplyMapper.selectById(associateProtocol.getApplyId());
        if (associateApply == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_ASSOCIATE);
        }

        int count = associateAuthMapper.selectCountName(associateAuthAddDTO.getProtocolId());
        String name = "授权" + (count + 1);
        Map<Object, Object> userInfo = commonService.getUserInfo();
        String code = (String) userInfo.get("username");
        if (StringUtils.isNotEmpty(code)){
            code = code.substring(1, code.length() - 1);
        }
        String uploadPerson = (String) userInfo.get("name");
        if (StringUtils.isNotEmpty(uploadPerson)){
            uploadPerson = uploadPerson.substring(1, uploadPerson.length() - 1);
        }
        AssociateAuth associateAuth = new AssociateAuth();
        associateAuth.setName(name);
        associateAuth.setProtocolId(associateAuthAddDTO.getProtocolId());
        associateAuth.setUrl(associateAuthAddDTO.getUrl());
        associateAuth.setUploadPerson(uploadPerson);
        associateAuth.setFileName(associateAuthAddDTO.getFileName());
        associateAuth.setCreatedBy(code);
        associateAuth.setCreatedAt(LocalDateTime.now());
        boolean result = this.save(associateAuth);
        if (result){
            associateProtocol.setAuth("1");
            associateProtocol.setUpdatedAt(LocalDateTime.now());
            associateProtocol.setUpdatedBy(uploadPerson);
            associateProtocolMapper.updateById(associateProtocol);

            QueryWrapper<AssociatePromotion> associatePromotionQueryWrapper = new QueryWrapper<>();
            associatePromotionQueryWrapper.eq("company_name", associateApply.getSubCompany());
            List<AssociatePromotion> associatePromotions = associatePromotionMapper.selectList(associatePromotionQueryWrapper);
            if (CollectionUtil.isEmpty(associatePromotions)){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_PROMOTION);
            }

            TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
            triggerMsgRequest.setBusiness("associate");
            triggerMsgRequest.setScene("associateProtocolAuth");
            JSONObject qywxParam = new JSONObject();
            qywxParam.put("msgtype", "template_card");
            qywxParam.put("noticeUser", associatePromotions.get(0).getCode());

            JSONObject templateCard = new JSONObject();
            templateCard.put("card_type", "text_notice");

            JSONObject mainTitle = new JSONObject();
            mainTitle.put("title", "联营授权已发放");
            mainTitle.put("desc", "");
            templateCard.put("main_title", mainTitle);

            List<JSONObject> horizontalContentList = new ArrayList<>();
            JSONObject keyName1 = new JSONObject();
            keyName1.put("keyname", "客户");
            keyName1.put("value", associateApply.getCompany());
            horizontalContentList.add(keyName1);
            JSONObject keyName2 = new JSONObject();
            keyName2.put("keyname", "联系人");
            keyName2.put("value", associateApply.getLinkman());
            horizontalContentList.add(keyName2);
            JSONObject keyName3 = new JSONObject();
            keyName3.put("keyname", "提交时间");
            keyName3.put("value", DateUtil.format(LocalDateTime.now(), "yyyy/MM/dd HH:mm:ss"));
            horizontalContentList.add(keyName3);
            JSONObject keyName4 = new JSONObject();
            keyName4.put("keyname", "备注");
            keyName4.put("value", "客户的联营授权已发放，点击跳转并查看。");
            horizontalContentList.add(keyName4);
            templateCard.put("horizontal_content_list", horizontalContentList);

            List<JSONObject> jumpList = new ArrayList<>();
            JSONObject jumpList1 = new JSONObject();
            jumpList1.put("type", 1);
            jumpList1.put("title", "跳转惠采");
            jumpList1.put("url", odsUrl + "/#/purchase-sign/protocol?key=" + URLUtil.encode(associateApply.getCompany()));
            jumpList.add(jumpList1);
            templateCard.put("jump_list", jumpList);

            JSONObject cardAction = new JSONObject();
            cardAction.put("type", 1);
            cardAction.put("url",  odsUrl + "/#/purchase-sign/protocol?key=" + URLUtil.encode(associateApply.getCompany()));
            templateCard.put("card_action", cardAction);
            qywxParam.put("template_card", templateCard);
            triggerMsgRequest.setQywxParam(qywxParam);
            msgClient.triggerMsg(triggerMsgRequest);

            String token = tokenUtils.getQyWXTokenBy1();
            //发送文件1
            OSS ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
            OSSObject object = ossClient.getObject(ossConfig.getBucketName(), associateAuthAddDTO.getUrl().replace(ossConfig.getOssUrl(), ""));
            InputStream inputStream = object.getObjectContent();

            Forest.post("https://qyapi.weixin.qq.com/cgi-bin/media/upload").addQuery("access_token", token).addQuery("type", "file")
                    // 指定请求体为Multipart格式
                    .contentTypeMultipartFormData()
                    // 添加InputStream对象
                    .addFile("file", inputStream, associateAuth.getFileName())
                    .onSuccess(((data, req, res) -> {
                        JSONObject jsonObject = JSON.parseObject(data.toString());
                        if(!jsonObject.containsKey("media_id")){
                            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.FORWARDING_ORDER_GENERATION_FAILED);
                        }

                        TriggerMsgRequest triggerMsgRequest1 = new TriggerMsgRequest();
                        triggerMsgRequest1.setBusiness("brandAuth");
                        triggerMsgRequest1.setScene("brandAuthProtocolPass");
                        JSONObject qywxParam1 = new JSONObject();
                        qywxParam1.put("msgtype", "file");
                        qywxParam1.put("noticeUser", associatePromotions.get(0).getCode());

                        qywxParam1.put("mediaId", jsonObject.getString("media_id"));
                        triggerMsgRequest1.setQywxParam(qywxParam1);
                        msgClient.triggerMsg(triggerMsgRequest1);
                    }))
                    // onError回调函数: 请求失败时被调用
                    .onError(((ex, req, res) -> {
                        log.info("企业微信上传临时素材异常" + ex.getMessage());
                        throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_SMS_TYPE);
                    }))
                    // 执行请求，请求成功则执行onSuccess, 失败则执行onError
                    .execute();

            return associateAuth.getId();
        }
        return null;
    }

    @Override
    public Page<AssociateAuth> queryList(AssociateAuthPageDTO associateAuthPageDTO) {
        return associateAuthMapper.page(associateAuthPageDTO, associateAuthPageDTO.buildPage());
    }
}
