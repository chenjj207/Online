package com.purchase.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.entity.RealNewsType;
import com.purchase.service.dto.QueryTypeDTO;
import com.purchase.service.dto.RealNewsTypeAddDTO;

import java.util.List;

/**
 * <p>
 * 资讯分类表 服务类
 * </p>
 *
 * @author
 * @since 2023-02-10
 */
public interface RealNewsTypeService extends IService<RealNewsType> {

    Boolean add(RealNewsTypeAddDTO realNewsTypeAddDTO);

    List<RealNewsType> queryType(QueryTypeDTO queryTypeDTO);
}
