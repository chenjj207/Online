package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.common.MemberConstants;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.Member;
import com.purchase.entity.MemberMessage;
import com.purchase.entity.Message;
import com.purchase.mapper.MemberMessageMapper;
import com.purchase.mapper.MessageMapper;
import com.purchase.service.CommonService;
import com.purchase.service.MessageService;
import com.purchase.service.dto.MessagePageDTO;
import com.purchase.service.dto.MessageQueryDTO;
import com.purchase.service.vo.MessagePageVO;
import com.purchase.service.vo.MessageWxPageVO;
import com.zyd.framework.boot.config.base.PageDTO;
import com.zyd.framework.utils.constant.UserSession;
import com.zyd.framework.utils.exception.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;

/**
 * <p>
 * 消息表 服务实现类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Service
public class MessageServiceImpl extends ServiceImpl<MessageMapper, Message> implements MessageService {

    @Resource
    MemberMessageMapper memberMessageMapper;
    @Resource
    MessageMapper messageMapper;
    @Autowired
    CommonService commonService;

    @Override
    public Message getIdInfo(MessageQueryDTO messageQueryDTO) {
        Message message  = messageMapper.info(messageQueryDTO);
        if(!BeanUtil.isNotEmpty(message)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_MESSAGE);
        }
        //用于验证小程序是否登录
        if(ObjectUtil.isNotNull(StpUtil.getLoginIdDefaultNull())){
            //小程序登录则设置相应公告为已读
            UpdateWrapper<MemberMessage> updateWrapper = new UpdateWrapper<>();
            updateWrapper.set("is_read",MemberConstants.MemberMessageRead.READ.code)
                    .set("updated_at", LocalDateTime.now())
                    .eq("member_id",StpUtil.getLoginId())
                    .eq("notice_id",messageQueryDTO.getNoticeId());
            memberMessageMapper.update(null,updateWrapper);
            return getById(messageQueryDTO.getNoticeId());
        }
        //返回对应公告详情
        return message ;
    }

    @Override
    public Page<MessagePageVO> pageList(MessagePageDTO messagePageDTO) {
        return messageMapper.page(messagePageDTO,messagePageDTO.buildPage());
    }

    @Override
    public Page<MessageWxPageVO> wxPageList(PageDTO pageDTO) {
        JSONObject json = StpUtil.getSession().getModel(UserSession.INFO,JSONObject.class);
        String id = json.getString("id");
        return messageMapper.wxPage(id,pageDTO.buildPage());
    }

    @Override
    public Page<MessagePageVO> mallPage(MessagePageDTO messagePageDTO) {
        if (messagePageDTO.getSendMemberId() == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_NULL_MEMBER_ID);
        }
        JSONObject jsonObject = commonService.getCustInfo();
        Integer currentMemberId = jsonObject.getInteger("memberId");

        messagePageDTO.setMemberId(currentMemberId);
        Page<MessagePageVO> messagePageVOPage = messageMapper.mallPage(messagePageDTO, messagePageDTO.buildPage());
        //更新已读
        UpdateWrapper<MemberMessage> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("send_member_id", messagePageDTO.getSendMemberId());
        updateWrapper.eq("member_id", currentMemberId);
        updateWrapper.set("is_read", MemberConstants.MemberMessageRead.READ.code);
        updateWrapper.set("updated_at", LocalDateTime.now());
        memberMessageMapper.update(null, updateWrapper);
        return messagePageVOPage;
    }
}
