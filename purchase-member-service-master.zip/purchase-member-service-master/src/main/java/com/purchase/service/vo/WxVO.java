package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/4/11  8:56
 */
@Data
@Schema(title = "微信响应对象")
public class WxVO {
    @Schema(description = "openid")
    private String openid;
    @Schema(description = "unionid")
    private String unionid;
}
