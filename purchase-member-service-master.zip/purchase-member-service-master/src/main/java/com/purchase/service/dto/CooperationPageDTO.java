package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;
@Data
public class CooperationPageDTO extends PageDTO {

    @Schema(description = "协作类型(resource=资源，need=需求)")
    private String type;

    @Schema(description = "状态（0=已回复，1=未回复，默认为未回复）")
    private Integer status;

    @Schema(description = "审核状态 0: 待审核 1：已通过 2：已拒绝")
    private Integer auditState;

    @Schema(description = "关键字")
    private String key;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "开始时间")
    private Date beginTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "结束时间")
    private Date endTime;
}
