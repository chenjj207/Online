package com.purchase.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.entity.CustomerSale;
import com.purchase.service.dto.CustSaleQueryDTO;

/**
 * 客户销售金额 服务类
 */
public interface CustSaleService extends IService<CustomerSale> {

    CustomerSale getCustSaleData(CustSaleQueryDTO param);

}
