package com.purchase.service.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Data
public class InterestListVO {

    @Schema(description = "会员id")
    private String id;

    @Schema(description = "联系人")
    private String linkman;

    @Schema(description = "会员公司")
    private String company;

    @Schema(description = "联系方式")
    private String linkphone;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(description = "心跳时间")
    private LocalDateTime createTime;
}
