package com.purchase.service.vo;

import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class MemberCooperationVO extends BaseEntity {


    @Schema(description = "联系方式")
    private String linkphone;

    @Schema(description = "图片路径")
    private String teamUrl;

    @Schema(description = "协作类型(resource=资源，need=需求)")
    private String type;

    @Schema(description = "协作描述")
    private String teamInfo;


    @Schema(description = "未回复信息数(0：表示该协作无回复信息或所有回复信息都已查看，其他数字：表示该协作的未查看的回复信息数)")
    private Integer replyNum;

}
