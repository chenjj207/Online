package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/3/1  9:56
 */
@Data
public class RealNewsBrowseRecordPageDTO extends PageDTO {

    @Schema(description = "资讯id")
    private Integer realNewsId;
}
