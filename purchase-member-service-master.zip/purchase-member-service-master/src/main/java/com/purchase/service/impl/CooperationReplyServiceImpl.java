package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.client.feign.MsgClient;
import com.purchase.common.MemberConstants;
import com.purchase.config.AliSmsProperties;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.Cooperation;
import com.purchase.entity.CooperationReply;
import com.purchase.entity.Member;
import com.purchase.entity.RealNews;
import com.purchase.mapper.CooperationMapper;
import com.purchase.mapper.CooperationReplyMapper;
import com.purchase.mapper.RealNewsMapper;
import com.purchase.service.CommonService;
import com.purchase.service.CooperationReplyService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CooperationInfoVO;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 协作回复表 服务实现类
 * </p>
 *
 * @author
 * @since 2023-02-03
 */
@Service
public class CooperationReplyServiceImpl extends ServiceImpl<CooperationReplyMapper, CooperationReply> implements CooperationReplyService {

    @Resource
    CooperationReplyMapper cooperationReplyMapper;
    @Resource
    CooperationMapper cooperationMapper;
    @Resource
    RealNewsMapper realNewsMapper;

    @Autowired
    MemberServiceImpl memberService;
    @Autowired
    CommonService commonService;

    @Resource
    MsgClient msgClient;
    @Resource
    AliSmsProperties aliSmsProperties;

    @Override
    public Boolean add(CooperationReplyAddDTO cooperationReplyAddDTO) {
        Cooperation cooperation = cooperationMapper.selectById(cooperationReplyAddDTO.getTeamId());
        //校验是否存在相应协作
        if (ObjectUtil.isAllEmpty(cooperation)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_COO);
        }
        CooperationReply cooperationReply = new CooperationReply();
        BeanUtil.copyProperties(cooperationReplyAddDTO,cooperationReply);
        cooperationReply.setCreatedAt(LocalDateTime.now());
        //判断协作的回复状态，未回复则修改回复状态
        if (cooperation.getStatus().equals(MemberConstants.CooperationStatus.UN_REVERT.code)){
            UpdateWrapper<Cooperation> wrapper = new UpdateWrapper<>();
            wrapper
                    .eq("id",cooperation.getId())
                    .set("status",MemberConstants.CooperationStatus.REVERT.code)
                    .set("updated_at",LocalDateTime.now());
            cooperationMapper.update(null,wrapper);
        }
        return save(cooperationReply);
    }

    @Override
    public List<CooperationReply> selectList(Integer id) {
        Cooperation cooperation = cooperationMapper.selectById(id);
        //判断此协作是否存在
        if (ObjectUtil.isAllEmpty(cooperation)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_COO);
        }
        //根据id获取相应协作的所有回复信息并按时间正序排序
        QueryWrapper<CooperationReply> wrapper = new QueryWrapper<>();
        wrapper
                .eq("team_id",id).isNull("member_id")
                .orderByAsc("created_at");
        List<CooperationReply> list = cooperationReplyMapper.selectList(wrapper);
        return list;
    }

    @Override
    public CooperationInfoVO queryInfo(QueryIdDTO queryIdDTO) {
        CooperationInfoVO cooperationInfoVO = new CooperationInfoVO();
        //获取协作信息并写入
        QueryWrapper<Cooperation> wrapper = new QueryWrapper<>();
        wrapper.eq("id",queryIdDTO.getId())
                .eq("member_id", StpUtil.getLoginId());
        Cooperation cooperation = cooperationMapper.selectOne(wrapper);
        //判断会员协作是否存在
       if (ObjectUtil.isAllEmpty(cooperation)){
           throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_COO);
       }
        cooperationInfoVO.setCooperation(cooperation);
        List<CooperationReply> list = selectList(queryIdDTO.getId());
        //获取协作回复信息并写入
        cooperationInfoVO.setCooperationReplyList(list);
        //如果协作有回复信息则将未读信息状态改为已读
        if (CollUtil.isNotEmpty(list)){
            UpdateWrapper<CooperationReply> updateWrapper = new UpdateWrapper<>();
            updateWrapper
                    .eq("team_id",queryIdDTO.getId())
                    .eq("is_read", MemberConstants.CooperationReplyRead.UN_READ.code)
                    .set("is_read",MemberConstants.CooperationReplyRead.READ.code)
                    .set("updated_at",LocalDateTime.now());
            update(updateWrapper);
        }
        //通过协作信息获取公司名和会员头像
        Member member = memberService.getById(cooperation.getMemberId());
        BeanUtil.copyProperties(member,cooperationInfoVO);
        return cooperationInfoVO;
    }

    /**
     * 会员回复协作
     * @param cooperationReplyMallAddDTO
     * @return
     */
    @Override
    @Transactional
    public Boolean mallAdd(CooperationReplyMallAddDTO cooperationReplyMallAddDTO) {
        RealNews realNews = realNewsMapper.selectById(cooperationReplyMallAddDTO.getRealNewsId());
        if (realNews == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_REAL_NEWS);
        }
        QueryWrapper<Cooperation> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("real_news_id", realNews.getId());
        Cooperation cooperation = cooperationMapper.selectOne(queryWrapper);
        Integer cooperationId = null;
        if (cooperation != null){
            if (!StringUtils.equals(cooperation.getType(), MemberConstants.CooperationType.NEED.code)
                    || !StringUtils.equals(cooperation.getNeedType(), MemberConstants.NeedType.SERVICECOOPERATE.code)){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_COO_TO_REPLY);
            }
            if (cooperation.getExpireTime() != null && cooperation.getExpireTime().isBefore(LocalDateTime.now())){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.EXPIRE_NEED_SERVICE);
            }
            if (cooperation.getAuditState().intValue() != 1){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_AUDIT_STATUS);
            }

            //判断协作的回复状态，未回复则修改回复状态
            if (cooperation.getStatus().equals(MemberConstants.CooperationStatus.UN_REVERT.code)){
                UpdateWrapper<Cooperation> wrapper = new UpdateWrapper<>();
                wrapper
                        .eq("id",cooperation.getId())
                        .set("status",MemberConstants.CooperationStatus.REVERT.code)
                        .set("updated_at",LocalDateTime.now());
                cooperationMapper.update(null,wrapper);
            }
            cooperationId = cooperation.getId();
        }
        CooperationReply cooperationReply = new CooperationReply();
        cooperationReply.setTeamId(cooperationId);
        cooperationReply.setRealNewsId(realNews.getId());
        cooperationReply.setContent(cooperationReplyMallAddDTO.getContent());
        cooperationReply.setIsRead(MemberConstants.CooperationReplyRead.UN_READ.code);
        cooperationReply.setMemberId(Integer.parseInt(commonService.memberId()));
        cooperationReply.setCreatedBy(commonService.memberId());
        cooperationReply.setCreatedAt(LocalDateTime.now());

        boolean result = save(cooperationReply);
        if (cooperation != null){
            //单独发布的慧需求，没有经过审核，就不需要发送通知
            //响应需求通知 埋点
            Member member = memberService.getById(commonService.memberId());
            Member member1 = memberService.getById(cooperation.getMemberId());
            TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
            triggerMsgRequest.setBusiness("notify");
            triggerMsgRequest.setScene("memberReplyCoo");
            JSONObject smsParam = new JSONObject();
            smsParam.put("company", member.getCompany());
            smsParam.put("phone", member1.getLinkphone());
            triggerMsgRequest.setSmsParam(smsParam);

            JSONObject wxpfParam = new JSONObject();
            wxpfParam.put("company", member.getCompany());
            wxpfParam.put("content", cooperationReplyMallAddDTO.getContent());
            wxpfParam.put("time", DateUtil.format(LocalDateTime.now(), "yyyy/MM/dd HH:mm:ss"));
            wxpfParam.put("page", "pages/mine-message/index");
            triggerMsgRequest.setWxpfParam(wxpfParam);
            msgClient.triggerMsg(triggerMsgRequest);
        }
        return result;
    }

    /**
     * 1.发布该需求的客户可以查看到所有响应
     * 2.回复响应的人只能查看到自己的响应；
     * @param cooperationReplyPageDTO
     * @return
     */
    @Override
    public Page<CooperationReply> mallPage(CooperationReplyPageDTO cooperationReplyPageDTO) {
        RealNews realNews = realNewsMapper.selectById(cooperationReplyPageDTO.getRealNewsId());
        if (realNews == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_REAL_NEWS);
        }
        QueryWrapper<Cooperation> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("real_news_id", realNews.getId());
        Cooperation cooperation = cooperationMapper.selectOne(queryWrapper1);
        //协作的发布者
        Integer memberId = null;
        if (cooperation != null){
            memberId = cooperation.getMemberId().intValue();
            cooperationReplyPageDTO.setCooperationId(cooperation.getId());
        }
        //当前会员
        int currentMemberId = Integer.parseInt(commonService.memberId());

        if (memberId != null && currentMemberId != memberId){
            //如果此协助不是当前用户回复, 回复响应的人只能查看到自己的响应；
            cooperationReplyPageDTO.setMemberId(currentMemberId);
        }
        return cooperationReplyMapper.page(cooperationReplyPageDTO, cooperationReplyPageDTO.buildPage());
    }

    @Override
    public Page<CooperationReply> page(CooperationReplyPageDTO cooperationReplyPageDTO) {
        return cooperationReplyMapper.page(cooperationReplyPageDTO, cooperationReplyPageDTO.buildPage());
    }

    @Override
    public Boolean delete(CooperationReplyDeleteDTO cooperationReplyDeleteDTO) {
        return removeById(cooperationReplyDeleteDTO.getCooperationId());
    }

}
