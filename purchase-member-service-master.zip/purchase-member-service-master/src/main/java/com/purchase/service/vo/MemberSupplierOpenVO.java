package com.purchase.service.vo;

import com.purchase.entity.Member;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.data.annotation.Transient;

/**
 * @author jidonglin
 * @Description: 会员开通供应商
 * @date 2023/5/8  15:08
 */
@Data
public class MemberSupplierOpenVO extends Member {
    @Schema(description = "客户id")
    private Integer custId;

    @Schema(description = "供应商id")
    private String supplierId;
}
