package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/10/16  13:56
 */
@Data
public class RealNewsResourceDTO extends PageDTO {

    @Schema(description = "tab类型：1、产品资源 2、服务资源 3、我发布的资源")
    @NotNull(message = "tab条件不能为空")
    private String tabType;

    @Schema(description = "资源类型")
    private String resourceType;

    @Schema(description = "会员id")
    private Integer memberId ;

    @Schema(description = "协作id")
    private Integer cooperationId ;
}
