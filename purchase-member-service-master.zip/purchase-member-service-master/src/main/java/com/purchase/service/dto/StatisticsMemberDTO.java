package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author jidonglin
 * @Description: 会员统计DTO
 * @date 2023/10/10  9:28
 */
@Data
public class StatisticsMemberDTO {
    @NotNull(message = "统计类型不能为空")
    @Schema(description = "1、会员服务行业分布 2、会员核心能力分布")
    private String type;
}
