package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.entity.MemberSearchHistory;
import com.purchase.service.dto.MemberSearchHistoryAddDTO;
import com.purchase.service.dto.QueryIdDTO;
import com.zyd.framework.boot.config.base.PageDTO;

/**
 * <p>
 * 客户搜索历史表 服务类
 * </p>
 *
 * @author
 * @since 2023-02-10
 */
public interface MemberSearchHistoryService extends IService<MemberSearchHistory> {

    Boolean add(MemberSearchHistoryAddDTO memberSearchHistoryAddDTO);

    Page<MemberSearchHistory> pageList(PageDTO pageDTO);

    Boolean deleted(QueryIdDTO queryIdDTO);

    Boolean allDeleted();
}
