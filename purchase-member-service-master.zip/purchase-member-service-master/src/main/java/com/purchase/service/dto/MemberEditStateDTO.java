package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.*;


@Data
public class MemberEditStateDTO extends BaseEntity {

    @NotNull(message = "id必填")
    @Schema(description="会员id")
    private Integer id;

    @Max(value = 2,message = "状态错误，请重新选择")
    @Min(value = 0,message = "状态错误,请重新选择")
    @Schema(description = "新的状态")
    private Integer state;

    @Schema(description = "未通过原因")
    private String reason;

    @Schema(description = "是否在小程序通讯录显示（0=不显示，1= 显示）")
    private Integer isShow;

    @Length(max = 1000,message = "备注不能超过1000")
    @Schema(description = "备注")
    private String remark;

}
