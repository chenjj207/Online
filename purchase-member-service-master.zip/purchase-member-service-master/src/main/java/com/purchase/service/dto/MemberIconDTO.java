package com.purchase.service.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
public class MemberIconDTO {

    @Pattern(regexp ="^https?:\\/\\/(.+\\/)+.+(\\.(gif|png|jpg|jpeg|webp|svg|psd|bmp|tif))$",message = "请选择图片")
    @NotBlank(message = "头像不能为空")
    private String IconUrl;
}
