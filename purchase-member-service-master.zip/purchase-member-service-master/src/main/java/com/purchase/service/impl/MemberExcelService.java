package com.purchase.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.map.MapUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.metadata.fill.FillConfig;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.ObjectUtils;
import com.purchase.common.MemberConstants;
import com.purchase.entity.Member;
import com.purchase.entity.MemberExcelEntity;
import com.purchase.mapper.MemberMapper;
import com.purchase.service.dto.MemberExportDTO;
import com.purchase.service.vo.MemberStateNumVO;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;


@Service
public class MemberExcelService {

    @Resource
    MemberMapper memberMapper;

    @Autowired
    MemberServiceImpl memberService;

    public void memberExportExcel(HttpServletResponse response,MemberExportDTO memberExportDTO) throws IOException {
        try {
//             这里URLEncoder.encode可以防止中文乱码 当然和easyExcel没有关系
            String fileName = URLEncoder.encode("会员信息"+ DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm").format(LocalDateTime.now()));
            //设置请求头
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
            response.setCharacterEncoding("utf-8");

            //【会员信息】获取要导出信息，并进行处理
            List<MemberExcelEntity> excelEntityList = new ArrayList<>();
            List<Integer> ids = new ArrayList<>();
            List<Member> list= queryList(memberExportDTO);
            System.out.println(list);
            list.forEach(e->{
                MemberExcelEntity memberExcelEntity = new MemberExcelEntity();
                BeanUtil.copyProperties(e,memberExcelEntity);
                memberExcelEntity.setState(MemberConstants.MemberState.getValue(e.getState()));
                memberExcelEntity.setIsShow(MemberConstants.IsShow.getValue(e.getIsShow()));
                memberExcelEntity.setArea(e.getProvince()+e.getCity()+e.getArea());
                excelEntityList.add(memberExcelEntity);
                ids.add(e.getId());
            });
            //【数据汇总】获取要导出信息，并进行处理
            Map<String,Integer> dataMap = leadData(ids);

            //根据实体类生成
//            EasyExcel.write(response.getOutputStream(), MemberExcelEntity.class).autoCloseStream(Boolean.FALSE).sheet("会员信息")
//                    .doWrite(excelEntityList);

            //【数据汇总】会员注册时间区间
            Map<String,String> timeMap = new HashMap<>();
        if(BeanUtil.isNotEmpty(memberExportDTO.getBeginTime())&&BeanUtil.isNotEmpty(memberExportDTO.getEndTime())){
            SimpleDateFormat format = new SimpleDateFormat("yyyy.MM.dd");
            timeMap.put("startTime", format.format(memberExportDTO.getBeginTime()));
            timeMap.put("endTime",format.format(memberExportDTO.getEndTime()));
        } else{
            timeMap.put("startTime", excelEntityList.get(excelEntityList.size() - 1).getCreatedAt().format(DateTimeFormatter.ofPattern("yyyy.MM.dd")));
            timeMap.put("endTime", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd")));
        }

            ServletOutputStream out= response.getOutputStream();
            //设置导出模板
            InputStream inputStream = new ClassPathResource("template/member.xlsx").getInputStream();
            ExcelWriter writer = EasyExcel.write(out).withTemplate(inputStream).excelType(ExcelTypeEnum.XLSX).build();
            //设置开启sheet与公式更新
            Workbook workbook = writer.writeContext().writeWorkbookHolder().getWorkbook();
            workbook.setForceFormulaRecalculation(true);
            workbook.setActiveSheet(0);
            WriteSheet sheet = EasyExcel.writerSheet(0).build();
            WriteSheet sheet1 = EasyExcel.writerSheet(1).build();
            //将数据写入模板
            FillConfig fillConfig = FillConfig.builder().forceNewRow(true).build();
            //【会员信息】数据填充
            writer.fill(excelEntityList,fillConfig,sheet);
            //【数据汇总】数据填充
            writer.fill(dataMap,fillConfig,sheet1);
            writer.fill(timeMap,fillConfig,sheet1);
            writer.finish();
            out.flush();
        } catch (Exception e) {
            // 重置response
            response.reset();
            response.setContentType("application/json");
            response.setCharacterEncoding("utf-8");
            Map<String, String> map = MapUtil.newHashMap();
            map.put("status", "failure");
            map.put("message", "下载文件失败" + e.getMessage());
            response.getWriter().println(JSON.toJSONString(map));
        }

    }


    //根据条件查询当前需要导出的信息
    public List<Member> queryList(MemberExportDTO memberExportDTO){
        QueryWrapper<Member> wrapper = new QueryWrapper<>();
        wrapper.eq(!ObjectUtils.isEmpty(memberExportDTO.getState()),"state",memberExportDTO.getState())
                //pc管理端搜索可选参数
                .and(StringUtils.isNotBlank(memberExportDTO.getKey()),i-> i
                        .or().like("company",memberExportDTO.getKey())
                        .or().like("linkman",memberExportDTO.getKey())
                        .or().like("linkphone",memberExportDTO.getKey())
                        .or().like("promoter",memberExportDTO.getKey())
                        .or().like("wx_nick_name",memberExportDTO.getKey())
                )
                .eq("is_inner", MemberConstants.IsInner.NO.code)
                .eq(ObjectUtils.isNotEmpty(memberExportDTO.getIsShow()),"is_show",memberExportDTO.getIsShow())
                .eq(StringUtils.isNotBlank(memberExportDTO.getIndustry()),"industry",memberExportDTO.getIndustry())
                .and(BeanUtil.isNotEmpty(memberExportDTO.getCompanyName())&&memberExportDTO.getCompanyName().size()>0,i->i
                        .in("company_name",memberExportDTO.getCompanyName())
                        .or(memberExportDTO.getCompanyName().contains("")).isNull(memberExportDTO.getCompanyName().contains(""),"company_name")
                )
                .eq(StringUtils.isNotBlank(memberExportDTO.getCompetence()),"competence",memberExportDTO.getCompetence())
                .gt(!ObjectUtils.isEmpty(memberExportDTO.getBeginTime()),"created_at",memberExportDTO.getBeginTime())
                .lt(!ObjectUtils.isEmpty(memberExportDTO.getEndTime()),"created_at",memberExportDTO.getEndTime())
                .orderByDesc("created_at");
        return memberMapper.selectList(wrapper);
    }

    public Map<String,Integer> leadData(List<Integer> ids){
        //【数据汇总】
        Map<String,Integer> dataMap = new LinkedHashMap<>();
        //如果会员数据为空时
        if (ids.size()==0){
            return new LinkedHashMap<>();
        }
        //【数据汇总】各公司数据汇总
        List<MemberStateNumVO> memberStateNumVOList = memberMapper.selectStateNumCount(ids);
        MemberStateNumVO memberStateNumVO = new MemberStateNumVO(0,0,0,"客户自行加入",null);
        memberStateNumVOList.forEach(e->{
            if(MemberConstants.AreaType.OTHER.getMessage().equals(e.getAreaName())&&!"上海供应链公司".equals(e.getCompanyName())) {
                memberStateNumVO.setCheckNum(memberStateNumVO.getCheckNum()+e.getCheckNum());
                memberStateNumVO.setPassNum(memberStateNumVO.getPassNum()+e.getPassNum());
                memberStateNumVO.setReferNum(memberStateNumVO.getReferNum()+e.getReferNum());
            }else  {
                dataMap.put(e.getCompanyName()+MemberConstants.MemberState.CHECK.message,e.getCheckNum());
                dataMap.put(e.getCompanyName()+MemberConstants.MemberState.PASS.message,e.getPassNum());
                dataMap.put(e.getCompanyName()+MemberConstants.MemberState.REFER.message,e.getReferNum());
                Integer totalNum = e.getCheckNum()+e.getPassNum()+e.getReferNum();
                dataMap.put(e.getCompanyName()+MemberConstants.MemberState.ALL.message,totalNum);
            }
        });
//        //【数据汇总】客户自行加入的公司数据汇总
        dataMap.put("客户自行加入"+MemberConstants.MemberState.CHECK.message,memberStateNumVO.getCheckNum());
        dataMap.put("客户自行加入"+MemberConstants.MemberState.PASS.message,memberStateNumVO.getPassNum());
        dataMap.put("客户自行加入"+MemberConstants.MemberState.REFER.message,memberStateNumVO.getReferNum());
        Integer companyTotalNum = memberStateNumVO.getCheckNum()+memberStateNumVO.getPassNum()+memberStateNumVO.getReferNum();
        dataMap.put("客户自行加入"+MemberConstants.MemberState.ALL.message,companyTotalNum);
        Map<String,Integer> map = new LinkedHashMap<>();
        dataMap.forEach((key, value) -> {
            if (value >0){
                map.put(key,value);
            }
        });
        return map;
    }
}
