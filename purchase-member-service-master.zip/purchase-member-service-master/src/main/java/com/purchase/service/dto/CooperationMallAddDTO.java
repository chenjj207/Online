package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.time.LocalDateTime;

@Data
public class CooperationMallAddDTO {

    @Pattern(regexp = "resource|need",message = "参数错误")
    @NotBlank(message = "协作类型不能为空")
    @Schema(description = "协作类型")
    private String type;

    @NotBlank(message = "标题不能为空")
    @Schema(description = "标题")
    private String title;

    @Schema(description = "资源类型")
    @Pattern(regexp = "product|service",message = "资源类型参数错误")
    private String resourceType;

    @Schema(description = "需求类型")
    @Pattern(regexp = "serviceCooperate",message = "需求类型参数错误")
    private String needType;

    @Schema(description = "图片路径")
    private String  teamUrl;

    @NotBlank(message = "协作详情不能为空")
    @Schema(description = "协作详情")
    private String teamInfo;

    @Schema(description = "需求有效期")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime expireTime;

}
