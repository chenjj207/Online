package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author jidonglin
 * @Description: 邀约聊天
 * @date 2023/10/17  16:40
 */
@Data
public class MemberInviteDTO {

    @Schema(description = "会员id")
    @NotNull(message = "会员id不能为空")
    private Integer memberId;
}
