package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Pattern;
import java.util.Date;
import java.util.List;

@Data
public class BrandAuthApplyPageDTO extends PageDTO {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "开始时间")
    private Date beginTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "结束时间")
    private Date endTime;

    @Schema(description = "状态")
    @Pattern(regexp = "1|2|3|4|5|6",message = "状态参数错误")
    private String state;

    @Schema(description = "子公司名称")
    private List<String> subCompany;

    @Schema(description = "项目推广专员")
    private String promotionPerson;

    @Schema(description = "年 如：2024")
    private Integer year;

    @Schema(description = "授权期限 1、第一季度 2、第二季度 3、第三季度 4、第四季度")
    private String authTime;

    @Schema(description = "模糊查询 客户名称/联系人/联系方式")
    private String key;

    @Schema(description = "是否有协议存档 0：否 1：是")
    private String archive;

    @Schema(description = "签约类型 1：首签 2：续签")
    private String signType;
}
