package com.purchase.service.impl;

import com.purchase.entity.AssociateApplyProductPlan;
import com.purchase.mapper.AssociateApplyProductPlanMapper;
import com.purchase.service.AssociateApplyProductPlanService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 计划合作产品基础信息 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-14
 */
@Service
public class AssociateApplyProductProductPlanServiceImpl extends ServiceImpl<AssociateApplyProductPlanMapper, AssociateApplyProductPlan> implements AssociateApplyProductPlanService {

}
