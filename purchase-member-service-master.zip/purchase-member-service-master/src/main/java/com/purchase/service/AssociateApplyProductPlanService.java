package com.purchase.service;

import com.purchase.entity.AssociateApplyProductPlan;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 计划合作产品基础信息 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-03-14
 */
public interface AssociateApplyProductPlanService extends IService<AssociateApplyProductPlan> {

}
