package com.purchase.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.extra.servlet.ServletUtil;
import com.purchase.entity.LoginLog;
import com.purchase.entity.Member;
import com.purchase.mapper.LoginLogMapper;
import com.purchase.service.LoginLogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * <p>
 * 登录日志表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-06-27
 */
@Service
public class LoginLogServiceImpl extends ServiceImpl<LoginLogMapper, LoginLog> implements LoginLogService {

    @Override
    public void saveLoginLog(Member memberResultOld, String ip) {
        LoginLog loginLog = new LoginLog();
        BeanUtil.copyProperties(memberResultOld,loginLog,"id","updatedBy","updatedAt");
        loginLog.setIpAddress(ip);
        loginLog.setAccessTime(LocalDateTime.now());
        loginLog.setCreatedAt(LocalDateTime.now());
        save(loginLog);
    }
}
