package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

@Data
public class MemberMessageAddDTO {

    @Schema(description = "接受消息的会员组id")
    private List<Integer> memberId;

    @Schema(description = "消息标题")
    private String noticeTitle;

    @NotBlank(message = "接受对象类型不能为空")
    @Schema(description = "接收者类型")
    private String receiverType;

    @NotBlank(message = "消息内容不能为空")
    @Schema(description = "消息内容")
    private String noticeInfo;

    @Schema(description = "附件路径")
    private String accessoryUrl;

    @NotBlank(message = "创建者不能为空")
    @Schema(description = "消息创建者")
    private String createdBy;
}
