package com.purchase.service.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Data
public class RealNewsVO  extends BaseEntity {
    @Schema(description = "资讯标题")
    private String consultTitle;

    @Schema(description = "资讯内容")
    private String consultInfo;

    @Schema(description = "资讯发布者")
    private String publisher;

    @Schema(description = "主图")
    private String firstPic;

    @Schema(description = "发布页面")
    private String page;

    @Schema(description = "是否显示(0为未发布,1为发布)")
    private Integer isShow;

    @Schema(description = "是否开启感兴趣(0为未开启，1为开启)")
    private Integer isOpenInterested;

    @Schema(description = "感兴趣人数")
    private Integer interestCount;

    @Schema(description = "感兴趣人员分组")
    private String interestList;

    @Schema(description = "资讯类型")
    private String consultType;

    @Schema(description = "浏览数")
    private Integer browseNum;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(description = "添加时间")
    private LocalDateTime createdTime;

    @Schema(description = "响应数")
    private Integer replyNum;
}
