package com.purchase.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.RealNewsType;
import com.purchase.mapper.RealNewsTypeMapper;
import com.purchase.service.RealNewsTypeService;
import com.purchase.service.dto.QueryTypeDTO;
import com.purchase.service.dto.RealNewsTypeAddDTO;
import com.zyd.framework.utils.exception.BusinessException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 资讯分类表 服务实现类
 * </p>
 *
 * @author
 * @since 2023-02-10
 */
@Service
public class RealNewsTypeServiceImpl extends ServiceImpl<RealNewsTypeMapper, RealNewsType> implements RealNewsTypeService {

    @Resource
    RealNewsTypeMapper realNewsTypeMapper;

    @Override
    public Boolean add(RealNewsTypeAddDTO realNewsTypeAddDTO) {
        QueryWrapper<RealNewsType> wrapper = new QueryWrapper<>();
        //查看分类是否存在
        if(count(wrapper.eq("type_name",realNewsTypeAddDTO.getTypeName()))>0){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.REAL_NEW_EXIST);
        }
        //不存在则新增
        RealNewsType realNewsType = new RealNewsType();
        BeanUtil.copyProperties(realNewsTypeAddDTO,realNewsType);
        realNewsType.setCreatedAt(LocalDateTime.now());
        return save(realNewsType);
    }

    @Override
    public List<RealNewsType> queryType(QueryTypeDTO queryTypeDTO) {
        QueryWrapper<RealNewsType> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(StrUtil.isNotBlank(queryTypeDTO.getQueryType()),"page",queryTypeDTO.getQueryType());
        return realNewsTypeMapper.selectList(queryWrapper);
    }

}
