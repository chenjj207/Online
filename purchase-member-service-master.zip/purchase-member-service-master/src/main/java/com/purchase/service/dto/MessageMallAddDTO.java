package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class MessageMallAddDTO {

    @NotNull(message = "消息内容不能为空")
    @Schema(description = "消息内容")
    private String noticeInfo;

    @NotNull(message = "会员id，消息接收者不能为空")
    @Schema(description = "会员id，消息接收者")
    private Integer memberId;
}
