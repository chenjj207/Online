package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
* <p>
* 联营协议表
* </p>
* @author jidonglin
* @since 2024-04-02
*/
@Data
@Schema(title = "联营协议表")
public class AssociateProtocolQueryDTO {

    @NotEmpty(message = "openId不能为空")
    @Schema(description = "openId")
    private String openId;


}
