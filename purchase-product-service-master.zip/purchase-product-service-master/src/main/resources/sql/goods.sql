
-- ----------------------------
-- ----------------------------
DROP TABLE IF EXISTS `t_pd_purchase_cata_brand_prop`;
CREATE TABLE `t_pd_purchase_cata_brand_prop` (
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键',
  `first_level_cata_name` varchar(50) DEFAULT NULL COMMENT '一级分类名称',
  `second_level_cata_name` varchar(50) DEFAULT NULL COMMENT '二级分类名称',
  `three_level_cata_name` varchar(50) DEFAULT NULL COMMENT '三级分类名称',
  `brand_name` varchar(50) DEFAULT NULL COMMENT '品牌名称',
  `prop_name` varchar(50) DEFAULT NULL COMMENT '系列名称',
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '创建者',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '更新者',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  `corp_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '公司标识',
  `remark` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='_分类、系列、品牌关系表';