package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseScmGuideConfig;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 * @Description: 供应商_SCM产品申请引导配置表
 * @Author: loine
 * @Date: 2024/11/5 14:01
 **/
public interface PurchaseScmGuideConfigMapper extends QguBaseMapper<PurchaseScmGuideConfig> {

}
