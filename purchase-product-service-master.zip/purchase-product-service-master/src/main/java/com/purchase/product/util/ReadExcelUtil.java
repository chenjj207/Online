package com.purchase.product.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.utils.DateUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
public class ReadExcelUtil {
    public static final String OFFICE_EXCEL_2003_POSTFIX = "xls";
    public static final String OFFICE_EXCEL_2010_POSTFIX = "xlsx";
    public static final String EMPTY = "";
    public static final String POINT = ".";
    private static final String[] parsePatterns = {"yyyy-MM-dd", "yyyy年MM月dd日",
            "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy/MM/dd",
            "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyyMMdd"};
    public static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

    public int totalRows; // sheet中总行数
    public static int totalCells; // 每一行总单元格数

    /**
     * 读取Excel（xls,xlsx），单个sheet
     *
     * @param file 上传文件
     */
    public List<ArrayList<String>> readExcelOne(MultipartFile file, int rowNumBegin) {
        if (file == null || EMPTY.equals(Objects.requireNonNull(file.getOriginalFilename()).trim())) {
            return null;
        } else {
            String postfix = getPostfix(file.getOriginalFilename());
            if (!EMPTY.equals(postfix)) {
                if (OFFICE_EXCEL_2003_POSTFIX.equals(postfix)) {
                    return readXlsOne(file, rowNumBegin);
                } else if (OFFICE_EXCEL_2010_POSTFIX.equals(postfix)) {
                    return readXlsxOne(file, rowNumBegin);
                } else {
                    return null;
                }
            }
        }
        return null;
    }

    /**
     * 读取Excel（xls,xlsx），支持多个sheet
     *
     * @param file 上传文件
     */
    public List<ArrayList<String>> readExcel(MultipartFile file, int rowNumBegin) {
        if (file == null || EMPTY.equals(Objects.requireNonNull(file.getOriginalFilename()).trim())) {
            return null;
        } else {
            String postfix = getPostfix(file.getOriginalFilename());
            if (!EMPTY.equals(postfix)) {
                if (OFFICE_EXCEL_2003_POSTFIX.equals(postfix)) {
                    return readXls(file, rowNumBegin);
                } else if (OFFICE_EXCEL_2010_POSTFIX.equals(postfix)) {
                    return readXlsx(file, rowNumBegin);
                } else {
                    return null;
                }
            }
        }
        return null;
    }

    /**
     * 读取Excel总行数（xls,xlsx）
     *
     * @param file 上传文件
     */
    public int readTotalRows(MultipartFile file) {
        if (file == null || EMPTY.equals(Objects.requireNonNull(file.getOriginalFilename()).trim())) {
            return 0;
        } else {
            String postfix = getPostfix(file.getOriginalFilename());
            if (!EMPTY.equals(postfix)) {
                if (OFFICE_EXCEL_2003_POSTFIX.equals(postfix)) {
                    return readXlsTotalRows(file);
                } else if (OFFICE_EXCEL_2010_POSTFIX.equals(postfix)) {
                    return readXlsxTotalRows(file);
                } else {
                    return 0;
                }
            }
        }
        return 0;
    }

    /**
     * 读取Excel（xls），单个sheet
     *
     * @param file 上传文件
     */
    private List<ArrayList<String>> readXlsOne(MultipartFile file, int rowNumBegin) {
        List<ArrayList<String>> list = new ArrayList<>();
        // IO流读取文件
        ArrayList<String> rowList;
        try (InputStream input = file.getInputStream(); HSSFWorkbook wb = new HSSFWorkbook(input)) {
            // 创建文档
            // 读取sheet(页)
            HSSFSheet hssfSheet = wb.getSheetAt(0);
            if (hssfSheet == null) {
                return list;
            }
            totalRows = hssfSheet.getLastRowNum();
            // 读取Row,从第3行开始
            for (int rowNum = rowNumBegin; rowNum <= totalRows; rowNum++) {
                HSSFRow hssfRow = hssfSheet.getRow(rowNum);
                if (hssfRow != null) {
                    rowList = new ArrayList<>();
                    totalCells = hssfRow.getLastCellNum();
                    // 读取列，从第一列开始
                    int empty = 0;
                    for (int c = 0; c < totalCells; c++) {
                        HSSFCell cell = hssfRow.getCell(c);
                        // 设置单元格类型
                        if (cell == null) {
                            rowList.add(EMPTY);
                            empty++;
                            continue;
                        }
                        String value;
                        if (!checkNull(cell) && cell.getCellStyle().getDataFormatString().contains("%") && !(cell.getCellTypeEnum() == CellType.STRING)) {
                            // 此字符串中没有这样的字符，则返回 -1
                            double a = cell.getNumericCellValue();
                            double b = a * 100;
                            String pp = String.format("%.4f", b);
                            value = pp + "%";
                        } else {
                            value = getHValue(cell).trim();
                        }
                        if (StringUtils.isBlank(value)) {
                            empty++;
                        }
                        rowList.add(value);
                    }
                    // 全部为空的数据则不加入
                    if (empty != totalCells) {
                        list.add(rowList);
                    }
                }
            }
            return list;
        } catch (IOException e) {
            log.error("读取xls异常：" + e.getMessage());
        }
        return null;
    }

    /**
     * 读取Excel（xlsx），单个sheet
     *
     * @param file 上传文件
     */
    private List<ArrayList<String>> readXlsxOne(MultipartFile file, int rowNumBegin) {
        List<ArrayList<String>> list = new ArrayList<>();
        // IO流读取文件
        ArrayList<String> rowList;
        try (InputStream input = file.getInputStream(); XSSFWorkbook wb = new XSSFWorkbook(input)) {
            // 创建文档
            // 读取sheet(页)
            XSSFSheet xssfSheet = wb.getSheetAt(0);
            if (xssfSheet == null) {
                return list;
            }
            totalRows = xssfSheet.getLastRowNum();
            // 读取Row,从第n行开始
            for (int rowNum = rowNumBegin; rowNum <= totalRows; rowNum++) {
                XSSFRow xssfRow = xssfSheet.getRow(rowNum);
                if (xssfRow != null) {
                    rowList = new ArrayList<>();
                    totalCells = xssfRow.getLastCellNum();
                    // 读取列，从第一列开始
                    int empty = 0;
                    for (int c = 0; c < totalCells; c++) {
                        XSSFCell cell = xssfRow.getCell(c);
                        // 设置单元格类型
                        if (cell == null) {
                            rowList.add(EMPTY);
                            empty++;
                            continue;
                        }
                        String value;
                        if (!checkNull(cell) && cell.getCellStyle().getDataFormatString().contains("%") && !(cell.getCellTypeEnum() == CellType.STRING)) {
                            // 此字符串中没有这样的字符，则返回 -1
                            double a = cell.getNumericCellValue();
                            double b = a * 100;
                            String pp = String.format("%.4f", b);
                            value = pp + "%";
                        } else {
                            value = getXValue(cell).trim();
                        }
                        if (StringUtils.isBlank(value)) {
                            empty++;
                        }
                        rowList.add(value);
                    }
                    // 全部为空的数据则不加入
                    if (empty != totalCells) {
                        list.add(rowList);
                    }
                }
            }
            return list;
        } catch (IOException e) {
            log.error("读取xlsx异常：" + e.getMessage());
        }
        return null;

    }

    /**
     * 读取Excel（xls），支持多个sheet
     *
     * @param file 上传文件
     */
    private List<ArrayList<String>> readXls(MultipartFile file, int rowNumBegin) {
        List<ArrayList<String>> list = new ArrayList<>();
        // IO流读取文件
        ArrayList<String> rowList;
        try (InputStream input = file.getInputStream(); HSSFWorkbook wb = new HSSFWorkbook(input)) {
            // 创建文档
            // 读取sheet(页)
            for (int numSheet = 0; numSheet < wb.getNumberOfSheets(); numSheet++) {
                HSSFSheet hssfSheet = wb.getSheetAt(numSheet);
                if (hssfSheet == null) {
                    continue;
                }
                totalRows = hssfSheet.getLastRowNum();
                // 读取Row,从第3行开始
                for (int rowNum = rowNumBegin; rowNum <= totalRows; rowNum++) {
                    HSSFRow hssfRow = hssfSheet.getRow(rowNum);
                    if (hssfRow != null) {
                        rowList = new ArrayList<>();
                        totalCells = hssfRow.getLastCellNum();
                        // 读取列，从第一列开始
                        int empty = 0;
                        for (int c = 0; c < totalCells; c++) {
                            HSSFCell cell = hssfRow.getCell(c);
                            // 设置单元格类型
                            if (cell == null) {
                                rowList.add(EMPTY);
                                empty++;
                                continue;
                            }
                            String value;
                            if (!checkNull(cell) && cell.getCellStyle().getDataFormatString().contains("%") && !(cell.getCellTypeEnum() == CellType.STRING)) {
                                // 此字符串中没有这样的字符，则返回 -1
                                double a = cell.getNumericCellValue();
                                double b = a * 100;
                                String pp = String.format("%.4f", b);
                                value = pp + "%";
                            } else {
                                value = getHValue(cell).trim();
                            }
                            if (StringUtils.isBlank(value)) {
                                empty++;
                            }
                            rowList.add(value);
                        }
                        // 全部为空的数据则不加入
                        if (empty != totalCells) {
                            list.add(rowList);
                        }
                    }
                }
            }
            return list;
        } catch (IOException e) {
            log.error("读取xls异常：" + e.getMessage());
        }
        return null;
    }

    /**
     * 读取Excel（xlsx），支持多个sheet
     *
     * @param file 上传文件
     */
    private List<ArrayList<String>> readXlsx(MultipartFile file, int rowNumBegin) {
        List<ArrayList<String>> list = new ArrayList<>();
        // IO流读取文件
        ArrayList<String> rowList;
        try (InputStream input = file.getInputStream(); XSSFWorkbook wb = new XSSFWorkbook(input)) {
            // 创建文档
            // 读取sheet(页)
            for (int numSheet = 0; numSheet < wb.getNumberOfSheets(); numSheet++) {
                XSSFSheet xssfSheet = wb.getSheetAt(numSheet);
                if (xssfSheet == null) {
                    continue;
                }
                totalRows = xssfSheet.getLastRowNum();
                // 读取Row,从第n行开始
                for (int rowNum = rowNumBegin; rowNum <= totalRows; rowNum++) {
                    XSSFRow xssfRow = xssfSheet.getRow(rowNum);
                    if (xssfRow != null) {
                        rowList = new ArrayList<>();
                        totalCells = xssfRow.getLastCellNum();
                        // 读取列，从第一列开始
                        int empty = 0;
                        for (int c = 0; c < totalCells; c++) {
                            XSSFCell cell = xssfRow.getCell(c);
                            // 设置单元格类型
                            if (cell == null) {
                                rowList.add(EMPTY);
                                empty++;
                                continue;
                            }
                            String value;
                            if (!checkNull(cell) && cell.getCellStyle().getDataFormatString().contains("%") && !(cell.getCellTypeEnum() == CellType.STRING)) {
                                // 此字符串中没有这样的字符，则返回 -1
                                double a = cell.getNumericCellValue();
                                double b = a * 100;
                                String pp = String.format("%.4f", b);
                                value = pp + "%";
                            } else {
                                value = getXValue(cell).trim();
                            }
                            if (StringUtils.isBlank(value)) {
                                empty++;
                            }
                            rowList.add(value);
                        }
                        // 全部为空的数据则不加入
                        if (empty != totalCells) {
                            list.add(rowList);
                        }
                    }
                }
            }
            return list;
        } catch (IOException e) {
            log.error("读取xlsx异常：" + e.getMessage());
        }
        return null;

    }

    /**
     * 读取Excel总行数（xls）
     *
     * @param file 上传文件
     */
    private int readXlsTotalRows(MultipartFile file) {
        List<ArrayList<String>> list = new ArrayList<>();
        // IO流读取文件
        try (InputStream input = file.getInputStream(); HSSFWorkbook wb = new HSSFWorkbook(input)) {
            // 创建文档
            // 读取sheet(页)
            for (int numSheet = 0; numSheet < wb.getNumberOfSheets(); numSheet++) {
                HSSFSheet hssfSheet = wb.getSheetAt(numSheet);
                if (hssfSheet == null) {
                    continue;
                }
                totalRows = hssfSheet.getLastRowNum();
            }
            return totalRows;
        } catch (IOException e) {
            log.error("读取xls总行数异常：" + e.getMessage());
        }
        return 0;
    }

    /**
     * 读取Excel总行数（xlsx）
     *
     * @param file 上传文件
     */
    private int readXlsxTotalRows(MultipartFile file) {
        // IO流读取文件
        try (InputStream input = file.getInputStream(); XSSFWorkbook wb = new XSSFWorkbook(input)) {
            // 创建文档
            // 读取sheet(页)
            for (int numSheet = 0; numSheet < wb.getNumberOfSheets(); numSheet++) {
                XSSFSheet xssfSheet = wb.getSheetAt(numSheet);
                if (xssfSheet == null) {
                    continue;
                }
                totalRows = xssfSheet.getLastRowNum();
            }
            return totalRows;
        } catch (IOException e) {
            log.error("读取xlsx总行数异常：" + e.getMessage());
        }
        return 0;
    }

    /**
     * 判断 String 是否为 日期格式
     *
     * @param string
     * @return
     */
    private static Boolean isDateFormat(String string) {
        if (string == null) {
            return null;
        }
        try {
            Date date = DateUtils.parseDate(string, parsePatterns);
            return date != null;

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 获取前缀
     *
     * @param path
     */
    public static String getPostfix(String path) {
        if (path == null || EMPTY.equals(path.trim())) {
            return EMPTY;
        }
        if (path.contains(POINT)) {
            return path.substring(path.lastIndexOf(POINT) + 1);
        }
        return EMPTY;
    }

    /**
     * 对象是否为空
     *
     * @param obj String,List,Map,Object[],int[],long[]
     * @return
     */
    private boolean checkNull(Object obj) {
        if (obj == null) {
            return true;
        }
        if (obj instanceof String) {
            return obj.toString().trim().equals("");
        } else if (obj instanceof List) {
            return ((List) obj).size() == 0;
        } else if (obj instanceof Map) {
            return ((Map) obj).size() == 0;
        } else if (obj instanceof Set) {
            return ((Set) obj).size() == 0;
        } else if (obj instanceof Object[]) {
            return ((Object[]) obj).length == 0;
        } else if (obj instanceof int[]) {
            return ((int[]) obj).length == 0;
        } else if (obj instanceof long[]) {
            return ((long[]) obj).length == 0;
        }
        return false;
    }

    /**
     * 单元格格式
     *
     * @param hssfCell
     * @return
     */
    private String getHValue(HSSFCell hssfCell) {
        if (hssfCell.getCellTypeEnum() == CellType.BOOLEAN) {
            return String.valueOf(hssfCell.getBooleanCellValue());
        } else if (hssfCell.getCellTypeEnum() == CellType.NUMERIC) {
            String cellValue = "";
            if (HSSFDateUtil.isCellDateFormatted(hssfCell)) {
                Date date = HSSFDateUtil.getJavaDate(hssfCell.getNumericCellValue());
                cellValue = sdf.format(date);
            } else {
                DecimalFormat df = new DecimalFormat("#.####");
                cellValue = df.format(hssfCell.getNumericCellValue());
                String strArr = cellValue.substring(cellValue.lastIndexOf(POINT) + 1);
                if (strArr.equals("0000")) {
                    cellValue = cellValue.substring(0, cellValue.lastIndexOf(POINT));
                }
            }
            return cellValue;
        } else if (hssfCell.getCellTypeEnum() == CellType.FORMULA) {
            return hssfCell.getNumericCellValue() + "";
        } else {
            return String.valueOf(hssfCell.getStringCellValue());
        }
    }

    /**
     * 单元格格式
     *
     * @param xssfCell
     * @return
     */
    private String getXValue(XSSFCell xssfCell) {
        if (xssfCell.getCellTypeEnum() == CellType.BOOLEAN) {
            return String.valueOf(xssfCell.getBooleanCellValue());
        } else if (xssfCell.getCellTypeEnum() == CellType.NUMERIC) {
            String cellValue = "";
            if (XSSFDateUtil.isCellDateFormatted(xssfCell)) {
                Date date = XSSFDateUtil.getJavaDate(xssfCell.getNumericCellValue());
                cellValue = sdf.format(date);
            } else {
                DecimalFormat df = new DecimalFormat("#.####");
                cellValue = df.format(xssfCell.getNumericCellValue());
                String strArr = cellValue.substring(cellValue.lastIndexOf(POINT) + 1);
                if (strArr.equals("0000")) {
                    cellValue = cellValue.substring(0, cellValue.lastIndexOf(POINT));
                }
            }
            return cellValue;
        } else if (xssfCell.getCellTypeEnum() == CellType.FORMULA) {
            return xssfCell.getNumericCellValue() + "";
        } else {
            return String.valueOf(xssfCell.getStringCellValue());
        }
    }

    /**
     * 自定义xssf日期工具类
     */
    private static class XSSFDateUtil extends DateUtil {
        protected static int absoluteDay(Calendar cal, boolean use1904windowing) {
            return DateUtil.absoluteDay(cal, use1904windowing);
        }
    }
}