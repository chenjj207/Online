package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseProductApply;
import com.purchase.product.model.SupplierProductProperty;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;

public interface SupplierProductPropertyMapper extends QguBaseMapper<SupplierProductProperty> {
    void insertProductProperty(@Param("apply") PurchaseProductApply apply,@Param("time") LocalDateTime now);

    void updatePublicProductId(@Param("apply")PurchaseProductApply apply, @Param("time")LocalDateTime now);

    void updateApplyNo(@Param("apply")PurchaseProductApply apply, @Param("time")LocalDateTime now);

    SupplierProductProperty selectInapplyNo(@Param("apply") Long applyNo);

    String selectInProductId(@Param("id")Long productId);

    String selectProperty(@Param("dto") PurchaseProductApply e);

    void updateProperty(@Param("id")String propertyId,@Param("dto") PurchaseProductApply e);

    void insertProperty(@Param("dto") PurchaseProductApply e);
}
