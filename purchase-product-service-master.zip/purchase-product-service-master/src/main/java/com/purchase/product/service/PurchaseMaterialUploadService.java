package com.purchase.product.service;

import com.github.pagehelper.PageHelper;
import com.purchase.product.mapper.PurchaseMaterialUploadMapper;
import com.purchase.product.model.PurchaseMaterialUpload;
import com.qgutech.qgyun.dev.client.uc.UcFeignClient;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *  purchaseMaterialUploadService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-09-01 17:11:06
 */
@Service
public class PurchaseMaterialUploadService extends BaseServiceImpl<PurchaseMaterialUpload> {

    @Resource
    private PurchaseMaterialUploadMapper purchaseMaterialUploadMapper;
    @Resource
    private UcFeignClient ucFeignClient;
 
    public List<PurchaseMaterialUpload> listAll() {
        return purchaseMaterialUploadMapper.selectAll();
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<PurchaseMaterialUpload> search(PurchaseMaterialUpload purchaseMaterialUpload, Page<PurchaseMaterialUpload> page) {
        Assert.notNull(purchaseMaterialUpload, "purchaseMaterialUpload can not be null!");
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<PurchaseMaterialUpload> list = purchaseMaterialUploadMapper.search(purchaseMaterialUpload);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packpurchaseMaterialUploadData(list);
        return page;
    }

    private Example genConditionExample(PurchaseMaterialUpload model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();

        return example;
    }

    /**
     * 分页数据处理
     */
    private void packpurchaseMaterialUploadData(List<PurchaseMaterialUpload> purchaseMaterialUploadList) {
        if (CollectionUtils.isEmpty(purchaseMaterialUploadList)) {
            return;
        }
        
        List<String> userIds = purchaseMaterialUploadList.stream().map(PurchaseMaterialUpload::getUpdatedBy).collect(Collectors.toList());
        List<String> createdIds = purchaseMaterialUploadList.stream().map(PurchaseMaterialUpload::getCreatedBy).collect(Collectors.toList());
        userIds.addAll(createdIds);
        userIds = userIds.stream().distinct().collect(Collectors.toList());
        Map<String, String> userMap = ucFeignClient.getUserIdAndNameMap(userIds);
        for (PurchaseMaterialUpload purchaseMaterialUpload : purchaseMaterialUploadList) {
            if (!MapUtils.isNotEmpty(userMap)) {
                continue;
            }
          
            purchaseMaterialUpload.setCreatedByName(userMap.get(purchaseMaterialUpload.getCreatedBy()));
            purchaseMaterialUpload.setUpdatedByName(userMap.get(purchaseMaterialUpload.getUpdatedBy()));
        }
    }
  
    /**
     * 通过id获取详情
     */
    @Override
    public PurchaseMaterialUpload get(String id) {
        PurchaseMaterialUpload purchaseMaterialUpload = super.get(id);
        String createdBy = purchaseMaterialUpload.getCreatedBy();
        String updatedBy = purchaseMaterialUpload.getUpdatedBy();
        List<String> userIds = new ArrayList<>();
        if (StringUtils.isNotEmpty(createdBy)) {
            userIds.add(createdBy);
        }
      
        if (StringUtils.isNotEmpty(updatedBy)) {
            userIds.add(updatedBy);
        }
      
        userIds = userIds.stream().distinct().collect(Collectors.toList());
        Map<String, String> userMap = ucFeignClient.getUserIdAndNameMap(userIds);
        purchaseMaterialUpload.setCreatedByName(userMap.get(createdBy));
        purchaseMaterialUpload.setUpdatedByName(userMap.get(updatedBy));
        return purchaseMaterialUpload;
    }
  
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(PurchaseMaterialUpload purchaseMaterialUpload) {
        Assert.notNull(purchaseMaterialUpload, "purchaseMaterialUpload can not be null");
        Example example = genConditionExample(purchaseMaterialUpload);
        example.selectProperties(PurchaseMaterialUpload.ID);
        List<PurchaseMaterialUpload> purchaseMaterialUploadList = purchaseMaterialUploadMapper.selectByExample(example);
        return CollectionUtils.isEmpty(purchaseMaterialUploadList) ? new ArrayList<>(0) :
                purchaseMaterialUploadList.stream().map(PurchaseMaterialUpload::getId).collect(Collectors.toList());
    }
  
    /**
     * 新增
     */
    public String add(PurchaseMaterialUpload purchaseMaterialUpload) {
        return super.insert(purchaseMaterialUpload);
    }

    /**
     * 修改
     */
    public void edit(PurchaseMaterialUpload purchaseMaterialUpload) {
        super.update(purchaseMaterialUpload);
    }

    /**
     * 批量删除
     */
    public void deleteByIds(List<String> ids) {
         super.batchDelete(ids);
    }

}
