package com.purchase.product.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class BusinessProductListDto {

    @NotNull(message = "产品状态不可为空")
    @ApiModelProperty("产品状态  0：待审核,1：销售中，2：仓库中， 3：推荐商品使用")
    private Integer productStatus;

    @ApiModelProperty("分页页数")
    private Integer pageNum;

    @ApiModelProperty("分页记录数量")
    private Integer pageSize;

    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;

    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;

    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;

    @ApiModelProperty("商品品牌名称")
    private String brandName;

    @ApiModelProperty("商品系列名称")
    private String propName;

    @ApiModelProperty("一级店铺分类名称")
    private String firstStoreCataName;

    @ApiModelProperty("二级店铺分类名称")
    private String secondStoreCataName;

    @ApiModelProperty("关键字")
    private String key;

    @ApiModelProperty("商品申请来源 来源： inquiry | publish")
    private String applySource;

    @ApiModelProperty("物料号列表")
    private List<String> skuList;

    @ApiModelProperty("产品型号列表")
    private List<String> productTypeList;

    @ApiModelProperty("商品编码列表")
    private List<String> productCodeList;

}
