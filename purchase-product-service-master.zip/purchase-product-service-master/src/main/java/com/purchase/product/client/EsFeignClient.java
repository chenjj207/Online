package com.purchase.product.client;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@FeignClient(value = "purchase-es")
public interface EsFeignClient {

    @PostMapping(value = "/sync/updateByIds")
    public JSONObject updateByIds(@RequestBody @NotEmpty(message = "产品id列表不能为空") List<String> ids);
}
