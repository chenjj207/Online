package com.purchase.product.model;


import lombok.Data;


/**
* <p>
* 店铺表
* </p>
*
* @author jidonglin
* @since 2023-04-20
*/
@Data
public class PurchaseStore {

    private Integer id;

    private String storeCode;

    private String storeName;

    private Integer storeType;

    private String storeLogo;

    private String province;

    private String city;

    private String area;

    private Integer storeSort;

    private String address;

    private String linkMan;

    private String linkPhone;

    private String suppilerId;

    private Integer state;

    private String remark;

}
