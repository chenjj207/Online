package com.purchase.product.model;

import com.purchase.product.dto.oss.LevelNameDto;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.List;


@Data
@ApiModel(value = "PurchaseCataBrandProp", description = "分类、系列、品牌关系表")
@Table(name = "t_pd_purchase_cata_brand_prop")
public class PurchaseCataBrandProp extends BaseCorpModel {

    public static final String FIRST_LEVEL_CATA_NAME = "firstLevelCataName";
    public static final String SECOND_LEVEL_CATA_NAME = "secondLevelCataName";
    public static final String THREE_LEVEL_CATA_NAME = "threeLevelCataName";
    public static final String BRAND_NAME = "brandName";
    public static final String PROP_NAME = "propName";
    public static final String SUPPLIER_ID = "supplierId";
    public static final String IS_SUPPLY = "isSupply";

    /**
     * 一级分类名称
     */
    @ApiModelProperty(value = "一级分类名称")
    private String firstLevelCataName;
    /**
     * 二级分类名称
     */
    @ApiModelProperty(value = "二级分类名称")
    private String secondLevelCataName;

    /**
     * 三级分类名称
     */
    @ApiModelProperty(value = "三级分类名称")
    private String threeLevelCataName;

    /**
     * 品牌名称
     */
    @ApiModelProperty(value = "品牌名称")
    private String brandName;

    /**
     * 系列名称
     */
    @ApiModelProperty(value = "系列名称")
    private String propName;


    @ApiModelProperty("供应商id")
    private String supplierId;

    @ApiModelProperty("是否是供应链（Y：是，N：否）")
    private String isSupply;

    @Transient
    private List<LevelNameDto> levelList;


}
