package com.purchase.product.mapper;

import com.purchase.product.dto.PurchaseScmErpProductCodeApplyDto;
import com.purchase.product.model.PurchaseScmErpProductCodeApply;
import com.purchase.product.vo.PurchaseScmErpProductCodeApplyVo;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description:
 * @Author: loine
 * @Date: 2026/3/10 15:20
 */
public interface PurchaseScmErpProductCodeApplyMapper extends QguBaseMapper<PurchaseScmErpProductCodeApply> {

    /**
     * 后台-搜索
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/11 09:39
     */
    List<PurchaseScmErpProductCodeApplyVo.ErpAdminSearchVo> adminSearch(@Param("dto") PurchaseScmErpProductCodeApplyDto.ErpAdminSearchDto dto);

    /**
     * 后台-搜索角标
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/11 10:11
     */
    PurchaseScmErpProductCodeApplyVo.ErpSearchCountVo adminSearchCount(@Param("dto") PurchaseScmErpProductCodeApplyDto.ErpAdminSearchDto dto);

    /**
     * 后台-详情
     *
     * @param id
     * @Author loine
     * @Date 2026/3/11 10:26
     */
    PurchaseScmErpProductCodeApplyVo.ErpDetailVo adminDetail(@Param("id") String id);

    /**
     * 获取最大的申请编码
     *
     * @Author loine
     * @Date 2026/3/11 11:18
     */
    String getMaxApplyNo(@Param("key") String key);

    /**
     * 后台-参考详情
     *
     * @param referenceCode
     * @Author loine
     * @Date 2026/3/11 13:34
     */
    PurchaseScmErpProductCodeApplyVo.ErpReferenceDetailVo adminReferenceDetail(@Param("referenceCode") String referenceCode);

    /**
     * 后台-ERP产品属性列表
     *
     * @param code
     * @Author loine
     * @Date 2026/3/11 14:03
     */
    List<String> selectErpProductList(@Param("code") String code);

    /**
     * 获取需要更新ERP编码的申请列表
     *
     * @Author loine
     * @Date 2026/3/13 10:16
     */
    List<PurchaseScmErpProductCodeApply> getNeedUpdateIfsErpCode();

    /**
     * 获取已通过的申请列表
     *
     * @Author loine
     * @Date 2026/3/13 10:16
     */
    List<PurchaseScmErpProductCodeApply> getApproveList();

    /**
     * 获取IFS产品信息到申请表
     *
     * @param productType
     * @param productArea
     * @Author loine
     * @Date 2026/3/13 11:07
     */
    PurchaseScmErpProductCodeApply getIfsInfoToApply(@Param("productType") String productType, @Param("productArea") String productArea);

    /**
     * 后台-反推用户列表
     *
     * @Author loine
     * @Date 2026/3/19 09:23
     */
    List<PurchaseScmErpProductCodeApplyVo.ErpAdminUserListVo> adminUserList();

    /**
     * 校验IFS产品表是否存在
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/19 17:18
     */
    int checkIsIfsProduct(@Param("dto") PurchaseScmErpProductCodeApplyDto.ErpPublishDto dto);

    /**
     * 获取公司名称
     *
     * @param comBm
     * @Author loine
     * @Date 2026/3/20 10:20
     */
    String getComName(@Param("comBm") String comBm);

    /**
     * 获取用户名称
     *
     * @param userId
     * @Author loine
     * @Date 2026/3/20 10:20
     */
    String getUserName(@Param("userId") String userId);
}
