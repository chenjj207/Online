package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseCataBrandProp;
import com.purchase.product.model.PurchaseMaterialUpload;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface PurchaseCataBrandPropMapper extends QguBaseMapper<PurchaseCataBrandProp> {

    List<PurchaseCataBrandProp> listBrand(@Param("firstLevelCataName") String firstLevelCataName,
                                          @Param("secondLevelCataName") String secondLevelCataName,
                                          @Param("threeLevelCataName") String threeLevelCataName,
                                          @Param("brandName") String brandName,
                                          @Param("supplierId") String supplierId,
                                          @Param("isAudit") String isAudit,
                                          @Param("tab") Integer tab);

    List<PurchaseCataBrandProp> listProp(@Param("firstLevelCataName") String firstLevelCataName,
                                         @Param("secondLevelCataName") String secondLevelCataName,
                                         @Param("threeLevelCataName") String threeLevelCataName,
                                         @Param("brandName") String brandName,
                                         @Param("propName") String propName,
                                         @Param("supplierId") String supplierId,
                                         @Param("isAudit") String isAudit,
                                         @Param("tab") Integer tab);

    List<PurchaseCataBrandProp> listCataData(@Param("supplierId") String supplierId,
                                             @Param("isAudit") String isAudit,
                                             @Param("tab") Integer tab);
}
