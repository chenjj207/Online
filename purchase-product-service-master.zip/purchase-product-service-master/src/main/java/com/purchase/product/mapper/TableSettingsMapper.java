package com.purchase.product.mapper;

import com.purchase.product.model.TableSettings;
import org.apache.ibatis.annotations.Mapper;
import tk.mybatis.mapper.common.BaseMapper;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/2/11 9:45
 **/
@Mapper
public interface TableSettingsMapper extends BaseMapper<TableSettings> {
}
