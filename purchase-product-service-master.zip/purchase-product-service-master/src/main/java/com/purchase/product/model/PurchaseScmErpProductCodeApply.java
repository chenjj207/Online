package com.purchase.product.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.qgutech.qgyun.framework.common.utils.ReflectUtil;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.List;
import java.util.StringJoiner;

/**
 * @Description: 供应商_SCM_ERP产品编码申请表
 * @Author: loine
 * @Date: 2026/3/10 15:09
 **/
@Data
@ApiModel("供应商_SCM_ERP产品编码申请表")
@Table(name = "t_pd_purchase_scm_erp_product_code_apply")
public class PurchaseScmErpProductCodeApply extends BaseCorpModel {

    public static final String ID = "id";
    public static final String APPLY_NO = "applyNo";
    public static final String PRODUCT_TYPE = "productType";
    public static final String PRODUCT_AREA = "productArea";
    public static final String AUDIT_STATUS = "auditStatus";

    @ApiModelProperty("申请编号")
    private String applyNo;
    @ApiModelProperty("来源（1：手工申请，2：报价申请）")
    private String source;
    @ApiModelProperty("供应商品牌")
    private String supplierBrand;
    @ApiModelProperty("产品型号")
    private String productType;
    @ApiModelProperty("订货号")
    private String skuCode;
    @ApiModelProperty("ERP产品编码")
    private String erpProductCode;
    @ApiModelProperty("参考编码")
    private String referenceCode;
    @ApiModelProperty("产品凭证（多个@隔开）")
    private String productVoucher;
    @ApiModelProperty("物料名称")
    private String materialName;
    @ApiModelProperty("产地")
    private String productArea;
    @ApiModelProperty("单位")
    private String unit;
    @ApiModelProperty("产品属性2-品牌")
    private String sifsBrand;
    @ApiModelProperty("产品属性3-产品大类")
    private String sifsPdBcata;
    @ApiModelProperty("产品属性8-商品小类")
    private String sifsPdScata;
    @ApiModelProperty("产品属性11-统计大类")
    private String sifsStBcata;
    @ApiModelProperty("产品属性10-统计小类")
    private String sifsStScata;
    @ApiModelProperty("产品属性6-产品系列")
    private String sifsProp;
    @ApiModelProperty("产品属性4-产品细分")
    private String sifsSubversion;
    @ApiModelProperty("产品属性12-主采购组")
    private String sifsMainProcurement;
    @ApiModelProperty("产品属性5-供应商属性")
    private String sapplerAttribute;
    @ApiModelProperty("产品属性14-主配套分类")
    private String smainSubCat;
    @ApiModelProperty("税务分类编码（关联税务分类关系表）")
    private String taxCataCode;
    @ApiModelProperty("税务分类名称")
    private String taxCataName;
    @ApiModelProperty("供应商编码（关联供应商对应关系表）")
    private String supplierCode;
    @ApiModelProperty("需求人所属公司编码")
    private String demandComBm;
    @ApiModelProperty("需求人的用户id")
    private String demandUserId;
    @ApiModelProperty("审核状态（0=待提交，1=待资料审核，2=待新增审核，3=建编码中，4=通过，5=驳回")
    private Integer auditStatus;
    @ApiModelProperty("审核备注")
    private String auditRemark;
    @ApiModelProperty("待资料审核时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime1;
    @ApiModelProperty("待新增审核时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime2;
    @ApiModelProperty("建编码中时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime3;
    @ApiModelProperty("取消时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime cancelTime;

    @Transient
    private String changeMessage;

    /**
     * 自定义比较，返回比较结果
     *
     * @param applyNew
     * @param excludeList 排除比较的列表
     * @Author loine
     * @Date 2026/3/12 11:15
     */
    public String ownCompare(PurchaseScmErpProductCodeApply applyNew, List<String> excludeList) {
        String[] fieldList = new String[]{"supplierBrand", "productType", "skuCode", "referenceCode", "productVoucher", "materialName", "productArea", "unit", "sifsBrand", "sifsPdBcata", "sifsPdScata", "sifsStBcata", "sifsStScata", "sifsProp", "sifsSubversion", "sifsMainProcurement", "sapplerAttribute", "smainSubCat", "taxCataCode", "taxCataName", "supplierCode"};
        String[] nameList = new String[]{"供应商品牌", "产品型号", "订货号", "参考产品编码", "产品凭证", "产品名称", "产地", "单位", "产品属性2-品牌", "产品属性3-产品大类", "产品属性8-商品小类", "产品属性11-统计大类", "产品属性10-统计小类", "产品属性6-产品系列", "产品属性4-产品细分", "产品属性12-主采购组", "产品属性5-供应商属性", "产品属性14-主配套分类", "税务分类编码", "税务分类名称", "供应商编码"};
        if (ArrayUtils.isNotEmpty(fieldList)) {
            StringJoiner sj = new StringJoiner("，");
            for (int i = 0; i < fieldList.length; i++) {
                String field = fieldList[i];
                if (excludeList != null && excludeList.contains(field)) {
                    continue;
                }
                String name = nameList[i];
                Object newValue;
                Object oldValue;
                Field modelField = ReflectUtil.getField(PurchaseScmErpProductCodeApply.class, field);
                oldValue = ReflectUtil.getFieldValue(modelField, this);
                newValue = ReflectUtil.getFieldValue(modelField, applyNew);
                String oldStringValue = oldValue == null ? "-" : StringUtils.trim(String.valueOf(oldValue));
                String newStringValue = newValue == null ? "-" : StringUtils.trim(String.valueOf(newValue));
                if (!newStringValue.equals(oldStringValue)) {
                    sj.add(name + "：" + oldStringValue + " -> " + newStringValue);
                }
            }
            return sj.toString();
        }
        return "";
    }
}
