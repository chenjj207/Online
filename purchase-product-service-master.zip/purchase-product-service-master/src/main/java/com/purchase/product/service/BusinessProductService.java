package com.purchase.product.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.lang.Filter;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.CharsetUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.compress.CompressUtil;
import cn.hutool.extra.compress.extractor.Extractor;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.exceptions.POIException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.CannedAccessControlList;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyun.oss.model.PutObjectResult;
import com.github.pagehelper.PageHelper;
import com.purchase.controller.oss.AliyunOssController;
import com.purchase.exception.ExceptionDictionary;
import com.purchase.model.dto.CommonProductDto;
import com.purchase.product.client.PublicProductFeignClient;
import com.purchase.product.client.PurchaseConfigFeignClient;
import com.purchase.product.conf.CommonOssConf;
import com.purchase.product.conf.OssConf;
import com.purchase.product.dto.BusinessProductListDto;
import com.purchase.product.dto.BusinessRecommendProductListDto;
import com.purchase.product.mapper.PurchaseProductApplyMapper;
import com.purchase.product.mapper.SupplierProductPropertyMapper;
import com.purchase.product.model.PurchaseCataBrandProp;
import com.purchase.product.model.PurchaseProductApply;
import com.purchase.product.model.PurchaseProductApplyBatch;
import com.purchase.product.model.PurchaseRecommendProduct;
import com.purchase.product.vo.BusinessProductListVo;
import com.purchase.product.vo.PurchaseProductApplyVo;
import com.purchase.service.AliyunOssService;
import com.purchase.utils.date.ZydDateUtils;
import com.purchase.utils.oss.AliyunOssUtils;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import lombok.extern.slf4j.Slf4j;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.xml.xpath.XPath;
import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

@Service
@Slf4j
public class BusinessProductService {

    @Resource
    private PurchaseProductApplyMapper purchaseProductApplyMapper;

    @Resource
    private PurchaseProductApplyService purchaseProductApplyService;

    @Resource
    private PublicProductFeignClient publicProductFeignClient;

    @Resource
    private PurchaseCataBrandPropService purchaseCataBrandPropService;

    @Resource
    private PurchaseProductApplyBatchService purchaseProductApplyBatchService;

    @Resource
    private SupplierProductPropertyMapper supplierProductPropertyMapper;

    @Resource
    private OssConf ossConfig;

    public String getOssCorpCodeTwo() {
        String supplierCode = (String) ContextHandler.get("supplierCode");
        return "purchase" + (StringUtils.isEmpty(supplierCode) ? "" : "_" + supplierCode);
    }




    public Page<BusinessProductListVo> search(BusinessProductListDto businessProductListDto) {
        Page<BusinessProductListVo> page = new Page<>();
        page.setPageNum(BeanUtil.isEmpty(businessProductListDto.getPageNum()) ? 1 : businessProductListDto.getPageNum());
        page.setPageSize(BeanUtil.isEmpty(businessProductListDto.getPageSize()) ? 12 : businessProductListDto.getPageSize());
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<BusinessProductListVo> list = purchaseProductlist(businessProductListDto);
        page = new Page<>(list);
        return page;
    }


    //根据状态获取对应的列表
    public List<BusinessProductListVo> purchaseProductlist(BusinessProductListDto businessProductListDto) {
        String supplierId = (String) ContextHandler.get("supplierId");
        return purchaseProductApplyMapper.selectBusinessProductList(businessProductListDto, supplierId);
    }

    public Map<Integer, Integer> count(BusinessProductListDto businessProductListDto) {
        String supplierId = (String) ContextHandler.get("supplierId");
        Map<Integer, Integer> countMap = new HashMap<>();
        for (int i = 0; i < 3; i++) {
            if (i == businessProductListDto.getProductStatus()) {
                countMap.put(i, purchaseProductApplyMapper.count(businessProductListDto, supplierId));
            } else {
                BusinessProductListDto businessProductListDto1 = new BusinessProductListDto();
                businessProductListDto1.setProductStatus(i);
                countMap.put(i, purchaseProductApplyMapper.count(businessProductListDto1, supplierId));
            }
        }
        return countMap;
    }

    public String lead(BusinessProductListDto businessProductListDto) throws IOException, InvalidFormatException {
        String targetUrl;

        // 模板上传oss
        targetUrl = ossConfig.getOssUrl() + exportTemplateToOss(businessProductListDto);
        return targetUrl;
    }

    public String exportTemplateToOss(BusinessProductListDto businessProductListDto) throws InvalidFormatException, IOException {
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
        // 获取当前时间
        Date currentDate = new Date();
        // 设置时间格式
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String targetUrl = "purchase" + ossConfig.getTmp() + "商品明细-" + dateFormat.format(currentDate) + ".xlsx";
        ByteArrayInputStream byteArrayInput = null;
        InputStream inputStream = null;
        Workbook workbook = null;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        List<Map<String, String>> listCataBrandProp = publicProductFeignClient.listCataBrandProp();
        Map<String, Object> model = new HashMap<>();
        model.put("appendix", listCataBrandProp);
        ClassLoader classLoader = BusinessProductService.class.getClassLoader();
        inputStream = classLoader.getResourceAsStream("template/supplierProductLead.xlsx");
        XLSTransformer transformer = new XLSTransformer();
        workbook = transformer.transformXLS(inputStream, model);


        // 定义动态表头字段
        String[] headers = {"*商品ID", "一级类目", "二级类目", "三级类目", "品牌", "系列", "物料名称", "*规格型号", "物料号", "我的编码", "库存", "货期", "面价", "*供货价", "*惠采价", "建议零售价", "重量(g)"};
        int max = 7;
        String supplierId = (String) ContextHandler.get("supplierId");

        if (businessProductListDto.getProductStatus().equals(0)) {
            List<BusinessProductListVo> list = purchaseProductlist(businessProductListDto);
            for (BusinessProductListVo business : list) {
                if (BeanUtil.isNotEmpty(business.getSpecData())) {
                    JSONArray jsonArray = JSONArray.parseArray(business.getSpecData());
                    if (max < jsonArray.size()) {
                        max = jsonArray.size();
                    }
                }
            }
        } else if (businessProductListDto.getProductStatus().equals(1)){
            max = purchaseProductApplyMapper.countBySpec(businessProductListDto, supplierId, "Y");
        }else if (businessProductListDto.getProductStatus().equals(2)){
            max = purchaseProductApplyMapper.countBySpec(businessProductListDto, supplierId, "N");
        }


        Sheet sheet1 = workbook.getSheetAt(0);//获取第一张表格
        Row headerRow = sheet1.createRow(0);
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setFontName("微软雅黑");
        headerFont.setFontHeightInPoints((short) 12);//设置字体大小
        headerFont.setBold(true);//粗体显示
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setAlignment(HorizontalAlignment.CENTER_SELECTION);

        CellStyle headerStyle1 = workbook.createCellStyle();
        Font headerFont1 = workbook.createFont();
        headerFont1.setFontName("微软雅黑");
        headerFont1.setFontHeightInPoints((short) 12);//设置字体大小
        headerFont1.setBold(true);//粗体显示
        headerFont1.setColor(Font.COLOR_RED);

        headerStyle1.cloneStyleFrom(headerStyle);
        headerStyle1.setFont(headerFont1);
        for (int i = 0; i < headers.length; i++) {
            Cell headerCell = headerRow.createCell(i);
            headerCell.setCellValue(headers[i]);
            if (StrUtil.contains(headers[i], '*')) {
                headerCell.setCellStyle(headerStyle1);
            } else {
                headerCell.setCellStyle(headerStyle);
            }
        }
        int length = headers.length;
        for (int i = 1; i <= max; i++) {
            Cell headerCell = headerRow.createCell(length);
            length = length + 1;
            headerCell.setCellValue("规格名" + i);
            headerCell.setCellStyle(headerStyle);

            Cell headerCell1 = headerRow.createCell(length);
            length = length + 1;
            headerCell1.setCellValue("规格值" + i);
            headerCell1.setCellStyle(headerStyle);
        }
        for (int i = 1; i < 6; i++) {
            Cell headerCell = headerRow.createCell(length);
            length = length + 1;
            if (i == 1) {
                headerCell.setCellValue("商品主图" + i);
            } else {
                headerCell.setCellValue("商品图片" + i);
            }
            headerCell.setCellStyle(headerStyle);
        }

        int pageNum = 1;
        int allSize = 0;
        int currentIndex = 0;
        Sheet sheet = workbook.getSheetAt(0);
        while (true){
            PageHelper.startPage(pageNum, 5000);
            List<BusinessProductListVo> list = purchaseProductlist(businessProductListDto);
            if (list.size() > 0) {
                allSize = allSize + list.size();
                int listIndex = 0;
                for (int rowIndex = currentIndex; rowIndex < allSize; rowIndex++) {
                    Row dataRow = sheet.createRow(rowIndex + 1);
                    BusinessProductListVo business = list.get(listIndex);
                    if (BeanUtil.isNotEmpty(business.getApplyId())) {
                        Cell headerCell = dataRow.createCell(0);
                        headerCell.setCellValue(String.valueOf(business.getApplyId()));
                    }
                    Cell headerCell1 = dataRow.createCell(1);
                    headerCell1.setCellValue(business.getFirstLevelCataName());
                    Cell secondLevelCataName = dataRow.createCell(2);
                    secondLevelCataName.setCellValue(business.getSecondLevelCataName());
                    Cell threeLevelCataName = dataRow.createCell(3);
                    threeLevelCataName.setCellValue(business.getThreeLevelCataName());
                    Cell brandName = dataRow.createCell(4);
                    brandName.setCellValue(business.getBrandName());
                    Cell propName = dataRow.createCell(5);
                    propName.setCellValue(business.getPropName());
                    Cell materialName = dataRow.createCell(6);
                    materialName.setCellValue(business.getMaterialName());
                    Cell productType = dataRow.createCell(7);
                    productType.setCellValue(business.getProductType());
                    Cell skuCode = dataRow.createCell(8);
                    skuCode.setCellValue(business.getSkuCode());
                    Cell productCode = dataRow.createCell(9);
                    productCode.setCellValue(business.getProductCode());
                    Cell stock = dataRow.createCell(10);
                    stock.setCellValue(business.getStock() == null ? 0 : business.getStock());
                    Cell deliveryDate = dataRow.createCell(11);
                    deliveryDate.setCellValue(business.getDeliveryDate());
                    Cell price = dataRow.createCell(12);
                    if (BeanUtil.isNotEmpty(business.getPrice())) {
                        price.setCellValue(String.valueOf(business.getPrice()));
                    }
                    Cell supplyPrice = dataRow.createCell(13);
                    if (BeanUtil.isNotEmpty(business.getSupplyPrice())) {
                        supplyPrice.setCellValue(String.valueOf(business.getSupplyPrice()));
                    }
                    Cell purchasePrice = dataRow.createCell(14);
                    if (BeanUtil.isNotEmpty(business.getPurchasePrice())) {
                        purchasePrice.setCellValue(String.valueOf(business.getPurchasePrice()));
                    }
                    Cell suggestPrice = dataRow.createCell(15);
                    if (BeanUtil.isNotEmpty(business.getSuggestPrice())) {
                        suggestPrice.setCellValue(String.valueOf(business.getSuggestPrice()));
                    }
                    Cell weight = dataRow.createCell(16);
                    weight.setCellValue(business.getWeight());
                    if (businessProductListDto.getProductStatus() == 0 && BeanUtil.isNotEmpty(business.getSpecData())) {
                        JSONArray jsonArray = JSONArray.parseArray(business.getSpecData());
                        int size = 17;
                        for (Object json : jsonArray) {
                            JSONObject jsonObject = JSON.parseObject(String.valueOf(json));
                            Cell spec = dataRow.createCell(size);
                            spec.setCellValue(String.valueOf(jsonObject.get("spec")));
                            size = size + 1;
                            Cell specValue = dataRow.createCell(size);
                            specValue.setCellValue(String.valueOf(jsonObject.get("specValue")));
                            size = size + 1;
                        }
                    }
                    if (businessProductListDto.getProductStatus() != 0 && BeanUtil.isNotEmpty(business.getSpecData())) {
                        List<String> specData = Arrays.asList(business.getSpecData().split("@@@@"));
                        int size = 17;
                        for (String data : specData) {
                            List<String> specsList = Arrays.asList(data.split(":"));
                            Cell spec = dataRow.createCell(size);
                            spec.setCellValue(specsList.get(0));
                            size = size + 1;
                            Cell specValue = dataRow.createCell(size);
                            try {
                                specValue.setCellValue(specsList.get(1));
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                            size = size + 1;
                        }
                    }
                    if (BeanUtil.isNotEmpty(business.getPicName())) {
                        int size = 17 + max * 2;
                        List<String> picNameList = Arrays.asList(business.getPicName().split("@"));
                        for (String data : picNameList) {
                            Cell spec = dataRow.createCell(size);
                            spec.setCellValue(data);
                            size = size + 1;
                        }
                    }
                    listIndex ++;
                }
                currentIndex = currentIndex + list.size();
                pageNum ++;
            }else {
                break;
            }
        }

        //将内容写入输出流并把缓存的内容全部发出去
        workbook.write(byteArrayOutputStream);
        byteArrayInput = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());


        PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConfig.getBucketName(),
                targetUrl, byteArrayInput));
        // 设置权限(公开读)
        ossClient.setBucketAcl(ossConfig.getBucketName(), CannedAccessControlList.PublicRead);
        if (result == null) {
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "批量导入模板失败");
        }

        IoUtil.close(inputStream);
        IoUtil.close(byteArrayInput);
        IoUtil.close(workbook);
        IoUtil.close(byteArrayOutputStream);
        ossClient.shutdown();
        return targetUrl;
    }


    @Transactional
    public JsonResult<String> importProductUpdate(MultipartFile multipartFile) throws IOException {
        String supplierDataType = (String) ContextHandler.get("supplierDataType");
        if ("SELF".equalsIgnoreCase(supplierDataType)) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "自营供应商暂不可修改商品！");
        }
        List<String> imgList = new ArrayList<>();
        String excelFileName = multipartFile.getOriginalFilename();
        String applyBatchNo = IDUtils.getUUID19();
        String bathId = IDUtils.getUUID19();

        List<Long> selectApplyNoList = purchaseProductApplyMapper.selectApplyNoList();

        String supplierId = (String) ContextHandler.get("supplierId");
        //获取申请表中 此供应商已有的数据。 此查询数据量多可能有OM问题，由于业务供应商的商品量不多，暂时这样处理
        List<PurchaseProductApply> purchaseProductApplies = purchaseProductApplyMapper.selectInfoBySupplier(supplierId);
        HashMap<String, String> existProductInfoMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(purchaseProductApplies)){
            for (PurchaseProductApply p : purchaseProductApplies) {
                String productInfo = supplierId + "@" + (StringUtils.isEmpty(p.getFirstLevelCataName()) ? "" : p.getFirstLevelCataName())
                        + "@" + (StringUtils.isEmpty(p.getSecondLevelCataName()) ? "" : p.getSecondLevelCataName())
                        + "@" + (StringUtils.isEmpty(p.getThreeLevelCataName()) ? "" : p.getThreeLevelCataName())
                        + "@" + (StringUtils.isEmpty(p.getBrandName()) ? "" : p.getBrandName())
                        + "@" + p.getProductType();
                if(!existProductInfoMap.containsKey(productInfo)){
                    existProductInfoMap.put(productInfo, p.getApplyNo().toString());
                }
            }
        }

        File file = null;
//        String supplierId = "hyi2p140a8Y4JcTUELL111";
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
        // 获取当前时间
        Date currentDate = new Date();
        // 设置时间格式
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String targetUrl = "purchase_" + supplierId + ossConfig.getTmp() + "批量修改商品结果" + dateFormat.format(currentDate) + ".xlsx";
        ExcelReader reader = null;
        List<Map<String, Object>> readAll = new LinkedList<>();
        InputStream getReaderInputStream = null;
        InputStream excelInputStream = null;
        try {
            if (StrUtil.contains(multipartFile.getOriginalFilename(), ".xlsx") || StrUtil.contains(multipartFile.getOriginalFilename(), ".xlx")) {
                excelInputStream = multipartFile.getInputStream();
                getReaderInputStream = multipartFile.getInputStream();
            } else if (StrUtil.contains(multipartFile.getOriginalFilename(), ".zip")) {
                file = new File(zipUnPacker(ossClient, multipartFile, imgList));
                excelInputStream = new FileInputStream(file);
                getReaderInputStream = new FileInputStream(file);
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "请上传xlsx或xls文件");
            }
            try {
                reader = ExcelUtil.getReader(getReaderInputStream);
                readAll = reader.readAll();
            } catch (POIException q) {
                throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " excel数据为空！");
            }
            if (readAll.size() > 500) {
                throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " excel数据超过500行！");
            }
            if (readAll.size() == 0) {
                throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " excel数据为空！");
            }
            String[] header = {"*商品ID", "一级类目", "二级类目", "三级类目", "品牌", "系列", "物料名称", "*规格型号", "物料号", "我的编码", "库存", "货期", "面价", "*惠采价", "建议零售价", "重量(g)"};
            for (String headerText : header) {
                if (!readAll.get(0).containsKey(headerText)) {
                    throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " 请上传正确的excel文件！");
                }
            }
            Map<String, String> mapList = new LinkedHashMap<>();
            List<PurchaseProductApply> purchaseProductApplyVos = new ArrayList<>();
            List<PurchaseProductApply> needInterApplyList = new ArrayList<>();
            List<String> code = new ArrayList<>();
            List<String> productInfoList = new ArrayList<>();
            readAll.forEach(e -> {
                StringBuilder error = new StringBuilder();
                PurchaseProductApply purchaseProductApplyVo = new PurchaseProductApplyVo();
                if (StrUtil.isNotBlank(String.valueOf(e.get("*商品ID"))) && BeanUtil.isNotEmpty(e.get("*商品ID"))) {
                    try {
                        purchaseProductApplyVo.setApplyNo(Long.parseLong(String.valueOf(e.get("*商品ID"))));
                        if (!CollUtil.contains(selectApplyNoList, purchaseProductApplyVo.getApplyNo())) {
                            error.append("商品ID不存在;");
                        }
                    } catch (NumberFormatException e1) {
                        error.append("商品ID错误;");
                    }
                } else {
                    error.append("商品ID不能为空;");
                }
                if (BeanUtil.isNotEmpty(e.get("我的编码")) && !"".equals(e.get("我的编码"))) {
                    purchaseProductApplyVo.setProductCode(String.valueOf(e.get("我的编码")));
                    String pattern = "^[a-zA-Z0-9]+$";
                    if (!Pattern.matches(pattern, String.valueOf(e.get("我的编码")))) {
                        error.append("我的编码格式错误;");
                    }
                    if (code.size() > 0) {
                        if (CollUtil.contains(code, purchaseProductApplyVo.getProductCode())) {
                            error.append("我的编码重复;");
                            code.add(purchaseProductApplyVo.getProductCode());
                        }
                    } else {
                        code.add(purchaseProductApplyVo.getProductCode());
                    }
                }

                int j = e.size() - 15 - 6;
                StringBuilder specList = new StringBuilder("[");
                for (int i = 0; i < j / 2; i++) {
                    int g = i + 1;
                    if (BeanUtil.isNotEmpty(e.get("规格名" + g))) {
                        if (i != 0) {
                            String specData = ",{\"spec\":\"" + e.get("规格名" + g) + "\",\"specValue\":\"" + e.get("规格值" + g) + "\"}";
                            specList.append(specData);
                        } else {
                            String specData = "{\"spec\":\"" + e.get("规格名" + g) + "\",\"specValue\":\"" + e.get("规格值" + g) + "\"}";
                            specList.append(specData);
                        }
                    }
                }
                if (!specList.toString().equals("[")) {
                    specList.append("]");
                    purchaseProductApplyVo.setSpecData(String.valueOf(specList));
                }
                purchaseProductApplyVo.setBatchNo(applyBatchNo);

                purchaseProductApplyVo.setCorpCode(ContextHandler.getCorpCodeWithDefault());
                purchaseProductApplyVo.setAuditStatus(0);
                checkError(e, error, purchaseProductApplyVo, supplierId, imgList, productInfoList, existProductInfoMap);

                CommonProductDto productDto = purchaseProductApplyMapper.getInApplyNo(purchaseProductApplyVo.getApplyNo());
                List<PurchaseProductApply> purchaseProductApply = purchaseProductApplyMapper.selectByApplyAndPendReview(purchaseProductApplyVo.getApplyNo(), 0, supplierId);
                //根据productDto、purchaseProductApply判断新增还是编辑
                if (null != productDto) {
                    purchaseProductApplyVo.setPublicProductId(productDto.getProductId());
                    purchaseProductApplyVo.setApplySource(productDto.getApplySource());
                    Boolean flag = purchaseProductApplyService.hasEdit(purchaseProductApplyVo);
                    if (BooleanUtils.isFalse(flag)) {
                        //有公海，但是修改的信息不需要审核，直接自动审核进入公海
                        purchaseProductApplyService.checkChangeColumnsNeedAudit(purchaseProductApplyVo);
                    } else if (null != purchaseProductApply) {
                        //有公海产品，也有待审核，那就更新待审核
                        purchaseProductApplyVo.setId(purchaseProductApply.get(0).getId());
                        purchaseProductApplyVo.setApplySource(purchaseProductApply.get(0).getApplySource());
                        purchaseProductApplyVos.add(purchaseProductApplyVo);
                    } else {
                        //有公海，并且没有待审核，就增加一条待审核
                        purchaseProductApplyVo.setAuditStatus(0);
                        purchaseProductApplyVo.setAuditType(2);
                        purchaseProductApplyVo.setCreatedBy(supplierId);
                        purchaseProductApplyVo.setCreatedAt(LocalDateTime.now());
                        purchaseProductApplyVo.setIsOnsale("Y");
                        purchaseProductApplyVo.setId(IDUtils.getUUID19());
                        purchaseProductApplyVo.setApplySource("publish");
                        purchaseProductApplyVo.setCorpCode(ContextHandler.getCorpCode());
                        needInterApplyList.add(purchaseProductApplyVo);
                    }
                } else {
                    if (null != purchaseProductApply) {
                        //没有公海，但是存在待审核，则修改数据
                        purchaseProductApplyVo.setId(purchaseProductApply.get(0).getId());
                        purchaseProductApplyVo.setApplySource(purchaseProductApply.get(0).getApplySource());
                        purchaseProductApplyVos.add(purchaseProductApplyVo);
                    } else {
                        //没有公海，但是不存在待审核，则增加数据
                        purchaseProductApplyVo.setAuditStatus(0);
                        purchaseProductApplyVo.setAuditType(2);
                        purchaseProductApplyVo.setId(IDUtils.getUUID19());
                        purchaseProductApplyVo.setCreatedBy(supplierId);
                        purchaseProductApplyVo.setCreatedAt(LocalDateTime.now());
                        purchaseProductApplyVo.setIsOnsale("Y");
                        purchaseProductApplyVo.setApplySource("publish");
                        needInterApplyList.add(purchaseProductApplyVo);
                    }
                }
                if (BeanUtil.isNotEmpty(purchaseProductApplyVo.getProductCode())) {
                    if (!purchaseProductApplyService.checkProductCode(purchaseProductApplyVo.getProductCode(), purchaseProductApplyVo.getId())) {
                        if (!error.toString().contains("商品编码重复;")){
                            error.append("商品编码重复;");
                        }
                    }
                }
                if (error.toString().length() > 0) {
                    mapList.put(String.valueOf(e.get("*商品ID")), String.valueOf(error));
                }
            });
            if (mapList.size() > 0) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                ByteArrayInputStream byteArrayInput = null;
                Workbook workbook = new XSSFWorkbook(excelInputStream);
                Sheet sheet = workbook.getSheetAt(0);
                Row headerRow = sheet.getRow(0);
                Cell headerCell = headerRow.createCell(readAll.get(0).size());
                headerCell.setCellValue("导入结果");
                headerCell.setCellStyle(headerRow.getCell(1).getCellStyle());
                for (int rowIndex = 0; rowIndex < readAll.size(); rowIndex++) {
                    Row dataRow = sheet.getRow(rowIndex + 1);
                    Cell ImportResults = dataRow.createCell(readAll.get(0).size());
                    ImportResults.setCellValue(mapList.get(dataRow.getCell(0).getStringCellValue()));
                }
                workbook.write(byteArrayOutputStream);
                byteArrayInput = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConfig.getBucketName(),
                        targetUrl, byteArrayInput));
                return new JsonResult<String>(false, "-1000", "导入失败，请下载查看错误原因", ossConfig.getOssUrl() + targetUrl);
            } else {
                if (readAll.size() > 1) {
                    interBath(ossClient, excelInputStream, applyBatchNo, bathId, excelFileName, 2);
                } else {
                    interBath(ossClient, excelInputStream, applyBatchNo, bathId, excelFileName, 1);
                }

                if (StrUtil.contains(multipartFile.getOriginalFilename(), ".zip") && BeanUtil.isNotEmpty(file)) {
                    Files.delete(Paths.get(file.getAbsolutePath()));
                }
            }
            if (purchaseProductApplyVos.size() > 0) {
                //要修改的商品申请
                purchaseProductApplyVos.forEach(e -> {
                    //先删除旧关系
                    PurchaseProductApply oldData = purchaseProductApplyService.get(e.getId());
                    purchaseProductApplyService.deleteCataBrandPropData(e.getId(), oldData.getFirstLevelCataName(),
                            oldData.getSecondLevelCataName(), oldData.getThreeLevelCataName(), oldData.getBrandName(), oldData.getPropName());

                    //记录分类、品牌、系列三者关系
                    PurchaseCataBrandProp purchaseCataBrandProp = new PurchaseCataBrandProp();
                    purchaseCataBrandProp.setId(IDUtils.getUUID19());
                    purchaseCataBrandProp.setFirstLevelCataName(e.getFirstLevelCataName());
                    purchaseCataBrandProp.setSecondLevelCataName(e.getSecondLevelCataName());
                    purchaseCataBrandProp.setThreeLevelCataName(e.getThreeLevelCataName());
                    purchaseCataBrandProp.setBrandName(e.getBrandName());
                    purchaseCataBrandProp.setPropName(e.getPropName());
                    purchaseCataBrandPropService.save(purchaseCataBrandProp);

                    purchaseProductApplyMapper.updateByPrimaryKeySelective(e);

                });
                //没有店铺概念，去掉此操作
//                insertOrUpdateProperty(purchaseProductApplyVos);
            }

            if (needInterApplyList.size() > 0) {
                insertOrUpdateProperty(needInterApplyList);
                needInterApplyList.forEach(purchaseProductApplyVo -> {
                    //记录分类、品牌、系列三者关系
                    PurchaseCataBrandProp purchaseCataBrandProp = new PurchaseCataBrandProp();
                    purchaseCataBrandProp.setId(IDUtils.getUUID19());
                    purchaseCataBrandProp.setFirstLevelCataName(purchaseProductApplyVo.getFirstLevelCataName());
                    purchaseCataBrandProp.setSecondLevelCataName(purchaseProductApplyVo.getSecondLevelCataName());
                    purchaseCataBrandProp.setThreeLevelCataName(purchaseProductApplyVo.getThreeLevelCataName());
                    purchaseCataBrandProp.setBrandName(purchaseProductApplyVo.getBrandName());
                    purchaseCataBrandProp.setPropName(purchaseProductApplyVo.getPropName());
                    purchaseCataBrandPropService.save(purchaseCataBrandProp);
                });
                if (purchaseProductApplyVos.size() > 0) {
                    insertOrUpdateProperty(purchaseProductApplyVos);
                }
                purchaseProductApplyMapper.insertBatch(needInterApplyList);
            }

        } catch (IOException e) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "新增失败，错误文件生成失败！");
        }
        return JsonResult.ok("批量更新成功");

    }


    @Transactional
    public JsonResult<String> importProductInter(MultipartFile multipartFile) throws FileNotFoundException {

        String supplierDataType = (String) ContextHandler.get("supplierDataType");
        if ("SELF".equalsIgnoreCase(supplierDataType)) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "自营供应商暂不可添加商品！");
        }

        List<String> imgList = new ArrayList<>();
        String excelFileName = multipartFile.getOriginalFilename();
        String applyBatchNo = IDUtils.getUUID19();
        String bathId = IDUtils.getUUID19();

        String supplierId = (String) ContextHandler.get("supplierId");
        File file = null;

        //获取商品编码集合
        List<String> code = purchaseProductApplyMapper.codeList(supplierId);
        //获取申请表中 此供应商已有的数据。 此查询数据量多可能有OM问题，由于业务供应商的商品量不多，暂时这样处理
        List<PurchaseProductApply> purchaseProductApplies = purchaseProductApplyMapper.selectInfoBySupplier(supplierId);
        HashMap<String, String> existProductInfoMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(purchaseProductApplies)){
            for (PurchaseProductApply p : purchaseProductApplies) {
                String productInfo = supplierId + "@" + (StringUtils.isEmpty(p.getFirstLevelCataName()) ? "" : p.getFirstLevelCataName())
                        + "@" + (StringUtils.isEmpty(p.getSecondLevelCataName()) ? "" : p.getSecondLevelCataName())
                        + "@" + (StringUtils.isEmpty(p.getThreeLevelCataName()) ? "" : p.getThreeLevelCataName())
                        + "@" + (StringUtils.isEmpty(p.getBrandName()) ? "" : p.getBrandName())
                        + "@" + p.getProductType();
                if(!existProductInfoMap.containsKey(productInfo)){
                    existProductInfoMap.put(productInfo, p.getApplyNo().toString());
                }
            }
        }
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
        Date currentDate = new Date();
        // 设置时间格式
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String targetUrl = "purchase_" + supplierId + ossConfig.getTmp() + "批量添加商品结果" + dateFormat.format(currentDate) + ".xlsx";

        ExcelReader reader = null;
        List<Map<String, Object>> readAll = new LinkedList<>();
        InputStream excelInputStream = null;
        InputStream getReaderInputStream = null;
        try {

            if (StrUtil.contains(multipartFile.getOriginalFilename(), ".xlsx") || StrUtil.contains(multipartFile.getOriginalFilename(), ".xlx")) {
                excelInputStream = multipartFile.getInputStream();
                getReaderInputStream = multipartFile.getInputStream();
            } else if (StrUtil.contains(multipartFile.getOriginalFilename(), ".zip")) {
                file = new File(zipUnPacker(ossClient, multipartFile, imgList));
                excelInputStream = new FileInputStream(file);
                getReaderInputStream = new FileInputStream(file);
                excelFileName = file.getName();

            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "请上传xlsx或xls文件");
            }
            try {
                reader = ExcelUtil.getReader(getReaderInputStream, false);
                readAll = reader.readAll();
            } catch (POIException q) {
                throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " excel数据为空！");
            }
        } catch (POIException q) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " excel数据为空！");
        } catch (IOException ex) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " 文件解析失败！");
        }
        try {
            if (readAll.size() > 500) {
                throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " excel数据超过500行！");
            }
            if (readAll.size() == 0) {
                throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " excel数据为空！");
            }
            String[] header = {"一级类目", "二级类目", "三级类目", "品牌", "系列", "物料名称", "*规格型号", "物料号", "我的编码", "库存", "货期", "面价", "*供货价", "*惠采价", "建议零售价", "重量(g)"};
            for (String headerText : header) {
                if (!readAll.get(0).containsKey(headerText)) {
                    throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " 请上传正确的excel文件！");
                }
            }
            if (readAll.get(0).containsKey("*商品ID")) {
                throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " 请上传正确的excel文件！");
            }
            List<String> productInfoList = new ArrayList<>();

            Map<String, String> mapList = new LinkedHashMap<>();
            List<PurchaseProductApply> purchaseProductApplys = new ArrayList<>();
            readAll.forEach(e -> {
                StringBuilder error = new StringBuilder();
                PurchaseProductApply purchaseProductApplyVo = new PurchaseProductApply();
                purchaseProductApplyVo.setApplyNo(purchaseProductApplyService.getMaxApplyNo());
                try {
                    //通用异常处理
                    checkError(e, error, purchaseProductApplyVo, supplierId, imgList, productInfoList, existProductInfoMap);
                    purchaseProductApplyVo.setBatchNo(applyBatchNo);
                    if (BeanUtil.isNotEmpty(e.get("我的编码")) && !"".equals(e.get("我的编码"))) {
                        purchaseProductApplyVo.setProductCode(String.valueOf(e.get("我的编码")));
                        String pattern = "^[a-zA-Z0-9]+$";
                        if (!Pattern.matches(pattern, String.valueOf(e.get("我的编码")))) {
                            error.append("我的编码格式错误;");
                        }
                        if (code.contains(String.valueOf(e.get("我的编码")))) {
                            error.append("我的编码重复;");
                        }
                        code.add(String.valueOf(e.get("我的编码")));
                    }
                    int j = e.size() - 16 - 6;
                    StringBuilder specList = new StringBuilder("[");
                    for (int i = 0; i < j / 2 + 1; i++) {
                        int g = i + 1;
                        if (BeanUtil.isNotEmpty(e.get("规格名" + g))) {
                            if (i != 0) {
                                String specData = ",{\"spec\":\"" + e.get("规格名" + g) + "\",\"specValue\":\"" + e.get("规格值" + g) + "\"}";
                                specList.append(specData);
                            } else {
                                String specData = "{\"spec\":\"" + e.get("规格名" + g) + "\",\"specValue\":\"" + e.get("规格值" + g) + "\"}";
                                specList.append(specData);
                            }
                        }
                    }
                    if (!specList.toString().equals("[")) {
                        specList.append("]");
                        purchaseProductApplyVo.setSpecData(String.valueOf(specList));
                    }
                } catch (ClassCastException e1) {
                    error.append("数据转化异常;");
                }
                if (error.length() > 0) {
                    String key = purchaseProductApplyVo.getFirstLevelCataName() + purchaseProductApplyVo.getSecondLevelCataName() + purchaseProductApplyVo.getThreeLevelCataName() + purchaseProductApplyVo.getBrandName() + purchaseProductApplyVo.getProductType();
                    mapList.put(key, String.valueOf(error));
                }
                purchaseProductApplyVo.setId(IDUtils.getUUID19());
                //新增通用属性（所有产品相同）
                purchaseProductApplyVo.setCreatedBy(supplierId);
                purchaseProductApplyVo.setCreatedAt(LocalDateTime.now());
                purchaseProductApplyVo.setIsOnsale("Y");
                purchaseProductApplyVo.setAuditStatus(0);
                purchaseProductApplyVo.setAuditType(1);
                //导入商品的来源属于发布
                purchaseProductApplyVo.setApplySource("publish");
                purchaseProductApplys.add(purchaseProductApplyVo);
            });
            if (mapList.size() > 0) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                ByteArrayInputStream byteArrayInput = null;
                Workbook workbook = new XSSFWorkbook(excelInputStream);
                Sheet sheet = workbook.getSheetAt(0);
                Row headerRow = sheet.getRow(0);
                Cell headerCell = headerRow.createCell(readAll.get(0).size());
                headerCell.setCellValue("导入结果");
                headerCell.setCellStyle(headerRow.getCell(1).getCellStyle());
                for (int rowIndex = 0; rowIndex < readAll.size(); rowIndex++) {
                    Row dataRow = sheet.getRow(rowIndex + 1);
                    Cell ImportResults = dataRow.createCell(readAll.get(0).size());
                    String key1 = null;
                    try {
                        key1 = dataRow.getCell(0).getStringCellValue();
                        if (!StrUtil.isNotBlank(key1)) {
                            key1 = null;
                        }
                    } catch (NullPointerException ignored) {
                    }
                    String key2 = null;
                    try {
                        key2 = dataRow.getCell(1).getStringCellValue().isEmpty() ? "" : dataRow.getCell(1).getStringCellValue();
                        if (!StrUtil.isNotBlank(key2)) {
                            key2 = null;
                        }
                    } catch (NullPointerException ignored) {

                    }
                    String key3 = null;
                    try {
                        key3 = dataRow.getCell(2).getStringCellValue().isEmpty() ? "" : dataRow.getCell(2).getStringCellValue();
                        if (!StrUtil.isNotBlank(key3)) {
                            key3 = null;
                        }
                    } catch (NullPointerException ignored) {

                    }
                    String key4 = null;
                    try {
                        key4 = dataRow.getCell(3).getStringCellValue().isEmpty() ? "" : dataRow.getCell(3).getStringCellValue();
                        if (!StrUtil.isNotBlank(key4)) {
                            key4 = null;
                        }
                    } catch (NullPointerException ignored) {

                    }
                    String key5 = null;
                    try {
                        key5 = dataRow.getCell(6).getStringCellValue().isEmpty() ? "" : dataRow.getCell(6).getStringCellValue();
                        if (!StrUtil.isNotBlank(key5)) {
                            key5 = null;
                        }
                    } catch (NullPointerException ignored) {

                    }
                    String key = key1 + key2 + key3 + key4 + key5;
                    ImportResults.setCellValue(mapList.get(key));
                }
                workbook.write(byteArrayOutputStream);
                byteArrayInput = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConfig.getBucketName(),
                        targetUrl, byteArrayInput));
                excelInputStream.close();
                if (StrUtil.contains(multipartFile.getOriginalFilename(), ".zip") && BeanUtil.isNotEmpty(file)) {
                    Files.delete(Paths.get(file.getAbsolutePath()));
                }
                return new JsonResult<String>(false, "-1000", "导入失败，请下载查看错误原因", ossConfig.getOssUrl() + targetUrl);
            } else {
                if (readAll.size() > 1) {
                    interBath(ossClient, excelInputStream, applyBatchNo, bathId, excelFileName, 2);
                } else {
                    interBath(ossClient, excelInputStream, applyBatchNo, bathId, excelFileName, 1);
                }

                if (StrUtil.contains(multipartFile.getOriginalFilename(), ".zip") && BeanUtil.isNotEmpty(file)) {
                    Files.delete(Paths.get(file.getAbsolutePath()));
                }

            }
            purchaseProductApplys.forEach(purchaseProductApplyVo -> {
//                //记录分类、品牌、系列三者关系
                PurchaseCataBrandProp purchaseCataBrandProp = new PurchaseCataBrandProp();
                purchaseCataBrandProp.setId(IDUtils.getUUID19());
                purchaseCataBrandProp.setFirstLevelCataName(purchaseProductApplyVo.getFirstLevelCataName());
                purchaseCataBrandProp.setSecondLevelCataName(purchaseProductApplyVo.getSecondLevelCataName());
                purchaseCataBrandProp.setThreeLevelCataName(purchaseProductApplyVo.getThreeLevelCataName());
                purchaseCataBrandProp.setBrandName(purchaseProductApplyVo.getBrandName());
                purchaseCataBrandProp.setPropName(purchaseProductApplyVo.getPropName());
                purchaseCataBrandPropService.save(purchaseCataBrandProp);
            });
            insertOrUpdateProperty(purchaseProductApplys);
            //批量新增
            purchaseProductApplyMapper.insertBatch(purchaseProductApplys);
        } catch (IOException e) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "新增失败，错误文件生成失败！");
        }
        return JsonResult.ok("批量添加成功");
    }

    private void insertOrUpdateProperty(List<PurchaseProductApply> purchaseProductApplys) {
        purchaseProductApplys.forEach(e -> {
            if (BeanUtil.isNotEmpty(e.getStoreCataId())) {
                String propertyId = supplierProductPropertyMapper.selectProperty(e);
                if (BeanUtil.isNotEmpty(propertyId)) {
                    e.setUpdatedBy((String) ContextHandler.get("supplierId"));
                    e.setUpdatedAt(LocalDateTime.now());
                    supplierProductPropertyMapper.updateProperty(propertyId, e);
                } else {
                    e.setCreatedAt(LocalDateTime.now());
                    supplierProductPropertyMapper.insertProperty(e);
                }
            }
        });

    }


    private String zipUnPacker(OSS ossClient, MultipartFile multipartFile, List<String> imgList) {
        String path = null;
        Boolean isProductFile = false;
        try {
            if (multipartFile.getSize() > 300 * 1024 * 1024) {
                throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), " 文件超过300M！");
            }

            List<String> list = new ArrayList<>();
            if (StrUtil.contains(multipartFile.getOriginalFilename(), ".zip")) {

                ZipInputStream zipInputStream = new ZipInputStream(multipartFile.getInputStream(), Charset.forName("GBK"));
                ZipEntry zipEntry;
                while ((zipEntry = zipInputStream.getNextEntry()) != null) {
                    if (!zipEntry.isDirectory()) {
                        String fileName = zipEntry.getName();
                        if (fileName.endsWith(".xlsx") || fileName.endsWith(".xls")) {
                            // 创建字节数组输出流
                            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                            int length;
                            byte[] buffer = new byte[1024];
                            while ((length = zipInputStream.read(buffer)) > 0) {
                                outputStream.write(buffer, 0, length);
                            }
                            File tempFile = null;
                            if (fileName.endsWith(".xlsx")) {
                                tempFile = File.createTempFile(fileName.replace(".xlsx", ""), ".xlsx");
                            } else {
                                tempFile = File.createTempFile(fileName.replace(".xls", ""), ".xls");
                            }

                            FileOutputStream fileOutputStream = new FileOutputStream(tempFile);
                            fileOutputStream.write(outputStream.toByteArray());
                            fileOutputStream.close();
                            path = tempFile.getAbsolutePath();
                        }
                    }
                    if (zipEntry.getName().startsWith("products/") || zipEntry.getName().startsWith("/products/")) {
                        if (zipEntry.getName().equals("products/")) {
                            continue;
                        }

                        imgList.add(zipEntry.getName().replaceFirst("^" + "products/", ""));
                        isProductFile = true;
                        int length;
                        byte[] buffer = new byte[1024];
                        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                        while ((length = zipInputStream.read(buffer)) > 0) {
                            outputStream.write(buffer, 0, length);
                        }
                        // 返回文件夹的字节流
                        File file = new File(System.getProperty("user.dir") + '/' + zipEntry.getName());
                        file.getParentFile().mkdirs();
                        FileOutputStream fileOutputStream = new FileOutputStream(file);
                        fileOutputStream.write(outputStream.toByteArray());

                        String newPath = "purchase_" + ContextHandler.get("supplierId") + ossConfig.getCorpOssPrex() + "products/";
                        PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConfig.getBucketName(), newPath + file.getName(), file));
                        outputStream.close();
                        fileOutputStream.close();
                        Files.delete(Paths.get(System.getProperty("user.dir") + '/' + zipEntry.getName()));

                    }
                    zipInputStream.closeEntry();
                }
                if (!isProductFile) {
                    throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "请上传xlsx或xls文件，products文件夹");
                }
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "文件格式错误，请上传正确文件");
            }
        } catch (FileNotFoundException e) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "文件异常！");
        } catch (IOException e) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "文件解压异常！");
        }
        return path;
    }

    private void checkError(Map<String, Object> e, StringBuilder error, PurchaseProductApply purchaseProductApplyVo,
                            String supplierId, List<String> imgList, List<String> productInfoList,  HashMap<String, String> existProductInfoMap) {
        // 分类名称
        try {
            purchaseProductApplyVo.setCorpCode(ContextHandler.getCorpCodeWithDefault());
//            //店铺分类id https://zentao-gz.zyd.cn/index.php?m=story&f=view&storyID=1756&version=5&param=827#app=execution  去除店铺分类
//            if (StrUtil.isNotBlank(String.valueOf(e.get("店铺二级分类"))) && BeanUtil.isNotEmpty(e.get("店铺二级分类"))) {
//                if (!StrUtil.isNotBlank(String.valueOf(e.get("店铺一级分类"))) || !BeanUtil.isNotEmpty(e.get("店铺一级分类"))) {
//                    error.append("请先维护店铺一级分类;");
//                }
//            }
//            if (StrUtil.isNotBlank(String.valueOf(e.get("店铺一级分类"))) && BeanUtil.isNotEmpty(e.get("店铺一级分类"))) {
//                Integer storeCataId = purchaseConfigFeignClient.cataAdd(String.valueOf(e.get("店铺一级分类")), (e.get("店铺二级分类") == null ? "" : e.get("店铺二级分类").toString()), supplierId, String.valueOf(purchaseProductApplyVo.getApplyNo()));
//                purchaseProductApplyVo.setStoreCataId(storeCataId);
//            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("一级类目"))) && BeanUtil.isNotEmpty(e.get("一级类目"))) {
                purchaseProductApplyVo.setFirstLevelCataName(String.valueOf(e.get("一级类目")));
            } else {
//                error.append("一级类目不能为空;");
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("二级类目"))) && BeanUtil.isNotEmpty(e.get("二级类目"))) {
                purchaseProductApplyVo.setSecondLevelCataName(String.valueOf(e.get("二级类目")));
            } else {
//                error.append("二级类目不能为空;");
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("三级类目"))) && BeanUtil.isNotEmpty(e.get("三级类目"))) {
                purchaseProductApplyVo.setThreeLevelCataName(String.valueOf(e.get("三级类目")));
            } else {
//                error.append("三级类目不能为空;");
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("品牌"))) && BeanUtil.isNotEmpty(e.get("品牌"))) {
                purchaseProductApplyVo.setBrandName(String.valueOf(e.get("品牌")));
            } else {
//                error.append("品牌名称不能为空;");
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("系列"))) && BeanUtil.isNotEmpty(e.get("系列"))) {
                purchaseProductApplyVo.setPropName(String.valueOf(e.get("系列")));
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("物料名称"))) && BeanUtil.isNotEmpty(e.get("物料名称"))) {
                purchaseProductApplyVo.setMaterialName(String.valueOf(e.get("物料名称")));
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("*规格型号"))) && BeanUtil.isNotEmpty(e.get("*规格型号"))) {
                purchaseProductApplyVo.setProductType(String.valueOf(e.get("*规格型号")));
            } else {
                error.append("型号不能为空;");
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("物料号"))) && BeanUtil.isNotEmpty(e.get("物料号"))) {
                purchaseProductApplyVo.setSkuCode(String.valueOf(e.get("物料号")));
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("库存"))) && BeanUtil.isNotEmpty(e.get("库存"))) {
                try {
                    purchaseProductApplyVo.setStock(Integer.valueOf(e.get("库存").toString()));
                    if (purchaseProductApplyVo.getStock() < 0) {
                        error.append("库存仅限为正整数;");
                    }
                } catch (ClassCastException e2) {
                    error.append("库存仅限为正整数;");
                } catch (NumberFormatException e2) {
                    error.append("库存仅限为正整数;");
                }
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("面价"))) && BeanUtil.isNotEmpty(e.get("面价"))) {
                try {
                    purchaseProductApplyVo.setPrice(new BigDecimal(Double.parseDouble(String.valueOf(e.get("面价")))));
                    if (purchaseProductApplyVo.getPrice().compareTo(BigDecimal.ZERO) < 0 || purchaseProductApplyVo.getPrice().compareTo(BigDecimal.ZERO) == 0) {
                        error.append("面价仅限为正数;");
                    }
                } catch (NumberFormatException e2) {
                    error.append("面价仅限为正数;");
                }

            } else {
//                error.append("面价不能为空;");
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("*供货价"))) && BeanUtil.isNotEmpty(e.get("*供货价"))) {
                try {
                    purchaseProductApplyVo.setSupplyPrice(new BigDecimal(Double.parseDouble(String.valueOf(e.get("*供货价")))));
                    if (purchaseProductApplyVo.getSupplyPrice().compareTo(BigDecimal.ZERO) < 0 || purchaseProductApplyVo.getSupplyPrice().compareTo(BigDecimal.ZERO) == 0) {
                        error.append("供货价仅限为正数;");
                    }
                } catch (NumberFormatException e2) {
                    error.append("供货价仅限为正数;");
                }
            } else {
                error.append("供货价不能为空;");
            }
            if (StrUtil.isNotBlank(String.valueOf(e.get("*惠采价"))) && BeanUtil.isNotEmpty(e.get("*惠采价"))) {
                try {
                    purchaseProductApplyVo.setPurchasePrice(new BigDecimal(Double.parseDouble(String.valueOf(e.get("*惠采价")))));
                    if (purchaseProductApplyVo.getPurchasePrice().compareTo(BigDecimal.ZERO) < 0 || purchaseProductApplyVo.getPurchasePrice().compareTo(BigDecimal.ZERO) == 0) {
                        error.append("惠采价仅限为正数;");
                    }
                } catch (NumberFormatException e2) {
                    error.append("惠采价仅限为正数;");
                }
            } else {
                error.append("惠采价不能为空;");
            }

            if (purchaseProductApplyVo.getSupplyPrice() != null && purchaseProductApplyVo.getPurchasePrice() != null){
                if ((purchaseProductApplyVo.getSupplyPrice().multiply(new BigDecimal(1.05)).compareTo(purchaseProductApplyVo.getPurchasePrice())) > 0 ){
                    error.append("商品毛利低于约定毛利率;");
                }
            }

            if (StrUtil.isNotBlank(String.valueOf(e.get("建议零售价"))) && BeanUtil.isNotEmpty(e.get("建议零售价"))) {
                try {
                    purchaseProductApplyVo.setSuggestPrice(new BigDecimal(Double.parseDouble(String.valueOf(e.get("建议零售价")))));
                    if (purchaseProductApplyVo.getSuggestPrice().compareTo(BigDecimal.ZERO) < 0 || purchaseProductApplyVo.getSuggestPrice().compareTo(BigDecimal.ZERO) == 0) {
                        error.append("建议零售价仅限为正数;");
                    }
                } catch (NumberFormatException e2) {
                    error.append("建议零售价仅限为正数;");
                }
            }

            if (StrUtil.isNotBlank(String.valueOf(e.get("货期"))) && BeanUtil.isNotEmpty(e.get("货期"))) {
                purchaseProductApplyVo.setDeliveryDate(String.valueOf(e.get("货期")));
            }

            if (StrUtil.isNotBlank(String.valueOf(e.get("重量(g)"))) && BeanUtil.isNotEmpty(e.get("重量(g)"))) {
                try {
                    purchaseProductApplyVo.setWeight(String.valueOf(Integer.valueOf(String.valueOf(e.get("重量(g)")))));
                    if (Integer.parseInt(purchaseProductApplyVo.getWeight()) < 0 || Integer.parseInt(purchaseProductApplyVo.getWeight()) == 0) {
                        error.append("重量仅限正整数;");
                    }
                } catch (NumberFormatException e2) {
                    error.append("重量仅限正整数;");
                }
            }
            purchaseProductApplyVo.setSupplierId(supplierId);
            purchaseProductApplyVo.setIsSupply("N");

            String ossPre = ossConfig.getOssUrl() + "purchase_" + ContextHandler.get("supplierId") + ossConfig.getCorpOssPrex() + "products/";
            String picName1 = "";
            if (StrUtil.isNotBlank(String.valueOf(e.get("商品主图1"))) && BeanUtil.isNotEmpty(e.get("商品主图1"))) {
                picName1 = String.valueOf(e.get("商品主图1"));
                if (!picName1.startsWith("http")) {
                    //20230731 如果图片路径不包含http
                    if (!CollUtil.contains(imgList, e.get("商品主图1"))) {
                        error.append("主图图片不存在;");
                    }else {
                        picName1 = ossPre + picName1;
                    }
                }
            }else {
                if(CollectionUtils.isNotEmpty(imgList)){
                    error.append("主图图片不存在;");
                }
            }
            String picName2 = "";
            if (e.containsKey("商品图片2") && e.get("商品图片2") != null) {
                picName2 = (String) e.get("商品图片2");
                if (!picName2.startsWith("http")) {
                    picName2 = "@" + ossPre + picName2;
                } else {
                    picName2 = "@" + picName2;
                }
            }
            String picName3 = "";
            if (e.containsKey("商品图片3") && e.get("商品图片3") != null) {
                picName3 = (String) e.get("商品图片3");
                if (!picName3.startsWith("http")) {
                    picName3 = "@" + ossPre + picName3;
                } else {
                    picName3 = "@" + picName3;
                }
            }
            String picName4 = "";
            if (e.containsKey("商品图片4") && e.get("商品图片4") != null) {
                picName4 = (String) e.get("商品图片4");
                if (!picName4.startsWith("http")) {
                    picName4 = "@" + ossPre + picName4;
                } else {
                    picName4 = "@" + picName4;
                }
            }
            String picName5 = "";
            if (e.containsKey("商品图片5") && e.get("商品图片5") != null) {
                picName5 = (String) e.get("商品图片5");
                if (!picName5.startsWith("http")) {
                    picName5 = "@" + ossPre + picName5;
                } else {
                    picName5 = "@" + picName5;
                }
            }
            String picName = picName1 + picName2 + picName3 + picName4 + picName5;
            if (!picName.equals("")) {
                purchaseProductApplyVo.setProductPicName(picName);
            }
            //检查excel是否有重复的数据
            String productInfo = supplierId + "@" + (StringUtils.isEmpty(purchaseProductApplyVo.getFirstLevelCataName()) ? "" : purchaseProductApplyVo.getFirstLevelCataName())
                    + "@" + (StringUtils.isEmpty(purchaseProductApplyVo.getSecondLevelCataName()) ? "" : purchaseProductApplyVo.getSecondLevelCataName())
                    + "@" + (StringUtils.isEmpty(purchaseProductApplyVo.getThreeLevelCataName()) ? "" : purchaseProductApplyVo.getThreeLevelCataName())
                    + "@" + (StringUtils.isEmpty(purchaseProductApplyVo.getBrandName()) ? "" : purchaseProductApplyVo.getBrandName())
                    + "@" + purchaseProductApplyVo.getProductType();
            if (productInfoList.contains(productInfo)){
                error.append("商品重复，请重新维护;");
            }else {
                productInfoList.add(productInfo);
            }
            if (existProductInfoMap.containsKey(productInfo)){
                if (!StringUtils.equals(existProductInfoMap.get(productInfo), purchaseProductApplyVo.getApplyNo().toString())){
                    error.append("商品已存在（商品ID：" + existProductInfoMap.get(productInfo) + "），如要修改请编辑或批量修改商品");
                }
            }

        } catch (ClassCastException e1) {
            e1.printStackTrace();
            error.append("数据转化异常;");
        }
    }

    private void interBath(OSS ossClient, InputStream excelInputStream, String applyBatchNo, String bathId, String excelFileName, Integer type) {
        try {
            String ossPath = getOssCorpCodeTwo() + ossConfig.getProductUpload()
                    + ZydDateUtils.format(ZydDateUtils.ymdhmsfGapless, new Date()) + excelFileName;
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConfig.getBucketName(),
                    ossPath, excelInputStream));
//                    // 设置权限(公开读)
            ossClient.setBucketAcl(ossConfig.getBucketName(), CannedAccessControlList.PublicRead);
            String ossUrl = ossConfig.getOssUrl() + ossPath;
            excelInputStream.close();
            PurchaseProductApplyBatch applyBatch = new PurchaseProductApplyBatch();
            applyBatch.setBatchNo(applyBatchNo);
            applyBatch.setId(bathId);
            applyBatch.setFileUrl(ossUrl);
            applyBatch.setType(type);
            applyBatch.setCorpCode(ContextHandler.getCorpCodeWithDefault());
            applyBatch.setCreatedBy((String) ContextHandler.get("supplierId"));
            applyBatch.setCreatedAt(LocalDateTime.now());
            purchaseProductApplyBatchService.add(applyBatch);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            ossClient.shutdown();
        }
    }
}
