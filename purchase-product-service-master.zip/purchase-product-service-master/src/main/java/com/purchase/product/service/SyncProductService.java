package com.purchase.product.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.purchase.model.PurchaseProductSync;
import com.purchase.product.client.PublicProductFeignClient;
import com.purchase.product.mapper.ZydmallProductSyncMapper;
import com.purchase.product.model.ZydmallProductSync;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 同步zydmall产品
 * @date 2022/9/27  13:23
 */
@Service
public class SyncProductService {

    private Logger logger = LoggerFactory.getLogger(SyncProductService.class);

    @Resource
    ZydmallProductSyncMapper zydmallProductSyncMapper;

    @Resource
    private PublicProductFeignClient publicProductFeignClient;

    public JsonResult syncProduct(String remark, boolean isUpdateCommon){
        while (true) {
            PageHelper.startPage(1, 5000);
            List<ZydmallProductSync> zydmallProductSyncs = new ArrayList<>();
            if (isUpdateCommon){
                zydmallProductSyncs = zydmallProductSyncMapper.selectByNotUpdate();
            }else {
                zydmallProductSyncs = zydmallProductSyncMapper.selectByModiTimeLastDay();
            }
            if (!CollectionUtils.isEmpty(zydmallProductSyncs)){
                List<ZydmallProductSync> zydmallProductSyncs1 = new ArrayList<>();
                for (ZydmallProductSync zydmallProductSync : zydmallProductSyncs) {
                    PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
                    if (StringUtils.isNotBlank(zydmallProductSync.getSpecData())) {
                        try {
                            String[] specs = zydmallProductSync.getSpecData().split("[@]");
                            String[] vals;
                            JSONArray jsonArray = new JSONArray(specs.length);
                            for (String spec : specs) {
                                vals = spec.split("[=]");
                                JSONObject jsonObject = new JSONObject();
                                jsonObject.put("spec", vals[0]);
                                jsonObject.put("specValue", vals[1]);
                                jsonArray.add(jsonObject);
                            }
                            purchaseProductSync.setSpecData(jsonArray.toJSONString());
                        } catch (Exception e) {
                            logger.error(e.getMessage());
                            continue;
                        }
                    }
                    purchaseProductSync.setFirstLevelCataName(zydmallProductSync.getFirstLevelCataName());
                    purchaseProductSync.setSecondLevelCataName(zydmallProductSync.getSecondLevelCataName());
                    purchaseProductSync.setThreeLevelCataName(zydmallProductSync.getThreeLevelCataName());
                    purchaseProductSync.setBrandName(zydmallProductSync.getBrandName());
                    purchaseProductSync.setPropName(zydmallProductSync.getPropName());
                    purchaseProductSync.setProductType(zydmallProductSync.getProductType());
                    purchaseProductSync.setSkuCode(zydmallProductSync.getSkuCode());
                    purchaseProductSync.setProductCode(zydmallProductSync.getProductCode());
                    purchaseProductSync.setErpProductId(Long.valueOf(zydmallProductSync.getErpProductId()));
                    purchaseProductSync.setSupplyPrice(zydmallProductSync.getSupplyPrice());
                    //慧采价格 修改为 面价 https://zentao-gz.zyd.cn/index.php?m=bug&f=view&bugID=11949#app=execution
                    purchaseProductSync.setPurchasePrice(zydmallProductSync.getPrice());
                    purchaseProductSync.setPrice(zydmallProductSync.getPrice());
                    purchaseProductSync.setSuggestPrice(zydmallProductSync.getSuggestPrice());
                    purchaseProductSync.setStock(zydmallProductSync.getStock());
                    purchaseProductSync.setDeliveryDate(zydmallProductSync.getDeliveryDate());
                    purchaseProductSync.setUnit(zydmallProductSync.getUnit());
                    purchaseProductSync.setWeight(zydmallProductSync.getWeight());
                    purchaseProductSync.setProductPicName(zydmallProductSync.getProductPicName());
                    purchaseProductSync.setProductVedioName(zydmallProductSync.getProductVedioName());
                    purchaseProductSync.setIsOnsale(zydmallProductSync.getIsOnsale());
                    purchaseProductSync.setProductContent(zydmallProductSync.getProductContent());
                    purchaseProductSync.setSample(zydmallProductSync.getSample());
                    purchaseProductSync.setProductErpCode(zydmallProductSync.getProductErpCode());
                    purchaseProductSync.setProductSrc("ZYDMALL");
                    purchaseProductSync.setZydmallProductId(zydmallProductSync.getPublicProductId());
                    purchaseProductSync.setUpdatedBy("同步更新");
                    purchaseProductSync.setUpdatedAt(LocalDateTime.now());
                    purchaseProductSync.setRemark(StringUtils.isBlank(remark) ? "定时任务同步更新" : remark);
                    purchaseProductSync.setIfsMainProcurement(zydmallProductSync.getIfsMainProcurement());
                    purchaseProductSync.setIfsStBcata(zydmallProductSync.getIfsStBcata());
                    purchaseProductSync.setIfsStScata(zydmallProductSync.getIfsStScata());
                    purchaseProductSync.setIfsSupplierDistribution(zydmallProductSync.getIfsSupplierDistribution());
                    purchaseProductSync.setIsShowProp(zydmallProductSync.getIsShowProp());
                    // 此接口可优化为批量
                    JsonResult<Long> jsonResult = publicProductFeignClient.purchaseProductSync(purchaseProductSync);
                    if (jsonResult != null && jsonResult.isSuccess()){
                        ZydmallProductSync zydmallProductSync1 = new ZydmallProductSync();
                        zydmallProductSync1.setId(zydmallProductSync.getId());
                        zydmallProductSync1.setIsUpdateCommon("Y");
                        zydmallProductSyncs1.add(zydmallProductSync1);
                    }
                }
                if (!CollectionUtils.isEmpty(zydmallProductSyncs1)){
                    try {
                        zydmallProductSyncMapper.batchUpdateProduct(zydmallProductSyncs1);
                    }catch (Exception e){
                        e.printStackTrace();
                    }finally {
                        continue;
                    }
                }else {
                }
            }else {
                break;
            }
        }
        return JsonResult.ok();
    }
}
