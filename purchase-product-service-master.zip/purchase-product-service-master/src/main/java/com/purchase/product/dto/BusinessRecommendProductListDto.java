package com.purchase.product.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class BusinessRecommendProductListDto {
    @ApiModelProperty("关键字")
    private String key;

    @ApiModelProperty("分页页数")
    private Integer pageNum;

    @ApiModelProperty("分页记录数量")
    private Integer pageSize;

    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;

    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;

    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;

    @ApiModelProperty("商品品牌名称")
    private String brandName;

    @ApiModelProperty("商品系列名称")
    private String propName;
}
