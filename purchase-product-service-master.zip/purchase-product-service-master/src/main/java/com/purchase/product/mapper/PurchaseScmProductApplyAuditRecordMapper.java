package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseScmProductApplyAuditRecord;
import com.purchase.product.model.PurchaseScmProductApplyChangeRecord;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/2/20 9:59
 **/
public interface PurchaseScmProductApplyAuditRecordMapper extends QguBaseMapper<PurchaseScmProductApplyAuditRecord> {

}
