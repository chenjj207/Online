package com.purchase.product.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.purchase.utils.excel.export.ExcelField;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @Author zhangcheng
 * @Description 商品发布审核
 * @Date 2022-08-16
 **/
@Data
@ApiModel("商品发布审核")
@Table(name = "t_pd_purchase_product_apply")
public class PurchaseProductApply extends BaseCorpModel {

    public static final String ID = "id";
    public static final String BATCH_NO = "batchNo";
    public static final String APPLY_NO = "applyNo";
    public static final String FIRST_LEVEL_CATA_NAME = "firstLevelCataName";
    public static final String SECOND_LEVEL_CATA_NAME = "secondLevelCataName";
    public static final String THREE_LEVEL_CATA_NAME = "threeLevelCataName";
    public static final String BRAND_NAME = "brandName";
    public static final String PROP_NAME = "propName";
    public static final String MATERIAL_NAME = "materialName";
    public static final String PRODUCT_TYPE = "productType";
    public static final String SKU_CODE = "skuCode";
    public static final String PRODUCT_CODE = "productCode";
    public static final String PRODUCT_ERP_CODE = "productErpCode";
    public static final String SUPPLY_PRICE = "supplyPrice";
    public static final String PURCHASE_PRICE = "purchasePrice";
    public static final String PRICE = "price";
    public static final String SUGGEST_PRICE = "suggestPrice";
    public static final String STOCK = "stock";
    public static final String DELIVERY_DATE = "deliveryDate";
    public static final String UNIT = "unit";
    public static final String WEIGHT = "weight";
    public static final String IS_ONSALE = "isOnsale";
    public static final String IS_SUPPLY = "isSupply";
    public static final String SUPPLIER_ID = "supplierId";
    public static final String AUDIT_TYPE = "auditType";
    public static final String AUDIT_STATUS = "auditStatus";
    public static final String AUDIT_REMARK = "auditRemark";
    public static final String PUBLIC_PRODUCT_ID = "publicProductId";
    public static final String STORE_CATA_ID = "storeCataId";

    @ApiModelProperty(value = "批次编号")
    private String batchNo;
    @ApiModelProperty(value = "申请编号")
    private Long applyNo;
    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;
    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;
    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;
    @ApiModelProperty("商品品牌名称")
    @ExcelField(title = "品牌",sort = 30)
    private String brandName;
    @ExcelField(title = "系列",sort = 40)
    @ApiModelProperty("商品系列名称")
    private String propName;
    @ExcelField(title = "物料名称",sort = 40)
    @ApiModelProperty("商品物料名称")
    private String materialName;
    @ApiModelProperty("规格json数据")
    private String specData;
    @ApiModelProperty("产品型号")
    @ExcelField(title = "产品型号",sort = 60)
    private String productType;
    @ApiModelProperty("订货号")
    @ExcelField(title = "订货号",sort = 50)
    private String skuCode;
    @ApiModelProperty("商品编号")
    @ExcelField(title = "商品编号",sort = 20)
    private String productCode;
    @ApiModelProperty("erp商品编号")
    private String productErpCode;
    @ApiModelProperty("供货价")
    @ExcelField(title = "供货价",sort = 70)
    private BigDecimal supplyPrice;
    @ApiModelProperty("慧采价")
    @ExcelField(title = "慧采价",sort = 80)
    private BigDecimal purchasePrice;
    @ApiModelProperty("面价（元）")
    @ExcelField(title = "面价",sort = 90)
    private BigDecimal price;
    @ApiModelProperty("建议销售价")
    @ExcelField(title = "建议销售价",sort = 100)
    private BigDecimal suggestPrice;
    @ApiModelProperty("库存")
    @ExcelField(title = "库存",sort = 110)
    private Integer stock;
    @ApiModelProperty("货期")
    @ExcelField(title = "货期",sort = 120)
    private String deliveryDate;
    @ApiModelProperty("计量单位")
    private String unit;
    @ApiModelProperty("重量")
    private String weight;
    @ApiModelProperty("商品图片（多个用@分隔）")
    private String productPicName;
    @ApiModelProperty("视频详情")
    private String productVedioName;
    @ApiModelProperty("商品申请来源 来源： inquiry | publish")
    private String applySource;
    @ApiModelProperty("是否上下架（Y=上架，N=下架）")
    @ExcelField(title = "状态",sort = 10)
    private String isOnsale;
    @ApiModelProperty("商品详情")
    private String productContent;
    @ApiModelProperty("编辑字段")
    private String editColumns;
    @ApiModelProperty("审核类型（1=新增，2=修改）")
    private Integer auditType;
    @ApiModelProperty("审核状态（0=待审核，1=通过，2=不通过）")
    private Integer auditStatus;
    @ApiModelProperty("审核备注")
    private String auditRemark;
    @ApiModelProperty(value = "审核时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime;
    @ApiModelProperty("公海产品id")
    private Long publicProductId;
    @ApiModelProperty("供应商id")
    private String supplierId;
    @ApiModelProperty("是否是供应链（Y：是，N：否）")
    private String isSupply;
    @ApiModelProperty("样本（多个用@分割）")
    private String sample;

    @ApiModelProperty("店铺分类id")
    private Integer storeCataId;

    @Transient
    private String createdByName;

    @Transient
    private String updatedByName;

    @Transient
    private String urlPrefix;
    @Transient
    private String keyword;

    @ApiModelProperty(value = "页码（pageNum=0 并且 pageSize=0 查全部）", allowableValues = "1")
    @Transient
    private Integer pageNum;
    @ApiModelProperty(value = "页大小（pageNum=0 并且 pageSize=0 查全部）", allowableValues = "10")
    @Transient
    private Integer pageSize;

    public Integer getPageNum() {
        return (null != pageNum) ? pageNum : 1;
    }

    public Integer getPageSize() {
        return (null != pageSize) ? pageSize : 10;
    }

    @Transient
    //行号
    private int row;
    //错误信息
    @Transient
    private String error;
    @Transient
    private String specValueStr;
    @Transient
    private String supplyPriceStr;
    @Transient
    private String purchasePriceStr;
    @Transient
    private String priceStr;
    @Transient
    private String suggestPriceStr;
    @Transient
    private String supplierName;
    @Transient
    private String searchFrom;
    /**
     * 是否忽略重复异常
     */
    @Transient
    private boolean ignoreRepeat;
    /**
     * 是否忽略重复异常
     */
    @Transient
    private String userId;
    /**
     * 品牌图
     */
    @Transient
    private String brandUrl;

}

