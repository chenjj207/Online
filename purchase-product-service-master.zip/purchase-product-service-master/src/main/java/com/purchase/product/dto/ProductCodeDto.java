package com.purchase.product.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class ProductCodeDto {
    private List<ProductCodeSubDto> list;

    private String isSupply;

    @Data
    public static class ProductCodeSubDto{
        @ApiModelProperty("产品id")
        private Long productId;
    }

}
