package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseScmErpProductCodeApplyLog;
import com.purchase.product.vo.PurchaseScmErpProductCodeApplyVo;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description:
 * @Author: loine
 * @Date: 2026/3/10 15:21
 */
public interface PurchaseScmErpProductCodeApplyLogMapper extends QguBaseMapper<PurchaseScmErpProductCodeApplyLog> {

    /**
     * 后台-日志列表
     *
     * @param applyNo
     * @Author loine
     * @Date 2026/3/12 14:25
     */
    List<PurchaseScmErpProductCodeApplyVo.ErpLogListVo> adminLogList(@Param("applyNo") String applyNo);
}
