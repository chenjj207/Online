package com.purchase.product.client;

import com.purchase.model.PurchaseProductSync;
import com.purchase.model.dto.CommonProductDto;
import com.purchase.product.dto.CommonProductTaskDto;
import com.purchase.product.dto.PurchaseCommonProductDto;
import com.purchase.product.vo.CommonProductVo;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import feign.hystrix.FallbackFactory;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.*;

/**
 *
 * @author zhangcheng
 */
@FeignClient(value = "purchase-public-product", path = "/publicProductFeign", fallbackFactory = PublicProductFeignClient.PublicProductFeignClientHystrix.class)
public interface PublicProductFeignClient {

    @PostMapping(value = "/public/purchaseProductSync")
    @ApiOperation(value = "产品同步至公海")
    JsonResult<Long> purchaseProductSync(@RequestBody PurchaseProductSync purchaseProductSync);

    @PostMapping(value = "/public/listProductByProductIds")
    @ApiOperation(value = "根据产品id获取产品集合")
    List<CommonProductDto> listProductByProductIds(@RequestBody List<Long> productIds);

    @PostMapping(value = "/public/checkCataAndCode")
    @ApiOperation(value = "校验分类名称与erpCode")
    JsonResult checkCataAndCode(@RequestBody PurchaseProductSync purchaseProductSync);

    @PostMapping(value = "/public/fndExistProductCode")
    @ApiOperation(value = "根据产品code获取产品code集合")
    List<CommonProductDto> fndExistProductCode(List<String> productCodes);

    @GetMapping(value = "/public/listCataBrandProp")
    @ApiOperation(value = "查询三方关系集合")
    List<Map<String, String>> listCataBrandProp();

    @PostMapping(value = "/public/purchaseProductListById")
    @ApiOperation(value = "根据产品id获取产品集合")
    List<PurchaseCommonProductDto>  PurchaseProductListById(@RequestBody List<Long> productIds);

    @PostMapping(value = "/public/purchaseZydmallAdd")
    @ApiOperation(value = "zydmall商品上架列表添加")
    JsonResult purchaseZydmallAdd(@RequestBody List<Long> productIds);

    @PostMapping(value = "/public/purchaseZydmallDelete")
    @ApiOperation(value = "zydmall商品上架列表删除")
    JsonResult purchaseZydmallDelete(@RequestBody List<Long> productIds);

    @PostMapping(value = "/public/purchaseProductList")
    @ApiOperation(value = "慧采列表")
    List<CommonProductVo> purchaseProductList(@RequestBody CommonProductTaskDto dto);

    @Slf4j
    @Component
    class PublicProductFeignClientHystrix implements FallbackFactory<PublicProductFeignClient> {
        @Override
        public PublicProductFeignClient create(Throwable throwable) {
            return new PublicProductFeignClient() {

                @Override
                public JsonResult<Long> purchaseProductSync(PurchaseProductSync purchaseProductSync) {
                    return null;
                }

                @Override
                public List<CommonProductDto> listProductByProductIds(List<Long> productIds) {
                    return Collections.emptyList();
                }

                @Override
                public JsonResult checkCataAndCode(PurchaseProductSync purchaseProductSync) {
                    return null;
                }

                @Override
                public List<CommonProductDto> fndExistProductCode(List<String> productCodes) {
                    return null;
                }

                @Override
                public List<Map<String, String>> listCataBrandProp() {
                    return null;
                }

                @Override
                public List<PurchaseCommonProductDto> PurchaseProductListById(List<Long> productIds) {
                    return null;
                }

                @Override
                public JsonResult purchaseZydmallAdd(List<Long> productIds) {
                    return null;
                }

                @Override
                public JsonResult purchaseZydmallDelete(List<Long> productIds) {
                    return null;
                }

                @Override
                public List<CommonProductVo> purchaseProductList(CommonProductTaskDto dto) {
                    return null;
                }


            };
        }
    }

}
