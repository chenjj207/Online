package com.purchase.product.mapper;

import com.alibaba.fastjson.JSONObject;
import com.purchase.model.dto.CommonProductDto;
import com.purchase.product.dto.BusinessProductListDto;
import com.purchase.product.dto.BusinessRecommendProductListDto;
import com.purchase.product.dto.PurchaseCommonProductDto;
import com.purchase.product.model.PurchaseProductApply;
import com.purchase.product.model.PurchaseRecommendProduct;
import com.purchase.product.model.PurchaseStore;
import com.purchase.product.vo.BusinessProductListVo;
import com.purchase.product.vo.PurchaseProductApplyVo;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author zhangcheng
 * @version 1.0
 * @since 2022-08-10
 */
public interface PurchaseProductApplyMapper extends QguBaseMapper<PurchaseProductApply> {


    List<PurchaseProductApply> getByProductApplyCodeList(@Param("applyList") List<PurchaseProductApply> applyList);

    int updateList(@Param("item") List<PurchaseProductApply> updateApplyList, @Param("corpCode") String corpCode);

    List<String> fndExistProductCode(@Param("productCodes") List<String> productCodes);

    int updateStockByProductCode(@Param("stock") Integer stock, @Param("productCode") String productCode, @Param("corpCode") String corpCode);

    Long getMaxApplyNo();

    Long countByStatus(@Param("con") PurchaseProductApply apply);

    List<PurchaseProductApply> selectByCon(@Param("con") PurchaseProductApply apply);

    PurchaseProductApplyVo getId(@Param("id") String id);

    String selectBrandUrl(@Param("brandName") String brandName);

    List<BusinessProductListVo> selectBusinessProductList(@Param("dto")BusinessProductListDto businessProductListDto , @Param("supplierId")String supplierId);

    List<String> selectSpecl(@Param("item") List<String> id);

    List<JSONObject> storeCata(@Param("supplierId")String supplierId);

    void insertBatch(@Param("list")List<PurchaseProductApply> purchaseProductApplys);

    CommonProductDto getInApplyNo(@Param("applyNo")Long applyNo);

    List<PurchaseProductApply> selectByApplyAndPendReview(@Param("applyNo")Long applyNo,@Param("status") Integer status,@Param("supplierId") String supplierId);

    PurchaseCommonProductDto selectStoreCataName(@Param("id") Integer storeCataId);

    Integer count(@Param("dto") BusinessProductListDto businessProductListDto,@Param("supplierId")String supplierId);

    Integer countBySpec(@Param("dto") BusinessProductListDto businessProductListDto,@Param("supplierId")String supplierId, @Param("isOnsale")String isOnsale);

    String selectSpecData(@Param("id")String id);

    List<String> codeList(@Param("supplierId")String supplierId);

    List<Long> selectApplyNoList();

    List<PurchaseProductApply> selectInfoBySupplier(@Param("supplierId")String supplierId);

    PurchaseStore selectBySupplier(@Param("supplierId")String supplierId);
}
