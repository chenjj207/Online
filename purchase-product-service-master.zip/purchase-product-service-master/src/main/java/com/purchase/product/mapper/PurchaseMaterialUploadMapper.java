package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseMaterialUpload;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author auto
 * @version 1.0
 * @since 2021-09-01 17:11:06
 */
public interface PurchaseMaterialUploadMapper extends QguBaseMapper<PurchaseMaterialUpload> {
    
    /**
     * 根据实体字段条件获取对应实体集合--分页公用（分页由PageHelper实现-解耦合）
     *
     * @param tenantMaterialUpload 实体对象
     * @return 对象集合
     */
    List<PurchaseMaterialUpload> search(@Param("con") PurchaseMaterialUpload tenantMaterialUpload);
}
