package com.purchase.product.job;

import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.spring.boot.annotation.JobRunner4TaskTracker;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.github.ltsopensource.tasktracker.runner.JobRunner;
import com.purchase.product.service.PurchaseScmErpProductCodeApplyService;
import com.purchase.product.service.SyncProductService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.helpers.MessageFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/2/2  14:27
 */
@Slf4j
@Component
@JobRunner4TaskTracker
public class SyncJob implements JobRunner {

    @Autowired
    private SyncProductService syncProductService;
    @Autowired
    private PurchaseScmErpProductCodeApplyService purchaseScmErpProductCodeApplyService;

    /**
     * 执行任务
     * 抛出异常则消费失败, 返回null则认为是消费成功
     *
     * @param jobContext
     */
    @Override
    public Result run(JobContext jobContext) throws Throwable {
        String type = jobContext.getJob().getParam("type");
        log.error("商品ERP编码申请业务任务执行开始，当前执行任务为：" + type);
        String isUpdateCommon = jobContext.getJob().getParam("isUpdateCommon");
        switch (type) {
            case "SYNC_ZYDMALL_PRODUCT":
                syncProductService.syncProduct("lts同步", Boolean.valueOf(isUpdateCommon));
                return new Result(Action.EXECUTE_SUCCESS, "同步zydmall产品成功");
            case "SYNC_IFS_ERP_CODE_TO_ERPAPPLY":
                purchaseScmErpProductCodeApplyService.syncIfsErpCodeToErpApply();
                return new Result(Action.EXECUTE_SUCCESS, "同步IFS的ERP编码到ERP产品编码申请表成功");
            case "SYNC_IFS_PRODUCT_TO_ERPAPPLY":
                purchaseScmErpProductCodeApplyService.syncIfsProductToErpApply();
                return new Result(Action.EXECUTE_SUCCESS, "同步IFS产品到ERP产品编码申请表成功");
            default:
                return new Result(Action.EXECUTE_EXCEPTION, MessageFormatter.format("非法执行命令: {}", type).getMessage());
        }
    }
}
