package com.purchase.product.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.purchase.product.dto.oss.LevelNameDto;
import com.purchase.product.mapper.PurchaseCataBrandPropMapper;
import com.purchase.product.model.PurchaseCataBrandProp;
import com.purchase.product.model.PurchaseProductApply;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by wangKang
 * Date :2022/8/16
 * Version :1.0
 */
@Service
@Slf4j
public class PurchaseCataBrandPropService extends BaseServiceImpl<PurchaseCataBrandProp> {
    @Resource
    private PurchaseCataBrandPropMapper purchaseCataBrandPropMapper;

    /**
     * 品牌接口
     * @param brandName
     * @return
     */
    public List<LevelNameDto> listBrand(String firstLevelCataName,
                                        String secondLevelCataName,
                                        String threeLevelCataName,
                                        String brandName,
                                        String isAudit,
                                        Integer tab) {
        List<LevelNameDto> levelNameDtos = new ArrayList<>();
        String supplierId  = (String) ContextHandler.get("supplierId");
        List<PurchaseCataBrandProp> purchaseCataBrandProps = purchaseCataBrandPropMapper.listBrand(firstLevelCataName,
                secondLevelCataName, threeLevelCataName, brandName, supplierId, isAudit,tab);
        if (CollectionUtils.isNotEmpty(purchaseCataBrandProps)) {
            for (PurchaseCataBrandProp purchaseCataBrandProp:purchaseCataBrandProps) {
                if (purchaseCataBrandProp == null){
                    continue;
                }
                LevelNameDto levelNameDto = new LevelNameDto();
                levelNameDto.setName(purchaseCataBrandProp.getBrandName());
                levelNameDto.setType("brand");
                levelNameDtos.add(levelNameDto);
            }
        }
        return levelNameDtos;
    }

    /**
     * 系列接口
     * @param brandName
     * @param propName
     * @return
     */
    public List<LevelNameDto> listProp(String firstLevelCataName,
                                       String secondLevelCataName,
                                       String threeLevelCataName,
                                       String brandName,
                                       String propName,
                                       String isAudit,
                                       Integer tab) {
        List<LevelNameDto> levelNameDtos = new ArrayList<>();
        String supplierId  = (String) ContextHandler.get("supplierId");
        List<PurchaseCataBrandProp> purchaseCataBrandProps = purchaseCataBrandPropMapper.listProp(firstLevelCataName,
                secondLevelCataName, threeLevelCataName, brandName, propName, supplierId, isAudit,tab);
        if (CollectionUtils.isNotEmpty(purchaseCataBrandProps)) {
            Boolean flag = false;
            for (PurchaseCataBrandProp purchaseCataBrandProp:purchaseCataBrandProps) {
                if (purchaseCataBrandProp == null || StringUtils.isEmpty(purchaseCataBrandProp.getPropName())) {
                    flag = true;
                    continue;
                }

                LevelNameDto levelNameDto = new LevelNameDto();
                levelNameDto.setName(purchaseCataBrandProp.getPropName());
                levelNameDto.setType("prop");
                levelNameDtos.add(levelNameDto);
            }
            if (flag) {
                LevelNameDto levelNameDto = new LevelNameDto();
                levelNameDto.setName("暂无数据");
                levelNameDto.setType("prop");
                levelNameDtos.add(0, levelNameDto);
            }
        }
        return levelNameDtos;
    }

    /**
     * 分类树接口
     * @return
     */
    public List<LevelNameDto> getTree(String isAudit ,Integer tab) {
        List<LevelNameDto> levelNameDtos = new ArrayList<>();
        String supplierId  = (String) ContextHandler.get("supplierId");
        String type = (String) ContextHandler.get("supplierDataType");
        List<PurchaseCataBrandProp> purchaseCataBrandProps = purchaseCataBrandPropMapper.listCataData(supplierId, isAudit,tab);
        if (CollectionUtils.isNotEmpty(purchaseCataBrandProps)) {
            Map<String,Set<String>> firstLevelMap = new HashMap<>();
            Map<String,Set<String>> secondLevelMap = new HashMap<>();
            for (PurchaseCataBrandProp purchaseCataBrandProp:purchaseCataBrandProps) {
                if (purchaseCataBrandProp == null){
                    continue;
                }
                String firstLevelName = purchaseCataBrandProp.getFirstLevelCataName();
                String secondLevelName = purchaseCataBrandProp.getSecondLevelCataName();
                String thirdLevelName = purchaseCataBrandProp.getThreeLevelCataName();
                Set<String> secondLevelNameSet = firstLevelMap.get(firstLevelName);
                if (CollectionUtils.isEmpty(secondLevelNameSet)) {
                    secondLevelNameSet = new HashSet<>(1);

                }
                secondLevelNameSet.add(secondLevelName);
                firstLevelMap.put(firstLevelName, secondLevelNameSet);
                Set<String> thirdLevelNameSet = secondLevelMap.get(secondLevelName);
                if (CollectionUtils.isEmpty(thirdLevelNameSet)) {
                    thirdLevelNameSet = new HashSet<>(1);
                }
                thirdLevelNameSet.add(thirdLevelName);
                secondLevelMap.put(secondLevelName, thirdLevelNameSet);
            }
            // 封装集合树
            for (Map.Entry<String, Set<String>> entry : firstLevelMap.entrySet()) {
                LevelNameDto levelNameDto = new LevelNameDto();
                levelNameDto.setName(entry.getKey());
                levelNameDto.setType("catalog");
                levelNameDto.setLevel("1");
                Set<String> secondSet = entry.getValue();
                if (CollectionUtils.isNotEmpty(secondSet)) {
                    List<LevelNameDto> children = new ArrayList<>(secondSet.size());
                    for (String cataName:secondSet) {
                        LevelNameDto secondCata = new LevelNameDto();
                        secondCata.setName(cataName);
                        secondCata.setType("catalog");
                        secondCata.setLevel("2");
                        Set<String> thirdLevelNameSet = secondLevelMap.get(cataName);
                        if (CollectionUtils.isNotEmpty(thirdLevelNameSet)) {
                            List<LevelNameDto> thildCataList = new ArrayList<>(thirdLevelNameSet.size());
                            for (String thirdCataName:thirdLevelNameSet) {
                                LevelNameDto thirdCata = new LevelNameDto();
                                thirdCata.setName(thirdCataName);
                                thirdCata.setType("catalog");
                                thirdCata.setLevel("3");
                                thildCataList.add(thirdCata);
                            }
                            secondCata.setChildren(thildCataList);
                        }
                        children.add(secondCata);
                    }
                    levelNameDto.setChildren(children);
                }
                levelNameDtos.add(levelNameDto);
            }
        }
        return levelNameDtos;
    }

    public void save(PurchaseCataBrandProp purchaseCataBrandProp) {
        if (null != purchaseCataBrandProp) {
            Example example = new Example(entityClass);
            Example.Criteria criteria = example.createCriteria();
            String supplierId  = (String) ContextHandler.get("supplierId");
            if (StringUtils.isNotEmpty(supplierId)) {
                purchaseCataBrandProp.setIsSupply("N");
                purchaseCataBrandProp.setSupplierId(supplierId);
                criteria.andEqualTo(PurchaseCataBrandProp.IS_SUPPLY, "N");
                criteria.andEqualTo(PurchaseCataBrandProp.SUPPLIER_ID, supplierId);
            } else {
                purchaseCataBrandProp.setIsSupply("Y");
                criteria.andEqualTo(PurchaseCataBrandProp.IS_SUPPLY, "Y");
            }
            if (StringUtils.isNotEmpty(purchaseCataBrandProp.getFirstLevelCataName())) {
                criteria.andEqualTo(PurchaseCataBrandProp.FIRST_LEVEL_CATA_NAME, purchaseCataBrandProp.getFirstLevelCataName());
            }
            if (StringUtils.isNotEmpty(purchaseCataBrandProp.getSecondLevelCataName())) {
                criteria.andEqualTo(PurchaseCataBrandProp.SECOND_LEVEL_CATA_NAME, purchaseCataBrandProp.getSecondLevelCataName());
            }
            if (StringUtils.isNotEmpty(purchaseCataBrandProp.getThreeLevelCataName())) {
                criteria.andEqualTo(PurchaseCataBrandProp.THREE_LEVEL_CATA_NAME, purchaseCataBrandProp.getThreeLevelCataName());
            }
            if (StringUtils.isNotEmpty(purchaseCataBrandProp.getBrandName())) {
                criteria.andEqualTo(PurchaseCataBrandProp.BRAND_NAME, purchaseCataBrandProp.getBrandName());
            }
            if (StringUtils.isNotEmpty(purchaseCataBrandProp.getPropName())) {
                criteria.andEqualTo(PurchaseCataBrandProp.PROP_NAME, purchaseCataBrandProp.getPropName());
            }
            List<PurchaseCataBrandProp> list = purchaseCataBrandPropMapper.selectByExample(example);
            if (CollectionUtils.isEmpty(list)) {
                insert(purchaseCataBrandProp);
            }
        }
    }

    public void deleteData(String firstLevelCataName,
                           String secondLevelCataName,
                           String threeLevelCataName,
                           String brandName,
                           String propName,
                           String supplierId) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotEmpty(supplierId)) {
            criteria.andEqualTo(PurchaseCataBrandProp.IS_SUPPLY, "N");
            criteria.andEqualTo(PurchaseCataBrandProp.SUPPLIER_ID, supplierId);
        } else {
            criteria.andEqualTo(PurchaseCataBrandProp.IS_SUPPLY, "Y");
        }
        criteria.andEqualTo(PurchaseCataBrandProp.FIRST_LEVEL_CATA_NAME, firstLevelCataName);
        criteria.andEqualTo(PurchaseCataBrandProp.SECOND_LEVEL_CATA_NAME, secondLevelCataName);
        criteria.andEqualTo(PurchaseCataBrandProp.THREE_LEVEL_CATA_NAME, threeLevelCataName);
        criteria.andEqualTo(PurchaseCataBrandProp.BRAND_NAME, brandName);
        if (StringUtils.isNotEmpty(propName)) {
            criteria.andEqualTo(PurchaseProductApply.PROP_NAME, propName);
        } else {
            Example.Criteria criteria1 = example.createCriteria();
            criteria1.andEqualTo(PurchaseProductApply.PROP_NAME, "");
            criteria1.orIsNull(PurchaseProductApply.PROP_NAME);
            example.and(criteria1);
        }
        purchaseCataBrandPropMapper.deleteByExample(example);
    }
}
