package com.purchase.product.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;

/**
 * @Author jdl
 * @Description 商城首页管理
 * @Date 2024-07-01
 **/
@Data
@ApiModel("商品发布审核")
@Table(name = "t_pd_purchase_home_page")
public class PurchaseHomePage extends BaseCorpModel {

    @ApiModelProperty(value = "楼层类型 1：辅材辅料 2：五金工具 3：安防劳保")
    private String floorType;
    @ApiModelProperty("位置")
    private String position;
    @ApiModelProperty("类型")
    private String type;
    @ApiModelProperty("明细内容")
    private String detailContent;
    @ApiModelProperty("跳转地址")
    private String jumpAddress;
    @ApiModelProperty("全局排序")
    private int sort;
    @ApiModelProperty("备注")
    private String remark;


    @ApiModelProperty(value = "产品id")
    @Transient
    private Long productId;
    @ApiModelProperty(value = "品牌名称")
    @Transient
    private String brandName;
    @ApiModelProperty(value = "系列名称")
    @Transient
    private String propName;
    @ApiModelProperty(value = "分类名称")
    @Transient
    private String cataName;
    @ApiModelProperty(value = "三级分类名称")
    @Transient
    private String threeCataName;
    @ApiModelProperty(value = "价格")
    @Transient
    private BigDecimal price;
    @ApiModelProperty(value = "惠采价格")
    @Transient
    private BigDecimal purchasePrice;
    @ApiModelProperty(value = "产品型号")
    @Transient
    private String productType;
    @ApiModelProperty(value = "订货号")
    @Transient
    private String skuCode;
    @ApiModelProperty(value = "产品图url")
    @Transient
    private String productImgUrl;
    @ApiModelProperty(value = "品牌图url")
    @Transient
    private String brandImgUrl;
    @ApiModelProperty(value = "产品图名称")
    @Transient
    private String productPicName;



}

