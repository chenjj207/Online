package com.purchase.product.controller.oss;

import com.purchase.product.dto.oss.OssResourceDto;
import com.purchase.product.dto.oss.OssResourceRequestDto;
import com.purchase.product.service.OssMaterialService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

/**
 * OssMaterialController 服务提供类
 *
 * @author zhangcheng
 * @version 1.0
 * @since 2022-08-10
 */
@RestController
@RequestMapping(value = "/admin/oss")
@Api(value = "OssMaterialController" , tags = {"后台管理-素材管理"})
public class OssMaterialController {

    @Autowired
    private OssMaterialService ossMaterialService;


    @PostMapping(value = "/getResource")
    @ApiOperation(value = "获取oss目录下的资源数据")
    public JsonResult<OssResourceDto> getResource(@RequestBody OssResourceRequestDto dto) {
        return new JsonResult<>(true, "", ossMaterialService.getResource(dto.getPath(), dto.getNextContinuationToken(), dto.getPrefix(), dto.getMaxKeys()));
    }

    @GetMapping(value = "/reNameResource")
    @ApiOperation(value = "重命名文件/文件夹")
    public JsonResult reNameResource(@RequestParam(required = false,value = "path") @ApiParam("路径") String path
            ,@RequestParam(required = false,value = "newFileName") @ApiParam("新文件名") String newFileName) {
        return ossMaterialService.reNameResource(path,newFileName);
    }

    @GetMapping(value = "/createResource")
    @ApiOperation(value = "创建文件夹")
    public JsonResult createResource(@RequestParam(required = false,value = "fileName") @ApiParam("文件夹名") String fileName) {
        return ossMaterialService.createResource(fileName);
    }

    @GetMapping(value = "/deleteResource")
    @ApiOperation(value = "删除文件/文件夹")
    public JsonResult deleteResource(@RequestParam(required = false,value = "path") @ApiParam("路径") String path) {
        return ossMaterialService.deleteResource(path);
    }

//    @GetMapping(value = "/getResourceUrl")
//    @ApiOperation(value = "获取文件链接")
//    public JsonResult<String> getResourceUrl(@RequestParam(required = false,value = "path") @ApiParam("路径") String path) {
//        return new JsonResult<>(true,"",ossMaterialService.getResourceUrl(path));
//    }

    @PostMapping(value = "/uploadResource")
    @ApiOperation(value = "上传文件(同步上传oss)")
    public JsonResult uploadResource(@RequestParam(required = false,value = "path") @ApiParam("路径") String path,
                                     @RequestParam(required = false,value = "files") @ApiParam("多个文件，需要控制最多10个")  MultipartFile[] files) {
        return ossMaterialService.uploadResource(path,files);
    }

    @GetMapping(value = "/download")
    @ApiOperation(value = "下载文件")
    public JsonResult download(@RequestParam(required = false,value = "path") @ApiParam("路径") String path,
                                     HttpServletResponse response) {
        return ossMaterialService.download(path,response);
    }

    @PostMapping(value = "/scmUploadResource")
    @ApiOperation(value = "SCM上传文件(同步上传oss)")
    public JsonResult scmUploadResource(@RequestParam(required = false, value = "path") @ApiParam("路径") String path, @RequestParam(required = false, value = "files") @ApiParam("多个文件，需要控制最多10个") MultipartFile[] files) {
        return ossMaterialService.scmUploadResource(path, files);
    }

}
