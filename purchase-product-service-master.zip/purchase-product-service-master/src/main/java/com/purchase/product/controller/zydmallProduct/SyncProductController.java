package com.purchase.product.controller.zydmallProduct;

import com.purchase.product.service.SyncProductService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author jidonglin
 * @Description: zydmall 商品同步接口
 * @date 2022/9/27  9:53
 */
@RestController
@RequestMapping(value = "/sync")
@Api(value = "SyncProductController" , tags = {"SyncProductController 服务提供类"})
public class SyncProductController {

    @Autowired
    SyncProductService syncProductService;

    @RequestMapping(value = "/zydmall/product")
    public JsonResult<Boolean> syncZydmallProduct(@RequestParam(value = "remark", required = false) String remark,
                                                  @RequestParam(value = "isUpdateCommon", required = false) boolean isUpdateCommon){
        return syncProductService.syncProduct(remark, isUpdateCommon);
    }
}
