package com.purchase.product.controller;

import com.purchase.product.dto.PurchaseScmProductApplyDto;
import com.purchase.product.service.PurchaseScmProductApplyService;
import com.purchase.product.vo.PurchaseScmProductApplyVo;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * @Description: 慧采SCM产品申请服务提供类
 * @Author: loine
 * @Date: 2024/10/14 15:16
 **/
@RestController
@RequestMapping(value = "/purchaseScmProductApply")
@Api(value = "PurchaseScmProductApplyController", tags = {"慧采SCM产品申请服务提供类"})
@Slf4j
public class PurchaseScmProductApplyController {

    @Resource
    private PurchaseScmProductApplyService purchaseScmProductApplyService;

    @PostMapping(value = "/supplier/search")
    @ApiOperation(value = "供应商-搜索")
    public JsonResult<Page<PurchaseScmProductApplyVo.SupplierSearchVo>> supplierSearch(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierSearchDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.supplierSearch(dto));
    }

    @PostMapping(value = "/supplier/count")
    @ApiOperation(value = "供应商-搜索角标")
    public JsonResult<PurchaseScmProductApplyVo.SearchCountVo> supplierSearchCount(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierSearchDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.supplierSearchCount(dto));
    }

    @PostMapping(value = "/supplier/detail")
    @ApiOperation(value = "供应商-详情")
    public JsonResult<PurchaseScmProductApplyVo.SupplierDetailVo> supplierDetail(@Valid @RequestBody PurchaseScmProductApplyDto.BaseDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.supplierDetail(dto.getId()));
    }

    @PostMapping(value = "/supplier/randomDetail")
    @ApiOperation(value = "供应商-随机商品详情")
    public JsonResult<PurchaseScmProductApplyVo.SupplierRandomDetailVo> supplierRandomDetail(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierRandomDetailDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.supplierRandomDetail(dto));
    }

    @PostMapping(value = "/supplier/selectDelivery")
    @ApiOperation(value = "供应商-选择货期")
    public JsonResult<PurchaseScmProductApplyVo.SupplierSelectDeliveryVo> supplierSelectDelivery() {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.supplierSelectDelivery());
    }

    @PostMapping(value = "/supplier/checkIsApply")
    @ApiOperation(value = "供应商-校验是否已经申请过")
    public JsonResult supplierCheckIsApply(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierCheckIsApplyDto dto){
        return purchaseScmProductApplyService.supplierCheckIsApply(dto);
    }

    @PostMapping(value = "/supplier/downloadImportTemplate")
    @ApiOperation(value = "供应商-下载导入模板/导出数据")
    public void supplierDownloadImportTemplate(HttpServletRequest request, HttpServletResponse response, @Valid @RequestBody PurchaseScmProductApplyDto.SupplierDownloadImportTemplateDto dto){
        purchaseScmProductApplyService.supplierDownloadImportTemplate(request, response, dto);
    }

    @PostMapping(value = "/supplier/readImportTemplate")
    @ApiOperation(value = "供应商-读取导入数据")
    public JsonResult<List<Map<String, String>>> supplierReadImportTemplate(@RequestParam("file") @ApiParam("上传文件") MultipartFile file, @RequestParam("type") @ApiParam("类型（1=新增，2=修改）") String type, @RequestParam("specNames") @ApiParam("规格名数组") List<String> specNames,
                                                                            @RequestParam("firstLevelCataName") String firstLevelCataName, @RequestParam("secondLevelCataName") String secondLevelCataName, @RequestParam("threeLevelCataName") String threeLevelCataName) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.supplierReadImportTemplate(file, type, specNames, firstLevelCataName, secondLevelCataName, threeLevelCataName));
    }

    @PostMapping(value = "/supplier/sameSearch")
    @ApiOperation(value = "供应商-相同型号搜索")
    public JsonResult<Page<PurchaseScmProductApplyVo.SupplierSameSearchVo>> supplierSameSearch(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierSameSearchDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.supplierSameSearch(dto));
    }

    @PostMapping(value = "/supplier/sameSelector")
    @ApiOperation(value = "供应商-相同型号搜索选择器")
    public JsonResult<PurchaseScmProductApplyVo.SupplierSameSelectorVo> supplierSameSelector(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierSameSearchDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.supplierSameSelector(dto));
    }

    @PostMapping(value = "/supplier/cancel")
    @ApiOperation(value = "供应商-批量撤销")
    public JsonResult supplierCancel(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierCancelDto dto){
        return purchaseScmProductApplyService.supplierCancel(dto);
    }

    @PostMapping(value = "/supplier/delete")
    @ApiOperation(value = "供应商-批量删除")
    public JsonResult supplierDelete(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierSearchDto dto){
        return purchaseScmProductApplyService.supplierDelete(dto);
    }

    @PostMapping(value = "/supplier/applyExport")
    @ApiOperation(value = "供应商-商品申请列表导出")
    public void supplierApplyExport(HttpServletRequest request, HttpServletResponse response, @Valid @RequestBody PurchaseScmProductApplyDto.SupplierSearchDto dto){
        purchaseScmProductApplyService.supplierApplyExport(request, response, dto);
    }

    @PostMapping(value = "/supplier/mySearch")
    @ApiOperation(value = "供应商-我的商品搜索")
    public JsonResult<Page<PurchaseScmProductApplyVo.SupplierMySearchVo>> supplierMySearch(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierMySearchDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.supplierMySearch(dto));
    }

    @PostMapping(value = "/supplier/myCount")
    @ApiOperation(value = "供应商-我的商品搜索角标")
    public JsonResult<PurchaseScmProductApplyVo.SupplierMySearchCountVo> supplierMySearchCount(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierMySearchDto dto) {
        return new JsonResult<>(true, null, purchaseScmProductApplyService.supplierMySearchCount(dto));
    }

    @PostMapping(value = "/supplier/myOnsale")
    @ApiOperation(value = "供应商-我的商品上下架")
    public JsonResult supplierMyOnsale(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierMyOnsaleDto dto){
        return purchaseScmProductApplyService.supplierMyOnsale(dto);
    }

    @PostMapping(value = "/supplier/myExport")
    @ApiOperation(value = "供应商-我的商品导出")
    public void supplierMyExport(HttpServletRequest request, HttpServletResponse response, @Valid @RequestBody PurchaseScmProductApplyDto.SupplierMySearchDto dto){
        purchaseScmProductApplyService.supplierMyExport(request, response, dto);
    }

    @PostMapping(value = "/supplier/publish")
    @ApiOperation(value = "供应商-批量发布")
    public JsonResult supplierPublish(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierPublishDto dto){
        return purchaseScmProductApplyService.supplierPublish(dto);
    }

    @PostMapping(value = "/supplier/publishDraft")
    @ApiOperation(value = "供应商-批量发布待提交")
    public JsonResult supplierPublishDraft(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierPublishDraftDto dto){
        return purchaseScmProductApplyService.supplierPublishDraft(dto);
    }

    @PostMapping(value = "/supplier/edit")
    @ApiOperation(value = "供应商-批量编辑修改")
    public JsonResult supplierEdit(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierPublishDto dto){
        return purchaseScmProductApplyService.supplierEdit(dto);
    }

    @PostMapping(value = "/supplier/editDraft")
    @ApiOperation(value = "供应商-批量编辑待提交")
    public JsonResult supplierEditDraft(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierPublishDraftDto dto){
        return purchaseScmProductApplyService.supplierEditDraft(dto);
    }

    @PostMapping(value = "/supplier/getGuide")
    @ApiOperation(value = "供应商-获取引导启用状态")
    public JsonResult<PurchaseScmProductApplyVo.SupplierGetGuideVo> supplierGetGuide(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierGetGuideDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.supplierGetGuide(dto));
    }

    @PostMapping(value = "/supplier/addGuide")
    @ApiOperation(value = "供应商-添加引导记录")
    public JsonResult supplierAddGuide(@Valid @RequestBody PurchaseScmProductApplyDto.SupplierGetGuideDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.addGuide(dto));
    }

    @PostMapping(value = "/admin/search")
    @ApiOperation(value = "后台-搜索")
    public JsonResult<Page<PurchaseScmProductApplyVo.AdminSearchVo>> adminSearch(@Valid @RequestBody PurchaseScmProductApplyDto.AdminSearchDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.adminSearch(dto));
    }

    @PostMapping(value = "/admin/count")
    @ApiOperation(value = "后台-搜索角标")
    public JsonResult<PurchaseScmProductApplyVo.SearchCountVo> adminSearchCount(@Valid @RequestBody PurchaseScmProductApplyDto.AdminSearchDto dto) {
        return new JsonResult<>(true, null, purchaseScmProductApplyService.adminSearchCount(dto));
    }

    @PostMapping(value = "/admin/detail")
    @ApiOperation(value = "后台-详情")
    public JsonResult<PurchaseScmProductApplyVo.SupplierDetailVo> adminDetail(@Valid @RequestBody PurchaseScmProductApplyDto.BaseDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.adminDetail(dto.getId()));
    }

    @PostMapping(value = "/admin/sameSearch")
    @ApiOperation(value = "后台-相同型号搜索")
    public JsonResult<Page<PurchaseScmProductApplyVo.SupplierSameSearchVo>> adminSameSearch(@Valid @RequestBody PurchaseScmProductApplyDto.AdminSameSearchDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.adminSameSearch(dto));
    }

    @PostMapping(value = "/admin/sameSelector")
    @ApiOperation(value = "后台-相同型号搜索选择器")
    public JsonResult<PurchaseScmProductApplyVo.SupplierSameSelectorVo> adminSameSelector(@Valid @RequestBody PurchaseScmProductApplyDto.AdminSameSearchDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmProductApplyService.adminSameSelector(dto));
    }

}
