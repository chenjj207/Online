package com.purchase.product.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Table;

/**
 * @Description: 供应商_SCM_ERP产品编码申请_日志表
 * @Author: loine
 * @Date: 2026/3/10 15:09
 **/
@Data
@ApiModel("供应商_SCM_ERP产品编码申请_日志表")
@Table(name = "t_pd_purchase_scm_erp_product_code_apply_log")
public class PurchaseScmErpProductCodeApplyLog extends BaseCorpModel {

    public static final String ID = "id";
    public static final String APPLY_NO = "applyNo";

    @ApiModelProperty("申请编号")
    private String applyNo;
    @ApiModelProperty("类型")
    private String type;
    @ApiModelProperty("处理信息")
    private String message;
}
