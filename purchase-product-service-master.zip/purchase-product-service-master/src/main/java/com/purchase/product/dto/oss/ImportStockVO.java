package com.purchase.product.dto.oss;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;


@Data
public class ImportStockVO implements Serializable {
    private int row;//行号
    @ApiModelProperty("产品编码")
    private String productCode;
    @ApiModelProperty(value = "库存")
    private String stock;
    @ApiModelProperty(value = "备注")
    private String remark;
}
