package com.purchase.product.mapper;

import com.purchase.product.dto.PurchaseScmProductApplyDto;
import com.purchase.product.model.PurchaseScmProductApplyAuditSum;
import com.purchase.product.vo.PurchaseScmProductApplyVo;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/12/15 13:56
 */
public interface PurchaseScmProductApplyAuditSumMapper extends QguBaseMapper<PurchaseScmProductApplyAuditSum> {

    /**
     * 相同供应商+相同品牌维度下，获取最近一行类型=‘提报数据’的事件结果数量
     *
     * @Author loine
     * @Date 2025/12/15 15:13
     */
    Integer getLastResultNum(@Param("supplierId") String supplierId, @Param("brandName") String brandName);

    /**
     * 导出
     *
     * @param dto
     * @Author loine
     * @Date 2025/12/16 13:27
     */
    List<PurchaseScmProductApplyVo.AuditSumExportVo> export(@Param("dto") PurchaseScmProductApplyDto.AuditSumExportDto dto);
}
