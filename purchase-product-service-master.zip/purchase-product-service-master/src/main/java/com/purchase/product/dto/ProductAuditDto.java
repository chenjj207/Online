package com.purchase.product.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProductAuditDto {

    @ApiModelProperty("审核id")
    private String id;

    @ApiModelProperty("审核后产品的审核状态")
    private Integer auditStatus;

    @ApiModelProperty("审核附加信息（未通过原因或Erp编码）")
    private String data;

    @ApiModelProperty("是否需要审核分类信息  运营端提交报价触发审核，是不需要检查分类，因为没有携带分类信息。  如果是从后台审核，那就需要审核分类信息")
    private boolean isCheckCata = true;

    /**
     * 可编辑属性
     */
    private CompileProperties properties;


    @Data
    public static class CompileProperties {

        /**
         * 一级分类名称
         */

        @ApiModelProperty(value = "一级分类名称")
        private String firstLevelCataName;

        /**
         * 二级分类名称
         */
        @ApiModelProperty(value = "二级分类名称")
        private String secondLevelCataName;

        /**
         * 三级分类名称
         */
        @ApiModelProperty(value = "三级分类名称")
        private String threeLevelCataName;

        /**
         * 商品品牌名称
         */
        @ApiModelProperty("商品品牌名称")
        private String brandName;

        /**
         * 商品系列名称
         */
        @ApiModelProperty("商品系列名称")
        private String propName;

        /**
         * 规格json数据
         */
        @ApiModelProperty("规格json数据")
        private String specData;
    }




}
