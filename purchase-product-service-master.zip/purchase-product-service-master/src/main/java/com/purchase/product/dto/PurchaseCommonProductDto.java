package com.purchase.product.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.purchase.model.dto.CommonProductDto;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDateTime;


@Data
public class PurchaseCommonProductDto extends CommonProductDto {



    /**
     * 一级店铺产品分类名
     */
    @ApiModelProperty(value = "一级店铺产品分类名")
    private String firstStoreCataName;

    /**
     * 二级店铺产品分类名
     */
    @ApiModelProperty(value = "二级店铺产品分类名")
    private String secondStoreCataName;

    /**
     * 店铺产品分类id
     */
    @ApiModelProperty(value = "店铺产品分类id")
    public Integer storeCataId;
}
