package com.purchase.product.service;

import com.github.pagehelper.PageHelper;
import com.purchase.product.model.ProductProperties;
import com.qgutech.qgyun.dev.client.uc.UcFeignClient;
import com.qgutech.qgyun.framework.common.utils.SqlUtil;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import com.purchase.product.mapper.ProductPropertiesMapper;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *  ProductPropertiesService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2022-11-04 11:46:24
 */
@Service
public class ProductPropertiesService extends BaseServiceImpl<ProductProperties> {

    @Resource
    private ProductPropertiesMapper productPropertiesMapper;
    @Resource
    private UcFeignClient ucFeignClient;

    public List<ProductProperties> listAll() {
        return productPropertiesMapper.selectAll();
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<ProductProperties> search(ProductProperties productProperties, Page<ProductProperties> page) {
        Assert.notNull(productProperties, "productProperties can not be null!");
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<ProductProperties> list = productPropertiesMapper.search(productProperties);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packProductPropertiesData(list);
        return page;
    }

    private Example genConditionExample(ProductProperties model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        String param = model.getParam();
        if (StringUtils.isNotBlank(param)) {
            criteria.andEqualTo(ProductProperties.PARAM, param);
        }

        String status = model.getStatus();
        if (StringUtils.isNotBlank(status)) {
            criteria.andEqualTo(ProductProperties.STATUS, status);
        }


        return example;
    }

    /**
     * 分页数据处理
     */
    private void packProductPropertiesData(List<ProductProperties> productPropertiesList) {
        if (CollectionUtils.isEmpty(productPropertiesList)) {
            return;
        }

        List<String> userIds = productPropertiesList.stream().map(ProductProperties::getUpdatedBy).collect(Collectors.toList());
        List<String> createdIds = productPropertiesList.stream().map(ProductProperties::getCreatedBy).collect(Collectors.toList());
        userIds.addAll(createdIds);
        userIds = userIds.stream().distinct().collect(Collectors.toList());
        Map<String, String> userMap = ucFeignClient.getUserIdAndNameMap(userIds);
        for (ProductProperties productProperties : productPropertiesList) {
            if (!MapUtils.isNotEmpty(userMap)) {
                continue;
            }

            productProperties.setCreatedByName(userMap.get(productProperties.getCreatedBy()));
            productProperties.setUpdatedByName(userMap.get(productProperties.getUpdatedBy()));
        }
    }

    /**
     * 通过id获取详情
     */
    @Override
    public ProductProperties get(String id) {
        ProductProperties productProperties = super.get(id);
        String createdBy = productProperties.getCreatedBy();
        String updatedBy = productProperties.getUpdatedBy();
        List<String> userIds = new ArrayList<>();
        if (StringUtils.isNotEmpty(createdBy)) {
            userIds.add(createdBy);
        }

        if (StringUtils.isNotEmpty(updatedBy)) {
            userIds.add(updatedBy);
        }

        userIds = userIds.stream().distinct().collect(Collectors.toList());
        Map<String, String> userMap = ucFeignClient.getUserIdAndNameMap(userIds);
        productProperties.setCreatedByName(userMap.get(createdBy));
        productProperties.setUpdatedByName(userMap.get(updatedBy));
        return productProperties;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(ProductProperties productProperties) {
        Assert.notNull(productProperties, "productProperties can not be null");
        Example example = genConditionExample(productProperties);
        example.selectProperties(ProductProperties.ID);
        List<ProductProperties> productPropertiesList = productPropertiesMapper.selectByExample(example);
        return CollectionUtils.isEmpty(productPropertiesList) ? new ArrayList<>(0) :
                productPropertiesList.stream().map(ProductProperties::getId).collect(Collectors.toList());
    }

    /**
     * 新增
     */
    public String add(ProductProperties productProperties) {
        return super.insert(productProperties);
    }

    /**
     * 修改
     */
    public void edit(ProductProperties productProperties) {
        super.update(productProperties);
    }

    /**
     * 批量删除
     */
    public void deleteByIds(List<String> ids) {
         super.batchDelete(ids);
    }

    public List<ProductProperties> listAllEnableColumns() {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(ProductProperties.STATUS, "Y");
        return productPropertiesMapper.selectByExample(example);
    }

    public List<ProductProperties> listByParam(String isOnline) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(ProductProperties.STATUS, "Y");
        if (StringUtils.isNotEmpty(isOnline)) {
            criteria.andEqualTo(ProductProperties.PARAM, isOnline);
        }
        return productPropertiesMapper.selectByExample(example);
    }
}
