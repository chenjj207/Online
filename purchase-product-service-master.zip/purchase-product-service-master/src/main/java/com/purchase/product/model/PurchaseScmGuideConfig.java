package com.purchase.product.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Table;

/**
 * @Description: 供应商_SCM产品申请引导配置表
 * @Author: loine
 * @Date: 2024/11/5 14:01
 **/
@Data
@ApiModel("供应商_SCM产品申请引导配置表")
@Table(name = "t_pd_purchase_scm_guide_config")
public class PurchaseScmGuideConfig extends BaseCorpModel {

    public static final String ID = "id";
    public static final String TYPE = "type";

    @ApiModelProperty("引导分类")
    private String type;
    @ApiModelProperty("是否启用（Y/N）")
    private String isEnable;
    @ApiModelProperty("引导次数")
    private Integer count;
}
