package com.purchase.product.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Table;

/**
 * @Description: 供应商_SCM产品申请引导记录表
 * @Author: loine
 * @Date: 2024/11/5 14:01
 **/
@Data
@ApiModel("供应商_SCM产品申请引导记录表")
@Table(name = "t_pd_purchase_scm_guide_record")
public class PurchaseScmGuideRecord extends BaseCorpModel {

    public static final String ID = "id";
    public static final String TYPE = "type";
    public static final String USER_ID = "userId";

    @ApiModelProperty("引导分类")
    private String type;
    @ApiModelProperty("用户表主键id")
    private String userId;
}
