package com.purchase.product.vo;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class BusinessProductListVo {

    @ApiModelProperty(value = "申请编号")
    private Long applyId;

    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;

    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;

    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;

    @ApiModelProperty("商品品牌名称")
    private String brandName;

    @ApiModelProperty("商品系列名称")
    private String propName;

    @ApiModelProperty("产品型号")
    private String productType;

    @ApiModelProperty("订货号")
    private String skuCode;

    @ApiModelProperty("商品编号")
    private String productCode;

    @ApiModelProperty("供货价")
    private BigDecimal supplyPrice;

    @ApiModelProperty("慧采价")
    private BigDecimal purchasePrice;

    @ApiModelProperty("面价（元）")
    private BigDecimal price;

    @ApiModelProperty("建议销售价")
    private BigDecimal suggestPrice;

    @ApiModelProperty("库存")
    private Integer stock;

    @ApiModelProperty("货期")
    private String deliveryDate;

    @ApiModelProperty("一级店铺分类名称")
    private String firstStoreCataName;

    @ApiModelProperty("二级店铺分类名称")
    private String secondStoreCataName;

    @ApiModelProperty("产品状态(待审核：待审核产品 未通过：未通过审核产品 销售中：上架通过审核产品产品 入库中：下架通过审核产品  )")
    private String state;

    @ApiModelProperty("主键id")
    private String id;

    @ApiModelProperty("重量")
    private String weight;

    @ApiModelProperty("规格属性")
    private String specData;

    @ApiModelProperty("图片")
    private String picName;

    @ApiModelProperty("审核备注")
    private String auditRemark;

    @ApiModelProperty("产品id")
    private String productId;

    @ApiModelProperty("创建者")
    private String createdBy;

    @ApiModelProperty("是否上架(Y:上架,N:下架)")
    private String isOnsale;

    @ApiModelProperty("商品申请来源 来源： inquiry | publish")
    private String applySource;

    @ApiModelProperty("待审核状态码（审核状态（0=待审核，2=不通过））")
    private Integer auditStatus;

    @ApiModelProperty("商品物料名称")
    private String materialName;

    @ApiModelProperty(value = "创建时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createdAt;

    @ApiModelProperty(value = "更新时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime updatedAt;

    @ApiModelProperty(value = "审核时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime;
}
