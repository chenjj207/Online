package com.purchase.product.dto.oss;

import lombok.Data;

import javax.persistence.Transient;
import java.util.List;

/**
 * Created by wangkang
 * Date :2022/8/16
 * Version :1.0
 */
@Data
public class LevelNameDto {
    private String id;
    private String name;
    private String level;
    private String type;

    /**
     * 子集
     */
    @Transient
    private List<LevelNameDto> children;
}
