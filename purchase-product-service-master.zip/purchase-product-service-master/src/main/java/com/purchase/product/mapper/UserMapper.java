package com.purchase.product.mapper;

import com.purchase.product.vo.UserInfoVo;
import org.apache.ibatis.annotations.Param;

/**
 * @Description:
 * @Author: loine
 * @Date: 2026/3/12 10:07
 */
public interface UserMapper {

    /**
     * 获取用户信息
     *
     * @param id
     * @Author loine
     * @Date 2026/3/11 14:03
     */
    UserInfoVo getUserInfo(@Param("id") String id);
}
