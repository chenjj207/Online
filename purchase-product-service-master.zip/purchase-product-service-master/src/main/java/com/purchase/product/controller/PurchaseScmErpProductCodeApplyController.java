package com.purchase.product.controller;

import com.purchase.product.dto.PurchaseScmErpProductCodeApplyDto;
import com.purchase.product.service.PurchaseScmErpProductCodeApplyService;
import com.purchase.product.vo.PurchaseScmErpProductCodeApplyVo;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @Description: 慧采SCM_ERP产品编码申请服务提供类
 * @Author: loine
 * @Date: 2026/3/10 15:49
 */
@RestController
@RequestMapping(value = "/purchaseScmErpProductCodeApply")
@Api(value = "PurchaseScmErpProductCodeApplyController", tags = {"慧采SCM_ERP产品编码申请服务提供类"})
@Slf4j
public class PurchaseScmErpProductCodeApplyController {

    @Resource
    private PurchaseScmErpProductCodeApplyService purchaseScmErpProductCodeApplyService;

    @PostMapping(value = "/admin/search")
    @ApiOperation(value = "后台-搜索")
    public JsonResult<Page<PurchaseScmErpProductCodeApplyVo.ErpAdminSearchVo>> adminSearch(@Valid @RequestBody PurchaseScmErpProductCodeApplyDto.ErpAdminSearchDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmErpProductCodeApplyService.adminSearch(dto));
    }

    @PostMapping(value = "/admin/count")
    @ApiOperation(value = "后台-搜索角标")
    public JsonResult<PurchaseScmErpProductCodeApplyVo.ErpSearchCountVo> adminSearchCount(@Valid @RequestBody PurchaseScmErpProductCodeApplyDto.ErpAdminSearchDto dto) {
        return new JsonResult<>(true, null, purchaseScmErpProductCodeApplyService.adminSearchCount(dto));
    }

    @PostMapping(value = "/admin/detail")
    @ApiOperation(value = "后台-详情")
    public JsonResult<PurchaseScmErpProductCodeApplyVo.ErpDetailVo> adminDetail(@Valid @RequestBody PurchaseScmErpProductCodeApplyDto.ErpBaseDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmErpProductCodeApplyService.adminDetail(dto.getId()));
    }

    @PostMapping(value = "/admin/publish")
    @ApiOperation(value = "后台-发布")
    public JsonResult adminPublish(@Valid @RequestBody PurchaseScmErpProductCodeApplyDto.ErpPublishDto dto) {
        return purchaseScmErpProductCodeApplyService.adminPublish(dto);
    }

    @PostMapping(value = "/admin/publishDraft")
    @ApiOperation(value = "后台-发布待提交")
    public JsonResult adminPublishDraft(@RequestBody PurchaseScmErpProductCodeApplyDto.ErpPublishDto dto) {
        return purchaseScmErpProductCodeApplyService.adminPublishDraft(dto);
    }

    @PostMapping(value = "/admin/edit")
    @ApiOperation(value = "后台-编辑修改")
    public JsonResult adminEdit(@Valid @RequestBody PurchaseScmErpProductCodeApplyDto.ErpPublishDto dto) {
        return purchaseScmErpProductCodeApplyService.adminEdit(dto);
    }

    @PostMapping(value = "/admin/editDraft")
    @ApiOperation(value = "后台-编辑待提交")
    public JsonResult adminEditDraft(@RequestBody PurchaseScmErpProductCodeApplyDto.ErpPublishDto dto) {
        return purchaseScmErpProductCodeApplyService.adminEditDraft(dto);
    }

    @PostMapping(value = "/admin/referenceDetail")
    @ApiOperation(value = "后台-参考详情")
    public JsonResult<PurchaseScmErpProductCodeApplyVo.ErpReferenceDetailVo> adminReferenceDetail(@Valid @RequestBody PurchaseScmErpProductCodeApplyDto.ErpReferenceDetailDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmErpProductCodeApplyService.adminReferenceDetail(dto.getReferenceCode()));
    }

    @PostMapping(value = "/admin/taxCataRelateList")
    @ApiOperation(value = "后台-税务分类关系列表")
    public JsonResult<List<PurchaseScmErpProductCodeApplyVo.ErpTaxCataRelateVo>> adminTaxCataRelateList() {
        return new JsonResult<>(true, "查询成功", purchaseScmErpProductCodeApplyService.adminTaxCataRelateList());
    }

    @PostMapping(value = "/admin/supplierRelateList")
    @ApiOperation(value = "后台-供应商关系列表")
    public JsonResult<List<PurchaseScmErpProductCodeApplyVo.ErpSupplierRelateVo>> adminSupplierRelateList() {
        return new JsonResult<>(true, "查询成功", purchaseScmErpProductCodeApplyService.adminSupplierRelateList());
    }

    @PostMapping(value = "/admin/erpProductList")
    @ApiOperation(value = "后台-ERP产品属性列表")
    public JsonResult<List<String>> adminErpProductList(@Valid @RequestBody PurchaseScmErpProductCodeApplyDto.ErpProductListDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmErpProductCodeApplyService.adminErpProductList(dto.getCode()));
    }

    @PostMapping(value = "/admin/approve")
    @ApiOperation(value = "后台-审核通过")
    public JsonResult adminApprove(@RequestBody PurchaseScmErpProductCodeApplyDto.ErpBaseDto dto) {
        return purchaseScmErpProductCodeApplyService.adminApprove(dto);
    }

    @PostMapping(value = "/admin/adminReject")
    @ApiOperation(value = "后台-审核驳回")
    public JsonResult adminReject(@RequestBody PurchaseScmErpProductCodeApplyDto.ErpRejectDto dto) {
        return purchaseScmErpProductCodeApplyService.adminReject(dto);
    }

    @PostMapping(value = "/admin/logList")
    @ApiOperation(value = "后台-日志列表")
    public JsonResult<List<PurchaseScmErpProductCodeApplyVo.ErpLogListVo>> adminLogList(@RequestBody PurchaseScmErpProductCodeApplyDto.ErpLogListDto dto) {
        return new JsonResult<>(true, "查询成功", purchaseScmErpProductCodeApplyService.adminLogList(dto));
    }

    @PostMapping(value = "/admin/userList")
    @ApiOperation(value = "后台-反推用户列表")
    public JsonResult<List<PurchaseScmErpProductCodeApplyVo.ErpAdminUserListVo>> adminUserList() {
        return new JsonResult<>(true, "查询成功", purchaseScmErpProductCodeApplyService.adminUserList());
    }
}
