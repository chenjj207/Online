package com.purchase.product.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/1/15  10:49
 */
@Data
public class PurchaseRecommendProductAddDTO {

    @NotEmpty(message = "商品id不能为空")
    private List<Long> productIds;
}
