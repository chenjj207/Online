package com.purchase.product.mapper;

import com.purchase.product.model.ZydmallProductSync;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author jidonglin
 * @Description: 同步zydmall产品
 * @date 2022/9/28  13:23
 */
public interface ZydmallProductSyncMapper extends QguBaseMapper<ZydmallProductSync> {

    //查询前一天并且未更新公海的商品
    List<ZydmallProductSync> selectByModiTimeLastDay();

    List<ZydmallProductSync> selectByNotUpdate();

    int batchUpdateProduct(@Param("list") List<ZydmallProductSync> zydmallProductSyncList);

}
