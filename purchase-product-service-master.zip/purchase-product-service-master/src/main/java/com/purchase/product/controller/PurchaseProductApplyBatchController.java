package com.purchase.product.controller;

import com.purchase.product.model.PurchaseProductApplyBatch;
import com.purchase.product.service.PurchaseProductApplyBatchService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 租户产品申请服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2022-08-16
 */
@RestController
@RequestMapping(value = "/purchaseProductApplyBatch")
@Api(value = "PurchaseProductApplyBatchController" , tags = {"慧采产品申请批次服务提供类"})
public class PurchaseProductApplyBatchController {

    @Resource
    private PurchaseProductApplyBatchService purchaseProductApplyBatchService;

    @GetMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "batchNo", value = "批次编号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "fileUrl", value = "文件地址", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "type", value = "类型（1=单个添加，2=批量添加）", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<PurchaseProductApplyBatch>> search(@ParamHide PurchaseProductApplyBatch batch, @ParamHide Page<PurchaseProductApplyBatch> page) {
        page = purchaseProductApplyBatchService.search(batch, page);
        return new JsonResult<>(true, "查询成功", page);
    }

    @GetMapping(value = "/listAll")
    @ApiOperation(value = "获取所有数据")
    public JsonResult<List<PurchaseProductApplyBatch>> listAll() {
        return new JsonResult<>(true, "查询成功", purchaseProductApplyBatchService.listAll());
    }

    @PostMapping("/add")
    @ApiOperation(value = "新增接口")
    public JsonResult<String> addPurchaseProductApplyBatch(@RequestBody PurchaseProductApplyBatch batch) {
        String id = purchaseProductApplyBatchService.add(batch);
        return new JsonResult<>(true, "添加成功", id);
    }

    @PutMapping("/edit")
    @ApiOperation(value = "编辑接口")
    public JsonResult editPurchaseProductApplyBatch(@RequestBody @Check(field = {"id"}) PurchaseProductApplyBatch batch) {
        purchaseProductApplyBatchService.edit(batch);
        return new JsonResult(true, "编辑成功");
    }

    @GetMapping(value = "/{id}")
    @ApiOperation(value = "根据id获取数据")
    @ApiImplicitParams(@ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true))
    public JsonResult<PurchaseProductApplyBatch> getPurchaseProductApplyBatch(@PathVariable(value = "id") String id) {
        PurchaseProductApplyBatch purchaseProductApplyBatch = purchaseProductApplyBatchService.get(id);
        return new JsonResult<>(true, "查询成功", purchaseProductApplyBatch);
    }

    @DeleteMapping(value = "/delete")
    @ApiOperation(value = "根据传入的Id，删除数据")
    public JsonResult<String> purchaseProductApplyBatchDelete(@RequestBody List<String> ids) {
        purchaseProductApplyBatchService.deleteByIds(ids);
        return new JsonResult<>(true, "删除成功");
    }

}