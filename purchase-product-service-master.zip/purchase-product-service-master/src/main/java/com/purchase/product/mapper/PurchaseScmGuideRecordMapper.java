package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseScmGuideRecord;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 * @Description: 供应商_SCM产品申请引导记录表
 * @Author: loine
 * @Date: 2024/11/5 14:01
 **/
public interface PurchaseScmGuideRecordMapper extends QguBaseMapper<PurchaseScmGuideRecord> {

}
