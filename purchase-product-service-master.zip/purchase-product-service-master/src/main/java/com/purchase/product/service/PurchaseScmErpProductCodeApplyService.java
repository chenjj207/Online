package com.purchase.product.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.util.URLUtil;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.purchase.exception.ZydExceptions;
import com.purchase.product.client.MsgClient;
import com.purchase.product.client.dto.TriggerMsgRequest;
import com.purchase.product.conf.OssConf;
import com.purchase.product.dto.PurchaseScmErpProductCodeApplyDto;
import com.purchase.product.mapper.*;
import com.purchase.product.model.PurchaseScmErpProductCodeApply;
import com.purchase.product.model.PurchaseScmErpProductCodeApplyLog;
import com.purchase.product.util.RedisUtils;
import com.purchase.product.vo.PurchaseScmErpProductCodeApplyVo;
import com.purchase.product.vo.UserInfoVo;
import com.purchase.utils.date.ZydDateUtils;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

/**
 * @Description:
 * @Author: loine
 * @Date: 2026/3/10 15:51
 */
@Service
@Slf4j
public class PurchaseScmErpProductCodeApplyService extends BaseServiceImpl<PurchaseScmErpProductCodeApply> {

    @Autowired
    private PurchaseScmErpProductCodeApplyMapper purchaseScmErpProductCodeApplyMapper;
    @Autowired
    private PurchaseScmTaxCataRelateMapper purchaseScmTaxCataRelateMapper;
    @Autowired
    private PurchaseScmSupplierRelateMapper purchaseScmSupplierRelateMapper;
    @Autowired
    private PurchaseScmErpProductCodeApplyLogMapper purchaseScmErpProductCodeApplyLogMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private OssMaterialService ossMaterialService;
    @Autowired
    private OssConf ossConf;
    @Autowired
    private RedisTemplate redisTemplate;
    @Value("${odsUrl}")
    private String odsUrl;
    @Resource
    private MsgClient msgClient;

    /**
     * 后台-搜索
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/11 09:36
     */
    public Page<PurchaseScmErpProductCodeApplyVo.ErpAdminSearchVo> adminSearch(PurchaseScmErpProductCodeApplyDto.ErpAdminSearchDto dto) {
        Page<PurchaseScmErpProductCodeApplyVo.ErpAdminSearchVo> page = new Page<>();
        page.setPageNum(BeanUtil.isEmpty(dto.getPageNum()) ? 1 : dto.getPageNum());
        page.setPageSize(BeanUtil.isEmpty(dto.getPageSize()) ? 12 : dto.getPageSize());
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        return new Page<>(purchaseScmErpProductCodeApplyMapper.adminSearch(dto));
    }

    /**
     * 后台-搜索角标
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/11 10:11
     */
    public PurchaseScmErpProductCodeApplyVo.ErpSearchCountVo adminSearchCount(PurchaseScmErpProductCodeApplyDto.ErpAdminSearchDto dto) {
        return purchaseScmErpProductCodeApplyMapper.adminSearchCount(dto);
    }

    /**
     * 后台-详情
     *
     * @param id
     * @Author loine
     * @Date 2026/3/11 10:21
     */
    public PurchaseScmErpProductCodeApplyVo.ErpDetailVo adminDetail(String id) {
        PurchaseScmErpProductCodeApplyVo.ErpDetailVo detailVo = purchaseScmErpProductCodeApplyMapper.adminDetail(id);
        if (detailVo != null) {
            detailVo.setUrlPrefix(ossConf.getOssUrl());
        }
        return detailVo;
    }

    /**
     * 后台-发布
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/11 11:07
     */
    @Transactional(rollbackFor = Exception.class)
    public JsonResult adminPublish(PurchaseScmErpProductCodeApplyDto.ErpPublishDto dto) {
        if (StringUtils.isBlank(dto.getIsDraft())) {
            dto.setIsDraft("N");
        }
        String[] ifsMainProcurements = new String[]{"上海供应链", "其它品种", "技术服务"};
        ZydExceptions.re(!Arrays.asList(ifsMainProcurements).contains(dto.getSifsMainProcurement()), "该编码非供应链产品，请联系对应商务添加<br/>施耐德工控：肖燕璇<br/>施耐德配电：张郁玲<br/>西门子工控：蔡秀芳<br/>西门子配电：刘玩虹<br/>ABB 工控：胡海燕<br/>ABB 配电：朱颖<br/>综合一部：林哲<br/>日系品牌：陈芳");

        // 如果是待提交，数据需要先删除，再新增
        String draftApplyNo = null;
        if (dto.getIsDraft().equals("Y")) {
            PurchaseScmErpProductCodeApply detail = getDetail(dto.getId());
            if (detail != null) {
                draftApplyNo = detail.getApplyNo();
                if (detail.getAuditStatus() == 0) {
                    delete(dto.getId());
                } else {
                    ZydExceptions.re(true, "状态有误，请检查");
                }
            }
        }
        ZydExceptions.re(purchaseScmErpProductCodeApplyMapper.checkIsIfsProduct(dto) > 0, "产地+产品型号已存在，请检查");
//        Example example = new Example(entityClass);
//        example.orderBy(PurchaseScmErpProductCodeApply.CREATED_AT).desc();
//        Example.Criteria criteria = example.createCriteria();
//        criteria.andEqualTo(PurchaseScmErpProductCodeApply.PRODUCT_TYPE, dto.getProductType());
//        criteria.andEqualTo(PurchaseScmErpProductCodeApply.PRODUCT_AREA, dto.getProductArea());
//        criteria.andNotEqualTo(PurchaseScmErpProductCodeApply.AUDIT_STATUS, 0);
//        ZydExceptions.re(purchaseScmErpProductCodeApplyMapper.selectCountByExample(example) > 0, "产地+产品型号已存在，请检查");

        String userId = ContextHandler.getUserId();
        LocalDateTime now = LocalDateTime.now();

        // 处理申请数据
        PurchaseScmErpProductCodeApply applyNew = handleApply(null, dto);
        if (applyNew != null) {
            // 处理图片
            handleImage(applyNew);

            applyNew.setId(IDUtils.getUUID19());
            if (StringUtils.isNotBlank(draftApplyNo)) {
                applyNew.setApplyNo(draftApplyNo);
            } else {
                applyNew.setApplyNo(getMaxApplyNo());
            }
            applyNew.setCreatedBy(userId);
            applyNew.setCreatedAt(now);
            applyNew.setUpdatedBy(userId);
            applyNew.setUpdatedAt(now);
            applyNew.setCorpCode(ContextHandler.getCorpCode());
            this.insert(applyNew);
            // 添加申请日志
            addApplyLog(applyNew, "商品新增", "-", now, userId);
            // 发送审核消息
            sendAuditMsg(applyNew);
        }
        return new JsonResult(true, "");
    }

    /**
     * 发布待提交
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/11 11:46
     */
    public JsonResult adminPublishDraft(PurchaseScmErpProductCodeApplyDto.ErpPublishDto dto) {
        String userId = ContextHandler.getUserId();
        LocalDateTime now = LocalDateTime.now();

        // 处理申请数据
        PurchaseScmErpProductCodeApply applyNew = handleApply(null, dto);
        if (applyNew != null) {
            // 处理图片
            handleImage(applyNew);

            applyNew.setId(IDUtils.getUUID19());
            applyNew.setApplyNo(getMaxApplyNo());
            applyNew.setAuditStatus(0);
            applyNew.setCreatedBy(userId);
            applyNew.setCreatedAt(now);
            applyNew.setUpdatedBy(userId);
            applyNew.setUpdatedAt(now);
            applyNew.setCorpCode(ContextHandler.getCorpCode());
            this.insert(applyNew);
        }
        return new JsonResult(true, "");
    }

    /**
     * 后台-编辑修改
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/11 11:56
     */
    @Transactional(rollbackFor = Exception.class)
    public JsonResult adminEdit(PurchaseScmErpProductCodeApplyDto.ErpPublishDto dto) {
        ZydExceptions.re(StringUtils.isBlank(dto.getId()), "不允许新增申请");
        String userId = ContextHandler.getUserId();
        LocalDateTime now = LocalDateTime.now();

        PurchaseScmErpProductCodeApply applyOld = getDetail(dto.getId());
        ZydExceptions.re(applyOld == null, "数据不存在，请检查");
        ZydExceptions.re(applyOld.getAuditStatus() == 4, "已建档，不允许修改");

        String[] ifsMainProcurements = new String[]{"上海供应链", "其它品种", "技术服务"};
        ZydExceptions.re(!Arrays.asList(ifsMainProcurements).contains(dto.getSifsMainProcurement()), "该编码非供应链产品，请联系对应商务添加<br/>施耐德工控：肖燕璇<br/>施耐德配电：张郁玲<br/>西门子工控：蔡秀芳<br/>西门子配电：刘玩虹<br/>ABB 工控：胡海燕<br/>ABB 配电：朱颖<br/>综合一部：林哲<br/>日系品牌：陈芳");

        if (!dto.getProductType().equals(applyOld.getProductType()) || !dto.getProductArea().equals(applyOld.getProductArea())) {
            ZydExceptions.re(purchaseScmErpProductCodeApplyMapper.checkIsIfsProduct(dto) > 0, "产地+产品型号已存在，请检查");
        }
//        Example example = new Example(entityClass);
//        example.orderBy(PurchaseScmErpProductCodeApply.CREATED_AT).desc();
//        Example.Criteria criteria = example.createCriteria();
//        criteria.andNotEqualTo(PurchaseScmErpProductCodeApply.ID, dto.getId());
//        criteria.andEqualTo(PurchaseScmErpProductCodeApply.PRODUCT_TYPE, dto.getProductType());
//        criteria.andEqualTo(PurchaseScmErpProductCodeApply.PRODUCT_AREA, dto.getProductArea());
//        criteria.andNotEqualTo(PurchaseScmErpProductCodeApply.AUDIT_STATUS, 0);
//        ZydExceptions.re(purchaseScmErpProductCodeApplyMapper.selectCountByExample(example) > 0, "产地+产品型号已存在，请检查");

        // 处理申请数据
        PurchaseScmErpProductCodeApply applyNew = handleApply(applyOld, dto);
        if (applyNew != null) {
            // 处理图片
            handleImage(applyNew);

            applyNew.setUpdatedBy(userId);
            applyNew.setUpdatedAt(now);
            this.update(applyNew);
            // 添加申请日志
            addApplyLog(applyNew, "产品修改", applyNew.getChangeMessage(), now, userId);
        }
        return new JsonResult(true, "");
    }

    /**
     * 后台-编辑待提交
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/11 11:56
     */
    public JsonResult adminEditDraft(PurchaseScmErpProductCodeApplyDto.ErpPublishDto dto) {
        ZydExceptions.re(StringUtils.isBlank(dto.getId()), "不允许新增申请");
        String userId = ContextHandler.getUserId();
        LocalDateTime now = LocalDateTime.now();

        PurchaseScmErpProductCodeApply applyOld = getDetail(dto.getId());
        ZydExceptions.re(applyOld == null, "数据不存在，请检查");
        // 处理申请数据
        PurchaseScmErpProductCodeApply applyNew = handleApply(applyOld, dto);
        if (applyNew != null) {
            // 处理图片
            handleImage(applyNew);

            applyNew.setAuditStatus(0);
            applyNew.setUpdatedBy(userId);
            applyNew.setUpdatedAt(now);
            this.update(applyNew);
        }
        return new JsonResult(true, "");
    }

    /**
     * 后台-参考详情
     *
     * @param referenceCode
     * @Author loine
     * @Date 2026/3/11 13:33
     */
    public PurchaseScmErpProductCodeApplyVo.ErpReferenceDetailVo adminReferenceDetail(String referenceCode) {
        return purchaseScmErpProductCodeApplyMapper.adminReferenceDetail(referenceCode);
    }

    /**
     * 后台-税务分类关系列表
     *
     * @Author loine
     * @Date 2026/3/11 13:52
     */
    public List<PurchaseScmErpProductCodeApplyVo.ErpTaxCataRelateVo> adminTaxCataRelateList() {
        return purchaseScmTaxCataRelateMapper.selectRelateList();
    }

    /**
     * 后台-供应商关系列表
     *
     * @Author loine
     * @Date 2026/3/11 13:57
     */
    public List<PurchaseScmErpProductCodeApplyVo.ErpSupplierRelateVo> adminSupplierRelateList() {
        return purchaseScmSupplierRelateMapper.selectRelateList();
    }

    /**
     * 后台-ERP产品属性列表
     *
     * @param code
     * @Author loine
     * @Date 2026/3/11 14:03
     */
    public List<String> adminErpProductList(String code) {
        return purchaseScmErpProductCodeApplyMapper.selectErpProductList(code);
    }

    /**
     * 后台-审核通过
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/11 15:51
     */
    @Transactional(rollbackFor = Exception.class)
    public JsonResult adminApprove(PurchaseScmErpProductCodeApplyDto.ErpBaseDto dto) {
        PurchaseScmErpProductCodeApply detail = getDetail(dto.getId());
        ZydExceptions.re(detail == null, "数据不存在，请检查");
        ZydExceptions.re(detail.getAuditStatus() == 4, "已建档，不允许操作");
        ZydExceptions.re(!(detail.getAuditStatus() == 1 || detail.getAuditStatus() == 2), "状态有误，不允许操作");

        String userId = ContextHandler.getUserId();
        LocalDateTime auditTime = LocalDateTime.now();
        String type;
        if (detail.getAuditStatus() == 1) {
            detail.setAuditStatus(2);
            detail.setAuditTime1(auditTime);
            type = "资料审核";
        } else {
            detail.setAuditStatus(3);
            detail.setAuditTime2(auditTime);
            type = "新增审核";
        }
        this.update(detail);
        // 添加申请日志
        addApplyLog(detail, type, "审核通过", auditTime, userId);
        // 发送审核消息
        sendAuditMsg(detail);
        return new JsonResult(true, "");
    }

    /**
     * 后台-审核驳回
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/11 15:51
     */
    @Transactional(rollbackFor = Exception.class)
    public JsonResult adminReject(PurchaseScmErpProductCodeApplyDto.ErpRejectDto dto) {
        PurchaseScmErpProductCodeApply detail = getDetail(dto.getId());
        ZydExceptions.re(detail == null, "数据不存在，请检查");
        ZydExceptions.re(detail.getAuditStatus() == 4, "已建档，不允许操作");

        String userId = ContextHandler.getUserId();
        LocalDateTime auditTime = LocalDateTime.now();
        String type;
        String message;
        if (detail.getAuditStatus() == 1) {
            type = "资料审核";
        } else {
            type = "新增审核";
        }
        if (StringUtils.isBlank(dto.getAuditRemark())) {
            message = "审核驳回";
        } else {
            message ="审核驳回，驳回原因：" + dto.getAuditRemark();
        }
        detail.setAuditStatus(5);
        detail.setAuditRemark(dto.getAuditRemark());
        detail.setCancelTime(auditTime);
        this.update(detail);
        // 添加申请日志
        addApplyLog(detail, type, message, auditTime, userId);
        // 发送审核消息
        sendAuditMsg(detail);
        return new JsonResult(true, "");
    }

    /**
     * 后台-日志列表
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/12 14:21
     */
    public List<PurchaseScmErpProductCodeApplyVo.ErpLogListVo> adminLogList(PurchaseScmErpProductCodeApplyDto.ErpLogListDto dto) {
        return purchaseScmErpProductCodeApplyLogMapper.adminLogList(dto.getApplyNo());
    }

    /**
     * 后台-导出
     *
     * @param dto
     * @Author loine
     * @Date 2026/3/12 14:03
     */
    public List<PurchaseScmErpProductCodeApplyVo.ErpAdminExportVo> adminExport(PurchaseScmErpProductCodeApplyDto.ErpAdminSearchDto dto) {
        List<PurchaseScmErpProductCodeApplyVo.ErpAdminExportVo> exports = new ArrayList<>();
        List<PurchaseScmErpProductCodeApplyVo.ErpAdminSearchVo> list = purchaseScmErpProductCodeApplyMapper.adminSearch(dto);
        for (PurchaseScmErpProductCodeApplyVo.ErpAdminSearchVo l : list) {
            PurchaseScmErpProductCodeApplyVo.ErpAdminExportVo eL = new PurchaseScmErpProductCodeApplyVo.ErpAdminExportVo();
            BeanUtils.copyProperties(l, eL);
            if (l.getAuditStatus() == 0) {
                eL.setAuditStatus("待提交");
            } else if (l.getAuditStatus() == 1) {
                eL.setAuditStatus("待资料审核");
            } else if (l.getAuditStatus() == 2) {
                eL.setAuditStatus("待新增审核");
            } else if (l.getAuditStatus() == 3) {
                eL.setAuditStatus("建编码中");
            } else if (l.getAuditStatus() == 4) {
                eL.setAuditStatus("已建档");
            } else if (l.getAuditStatus() == 5) {
                eL.setAuditStatus("审核驳回");
            }
            if (l.getSource().equals("1")) {
                eL.setSource("手工申请");
            } else {
                eL.setSource("报价申请");
            }
            if (StringUtils.isBlank(l.getErpProductCode())) {
                eL.setErpProductCode("-");
            }
            eL.setCreatedAt(ZydDateUtils.YMDHMSformatDate(Date.from(l.getCreatedAt().atZone(ZoneId.systemDefault()).toInstant())));
            exports.add(eL);
        }
        return exports;
    }

    /**
     * 后台-反推用户列表
     *
     * @Author loine
     * @Date 2026/3/19 09:23
     */
    public List<PurchaseScmErpProductCodeApplyVo.ErpAdminUserListVo> adminUserList() {
        return purchaseScmErpProductCodeApplyMapper.adminUserList();
    }

    /**
     * 同步IFS的ERP编码到ERP产品编码申请表
     * @Author loine
     * @Date 2026/3/13 10:08
     */
    @Transactional(rollbackFor = Exception.class)
    public void syncIfsErpCodeToErpApply() {
        // 获取需要更新ERP编码的申请列表
        List<PurchaseScmErpProductCodeApply> applies = purchaseScmErpProductCodeApplyMapper.getNeedUpdateIfsErpCode();
        if (!applies.isEmpty()) {
            // 批量更新
            this.batchUpdate(applies);
            for (PurchaseScmErpProductCodeApply apply : applies) {
                // 添加申请日志
                addApplyLog(apply, "关联编码", "ERP产品编码：" + apply.getErpProductCode(), apply.getAuditTime3(), "系统同步");
                // 发送审核消息
                sendAuditMsg(apply);
            }
        }
    }

    /**
     * 同步IFS产品到ERP产品编码申请表
     *
     * @Author loine
     * @Date 2026/3/13 10:08
     */
    @Transactional(rollbackFor = Exception.class)
    public void syncIfsProductToErpApply() {
        LocalDateTime now = LocalDateTime.now();
        // 获取需要更新ERP编码的申请列表
        List<PurchaseScmErpProductCodeApply> applies = purchaseScmErpProductCodeApplyMapper.getApproveList();
        if (!applies.isEmpty()) {
            List<PurchaseScmErpProductCodeApply> updates = new ArrayList<>();
            List<String> excludeList = new ArrayList<>();
            excludeList.add("productType");
            excludeList.add("productArea");
            excludeList.add("supplierBrand");
            excludeList.add("referenceCode");
            excludeList.add("productVoucher");
            excludeList.add("supplierCode");
            for (PurchaseScmErpProductCodeApply apply : applies) {
                PurchaseScmErpProductCodeApply applyNew = purchaseScmErpProductCodeApplyMapper.getIfsInfoToApply(apply.getProductType(), apply.getProductArea());
                if (applyNew == null) {
                    continue;
                }
                String changeMessage = apply.ownCompare(applyNew, excludeList);
                // 没有修改数据的，直接跳过
                if (StringUtils.isBlank(changeMessage)) {
                    continue;
                }
                apply.setChangeMessage(changeMessage);
                BeanUtil.copyProperties(applyNew, apply, CopyOptions.create().setIgnoreNullValue(true));
                updates.add(apply);
            }
            // 批量更新
            this.batchUpdate(updates);
            for (PurchaseScmErpProductCodeApply update : updates) {
                // 添加申请日志
                addApplyLog(update, "数据同步", update.getChangeMessage(), now, "系统同步");
            }
        }
    }

    /**
     * 供应商获取商品申请详情
     *
     * @param id
     * @Author: loine
     * @Date: 2024/10/26 9:41
     */
    private PurchaseScmErpProductCodeApply getDetail(String id) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(PurchaseScmErpProductCodeApply.ID, id);
        return purchaseScmErpProductCodeApplyMapper.selectOneByExample(example);
    }

    /**
     * 处理申请数据
     *
     * @param applyOld
     * @param dtoNew
     * @Author loine
     * @Date 2026/3/12 11:28
     */
    private PurchaseScmErpProductCodeApply handleApply(PurchaseScmErpProductCodeApply applyOld, PurchaseScmErpProductCodeApplyDto.ErpPublishDto dtoNew){
        PurchaseScmErpProductCodeApply applyNew = new PurchaseScmErpProductCodeApply();
        if (applyOld == null) {
            BeanUtils.copyProperties(dtoNew, applyNew);
            applyNew.setAuditStatus(1);
        } else {
            BeanUtils.copyProperties(applyOld, applyNew);
            BeanUtils.copyProperties(dtoNew, applyNew);
            String changeMessage = applyOld.ownCompare(applyNew, null);
            // 校验需求人信息
            if (!Objects.equals(applyOld.getDemandComBm(), applyNew.getDemandComBm())) {
                String oldValue = purchaseScmErpProductCodeApplyMapper.getComName(applyOld.getDemandComBm());
                String newValue = purchaseScmErpProductCodeApplyMapper.getComName(applyNew.getDemandComBm());
                String oldStringValue = oldValue == null ? "-" : StringUtils.trim(oldValue);
                String newStringValue = newValue == null ? "-" : StringUtils.trim(newValue);
                if (StringUtils.isBlank(changeMessage)) {
                    changeMessage = "需求人所属公司：" + oldStringValue + " -> " + newStringValue;
                } else {
                    changeMessage += "，需求人所属公司：" + oldStringValue + " -> " + newStringValue;
                }
            }
            if (!Objects.equals(applyOld.getDemandUserId(), applyNew.getDemandUserId())) {
                String oldValue = purchaseScmErpProductCodeApplyMapper.getUserName(applyOld.getDemandUserId());
                String newValue = purchaseScmErpProductCodeApplyMapper.getUserName(applyNew.getDemandUserId());
                String oldStringValue = oldValue == null ? "-" : StringUtils.trim(oldValue);
                String newStringValue = newValue == null ? "-" : StringUtils.trim(newValue);
                if (StringUtils.isBlank(changeMessage)) {
                    changeMessage = "产品需求人：" + oldStringValue + " -> " + newStringValue;
                } else {
                    changeMessage += "，产品需求人：" + oldStringValue + " -> " + newStringValue;
                }
            }
            // 没有修改数据的，直接跳过
            if (StringUtils.isBlank(changeMessage)) {
                return null;
            }
            applyNew.setAuditStatus(1);
            applyNew.setChangeMessage(changeMessage);
        }
        return applyNew;
    }

    /**
     * 添加申请日志
     *
     * @param apply
     * @param type
     * @param message
     * @param time
     * @param createdBy
     * @Author loine
     * @Date 2026/3/12 11:40
     */
    private void addApplyLog(PurchaseScmErpProductCodeApply apply, String type, String message, LocalDateTime time, String createdBy) {
        PurchaseScmErpProductCodeApplyLog log = new PurchaseScmErpProductCodeApplyLog();
        log.setId(IDUtils.getUUID19());
        log.setApplyNo(apply.getApplyNo());
        log.setType(type);
        log.setMessage(message);
        log.setCreatedBy(StringUtils.isBlank(createdBy) ? apply.getCreatedBy() : createdBy);
        log.setCreatedAt(time);
        log.setUpdatedBy(StringUtils.isBlank(createdBy) ? apply.getCreatedBy() : createdBy);
        log.setUpdatedAt(time);
        log.setCorpCode("default");
        purchaseScmErpProductCodeApplyLogMapper.insert(log);
    }

    /**
     * 获取最大申请编码+1
     *
     * @return
     */
    private String getMaxApplyNo() {
        String key = "SGT" + ZydDateUtils.format("yyMMdd", new Date()) + "-";
        Long num = RedisUtils.genCode("scm_erp_product_code_apply_no:" + key, redisTemplate, () -> {
            String max = purchaseScmErpProductCodeApplyMapper.getMaxApplyNo(key);
            if (StringUtils.isBlank(max)) {
                return 0L;
            } else {
                return Long.parseLong(max);
            }
        });
        return key + (String.format("%04d", num));
    }

    /**
     * 处理图片
     *
     * @param applyNew
     * @Author: loine
     * @Date: 2024/10/23 17:54
     */
    private void handleImage(PurchaseScmErpProductCodeApply applyNew) {
        if (StringUtils.isNotBlank(applyNew.getProductVoucher())) {
            StringBuilder sb = new StringBuilder();
            String[] picNames = applyNew.getProductVoucher().split("@");
            for (String picName : picNames) {
                if (picName.contains("http://") || picName.contains("https")) {
                    String result = ossMaterialService.scmUploadResourceByUrl("/产线管理/编码申请/产品凭证/", picName);
                    sb.append(result).append("@");
                } else {
                    sb.append(picName).append("@");
                }
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
            }
            applyNew.setProductVoucher(sb.toString());
        }
    }

    /**
     * 发送审核消息
     *
     * @param apply
     * @Author loine
     * @Date 2026/3/11 15:59
     */
    private void sendAuditMsg(PurchaseScmErpProductCodeApply apply) {
        Integer auditStatus = apply.getAuditStatus();
        UserInfoVo createUser = userMapper.getUserInfo(apply.getCreatedBy());
        UserInfoVo demandUser = userMapper.getUserInfo(apply.getDemandUserId());
        if (createUser != null && demandUser != null) {
            // 企业微信参数
            TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
            triggerMsgRequest.setBusiness("scmProduct");
            String mainTitleText = "您有新的产品待审核（SCM编码申请）";
            String status;
            String scene;
            String keyNameString4 = "提报人";
            String valueString4 = createUser.getName();
            JSONObject qywxParam = new JSONObject();
            if (auditStatus == 1) {
                status = "待资料审核";
                scene = "erpProductCodeApplyData";
            } else if (auditStatus == 2) {
                status = "待新增审核";
                scene = "erpProductCodeApplyNew";
            } else if (auditStatus == 4) {
                status = "已建档";
                scene = "erpProductCodeApplyApprove";
                mainTitleText = "产品申请已建档（SCM编码申请）";
                qywxParam.put("noticeUser", createUser.getCode() + "," + demandUser.getCode());
                keyNameString4 = "产品编码";
                valueString4 = apply.getErpProductCode();
            } else if (auditStatus == 5) {
                status = "审核驳回";
                scene = "erpProductCodeApplyReject";
                mainTitleText = "产品申请未通过（SCM编码申请）";
                qywxParam.put("noticeUser", createUser.getCode());
                keyNameString4 = "驳回原因";
                valueString4 = apply.getAuditRemark();
            } else {
                return;
            }
            triggerMsgRequest.setScene(scene);

            qywxParam.put("msgtype", "template_card");
            JSONObject templateCard = new JSONObject();
            templateCard.put("card_type", "text_notice");
            JSONObject mainTitle = new JSONObject();
            mainTitle.put("title", mainTitleText);
            mainTitle.put("desc", status);
            templateCard.put("main_title", mainTitle);
            List<JSONObject> horizontalContentList = new ArrayList<>();
            JSONObject keyName1 = new JSONObject();
            keyName1.put("keyname", "产地");
            keyName1.put("value", apply.getProductArea());
            horizontalContentList.add(keyName1);
            JSONObject keyName2 = new JSONObject();
            keyName2.put("keyname", "产品型号");
            keyName2.put("value", apply.getProductType());
            horizontalContentList.add(keyName2);
            JSONObject keyName3 = new JSONObject();
            keyName3.put("keyname", "提报时间");
            keyName3.put("value", ZydDateUtils.format(ZydDateUtils.ymdhmsSlant, Date.from(apply.getCreatedAt().atZone(ZoneId.systemDefault()).toInstant())));
            horizontalContentList.add(keyName3);
            JSONObject keyName4 = new JSONObject();
            keyName4.put("keyname", keyNameString4);
            keyName4.put("value", valueString4);
            horizontalContentList.add(keyName4);
            templateCard.put("horizontal_content_list", horizontalContentList);

            List<JSONObject> jumpList = new ArrayList<>();
            JSONObject jumpList1 = new JSONObject();
            jumpList1.put("type", 1);
            jumpList1.put("title", "跳转运营管理后台");
            jumpList1.put("url", odsUrl + "/#/scm/admin/product/apply?auditStatus=" + URLUtil.encode(auditStatus + ""));
            jumpList.add(jumpList1);
            templateCard.put("jump_list", jumpList);

            JSONObject cardAction = new JSONObject();
            cardAction.put("type", 1);
            cardAction.put("url", odsUrl + "/#/scm/admin/product/apply?auditStatus=" + URLUtil.encode(auditStatus + ""));
            templateCard.put("card_action", cardAction);
            qywxParam.put("template_card", templateCard);
            triggerMsgRequest.setQywxParam(qywxParam);

            try {
                log.error("商品ERP编码申请业务消息发送入参：" + JSONObject.toJSONString(triggerMsgRequest));
                msgClient.triggerMsg(triggerMsgRequest);
            } catch (Exception e) {
                log.error("商品ERP编码申请业务消息发送异常：" + e);
            }
        } else {
            log.error("商品ERP编码申请业务消息发送异常：提报人或需求人为空");
        }
    }

}
