package com.purchase.product.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;

/**
 * @author jidonglin
 * @Description: 来源zydmall商品同步实体类
 * @date 2022/9/28  13:23
 */
@Data
@ApiModel(value = "ZydmallProductSync", description = "来源zydmall商品同步实体类")
@Table(name = "zydmall_product_sync")
public class ZydmallProductSync extends BaseCorpModel {

    public static final String ID = "id";
    public static final String FIRST_LEVEL_CATA_NAME = "firstLevelCataName";
    public static final String SECOND_LEVEL_CATA_NAME = "secondLevelCataName";
    public static final String THREE_LEVEL_CATA_NAME = "threeLevelCataName";
    public static final String BRAND_NAME = "brandName";
    public static final String PROP_NAME = "propName";
    public static final String PRODUCT_TYPE = "productType";
    public static final String SKU_CODE = "skuCode";
    public static final String PRODUCT_CODE = "productCode";
    public static final String SUPPLY_PRICE = "supplyPrice";
    public static final String PURCHASE_PRICE = "purchasePrice";
    public static final String PRICE = "price";
    public static final String SUGGEST_PRICE = "suggestPrice";
    public static final String STOCK = "stock";
    public static final String DELIVERY_DATE = "deliveryDate";
    public static final String UNIT = "unit";
    public static final String WEIGHT = "weight";
    public static final String IS_ONSALE = "isOnsale";
    public static final String PUBLIC_PRODUCT_ID = "publicProductId";

    @ApiModelProperty("公海产品id")
    private Long publicProductId;
    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;
    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;
    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;
    @ApiModelProperty("商品品牌名称")
    private String brandName;
    @ApiModelProperty("商品系列名称")
    private String propName;
    @ApiModelProperty("规格json数据")
    private String specData;
    @ApiModelProperty("产品型号")
    private String productType;
    @ApiModelProperty("订货号")
    private String skuCode;
    @ApiModelProperty("商品编号")
    private String productCode;
    @ApiModelProperty("供货价")
    private BigDecimal supplyPrice;
    @ApiModelProperty("慧采价")
    private BigDecimal purchasePrice;
    @ApiModelProperty("面价（元）")
    private BigDecimal price;
    @ApiModelProperty("建议销售价")
    private BigDecimal suggestPrice;
    @ApiModelProperty("库存")
    private Integer stock;
    @ApiModelProperty("货期")
    private String deliveryDate;
    @ApiModelProperty("计量单位")
    private String unit;
    @ApiModelProperty("重量")
    private String weight;
    @ApiModelProperty("商品图片（多个用@分隔）")
    private String productPicName;
    @ApiModelProperty("视频详情")
    private String productVedioName;
    @ApiModelProperty("是否上下架（Y=上架，N=下架）")
    private String isOnsale;
    @ApiModelProperty("商品详情")
    private String productContent;
    @ApiModelProperty("样本（多个用@分割）")
    private String sample;
    @Transient
    private String createdByName;
    @Transient
    private String updatedByName;
    @ApiModelProperty("erp产品id")
    private String erpProductId;
    @ApiModelProperty("产品来源")
    private String productSrc;
    @ApiModelProperty("erp编码")
    private String productErpCode;
    @ApiModelProperty("是否已更新公海（Y=是，N=否）")
    private String isUpdateCommon;
    @ApiModelProperty("主采购组")
    private String ifsMainProcurement;
    @ApiModelProperty("是否展示系列")
    private String isShowProp;
    @ApiModelProperty("产品属性11-统计大类")
    private String ifsStBcata;
    @ApiModelProperty("产品属性10-统计小类")
    private String ifsStScata;
    @ApiModelProperty("供应商分货")
    private String ifsSupplierDistribution;
}
