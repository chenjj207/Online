package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseProductApplyBatch;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author zhangcheng
 * @version 1.0
 * @since 2022-08-10
 */
public interface PurchaseProductApplyBatchMapper extends QguBaseMapper<PurchaseProductApplyBatch> {

    /**
     * 根据实体字段条件获取对应实体集合--分页公用（分页由PageHelper实现-解耦合）
     *
     * @param batch 实体对象
     * @return 对象集合
     */
    List<PurchaseProductApplyBatch> search(@Param("batch") PurchaseProductApplyBatch batch);
}
