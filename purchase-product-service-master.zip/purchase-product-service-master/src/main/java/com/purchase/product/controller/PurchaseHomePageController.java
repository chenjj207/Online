package com.purchase.product.controller;


import com.purchase.product.model.PurchaseHomePage;
import com.purchase.product.model.PurchaseProductApply;
import com.purchase.product.service.BusinessProductService;
import com.purchase.product.service.PurchaseHomePageService;
import com.purchase.product.service.PurchaseProductApplyService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 首页惠采商品服务提供类
 *
 * @author jdl
 * @version 1.0
 * @since 2024-07-01
 */
@RestController
@RequestMapping(value = "/purchaseHomePage")
@Api(value = "PurchaseHomePageController", tags = {"首页惠采商品服务提供类"})
@Slf4j
public class PurchaseHomePageController {

    @Autowired
    private PurchaseHomePageService purchaseHomePageService;


    @GetMapping(value = "/queryAll")
    @ApiOperation(value = "查询惠采首页数据")
    public JsonResult<List<PurchaseHomePage>> queryAll() {
        List<PurchaseHomePage> purchaseHomePages = purchaseHomePageService.queryAll();
        return new JsonResult<>(true, "查询成功", purchaseHomePages);
    }
}
