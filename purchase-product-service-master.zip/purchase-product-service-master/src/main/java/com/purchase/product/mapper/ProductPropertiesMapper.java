package com.purchase.product.mapper;

import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import com.purchase.product.model.ProductProperties;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author auto
 * @version 1.0
 * @since 2022-11-04 11:46:23
 */
public interface ProductPropertiesMapper extends QguBaseMapper<ProductProperties> {
    
    /**
     * 根据实体字段条件获取对应实体集合--分页公用（分页由PageHelper实现-解耦合）
     *
     * @param ProductProperties 实体对象
     * @return 对象集合
     */
    List<ProductProperties> search(@Param("con") ProductProperties ProductProperties);
}
