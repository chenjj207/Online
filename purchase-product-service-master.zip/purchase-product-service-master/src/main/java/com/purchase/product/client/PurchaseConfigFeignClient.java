package com.purchase.product.client;

import com.alibaba.fastjson.JSONObject;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@FeignClient(value = "purchase-config-service", path = "/PurchaseConfigFeign", fallbackFactory = PurchaseConfigFeignClient.PurchaseConfigFeignClientHystrix.class)
public interface PurchaseConfigFeignClient {

    @PostMapping(value = "/cata-add")
    Integer cataAdd(@RequestParam String firstCataAddDTO, @RequestParam String secondCataAddDTO, @RequestParam String supplierId, @RequestParam String applyNo);

    @Slf4j
    @Component
    class PurchaseConfigFeignClientHystrix implements FallbackFactory<PurchaseConfigFeignClient> {
        @Override
        public PurchaseConfigFeignClient create(Throwable throwable) {
            return new PurchaseConfigFeignClient() {

                @Override
                public Integer cataAdd(@RequestParam String firstCataAddDTO, @RequestParam String secondCataAddDTO, @RequestParam String supplierId, @RequestParam String applyNo) {
                    return null;
                }
            };
            }
        }
}
