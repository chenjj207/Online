package com.purchase.product.mapper;

import com.alibaba.fastjson.JSONObject;
import com.purchase.model.dto.CommonProductDto;
import com.purchase.product.dto.BusinessProductListDto;
import com.purchase.product.dto.PurchaseCommonProductDto;
import com.purchase.product.model.PurchaseHomePage;
import com.purchase.product.model.PurchaseProductApply;
import com.purchase.product.vo.BusinessProductListVo;
import com.purchase.product.vo.PurchaseProductApplyVo;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author jdl
 * @version 1.0
 * @since 2024-07-01
 */
public interface PurchaseHomePageMapper extends QguBaseMapper<PurchaseHomePage> {


    List<PurchaseHomePage> selectByCon();

}
