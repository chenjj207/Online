package com.purchase.product.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;

@Getter
@Setter
@ToString
@ApiModel(value = "SupplierProductProperty", description = "供应商产品附属属性表")
@Table(name = "t_pd_supplier_product_property")
public class SupplierProductProperty extends BaseCorpModel {

    public static final String STORE_CATA_ID = "storeCataId";
    public static final String APPLY_ID = "applyId";
    public static final String PRODUCT_ID = "productId";


    @ApiModelProperty(value = "申请ID")
    private Long applyId;

    @ApiModelProperty(value = "产品ID")
    private Long productId;

    @ApiModelProperty(value = "店铺分类id")
    private Integer storeCataId;


}
