package com.purchase.product.dto.oss;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @ClassName: OssResourceDto
 * @Description: oss资源数据-自定义实体
 * @author zhangcheng
 * @Date: 2022-08-10
 **/
@Data
@ApiModel("oss资源数据-自定义实体")
public class OssResourceDto {
    @ApiModelProperty("用于分页标记oss位置传参")
    private String nextContinuationToken;
    @ApiModelProperty("列表数据")
    private List<OssResourceSubDto> list;
    @ApiModelProperty("是否到底，false还有分页")
    private boolean isTruncated;

    @Data
    public static class OssResourceSubDto{
        @ApiModelProperty("文件名称")
        private String fileName;
        @ApiModelProperty("文件大小,单位bytes")
        private Long fileSize;
        @ApiModelProperty("文件类型")
        private String fileType;
        @ApiModelProperty("缩略图")
        private String fileSmallImg;
        @ApiModelProperty("最后修改时间-文件夹没有该属性")
        private String lastUpdateTime;
        @ApiModelProperty("传参的path")
        private String path;
        @ApiModelProperty("下载url")
        private String url;
    }
}
