package com.purchase.product.client;

import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.CommonResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @Description: 任务中心-对外服务接口
 * @Author: loine
 * @Date: 2024/12/27 9:40
 **/
@FeignClient(value = "purchase-task")
public interface TaskClient {

    /**
     * 任务详情
     *
     * @return
     */
    @PostMapping("/feign/task-manage/detail")
    JSONObject taskDetail(@RequestBody JSONObject object);

    /**
     * 任务更新
     *
     * @return
     */
    @PostMapping("/feign/task-manage/update")
    CommonResponse taskUpdate(@RequestBody JSONObject object);
}
