package com.purchase.product.controller.oss;

import com.purchase.product.dto.oss.LevelNameDto;
import com.purchase.product.model.PurchaseCataBrandProp;
import com.purchase.product.service.PurchaseCataBrandPropService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.Example;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangkang
 * Date :2022/8/16
 * Version :1.0
 */
@RestController
@RequestMapping(value = "/cataBrandProp")
@Api(value = "PurchaseCataBrandPropController", tags = {"后台管理-条件查询联动"})
public class PurchaseCataBrandPropController {
    @Resource
    private PurchaseCataBrandPropService purchaseCataBrandPropService;

    @GetMapping(value = "/listBrand")
    @ApiOperation(value = "品牌")
    public JsonResult<List<LevelNameDto>> listBrand(String firstLevelCataName,
                                                    String secondLevelCataName,
                                                    String threeLevelCataName,
                                                    String brandName,
                                                    String isAudit,
                                                    @ApiParam("产品状态（0：待审核,1：销售中，2：仓库中， 3：推荐商品使用）") Integer tab) {
        return new JsonResult<>(true, "查询成功", purchaseCataBrandPropService.listBrand(firstLevelCataName,
                secondLevelCataName, threeLevelCataName, brandName, isAudit,tab));
    }

    @GetMapping(value = "/listProp")
    @ApiOperation(value = "系列")
    public JsonResult<List<LevelNameDto>> listProp(String firstLevelCataName,
                                                   String secondLevelCataName,
                                                   String threeLevelCataName,
                                                   String brandName,
                                                   String propName,
                                                   String isAudit,
                                                   @ApiParam("产品状态（0：待审核,1：销售中，2：仓库中， 3：推荐商品使用）") Integer tab) {
        return new JsonResult<>(true, "查询成功", purchaseCataBrandPropService.listProp(firstLevelCataName,
                secondLevelCataName, threeLevelCataName, brandName, propName, isAudit,tab));
    }

    @GetMapping(value = "/treeList")
    @ApiOperation(value = "获取分类树")
    public JsonResult<List<LevelNameDto>> listAll(String isAudit,@ApiParam("产品状态（0：待审核,1：销售中，2：仓库中， 3：推荐商品使用）") Integer tab) {
        return new JsonResult<>(true, "查询成功", purchaseCataBrandPropService.getTree(isAudit,tab));
    }
}
