package com.purchase.product.service;


import com.purchase.model.dto.DetailResponse;
import com.purchase.product.conf.CommonOssConf;
import com.purchase.product.mapper.PurchaseHomePageMapper;
import com.purchase.product.model.*;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;


/**
 * PurchaseHomePageService 服务提供类
 *
 * @author jdl
 * @Date: 2024-07-01
 */
@Service
@Slf4j
public class PurchaseHomePageService extends BaseServiceImpl<PurchaseHomePage> {

    @Resource
    PurchaseHomePageMapper purchaseHomePageMapper;
    @Resource
    private CommonOssConf commonOssConf;


    public List<PurchaseHomePage> queryAll() {
        List<PurchaseHomePage> purchaseHomePages = purchaseHomePageMapper.selectByCon();
        if (CollectionUtils.isNotEmpty(purchaseHomePages)){
            for (PurchaseHomePage p : purchaseHomePages) {
                if (StringUtils.equals(p.getType(), "2")){
                    if (p.getProductId() != null){
                        String[] commonCatalogs = p.getCataName().split(" ");
                        String filePath = "product/image" + "/" + p.getBrandName() + "/" + commonCatalogs[0] +
                                "/" + commonCatalogs[1] + "/" + commonCatalogs[2] +
                                "/" + p.getBrandName() + "_" + commonCatalogs[0]
                                + "_" + commonCatalogs[1]
                                + "_" + commonCatalogs[2] + "_" + p.getPropName();
                        if (StringUtils.isNotEmpty(p.getProductPicName())){
                            p.setProductImgUrl(commonOssConf.getOssUrl() + filePath + "/产品主图/" + p.getProductPicName().split("@")[0] + ".jpg");
                        }

                        p.setBrandImgUrl(commonOssConf.getOssUrl() + "product/brand/" + p.getBrandName() + "/" + p.getBrandName() + "logo.png");
                    }
                }else if (StringUtils.equals(p.getType(), "3")){
                    p.setBrandImgUrl(commonOssConf.getOssUrl() + "product/brand/" + p.getDetailContent() + "/" + p.getDetailContent() + "logo.png");
                }
            }
        }
        return purchaseHomePages;
    }
}
