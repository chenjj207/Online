package com.purchase.product.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * 慧采_产品申请批次 model
 *
 * @author auto
 * @version 1.0
 * @since 2022-08-16
 */
@Getter
@Setter
@ToString
@ApiModel(value = "PurchaseProductApplyBatch", description = "慧采_产品申请批次")
@Table(name = "t_pd_purchase_product_apply_batch")
public class PurchaseProductApplyBatch extends BaseCorpModel {

    public static final String BATCH_NO = "batchNo";
    public static final String FILE_URL = "fileUrl";
    public static final String TYPE = "type";

    /**
     * 批次编号
     */
    @ApiModelProperty(value = "批次编号")
    private String batchNo;

    /**
     * 文件地址
     */
    @ApiModelProperty(value = "文件地址")
    private String fileUrl;

    /**
     * 类型（1=单个添加，2=批量添加）
     */
    @ApiModelProperty(value = "类型（1=单个添加，2=批量添加）")
    private Integer type;
    
    @Transient
    private String createdByName;

    @Transient
    private String updatedByName; 
}
