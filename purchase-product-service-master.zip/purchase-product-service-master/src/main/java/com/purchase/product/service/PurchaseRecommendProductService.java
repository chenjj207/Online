package com.purchase.product.service;

import cn.hutool.core.bean.BeanUtil;
import com.github.pagehelper.PageHelper;
import com.purchase.exception.ExceptionDictionary;
import com.purchase.product.dto.BusinessRecommendProductListDto;
import com.purchase.product.dto.PurchaseRecommendProductAddDTO;
import com.purchase.product.mapper.PurchaseRecommendProductMapper;
import com.purchase.product.model.PurchaseRecommendProduct;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author jidonglin
 * @Description:
 * @date 2024/1/11  13:33
 */
@Service
@Slf4j
public class PurchaseRecommendProductService extends BaseServiceImpl<PurchaseRecommendProduct> {

    @Resource
    private PurchaseRecommendProductMapper purchaseRecommendProductMapper;

    @Transactional
    public List<String> add(PurchaseRecommendProductAddDTO purchaseRecommendProductAddDTO){
        String supplierId = (String) ContextHandler.get("supplierId");
        PurchaseRecommendProduct purchaseRecommendProductDelete = new PurchaseRecommendProduct();
        purchaseRecommendProductDelete.setSupplierId(supplierId);
        purchaseRecommendProductMapper.delete(purchaseRecommendProductDelete);

        if ((purchaseRecommendProductAddDTO.getProductIds().size()) > 8){
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "只能添加8个推荐商品");
        }
        List<PurchaseRecommendProduct> purchaseRecommendProductList = new ArrayList<>();
        for (Long productId : purchaseRecommendProductAddDTO.getProductIds()){
            PurchaseRecommendProduct purchaseRecommendProduct1 = new PurchaseRecommendProduct();
            purchaseRecommendProduct1.setId(IDUtils.getUUID19());
            purchaseRecommendProduct1.setProductId(productId);
            purchaseRecommendProduct1.setSupplierId(supplierId);
            purchaseRecommendProduct1.setCreatedAt(LocalDateTime.now());
            purchaseRecommendProduct1.setCreatedBy(ContextHandler.getUserId());
            purchaseRecommendProduct1.setCorpCode(ContextHandler.getCorpCode());
            purchaseRecommendProductList.add(purchaseRecommendProduct1);
        }

        return this.batchInsert(purchaseRecommendProductList);
    }

    public String remove(String id){
        int i = purchaseRecommendProductMapper.deleteByPrimaryKey(id);
        if (i == 0){
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "商品信息不存在，请重新处理");
        }else {
            return "删除成功";
        }
    }

    public Page<PurchaseRecommendProduct> searchRecommendProduct(BusinessRecommendProductListDto businessRecommendProductListDto) {
        Page<PurchaseRecommendProduct> page = new Page<>();
        page.setPageNum(BeanUtil.isEmpty(businessRecommendProductListDto.getPageNum()) ? 1 : businessRecommendProductListDto.getPageNum());
        page.setPageSize(BeanUtil.isEmpty(businessRecommendProductListDto.getPageSize()) ? 12 : businessRecommendProductListDto.getPageSize());
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        String supplierId = (String) ContextHandler.get("supplierId");
        List<PurchaseRecommendProduct> purchaseRecommendProducts = purchaseRecommendProductMapper.selectBusinessRecommendProductList(businessRecommendProductListDto, supplierId);
        page = new Page<>(purchaseRecommendProducts);
        return page;
    }

}
