package com.purchase.product.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.util.List;

/**
 * @Description:
 * @Author: loine
 * @Date: 2024/10/14 16:29
 **/
@Data
@ApiModel("慧采SCM供应商产品申请-入参")
public class PurchaseScmProductApplyDto {

    @Data
    @ApiModel("基本-入参")
    public static class BaseDto {
        @NotBlank(message = "id不可为空")
        @ApiModelProperty("主键id")
        private String id;
    }

    @Data
    @ApiModel("供应商-搜索-入参")
    public static class SupplierSearchDto {
        @ApiModelProperty("分页页数")
        private Integer pageNum;
        @ApiModelProperty("分页记录数量")
        private Integer pageSize;

        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回，注意如果要待总部审核时传23）")
        private Integer auditStatus;

        @ApiModelProperty("申请编号列表")
        private List<String> applyNoList;
        @ApiModelProperty("订货号/物料号列表")
        private List<String> skuCodeList;
        @ApiModelProperty("产品型号列表")
        private List<String> productTypeList;
        @ApiModelProperty("商品编码列表")
        private List<String> productCodeList;
        @ApiModelProperty("审核类型（1=商品新增，2=资料修改，3=价格修改，4=资料价格修改，5=图片修改）")
        private String auditType;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("系列名称")
        private String propName;

        @ApiModelProperty("规格、规格值数组")
        private List<SpecDto> specNameValues;

        @ApiModelProperty("包含的主键ids（全部传all）")
        private List<String> ids;
        @ApiModelProperty("不包含的主键ids")
        private List<String> notInIds;

        @ApiModelProperty("导出的列字段")
        private List<String> exportTitleFields;
        @ApiModelProperty("导出的列名称")
        private List<String> exportTitleTexts;
    }

    @Data
    @ApiModel("供应商-随机商品详情-入参")
    public static class SupplierRandomDetailDto {
        @NotNull(message = "分类不可为空")
        @ApiModelProperty("分类id")
        private Long cataId;
        @NotNull(message = "品牌不可为空")
        @ApiModelProperty("品牌id")
        private Long brandId;
        @ApiModelProperty("系列id")
        private Long propId;
    }

    @Data
    @ApiModel("供应商-校验是否已经申请过-入参")
    public static class SupplierCheckIsApplyDto {
        @ApiModelProperty("产品型号")
        @NotBlank(message = "产品型号不可为空")
        private String productType;
    }

    @Data
    @ApiModel("供应商-下载导入模板-入参")
    public static class SupplierDownloadImportTemplateDto {
        @ApiModelProperty("一级分类名称")
        @NotBlank(message = "一级分类名称不可为空")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        @NotBlank(message = "二级分类名称不可为空")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        @NotBlank(message = "三级分类名称不可为空")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        @NotBlank(message = "品牌名称不可为空")
        private String brandName;
        @ApiModelProperty("系列名称")
        private String propName;
        @ApiModelProperty("规格名数组（为了写入导出的excel）")
        private List<String> specNames;
        @ApiModelProperty("类型（1=新增，2=修改）")
        @NotBlank(message = "类型不可为空")
        private String type;
        @ApiModelProperty("入口（1=商品申请，2=我的商品）")
        @NotBlank(message = "入口不可为空")
        private String entrance;
        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回，注意如果要待总部审核时传23）")
        private Integer auditStatus;

        // 切换分类时传
        @ApiModelProperty("旧的一级分类名称")
        private String oldFirstLevelCataName;
        @ApiModelProperty("旧的二级分类名称")
        private String oldSecondLevelCataName;
        @ApiModelProperty("旧的三级分类名称")
        private String oldThreeLevelCataName;
        // 切换品牌时传
        @ApiModelProperty("旧的品牌名称")
        private String oldBrandName;
    }

    @Data
    @ApiModel("供应商-相同型号搜索-入参")
    public static class SupplierSameSearchDto {
        @ApiModelProperty("分页页数")
        private Integer pageNum;
        @ApiModelProperty("分页记录数量")
        private Integer pageSize;

        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回，注意如果要待总部审核时传23）")
        private Integer auditStatus;
        @ApiModelProperty("一级分类名称")
        @NotBlank(message = "一级分类名称不可为空")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        @NotBlank(message = "二级分类名称不可为空")
        private String secondLevelCataName;
        @NotBlank(message = "三级分类名称不可为空")
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        @NotBlank(message = "品牌名称不可为空")
        private String brandName;
        @ApiModelProperty("系列名称")
        private String propName;
        @ApiModelProperty("规格、规格值数组（选中规格）")
        private List<SpecDto> specNameValues;

        @ApiModelProperty("入口（1=商品申请，2=我的商品）")
        @NotBlank(message = "入口不可为空")
        private String entrance;
        @ApiModelProperty("是否审核通过（Y/N）")
        private String isAudit;
        @ApiModelProperty("是否上下架（Y=上架，N=下架）")
        private String isOnsale;
    }

    @Data
    @ApiModel("规格-入参")
    public static class SpecDto {
        @ApiModelProperty("规格名称")
        private String specName;
        @ApiModelProperty("规格值")
        private String specValue;
    }

    @Data
    @ApiModel("供应商-批量撤销-入参")
    public static class SupplierCancelDto extends SupplierSearchDto{
        @ApiModelProperty("审核备注")
        @NotBlank(message = "审核备注不可为空")
        private String auditRemark;
    }

    @Data
    @ApiModel("供应商-我的商品搜索-入参")
    public static class SupplierMySearchDto {
        @ApiModelProperty("分页页数")
        private Integer pageNum;
        @ApiModelProperty("分页记录数量")
        private Integer pageSize;

        @ApiModelProperty("是否上下架（Y=上架，N=下架）")
        private String isOnsale;

        @ApiModelProperty("商品id列表")
        private List<Long> productIdList;
        @ApiModelProperty("订货号/物料号列表")
        private List<String> skuCodeList;
        @ApiModelProperty("产品型号列表")
        private List<String> productTypeList;
        @ApiModelProperty("商品编码列表")
        private List<String> productCodeList;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("系列名称")
        private String propName;

        @ApiModelProperty("规格、规格值数组")
        private List<SpecDto> specNameValues;

        @ApiModelProperty("包含的主键ids（全部传all）")
        private List<String> ids;
        @ApiModelProperty("不包含的主键ids")
        private List<String> notInIds;

        @ApiModelProperty("导出的列字段")
        private List<String> exportTitleFields;
        @ApiModelProperty("导出的列名称")
        private List<String> exportTitleTexts;
    }

    @Data
    @ApiModel("供应商-我的商品上下架-入参")
    public static class SupplierMyOnsaleDto extends SupplierMySearchDto {
        @ApiModelProperty("编辑上下架（Y=上架，N=下架）")
        @NotNull(message = "编辑上下架不可为空")
        private String editOnsale;
        @ApiModelProperty("下架原因")
        private String offsaleReason;
    }

    @Data
    @ApiModel("供应商-发布-入参")
    public static class SupplierPublishDto {
        @ApiModelProperty("发布列表")
        @NotEmpty(message = "列表不可为空")
        @Valid
        private List<SupplierPublishListDto> list;
        @ApiModelProperty("删除的主键ids")
        private List<String> deleteIds;
        @ApiModelProperty("撤销的列表")
        private List<SupplierPublishCancelDto> cancels;
        @ApiModelProperty("入口（1=商品申请，2=我的商品）")
        private String entrance;
        @ApiModelProperty("是否草稿（Y/N，默认N）")
        private String isDraft;
    }

    @Data
    @ApiModel("供应商-发布-草稿-入参")
    public static class SupplierPublishDraftDto {
        @ApiModelProperty("发布列表")
        @NotEmpty(message = "列表不可为空")
        private List<SupplierPublishListDto> list;
        @ApiModelProperty("删除的主键ids")
        private List<String> deleteIds;
    }

    @Data
    @ApiModel("供应商-发布-列表-入参")
    public static class SupplierPublishListDto {
        @ApiModelProperty("主键id")
        private String id;
        @ApiModelProperty("一级分类名称")
        @NotBlank(message = "一级分类名称不可为空")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        @NotBlank(message = "二级分类名称不可为空")
        private String secondLevelCataName;
        @NotBlank(message = "三级分类名称不可为空")
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        @NotBlank(message = "品牌名称不可为空")
        private String brandName;
        @ApiModelProperty("系列名称")
        private String propName;
        @ApiModelProperty("商品物料名称")
        private String materialName;
        @ApiModelProperty("规格json数据")
        @NotBlank(message = "规格不可为空")
        private String specData;
        @ApiModelProperty("产品型号")
        @NotBlank(message = "产品型号不可为空")
        @Length(max = 150, message = "产品型号长度不可超过150")
        private String productType;
        @ApiModelProperty("订货号")
        @Length(max = 150, message = "厂家物料号长度不可超过150")
        private String skuCode;
        @ApiModelProperty("商品编号")
        @Length(max = 50, message = "商品编号长度不可超过50")
        private String productCode;
        @ApiModelProperty("供货价折扣")
        private BigDecimal supplyDiscount;
        @ApiModelProperty("供货价")
        private BigDecimal supplyPrice;
        @ApiModelProperty("面价")
        private BigDecimal price;
        @ApiModelProperty("建议销售价折扣")
        private BigDecimal suggestDiscount;
        @ApiModelProperty("建议销售价")
        private BigDecimal suggestPrice;
        @ApiModelProperty("库存（1=现货，0=订货）")
        @NotNull(message = "库存不可为空")
        private Integer stock;
        @ApiModelProperty("货期")
        @NotBlank(message = "交货期不可为空")
        @Length(max = 10, message = "交货期长度不可超过10")
        private String deliveryDate;
        @ApiModelProperty("计量单位")
        @NotBlank(message = "单位不可为空")
        @Length(max = 10, message = "单位长度不可超过10")
        private String unit;
        @ApiModelProperty("重量")
        private String weight;
        @ApiModelProperty("最小起订量")
        @Min(value = 1, message = "最小起订量不得小于1")
        @Max(value = 9999, message = "最小起订量不得超过9999")
        private Integer minimunRequire;
        @ApiModelProperty("商品图片（多个用@分隔）")
        private String productPicName;
        @ApiModelProperty("视频详情（多个用@分隔）")
        private String productVideoName;
        @ApiModelProperty("样本详情（多个用@分隔）")
        private String productSampleName;
        @ApiModelProperty("产品详情图名称（多个用@分隔）")
        private String productContentPicName;
    }

    @Data
    @ApiModel("供应商-发布-撤销-入参")
    public static class SupplierPublishCancelDto {
        @ApiModelProperty("撤销的主键id")
        private String id;
        @ApiModelProperty("审核备注")
        private String auditRemark;
    }

    @Data
    @ApiModel("供应商-获取引导启用状态-入参")
    public static class SupplierGetGuideDto {
        @ApiModelProperty("引导分类（1=商品申请发布）")
        @NotNull(message = "引导分类不可为空")
        private String type;
    }

    @Data
    @ApiModel("后台-搜索-入参")
    public static class AdminSearchDto {
        @ApiModelProperty("分页页数")
        private Integer pageNum;
        @ApiModelProperty("分页记录数量")
        private Integer pageSize;

        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回，注意如果要待总部审核时传23）")
        private Integer auditStatus;

        @ApiModelProperty("申请编号列表")
        private List<String> applyNoList;
        @ApiModelProperty("订货号/物料号列表")
        private List<String> skuCodeList;
        @ApiModelProperty("产品型号列表")
        private List<String> productTypeList;
        @ApiModelProperty("商品编码列表")
        private List<String> productCodeList;

        @ApiModelProperty("审核类型（1=商品新增，2=资料修改，3=价格修改，4=资料价格修改，5=图片修改）")
        private String auditType;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("系列名称")
        private String propName;
        @ApiModelProperty("规格、规格值数组（选中规格）")
        private List<SpecDto> specNameValues;

        @ApiModelProperty("子公司id")
        private String companyId;
        @ApiModelProperty("供应商id")
        private String supplierId;

        @ApiModelProperty("包含的主键ids")
        private List<String> ids;
        @ApiModelProperty("不包含的主键ids")
        private List<String> notInIds;
    }

    @Data
    @ApiModel("后台-相同型号搜索-入参")
    public static class AdminSameSearchDto {
        @ApiModelProperty("分页页数")
        private Integer pageNum;
        @ApiModelProperty("分页记录数量")
        private Integer pageSize;

        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回，注意如果要待总部审核时传23）")
        private Integer auditStatus;
        @ApiModelProperty("一级分类名称")
        @NotBlank(message = "一级分类名称不可为空")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        @NotBlank(message = "二级分类名称不可为空")
        private String secondLevelCataName;
        @NotBlank(message = "三级分类名称不可为空")
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        @NotBlank(message = "品牌名称不可为空")
        private String brandName;
        @ApiModelProperty("系列名称")
        private String propName;
        @ApiModelProperty("规格、规格值数组（选中规格）")
        private List<SpecDto> specNameValues;

        @ApiModelProperty("供应商id")
        private String supplierId;

        @ApiModelProperty("是否审核通过（Y/N）")
        private String isAudit;
    }

    @Data
    @ApiModel("后台-商品审核页面异步任务-入参")
    public static class AdminTaskDto {
        // 公共参数
        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回，注意如果要待总部审核时传23）")
        private Integer auditStatus;
        @ApiModelProperty("申请编号列表")
        private List<String> applyNoList;
        @ApiModelProperty("订货号/物料号列表")
        private List<String> skuCodeList;
        @ApiModelProperty("产品型号列表")
        private List<String> productTypeList;
        @ApiModelProperty("商品编码列表")
        private List<String> productCodeList;
        @ApiModelProperty("审核类型（1=商品新增，2=资料修改，3=价格修改，4=资料价格修改，5=图片修改）")
        private String auditType;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("子公司id")
        private String companyId;
        @ApiModelProperty("供应商id")
        private String supplierId;
        @ApiModelProperty("包含的主键ids（全部传all）")
        private List<String> ids;
        @ApiModelProperty("不包含的主键ids")
        private List<String> notInIds;

        // 审核通过
        @ApiModelProperty("通过类型（1：仅上架SCM商品池，2：上架SCM商品池和zydmall商城）")
        private String approveType;

        // 审核驳回
        @ApiModelProperty("审核备注")
        private String auditRemark;

        // 设置调货价
        @ApiModelProperty("调货价折扣")
        private BigDecimal distributeDiscount;
        @ApiModelProperty("调货价折扣 计算方式（乘：*、除：/）")
        private String distributeCalcWay;
    }

    @Data
    @ApiModel("审核考核统计导出-入参")
    public static class AuditSumExportDto {
        @ApiModelProperty("创建时间开始")
        private String startDate;
        @ApiModelProperty("创建时间截止")
        private String endDate;
    }
}
