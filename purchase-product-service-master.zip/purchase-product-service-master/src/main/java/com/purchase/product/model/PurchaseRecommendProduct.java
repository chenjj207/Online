package com.purchase.product.model;

import com.purchase.product.dto.oss.LevelNameDto;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.util.List;


@Data
@ApiModel(value = "PurchaseRecommendProduct", description = "供应商推荐产品表")
@Table(name = "t_pd_purchase_recommend_product")
public class PurchaseRecommendProduct extends BaseCorpModel {

    public static final String SUPPLIER_ID = "supplierId";
    public static final String PRODUCT_ID = "productId";

    /**
     * 公海产品id
     */
    @ApiModelProperty(value = "公海产品id")
    private Long productId;

    /**
     * 供应商id
     */
    @ApiModelProperty(value = "供应商id")
    private String supplierId;

    @Transient
    private String brandName;
    @Transient
    private String propName;
    @Transient
    private String productCode;
    @Transient
    private String materialName;
    @Transient
    private String skuCode;
    @Transient
    private String productType;
    @Transient
    private BigDecimal purchasePrice;
    @Transient
    private BigDecimal price;
    @Transient
    private BigDecimal suggestPrice;
    @Transient
    private Integer stock;
    @Transient
    private String deliveryDate;
    @Transient
    private String firstLevelCataName;
    @Transient
    private String secondLevelCataName;
    @Transient
    private String threeLevelCataName;

}
