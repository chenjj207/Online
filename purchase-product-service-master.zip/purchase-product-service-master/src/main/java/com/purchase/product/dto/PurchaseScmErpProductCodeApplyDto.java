package com.purchase.product.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @Description:
 * @Author: loine
 * @Date: 2026/3/10 16:02
 */
@Data
@ApiModel("慧采SCM_ERP产品编码申请-入参")
public class PurchaseScmErpProductCodeApplyDto {

    @Data
    @ApiModel("基本-入参")
    public static class ErpBaseDto {
        @ApiModelProperty("主键id")
        @NotBlank(message = "id不可为空")
        private String id;
    }

    @Data
    @ApiModel("后台-搜索-入参")
    public static class ErpAdminSearchDto {
        @ApiModelProperty("分页页数")
        private Integer pageNum;
        @ApiModelProperty("分页记录数量")
        private Integer pageSize;
        @ApiModelProperty("审核状态（0=待提交，1=待资料审核，2=待新增审核，3=建编码中，4=通过，5=驳回")
        private Integer auditStatus;
        @ApiModelProperty("关键字")
        private String key;
        @ApiModelProperty("产地")
        private String productArea;
        @ApiModelProperty("提报人的用户id")
        private String createUserId;
        @ApiModelProperty("创建时间（起始，格式：yyyy-MM-dd HH:mm:ss）")
        private String createdTimeStart;
        @ApiModelProperty("创建时间（截止，格式：yyyy-MM-dd HH:mm:ss）")
        private String createdTimeEnd;
        @ApiModelProperty("包含的主键ids（全部传all）")
        private List<String> ids;
        @ApiModelProperty("不包含的主键ids")
        private List<String> notInIds;
    }

    @Data
    @ApiModel("后台-发布-入参")
    public static class ErpPublishDto {
        @ApiModelProperty("主键id")
        private String id;
        @ApiModelProperty("来源（1：手工申请，2：报价申请）")
        @NotBlank(message = "来源不可为空")
        private String source;
        @ApiModelProperty("供应商品牌")
        @NotBlank(message = "供应商品牌不可为空")
        private String supplierBrand;
        @ApiModelProperty("产品型号")
        @NotBlank(message = "产品型号不可为空")
        @Length(max = 500, message = "产品型号过长")
        private String productType;
        @ApiModelProperty("订货号")
        @Length(max = 200, message = "订货号过长")
        private String skuCode;
        @ApiModelProperty("参考编码")
        private String referenceCode;
        @ApiModelProperty("产品凭证（多个@隔开）")
        private String productVoucher;
        @ApiModelProperty("物料名称")
        @NotBlank(message = "产品名称不可为空")
        private String materialName;
        @ApiModelProperty("产地")
        @NotBlank(message = "产地不可为空")
        private String productArea;
        @ApiModelProperty("单位")
        @NotBlank(message = "单位不可为空")
        private String unit;
        @ApiModelProperty("产品属性2-品牌")
        @NotBlank(message = "产地不可为空")
        private String sifsBrand;
        @ApiModelProperty("产品属性3-产品大类")
        @NotBlank(message = "产品属性3-产品大类不可为空")
        private String sifsPdBcata;
        @ApiModelProperty("产品属性8-商品小类")
        @NotBlank(message = "产品属性8-商品小类不可为空")
        private String sifsPdScata;
        @ApiModelProperty("产品属性11-统计大类")
        @NotBlank(message = "产品属性11-统计大类不可为空")
        private String sifsStBcata;
        @ApiModelProperty("产品属性10-统计小类")
        @NotBlank(message = "产品属性10-统计小类不可为空")
        private String sifsStScata;
        @ApiModelProperty("产品属性6-产品系列")
        @NotBlank(message = "产品属性6-产品系列不可为空")
        private String sifsProp;
        @ApiModelProperty("产品属性4-产品细分")
        @NotBlank(message = "产品属性4-产品细分不可为空")
        private String sifsSubversion;
        @ApiModelProperty("产品属性12-主采购组")
        @NotBlank(message = "产品属性12-主采购组不可为空")
        private String sifsMainProcurement;
        @ApiModelProperty("产品属性5-供应商属性")
        @NotBlank(message = "产品属性5-供应商属性不可为空")
        private String sapplerAttribute;
        @ApiModelProperty("产品属性14-主配套分类")
        @NotBlank(message = "产品属性14-主配套分类不可为空")
        private String smainSubCat;
        @ApiModelProperty("税务分类编码（关联税务分类关系表）")
        @NotBlank(message = "税务分类编码不可为空")
        private String taxCataCode;
        @ApiModelProperty("税务分类名称")
        @NotBlank(message = "税务分类名称不可为空")
        private String taxCataName;
        @ApiModelProperty("供应商编码（关联供应商对应关系表）")
        @NotBlank(message = "供应商编码不可为空")
        private String supplierCode;
        @ApiModelProperty("需求人所属公司编码")
        private String demandComBm;
        @ApiModelProperty("需求人的用户id")
        private String demandUserId;

        @ApiModelProperty("是否草稿（Y/N，默认N）")
        private String isDraft;
    }

    @Data
    @ApiModel("参考详情-入参")
    public static class ErpReferenceDetailDto {
        @ApiModelProperty("参考编码")
        @NotBlank(message = "参考编码不可为空")
        private String referenceCode;
    }

    @Data
    @ApiModel("ERP产品属性列表-入参")
    public static class ErpProductListDto {
        @ApiModelProperty("属性字段名")
        @NotBlank(message = "属性字段名不可为空")
        private String code;
    }

    @Data
    @ApiModel("驳回-入参")
    public static class ErpRejectDto {
        @ApiModelProperty("主键id")
        @NotBlank(message = "id不可为空")
        private String id;
        @ApiModelProperty("审核备注")
        private String auditRemark;
    }

    @Data
    @ApiModel("日志列表-入参")
    public static class ErpLogListDto {
        @ApiModelProperty("申请编号")
        @NotBlank(message = "申请编号不可为空")
        private String applyNo;
    }

}
