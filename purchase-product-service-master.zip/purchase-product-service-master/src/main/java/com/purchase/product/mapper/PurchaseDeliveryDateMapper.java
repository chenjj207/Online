package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseDeliveryDate;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

/**
 * @Description: 供应商商品货期管理表
 * @Author: loine
 * @Date: 2024/10/16 11:17
 **/
@Mapper
public interface PurchaseDeliveryDateMapper extends BaseMapper<PurchaseDeliveryDate> {

    /**
     * 获取最大的id
     *
     * @Author: loine
     * @Date: 2024/10/17 16:35
     */
    Long getMaxDeliveryId();

    /**
     * 查询是否存在
     *
     * @param supplierId
     * @param deliveryDate
     * @Author: loine
     * @Date: 2024/10/29 11:31
     */
    int selectExist(@Param("supplierId") String supplierId, @Param("deliveryDate") String deliveryDate);
}
