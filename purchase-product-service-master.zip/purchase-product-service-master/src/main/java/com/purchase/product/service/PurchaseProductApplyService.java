package com.purchase.product.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.lang.UUID;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.*;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Maps;
import com.purchase.exception.ExceptionDictionary;
import com.purchase.model.PurchaseProductSync;
import com.purchase.model.Supplier;
import com.purchase.model.dto.CommonProductDto;
import com.purchase.model.dto.DetailResponse;
import com.purchase.model.dto.SpecAndValDTO;
import com.purchase.product.client.EsFeignClient;
import com.purchase.product.client.PublicProductFeignClient;
import com.purchase.product.client.PurchaseUserFeignClient;
import com.purchase.product.conf.CommonOssConf;
import com.purchase.product.conf.OssConf;
import com.purchase.product.dto.ProductAuditDto;
import com.purchase.product.dto.ProductCodeDto;
import com.purchase.product.dto.PurchaseCommonProductDto;
import com.purchase.product.dto.oss.ImportStockVO;
import com.purchase.product.mapper.PurchaseProductApplyMapper;
import com.purchase.product.mapper.SupplierProductPropertyMapper;
import com.purchase.product.model.*;
import com.purchase.product.util.RedisUtils;
import com.purchase.product.vo.PurchaseProductApplyVo;
import com.purchase.utils.date.ZydDateUtils;
import com.purchase.utils.entity.ZydUtils;
import com.purchase.utils.excel.JxlsExcelView;
import com.qgutech.qgyun.dev.client.uc.UcFeignClient;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.common.utils.SqlUtil;
import com.qgutech.qgyun.framework.database.mybatis.helper.CorpHelper;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.io.*;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

/**
 * PurchaseProductApplyService 服务提供类
 *
 * @author zhangcheng
 * @Date: 2022-08-10
 */
@Service
@Slf4j
public class PurchaseProductApplyService extends BaseServiceImpl<PurchaseProductApply> {

    @Resource
    private SupplierProductPropertyMapper supplierProductPropertyMapper;
    @Resource
    private PurchaseProductApplyMapper purchaseProductApplyMapper;
    @Resource
    private PurchaseProductApplyBatchService purchaseProductApplyBatchService;
    @Resource
    private UcFeignClient ucFeignClient;
    @Resource
    EsFeignClient esFeignClient;
    @Autowired
    private RedisTemplate redisTemplate;
    @Resource
    private OssConf ossConf;
    @Resource
    private CommonOssConf commonOssConf;
    //oss的空间地址
    @Value("${oss.ossUrl:}")
    private String ossUrl;
    @Resource
    private PublicProductFeignClient publicProductFeignClient;
    @Resource
    private PurchaseCataBrandPropService purchaseCataBrandPropService;
    @Resource
    private PurchaseUserFeignClient purchaseUserFeignClient;
    @Resource
    private ProductPropertiesService productPropertiesService;

    @Resource
    private SupplierProductPropertyService supplierProductPropertyService;
    /**
     * 组合租户的oss路径
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    public String getOssCorpCode(){
        String supplierCode =(String) ContextHandler.get("supplierCode");
        return "purchase" + (StringUtils.isEmpty(supplierCode) ? "" : "_"+supplierCode) + ossConf.getCorpOssPrex();
    }

    /**
     * 组合租户的oss路径
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    public String getOssCorpCodeTwo(){
        String supplierCode =(String) ContextHandler.get("supplierCode");
        return "purchase" + (StringUtils.isEmpty(supplierCode) ? "" : "_"+supplierCode);
    }


    public List<PurchaseProductApply> listAll() {
        return purchaseProductApplyMapper.selectAll();
    }

    public List<PurchaseProductApply> list(PurchaseProductApply purchaseProductApply) {
        Example example = genConditionExample(purchaseProductApply);
        List<PurchaseProductApply> list = purchaseProductApplyMapper.selectByExample(example);
        return list;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<PurchaseProductApply> search(PurchaseProductApply purchaseProductApply) {
        Assert.notNull(purchaseProductApply, "purchaseProductApply can not be null!");
        Page<PurchaseProductApply> page = new Page<>();
        page.setPageNum(purchaseProductApply.getPageNum());
        page.setPageSize(purchaseProductApply.getPageSize());
        PageHelper.startPage(purchaseProductApply.getPageNum(), purchaseProductApply.getPageSize());
        Example example = genConditionExample(purchaseProductApply);
        List<PurchaseProductApply> list = purchaseProductApplyMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packPurchaseProductApplyData(list);
        return page;
    }

    private Example genConditionExample(PurchaseProductApply model) {
        Example example = new Example(entityClass);
        example.orderBy(PurchaseProductApply.UPDATED_AT).desc();
        Example.Criteria criteria = example.createCriteria();
        String batchNo = model.getBatchNo();
        if (StringUtils.isNotBlank(batchNo)) {
            criteria.andEqualTo(PurchaseProductApply.BATCH_NO, batchNo);
        }

        String isSupply  = model.getIsSupply();
        String supplierId  = (String) ContextHandler.get("supplierId");
        if (StringUtils.isNotBlank(isSupply)) {
            if ("Y".equals(isSupply)) {
                criteria.andEqualTo(PurchaseProductApply.IS_SUPPLY, "Y");
            } else {
                criteria.andEqualTo(PurchaseProductApply.IS_SUPPLY, "N");
                if (StringUtils.isNotEmpty(supplierId)) {
                    criteria.andEqualTo(PurchaseProductApply.SUPPLIER_ID, supplierId);
                }
            }
        }


        String keyword = model.getKeyword();
        if (StringUtils.isNotBlank(keyword)) {
            Example.Criteria criteria1 = example.createCriteria();
            String searchFrom = model.getSearchFrom();
            if (StringUtils.isNotEmpty(searchFrom) && searchFrom.equals("apply")) {
                criteria1.andLike(PurchaseProductApply.PRODUCT_CODE, SqlUtil.asLike(keyword));
            } else {
                criteria1.andLike(PurchaseProductApply.PRODUCT_ERP_CODE, SqlUtil.asLike(keyword));
            }
            criteria1.orLike(PurchaseProductApply.SKU_CODE, SqlUtil.asLike(keyword));
            criteria1.orLike(PurchaseProductApply.PRODUCT_TYPE, SqlUtil.asLike(keyword));
            example.and(criteria1);
        }

        String productCode = model.getProductCode();
        if (StringUtils.isNotBlank(productCode)) {
            criteria.andEqualTo(PurchaseProductApply.PRODUCT_CODE, productCode);
        }

        String productType = model.getProductType();
        if (StringUtils.isNotBlank(productType)) {
            criteria.andEqualTo(PurchaseProductApply.PRODUCT_TYPE, productType);
        }

        String skuCode = model.getSkuCode();
        if (StringUtils.isNotBlank(skuCode)) {
            criteria.andEqualTo(PurchaseProductApply.SKU_CODE, skuCode);
        }

        Integer stock = model.getStock();
        if (null != stock) {
            criteria.andEqualTo(PurchaseProductApply.STOCK, stock);
        }

        String firstLevelCataName = model.getFirstLevelCataName();
        if (StringUtils.isNotBlank(firstLevelCataName)) {
            criteria.andEqualTo(PurchaseProductApply.FIRST_LEVEL_CATA_NAME, firstLevelCataName);
        }

        String secondLevelCataName = model.getSecondLevelCataName();
        if (StringUtils.isNotBlank(secondLevelCataName)) {
            criteria.andEqualTo(PurchaseProductApply.SECOND_LEVEL_CATA_NAME, secondLevelCataName.trim());
        }

        String threeLevelCataName = model.getThreeLevelCataName();
        if (StringUtils.isNotBlank(threeLevelCataName)) {
            criteria.andEqualTo(PurchaseProductApply.THREE_LEVEL_CATA_NAME, threeLevelCataName.trim());
        }

        String brandName = model.getBrandName();
        if (StringUtils.isNotBlank(brandName)) {
            criteria.andEqualTo(PurchaseProductApply.BRAND_NAME, brandName);
        }

        String propName = model.getPropName();
        if (StringUtils.isNotBlank(propName)) {
            if ("999999999".equals(propName) || "暂无数据".equals(propName)) {
                Example.Criteria criteria1 = example.createCriteria();
                criteria1.andEqualTo(PurchaseProductApply.PROP_NAME, "");
                criteria1.orIsNull(PurchaseProductApply.PROP_NAME);
                example.and(criteria1);
            } else {
                criteria.andEqualTo(PurchaseProductApply.PROP_NAME, propName);
            }
        }

        String isOnsale = model.getIsOnsale();
        if (StringUtils.isNotBlank(isOnsale)) {
            criteria.andEqualTo(PurchaseProductApply.IS_ONSALE, isOnsale);
        }

        Integer auditType = model.getAuditType();
        if (null != auditType) {
            criteria.andEqualTo(PurchaseProductApply.AUDIT_TYPE, auditType);
        }

        Integer auditStatus = model.getAuditStatus();
        if (null != auditStatus) {
            criteria.andEqualTo(PurchaseProductApply.AUDIT_STATUS, auditStatus);
        }

        String auditRemark = model.getAuditRemark();
        if (StringUtils.isNotBlank(auditRemark)) {
            criteria.andEqualTo(PurchaseProductApply.AUDIT_REMARK, auditRemark);
        }

        return example;
    }

    /**
     * 分页数据处理
     */
    private void packPurchaseProductApplyData(List<PurchaseProductApply> purchaseProductApplyList) {
        if (CollectionUtils.isEmpty(purchaseProductApplyList)) {
            return;
        }

        List<String> userIds = purchaseProductApplyList.stream().map(PurchaseProductApply::getUpdatedBy).collect(toList());
        List<String> createdIds = purchaseProductApplyList.stream().map(PurchaseProductApply::getCreatedBy).collect(toList());
        userIds.addAll(createdIds);
        userIds = userIds.stream().distinct().collect(toList());
        Map<String, String> userMap = ucFeignClient.getUserIdAndNameMap(userIds);

        List<String> supplierIds = purchaseProductApplyList.stream()
                .filter(apply -> StringUtils.isNotBlank(apply.getSupplierId())).map(PurchaseProductApply::getSupplierId).collect(toList());
        Map<String, Supplier> supplierMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(supplierIds)) {
            supplierMap = purchaseUserFeignClient.mapSupplierByIds(supplierIds);
        }

        for (PurchaseProductApply purchaseProductApply : purchaseProductApplyList) {
            if (MapUtils.isNotEmpty(userMap)) {
                purchaseProductApply.setCreatedByName(userMap.get(purchaseProductApply.getCreatedBy()));
                purchaseProductApply.setUpdatedByName(userMap.get(purchaseProductApply.getUpdatedBy()));

            }

            if (MapUtils.isNotEmpty(supplierMap)) {
                if (StringUtils.isNotEmpty(purchaseProductApply.getSupplierId())) {
                    Supplier supplier = supplierMap.get(purchaseProductApply.getSupplierId());
                    purchaseProductApply.setSupplierName(null == supplier ? null : supplier.getName());
                }
            }
            if (StringUtils.isEmpty(purchaseProductApply.getSupplierId())) {
                purchaseProductApply.setSupplierName("供应链公司");
            }
        }
    }

    private BigDecimal formatBigDecimalData(BigDecimal bigDecimal) {
        if (null != bigDecimal) {
            bigDecimal = bigDecimal.setScale(2,BigDecimal.ROUND_HALF_UP);
        }
        return bigDecimal;
    }

    private void dealBigDecimalData(CommonProductDto apply) {
        if (null != apply) {
            apply.setSupplyPrice(formatBigDecimalData(apply.getSupplyPrice()));
            apply.setPurchasePrice(formatBigDecimalData(apply.getPurchasePrice()));
            apply.setPrice(formatBigDecimalData(apply.getPrice()));
            apply.setSuggestPrice(formatBigDecimalData(apply.getSuggestPrice()));
        }
    }

    private void dealBigDecimalData(PurchaseCommonProductDto apply) {
        if (null != apply) {
            apply.setSupplyPrice(formatBigDecimalData(apply.getSupplyPrice()));
            apply.setPurchasePrice(formatBigDecimalData(apply.getPurchasePrice()));
            apply.setPrice(formatBigDecimalData(apply.getPrice()));
            apply.setSuggestPrice(formatBigDecimalData(apply.getSuggestPrice()));
        }
    }

    private void dealBigDecimalData(PurchaseProductApply apply) {
        if (null != apply) {
            apply.setSupplyPrice(formatBigDecimalData(apply.getSupplyPrice()));
            apply.setPurchasePrice(formatBigDecimalData(apply.getPurchasePrice()));
            apply.setPrice(formatBigDecimalData(apply.getPrice()));
            apply.setSuggestPrice(formatBigDecimalData(apply.getSuggestPrice()));
        }
    }

    /**
     * 通过id获取详情
     */
    @Override
    public PurchaseProductApply get(String id) {
//        PurchaseProductApply purchaseProductApply = super.get(id);
        PurchaseProductApplyVo purchaseProductApply = purchaseProductApplyMapper.getId(id);
        if (null != purchaseProductApply) {
            if (StringUtils.isNotEmpty(purchaseProductApply.getBrandName())){
                String brandUrl = purchaseProductApplyMapper.selectBrandUrl(purchaseProductApply.getBrandName());
                if (StringUtils.isEmpty(brandUrl)){
                    purchaseProductApply.setBrandUrl(commonOssConf.getOssUrl() + "product/brand/" + purchaseProductApply.getBrandName() + "/" + purchaseProductApply.getBrandName() + "logo.png");
                }else {
                    purchaseProductApply.setBrandUrl(brandUrl);
                }
            }
            String createdBy = purchaseProductApply.getCreatedBy();
            String updatedBy = purchaseProductApply.getUpdatedBy();
            List<String> userIds = new ArrayList<>();
            if (StringUtils.isNotEmpty(createdBy)) {
                userIds.add(createdBy);
            }

            if (StringUtils.isNotEmpty(updatedBy)) {
                userIds.add(updatedBy);
            }

            userIds = userIds.stream().distinct().collect(toList());
            Map<String, String> userMap = ucFeignClient.getUserIdAndNameMap(userIds);
            purchaseProductApply.setCreatedByName(userMap.get(createdBy));
            purchaseProductApply.setUpdatedByName(userMap.get(updatedBy));
            if ((null != purchaseProductApply.getAuditType() && 2 == purchaseProductApply.getAuditType())
                && (null != purchaseProductApply.getAuditStatus() && 0 == purchaseProductApply.getAuditStatus())
                && (null != purchaseProductApply.getPublicProductId())) {
                List<PurchaseCommonProductDto> commonProductDtos = publicProductFeignClient
                        .PurchaseProductListById(Collections.singletonList(purchaseProductApply.getPublicProductId()));
                Map<Long,PurchaseCommonProductDto> commonProductDtoMap = new HashMap<>(commonProductDtos.size());
                for (PurchaseCommonProductDto commonProductDto:commonProductDtos) {
                    commonProductDtoMap.put(commonProductDto.getProductId(), commonProductDto);
                }
                PurchaseCommonProductDto commonProductDto = commonProductDtoMap.get(purchaseProductApply.getPublicProductId());
                if (null != commonProductDto) {
                    //添加品牌图链接
                    purchaseProductApply.setBrandUrl(commonProductDto.getBrandUrl());
                    String editColumns = "";
                    if (!compareStr(commonProductDto.getCataNameOne(), purchaseProductApply.getFirstLevelCataName())) {
                        editColumns += "firstLevelCataName,";
                    }
                    if (!compareStr(commonProductDto.getCataNameTwo(), purchaseProductApply.getSecondLevelCataName())) {
                        editColumns += "secondtLevelCataName,";
                    }
                    if (!compareStr(commonProductDto.getCataNameThree(), purchaseProductApply.getThreeLevelCataName())) {
                        editColumns += "threeLevelCataName,";
                    }
                    if (!compareStr(commonProductDto.getBrandName(), purchaseProductApply.getBrandName())) {
                        editColumns += "brandName,";
                    }
                    if (!compareStr(commonProductDto.getPropName(), purchaseProductApply.getPropName())) {
                        editColumns += "propName,";
                    }
                    if (!compareStr(commonProductDto.getSpecData(), purchaseProductApply.getSpecData())) {
                        boolean flag = false;
                        JSONArray newArray = JSONArray.parseArray(purchaseProductApply.getSpecData());
                        JSONArray oldArray = JSONArray.parseArray(commonProductDto.getSpecData());
                        if ((newArray == null && oldArray != null)){
                            if (oldArray.size() != 0){
                                flag = true;
                            }
                        }else if ((newArray != null && oldArray == null)){
                            if (newArray.size() != 0){
                                flag = true;
                            }
                        }else {
                            if (null != newArray && (null == oldArray || newArray.size() != oldArray.size())) {
                                flag = true;
                            }
                            if (null != oldArray && (null == newArray || newArray.size() != oldArray.size())) {
                                flag = true;
                            }
                            if (null != newArray && null != oldArray) {
                                for (Object object : newArray) {
                                    JSONObject obj = (JSONObject) object;
                                    String spec = obj.getString("spec");
                                    String specValue = obj.getString("specValue");
                                    boolean temp = false;
                                    for (Object object1 : oldArray) {
                                        JSONObject obj1 = (JSONObject) object1;
                                        if (spec.equals(obj1.getString("spec")) && specValue.equals(obj1.getString("specValue"))) {
                                            temp = true;
                                        }
                                    }
                                    if (!temp) {
                                        flag = true;
                                    }
                                }
                            }
                        }
                        if (flag) {
                            editColumns += "specData,";
                        }
                    }
                    if(!compareStr(commonProductDto.getMaterialName(),purchaseProductApply.getMaterialName())){
                        editColumns += "materialName,";
                    }
                    if(!compareStr(commonProductDto.getFirstStoreCataName(),purchaseProductApply.getFirstStoreCataName())){
                        editColumns += "firstStoreCataName,";
                    }

                    if(!compareStr(commonProductDto.getSecondStoreCataName(),purchaseProductApply.getSecondStoreCataName())){
                        editColumns += "secondStoreCataName,";
                    }
                    if (!compareStr(commonProductDto.getProductType(), purchaseProductApply.getProductType())) {
                        editColumns += "productType,";
                    }
                    if (!compareStr(commonProductDto.getSkuCode(), purchaseProductApply.getSkuCode())) {
                        editColumns += "skuCode,";
                    }
                    if (!compareStr(commonProductDto.getSupplierProductCode(), purchaseProductApply.getProductCode())) {
                        editColumns += "productCode,";
                    }
                    if (!compareBigDecimal(commonProductDto.getSupplyPrice(), purchaseProductApply.getSupplyPrice())) {
                        editColumns += "supplyPrice,";
                    }
                    if (!compareBigDecimal(commonProductDto.getPurchasePrice(), purchaseProductApply.getPurchasePrice())) {
                        editColumns += "purchasePrice,";
                    }
                    if (!compareBigDecimal(commonProductDto.getPrice(), purchaseProductApply.getPrice())) {
                        editColumns += "price,";
                    }
                    if (!compareBigDecimal(commonProductDto.getSuggestPrice(), purchaseProductApply.getSuggestPrice())) {
                        editColumns += "suggestPrice,";
                    }
                    if ((commonProductDto.getStock() == null ? 0 : commonProductDto.getStock().intValue()) != purchaseProductApply.getStock()) {
                        editColumns += "stock,";
                    }
                    if (!compareStr(commonProductDto.getDeliveryDate(), purchaseProductApply.getDeliveryDate())) {
                        editColumns += "deliveryDate,";
                    }
                    if (!compareStr(commonProductDto.getWeight(), purchaseProductApply.getWeight())) {
                        editColumns += "weight,";
                    }
                    if (!compareStr(commonProductDto.getUnit(), purchaseProductApply.getUnit())) {
                        editColumns += "unit,";
                    }
                    if (!compareStr(commonProductDto.getProductContent(), purchaseProductApply.getProductContent())) {
                        editColumns += "productContent,";
                    }
                    if (!compareStr(commonProductDto.getIsOnsale(), purchaseProductApply.getIsOnsale())) {
                        editColumns += "isOnsale,";
                    }
                    if (!compareStr(commonProductDto.getProductPicName(), purchaseProductApply.getProductPicName())) {
                        editColumns += "productPicName,";
                    }
                    if (!compareStr(commonProductDto.getProductVedioName(), purchaseProductApply.getProductVedioName())) {
                        editColumns += "productVedioName,";
                    }
                    purchaseProductApply.setEditColumns(editColumns);
                }
            }
        }
        dealBigDecimalData(purchaseProductApply);
        return purchaseProductApply;
    }

    public Boolean hasEdit(PurchaseProductApply purchaseProductApply) {
        if (null != purchaseProductApply && null != purchaseProductApply.getPublicProductId()) {
            List<PurchaseCommonProductDto> commonProductDtos = publicProductFeignClient
                    .PurchaseProductListById(Collections.singletonList(purchaseProductApply.getPublicProductId()));
            Map<Long,PurchaseCommonProductDto> commonProductDtoMap = new HashMap<>(commonProductDtos.size());
            for (PurchaseCommonProductDto purchaseCommonProductDto:commonProductDtos) {
                commonProductDtoMap.put(purchaseCommonProductDto.getProductId(), purchaseCommonProductDto);
            }
            PurchaseCommonProductDto commonProductDto = commonProductDtoMap.get(purchaseProductApply.getPublicProductId());
            dealBigDecimalData(commonProductDto);
            if (null != commonProductDto) {
                if (!compareStr(commonProductDto.getCataNameOne(), purchaseProductApply.getFirstLevelCataName())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getCataNameTwo(), purchaseProductApply.getSecondLevelCataName())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getCataNameThree(), purchaseProductApply.getThreeLevelCataName())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getBrandName(), purchaseProductApply.getBrandName())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getPropName(), purchaseProductApply.getPropName())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getSpecData(), purchaseProductApply.getSpecData())) {
                    boolean flag = false;
                    JSONArray newArray = JSONArray.parseArray(purchaseProductApply.getSpecData());
                    JSONArray oldArray = JSONArray.parseArray(commonProductDto.getSpecData());
                    if (null != newArray && (null == oldArray || newArray.size() != oldArray.size())) {
                        flag = true;
                    }
                    if (null != oldArray && (null == newArray || newArray.size() != oldArray.size())) {
                        flag = true;
                    }
                    if (null != newArray && null != oldArray) {
                        for (Object object : newArray) {
                            JSONObject obj = (JSONObject) object;
                            String spec = obj.getString("spec");
                            String specValue = obj.getString("specValue");
                            boolean temp = false;
                            for (Object object1 : oldArray){
                                JSONObject obj1 = (JSONObject) object1;
                                if (spec.equals(obj1.getString("spec")) && specValue.equals(obj1.getString("specValue"))) {
                                    temp = true;
                                }
                            }
                            if (!temp) {
                                flag = true;
                            }
                        }
                    }
                    if (flag) {
                        return true;
                    }
                }
                if (!compareStr(commonProductDto.getProductType(), purchaseProductApply.getProductType())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getSkuCode(), purchaseProductApply.getSkuCode())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getSupplierProductCode(), purchaseProductApply.getProductCode())) {
                    return true;
                }
                if (!compareBigDecimal(commonProductDto.getSupplyPrice(), purchaseProductApply.getSupplyPrice())) {
                    return true;
                }
                if (!compareBigDecimal(commonProductDto.getPurchasePrice(), purchaseProductApply.getPurchasePrice())) {
                    return true;
                }
                if (!compareBigDecimal(commonProductDto.getPrice(), purchaseProductApply.getPrice())) {
                    return true;
                }
                if (!compareBigDecimal(commonProductDto.getSuggestPrice(), purchaseProductApply.getSuggestPrice())) {
                    return true;
                }
                if ((int) commonProductDto.getStock() != purchaseProductApply.getStock()) {
                    return true;
                }
                if (!compareStr(commonProductDto.getDeliveryDate(), purchaseProductApply.getDeliveryDate())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getWeight(), purchaseProductApply.getWeight())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getUnit(), purchaseProductApply.getUnit())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getProductContent(), purchaseProductApply.getProductContent())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getIsOnsale(), purchaseProductApply.getIsOnsale())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getProductPicName(), purchaseProductApply.getProductPicName())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getProductVedioName(), purchaseProductApply.getProductVedioName())) {
                    return true;
                }
                if (!compareStr(commonProductDto.getFirstStoreCataName(), purchaseProductApply.getFirstLevelCataName())) {
                    return true;
                }
                //如果店铺id存在则校验一二级分类
                if(BeanUtil.isNotEmpty(purchaseProductApply.getStoreCataId())){
                    PurchaseCommonProductDto productDto = purchaseProductApplyMapper.selectStoreCataName(purchaseProductApply.getStoreCataId());
                    if (!compareStr(commonProductDto.getFirstStoreCataName(), productDto.getFirstStoreCataName())) {
                        return true;
                    }
                    if (!compareStr(commonProductDto.getSecondStoreCataName(), productDto.getSecondStoreCataName())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public Boolean checkChangeColumnsNeedAudit(PurchaseProductApply purchaseProductApply) {
        List<String> editColumns = new ArrayList<>();
        List<ProductProperties> productProperties = productPropertiesService.listAllEnableColumns();

        if (null != purchaseProductApply.getPublicProductId()) {
            if (null != purchaseProductApply && CollectionUtils.isNotEmpty(productProperties)) {
                List<CommonProductDto> commonProductDtos = publicProductFeignClient
                        .listProductByProductIds(Collections.singletonList(purchaseProductApply.getPublicProductId()));
                Map<Long,CommonProductDto> commonProductDtoMap = new HashMap<>(commonProductDtos.size());
                for (CommonProductDto commonProductDto:commonProductDtos) {
                    commonProductDtoMap.put(commonProductDto.getProductId(), commonProductDto);
                }
                CommonProductDto commonProductDto = commonProductDtoMap.get(purchaseProductApply.getPublicProductId());
                dealBigDecimalData(commonProductDto);
                if (null != commonProductDto) {
                    if (!compareStr(commonProductDto.getCataNameOne(), purchaseProductApply.getFirstLevelCataName())) {
                        editColumns.add("firstLevelCataName");
                    }
                    if (!compareStr(commonProductDto.getCataNameTwo(), purchaseProductApply.getSecondLevelCataName())) {
                        editColumns.add("secondtLevelCataName");
                    }
                    if (!compareStr(commonProductDto.getCataNameThree(), purchaseProductApply.getThreeLevelCataName())) {
                        editColumns.add("threeLevelCataName");
                    }
                    if (!compareStr(commonProductDto.getBrandName(), purchaseProductApply.getBrandName())) {
                        editColumns.add("brandName");
                    }
                    if (!compareStr(commonProductDto.getPropName(), purchaseProductApply.getPropName())) {
                        editColumns.add("propName");
                    }
                    if (!compareStr(commonProductDto.getSpecData(), purchaseProductApply.getSpecData())) {
                        boolean flag = false;
                        JSONArray newArray = JSONArray.parseArray(purchaseProductApply.getSpecData());
                        JSONArray oldArray = JSONArray.parseArray(commonProductDto.getSpecData());
                        if (null != newArray && (null == oldArray || newArray.size() != oldArray.size())) {
                            flag = true;
                        }
                        if (null != oldArray && (null == newArray || newArray.size() != oldArray.size())) {
                            flag = true;
                        }
                        if (null != newArray && null != oldArray) {
                            for (Object object : newArray) {
                                JSONObject obj = (JSONObject) object;
                                String spec = obj.getString("spec");
                                String specValue = obj.getString("specValue");
                                boolean temp = false;
                                for (Object object1 : oldArray){
                                    JSONObject obj1 = (JSONObject) object1;
                                    if (spec.equals(obj1.getString("spec")) && specValue.equals(obj1.getString("specValue"))) {
                                        temp = true;
                                    }
                                }
                                if (!temp) {
                                    flag = true;
                                }
                            }
                        }
                        if (flag) {
                            editColumns.add("specData");
                        }
                    }
                    if (!compareStr(commonProductDto.getProductType(), purchaseProductApply.getProductType())) {
                        editColumns.add("productType");
                    }
                    if (!compareStr(commonProductDto.getSkuCode(), purchaseProductApply.getSkuCode())) {
                        editColumns.add("skuCode");
                    }
                    if (!compareStr(commonProductDto.getSupplierProductCode(), purchaseProductApply.getProductCode())) {
                        editColumns.add("productCode");
                    }
                    if (!compareBigDecimal(commonProductDto.getSupplyPrice(), purchaseProductApply.getSupplyPrice())) {
                        editColumns.add("supplyPrice");
                    }
                    if (!compareBigDecimal(commonProductDto.getPurchasePrice(), purchaseProductApply.getPurchasePrice())) {
                        editColumns.add("purchasePrice");
                    }
                    if (!compareBigDecimal(commonProductDto.getPrice(), purchaseProductApply.getPrice())) {
                        editColumns.add("price");
                    }
                    if (!compareBigDecimal(commonProductDto.getSuggestPrice(), purchaseProductApply.getSuggestPrice())) {
                        editColumns.add("suggestPrice");
                    }
                    if ((int) commonProductDto.getStock() != purchaseProductApply.getStock()) {
                        editColumns.add("stock");
                    }
                    if (!compareStr(commonProductDto.getDeliveryDate(), purchaseProductApply.getDeliveryDate())) {
                        editColumns.add("deliveryDate");
                    }
                    if (!compareStr(commonProductDto.getWeight(), purchaseProductApply.getWeight())) {
                        editColumns.add("weight");
                    }
                    if (!compareStr(commonProductDto.getUnit(), purchaseProductApply.getUnit())) {
                        editColumns.add("unit");
                    }
                    if (!compareStr(commonProductDto.getProductContent(), purchaseProductApply.getProductContent())) {
                        editColumns.add("productContent");
                    }
                    if (!compareStr(commonProductDto.getIsOnsale(), purchaseProductApply.getIsOnsale())) {
                        editColumns.add("isOnsale");
                    }
                    if (!compareStr(commonProductDto.getProductPicName(), purchaseProductApply.getProductPicName())) {
                        editColumns.add("productPicName");
                    }
                    if (!compareStr(commonProductDto.getProductVedioName(), purchaseProductApply.getProductVedioName())) {
                        editColumns.add("productVedioName");
                    }
                } else {
                    return true;
                }
            }
        } else {
            return true;
        }
        List<String> columns = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(productProperties)) {
            columns = productProperties.stream().map(ProductProperties::getParam).collect(Collectors.toList());
        }

        if (CollectionUtils.isNotEmpty(columns) && CollectionUtils.isNotEmpty(editColumns)) {
            for (String column: editColumns) {
                if (columns.contains(column)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(PurchaseProductApply purchaseProductApply) {
        Assert.notNull(purchaseProductApply, "purchaseProductApply can not be null");
        Example example = genConditionExample(purchaseProductApply);
        example.selectProperties(PurchaseProductApply.ID);
        List<PurchaseProductApply> purchaseProductApplyList = purchaseProductApplyMapper.selectByExample(example);
        return CollectionUtils.isEmpty(purchaseProductApplyList) ? new ArrayList<>(0) :
                purchaseProductApplyList.stream().map(PurchaseProductApply::getId).collect(toList());
    }

    /**
     * 新增
     */
    public String add(PurchaseProductApply purchaseProductApply) {
        return super.insert(purchaseProductApply);
    }

    /**
     * 修改
     */
    @Transactional
    public void edit(PurchaseProductApply purchaseProductApply) {
        if ((purchaseProductApply.getSupplyPrice().multiply(new BigDecimal(1.05)).compareTo(purchaseProductApply.getPurchasePrice())) > 0 ){
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "商品毛利低于约定毛利率");
        }
        String supplierId = (String) ContextHandler.get("supplierId");
        PurchaseProductApply oldData = super.get(purchaseProductApply.getId());
        List<PurchaseProductApply> purchaseProductApplies = purchaseProductApplyMapper.selectByCon(purchaseProductApply);
        if (CollectionUtils.isNotEmpty(purchaseProductApplies)){
            List<String> ids = purchaseProductApplies.stream().map(PurchaseProductApply::getId).collect(Collectors.toList());
            if (!ids.contains(purchaseProductApply.getId())){
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "商品已存在（商品ID：" + purchaseProductApplies.get(0).getApplyNo() + "），如要修改请编辑或批量修改商品");
            }
        }
        if (null != oldData) {
            deleteCataBrandPropData(purchaseProductApply.getId(), oldData.getFirstLevelCataName(),
                    oldData.getSecondLevelCataName(), oldData.getThreeLevelCataName(), oldData.getBrandName(), oldData.getPropName());
        }
        PurchaseProductApply purchaseProductApplyVo = new PurchaseProductApplyVo();
        BeanUtil.copyProperties(purchaseProductApply, purchaseProductApplyVo, "id", "updatedBy", "updatedAt", "batchNo");
        CommonProductDto productDto = purchaseProductApplyMapper.getInApplyNo(oldData.getApplyNo());
        //查询是否存在待审核数据
        CorpHelper.skipCorpCode(true);
        List<PurchaseProductApply> purchaseProductApplyOld = purchaseProductApplyMapper.selectByApplyAndPendReview(oldData.getApplyNo(), 0, supplierId);
        List<PurchaseProductApply> needInterApplyList = new ArrayList<>();
        List<PurchaseProductApply> needUpdateApplyList = new ArrayList<>();
        //根据productDto、purchaseProductApply判断新增还是编辑
        if (null != productDto) {
            purchaseProductApplyVo.setPublicProductId(productDto.getProductId());
            purchaseProductApplyVo.setApplySource(productDto.getApplySource());
            Boolean flag = hasEdit(purchaseProductApplyVo);
            if (BooleanUtils.isFalse(flag)) {
                //有公海，但是修改的信息不需要审核，直接自动审核进入公海
                checkChangeColumnsNeedAudit(purchaseProductApplyVo);
            } else if (CollectionUtils.isNotEmpty(purchaseProductApplyOld)) {
                //有公海产品，也有待审核，那就更新待审核
                purchaseProductApplyVo.setId(purchaseProductApplyOld.get(0).getId());
                purchaseProductApplyVo.setApplySource(purchaseProductApplyOld.get(0).getApplySource());
                purchaseProductApplyVo.setUpdatedBy(supplierId);
                purchaseProductApplyVo.setUpdatedAt(LocalDateTime.now());
                needUpdateApplyList.add(purchaseProductApplyVo);
            } else {
                //有公海，并且没有待审核，就增加一条待审核
                purchaseProductApplyVo.setAuditStatus(0);
                purchaseProductApplyVo.setAuditType(2);
                purchaseProductApplyVo.setIsOnsale(purchaseProductApply.getIsOnsale());
                purchaseProductApplyVo.setId(IDUtils.getUUID19());
                purchaseProductApplyVo.setApplySource(productDto.getApplySource());
                purchaseProductApplyVo.setCreatedBy(supplierId);
                purchaseProductApplyVo.setCreatedAt(LocalDateTime.now());
                purchaseProductApplyVo.setCorpCode(ContextHandler.getCorpCode());
                needInterApplyList.add(purchaseProductApplyVo);
            }
        } else {
            if (null != purchaseProductApplyOld) {
                //没有公海，但是存在待审核，则修改数据
                purchaseProductApplyVo.setId(purchaseProductApplyOld.get(0).getId());
                purchaseProductApplyVo.setApplySource(purchaseProductApplyOld.get(0).getApplySource());
                purchaseProductApplyVo.setUpdatedBy(supplierId);
                purchaseProductApplyVo.setUpdatedAt(LocalDateTime.now());
                needUpdateApplyList.add(purchaseProductApplyVo);
            } else {
                //没有公海，但是不存在待审核，则增加数据
                purchaseProductApplyVo.setAuditStatus(0);
                purchaseProductApplyVo.setAuditType(2);
                purchaseProductApplyVo.setId(IDUtils.getUUID19());
                purchaseProductApplyVo.setIsOnsale("Y");
                purchaseProductApplyVo.setApplySource("publish");
                purchaseProductApplyVo.setCreatedBy(supplierId);
                purchaseProductApplyVo.setCreatedAt(LocalDateTime.now());
                purchaseProductApplyVo.setCorpCode(ContextHandler.getCorpCode());
                needInterApplyList.add(purchaseProductApplyVo);
            }
        }
        if (StringUtils.isNotEmpty(purchaseProductApplyVo.getProductCode())) {
            if (!checkProductCode(purchaseProductApplyVo.getProductCode(), purchaseProductApply.getId())) {
                throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "我的编码重复！");
            }
        }

        if (needUpdateApplyList.size() > 0) {
            //要修改的商品申请
            needUpdateApplyList.forEach(e -> {
//                //先删除旧关系
//                PurchaseProductApply oldData1 = get(e.getId());
//                deleteCataBrandPropData(e.getId(), oldData1.getFirstLevelCataName(),
//                        oldData1.getSecondLevelCataName(), oldData1.getThreeLevelCataName(), oldData1.getBrandName(), oldData1.getPropName());

                //记录分类、品牌、系列三者关系
                PurchaseCataBrandProp purchaseCataBrandProp = new PurchaseCataBrandProp();
                purchaseCataBrandProp.setId(IDUtils.getUUID19());
                purchaseCataBrandProp.setFirstLevelCataName(e.getFirstLevelCataName());
                purchaseCataBrandProp.setSecondLevelCataName(e.getSecondLevelCataName());
                purchaseCataBrandProp.setThreeLevelCataName(e.getThreeLevelCataName());
                purchaseCataBrandProp.setBrandName(e.getBrandName());
                purchaseCataBrandProp.setPropName(e.getPropName());
                purchaseCataBrandPropService.save(purchaseCataBrandProp);

                purchaseProductApplyMapper.updateByPrimaryKeySelective(e);
            });
        }

        if (needInterApplyList.size() > 0) {
            needInterApplyList.forEach(purchaseProductApplyVo1 -> {
                //记录分类、品牌、系列三者关系
                PurchaseCataBrandProp purchaseCataBrandProp = new PurchaseCataBrandProp();
                purchaseCataBrandProp.setId(IDUtils.getUUID19());
                purchaseCataBrandProp.setFirstLevelCataName(purchaseProductApplyVo1.getFirstLevelCataName());
                purchaseCataBrandProp.setSecondLevelCataName(purchaseProductApplyVo1.getSecondLevelCataName());
                purchaseCataBrandProp.setThreeLevelCataName(purchaseProductApplyVo1.getThreeLevelCataName());
                purchaseCataBrandProp.setBrandName(purchaseProductApplyVo1.getBrandName());
                purchaseCataBrandProp.setPropName(purchaseProductApplyVo1.getPropName());
                purchaseCataBrandPropService.save(purchaseCataBrandProp);
            });
            purchaseProductApplyMapper.insertBatch(needInterApplyList);
        }
    }

    public void deleteCataBrandPropData(String id,
                                        String firstLevelCataName,
                                        String secondLevelCataName,
                                        String threeLevelCataName,
                                        String brandName,
                                        String propName) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(PurchaseProductApply.FIRST_LEVEL_CATA_NAME, firstLevelCataName);
        criteria.andEqualTo(PurchaseProductApply.SECOND_LEVEL_CATA_NAME, secondLevelCataName);
        criteria.andEqualTo(PurchaseProductApply.THREE_LEVEL_CATA_NAME, threeLevelCataName);
        criteria.andEqualTo(PurchaseProductApply.BRAND_NAME, brandName);
        if (StringUtils.isNotEmpty(propName)) {
            criteria.andEqualTo(PurchaseProductApply.PROP_NAME, propName);
        } else {
            Example.Criteria criteria1 = example.createCriteria();
            criteria1.andEqualTo(PurchaseProductApply.PROP_NAME, "");
            criteria1.orIsNull(PurchaseProductApply.PROP_NAME);
            example.and(criteria1);
        }

        criteria.andNotEqualTo(PurchaseProductApply.ID, id);
        String supplierId  = (String) ContextHandler.get("supplierId");
        if (StringUtils.isNotEmpty(supplierId)) {
            criteria.andEqualTo(PurchaseCataBrandProp.IS_SUPPLY, "N");
            criteria.andEqualTo(PurchaseCataBrandProp.SUPPLIER_ID, supplierId);
        } else {
            criteria.andEqualTo(PurchaseCataBrandProp.IS_SUPPLY, "Y");
        }

        List<PurchaseProductApply> applyList = purchaseProductApplyMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(applyList)) {
            purchaseCataBrandPropService.deleteData(firstLevelCataName, secondLevelCataName, threeLevelCataName, brandName, propName, supplierId);
        }

    }

    /**
     * 批量删除
     */
    public void deleteByIds(List<String> ids) {
        super.batchDelete(ids);
    }

    /**
     * 校验商品编码 true-为可用，false-为不可用
     *
     * @param productCode 商品编码
     * @return Boolean
     */
    public Boolean checkProductCode(String productCode, String id) {
        if (StringUtils.isNotEmpty(id)) {
            PurchaseProductApply purchaseProductApply = get(id);
            if (null != purchaseProductApply && StringUtils.isNotEmpty(productCode)
                && productCode.equals(purchaseProductApply.getProductCode())) {
                return true;
            }
        }
        //验证产品申请表是否有该编码
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotEmpty(productCode)) {
            criteria.andEqualTo(PurchaseProductApply.PRODUCT_CODE, productCode);
        }
        if (StringUtils.isNotEmpty(id)) {
            criteria.andNotEqualTo(PurchaseProductApply.ID, id);
        }
        String supplierId  = (String) ContextHandler.get("supplierId");
        if (StringUtils.isNotEmpty(supplierId)) {
            criteria.andEqualTo(PurchaseProductApply.IS_SUPPLY, "N");
            criteria.andEqualTo(PurchaseProductApply.SUPPLIER_ID, supplierId);
        } else {
            criteria.andEqualTo(PurchaseProductApply.IS_SUPPLY, "Y");
        }
        List<PurchaseProductApply> applyList = purchaseProductApplyMapper.selectByExample(example);
        if (applyList != null && applyList.size() > 0) {
            return false;
        }
        return true;
    }

    /**
     * 供应商报价调用
     * @param applys 商品发布请求vo类
     * @return id
     */
    public HashMap multiQuote(List<PurchaseProductApply> applys) {
        HashMap<String, String> hashMap = new HashMap<>();
        for (PurchaseProductApply p : applys) {
            try {
                ContextHandler.set("supplierId", p.getSupplierId());
                ContextHandler.setCorpCode("default");
                //供应商提交报价时 返回商品id
                p.setIgnoreRepeat(true);
                p.setApplySource("inquiry");
                String id = singlePublishProduct(p);
                String key = p.getProductType() + "@" + (StringUtils.isEmpty(p.getBrandName()) ? "" : p.getBrandName());
                hashMap.put(key, id);
            }catch (Exception e){
                log.info("忽略异常：" + e.getMessage());
            }
        }
        return hashMap;
    }

    /**
     * 单商品发布
     *
     * @param apply 商品发布请求vo类
     * @return id
     */
    @Transactional(rollbackFor = Exception.class)
    public String singlePublishProduct(PurchaseProductApply apply) {
        String userId = ContextHandler.getUserId();
        if (StringUtils.isEmpty(userId)){
            userId = apply.getUserId();
        }
        String oldId = apply.getId();
        String supplierId  = (String) ContextHandler.get("supplierId");
//        String supplierId = "hyi2p140a8Y4JcTUELL111";
        String supplierDataType  = (String) ContextHandler.get("supplierDataType");
        if ("SELF".equalsIgnoreCase(supplierDataType)){
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "自营供应商暂不可添加商品！");
        }
        if (apply.getSupplyPrice() == null || (apply.getSupplyPrice().compareTo(BigDecimal.ZERO) == 0)){
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "供货价必填");
        }
        if (apply.getPurchasePrice() == null || (apply.getPurchasePrice().compareTo(BigDecimal.ZERO) == 0)){
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "慧采价必填");
        }
        if ((apply.getSupplyPrice().multiply(new BigDecimal(1.05)).compareTo(apply.getPurchasePrice())) > 0 ){
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "商品毛利低于约定毛利率");
        }
        List<PurchaseProductApply> purchaseProductApplies = purchaseProductApplyMapper.selectByCon(apply);
        if (CollectionUtils.isNotEmpty(purchaseProductApplies)){
            if (apply.isIgnoreRepeat()){
                return purchaseProductApplies.get(0).getId();
            }
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "商品已存在（商品ID：" + purchaseProductApplies.get(0).getApplyNo() + "），如要修改请编辑或批量修改商品");
        }

        //组装数据
        apply.setId(IDUtils.getUUID19());
        //唯一校验
        String productCode = apply.getProductCode();
        if (null == apply.getAuditType()) {
            apply.setAuditType(1);
        }
        if (StringUtils.isEmpty(apply.getApplySource())){
            apply.setApplySource("publish");
        }

        if (StringUtils.isNotBlank(productCode) &&
                !this.checkProductCode(productCode, oldId) && apply.getAuditType() == 1) {
            throw new BaseException(String.valueOf(ExceptionDictionary.ParamVldExp.getCode()), "商品编码重复");
        }

        PurchaseCataBrandProp purchaseCataBrandProp = new PurchaseCataBrandProp();
        purchaseCataBrandProp.setId(IDUtils.getUUID19());
        purchaseCataBrandProp.setFirstLevelCataName(apply.getFirstLevelCataName());
        purchaseCataBrandProp.setSecondLevelCataName(apply.getSecondLevelCataName());
        purchaseCataBrandProp.setThreeLevelCataName(apply.getThreeLevelCataName());
        purchaseCataBrandProp.setBrandName(apply.getBrandName());
        purchaseCataBrandProp.setPropName(apply.getPropName());
        purchaseCataBrandPropService.save(purchaseCataBrandProp);

        //审核状态（0=待审核，1=通过，2=不通过）
        apply.setUpdatedBy(userId);
        apply.setCreatedBy(userId);
        if ("N".equals(apply.getIsSupply()) && StringUtils.isBlank(supplierId)) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "不是供应商账号不可申请！");
        }
        if ("Y".equals(apply.getIsSupply()) && StringUtils.isNotBlank(supplierId)) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "不是供应链账号不可申请！");
        }
        if ("N".equals(apply.getIsSupply())) {
            apply.setAuditStatus(0);
            apply.setSupplierId(supplierId);
        } else {
            apply.setAuditStatus(1);
        }
        if (null == apply.getApplyNo()) {
            apply.setApplyNo(getMaxApplyNo());
            //当商品申请状态新增时
            if(apply.getAuditType().equals(1)&&BeanUtil.isNotEmpty(apply.getStoreCataId())){
                supplierProductPropertyMapper.insertProductProperty(apply, LocalDateTime.now());
            }
        } else {
            PurchaseProductApply apply1 = getByApplyNo(apply.getApplyNo());
            dealBigDecimalData(apply);
            Boolean flag = hasEdit(apply);
            if (BooleanUtils.isFalse(flag)) {
                return apply.getId();
            }
            if (null != apply1 && 1 != apply1.getAuditStatus()) {
                apply.setId(apply1.getId());
                apply.setAuditTime(null);
                apply.setAuditRemark(null);
                apply.setAuditStatus(0);
                apply.setPublicProductId(apply1.getPublicProductId());

                Boolean result = checkChangeColumnsNeedAudit(apply);
                if (BooleanUtils.isFalse(result)) {
                    apply.setAuditStatus(1);
                    apply.setAuditTime(LocalDateTime.now());
                    syncProduct(apply);
                }
                apply.setCreatedBy(apply1.getCreatedBy());
                apply.setCreatedAt(apply1.getCreatedAt());
                apply.setCorpCode(ContextHandler.getCorpCode());
                purchaseProductApplyMapper.updateByPrimaryKey(apply);
                return apply.getId();
            } else if (null != apply1 && 1 == apply1.getAuditStatus() && "N".equals(apply.getIsSupply())) {
                apply.setAuditTime(null);
                apply.setAuditRemark(null);
                apply.setAuditStatus(0);
                apply.setPublicProductId(apply1.getPublicProductId());
                Boolean result = checkChangeColumnsNeedAudit(apply);
                if (BooleanUtils.isFalse(result)) {
                    apply.setAuditStatus(1);
                    apply.setAuditTime(LocalDateTime.now());
                    syncProduct(apply);
                }
                return super.insert(apply);
            }
        }

        if (apply.getAuditStatus() == 1) {
            syncProduct(apply);
        }

        return super.insert(apply);
    }

    private void syncProduct(PurchaseProductApply apply) {
        apply.setAuditTime(LocalDateTime.now());
        PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
        purchaseProductSync.setFirstLevelCataName(apply.getFirstLevelCataName());
        purchaseProductSync.setSecondLevelCataName(apply.getSecondLevelCataName());
        purchaseProductSync.setThreeLevelCataName(apply.getThreeLevelCataName());
        purchaseProductSync.setBrandName(apply.getBrandName());
        purchaseProductSync.setPropName(apply.getPropName());
        purchaseProductSync.setProductErpCode(apply.getProductCode());
        purchaseProductSync.setProductType(apply.getProductType());
        purchaseProductSync.setProductErpCode(apply.getProductCode());
        purchaseProductSync.setProductCode(apply.getProductCode());
        purchaseProductSync.setSkuCode(apply.getSkuCode());
        purchaseProductSync.setPrice(apply.getPrice());
        purchaseProductSync.setSupplyPrice(apply.getSupplyPrice());
        purchaseProductSync.setSuggestPrice(apply.getSuggestPrice());
        purchaseProductSync.setPurchasePrice(apply.getPurchasePrice());
        purchaseProductSync.setUnit(apply.getUnit());
        purchaseProductSync.setWeight(apply.getWeight());
        purchaseProductSync.setIsOnsale(apply.getIsOnsale());
        purchaseProductSync.setDeliveryDate(apply.getDeliveryDate());
        purchaseProductSync.setAuditTime(apply.getAuditTime());
        purchaseProductSync.setSupplierId(apply.getSupplierId());
        purchaseProductSync.setProductContent(apply.getProductContent());
        purchaseProductSync.setProductVedioName(apply.getProductVedioName());
        purchaseProductSync.setProductPicName(apply.getProductPicName());
        purchaseProductSync.setSpecData(apply.getSpecData());
        purchaseProductSync.setPublicProductId(apply.getPublicProductId());
        purchaseProductSync.setId(apply.getId());
        purchaseProductSync.setStock(apply.getStock());
        purchaseProductSync.setSample(apply.getSample());
        purchaseProductSync.setApplyNo(apply.getApplyNo());
        purchaseProductSync.setApplySource(apply.getApplySource());
        purchaseProductSync.setMaterialName(apply.getMaterialName());
        JsonResult<Long> jsonResult = publicProductFeignClient.purchaseProductSync(purchaseProductSync);
        if (null != jsonResult && BooleanUtils.isTrue(jsonResult.isSuccess())) {
            apply.setPublicProductId(jsonResult.getData());
        }
        if ("Y".equals(apply.getIsSupply())) {
            apply.setProductErpCode(apply.getProductCode());
        }
    }

    private Boolean compareStr(String newStr, String oldStr) {
        if (newStr == null) {
            if (StringUtils.isEmpty(oldStr)) {
                return true;
            }
            return oldStr.equals(newStr);
        }
        if (oldStr == null) {
            if (StringUtils.isEmpty(newStr)) {
                return true;
            }
            return newStr.equals(oldStr);
        }
        return newStr.equals(oldStr);
    }

    private Boolean compareBigDecimal(BigDecimal newVal, BigDecimal oldVal) {
        if (newVal == null) {
            if (oldVal == null) {
                return true;
            }
            return oldVal.equals(newVal);
        }
        return newVal.equals(oldVal);
    }

    private List<PurchaseProductApply> getIsAuditListByProductCodeList(List<String> productCodeList) {
        //验证产品申请表是否有该编码
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        if (CollectionUtils.isNotEmpty(productCodeList)) {
            criteria.andIn(PurchaseProductApply.PRODUCT_CODE, productCodeList);
        }
        return purchaseProductApplyMapper.selectByExample(example);
    }

    public PurchaseProductApply details(String id) {
        String prefix = ossUrl ;
        PurchaseProductApply details = get(id);
        details.setUrlPrefix(prefix);
        return details;
    }


    public JsonResult<String> getApplyTemp() {
        String applyTempUrl = ossUrl + "慧采批量发布商品导入模板.xlsx";
        return new JsonResult<>(true, "查询成功", applyTempUrl);
    }

    public JsonResult<String> getStockTemp() {
        String applyTempUrl = ossUrl + "慧采批量上传库存模板.xlsx";
        return new JsonResult<>(true, "查询成功", applyTempUrl);
    }


    public Boolean audit(String id, Integer auditStatus, String data) {
        PurchaseProductApply apply = super.get(id);
        if (apply == null) {
            throw new BaseException(String.valueOf(ExceptionDictionary.ParamVldExp.getCode()), "请求参数异常");
        }
        if (0 != apply.getAuditStatus()) {
            throw new BaseException(String.valueOf(ExceptionDictionary.ParamVldExp.getCode()), "商品信息已调整，请重新申请");
        }
        apply.setAuditStatus(auditStatus);
        apply.setAuditTime(LocalDateTime.now());
        if (auditStatus == 1) {
            apply.setProductErpCode(data);
            PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
            purchaseProductSync.setFirstLevelCataName(apply.getFirstLevelCataName());
            purchaseProductSync.setSecondLevelCataName(apply.getSecondLevelCataName());
            purchaseProductSync.setThreeLevelCataName(apply.getThreeLevelCataName());
            purchaseProductSync.setBrandName(apply.getBrandName());
            purchaseProductSync.setPropName(apply.getPropName());
            purchaseProductSync.setProductCode(apply.getProductCode());
            purchaseProductSync.setProductType(apply.getProductType());
            purchaseProductSync.setSkuCode(apply.getSkuCode());
            purchaseProductSync.setStock(apply.getStock());
            purchaseProductSync.setPrice(apply.getPrice());
            purchaseProductSync.setSupplyPrice(apply.getSupplyPrice());
            purchaseProductSync.setSuggestPrice(apply.getSuggestPrice());
            purchaseProductSync.setPurchasePrice(apply.getPurchasePrice());
            purchaseProductSync.setUnit(apply.getUnit());
            purchaseProductSync.setWeight(apply.getWeight());
            purchaseProductSync.setIsOnsale(apply.getIsOnsale());
            purchaseProductSync.setDeliveryDate(apply.getDeliveryDate());
            purchaseProductSync.setAuditTime(apply.getAuditTime());
            purchaseProductSync.setSupplierId(apply.getSupplierId());
            purchaseProductSync.setProductContent(apply.getProductContent());
            purchaseProductSync.setProductVedioName(apply.getProductVedioName());
            purchaseProductSync.setProductPicName(apply.getProductPicName());
            purchaseProductSync.setSpecData(apply.getSpecData());
            purchaseProductSync.setPublicProductId(apply.getPublicProductId());
            purchaseProductSync.setId(apply.getId());
            purchaseProductSync.setSample(apply.getSample());
            purchaseProductSync.setProductErpCode(data);
            purchaseProductSync.setApplyNo(apply.getApplyNo());

            //商品的店铺信息
            PurchaseStore purchaseStore = purchaseProductApplyMapper.selectBySupplier(apply.getSupplierId());
            if (purchaseStore != null){
                purchaseProductSync.setStoreId(purchaseStore.getId());
                purchaseProductSync.setStoreName(purchaseStore.getStoreName());
                purchaseProductSync.setStoreType(purchaseStore.getStoreType());
                purchaseProductSync.setStoreDesc(purchaseStore.getRemark());
            }

            JsonResult checkResult = publicProductFeignClient.checkCataAndCode(purchaseProductSync);
            if (null != checkResult && BooleanUtils.isNotTrue(checkResult.isSuccess())) {
                throw new BaseException("-100", checkResult.getMsg());
            }
            JsonResult<Long> jsonResult = publicProductFeignClient.purchaseProductSync(purchaseProductSync);
            if (null != jsonResult && BooleanUtils.isTrue(jsonResult.isSuccess())) {
                //同步purchase 的es接口
                esFeignClient.updateByIds(Arrays.asList(String.valueOf(jsonResult.getData())));
                apply.setPublicProductId(jsonResult.getData());
            }
        } else if (auditStatus == 2) {
            apply.setAuditRemark(data);
        }
        purchaseProductApplyMapper.updateByPrimaryKeySelective(apply);
        return true;
    }

    public JsonResult<String> importProduct(MultipartFile multipartFile, String isSupply) {
        if (StringUtils.isBlank(isSupply)) {
            throw new BaseException(String.valueOf(ExceptionDictionary.ParamVldExp.getCode()), "请求参数异常");
        }
        //校验文件
        if (multipartFile == null) {
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "上传文件不能为空");
        }
        String originalFilename = multipartFile.getOriginalFilename();
        String suffix = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
        if (!"xls".equals(suffix) && !"xlsx".equals(suffix)) {
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "请上传Excel文件");
        }

        String supplierId  = (String) ContextHandler.get("supplierId");
        if ("N".equals(isSupply) && StringUtils.isBlank(supplierId)) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "不是供应商账号不可申请！");
        }
        if ("Y".equals(isSupply) && StringUtils.isNotBlank(supplierId)) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "不是供应链账号不可申请！");
        }

        FileInputStream fi = null;
        FileOutputStream os = null;
        File newFile = new File(UUID.randomUUID().toString());
        try {
            os = new FileOutputStream(newFile);
            os.write(multipartFile.getBytes());
            multipartFile.transferTo(newFile);
            fi = new FileInputStream(newFile);
        } catch (IOException e) {
            e.printStackTrace();
            IoUtil.close(fi);
            IoUtil.close(os);
        }
        List<PurchaseProductApply> importExcelDtos = changeExcel(fi);
        log.info("importExcelDtos:{}", importExcelDtos);
        //统计导入行数
        if (importExcelDtos == null || importExcelDtos.size() <= 0) {
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "excel数据为空");
        }
        if (importExcelDtos.size() > 500) {
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "一次最多导入500条");
        }
        Map<String, Object> model = new HashMap<>();
        List<PurchaseProductApply> items = new ArrayList<>();
        List<PurchaseProductApply> successList = new ArrayList<>();
        Map<String, String> productCodeMap = new HashMap<>();
        importExcelDtos.stream().forEach(e -> {

            if (null != e.getApplyNo()) {
                PurchaseProductApply exist = getByApplyNo(e.getApplyNo());
                log.info("exist:{}", exist);
                if (exist == null) {
                    e.setError(e.getApplyNo() + "不存在该商品");
                    items.add(e);
                    return;
                } else {
                    e.setCreatedBy(exist.getCreatedBy());
                    e.setCreatedAt(exist.getCreatedAt());
                    e.setId(exist.getId());
                    e.setApplyNo(exist.getApplyNo());
                    e.setAuditType(exist.getAuditType());
                    e.setAuditStatus(exist.getAuditStatus());
                    e.setPublicProductId(exist.getPublicProductId());
                    e.setProductErpCode(exist.getProductErpCode());
                }
            }

            log.info("e:{}", e);

            // 分类名称
            if (StringUtils.isBlank(e.getFirstLevelCataName())) {
                e.setError("一级分类不能为空");
                items.add(e);
                return;
            }
            if (StringUtils.isBlank(e.getSecondLevelCataName())) {
                e.setError("二级分类不能为空");
                items.add(e);
                return;
            }
            if (StringUtils.isBlank(e.getThreeLevelCataName())) {
                e.setError("三级分类不能为空");
                items.add(e);
                return;
            }

            // 品牌名
            if (StringUtils.isBlank(e.getBrandName())) {
                e.setError("品牌不能为空");
                items.add(e);
                return;
            }

            // 系列名称
            if (StringUtils.isBlank(e.getPropName())) {
                e.setError("系列不能为空");
                items.add(e);
                return;
            }
            // 产品型号
            if (StringUtils.isBlank(e.getProductType())) {
                e.setError("产品型号不能为空");
                items.add(e);
                return;
            }
            if (e.getProductType().length() > 50) {
                e.setError("产品型号不能超过50个字符");
                items.add(e);
                return;
            }
            // 订货号
            if (StringUtils.isNotBlank(e.getSkuCode())) {
                if (e.getSkuCode().length() > 50) {
                    e.setError("订货号不能超过50个字符");
                    items.add(e);
                    return;
                }
            }
            // 商品编号
            if (StringUtils.isNotBlank(e.getProductCode())) {
                Boolean result = checkProductCode(e.getProductCode(), e.getId());
                if (BooleanUtils.isNotTrue(result)) {
                    e.setError("商品编码重复，请重新填写");
                    items.add(e);
                    return;
                }
                log.info("e.getProductCode():{}", e.getProductCode());
                log.info("productCodeMap:{}", productCodeMap);
                String row = productCodeMap.get(e.getProductCode());
                log.info("row:{}", row);
                if (StringUtils.isNotBlank(row)) {
                    e.setError("该商品编码在第" + row + "行已存在，请重新填写");
                    items.add(e);
                    return;
                }
                productCodeMap.put(e.getProductCode(), e.getRow()+"");
            }
            // 规格名和规格值
            if (StringUtils.isNotBlank(e.getSpecValueStr())) {
                try {
                    String[] specs = e.getSpecValueStr().split("[@]");
                    if (specs.length <= 0) {
                        e.setError("规格名和规格值不合法");
                        items.add(e);
                        return;
                    }
                    String[] vals;
                    JSONArray jsonArray = new JSONArray(specs.length);
                    for (String spec : specs) {
                        vals = spec.split("[=]");
                        if (vals.length != 2) {
                            e.setError("规格名和规格值不合法");
                            items.add(e);
                            return;
                        }
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("spec", vals[0]);
                        jsonObject.put("specValue", vals[1]);
                        jsonArray.add(jsonObject);
                    }
                    e.setSpecData(jsonArray.toJSONString());
                } catch (Exception e1) {
                    e.setError(e1.getMessage());
                    items.add(e);
                    return;
                }
            } else {
                e.setError("规格名和规格值必填");
                items.add(e);
                return;
            }

            // 是否上架
            if (StringUtils.isBlank(e.getIsOnsale())) {
                e.setError("是否上架不能为空");
                items.add(e);
                return;
            }
            if (!e.getIsOnsale().equals("Y") && !e.getIsOnsale().equals("N")) {
                e.setError("是否上架不合法");
                items.add(e);
                return;
            }
            // 供货价
            try {
                if (StringUtils.isBlank(e.getSupplyPriceStr())) {
                    e.setError("供货价不能为空");
                    items.add(e);
                    return;
                }
                e.setSupplyPrice(new BigDecimal(e.getSupplyPriceStr()));
            } catch (Exception ex) {
                e.setError("供货价不合法");
                items.add(e);
                return;
            }
            if (e.getSupplyPrice().compareTo(BigDecimal.ZERO) != 1) {
                e.setError("供货价必须大于0");
                items.add(e);
                return;
            }
            // 慧采价
            try {
                if (StringUtils.isBlank(e.getPurchasePriceStr())) {
                    e.setError("慧采价不能为空");
                    items.add(e);
                    return;
                }
                e.setPurchasePrice(new BigDecimal(e.getPurchasePriceStr()));
            } catch (Exception ex) {
                e.setError("慧采价不合法");
                items.add(e);
                return;
            }
            if (e.getPurchasePrice().compareTo(BigDecimal.ZERO) != 1) {
                e.setError("慧采价必须大于0");
                items.add(e);
                return;
            }
            if (e.getPurchasePrice().compareTo(e.getSupplyPrice()) != 1) {
                e.setError("慧采价必须大于供货价");
                items.add(e);
                return;
            }
            // 面价
            try {
                if (StringUtils.isBlank(e.getPriceStr())) {
                    e.setError("面价不能为空");
                    items.add(e);
                    return;
                }
                e.setPrice(new BigDecimal(e.getPriceStr()));
            } catch (Exception ex) {
                e.setError("面价不合法");
                items.add(e);
                return;
            }
            if (e.getPrice().compareTo(BigDecimal.ZERO) != 1) {
                e.setError("面价必须大于0");
                items.add(e);
                return;
            }
            if (e.getPrice().compareTo(e.getSupplyPrice()) != 1) {
                e.setError("面价必须大于供货价");
                items.add(e);
                return;
            }
            // 折扣价
            try {
                if (StringUtils.isBlank(e.getSuggestPriceStr())) {
                    e.setError("折建议价不能为空");
                    items.add(e);
                    return;
                }
                e.setSuggestPrice(new BigDecimal(e.getSuggestPriceStr()));
            } catch (Exception ex) {
                e.setError("建议零售价不合法");
                items.add(e);
                return;
            }
            if (e.getSuggestPrice().compareTo(BigDecimal.ZERO) != 1) {
                e.setError("建议零售价必须大于0");
                items.add(e);
                return;
            }
            if (e.getSuggestPrice().compareTo(e.getSupplyPrice()) != 1) {
                e.setError("建议零售价必须大于供货价");
                items.add(e);
                return;
            }
            // 库存
            try {
                if (null == e.getStock()) {
                    e.setError("库存不能为空");
                    items.add(e);
                    return;
                }
            } catch (Exception ex) {
                e.setError("库存不合法");
                items.add(e);
                return;
            }
            // 货期
            if (StringUtils.isNotBlank(e.getDeliveryDate())) {
                if (e.getDeliveryDate().length() > 6) {
                    e.setError("货期不能超过6个字符");
                    items.add(e);
                    return;
                }
            }
            // 重量
            if (StringUtils.isNotBlank(e.getWeight())) {
                try {
                    if (new BigDecimal(e.getWeight()).compareTo(BigDecimal.ZERO) != 1) {
                        e.setError("重量必须大于0");
                        items.add(e);
                        return;
                    }
                } catch (Exception ex) {
                    log.error(ex.getMessage(), ex);
                    e.setError("请输入正确数量的重量");
                    items.add(e);
                    return;
                }
            }
            // 详情图校验
            String[] urloss;
            if (StringUtils.isNotBlank(e.getProductPicName())) {
                urloss = e.getProductPicName().split("[@]");
                if (urloss.length > 5) {
                    e.setError("产品图最多支持5张图片");
                    items.add(e);
                    return;
                }
                StringBuilder imageStr = new StringBuilder();
                for (int i = 0; i < urloss.length; i++) {
                    imageStr.append(i == urloss.length - 1 ?
                            ossUrl+getOssCorpCode()+urloss[i] : ossUrl+getOssCorpCode()+urloss[i] + "@");
                }
                e.setProductPicName(imageStr.toString());
            }
            // 视频
            if (StringUtils.isNotBlank(e.getProductVedioName())) {
                urloss = e.getProductVedioName().split("[@]");
                if (urloss.length > 1) {
                    e.setError("视频最多支持1个");
                    items.add(e);
                    return;
                }
                StringBuilder vedioStr = new StringBuilder();
                for (int i = 0; i < urloss.length; i++) {
                    vedioStr.append(i == urloss.length - 1 ?
                            ossUrl+getOssCorpCode()+urloss[i] : ossUrl+getOssCorpCode()+urloss[i] + "@");
                }
                e.setProductVedioName(vedioStr.toString());
            }
            // 商品详情
            if (StringUtils.isNotBlank(e.getProductContent())) {
                urloss = e.getProductContent().split("[@]");
                StringBuilder productContentStr = new StringBuilder();
                if (urloss.length > 10) {
                    e.setError("商品详情最多支持10张图片");
                    items.add(e);
                    return;
                } else {
                    for (int i = 0; i < urloss.length; i++) {
                        productContentStr.append("<p><img src=\"").append(i == urloss.length - 1 ?
                                ossUrl+getOssCorpCode()+urloss[i] + "\" alt=\"\" width=\"900\"  /></p>"
                                : ossUrl+getOssCorpCode()+urloss[i] + "\" alt=\"\" width=\"900\"  /></p>\n");
                    }
                    e.setProductContent(productContentStr.toString());
                }
            }
            // 样本
            if (StringUtils.isNotBlank(e.getSample())) {
                urloss = e.getSample().split("[@]");
                if (urloss.length > 4) {
                    e.setError("最多支持4个样本");
                    items.add(e);
                    return;
                }
                StringBuilder sampleStr = new StringBuilder();
                for (int i = 0; i < urloss.length; i++) {
                    sampleStr.append(i == urloss.length - 1 ? ossUrl+getOssCorpCode()+urloss[i] : ossUrl+getOssCorpCode()+urloss[i] + "@");
                }
                e.setSample(sampleStr.toString());
            }
            successList.add(e);
        });

        if (items.size() <= 0) {
            try {
                Thread commandLineThread = new Thread(() -> {
                    try {
                        saveApplyData(successList, isSupply, supplierId, newFile, originalFilename);
                    } catch (Exception ex) {
                        log.error(ex.getMessage(), ex);
                    }
                });
                commandLineThread.start();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            } finally {
                IoUtil.close(fi);
                IoUtil.close(os);
            }
            return new JsonResult(true, "批量发布商品数据共" + importExcelDtos.size() + "条，成功" + importExcelDtos.size() + "条");
        }
        model.put("items", items);
        model.put("appendix", new ArrayList<>(0));
        try {
            List<Map<String,String>> list = publicProductFeignClient.listCataBrandProp();
            model.put("appendix", list);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //上传数据
        String targetUrl = null;
        if (!items.isEmpty()) {
            //同步到oss
            targetUrl = importProductOss(model);
        }

        try{
            Thread commandLineThread = new Thread(() -> {
                try {
                    saveApplyData(successList, isSupply, supplierId, newFile, originalFilename);
                } catch (Exception ex) {
                    log.error(ex.getMessage(), ex);
                }
            });
            commandLineThread.start();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new BaseException("-1", ex.getMessage());
        } finally {
            IoUtil.close(fi);
            IoUtil.close(os);
        }
        return new JsonResult<>(false, "批量发布商品数据共" + importExcelDtos.size() + "条，成功"
                + (importExcelDtos.size() - items.size()) + "条、失败" + items.size() + "条",
                (targetUrl == null ? "" : ossConf.getOssUrl() + targetUrl));
    }

    private PurchaseProductApply getByApplyNo(Long applyNo) {
        //验证产品申请表是否有该编码
        Example example = new Example(entityClass);
        example.orderBy(PurchaseProductApply.CREATED_AT).desc();
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(PurchaseProductApply.APPLY_NO, applyNo);
        String supplierId  = (String) ContextHandler.get("supplierId");
        if (StringUtils.isNotEmpty(supplierId)) {
            criteria.andEqualTo(PurchaseProductApply.IS_SUPPLY, "N");
            criteria.andEqualTo(PurchaseProductApply.SUPPLIER_ID, supplierId);
        } else {
            criteria.andEqualTo(PurchaseProductApply.IS_SUPPLY, "Y");
        }
        List<PurchaseProductApply> applyList = purchaseProductApplyMapper.selectByExample(example);
        if (applyList != null && applyList.size() > 0) {
            return applyList.get(0);
        }
        return null;
    }

    private PurchaseProductApply getByProductId(Long productId) {
        //验证产品申请表是否有该编码
        Example example = new Example(entityClass);
        example.orderBy(PurchaseProductApply.CREATED_AT).desc();
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(PurchaseProductApply.PUBLIC_PRODUCT_ID, productId);
        String supplierId  = (String) ContextHandler.get("supplierId");
        if (StringUtils.isNotEmpty(supplierId)) {
            criteria.andEqualTo(PurchaseProductApply.IS_SUPPLY, "N");
            criteria.andEqualTo(PurchaseProductApply.SUPPLIER_ID, supplierId);
        } else {
            criteria.andEqualTo(PurchaseProductApply.IS_SUPPLY, "Y");
        }
        List<PurchaseProductApply> applyList = purchaseProductApplyMapper.selectByExample(example);
        if (applyList != null && applyList.size() > 0) {
            return applyList.get(0);
        }
        return null;
    }

    /**
     * 上传OSS
     */
    private String importProductOss(Map<String, Object> model) {
        //保存oss
        ClassLoader classLoader = PurchaseProductApplyService.class.getClassLoader();
        InputStream is = null;
        Workbook workbook = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ByteArrayInputStream swapStream = null;
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        String name = "批量发布商品结果" + ZydDateUtils.format(ZydDateUtils.ymdhmsfGapless, new Date()) + ".xlsx";
        String targetUrl = getOssCorpCodeTwo() + ossConf.getTmp() + name;
        try {
            is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + "productError.xlsx");
            if (is != null) {
                //转换成excel并输出
                XLSTransformer transformer = new XLSTransformer();
                workbook = transformer.transformXLS(is, model);
                //将内容写入输出流并把缓存的内容全部发出去
                workbook.write(baos);
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "获取不到批量发布商品的结果模板");
            }
            swapStream = new ByteArrayInputStream(baos.toByteArray());
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(),
                    targetUrl, swapStream));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            if (result == null) {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "导入批量发布商品的结果失败");
            }
            return targetUrl;
        } catch (Exception ex) {
            log.error("【批量发布商品】导入oss的错误结果异常：{}", JSONObject.toJSONString(ex));
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "导入批量发布商品的结果失败");
        } finally {
            try {
                baos.flush();
            } catch (IOException e) {
                log.error("【批量发布商品】导入oss ByteArrayOutputStream类io异常：{}", JSONObject.toJSONString(e));
            }
            IoUtil.close(is);
            IoUtil.close(swapStream);
            IoUtil.close(workbook);
            IoUtil.close(baos);
            ossClient.shutdown();
        }
    }

    private void saveApplyData(List<PurchaseProductApply> successList, String isSupply, String supplierId, File file, String originalFilename) {
        if (CollectionUtils.isNotEmpty(successList)) {
            OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
            String applyBatchNo = IDUtils.getUUID19();
            try {
                String ossPath = getOssCorpCodeTwo() + ossConf.getProductUpload()
                        + ZydDateUtils.format(ZydDateUtils.ymdhmsfGapless, new Date()) + originalFilename;
                // 上传文件
                PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(),
                        ossPath, file));
                // 设置权限(公开读)
                ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
                String ossUrl = ossConf.getOssUrl() + ossPath;
                PurchaseProductApplyBatch applyBatch = new PurchaseProductApplyBatch();
                applyBatch.setBatchNo(applyBatchNo);
                applyBatch.setId(IDUtils.getUUID19());
                applyBatch.setFileUrl(ossUrl);
                applyBatch.setType(2);
                purchaseProductApplyBatchService.add(applyBatch);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            } finally {
                ossClient.shutdown();
            }
            for (PurchaseProductApply apply:successList) {
                String userId = ContextHandler.getUserId();
                //组装数据
                apply.setBatchNo(applyBatchNo);
                //唯一校验
                String productCode = apply.getProductCode();
                if (null == apply.getAuditType()) {
                    apply.setAuditType(1);
                }
                apply.setEditColumns("");

                PurchaseCataBrandProp purchaseCataBrandProp = new PurchaseCataBrandProp();
                purchaseCataBrandProp.setId(IDUtils.getUUID19());
                purchaseCataBrandProp.setFirstLevelCataName(apply.getFirstLevelCataName());
                purchaseCataBrandProp.setSecondLevelCataName(apply.getSecondLevelCataName());
                purchaseCataBrandProp.setThreeLevelCataName(apply.getThreeLevelCataName());
                purchaseCataBrandProp.setBrandName(apply.getBrandName());
                purchaseCataBrandProp.setPropName(apply.getPropName());
                purchaseCataBrandPropService.save(purchaseCataBrandProp);

                //审核状态（0=待审核，1=通过，2=不通过）
                List<String> productCodeList = new LinkedList<>();
                productCodeList.add(productCode);
                apply.setUpdatedBy(userId);
                apply.setCreatedBy(userId);
                apply.setIsSupply(isSupply);

                Integer oldStatus = apply.getAuditStatus();
                if ("N".equals(isSupply)) {
                    apply.setAuditStatus(0);
                    apply.setSupplierId(supplierId);
                } else {
                    apply.setAuditStatus(1);
                }

                dealBigDecimalData(apply);

                if (null != apply && null != apply.getPublicProductId()) {
                    Boolean flag = hasEdit(apply);
                    if (BooleanUtils.isFalse(flag)) {
                        continue;
                    }
                }

                if (null == apply.getApplyNo()) {
                    apply.setApplyNo(getMaxApplyNo());
                }

                Boolean needAudit = checkChangeColumnsNeedAudit(apply);
                if (BooleanUtils.isFalse(needAudit)) {
                    apply.setAuditStatus(1);
                }

                if (StringUtils.isNotEmpty(apply.getId()) && null != oldStatus && 1 != oldStatus) {
                    apply.setAuditTime(null);
                    apply.setAuditRemark(null);
                    apply.setCorpCode(ContextHandler.getCorpCode());
                    purchaseProductApplyMapper.updateByPrimaryKey(apply);
                } else {
                    apply.setId(IDUtils.getUUID19());
                    if (null != oldStatus && 1 == oldStatus) {
                        apply.setAuditType(2);
                    }
                    super.insert(apply);
                }

                if (apply.getAuditStatus() == 1) {
                    apply.setAuditTime(LocalDateTime.now());
                    PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
                    purchaseProductSync.setFirstLevelCataName(apply.getFirstLevelCataName());
                    purchaseProductSync.setSecondLevelCataName(apply.getSecondLevelCataName());
                    purchaseProductSync.setThreeLevelCataName(apply.getThreeLevelCataName());
                    purchaseProductSync.setBrandName(apply.getBrandName());
                    purchaseProductSync.setPropName(apply.getPropName());
                    purchaseProductSync.setProductCode(apply.getProductCode());
                    purchaseProductSync.setProductType(apply.getProductType());
                    purchaseProductSync.setProductErpCode(apply.getProductCode());
                    purchaseProductSync.setSkuCode(apply.getSkuCode());
                    purchaseProductSync.setStock(apply.getStock());
                    purchaseProductSync.setPrice(apply.getPrice());
                    purchaseProductSync.setSupplyPrice(apply.getSupplyPrice());
                    purchaseProductSync.setSuggestPrice(apply.getSuggestPrice());
                    purchaseProductSync.setPurchasePrice(apply.getPurchasePrice());
                    purchaseProductSync.setUnit(apply.getUnit());
                    purchaseProductSync.setWeight(apply.getWeight());
                    purchaseProductSync.setIsOnsale(apply.getIsOnsale());
                    purchaseProductSync.setDeliveryDate(apply.getDeliveryDate());
                    purchaseProductSync.setAuditTime(apply.getAuditTime());
                    purchaseProductSync.setSupplierId(apply.getSupplierId());
                    purchaseProductSync.setProductContent(apply.getProductContent());
                    purchaseProductSync.setProductVedioName(apply.getProductVedioName());
                    purchaseProductSync.setProductPicName(apply.getProductPicName());
                    purchaseProductSync.setSpecData(apply.getSpecData());
                    purchaseProductSync.setPublicProductId(apply.getPublicProductId());
                    purchaseProductSync.setId(apply.getId());
                    purchaseProductSync.setSample(apply.getSample());
                    purchaseProductSync.setPublicProductId(apply.getPublicProductId());
                    purchaseProductSync.setApplyNo(apply.getApplyNo());
                    purchaseProductSync.setMaterialName(apply.getMaterialName());
                    JsonResult<Long> jsonResult = publicProductFeignClient.purchaseProductSync(purchaseProductSync);
                    if (null != jsonResult && BooleanUtils.isTrue(jsonResult.isSuccess())) {
                        apply.setPublicProductId(jsonResult.getData());
                        super.update(apply);
                    }
                }
            }
        }
    }

    /**
     * 获取最大产品id+1
     *
     * @return
     */
    public Long getMaxApplyNo() {
        Long num = RedisUtils.genCode("apply_no", redisTemplate, () -> {
            return purchaseProductApplyMapper.getMaxApplyNo();
        });
        try{
            DecimalFormat df = new DecimalFormat("00000000000");
            String numTemp = "1688" + df.format(num);
            num = Long.parseLong(numTemp);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return num;
    }

    private PurchaseProductApply getDataIdByProductCode(String productCode, Integer auditStatus) {
        if (StringUtils.isNotEmpty(productCode)) {
            Example example = new Example(entityClass);
            Example.Criteria criteria = example.createCriteria();
            criteria.andEqualTo(PurchaseProductApply.PRODUCT_CODE, productCode);
            criteria.andEqualTo(PurchaseProductApply.AUDIT_STATUS, auditStatus);
            List<PurchaseProductApply> applyList = purchaseProductApplyMapper.selectByExample(example);
            if (CollectionUtils.isNotEmpty(applyList)) {
                return applyList.get(0);
            }
        }
        return null;
    }

    private List<PurchaseProductApply> changeExcel(FileInputStream fi) {
        //商品申请模块读取excel模块
        List<PurchaseProductApply> importExcelDtos = new ArrayList<>();
        XSSFWorkbook xssfWorkbook = null;
        PurchaseProductApply productImportExcelDto;
        try {
            xssfWorkbook = new XSSFWorkbook(fi);
            XSSFSheet sheet = xssfWorkbook.getSheetAt(0);//sheet 从0开始
            int rowNum = sheet.getLastRowNum() + 1;//取得最后一行的行号
            XSSFRow xssfRow;
            XSSFCell xssfCell;
            rowfor:
            for (int i = 2; i < rowNum; i++) {//行循环开始
                xssfRow = sheet.getRow(i);
                if (xssfRow == null) {
                    continue;
                }
                productImportExcelDto = new PurchaseProductApply();
                productImportExcelDto.setRow(i + 1);
                String cellValue_productId = null;
                String cellValue_firstLevelCataName = null;
                String cellValue_secondLevelCataName = null;
                String cellValue_threeLevelCataName = null;
                String cellValue_brandName = null;
                String cellValue_propName = null;
                String cellValue_specData = null;
                String cellValue_skuCode = null;
                String cellValue_productCode = null;
                String cellValue_productType = null;
                String cellValue_productErpCode = null;
                String cellValue_supplyPrice = null;
                String cellValue_purchasePrice = null;
                String cellValue_price = "";
                String cellValue_suggestPrice = "";
                String cellValue_stock = null;
                String cellValue_deliveryDate = null;
                String cellValue_weight = null;
                String cellValue_productPicName = null;
                String cellValue_productVedioName = null;
                String cellValue_productContent = null;
                String cellValue_product_simple_name = null;
                String cellValue_isOnsale = null;
                cellfor:
                for (int j = 0; j < 22; j++) { //列循环开始
                    xssfCell = xssfRow.getCell(j);
                    if (xssfCell == null) {
                        continue cellfor;
                    }
                    xssfCell.setCellType(CellType.STRING);
                    switch (j) {
                        case 0:
                            cellValue_productId = xssfCell.getStringCellValue().trim();
                            break;
                        case 1:
                            cellValue_firstLevelCataName = xssfCell.getStringCellValue().trim();
                            break;
                        case 2:
                            cellValue_secondLevelCataName = xssfCell.getStringCellValue().trim();
                            break;
                        case 3:
                            cellValue_threeLevelCataName = xssfCell.getStringCellValue().trim();
                            break;
                        case 4:
                            cellValue_brandName = xssfCell.getStringCellValue().trim();
                            break;
                        case 5:
                            cellValue_propName = xssfCell.getStringCellValue().trim();
                            break;
                        case 6:
                            //产品型号
                            cellValue_productType = xssfCell.getStringCellValue().trim();
                            break;
                        case 7:
                            //订货号
                            cellValue_skuCode = xssfCell.getStringCellValue().trim();
                            break;
                        case 8:
                            //商品编号
                            cellValue_productCode = xssfCell.getStringCellValue().trim();
                            break;
                        case 9:
                            //供货价
                            cellValue_supplyPrice = xssfCell.getStringCellValue().trim();
                            break;
                        case 10:
                            //慧彩价
                            cellValue_purchasePrice = xssfCell.getStringCellValue().trim();
                            break;
                        case 11:
                            //面价
                            cellValue_price = xssfCell.getStringCellValue().trim();
                            break;
                        case 12:
                            //建议零售价
                            cellValue_suggestPrice = xssfCell.getStringCellValue().trim();
                            break;
                        case 13:
                            //库存
                            cellValue_stock = xssfCell.getStringCellValue().trim();
                            break;
                        case 14:
                            //货期
                            cellValue_deliveryDate = xssfCell.getStringCellValue().trim();
                            break;
                        case 15:
                            //重量
                            cellValue_weight = xssfCell.getStringCellValue().trim();
                            break;
                        case 16:
                            //规格名和规格值
                            cellValue_specData = xssfCell.getStringCellValue().trim();
                            break;
                        case 17:
                            //是否上架
                            cellValue_isOnsale = xssfCell.getStringCellValue().trim();
                            break;
                        case 18:
                            //商品图片
                            cellValue_productPicName = xssfCell.getStringCellValue().trim();
                            break;
                        case 19:
                            //视频详情
                            cellValue_productVedioName = xssfCell.getStringCellValue().trim();
                            break;
                        case 20:
                            //商品详情
                            cellValue_productContent = xssfCell.getStringCellValue().trim();
                            break;
                        case 21:
                            //样本
                            cellValue_product_simple_name = xssfCell.getStringCellValue().trim();
                            break;
                    }
                }
                // 如果全部是空，当行数据跳掉
                if (StringUtils.isBlank(cellValue_productId)
                        &&StringUtils.isBlank(cellValue_firstLevelCataName)
                        && StringUtils.isBlank(cellValue_secondLevelCataName)
                        && StringUtils.isBlank(cellValue_threeLevelCataName)
                        && StringUtils.isBlank(cellValue_supplyPrice)
                        && StringUtils.isBlank(cellValue_purchasePrice)
                        && StringUtils.isBlank(cellValue_suggestPrice)
                        && StringUtils.isBlank(cellValue_brandName)
                        && StringUtils.isBlank(cellValue_propName)
                        && StringUtils.isBlank(cellValue_productCode)
                        && StringUtils.isBlank(cellValue_skuCode)
                        && StringUtils.isBlank(cellValue_productType)
                        && StringUtils.isBlank(cellValue_isOnsale)
                        && StringUtils.isBlank(cellValue_price)
                        && StringUtils.isBlank(cellValue_stock)
                        && StringUtils.isBlank(cellValue_deliveryDate)
                        && StringUtils.isBlank(cellValue_weight)
                        && StringUtils.isBlank(cellValue_productPicName)
                        && StringUtils.isBlank(cellValue_productVedioName)
                        && StringUtils.isBlank(cellValue_productContent)
                        && StringUtils.isBlank(cellValue_product_simple_name)) {
                    continue rowfor;
                }
                log.info("cellValue_productId:{}", cellValue_productId);
                if (StringUtils.isNotEmpty(cellValue_productId)) {
                    productImportExcelDto.setApplyNo(Long.parseLong(cellValue_productId));
                }
                productImportExcelDto.setFirstLevelCataName(cellValue_firstLevelCataName);
                productImportExcelDto.setSecondLevelCataName(cellValue_secondLevelCataName);
                productImportExcelDto.setThreeLevelCataName(cellValue_threeLevelCataName);
                productImportExcelDto.setBrandName(cellValue_brandName);
                productImportExcelDto.setPropName(cellValue_propName);

                productImportExcelDto.setSkuCode(cellValue_skuCode);
                productImportExcelDto.setProductType(cellValue_productType);
                productImportExcelDto.setProductCode(cellValue_productCode);
                productImportExcelDto.setSupplyPriceStr(StringUtils.isBlank(cellValue_supplyPrice) ? "" : cellValue_supplyPrice.replace("¥", ""));
                productImportExcelDto.setPurchasePriceStr(StringUtils.isBlank(cellValue_purchasePrice) ? "" : cellValue_purchasePrice.replace("¥", ""));
                productImportExcelDto.setPriceStr(StringUtils.isBlank(cellValue_price) ? "" : cellValue_price.replace("¥", ""));
                productImportExcelDto.setSuggestPriceStr(StringUtils.isBlank(cellValue_suggestPrice) ? "" : cellValue_suggestPrice.replace("¥", ""));
                if (StringUtils.isNotEmpty(cellValue_stock)) {
                    productImportExcelDto.setStock(Integer.parseInt(cellValue_stock));
                }
                productImportExcelDto.setDeliveryDate(cellValue_deliveryDate);
                productImportExcelDto.setWeight(cellValue_weight);
                productImportExcelDto.setSpecValueStr(cellValue_specData);
                productImportExcelDto.setIsOnsale(cellValue_isOnsale);
                //productImportExcelDto.setUnit(cellValue_unit);
                productImportExcelDto.setDeliveryDate(cellValue_deliveryDate);
                productImportExcelDto.setProductPicName(StringUtils.isBlank(cellValue_productPicName) ? "" : cellValue_productPicName);
                productImportExcelDto.setProductVedioName(StringUtils.isBlank(cellValue_productVedioName) ? "" : cellValue_productVedioName);
                productImportExcelDto.setProductContent(StringUtils.isBlank(cellValue_productContent) ? "" : cellValue_productContent);
                productImportExcelDto.setSample(StringUtils.isBlank(cellValue_product_simple_name) ? "" : cellValue_product_simple_name);
                importExcelDtos.add(productImportExcelDto);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new BaseException("-1", "转换excel数据异常");
        } finally {
            IoUtil.close(xssfWorkbook);
        }
        return importExcelDtos;
    }



    /**
     * 把错误结果文件导入oss
     *
     * @param model
     * @return
     */
    private String importResultToOss(Map<String, Object> model) {
        //保存oss
        ClassLoader classLoader = PurchaseProductApplyService.class.getClassLoader();
        InputStream is = null;
        Workbook workbook = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ByteArrayInputStream swapStream = null;
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        String resultName = "商品导入结果" + ZydDateUtils.format(ZydDateUtils.ymdhmsfGapless, new Date()) + ".xlsx";
        String targetUrl = ContextHandler.getCorpCode() + ossConf.getTmp() + resultName;
        try {
            is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + "applyProductError.xlsx");
            if (is != null) {
                //转换成excel并输出
                XLSTransformer transformer = new XLSTransformer();
                workbook = transformer.transformXLS(is, model);
                //将内容写入输出流并把缓存的内容全部发出去
                workbook.write(baos);
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "获取不到生成错误格式的结果模板");
            }
            swapStream = new ByteArrayInputStream(baos.toByteArray());
            // 上传结果文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(),
                    targetUrl, swapStream));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            if (result == null) {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "导入生成错误格式的结果失败~");
            }
            return targetUrl;
        } catch (Exception ex) {
            log.error("【商品申请】-导入oss的错误结果异常：{}", JSONObject.toJSONString(ex));
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "商品导入失败~");
        } finally {
            try {
                baos.flush();
            } catch (IOException e) {
                log.error("【商品申请】-导入oss ByteArrayOutputStream类io异常：{}", JSONObject.toJSONString(e));
            }
            IoUtil.close(is);
            IoUtil.close(swapStream);
            IoUtil.close(workbook);
            IoUtil.close(baos);
            ossClient.shutdown();
        }
    }

    public JsonResult<String> stockImport(MultipartFile file, String isSupply) {
        Integer errorNum = 0;
        String corpCode = ContextHandler.getCorpCode();
        FileInputStream fi = null;
        FileOutputStream os = null;
        File newFile = new File(UUID.randomUUID().toString());
        List<ImportStockVO> importStockList = null;
        String supplierId  = (String) ContextHandler.get("supplierId");
        if ("N".equals(isSupply) && StringUtils.isBlank(supplierId)) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "不是供应商账号不可申请！");
        }
        if ("Y".equals(isSupply) && StringUtils.isNotBlank(supplierId)) {
            throw new BaseException(String.valueOf(ExceptionDictionary.INVALID_ACCESS.getCode()), "不是供应链账号不可申请！");
        }
        try {
            os = new FileOutputStream(newFile);
            os.write(file.getBytes());
            file.transferTo(newFile);
            fi = new FileInputStream(newFile);
            importStockList = changeXExcel(fi);
        } catch (Exception e) {
            log.error("批量上传库存异常:{}", JSONObject.toJSONString(e));
        } finally {
            IoUtil.close(fi);
            IoUtil.close(os);
        }

        if (importStockList == null || importStockList.size() <= 0) {
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "excel数据为空");
        }
        if (importStockList.size() > 4000) {
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "一次最多导入4000条");
        }

        //将数据插入数据库
        Pattern pattern = Pattern.compile("^[0-9]*[1-9][0-9]*$");

        //查询存在的商品编码
        List<String> productCodes = importStockList.stream().map(ImportStockVO::getProductCode).collect(Collectors.toList());
        List<CommonProductDto> existProductList = publicProductFeignClient.fndExistProductCode(productCodes);
        Map<String,CommonProductDto> map = new HashMap<>();
        if (CollectionUtils.isNotEmpty(existProductList)) {
            for (CommonProductDto commonProductDto:existProductList) {
                map.put(commonProductDto.getErpProductCode(), commonProductDto);
            }
            List<String> existProductCodeEdit = existProductList.stream().map(CommonProductDto::getErpProductCode).collect(Collectors.toList());
            //筛选不存在的商品编码
            productCodes.removeAll(existProductCodeEdit);
        }

        for (ImportStockVO sv : importStockList) {
            String productCodeEdit = sv.getProductCode();
            String stock = ZydUtils.checkNull(sv.getStock()) ? null : sv.getStock();
            if (ZydUtils.checkNull(productCodeEdit)) {
                errorNum += 1;
                sv.setRemark("商品编码为空");
            } else if (productCodes.contains(productCodeEdit)) {
                errorNum += 1;
                sv.setRemark("商品编码不存在");
            } else if (ZydUtils.checkNull(stock) || !pattern.matcher(stock).matches()) {
                errorNum += 1;
                sv.setRemark("库存数量不正确");
            } else if (!ZydUtils.checkNull(productCodeEdit) && !ZydUtils.checkNull(stock) && pattern.matcher(stock).matches()) {
                // 修改库存
                PurchaseProductApply tmp = new PurchaseProductApply();
                tmp.setProductCode(productCodeEdit);
                tmp.setCorpCode(corpCode);
                CommonProductDto commonProductDto = map.get(productCodeEdit);
                if (commonProductDto != null) {
                    try {
                        commonProductDto.setStock(Integer.parseInt(sv.getStock()));
                        int i = saveStockApplyData(commonProductDto, isSupply);
                        sv.setRemark("导入成功");
                    } catch (Exception e) {
                        sv.setRemark("导入失败");
                    }
                }
            }
        }
        //上传数据
        String targetUrl = null;
        if (!importStockList.isEmpty()) {
            Map<String, Object> model = new HashMap<>();
            model.put("items", importStockList);
            //同步到oss
            targetUrl = importOss(model);
        }
        Boolean bool = true;
        if (errorNum > 0) {
            bool = false;
        }
        return new JsonResult<>(bool, "批量上传库存数据共" + importStockList.size() + "条，成功"
                + (importStockList.size() - errorNum) + "条、失败" + errorNum + "条",
                (targetUrl == null ? "" : ossConf.getOssUrl() + targetUrl));
    }

    private Integer saveStockApplyData(CommonProductDto commonProductDto, String isSupply) {
        PurchaseProductApply purchaseProductApply = new PurchaseProductApply();
        purchaseProductApply.setId(IDUtils.getUUID19());
        purchaseProductApply.setProductErpCode(commonProductDto.getErpProductCode());
        purchaseProductApply.setPublicProductId(commonProductDto.getProductId());
        purchaseProductApply.setFirstLevelCataName(commonProductDto.getCataNameOne());
        purchaseProductApply.setSecondLevelCataName(commonProductDto.getCataNameTwo());
        purchaseProductApply.setThreeLevelCataName(commonProductDto.getCataNameThree());
        purchaseProductApply.setBrandName(commonProductDto.getBrandName());
        purchaseProductApply.setPropName(commonProductDto.getPropName());
        purchaseProductApply.setSpecData(commonProductDto.getSpecData());
        purchaseProductApply.setProductType(commonProductDto.getProductType());
        purchaseProductApply.setSkuCode(commonProductDto.getSkuCode());
        purchaseProductApply.setProductCode(commonProductDto.getSupplierProductCode());
        purchaseProductApply.setSuggestPrice(commonProductDto.getSuggestPrice());
        purchaseProductApply.setSupplyPrice(commonProductDto.getSupplyPrice());
        purchaseProductApply.setPurchasePrice(commonProductDto.getPurchasePrice());
        purchaseProductApply.setPrice(commonProductDto.getPrice());
        purchaseProductApply.setStock(commonProductDto.getStock());
        purchaseProductApply.setDeliveryDate(commonProductDto.getDeliveryDate());
        purchaseProductApply.setUnit(commonProductDto.getUnit());
        purchaseProductApply.setWeight(commonProductDto.getWeight());
        purchaseProductApply.setProductPicName(commonProductDto.getProductPicName());
        purchaseProductApply.setProductContent(commonProductDto.getProductContent());
        purchaseProductApply.setAuditType(2);
        purchaseProductApply.setAuditStatus(0);
        purchaseProductApply.setIsOnsale("Y");
        purchaseProductApply.setIsSupply(isSupply);
        purchaseProductApply.setSample(commonProductDto.getSample());
        purchaseProductApply.setApplyNo(commonProductDto.getApplyNo());
        String supplierId = (String) ContextHandler.get("supplierId");
        purchaseProductApply.setSupplierId("Y".equals(isSupply) ? "" : supplierId);
        if ("Y".equals(isSupply)) {
            purchaseProductApply.setAuditStatus(1);
            purchaseProductApply.setAuditTime(LocalDateTime.now());
        }
        purchaseProductApply.setEditColumns("stock");

        List<ProductProperties> productProperties = productPropertiesService.listByParam("stock");
        Boolean isEmpty = CollectionUtils.isEmpty(productProperties);
        if (BooleanUtils.isTrue(isEmpty)) {
            purchaseProductApply.setAuditStatus(1);
            purchaseProductApply.setAuditTime(LocalDateTime.now());
        }
        Boolean flag = true;
        if (null != purchaseProductApply.getPublicProductId()) {
            if (null != purchaseProductApply.getPublicProductId()) {
                Example example = new Example(entityClass);
                example.orderBy(PurchaseProductApply.CREATED_AT).desc();
                Example.Criteria criteria = example.createCriteria();
                criteria.andEqualTo(PurchaseProductApply.PUBLIC_PRODUCT_ID, purchaseProductApply.getPublicProductId());
                List<PurchaseProductApply> applyList = purchaseProductApplyMapper.selectByExample(example);
                if (applyList != null && applyList.size() > 0) {
                    PurchaseProductApply apply1 = applyList.get(0);
                    if (null != apply1 && 1 != apply1.getAuditStatus()) {
                        purchaseProductApply.setId(apply1.getId());
                        if (1 != purchaseProductApply.getAuditStatus()) {
                            purchaseProductApply.setAuditTime(null);
                            purchaseProductApply.setAuditRemark(null);
                            purchaseProductApply.setAuditStatus(0);
                        }
                        purchaseProductApply.setCorpCode(ContextHandler.getCorpCode());
                        purchaseProductApply.setCreatedBy(apply1.getCreatedBy());
                        purchaseProductApply.setCreatedAt(apply1.getCreatedAt());
                        purchaseProductApplyMapper.updateByPrimaryKey(purchaseProductApply);
                        flag = false;
                    }
                }
            }
        }

        if (BooleanUtils.isTrue(flag)) {
            this.insert(purchaseProductApply);
        }

        if ("Y".equals(isSupply) || isEmpty) {
            PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
            purchaseProductSync.setFirstLevelCataName(purchaseProductApply.getFirstLevelCataName());
            purchaseProductSync.setSecondLevelCataName(purchaseProductApply.getSecondLevelCataName());
            purchaseProductSync.setThreeLevelCataName(purchaseProductApply.getThreeLevelCataName());
            purchaseProductSync.setBrandName(purchaseProductApply.getBrandName());
            purchaseProductSync.setPropName(purchaseProductApply.getPropName());
            purchaseProductSync.setProductCode(purchaseProductApply.getProductCode());
            purchaseProductSync.setProductType(purchaseProductApply.getProductType());
            purchaseProductSync.setProductErpCode(purchaseProductApply.getProductErpCode());
            purchaseProductSync.setSkuCode(purchaseProductApply.getSkuCode());
            purchaseProductSync.setStock(purchaseProductApply.getStock());
            purchaseProductSync.setPrice(purchaseProductApply.getPrice());
            purchaseProductSync.setSupplyPrice(purchaseProductApply.getSupplyPrice());
            purchaseProductSync.setSuggestPrice(purchaseProductApply.getSuggestPrice());
            purchaseProductSync.setPurchasePrice(purchaseProductApply.getPurchasePrice());
            purchaseProductSync.setUnit(purchaseProductApply.getUnit());
            purchaseProductSync.setWeight(purchaseProductApply.getWeight());
            purchaseProductSync.setIsOnsale(purchaseProductApply.getIsOnsale());
            purchaseProductSync.setDeliveryDate(purchaseProductApply.getDeliveryDate());
            purchaseProductSync.setAuditTime(purchaseProductApply.getAuditTime());
            purchaseProductSync.setSupplierId(purchaseProductApply.getSupplierId());
            purchaseProductSync.setProductContent(purchaseProductApply.getProductContent());
            purchaseProductSync.setProductVedioName(purchaseProductApply.getProductVedioName());
            purchaseProductSync.setProductPicName(purchaseProductApply.getProductPicName());
            purchaseProductSync.setSpecData(purchaseProductApply.getSpecData());
            purchaseProductSync.setPublicProductId(purchaseProductApply.getPublicProductId());
            purchaseProductSync.setSample(purchaseProductApply.getSample());
            purchaseProductSync.setId(purchaseProductApply.getId());
            purchaseProductSync.setApplyNo(purchaseProductApply.getApplyNo());
            publicProductFeignClient.purchaseProductSync(purchaseProductSync);
        }
        return 1;
    }

    /**
     * 读取 Excel 内容
     */
    public List<ImportStockVO> changeXExcel(FileInputStream fi) {
        List<ImportStockVO> list = new ArrayList<>();
        XSSFWorkbook xssfWorkbook = null;
        ImportStockVO param;
        try {
            xssfWorkbook = new XSSFWorkbook(fi);
            XSSFSheet sheet = xssfWorkbook.getSheetAt(0);//sheet 从0开始
            int rowNum = sheet.getLastRowNum() + 1;//取得最后一行的行号
            XSSFRow xssfRow;
            XSSFCell xssfCell;
            rowfor:
            for (int i = 1; i < rowNum; i++) {//行循环开始
                xssfRow = sheet.getRow(i);
                if (xssfRow == null) {
                    continue;
                }
                param = new ImportStockVO();
                param.setRow(i + 1);
                String cellValue_productCode = null;
                String cellValue_stock = null;
                String cellValue_remark = null;
                cellfor:
                for (int j = 0; j < 3; j++) { //列循环开始
                    xssfCell = xssfRow.getCell(j);
                    if (xssfCell == null) {
                        continue cellfor;
                    }
                    xssfCell.setCellType(CellType.STRING);
                    switch (j) {
                        case 0:
                            cellValue_productCode = xssfCell.getStringCellValue().trim();
                            break;
                        case 1:
                            cellValue_stock = xssfCell.getStringCellValue().trim();
                            break;
                        case 2:
                            cellValue_remark = xssfCell.getStringCellValue().trim();
                            break;

                    }
                }
                //如果全部是空，当行数据跳掉
                if (StringUtils.isBlank(cellValue_productCode)
                        && StringUtils.isBlank(cellValue_stock)
                        && StringUtils.isBlank(cellValue_remark)) {
                    continue rowfor;
                }
                param.setProductCode(cellValue_productCode);
                param.setStock(cellValue_stock);
                param.setRemark(cellValue_remark);
                list.add(param);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new BaseException("-1", "转换excel数据异常");
        } finally {
            IoUtil.close(xssfWorkbook);
        }
        return list;
    }

    /**
     * 上传OSS
     */
    private String importOss(Map<String, Object> model) {
        //保存oss
        ClassLoader classLoader = PurchaseProductApplyService.class.getClassLoader();
        InputStream is = null;
        Workbook workbook = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ByteArrayInputStream swapStream = null;
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        String name = "批量上传库存结果" + ZydDateUtils.format(ZydDateUtils.ymdhmsfGapless, new Date()) + ".xlsx";
        String targetUrl = getOssCorpCodeTwo() + ossConf.getTmp() + name;
        try {
            is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + "stockError.xlsx");
            if (is != null) {
                //转换成excel并输出
                XLSTransformer transformer = new XLSTransformer();
                workbook = transformer.transformXLS(is, model);
                //将内容写入输出流并把缓存的内容全部发出去
                workbook.write(baos);
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "获取不到批量上传库存的结果模板");
            }
            swapStream = new ByteArrayInputStream(baos.toByteArray());
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(),
                    targetUrl, swapStream));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            if (result == null) {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "导入批量上传库存的结果失败");
            }
            return targetUrl;
        } catch (Exception ex) {
            log.error("【批量上传库存】导入oss的错误结果异常：{}", JSONObject.toJSONString(ex));
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "导入批量上传库存的结果失败");
        } finally {
            try {
                baos.flush();
            } catch (IOException e) {
                log.error("【批量上传库存】导入oss ByteArrayOutputStream类io异常：{}", JSONObject.toJSONString(e));
            }
            IoUtil.close(is);
            IoUtil.close(swapStream);
            IoUtil.close(workbook);
            IoUtil.close(baos);
            ossClient.shutdown();
        }
    }

    /**
     * 批量上架
     * @param productCodeSubDtos
     * @return
     */
    @Transactional
    public JsonResult upSale(List<ProductCodeDto.ProductCodeSubDto> productCodeSubDtos, Boolean isSupply) {
        if (productCodeSubDtos == null || productCodeSubDtos.size() <= 0) {
            return new JsonResult(false, "请选择数据");
        }
        //判断租户是否有产品数据
        PurchaseProductApply purchaseProductApply;
        List<Long> productIds = productCodeSubDtos.stream().map(ProductCodeDto.ProductCodeSubDto::getProductId).collect(Collectors.toList());
        List<CommonProductDto> commonProductDtos = publicProductFeignClient.listProductByProductIds(productIds);
        Map<Long,CommonProductDto> commonProductDtoMap = new HashMap<>(commonProductDtos.size());
        for (CommonProductDto commonProductDto:commonProductDtos) {
            commonProductDtoMap.put(commonProductDto.getProductId(), commonProductDto);
        }
        List<PurchaseProductApply> purchaseProductApplyList = new ArrayList<>();
        List<ProductProperties> productProperties = productPropertiesService.listByParam("isOnsale");
        Boolean isEmpty = CollectionUtils.isEmpty(productProperties);
        for (ProductCodeDto.ProductCodeSubDto productCodeSubDto : productCodeSubDtos) {
            if (productCodeSubDto.getProductId() == null) {
                continue;
            }
            CommonProductDto commonProductDto = null;
            commonProductDto = commonProductDtoMap.get(productCodeSubDto.getProductId());
            //如果没有则报错
            if (commonProductDto == null) {
                return new JsonResult(false, productCodeSubDto.getProductId() + "查询不到产品");
            }
            //需要校验公海上架状态
            if (commonProductDto.getIsOnsale().equals("Y")) {
                return new JsonResult(false, "商品序号" + commonProductDto.getApplyNo() + "为上架状态，无法上架");
            }
            purchaseProductApply = new PurchaseProductApply();
            purchaseProductApply.setId(IDUtils.getUUID19());
            purchaseProductApply.setProductErpCode(commonProductDto.getErpProductCode());
            purchaseProductApply.setPublicProductId(commonProductDto.getProductId());
            purchaseProductApply.setFirstLevelCataName(commonProductDto.getCataNameOne());
            purchaseProductApply.setSecondLevelCataName(commonProductDto.getCataNameTwo());
            purchaseProductApply.setThreeLevelCataName(commonProductDto.getCataNameThree());
            purchaseProductApply.setBrandName(commonProductDto.getBrandName());
            purchaseProductApply.setPropName(commonProductDto.getPropName());
            purchaseProductApply.setSpecData(commonProductDto.getSpecData());
            purchaseProductApply.setProductType(commonProductDto.getProductType());
            purchaseProductApply.setSkuCode(commonProductDto.getSkuCode());
            purchaseProductApply.setProductCode(commonProductDto.getSupplierProductCode());
            purchaseProductApply.setSuggestPrice(commonProductDto.getSuggestPrice());
            purchaseProductApply.setSupplyPrice(commonProductDto.getSupplyPrice());
            purchaseProductApply.setPurchasePrice(commonProductDto.getPurchasePrice());
            purchaseProductApply.setPrice(commonProductDto.getPrice());
            purchaseProductApply.setStock(commonProductDto.getStock());
            purchaseProductApply.setApplySource(commonProductDto.getApplySource());
            purchaseProductApply.setMaterialName(commonProductDto.getMaterialName());
            purchaseProductApply.setDeliveryDate(commonProductDto.getDeliveryDate());
            purchaseProductApply.setUnit(commonProductDto.getUnit());
            purchaseProductApply.setWeight(commonProductDto.getWeight());
            purchaseProductApply.setProductPicName(commonProductDto.getProductPicName());
            purchaseProductApply.setProductVedioName(commonProductDto.getProductVedioName());
            purchaseProductApply.setProductContent(commonProductDto.getProductContent());
            purchaseProductApply.setAuditType(2);
            purchaseProductApply.setAuditStatus(0);
            purchaseProductApply.setIsOnsale("Y");
            purchaseProductApply.setSample(commonProductDto.getSample());
            purchaseProductApply.setApplyNo(commonProductDto.getApplyNo());
            purchaseProductApply.setIsSupply(BooleanUtils.isTrue(isSupply) ? "Y" : "N");
            String supplierId = (String) ContextHandler.get("supplierId");
            purchaseProductApply.setSupplierId(BooleanUtils.isTrue(isSupply) ? "" : supplierId);
            if (BooleanUtils.isTrue(isSupply)) {
                purchaseProductApply.setAuditStatus(1);
                purchaseProductApply.setProductErpCode(commonProductDto.getErpProductCode());
                purchaseProductApply.setAuditTime(LocalDateTime.now());
            }
            if (BooleanUtils.isTrue(isEmpty)) {
                purchaseProductApply.setAuditStatus(1);
                purchaseProductApply.setAuditTime(LocalDateTime.now());
            }
            purchaseProductApply.setEditColumns("isOnsale");
            purchaseProductApplyList.add(purchaseProductApply);
        }

        //this.batchInsert(purchaseProductApplyList);
        batchSave(purchaseProductApplyList);
        if (BooleanUtils.isTrue(isSupply) || BooleanUtils.isTrue(isEmpty)) {
            for (PurchaseProductApply apply:purchaseProductApplyList) {
                PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
                purchaseProductSync.setFirstLevelCataName(apply.getFirstLevelCataName());
                purchaseProductSync.setSecondLevelCataName(apply.getSecondLevelCataName());
                purchaseProductSync.setThreeLevelCataName(apply.getThreeLevelCataName());
                purchaseProductSync.setBrandName(apply.getBrandName());
                purchaseProductSync.setPropName(apply.getPropName());
                purchaseProductSync.setProductErpCode(apply.getProductErpCode());
                purchaseProductSync.setProductType(apply.getProductType());
                purchaseProductSync.setProductCode(apply.getProductCode());
                purchaseProductSync.setSkuCode(apply.getSkuCode());
                purchaseProductSync.setStock(apply.getStock());
                purchaseProductSync.setPrice(apply.getPrice());
                purchaseProductSync.setSupplyPrice(apply.getSupplyPrice());
                purchaseProductSync.setSuggestPrice(apply.getSuggestPrice());
                purchaseProductSync.setPurchasePrice(apply.getPurchasePrice());
                purchaseProductSync.setUnit(apply.getUnit());
                purchaseProductSync.setWeight(apply.getWeight());
                purchaseProductSync.setIsOnsale(apply.getIsOnsale());
                purchaseProductSync.setDeliveryDate(apply.getDeliveryDate());
                purchaseProductSync.setAuditTime(apply.getAuditTime());
                purchaseProductSync.setSupplierId(apply.getSupplierId());
                purchaseProductSync.setProductContent(apply.getProductContent());
                purchaseProductSync.setProductVedioName(apply.getProductVedioName());
                purchaseProductSync.setProductPicName(apply.getProductPicName());
                purchaseProductSync.setSpecData(apply.getSpecData());
                purchaseProductSync.setPublicProductId(apply.getPublicProductId());
                purchaseProductSync.setSample(apply.getSample());
                purchaseProductSync.setApplyNo(apply.getApplyNo());
                purchaseProductSync.setId(apply.getId());
                purchaseProductSync.setMaterialName(apply.getMaterialName());
                purchaseProductSync.setApplySource(apply.getApplySource());
                publicProductFeignClient.purchaseProductSync(purchaseProductSync);
            }
        }
        return new JsonResult(true, "");
    }

    private void batchSave(List<PurchaseProductApply> purchaseProductApplyList) {
        for (PurchaseProductApply apply:purchaseProductApplyList) {
            if (null != apply.getPublicProductId()) {
                if (null != apply.getPublicProductId()) {
                    Example example = new Example(entityClass);
                    example.orderBy(PurchaseProductApply.CREATED_AT).desc();
                    Example.Criteria criteria = example.createCriteria();
                    criteria.andEqualTo(PurchaseProductApply.PUBLIC_PRODUCT_ID, apply.getPublicProductId());
                    List<PurchaseProductApply> applyList = purchaseProductApplyMapper.selectByExample(example);
                    if (applyList != null && applyList.size() > 0) {
                        PurchaseProductApply apply1 = applyList.get(0);
                        if (null != apply1 && 1 != apply1.getAuditStatus()) {
                            apply.setId(apply1.getId());
                            if (1 != apply.getAuditStatus()) {
                                apply.setAuditTime(null);
                                apply.setAuditRemark(null);
                                apply.setAuditStatus(0);
                            }
                            apply.setCreatedBy(apply1.getCreatedBy());
                            apply.setCreatedAt(apply1.getCreatedAt());
                            apply.setCorpCode(ContextHandler.getCorpCode());
                            purchaseProductApplyMapper.updateByPrimaryKey(apply);
                            continue;
                        }
                    }
                }
            }
            super.insert(apply);
        }
    }

    /**
     * 批量下架
     * @param productCodeSubDtos
     * @return
     */
    @Transactional
    public JsonResult downSale(List<ProductCodeDto.ProductCodeSubDto> productCodeSubDtos, Boolean isSupply) {
        if (productCodeSubDtos == null || productCodeSubDtos.size() <= 0) {
            return new JsonResult(false, "请选择数据");
        }
        //判断租户是否有产品数据
        PurchaseProductApply purchaseProductApply;
        List<Long> productIds = productCodeSubDtos.stream().map(ProductCodeDto.ProductCodeSubDto::getProductId).collect(Collectors.toList());
        List<CommonProductDto> commonProductDtos = publicProductFeignClient.listProductByProductIds(productIds);
        Map<Long,CommonProductDto> commonProductDtoMap = new HashMap<>(commonProductDtos.size());
        for (CommonProductDto commonProductDto:commonProductDtos) {
            commonProductDtoMap.put(commonProductDto.getProductId(), commonProductDto);
        }
        List<PurchaseProductApply> purchaseProductApplyList = new ArrayList<>();
        List<ProductProperties> productProperties = productPropertiesService.listByParam("isOnsale");
        Boolean isEmpty = CollectionUtils.isEmpty(productProperties);
        for (ProductCodeDto.ProductCodeSubDto productCodeSubDto : productCodeSubDtos) {
            if (productCodeSubDto.getProductId() == null) {
                continue;
            }
            CommonProductDto commonProductDto = null;
            commonProductDto = commonProductDtoMap.get(productCodeSubDto.getProductId());
            //如果没有则报错
            if (commonProductDto == null) {
                return new JsonResult(false, productCodeSubDto.getProductId() + "查询不到产品");
            }
            //需要校验公海上架状态
            if (commonProductDto.getIsOnsale().equals("N")) {
                return new JsonResult(false, "商品序号" + commonProductDto.getApplyNo() + "为下架状态，无法下架");
            }
            purchaseProductApply = new PurchaseProductApply();
            purchaseProductApply.setId(IDUtils.getUUID19());
            purchaseProductApply.setProductErpCode(commonProductDto.getErpProductCode());
            purchaseProductApply.setPublicProductId(commonProductDto.getProductId());
            purchaseProductApply.setFirstLevelCataName(commonProductDto.getCataNameOne());
            purchaseProductApply.setSecondLevelCataName(commonProductDto.getCataNameTwo());
            purchaseProductApply.setThreeLevelCataName(commonProductDto.getCataNameThree());
            purchaseProductApply.setBrandName(commonProductDto.getBrandName());
            purchaseProductApply.setPropName(commonProductDto.getPropName());
            purchaseProductApply.setSpecData(commonProductDto.getSpecData());
            purchaseProductApply.setProductType(commonProductDto.getProductType());
            purchaseProductApply.setSkuCode(commonProductDto.getSkuCode());
            purchaseProductApply.setProductCode(commonProductDto.getSupplierProductCode());
            purchaseProductApply.setSuggestPrice(commonProductDto.getSuggestPrice());
            purchaseProductApply.setSupplyPrice(commonProductDto.getSupplyPrice());
            purchaseProductApply.setPurchasePrice(commonProductDto.getPurchasePrice());
            purchaseProductApply.setPrice(commonProductDto.getPrice());
            purchaseProductApply.setStock(commonProductDto.getStock());
            purchaseProductApply.setApplySource(commonProductDto.getApplySource());
            purchaseProductApply.setMaterialName(commonProductDto.getMaterialName());
            purchaseProductApply.setDeliveryDate(commonProductDto.getDeliveryDate());
            purchaseProductApply.setUnit(commonProductDto.getUnit());
            purchaseProductApply.setWeight(commonProductDto.getWeight());
            purchaseProductApply.setProductPicName(commonProductDto.getProductPicName());
            purchaseProductApply.setProductVedioName(commonProductDto.getProductVedioName());
            purchaseProductApply.setProductContent(commonProductDto.getProductContent());
            purchaseProductApply.setAuditType(2);
            purchaseProductApply.setAuditStatus(0);
            purchaseProductApply.setIsOnsale("N");
            purchaseProductApply.setSample(commonProductDto.getSample());
            purchaseProductApply.setIsSupply(BooleanUtils.isTrue(isSupply) ? "Y" : "N");
            purchaseProductApply.setApplyNo(commonProductDto.getApplyNo());
            String supplierId = (String) ContextHandler.get("supplierId");
            purchaseProductApply.setSupplierId(BooleanUtils.isTrue(isSupply) ? "" : supplierId);
            if (BooleanUtils.isTrue(isSupply)) {
                purchaseProductApply.setAuditStatus(1);
                purchaseProductApply.setAuditTime(LocalDateTime.now());
                if (StringUtils.isNotBlank(supplierId)) {
                    return new JsonResult(false, "供应商账号不可对供应链数据进行操作");
                }
            } else {
                if (StringUtils.isBlank(supplierId)) {
                    return new JsonResult(false, "供应链账号不可对供应商数据进行操作");
                }
            }
            if (BooleanUtils.isTrue(isEmpty)) {
                purchaseProductApply.setAuditStatus(1);
                purchaseProductApply.setAuditTime(LocalDateTime.now());
            }
            purchaseProductApply.setEditColumns("isOnsale");
            purchaseProductApplyList.add(purchaseProductApply);
        }

        //this.batchInsert(purchaseProductApplyList);
        batchSave(purchaseProductApplyList);
        if (BooleanUtils.isTrue(isSupply) || CollectionUtils.isEmpty(productProperties)) {
            for (PurchaseProductApply apply:purchaseProductApplyList) {
                PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
                purchaseProductSync.setFirstLevelCataName(apply.getFirstLevelCataName());
                purchaseProductSync.setSecondLevelCataName(apply.getSecondLevelCataName());
                purchaseProductSync.setThreeLevelCataName(apply.getThreeLevelCataName());
                purchaseProductSync.setBrandName(apply.getBrandName());
                purchaseProductSync.setPropName(apply.getPropName());
                purchaseProductSync.setProductErpCode(apply.getProductErpCode());
                purchaseProductSync.setProductType(apply.getProductType());
                purchaseProductSync.setProductCode(apply.getProductCode());
                purchaseProductSync.setSkuCode(apply.getSkuCode());
                purchaseProductSync.setStock(apply.getStock());
                purchaseProductSync.setPrice(apply.getPrice());
                purchaseProductSync.setSupplyPrice(apply.getSupplyPrice());
                purchaseProductSync.setSuggestPrice(apply.getSuggestPrice());
                purchaseProductSync.setPurchasePrice(apply.getPurchasePrice());
                purchaseProductSync.setUnit(apply.getUnit());
                purchaseProductSync.setWeight(apply.getWeight());
                purchaseProductSync.setIsOnsale(apply.getIsOnsale());
                purchaseProductSync.setDeliveryDate(apply.getDeliveryDate());
                purchaseProductSync.setAuditTime(apply.getAuditTime());
                purchaseProductSync.setSupplierId(apply.getSupplierId());
                purchaseProductSync.setProductContent(apply.getProductContent());
                purchaseProductSync.setProductVedioName(apply.getProductVedioName());
                purchaseProductSync.setProductPicName(apply.getProductPicName());
                purchaseProductSync.setSpecData(apply.getSpecData());
                purchaseProductSync.setPublicProductId(apply.getPublicProductId());
                purchaseProductSync.setSample(apply.getSample());
                purchaseProductSync.setApplyNo(apply.getApplyNo());
                purchaseProductSync.setId(apply.getId());
                purchaseProductSync.setMaterialName(apply.getMaterialName());
                purchaseProductSync.setApplySource(apply.getApplySource());
                publicProductFeignClient.purchaseProductSync(purchaseProductSync);
            }
        }
        return new JsonResult(true, "");
    }

    public void deleteById(String id) {
        PurchaseProductApply oldData = super.get(id);
        if (null != oldData) {
            if (oldData.getAuditStatus() != 0) {
                throw new BaseException(String.valueOf(ExceptionDictionary.ParamVldExp.getCode()), "商品信息已调整，请刷新页面");
            }
            Example example = new Example(entityClass);
            Example.Criteria criteria = example.createCriteria();
            criteria.andEqualTo(PurchaseProductApply.APPLY_NO, oldData.getApplyNo()).andEqualTo(PurchaseProductApply.AUDIT_STATUS,1);

            List<PurchaseProductApply> purchaseProductApplies = purchaseProductApplyMapper.selectByExample(example);
            if(CollectionUtils.isEmpty(purchaseProductApplies)){
                supplierProductPropertyService.deletedInApplyId(oldData.getApplyNo());
            }
            deleteCataBrandPropData(id, oldData.getFirstLevelCataName(),
                    oldData.getSecondLevelCataName(), oldData.getThreeLevelCataName(), oldData.getBrandName(), oldData.getPropName());
        } else {
            throw new BaseException(String.valueOf(ExceptionDictionary.ParamVldExp.getCode()), "商品信息已调整，请刷新页面");
        }
        super.batchDelete(Collections.singletonList(id));
    }

    /**
     * 预览接口
     * @param id
     * @return
     */
    public DetailResponse previewInfo(String id) {
        PurchaseProductApply details = get(id);
        DetailResponse detailResponse = new DetailResponse();
        if (details != null) {
            DetailResponse.Info info = new DetailResponse.Info();
            info.setBrandName(details.getBrandName());
            info.setPropName(details.getPropName());
            info.setCataName(details.getThreeLevelCataName());
            List<String> cataList = new ArrayList<>(3);
            cataList.add(details.getFirstLevelCataName());
            cataList.add(details.getSecondLevelCataName());
            cataList.add(details.getThreeLevelCataName());
            info.setCataIdList(cataList);
            info.setProductType(details.getProductType());
            info.setSkuCode(details.getSkuCode());
            info.setStock(details.getStock());
            info.setUnit(details.getUnit());
            info.setWeight(details.getWeight());
            info.setProductContent(details.getProductContent());
            info.setPrice(details.getPrice());
            info.setSuggestPrice(details.getSuggestPrice());
            info.setSupplyPrice(details.getSupplyPrice());
            info.setPurchasePrice(details.getPurchasePrice());
            info.setPackageUnit(details.getUnit());
            info.setProductPicName(details.getProductPicName());
            info.setProductVedioName(details.getProductVedioName());
            info.setBrandImgUrl(details.getBrandUrl());
            String specData = details.getSpecData();
            if (StringUtils.isNotEmpty(specData)) {
                JSONArray jsonArray = (JSONArray) JSONArray.parse(specData);
                if (null != jsonArray && !jsonArray.isEmpty()) {
                    List<SpecAndValDTO> specAndValDTOS = new ArrayList<>();
                    for (int i = 0; i < jsonArray.size(); i++) {
                        try {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            String spec = jsonObject.getString("spec");
                            String specVal = jsonObject.getString("specValue");
                            SpecAndValDTO specAndValDTO = new SpecAndValDTO();
                            specAndValDTO.setSpecName(spec);
                            specAndValDTO.setSpecValue(specVal);
                            specAndValDTOS.add(specAndValDTO);
                        } catch (Exception e) {
                            log.error("封装规格数据异常");
                            e.printStackTrace();
                        }
                    }
                    info.setSpecAndVals(specAndValDTOS);
                }
            }
            String productPicName = details.getProductPicName();
            String productVedioName = details.getProductVedioName();
            String sample = details.getSample();
            String[] productPicList = null;
            if (StringUtils.isNotBlank(productPicName)) {
                productPicList = productPicName.split("@");
            }
            String[] productVedioList = null;
            if (StringUtils.isNotBlank(productVedioName)) {
                productVedioList = productVedioName.split("@");
            }
            String[] sampleList = null;
            if (StringUtils.isNotBlank(sample)) {
                sampleList = sample.split("@");
            }
            List<DetailResponse.Image> imageList = new ArrayList<>();
            if (null != productPicList && productPicList.length > 0) {
                for (int i=0;i<productPicList.length;i++) {
                    DetailResponse.Image image = new DetailResponse.Image();
                    image.setImgSrcUrl(productPicList[i]);
                    image.setImgSmallUrl(productPicList[i]);
                    imageList.add(image);
                }
            }
            detailResponse.setImageList(imageList);
            List<DetailResponse.Vedio> vedioList = new ArrayList<>();
            if (null != productVedioList && productVedioList.length > 0) {
                for (int i=0;i<productVedioList.length;i++) {
                    DetailResponse.Vedio vedio = new DetailResponse.Vedio();
                    vedio.setVedioUrl(productVedioList[i]);
                    vedioList.add(vedio);
                }
            }
            detailResponse.setVedioList(vedioList);

            List<DetailResponse.Sample> samples = new ArrayList<>();
            if (null != sampleList && sampleList.length > 0) {
                for (int i=0;i<sampleList.length;i++) {
                    String temp = sampleList[i];
                    if (StringUtils.isNotBlank(temp)) {
                        DetailResponse.Sample sample1 = new DetailResponse.Sample();
                        sample1.setFileUrl(temp);
                        sample1.setFileName(temp);
                        if (temp.contains("/")) {
                            sample1.setFileName(temp.substring(temp.lastIndexOf("/")+1));
                        }
                        if (temp.contains("%2F")) {
                            sample1.setFileName(temp.substring(temp.lastIndexOf("%2F")+3));
                        }
                        samples.add(sample1);
                    }

                }
            }
            detailResponse.setSampleList(samples);
            detailResponse.setInfo(info);
        }
        return detailResponse;
    }

    /**
     * 封装申请数据
     * @param id
     * @return
     */
    public PurchaseProductApplyVo getCommonData(Long id) {
        if (null == id) {
            return new PurchaseProductApplyVo();
        }
//        List<CommonProductDto> commonProductDtos = publicProductFeignClient.listProductByProductIds(Collections.singletonList(id));
        List<PurchaseCommonProductDto> commonProductDtos =  publicProductFeignClient.PurchaseProductListById(Collections.singletonList(id));
        if (CollectionUtils.isNotEmpty(commonProductDtos)) {
            PurchaseCommonProductDto commonProductDto = commonProductDtos.get(0);
//            PurchaseProductApply purchaseProductApply = new PurchaseProductApply();
            PurchaseProductApplyVo purchaseProductApplyVo = new PurchaseProductApplyVo();
            BeanUtil.copyProperties(commonProductDto,purchaseProductApplyVo);
            purchaseProductApplyVo.setApplyId(commonProductDto.getApplyId());
            purchaseProductApplyVo.setProductErpCode(commonProductDto.getErpProductCode());
            purchaseProductApplyVo.setPublicProductId(commonProductDto.getProductId());
            purchaseProductApplyVo.setFirstLevelCataName(commonProductDto.getCataNameOne());
            purchaseProductApplyVo.setSecondLevelCataName(commonProductDto.getCataNameTwo());
            purchaseProductApplyVo.setThreeLevelCataName(commonProductDto.getCataNameThree());
            if(BeanUtil.isNotEmpty(commonProductDto.getProductId())){
                String storeCataId = supplierProductPropertyMapper.selectInProductId(commonProductDto.getProductId());
                if(BeanUtil.isNotEmpty(storeCataId)){
                    purchaseProductApplyVo.setStoreCataId(Integer.valueOf(storeCataId));
                }

            }

//            purchaseProductApply.setBrandName(commonProductDto.getBrandName());
//            purchaseProductApply.setPropName(commonProductDto.getPropName());
//            purchaseProductApply.setSpecData(commonProductDto.getSpecData());
//            purchaseProductApply.setProductType(commonProductDto.getProductType());
//            purchaseProductApply.setSkuCode(commonProductDto.getSkuCode());
//            purchaseProductApply.setProductCode(commonProductDto.getSipplierProductCode());
//            purchaseProductApply.setSuggestPrice(commonProductDto.getSuggestPrice());
//            purchaseProductApply.setSupplyPrice(commonProductDto.getSupplyPrice());
//            purchaseProductApply.setPurchasePrice(commonProductDto.getPurchasePrice());
//            purchaseProductApply.setPrice(commonProductDto.getPrice());
//            purchaseProductApply.setStock(commonProductDto.getStock());
//            purchaseProductApply.setDeliveryDate(commonProductDto.getDeliveryDate());
//            purchaseProductApply.setUnit(commonProductDto.getUnit());
//            purchaseProductApply.setWeight(commonProductDto.getWeight());
//            purchaseProductApply.setProductPicName(commonProductDto.getProductPicName());
//            purchaseProductApply.setProductVedioName(commonProductDto.getProductVedioName());
//            purchaseProductApply.setProductContent(commonProductDto.getProductContent());
//            purchaseProductApply.setIsOnsale(commonProductDto.getIsOnsale());
//            purchaseProductApply.setSample(commonProductDto.getSample());
//            purchaseProductApply.setApplyNo(commonProductDto.getApplyNo());
            dealBigDecimalData(purchaseProductApplyVo);
            if(BeanUtil.isEmpty(purchaseProductApplyVo.getFirstStoreCataName())){
                purchaseProductApplyVo.setFirstStoreCataName("");
            }if(BeanUtil.isEmpty(purchaseProductApplyVo.getSecondStoreCataName())){
                purchaseProductApplyVo.setSecondStoreCataName("");
            }
            return purchaseProductApplyVo;
        }
        return new PurchaseProductApplyVo();
    }

    public List<Map<String,Object>> count(PurchaseProductApply apply) {
        String isSupply  = apply.getIsSupply();
        String supplierId  = (String) ContextHandler.get("supplierId");
        if (StringUtils.isNotBlank(isSupply)) {
            if (!"Y".equals(isSupply)) {
                if (StringUtils.isNotEmpty(supplierId)) {
                    apply.setSupplierId(supplierId);
                }
            }
        }
        List<Map<String,Object>> list = new ArrayList<>(4);
        apply.setAuditStatus(null);
        Map<String,Object> map = new HashMap<>(3);
        map.put("status", "ALL");
        map.put("statusName", "全部");
        map.put("count", purchaseProductApplyMapper.countByStatus(apply));
        list.add(map);
        map = new HashMap<>(3);
        apply.setAuditStatus(4);
        map.put("status", "0");
        map.put("statusName", "待审核");
        map.put("count", purchaseProductApplyMapper.countByStatus(apply));
        list.add(map);
        map = new HashMap<>(3);
        apply.setAuditStatus(2);
        map.put("status", "2");
        map.put("statusName", "已拒绝");
        map.put("count", purchaseProductApplyMapper.countByStatus(apply));
        list.add(map);
        map = new HashMap<>(3);
        apply.setAuditStatus(1);
        map.put("status", "1");
        map.put("statusName", "已通过");
        map.put("count", purchaseProductApplyMapper.countByStatus(apply));
        list.add(map);
        return list;
    }

    public HashMap<String, Long> productQuoteAudit(List<ProductAuditDto> productAuditDto) {
        HashMap<String, Long> hashMap = new HashMap<>();
        for (ProductAuditDto p : productAuditDto) {
            try {
                p.setAuditStatus(1);
                p.setCheckCata(false);
                Long productId = productAudit(p);
                hashMap.put(p.getId(), productId);
            }catch (Exception e){
                log.info("审核忽略异常：" + e.getMessage());
            }
        }
        return hashMap;
    }

    public Long productAudit(ProductAuditDto productAuditDto) {
        PurchaseProductApply apply = super.get(productAuditDto.getId());
        if (apply == null) {
            throw new BaseException(String.valueOf(ExceptionDictionary.ParamVldExp.getCode()), "请求参数异常");
        }
        if (0 != apply.getAuditStatus()) {
            throw new BaseException(String.valueOf(ExceptionDictionary.ParamVldExp.getCode()), "商品信息已调整，请重新申请");
        }
        apply.setAuditStatus(productAuditDto.getAuditStatus());
        apply.setAuditTime(LocalDateTime.now());
        //运维人员修改数据时，忽略为空的状态,传入相关数据
        if (productAuditDto.getProperties() != null){
            if (BeanUtil.isNotEmpty(productAuditDto.getProperties().getBrandName()) && !"暂无数据".equals(productAuditDto.getProperties().getBrandName())) {
                apply.setBrandName(productAuditDto.getProperties().getBrandName());
            }else if("暂无数据".equals(productAuditDto.getProperties().getBrandName())){
                apply.setBrandName("");
            }
            if (BeanUtil.isNotEmpty(productAuditDto.getProperties().getPropName()) && !"暂无数据".equals(productAuditDto.getProperties().getPropName())) {
                apply.setPropName(productAuditDto.getProperties().getPropName());
            }else if("暂无数据".equals(productAuditDto.getProperties().getPropName())){
                apply.setPropName("");
            }
            if (BeanUtil.isNotEmpty(productAuditDto.getProperties().getSpecData()) && !"暂无数据".equals(productAuditDto.getProperties().getSpecData())) {
                apply.setSpecData(productAuditDto.getProperties().getSpecData());
            }else if("暂无数据".equals(productAuditDto.getProperties().getSpecData())){
                apply.setSpecData("");
            }
            if (BeanUtil.isNotEmpty(productAuditDto.getProperties().getFirstLevelCataName()) && !"暂无数据".equals(productAuditDto.getProperties().getFirstLevelCataName())) {
                apply.setFirstLevelCataName(productAuditDto.getProperties().getFirstLevelCataName());
            }else if("暂无数据".equals(productAuditDto.getProperties().getFirstLevelCataName())){
                apply.setFirstLevelCataName("");
            }else if (StringUtils.isEmpty(productAuditDto.getProperties().getFirstLevelCataName())){
                apply.setFirstLevelCataName("");
            }
            if (BeanUtil.isNotEmpty(productAuditDto.getProperties().getSecondLevelCataName()) && !"暂无数据".equals(productAuditDto.getProperties().getSecondLevelCataName())) {
                apply.setSecondLevelCataName(productAuditDto.getProperties().getSecondLevelCataName());
            }else if(!"暂无数据".equals(productAuditDto.getProperties().getSecondLevelCataName())){
                apply.setSecondLevelCataName("");
            }else if (StringUtils.isEmpty(productAuditDto.getProperties().getSecondLevelCataName())){
                apply.setSecondLevelCataName("");
            }
            if (BeanUtil.isNotEmpty(productAuditDto.getProperties().getThreeLevelCataName()) && !"暂无数据".equals(productAuditDto.getProperties().getThreeLevelCataName())) {
                apply.setThreeLevelCataName(productAuditDto.getProperties().getThreeLevelCataName());
            }else if(!"暂无数据".equals(productAuditDto.getProperties().getThreeLevelCataName())){
                apply.setThreeLevelCataName("");
            }else if (StringUtils.isEmpty(productAuditDto.getProperties().getThreeLevelCataName())){
                apply.setThreeLevelCataName("");
            }
        }
        JsonResult<Long> jsonResult = new JsonResult<>();
        if (productAuditDto.getAuditStatus() == 1) {
//            apply.setProductErpCode(productAuditDto.getData());
            PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
            BeanUtil.copyProperties(apply, purchaseProductSync);
            if (BeanUtil.isNotEmpty(apply.getProductCode())) {
                purchaseProductSync.setProductErpCode(apply.getProductCode());
            }
            if (productAuditDto.isCheckCata()){
                JsonResult checkResult = publicProductFeignClient.checkCataAndCode(purchaseProductSync);
                if (null != checkResult && BooleanUtils.isNotTrue(checkResult.isSuccess())) {
                    throw new BaseException("-100", checkResult.getMsg());
                }
            }
            //商品的店铺信息
            PurchaseStore purchaseStore = purchaseProductApplyMapper.selectBySupplier(apply.getSupplierId());
            if (purchaseStore != null){
                purchaseProductSync.setStoreId(purchaseStore.getId());
                purchaseProductSync.setStoreName(purchaseStore.getStoreName());
                purchaseProductSync.setStoreType(purchaseStore.getStoreType());
                purchaseProductSync.setStoreDesc(purchaseStore.getRemark());
            }
            jsonResult = publicProductFeignClient.purchaseProductSync(purchaseProductSync);
            if (null != jsonResult && BooleanUtils.isTrue(jsonResult.isSuccess())) {
                //同步purchase 的es接口
                esFeignClient.updateByIds(Arrays.asList(String.valueOf(jsonResult.getData())));
                apply.setPublicProductId(jsonResult.getData());
            }
            if (BeanUtil.isNotEmpty(apply.getStoreCataId())) {
                SupplierProductProperty supplierProductProperty = supplierProductPropertyMapper.selectInapplyNo(apply.getApplyNo());
                if(null != supplierProductProperty){
                    supplierProductPropertyMapper.updateApplyNo(apply,LocalDateTime.now());
                }else  {
                    supplierProductPropertyMapper.insertProductProperty(apply,LocalDateTime.now());
                }
                supplierProductPropertyMapper.updatePublicProductId(apply, LocalDateTime.now());
            }
        } else if (productAuditDto.getAuditStatus() == 2) {
            if (BeanUtil.isNotEmpty(apply.getStoreCataId())) {
                SupplierProductProperty supplierProductProperty = supplierProductPropertyMapper.selectInapplyNo(apply.getApplyNo());
                if(null != supplierProductProperty){
                    supplierProductPropertyMapper.updateApplyNo(apply,LocalDateTime.now());
                }else  {
                    supplierProductPropertyMapper.insertProductProperty(apply,LocalDateTime.now());
                }
                supplierProductPropertyMapper.updatePublicProductId(apply, LocalDateTime.now());
            }
            apply.setAuditRemark(productAuditDto.getData());
        }
        purchaseProductApplyMapper.updateByPrimaryKeySelective(apply);
        return jsonResult.getData();
    }
}
