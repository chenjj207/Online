package com.purchase.product.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Table;

/**
 * @Description: 供应商_SCM_税务分类关系表
 * @Author: loine
 * @Date: 2026/3/10 15:09
 **/
@Data
@ApiModel("供应商_SCM_税务分类关系表")
@Table(name = "t_pd_purchase_scm_tax_cata_relate")
public class PurchaseScmTaxCataRelate extends BaseCorpModel {

    public static final String ID = "id";
    public static final String CODE = "code";
    public static final String NAME = "name";

    @ApiModelProperty("编码")
    private String code;
    @ApiModelProperty("名称（大类）")
    private String nameBig;
    @ApiModelProperty("名称（小类）")
    private String nameSmall;
    @ApiModelProperty("备注")
    private String remark;
}
