package com.purchase.product.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @ClassName: MaterialConf
 * @Description:素材管理配置文件
 * @author zhangcheng
 * @Date: 2022-08-10
 **/
@Component
@ConfigurationProperties(prefix = "material")
@Data
public class MaterialConf {
    private String uploadtmp;
}
