package com.purchase.product.dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * <p>
 * 任务管理
 * </p>
 *
 * @author jidonglin
 * @since 2024-12-24
 */
@Data
@ApiModel("任务管理")
public class TaskManageDto {
    @ApiModelProperty(value = "任务id")
    private Integer id;
    @ApiModelProperty(value = "类型，指按钮操作（审核通过、审核驳回、设置调货价、批量发布商品）")
    private String type;
    @ApiModelProperty(value = "模块：页面菜单名称，如商品管理")
    private String module;
    @ApiModelProperty(value = "服务名称：例如purchase-product")
    private String service;
    @ApiModelProperty(value = "状态：0：未执行 1：执行中 2：执行成功 3：执行失败")
    private String status;
    @ApiModelProperty(value = "请求参数，用于保存用户当前执行的参数")
    private String requestParam;
    @ApiModelProperty(value = "执行结果类型：1: url  2：text")
    private String resultType;
    @ApiModelProperty(value = "执行结果内容")
    private String resultContent;
    @ApiModelProperty(value = "下载次数")
    private Integer downloadNum;
    @ApiModelProperty(value = "备注")
    private String remark;
    @ApiModelProperty(value = "创建者")
    private String createdBy;
    @ApiModelProperty(value = "更新者")
    private String updatedBy;
}
