package com.purchase.product.controller;

import com.purchase.exception.ZydExceptions;
import com.purchase.model.dto.DetailResponse;
import com.purchase.product.dto.BusinessProductListDto;
import com.purchase.product.dto.BusinessRecommendProductListDto;
import com.purchase.product.dto.ProductAuditDto;
import com.purchase.product.dto.ProductCodeDto;
import com.purchase.product.model.ProductProperties;
import com.purchase.product.model.PurchaseProductApply;
import com.purchase.product.model.PurchaseRecommendProduct;
import com.purchase.product.service.BusinessProductService;
import com.purchase.product.service.PurchaseProductApplyService;
import com.purchase.product.vo.BusinessProductListVo;
import com.purchase.product.vo.PurchaseProductApplyVo;
import com.purchase.utils.excel.export.ZydExportExcel;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 慧采产品申请服务提供类
 *
 * @author zhangcheng
 * @version 1.0
 * @since 2022-08-16
 */
@RestController
@RequestMapping(value = "/purchaseProductApply")
@Api(value = "PurchaseProductApplyController", tags = {"慧采产品申请服务提供类"})
@Slf4j
public class PurchaseProductApplyController {

    @Resource
    private PurchaseProductApplyService purchaseProductApplyService;

    @Resource
    private BusinessProductService businessProductService;

    @GetMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    public JsonResult<Page<PurchaseProductApply>> search(@ParamHide PurchaseProductApply purchaseProductApply) {
        Page<PurchaseProductApply> page = purchaseProductApplyService.search(purchaseProductApply);
        return new JsonResult<>(true, "查询成功", page);
    }

    @GetMapping(value = "/listAll")
    @ApiOperation(value = "获取所有数据")
    public JsonResult<List<PurchaseProductApply>> listAll() {
        return new JsonResult<>(true, "查询成功", purchaseProductApplyService.listAll());
    }

    @GetMapping(value = "/{id}")
    @ApiOperation(value = "根据id获取数据")
    public JsonResult<PurchaseProductApply> getPurchaseProductApply(@PathVariable(value = "id") String id) {
        PurchaseProductApply purchaseProductApply = purchaseProductApplyService.get(id);
        return new JsonResult<>(true, "查询成功", purchaseProductApply);
    }

    @GetMapping(value = "/common/packApplyData")
    @ApiOperation(value = "根据公海id获取数据")
    public JsonResult<PurchaseProductApplyVo> getDataByCommonId(Long id) {
        PurchaseProductApplyVo purchaseProductApply = purchaseProductApplyService.getCommonData(id);
        return new JsonResult<>(true, "查询成功", purchaseProductApply);
    }

    //===========================================================================================

    @GetMapping(value = "/check/product/code/{productCode}")
    @ApiOperation(value = "校验商品编码：true-为可用，false-为不可用")
    public JsonResult<Boolean> checkProductCode(@PathVariable(value = "productCode") String productCode, String id) {
        return new JsonResult<>(true, "商品编码校验", purchaseProductApplyService.checkProductCode(productCode, id));
    }

    @PostMapping("/quote/product/publish")
    @ApiOperation(value = "供应商报价, 服务间调用，给供应商报价 purchase-order 调用")
    public HashMap<String, String> multiQuote(@RequestBody List<PurchaseProductApply> applyVOS) {
        return purchaseProductApplyService.multiQuote(applyVOS);
    }

    @PostMapping("/single/publish")
    @ApiOperation(value = "单商品发布")
    public JsonResult<String> singlePublish(@RequestBody PurchaseProductApply applyVO) {
        String id = purchaseProductApplyService.singlePublishProduct(applyVO);
        return new JsonResult<>(true, "发布成功", id);
    }

    @PutMapping(value = "/single/edit")
    @ApiOperation(value = "商品编辑")
    public JsonResult editPurchaseProductApply(@RequestBody @Check(field = {"id"}) PurchaseProductApply applyVO) {
        purchaseProductApplyService.edit(applyVO);
        return new JsonResult(true, "编辑成功");
    }

    @PostMapping(value = "/delete")
    @ApiOperation(value = "根据传入的Id，标记删除数据")
    public JsonResult<String> delete(@RequestBody @Check(field = {"id"}) PurchaseProductApply applyVO) {
        purchaseProductApplyService.deleteById(applyVO.getId());
        return new JsonResult<>(true, "删除成功");
    }

    //===========================================================================================

    @GetMapping(value = "/details/{id}")
    @ApiOperation(value = "详情")
    public JsonResult<PurchaseProductApply> details(@PathVariable(value = "id") @ApiParam("自增id") String id) {
        return new JsonResult<>(true, "查询成功", purchaseProductApplyService.details(id));
    }

    @GetMapping(value = "/audit/{id}/{auditStatus}")
    @ApiOperation(value = "商品审核")
    public JsonResult audit(@PathVariable(value = "id") String id, @PathVariable(value = "auditStatus") Integer auditStatus, String data) {
        return new JsonResult<>(true, "审核成功", purchaseProductApplyService.audit(id, auditStatus, data));
    }

    @PostMapping(value = "/audit/product")
    @ApiOperation(value = "后台商品审核")
    public JsonResult productEdit(@RequestBody ProductAuditDto productAuditDto ) {
        return new JsonResult<>(true, "审核成功", purchaseProductApplyService.productAudit(productAuditDto));
    }

    @PostMapping(value = "/batch/audit/product")
    @ApiOperation(value = "后台商品审核")
    public JsonResult batchProductEdit(@RequestBody List<String> ids) {
        for (String id : ids) {
            ProductAuditDto productAuditDto = new ProductAuditDto();
            productAuditDto.setAuditStatus(1);
            productAuditDto.setId(id);
            purchaseProductApplyService.productAudit(productAuditDto);
        }
        return new JsonResult<>(true, "审核成功");
    }

    @PostMapping(value = "/audit/quote/product")
    @ApiOperation(value = "运营端提交报价, 服务间调用 purchase-order 调用")
    public HashMap<String, Long> productQuoteAudit(@RequestBody List<ProductAuditDto> productAuditDtos) {
        return purchaseProductApplyService.productQuoteAudit(productAuditDtos);
    }

    @PostMapping(value = "/upSale")
    @ApiOperation(value = "批量上架")
    public JsonResult upSale(@RequestBody ProductCodeDto dto){
        return purchaseProductApplyService.upSale(dto.getList(), "Y".equals(dto.getIsSupply()));
    }

    @PostMapping(value = "/downSale")
    @ApiOperation(value = "批量下架")
    public JsonResult downSale(@RequestBody ProductCodeDto dto){
        return purchaseProductApplyService.downSale(dto.getList(), "Y".equals(dto.getIsSupply()));
    }

    @PostMapping("/list/excel")
    @ApiOperation("商品列表excel导出")
    public void download(@RequestBody PurchaseProductApply dto){
        dto.setPageNum(0);
        dto.setPageSize(0);
        List<PurchaseProductApply> list = purchaseProductApplyService.list(dto);
        try {
            new ZydExportExcel("", PurchaseProductApply.class)
                    .setDataListColSize(list)
                    .write(getRequest(), getResponse(),
                            "商品列表-" + LocalDateTime.now().format(
                                    DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))+".xlsx");
        }catch (Exception e){
            log.error("商品列表excel导出异常：{}",e);
            ZydExceptions.re(true,"商品列表导出失败");
        }
    }


    /***
     * 获得请求对象
     * @return
     */
    public HttpServletRequest getRequest() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
    }

    /***
     * 获得response对象
     *
     * @return
     */
    public HttpServletResponse getResponse() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
    }


    @GetMapping(value = "/getApplyTemp")
    @ApiOperation(value = "获取批量发布模板")
    public JsonResult<String> getApplyTemp(){
        return purchaseProductApplyService.getApplyTemp();
    }


    @PostMapping(value = "/batch/applyImport/{isSupply}")
    @ApiOperation(value = "商品导入")
    public JsonResult<String> importProduct(@RequestParam(value = "file", required = false) MultipartFile multipartFile, @PathVariable(value = "isSupply") String isSupply) {
        return purchaseProductApplyService.importProduct(multipartFile, isSupply);
    }


    @GetMapping(value = "/getStockTemp")
    @ApiOperation(value = "获取批量上传库存模板")
    public JsonResult<String> getStockTemp(){
        return purchaseProductApplyService.getStockTemp();
    }


    @PostMapping(value = "/batch/stockImport/{isSupply}")
    @ApiOperation(value = "商品库存导入")
    public JsonResult<String> stockImport(@RequestParam(value = "file", required = false) MultipartFile multipartFile, @PathVariable(value = "isSupply") String isSupply) {
        return purchaseProductApplyService.stockImport(multipartFile, isSupply);
    }

    @GetMapping(value = "/previewInfo/{id}")
    @ApiOperation(value = "详情")
    public JsonResult<DetailResponse> previewInfo(@PathVariable(value = "id") @ApiParam("自增id") String id) {
        return new JsonResult<>(true, "查询成功", purchaseProductApplyService.previewInfo(id));
    }

    /**
     * 交表数据
     */
    @GetMapping(value = "/public/count")
    public JsonResult<List<Map<String,Object>>> count(@ParamHide PurchaseProductApply purchaseProductApply) {
        return new JsonResult<>(true, null, purchaseProductApplyService.count(purchaseProductApply));
    }


    /**
     * 商家后台相关接口
     */
    @PostMapping(value = "/business/product/list")
    @ApiOperation(value = "商家后台商家产品列表")
    public JsonResult<Page<BusinessProductListVo>> businessProductList(@Valid @RequestBody BusinessProductListDto businessProductListDto) {
        return new JsonResult<>(true, null, businessProductService.search(businessProductListDto));
    }

    @PostMapping(value = "/business/product/count")
    @ApiOperation(value = "商家后台商家产品状态计数")
    public JsonResult<Map<Integer,Integer>> businessProductCount(@RequestBody BusinessProductListDto businessProductListDto) {
        return new JsonResult<>(true, null, businessProductService.count(businessProductListDto));
    }

    @PostMapping(value = "/business/product/lead")
    @ApiOperation(value = "商家后台商家产品信息导出")
    public JsonResult<String> businessProductLead(@RequestBody BusinessProductListDto businessProductListDto) throws IOException, InvalidFormatException {
        return new JsonResult<>(true, null, businessProductService.lead(businessProductListDto));
    }

    @PostMapping(value = "/business/applyImport/update")
    @ApiOperation(value = "商家后台商品批量导入修改")
    public JsonResult<String> businessImportProductUpdate(@RequestParam(value = "file", required = false) MultipartFile multipartFile) throws IOException {
        return businessProductService.importProductUpdate(multipartFile);
    }

    @PostMapping(value = "/business/applyImport/inter")
    @ApiOperation(value = "商家后台商品批量导入插入")
    public JsonResult<String> businessImportProductInter(@RequestParam(value = "file", required = false) MultipartFile multipartFile) throws IOException {
        return businessProductService.importProductInter(multipartFile);
    }
}
