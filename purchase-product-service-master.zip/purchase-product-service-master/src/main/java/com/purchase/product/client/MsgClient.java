package com.purchase.product.client;

import com.aliyuncs.CommonResponse;
import com.purchase.product.client.dto.TriggerMsgRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


/**
 * 发消息-对外服务接口
 */
@FeignClient(value = "purchase-msg")
public interface MsgClient {

    /**
     * 业务消息发送
     * @return
     */
    @PostMapping("/trigger/business/msg")
    CommonResponse triggerMsg(@RequestBody TriggerMsgRequest request);
}
