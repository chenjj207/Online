package com.purchase.product.service;

import com.purchase.product.mapper.SupplierProductPropertyMapper;
import com.purchase.product.model.SupplierProductProperty;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;

@Service
@Slf4j
public class SupplierProductPropertyService extends BaseServiceImpl<SupplierProductProperty> {

    @Resource
    SupplierProductPropertyMapper supplierProductPropertyMapper;

    public void deletedInApplyId (Long applyId){
        Example example = new Example(SupplierProductProperty.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(SupplierProductProperty.APPLY_ID, applyId);
        supplierProductPropertyMapper.deleteByExample(example);

    }}
