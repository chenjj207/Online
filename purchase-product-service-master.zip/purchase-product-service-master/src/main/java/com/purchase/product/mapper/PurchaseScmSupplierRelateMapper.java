package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseScmSupplierRelate;
import com.purchase.product.vo.PurchaseScmErpProductCodeApplyVo;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

import java.util.List;

/**
 * @Description:
 * @Author: loine
 * @Date: 2026/3/10 15:13
 */
public interface PurchaseScmSupplierRelateMapper extends QguBaseMapper<PurchaseScmSupplierRelate> {

    /**
     * 查询列表
     *
     * @Author loine
     * @Date 2026/3/11 13:54
     */
    List<PurchaseScmErpProductCodeApplyVo.ErpSupplierRelateVo> selectRelateList();
}
