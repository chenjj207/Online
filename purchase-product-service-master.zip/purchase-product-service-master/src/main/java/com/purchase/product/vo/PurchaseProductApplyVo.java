package com.purchase.product.vo;

import com.purchase.product.model.PurchaseProductApply;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class PurchaseProductApplyVo extends PurchaseProductApply {


    /**
     * 一级店铺产品分类名
     */
    @ApiModelProperty(value = "一级店铺产品分类名")
    private String firstStoreCataName;

    /**
     * 二级店铺产品分类名
     */
    @ApiModelProperty(value = "二级店铺产品分类名")
    private String secondStoreCataName;

    /**
     * 申请表id
     */
    @ApiModelProperty(value = "申请表id")
    private String applyId;
}
