package com.purchase.product.util;

import com.google.common.collect.Lists;
import com.purchase.utils.entity.ZydEntityUtil;
import com.purchase.utils.excel.export.ExcelField;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTSheetProtection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @Description: 多标题导出Excel文件（导出“XLSX”格式，支持大数据量导出）
 * @Author: loine
 * @Date: 2024/10/16 11:17
 **/
public class MultiTitleExportExcelUtil {
    private static final Logger log = LoggerFactory.getLogger(MultiTitleExportExcelUtil.class);

    /**
     * 工作薄对象
     */
    private final XSSFWorkbook wb = new XSSFWorkbook();

    /**
     * 工作表对象
     */
    private XSSFSheet sheet;

    /**
     * 样式列表
     */
    private Map<String, CellStyle> styles;

    /**
     * 当前行号
     */
    private int rownum;

    /**
     * 注解列表（Object[]{ ExcelField, Field/Method }）
     */
    private List<Object[]> annotationList = Lists.newArrayList();

    // 样式
    public static final String STYLE_TITLE1 = "title1";
    public static final String STYLE_TITLE2 = "title2";
    public static final String STYLE_TITLE3 = "title3";
    public static final String STYLE_TITLE4 = "title4";
    public static final String STYLE_TITLE3RED = "title3red";
    public static final String STYLE_DATA = "data";
    public static final String STYLE_DATA1 = "data1";
    public static final String STYLE_DATA2 = "data2";
    public static final String STYLE_DATA3 = "data3";
    public static final String STYLE_DATA_LOCK = "dataLock";
    public static final String STYLE_DATA_LOCK1 = "dataLock1";
    public static final String STYLE_DATA_LOCK2 = "dataLock2";
    public static final String STYLE_DATA_LOCK3 = "dataLock3";
    // 列加锁的索引
    private List<Integer> columLockIndex = Lists.newArrayList();
    // 最大列宽
    private final List<Integer> maxColumnWidth = new LinkedList<>();

    /**
     * 构造函数（多标题行，支持合并表格）
     *
     * @param sheetName 表格名称
     * @param titleList 表头列表
     */
    public MultiTitleExportExcelUtil(String sheetName, List<List<Title>> titleList) {
        initialize(sheetName, titleList);
    }

    /**
     * 构造函数（单标题行，通过annotation.ExportField，不支持合并表格）
     *
     * @param sheetName 表格名称
     * @param height    列高
     * @param style     样式
     * @param cls       对象
     */
    public MultiTitleExportExcelUtil(String sheetName, int height, String style, Class<?> cls) {
        initialize(sheetName, height, style, cls);
    }

    /**
     * 初始化函数（多标题行，支持合并表格）
     *
     * @param sheetName 表格名称
     * @param titleList 表头列表，传“空值”，表示无标题
     */
    private void initialize(String sheetName, List<List<Title>> titleList) {
        sheet = wb.createSheet(sheetName);
        sheet.setDefaultColumnWidth(15);
        styles = createStyles(wb);
        if (titleList == null || titleList.size() == 0) {
            return;
        }
        int maxColNum = 0;
        for (List<Title> titles : titleList) {
            Row row = sheet.createRow(rownum++);
            row.setHeightInPoints(titles.get(0).getHeight());
            int col = 0;
            for (Title title : titles) {
                // 合并表格
                if (title.getColNum() > 1) {
                    sheet.addMergedRegion(new CellRangeAddress(row.getRowNum(), row.getRowNum(), col, col + title.getColNum() - 1));
                }
                col += title.getColNum();
            }
            if (maxColNum < titles.size()) {
                maxColNum = titles.size();
            }
        }
        for (int i = 0; i < titleList.size(); i++) {
            List<Title> titles = titleList.get(i);
            Row row = sheet.getRow(i);
            // 合并表格设置样式的时候，需要全表格都设置，因此不够时，补充空数据
            List<Integer> addColNums = new ArrayList<>();
            for (Title title : titles) {
                addColNums.add(title.getColNum() - 1);
            }
            int index = 1;
            for (int addColNum : addColNums) {
                if (addColNum > 0) {
                    for (int k = 0; k < addColNum; k++) {
                        titles.add(index, new Title("", 1, 1, titles.get(0).getStyle()));
                        index++;
                    }
                }
                index++;
            }
            List<Integer> columnWithList = new LinkedList<>();
            for (int j = 0; j < maxColNum; j++) {
                Title title = titles.get(j);
                Cell cell = row.createCell(j);
                cell.setCellStyle(styles.get(title.getStyle()));
                cell.setCellValue(title.getName());
                // 判断列长度
                int length = title.getName().getBytes().length;
                columnWithList.add(length);
            }
            // 设置列宽
            if (i == titleList.size() - 1) {
                for (int j = 0; j < columnWithList.size(); j++) {
                    int colWidth = columnWithList.get(j) * 256 + 1000;
                    int maxWidth = Math.max(colWidth, 3000);
                    maxColumnWidth.add(maxWidth);
                    sheet.setColumnWidth(j, maxWidth);
                }
            }
        }
    }

    /**
     * 初始化函数（单标题行，通过annotation.ExportField，不支持合并表格）
     *
     * @param sheetName 表格名称
     * @param height    列高
     * @param style     样式
     * @param cls       对象
     */
    private void initialize(String sheetName, int height, String style, Class<?> cls) {
        annotationList = new ArrayList<>();
        Field[] fs = cls.getDeclaredFields();
        for (Field f : fs) {
            ExcelField ef = f.getAnnotation(ExcelField.class);
            if (ef != null) {
                annotationList.add(new Object[]{ef, f});
            }
        }
        // Get annotation method
        Method[] ms = cls.getDeclaredMethods();
        for (Method m : ms) {
            ExcelField ef = m.getAnnotation(ExcelField.class);
            if (ef != null) {
                annotationList.add(new Object[]{ef, m});
            }
        }
        // 按sort排序
        annotationList.sort(Comparator.comparing(o -> ((ExcelField) o[0]).sort()));
        // 处理标题
        List<List<Title>> titleList = Lists.newArrayList();
        List<Title> titleList1 = new ArrayList<>();
        for (Object[] os : annotationList) {
            String t = ((ExcelField) os[0]).title();
            titleList1.add(new Title(t, 1, height, style));
        }
        titleList.add(titleList1);
        initialize(sheetName, titleList);
    }

    /**
     * 创建表格样式
     *
     * @param wb 工作薄对象
     * @return 样式列表
     */
    private Map<String, CellStyle> createStyles(Workbook wb) {
        Map<String, CellStyle> styles = new HashMap<>();

        CellStyle style = wb.createCellStyle();
        style.setLocked(true);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderRight(BorderStyle.THIN);
        style.setRightBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderLeft(BorderStyle.THIN);
        style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderTop(BorderStyle.THIN);
        style.setTopBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderBottom(BorderStyle.THIN);
        style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        styles.put("base", style);
        Font title1Font = wb.createFont();
        title1Font.setFontName("微软雅黑");
        title1Font.setFontHeightInPoints((short) 14);
        title1Font.setBold(true);
        title1Font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(title1Font);
        styles.put(STYLE_TITLE1, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get("base"));
        Font title2Font = wb.createFont();
        title2Font.setFontName("微软雅黑");
        title2Font.setFontHeightInPoints((short) 13);
        title2Font.setBold(true);
        title2Font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(title2Font);
        styles.put(STYLE_TITLE2, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get("base"));
        style.setWrapText(true);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        Font title3Font = wb.createFont();
        title3Font.setFontName("微软雅黑");
        title3Font.setFontHeightInPoints((short) 12);
        title3Font.setBold(false);
        title3Font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(title3Font);
        styles.put(STYLE_TITLE3, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get("base"));
        style.setWrapText(true);
        style.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        Font title4Font = wb.createFont();
        title4Font.setFontName("微软雅黑");
        title4Font.setFontHeightInPoints((short) 12);
        title4Font.setBold(true);
        title4Font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(title4Font);
        styles.put(STYLE_TITLE4, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get("base"));
        style.setWrapText(true);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        Font title3RedFont = wb.createFont();
        title3RedFont.setFontName("微软雅黑");
        title3RedFont.setFontHeightInPoints((short) 12);
        title3RedFont.setBold(true);
        title3RedFont.setColor(IndexedColors.RED.getIndex());
        style.setFont(title3RedFont);
        styles.put(STYLE_TITLE3RED, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get("base"));
        style.setLocked(false);
        style.setWrapText(true);
        Font dataFont = wb.createFont();
        dataFont.setFontName("微软雅黑");
        dataFont.setFontHeightInPoints((short) 10);
        style.setFont(dataFont);
        styles.put(STYLE_DATA, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get(STYLE_DATA));
        style.setAlignment(HorizontalAlignment.LEFT);
        styles.put(STYLE_DATA1, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get(STYLE_DATA));
        style.setAlignment(HorizontalAlignment.CENTER);
        styles.put(STYLE_DATA2, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get(STYLE_DATA));
        style.setAlignment(HorizontalAlignment.RIGHT);
        styles.put(STYLE_DATA3, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get(STYLE_DATA));
        style.setLocked(true);
        styles.put(STYLE_DATA_LOCK, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get(STYLE_DATA));
        style.setLocked(true);
        style.setAlignment(HorizontalAlignment.LEFT);
        styles.put(STYLE_DATA_LOCK1, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get(STYLE_DATA));
        style.setLocked(true);
        style.setAlignment(HorizontalAlignment.CENTER);
        styles.put(STYLE_DATA_LOCK2, style);

        style = wb.createCellStyle();
        style.cloneStyleFrom(styles.get(STYLE_DATA));
        style.setLocked(true);
        style.setAlignment(HorizontalAlignment.RIGHT);
        styles.put(STYLE_DATA_LOCK3, style);
        return styles;
    }

    /**
     * 添加一行
     *
     * @return 行对象
     */
    private Row addRow() {
        return sheet.createRow(rownum++);
    }

    /**
     * 添加一个单元格
     *
     * @param row    添加的行
     * @param column 添加列号
     * @param val    添加值
     * @return 单元格对象
     */
    private Cell addCell(Row row, int column, Object val) {
        return this.addCell(row, column, val, 0, Class.class);
    }

    /**
     * 添加一个单元格
     *
     * @param row    添加的行
     * @param columnIndex 添加列号
     * @param val    添加值
     * @param align  对齐方式（1：靠左；2：居中；3：靠右）
     * @return 单元格对象
     */
    private Cell addCell(Row row, int columnIndex, Object val, int align, Class<?> fieldType) {
        Cell cell = row.createCell(columnIndex);
        String cellFormatString = "@";
        // 设置样式
        String styleKey = "data";
        if (columLockIndex.size() > 0) {
            if (columLockIndex.contains(columnIndex)) {
                styleKey = "dataLock";
            }
        }
        CellStyle style = styles.get(styleKey + (align >= 1 && align <= 3 ? align : ""));
        try {
            if (val == null) {
                cell.setCellValue("");
            } else if (fieldType != Class.class) {
                cell.setCellValue((String) fieldType.getMethod("setValue", Object.class).invoke(null, val));
            } else {
                if (val instanceof String) {
                    cell.setCellValue((String) val);
                } else if (val instanceof Integer) {
                    cell.setCellValue((Integer) val);
                    cellFormatString = "0";
                } else if (val instanceof Long) {
                    cell.setCellValue(val + "");
                } else if (val instanceof Double) {
                    cell.setCellValue((Double) val);
                    cellFormatString = "0.00";
                } else if (val instanceof Float) {
                    cell.setCellValue((Float) val);
                    cellFormatString = "0.00";
                } else if (val instanceof BigDecimal) {
                    cell.setCellValue(new BigDecimal(val + "").doubleValue());
                    cellFormatString = "0.00";
                } else if (val instanceof Date) {
                    CreationHelper creationHelper = wb.getCreationHelper();
                    style.setDataFormat(creationHelper.createDataFormat().getFormat("yyyy-MM-dd HH:mm:ss"));
                    cell.setCellValue((Date) val);
                } else if (val instanceof LocalDateTime) {
                    CreationHelper creationHelper = wb.getCreationHelper();
                    style.setDataFormat(creationHelper.createDataFormat().getFormat("yyyy-MM-dd HH:mm:ss"));
                    cell.setCellValue(Date.from(((LocalDateTime) val).atZone(ZoneId.systemDefault()).toInstant()));
                } else {
                    cell.setCellValue((String) Class.forName(this.getClass().getName().replaceAll(this.getClass().getSimpleName(), "fieldtype." + val.getClass().getSimpleName() + "Type")).getMethod("setValue", Object.class).invoke(null, val));
                }
            }
            // 日期格式，不做处理
            if (val != null && !(val instanceof Date) && !(val instanceof LocalDateTime)) {
                style.setDataFormat(wb.createDataFormat().getFormat(cellFormatString));
            }
        } catch (Exception ex) {
            log.info("设置列值 [" + row.getRowNum() + "," + columnIndex + "] 错误: " + ex);
            if (val != null) {
                cell.setCellValue(val.toString());
            }
        }
        cell.setCellStyle(style);
        return cell;
    }

    /**
     * 输出数据流
     *
     * @param os 输出数据流
     */
    public void write(OutputStream os) throws IOException {
        wb.write(os);
    }

    /**
     * 添加数据（通过annotation.ExportField添加数据）
     *
     * @param list 数据列表
     * @return list 数据列表
     */
    public <E> MultiTitleExportExcelUtil setDataList(List<E> list) {
        return setDataList(list, false);
    }

    /**
     * 设置数据（通过annotation.ExportField添加数据，列宽自适应，兼容中文）
     *
     * @param list 数据列表
     * @return list 数据列表
     */
    public <E> MultiTitleExportExcelUtil setDataListColWidth(List<E> list) {
        return setDataList(list, true);
    }

    /**
     * 设置数据（通过annotation.ExportField添加数据）
     *
     * @param list       数据列表
     * @param isColWidth 是否列宽自适应
     * @return list 数据列表
     */
    private <E> MultiTitleExportExcelUtil setDataList(List<E> list, boolean isColWidth) {
        CopyOnWriteArrayList<Integer> columnWithList = new CopyOnWriteArrayList<>();
        for (int i = 0; i < annotationList.size(); i++) {
            columnWithList.add(1);
        }
        for (E e : list) {
            int column = 0;
            Row row = this.addRow();
            for (Object[] os : annotationList) {
                ExcelField ef = (ExcelField) os[0];
                Object val = null;
                // 根据注解获取列值
                try {
                    if (StringUtils.isNotBlank(ef.value())) {
                        val = ZydEntityUtil.invokesByFields(e, ef.value());
                    } else {
                        if (os[1] instanceof Field) {
                            val = ZydEntityUtil.invokesByFields(e, ((Field) os[1]).getName());
                        } else if (os[1] instanceof Method) {
                            val = ((Method) os[1]).invoke(e);
                        }
                    }
                } catch (Exception ex) {
                    log.error("ZydExportExcel导出excel异常：{}", ex.getMessage(), ex);
                    val = "";
                }

                val = val == null ? "" : val;
                // 判断列长度
                int length = val.toString().getBytes().length;
                if (columnWithList.get(column) < length) {
                    columnWithList.set(column, length);
                }

                this.addCell(row, column++, val, ef.align(), ef.fieldType());
            }
            if (row.getRowNum() % 1000 == 0) {
                log.info("写入{}行", row.getRowNum());
            }
        }
        if (isColWidth) {
            for (int i = 0; i < maxColumnWidth.size(); i++) {
                int colWidth = columnWithList.get(i) * 256 + 1000;
                if (colWidth > maxColumnWidth.get(i)) {
                    if (colWidth < 255 * 256) {
                        sheet.setColumnWidth(i, Math.max(colWidth, 3000));
                    } else {
                        sheet.setColumnWidth(i, 6000);
                    }
                }
            }
        }
        return this;
    }

    /**
     * 设置数据（通过Object数组添加数据，列宽自适应，兼容中文）
     *
     * @param list 数据列表
     * @return list 数据列表
     */
    public <E> MultiTitleExportExcelUtil setDataListObject(List<List<Object>> list) {
        if (list.size() > 0) {
            CopyOnWriteArrayList<Integer> columnWithList = new CopyOnWriteArrayList<>();
            for (int i = 0; i < list.get(0).size(); i++) {
                columnWithList.add(1);
            }
            for (List<Object> dataRow : list) {
                int column = 0;
                Row row = this.addRow();
                for (Object val : dataRow) {
                    val = val == null ? "" : val;

                    // 判断列长度
                    int length = val.toString().getBytes().length;
                    if (columnWithList.get(column) < length) {
                        columnWithList.set(column, length);
                    }

                    this.addCell(row, column++, val, 0, Class.class);
                }
                if (row.getRowNum() % 1000 == 0) {
                    log.info("写入{}行", row.getRowNum());
                }
            }
            for (int i = 0; i < maxColumnWidth.size(); i++) {
                int colWidth = columnWithList.get(i) * 256 + 1000;
                if (colWidth > maxColumnWidth.get(i)) {
                    if (colWidth < 255 * 256) {
                        sheet.setColumnWidth(i, Math.max(colWidth, 3000));
                    } else {
                        sheet.setColumnWidth(i, 6000);
                    }
                }
            }
        }
        return this;
    }

    /**
     * 设置数据列加锁
     * @param password
     * @param columLockIndex
     * @Author: loine
     * @Date: 2024/10/21 10:17
     */
    public <E> MultiTitleExportExcelUtil setDataColumLock(String password, List<Integer> columLockIndex) {
        if (columLockIndex.size() > 0) {
            // 工作表加锁
            sheet.protectSheet(password);
            // 设置允许操作行为（false为允许）
            CTSheetProtection sheetProtection = sheet.getCTWorksheet().getSheetProtection();
            sheetProtection.setSheet(true);
            sheetProtection.setObjects(true);
            sheetProtection.setScenarios(true);
            sheetProtection.setFormatCells(true);
            sheetProtection.setFormatColumns(true);
            sheetProtection.setFormatRows(true);
            sheetProtection.setInsertColumns(true);
            sheetProtection.setInsertRows(true);
            sheetProtection.setInsertHyperlinks(true);
            sheetProtection.setDeleteColumns(true);
            sheetProtection.setDeleteRows(true);
            sheetProtection.setSelectLockedCells(true);
            sheetProtection.setSelectUnlockedCells(false);
            sheetProtection.setSort(true);
            sheetProtection.setAutoFilter(true);
            sheetProtection.setPivotTables(true);

            this.columLockIndex = columLockIndex;
        }
        return this;
    }

    /**
     * 设置下拉框列
     *
     * @param colIndex
     * @param dropDownList
     * @Author: loine
     * @Date: 2024/11/25 15:13
     */
    public <E> MultiTitleExportExcelUtil setDropDownList(int firstRow, int colIndex, String[] dropDownList) {
        // 将下拉列表的内容设置到单元格中
        DataValidationHelper validationHelper = sheet.getDataValidationHelper();
        DataValidationConstraint constraint = validationHelper.createExplicitListConstraint(dropDownList);

        // 设置数据验证的单元格范围
        CellRangeAddressList addressList = new CellRangeAddressList(firstRow, 65536, colIndex, colIndex);
        DataValidation dataValidation = validationHelper.createValidation(constraint, addressList);
        // 禁止输入非下拉列表中的内容
        dataValidation.setShowErrorBox(true);
        // 将数据验证添加到工作表中
        sheet.addValidationData(dataValidation);
        return this;
    }

    /**
     * 添加示例数据sheet
     *
     * @param sheetName
     * @param titleList
     * @param list
     * @Author: loine
     * @Date: 2024/12/2 15:34
     */
    public <E> MultiTitleExportExcelUtil dddSampleSheet(String sheetName, List<Title> titleList, List<List<Object>> list) {
        if (titleList.size() > 0) {
            XSSFSheet sampleSheet = wb.createSheet(sheetName);
            sampleSheet.setDefaultColumnWidth(20);
            Row row = sampleSheet.createRow(0);
            // 设置标题
            for (int i = 0; i < titleList.size(); i++) {
                Title title = titleList.get(i);
                row.setHeightInPoints(title.getHeight());
                Cell cell = row.createCell(i);
                cell.setCellStyle(styles.get(title.getStyle()));
                cell.setCellValue(title.getName());
            }
            // 设置数据
            if (list.size() > 0) {
                int rownum = 1;
                for (List<Object> dataRow : list) {
                    int column = 0;
                    row = sampleSheet.createRow(rownum++);
                    for (Object val : dataRow) {
                        val = val == null ? "" : val;

                        this.addCell(row, column++, val, 0, Class.class);
                    }
                    if (row.getRowNum() % 1000 == 0) {
                        log.info("写入{}行", row.getRowNum());
                    }
                }
            }
        }
        return this;
    }

    /**
     * 输出到客户端
     *
     * @param fileName 输出文件名
     */
    public MultiTitleExportExcelUtil write(HttpServletResponse response, String fileName) throws IOException {
        response.reset();
        response.setContentType("application/octet-stream;charset=utf-8");
        fileName = URLEncoder.encode(fileName, "UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        write(response.getOutputStream());
        return this;
    }

    /**
     * 输出到客户端
     */
    public MultiTitleExportExcelUtil write(HttpServletRequest request, HttpServletResponse response, String fileName) throws IOException {
        response.reset();
        response.setContentType("application/octet-stream; charset=utf-8");
        fileName = filenameEncoding(fileName, request);
        response.setHeader("Content-Disposition", "attachment; filename=" + fileName + ";");
        write(response.getOutputStream());
        return this;
    }

    /**
     * 文件名编码
     */
    private static String filenameEncoding(String filename, HttpServletRequest request) throws IOException {
        String agent = request.getHeader("User-Agent").toUpperCase(); //获取浏览器
        if (agent.contains("iphone".toUpperCase())
                || agent.contains("mac".toUpperCase())) {
            filename = new String(filename.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
        } else {
            filename = URLEncoder.encode(filename, "UTF-8");
        }
        return filename;
    }

    /**
     * 输出到文件
     * param fileName 输出文件名
     */
    private MultiTitleExportExcelUtil writeFile(String name) throws IOException {
        FileOutputStream os = new FileOutputStream(name);
        this.write(os);
        return this;
    }

    @Data
    public static class Title {
        private String name;// 列名称
        private Integer colNum;// 占用列数
        private float height;// 列高
        private String style;// 样式

        public Title(String name, Integer colNum, float height, String style) {
            this.name = name;
            this.colNum = colNum;
            this.height = height;
            this.style = style;
        }

    }
}