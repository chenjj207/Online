package com.purchase.product.util;


import lombok.Builder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

@Slf4j
@Builder
public class RedisUtils {

    // 上锁成功后返回值
    private static final String LOCK_SUCCESS = "OK";

    // SetNX方法中NX的含义
    private static final String SET_IF_NOT_EXIST = "NX";

    // SetNX方法中PX的含义
    private static final String SET_WITH_EXPIRE_TIME = "PX";

    private RedisTemplate<?, ?> redisTemplate;

    public String searchLockNX(String key) {
        //指令执行成功的话返回"OK"
        return redisTemplate.execute((RedisCallback<String>) redisConnection -> new String(
                        Optional.ofNullable(redisConnection.get(key.getBytes()))
                                .orElse(new byte[]{})
                )
        );
    }

    // 申请一个唯一锁
    public Boolean findLockNX(String key) {
        //指令执行成功的话返回"OK"
        return redisTemplate.execute((RedisCallback<Boolean>) redisConnection -> redisConnection.exists(key.getBytes()));
    }

    // 申请一个唯一锁
    public boolean setLockNX(String key, long expireMillis) {
        return (Boolean) redisTemplate.execute((RedisCallback) connection -> {
            long expireAt = System.currentTimeMillis() + expireMillis;
            Boolean acquire = connection.setNX(key.getBytes(), String.valueOf(expireAt).getBytes());
            if (acquire) {
                return true;
            } else {
                byte[] value = connection.get(key.getBytes());
                if (Objects.nonNull(value) && value.length > 0) {
                    long expireTime = Long.parseLong(new String(value));
                    // 如果锁已经过期
                    if (expireTime < System.currentTimeMillis()) {
                        return true;
                        // 重新加锁，防止死锁
//                        byte[] oldValue = connection.getSet(key.getBytes(), String.valueOf(expireAt).getBytes());
//                        return Long.parseLong(new String(oldValue)) < System.currentTimeMillis();
                    }
                }
            }
            return false;
        });
    }

    // 申请一个带过期时间的唯一锁
    public boolean setLockNX(String key, String value, long expired) {
        //指令执行成功的话返回"OK"
        long expireAt = System.currentTimeMillis() + expired;
        return redisTemplate.execute((RedisCallback<Boolean>) redisConnection -> redisConnection.setEx(key.getBytes(), expireAt, value.getBytes()));
    }

    // 释放一个唯一锁
    public Boolean releaseLockNX(String key) {
        //指令执行成功的话返回"OK"
        return redisTemplate.execute((RedisCallback<Boolean>) redisConnection -> {
            Long del = redisConnection.del(key.getBytes());
            log.info("释放锁{},RedisKeyCommands.del返回值{}", key, del);
            return del != null && del > 0;
        });
    }

    /***
     * 在有锁的环境下执行并得到执行结果
     * @author CGR
     * @param key 锁的key
     * @param timeInMillions 死锁过期时间
     * @param supp 执行的方法
     */
    public <T> T lockDo(String key, long timeInMillions, Supplier<T> supp) {
        while (!setLockNX(key, timeInMillions)) {
            try {
                Thread.sleep(1000L);
                log.debug("等待锁:{}", key);
            } catch (InterruptedException e) {
                log.info("暂停失败", e);
            }
        }
        return work(key, timeInMillions, supp);
    }

    private <T> T work(String key, long timeInMillions, Supplier<T> supp) {
        String uuid = UUID.randomUUID().toString();
        log.info("获得锁{},标示{},最长占用时间{}秒", new Object[]{key, uuid, timeInMillions / 1000L});
        T var6;
        try {
            var6 = supp.get();
        } catch (Exception var10) {
            log.error("执行出错;" + var10.getMessage(), var10);
            throw var10;
        } finally {
            log.info("释放锁{},标示{}", key, uuid);
            this.releaseLockNX(key);
        }
        return var6;
    }

    public static Long genCode(String customeCode, RedisTemplate redisTemplate, Supplier<Long> task) {
        if (StringUtils.isEmpty(customeCode)) {
            customeCode = "ID";
        }

        String redisKey = customeCode + "_INCR_NO";
        Object redisNumber = redisTemplate.opsForValue().get(redisKey);
        Long num;
        if (redisNumber != null) {
            return redisTemplate.opsForValue().increment(redisKey, 1);
        }
        Long temp = task.get();
        num = (temp == null ? 0 : temp) +1;
        redisTemplate.opsForValue().set(redisKey, num);
        return num;
    }

}
