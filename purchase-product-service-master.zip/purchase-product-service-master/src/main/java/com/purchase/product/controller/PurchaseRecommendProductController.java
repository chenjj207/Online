package com.purchase.product.controller;

import com.purchase.product.dto.BusinessRecommendProductListDto;
import com.purchase.product.dto.PurchaseRecommendProductAddDTO;
import com.purchase.product.model.PurchaseRecommendProduct;
import com.purchase.product.service.PurchaseRecommendProductService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 供应商产品推荐提供类
 * @date 2024/1/11  11:34
 */
@RestController
@RequestMapping(value = "/purchaseRecommendProduct")
@Api(value = "PurchaseRecommendProductController", tags = {"供应商产品推荐提供类"})
@Slf4j
public class PurchaseRecommendProductController {

    @Autowired
    PurchaseRecommendProductService purchaseRecommendProductService;

    @PostMapping("/add")
    @ApiOperation(value = "添加推荐商品")
    public JsonResult<List<String>> add(@RequestBody PurchaseRecommendProductAddDTO purchaseRecommendProductAddDTO) {
        List<String> ids = purchaseRecommendProductService.add(purchaseRecommendProductAddDTO);
        return new JsonResult<>(true, "添加成功", ids);
    }

    @PostMapping("/delete")
    @ApiOperation(value = "删除推荐商品")
    public JsonResult<String> delete(@RequestParam String id) {
        String result = purchaseRecommendProductService.remove(id);
        return new JsonResult<>(true, result, id);
    }

    /**
     * 商家后台推荐商品相关接口
     */
    @PostMapping(value = "/list")
    @ApiOperation(value = "商家后台商家推荐产品列表")
    public JsonResult<Page<PurchaseRecommendProduct>> searchRecommendProduct(@Valid @RequestBody BusinessRecommendProductListDto businessRecommendProductListDto) {
        return new JsonResult<>(true, null, purchaseRecommendProductService.searchRecommendProduct(businessRecommendProductListDto));
    }


}
