package com.purchase.product.activemq;

import com.purchase.product.service.PurchaseScmProductApplyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


/**
 * @author jidonglin
 * @Description: 商家队列消费
 * @date 2024/12/24  14:30
 */
@Component
@Slf4j
public class QueueConsumerListener {

    @Resource
    private PurchaseScmProductApplyService purchaseScmProductApplyService;

    // 审核
    @JmsListener(destination = "${mq.queue.task.product-approve}", containerFactory = "queueListener", concurrency = "1")
    public void readProductApproveQueue(String message) {
        purchaseScmProductApplyService.readProductApproveQueue(message);
    }

    // 导出
    @JmsListener(destination = "${mq.queue.task.product-export}", containerFactory = "queueListener", concurrency = "1")
    public void readProductExportQueue(String message) {
        purchaseScmProductApplyService.readProductExportQueue(message);
    }
}
