package com.purchase.product.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:
 * @Author: loine
 * @Date: 2026/3/12 10:05
 */
@Data
public class UserInfoVo {
    @ApiModelProperty("用户id")
    private String id;
    @ApiModelProperty("用户名称")
    private String name;
    @ApiModelProperty("用户编码")
    private String code;
}
