package com.purchase.product.dto.oss;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/***
 * oss资源数据素材管理搜索入参
 * @author zhangcheng
 * @Date 2022-08-10
 */
@Data
public class OssResourceRequestDto {
    @ApiModelProperty("路径(默认是空，后面用接口返回的参数传递)")
    private String path;
    @ApiModelProperty("用于分页标记oss位置传参")
    private String nextContinuationToken;
    @ApiModelProperty("每次查询加载数量")
    private int maxKeys;
    @ApiModelProperty("前缀搜索")
    private String prefix;
}
