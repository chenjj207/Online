package com.purchase.product.controller;

import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import javax.annotation.Resource;
import io.swagger.annotations.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.purchase.product.model.ProductProperties;
import com.purchase.product.service.ProductPropertiesService;

/**
 * ProductPropertiesController 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2022-11-04 11:46:24
 */
@RestController
@RequestMapping(value = "/productProperties")
@Api(value = "ProductPropertiesController" , tags = {"ProductPropertiesController 服务提供类"})
public class ProductPropertiesController {

    @Resource
    private ProductPropertiesService productPropertiesService;

    @GetMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "param", value = "字段", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "是否需要审核（Y：需要，N：不需要）", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<ProductProperties>> search(@ParamHide ProductProperties productProperties, @ParamHide Page<ProductProperties> page) {
        page = productPropertiesService.search(productProperties, page);
        return new JsonResult<>(true, "查询成功", page);
    }

    @GetMapping(value = "/listAll")
    @ApiOperation(value = "获取所有数据")
    public JsonResult<List<ProductProperties>> listAll() {
        return new JsonResult<>(true, "查询成功", productPropertiesService.listAll());
    }

    @PostMapping("/add")
    @ApiOperation(value = "新增接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "param", value = "字段", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "是否需要审核（Y：需要，N：不需要）", dataType = "String", paramType = "query"),
    })
    public JsonResult<String> addProductProperties(@RequestBody ProductProperties productProperties) {
        String id = productPropertiesService.add(productProperties);
        return new JsonResult<>(true, "添加成功", id);
    }

    @PutMapping("/edit")
    @ApiOperation(value = "编辑接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "param", value = "字段", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "是否需要审核（Y：需要，N：不需要）", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult editProductProperties(@RequestBody @Check(field = {"id"}) ProductProperties productProperties) {
        productPropertiesService.edit(productProperties);
        return new JsonResult(true, "编辑成功");
    }

    @GetMapping(value = "/{id}")
    @ApiOperation(value = "根据id获取数据")
    @ApiImplicitParams(@ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true))
    public JsonResult<ProductProperties> getProductProperties(@PathVariable(value = "id") String id) {
        ProductProperties productProperties = productPropertiesService.get(id);
        return new JsonResult<>(true, "查询成功", productProperties);
    }

    @DeleteMapping(value = "/delete")
    @ApiOperation(value = "根据传入的Id，删除数据")
    public JsonResult<String> batchDelete(@RequestBody List<String> ids) {
        productPropertiesService.deleteByIds(ids);
        return new JsonResult<>(true, "删除成功");
    }
}