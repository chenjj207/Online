package com.purchase.product.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.URLUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.base.Joiner;
import com.purchase.exception.ZydExceptions;
import com.purchase.model.PurchaseProductSync;
import com.purchase.product.client.MsgClient;
import com.purchase.product.client.PublicProductFeignClient;
import com.purchase.product.client.TaskClient;
import com.purchase.product.client.dto.TriggerMsgRequest;
import com.purchase.product.conf.OssConf;
import com.purchase.product.dto.*;
import com.purchase.product.mapper.*;
import com.purchase.product.model.*;
import com.purchase.product.util.MultiTitleExportExcelUtil;
import com.purchase.product.util.ReadExcelUtil;
import com.purchase.product.util.RedisUtils;
import com.purchase.product.vo.CommonProductVo;
import com.purchase.product.vo.PurchaseScmErpProductCodeApplyVo;
import com.purchase.product.vo.PurchaseScmProductApplyVo;
import com.purchase.utils.date.ZydDateUtils;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.database.mybatis.helper.CorpHelper;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: loine
 * @Date: 2024/10/14 15:50
 **/
@Service
@Slf4j
public class PurchaseScmProductApplyService extends BaseServiceImpl<PurchaseScmProductApply> {

    @Resource
    private PurchaseScmProductApplyMapper purchaseScmProductApplyMapper;
    @Resource
    private PurchaseDeliveryDateMapper purchaseDeliveryDateMapper;
    @Resource
    private PurchaseScmGuideConfigMapper purchaseScmGuideConfigMapper;
    @Resource
    private PurchaseScmGuideRecordMapper purchaseScmGuideRecordMapper;
    @Resource
    private PurchaseMsgCompanyUserMapper purchaseMsgCompanyUserMapper;
    @Resource
    private PurchaseScmProductApplyChangeRecordMapper purchaseScmProductApplyChangeRecordMapper;
    @Resource
    private PurchaseScmProductApplyAuditRecordMapper purchaseScmProductApplyAuditRecordMapper;
    @Resource
    private PurchaseScmProductApplyAuditSumMapper purchaseScmProductApplyAuditSumMapper;
    @Resource
    private TableSettingsMapper tableSettingsMapper;
    @Resource
    private OssMaterialService ossMaterialService;
    @Autowired
    private RedisTemplate redisTemplate;
    @Resource
    private PublicProductFeignClient publicProductFeignClient;
    @Resource
    private MsgClient msgClient;
    @Resource
    private TaskClient taskClient;
    @Value("${export.excel.sheet.password:}")
    private String sheetPassword;
    @Value("${odsUrl}")
    private String odsUrl;
    @Autowired
    private OssConf ossConf;
    @Resource
    private PurchaseScmErpProductCodeApplyService purchaseScmErpProductCodeApplyService;

    /**
     * 供应商-获取分页
     *
     * @param dto`
     * @Author: loine
     * @Date: 2024/10/14 16:02
     */
    public Page<PurchaseScmProductApplyVo.SupplierSearchVo> supplierSearch(PurchaseScmProductApplyDto.SupplierSearchDto dto) {
        Page<PurchaseScmProductApplyVo.SupplierSearchVo> page = new Page<>();
        page.setPageNum(BeanUtil.isEmpty(dto.getPageNum()) ? 1 : dto.getPageNum());
        page.setPageSize(BeanUtil.isEmpty(dto.getPageSize()) ? 12 : dto.getPageSize());
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<PurchaseScmProductApplyVo.SupplierSearchVo> list = getSupplierApplySearch(dto);
        for (PurchaseScmProductApplyVo.SupplierSearchVo l : list) {
            l.setSupplyPrice(formatBigDecimalData(l.getSupplyPrice()));
            l.setPrice(formatBigDecimalData(l.getPrice()));
            l.setSuggestPrice(formatBigDecimalData(l.getSuggestPrice()));
            if (l.getAuditTime3() != null) {
                l.setAuditTimeMerge(l.getAuditTime3());
            } else if (l.getAuditTime2() != null) {
                l.setAuditTimeMerge(l.getAuditTime2());
            } else if (l.getAuditTime1() != null) {
                l.setAuditTimeMerge(l.getAuditTime1());
            }
            Map<String, String> newSpec = handleSpecToTwoColumn(l.getSpecData());
            l.setSpecName(newSpec.get("specName"));
            l.setSpecValue(newSpec.get("specValue"));
        }
        return new Page<>(list);
    }

    /**
     * 供应商-搜索角标
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 13:12
     */
    public PurchaseScmProductApplyVo.SearchCountVo supplierSearchCount(PurchaseScmProductApplyDto.SupplierSearchDto dto) {
        String supplierId = (String) ContextHandler.get("supplierId");
        String corpCode = ContextHandler.getCorpCode();
        return purchaseScmProductApplyMapper.supplierSearchCount(dto, supplierId, corpCode);
    }

    /**
     * 供应商-详情
     *
     * @param id
     * @Author: loine
     * @Date: 2024/10/14 17:43
     */
    public PurchaseScmProductApplyVo.SupplierDetailVo supplierDetail(String id) {
        PurchaseScmProductApplyVo.SupplierDetailVo detailVo = new PurchaseScmProductApplyVo.SupplierDetailVo();
        PurchaseScmProductApply detail = getDetail(id);
        if (detail != null) {
            BeanUtils.copyProperties(detail, detailVo);
            detailVo.setSupplyPrice(formatBigDecimalData(detail.getSupplyPrice()));
            detailVo.setPrice(formatBigDecimalData(detail.getPrice()));
            detailVo.setSuggestPrice(formatBigDecimalData(detail.getSuggestPrice()));
            detailVo.setProductPicName(resizeImage(detailVo.getProductPicName()));
            // 产品名称为空，需要按商城拼接
            handleMaterialName(detailVo);
        }
        detailVo.setUrlPrefix(ossConf.getOssUrl());
        return detailVo;
    }

    /**
     * 供应商-随机商品详情
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 9:33
     */
    public PurchaseScmProductApplyVo.SupplierRandomDetailVo supplierRandomDetail(PurchaseScmProductApplyDto.SupplierRandomDetailDto dto) {
        CorpHelper.skipCorpCode(true);
        PurchaseScmProductApplyVo.SupplierRandomDetailVo detailVo = purchaseScmProductApplyMapper.selectRandomCommonByCataBrandProp(dto);
        if (detailVo != null) {
            // 处理折扣
            if (detailVo.getPrice() != null && new BigDecimal(detailVo.getPrice()).compareTo(BigDecimal.ZERO) != 0) {
                if (detailVo.getSupplyPrice() != null) {
                    detailVo.setSupplyDiscount(new BigDecimal(detailVo.getSupplyPrice()).divide(new BigDecimal(detailVo.getPrice()), 4, RoundingMode.HALF_UP));
                }
                if (detailVo.getSuggestPrice() != null) {
                    detailVo.setSuggestDiscount(new BigDecimal(detailVo.getSuggestPrice()).divide(new BigDecimal(detailVo.getPrice()), 4, RoundingMode.HALF_UP));
                }
            }
            detailVo.setSupplyPrice(formatBigDecimalData(detailVo.getSupplyPrice()));
            detailVo.setPrice(formatBigDecimalData(detailVo.getPrice()));
            detailVo.setSuggestPrice(formatBigDecimalData(detailVo.getSuggestPrice()));
            detailVo.setProductPicName(resizeImage(detailVo.getProductPicName()));
            detailVo.setUrlPrefix(ossConf.getOssUrl());
        } else {
//            CorpHelper.skipCorpCode(true);
//            String cataName = purchaseScmProductApplyMapper.getCommonCataName(dto.getCataId());
//            CorpHelper.skipCorpCode(true);
//            String brandName = purchaseScmProductApplyMapper.getCommonBrandName(dto.getBrandId());
//            String propName = "";
//            if (dto.getPropId() != null) {
//                CorpHelper.skipCorpCode(true);
//                propName = purchaseScmProductApplyMapper.getCommonPropName(dto.getPropId());
//            }
            detailVo = new PurchaseScmProductApplyVo.SupplierRandomDetailVo();
//            if (StringUtils.isBlank(propName)) {
//                detailVo.setMaterialName(cataName + " " + brandName);
//            } else {
//                detailVo.setMaterialName(cataName + " " + propName + " " + brandName);
//            }
            detailVo.setProductId(0L);
            detailVo.setProductType("IC65N 3P C32A");
            detailVo.setSkuCode("A9F18332");
            detailVo.setProductCode("151049");
            detailVo.setSupplyPrice("160.91");
            detailVo.setPrice("179.81");
            detailVo.setSuggestPrice("188.32");
            detailVo.setStock(0);
            detailVo.setDeliveryDate("预计5天");
            detailVo.setWeight("342");
            detailVo.setUrlPrefix(ossConf.getOssUrl());
        }
        return detailVo;
    }

    /**
     * 供应商-选择货期
     *
     * @Author: loine
     * @Date: 2024/10/16 11:23
     */
    public PurchaseScmProductApplyVo.SupplierSelectDeliveryVo supplierSelectDelivery() {
        PurchaseScmProductApplyVo.SupplierSelectDeliveryVo vo = new PurchaseScmProductApplyVo.SupplierSelectDeliveryVo();
        List<String> deliveryDates = new ArrayList<>();
        String supplierId = (String) ContextHandler.get("supplierId");
        PurchaseDeliveryDate date = new PurchaseDeliveryDate();
        date.setSupplierId(supplierId);
        List<PurchaseDeliveryDate> list = purchaseDeliveryDateMapper.select(date);
        for (PurchaseDeliveryDate l : list) {
            deliveryDates.add(l.getDeliveryDate());
        }
        vo.setDeliveryDates(deliveryDates);
        return vo;
    }

    /**
     * 供应商-校验是否已经申请过
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/16 10:51
     */
    public JsonResult supplierCheckIsApply(PurchaseScmProductApplyDto.SupplierCheckIsApplyDto dto) {
        String supplierId = (String) ContextHandler.get("supplierId");
        int num = purchaseScmProductApplyMapper.supplierCheckIsApply(supplierId, dto.getProductType());
        ZydExceptions.re(num > 0, "加入失败，该产品型号已添加");
        return new JsonResult(true, "");
    }

    /**
     * 供应商-下载导入模板/导出数据
     *
     * @param request
     * @param response
     * @param dto
     * @Author: loine
     * @Date: 2024/10/16 11:48
     */
    public void supplierDownloadImportTemplate(HttpServletRequest request, HttpServletResponse response, PurchaseScmProductApplyDto.SupplierDownloadImportTemplateDto dto) {
        try {
            String title = "分类：" + dto.getFirstLevelCataName() + " >> " + dto.getSecondLevelCataName() + " >> " + dto.getThreeLevelCataName() + " ，品牌：" + dto.getBrandName();
            if (StringUtils.isNotBlank(dto.getPropName())) {
                title += " ，系列：" + dto.getPropName();
            }
            boolean isUpdate = dto.getType().equals("2");
            int offset = 0;
            if (isUpdate) {
                offset = 2;
            }
            boolean hasSpec = !CollectionUtils.isEmpty(dto.getSpecNames());
            List<List<MultiTitleExportExcelUtil.Title>> titleList = new ArrayList<>();
            List<MultiTitleExportExcelUtil.Title> titles1 = new ArrayList<>();
            titles1.add(new MultiTitleExportExcelUtil.Title(title, 13 + offset + dto.getSpecNames().size(), 25, MultiTitleExportExcelUtil.STYLE_TITLE1));
            List<MultiTitleExportExcelUtil.Title> titles2 = new ArrayList<>();
            titles2.add(new MultiTitleExportExcelUtil.Title("基础信息", 10 + offset, 19.5f, MultiTitleExportExcelUtil.STYLE_TITLE2));
            if (isUpdate) {
                titles2.add(new MultiTitleExportExcelUtil.Title("价格相关", 3, 19.5f, MultiTitleExportExcelUtil.STYLE_TITLE2));
            } else {
                titles2.add(new MultiTitleExportExcelUtil.Title("商品价格", 3, 19.5f, MultiTitleExportExcelUtil.STYLE_TITLE2));
            }
            if (hasSpec) {
                titles2.add(new MultiTitleExportExcelUtil.Title("规格参数（可参照规格参数示例数据或新增）", dto.getSpecNames().size(), 19.5f, MultiTitleExportExcelUtil.STYLE_TITLE2));
            }
            List<MultiTitleExportExcelUtil.Title> titles3 = new ArrayList<>();
            List<MultiTitleExportExcelUtil.Title> specTitle3 = new ArrayList<>();
            if (isUpdate) {
                titles3.add(new MultiTitleExportExcelUtil.Title("状态", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
                if (dto.getEntrance().equals("1")) {
                    titles3.add(new MultiTitleExportExcelUtil.Title("申请编号", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
                } else {
                    titles3.add(new MultiTitleExportExcelUtil.Title("商品ID", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
                }
            }
            titles3.add(new MultiTitleExportExcelUtil.Title("*产品型号", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3RED));
            titles3.add(new MultiTitleExportExcelUtil.Title("产品系列", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            titles3.add(new MultiTitleExportExcelUtil.Title("产品名称", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            titles3.add(new MultiTitleExportExcelUtil.Title("厂家物料号", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            titles3.add(new MultiTitleExportExcelUtil.Title("商品编码", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            titles3.add(new MultiTitleExportExcelUtil.Title("*库存", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3RED));
            titles3.add(new MultiTitleExportExcelUtil.Title("*交货期", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3RED));
            titles3.add(new MultiTitleExportExcelUtil.Title("重量", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            titles3.add(new MultiTitleExportExcelUtil.Title("*单位", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3RED));
            titles3.add(new MultiTitleExportExcelUtil.Title("最小起订量", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            titles3.add(new MultiTitleExportExcelUtil.Title("面价", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            titles3.add(new MultiTitleExportExcelUtil.Title("供货价", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            titles3.add(new MultiTitleExportExcelUtil.Title("建议销售价", 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            if (hasSpec) {
                for (String specName : dto.getSpecNames()) {
                    titles3.add(new MultiTitleExportExcelUtil.Title("*" + specName, 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3RED));
                    specTitle3.add(new MultiTitleExportExcelUtil.Title(specName, 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE4));
                }
            }
            titleList.add(titles1);
            titleList.add(titles2);
            titleList.add(titles3);

            String fileName;
            List<List<Object>> objects = new ArrayList<>();
            List<Integer> columLockIndex = new ArrayList<>();
            if (isUpdate) {
                if (dto.getEntrance().equals("1")) {
                    fileName = "商品申请修改";
                } else {
                    fileName = "我的商品信息修改";
                }
                // 查询数据
                PurchaseScmProductApplyDto.SupplierSameSearchDto searchDto = new PurchaseScmProductApplyDto.SupplierSameSearchDto();
                BeanUtils.copyProperties(dto, searchDto);
                searchDto.setPageNum(0);
                searchDto.setPageSize(0);
                // 切换分类需替换为旧分类查询基本信息
                boolean needSpecValue = true;
                if (StringUtils.isNotBlank(dto.getOldFirstLevelCataName()) && StringUtils.isNotBlank(dto.getOldSecondLevelCataName()) && StringUtils.isNotBlank(dto.getOldThreeLevelCataName())) {
                    searchDto.setFirstLevelCataName(dto.getOldFirstLevelCataName());
                    searchDto.setSecondLevelCataName(dto.getOldSecondLevelCataName());
                    searchDto.setThreeLevelCataName(dto.getOldThreeLevelCataName());
                    // 此时规格一定为空，无需处理，因此设置为false
                    needSpecValue = false;
                }
                // 切换品牌需替换为旧品牌查询基本信息
                if (StringUtils.isNotBlank(dto.getOldBrandName())) {
                    searchDto.setBrandName(dto.getOldBrandName());
                }
                Page<PurchaseScmProductApplyVo.SupplierSameSearchVo> page = supplierSameSearch(searchDto);
                List<PurchaseScmProductApplyVo.SupplierSameSearchVo> list = page.getList();
                for (PurchaseScmProductApplyVo.SupplierSameSearchVo l : list) {
                    List<Object> object = new ArrayList<>();
                    if (dto.getEntrance().equals("1")) {
                        String auditStatus = "";
                        if (l.getAuditStatus() == 0) {
                            auditStatus = "待提交";
                        } else if (l.getAuditStatus() == 1) {
                            auditStatus = "待分部审核";
                        } else if (l.getAuditStatus() == 2) {
                            auditStatus = "待资料审核";
                        } else if (l.getAuditStatus() == 3) {
                            auditStatus = "待价格审核";
                        } else if (l.getAuditStatus() == 4) {
                            auditStatus = "通过";
                        } else if (l.getAuditStatus() == 5) {
                            auditStatus = "驳回";
                        }
                        object.add(auditStatus);
                        object.add(l.getApplyNo() == null ? "" : l.getApplyNo());
                    } else {
                        object.add(StringUtils.isBlank(l.getIsOnsale()) ? "" : (l.getIsOnsale().equals("Y") ? "上架中" : "已下架"));
                        object.add(l.getProductId() == null ? "" : l.getProductId());
                    }
                    object.add(StringUtils.isBlank(l.getProductType()) ? "" : l.getProductType());
                    object.add(StringUtils.isBlank(l.getPropName()) ? "" : l.getPropName());
                    object.add(StringUtils.isBlank(l.getMaterialName()) ? "" : l.getMaterialName());
                    object.add(StringUtils.isBlank(l.getSkuCode()) ? "" : l.getSkuCode());
                    object.add(StringUtils.isBlank(l.getProductCode()) ? "" : l.getProductCode());
                    object.add(l.getStock() == null ? "" : (l.getStock().equals(1) ? "现货" : "订货"));
                    object.add(StringUtils.isBlank(l.getDeliveryDate()) ? "" : l.getDeliveryDate());
                    object.add(StringUtils.isBlank(l.getWeight()) ? "" : l.getWeight());
                    object.add(StringUtils.isBlank(l.getUnit()) ? "" : l.getUnit());
                    object.add(l.getMinimunRequire() == null ? "1" : l.getMinimunRequire());
                    object.add(l.getPrice() == null ? "" : l.getPrice());
                    object.add(l.getSupplyPrice() == null ? "" : l.getSupplyPrice());
                    object.add(l.getSuggestPrice() == null ? "" : l.getSuggestPrice());
                    // 处理规格
                    Map<String, String> specNameUnitMaps = assembleSpecUnit(l.getFirstLevelCataName(), l.getSecondLevelCataName(), l.getThreeLevelCataName());
                    if (hasSpec) {
                        JSONArray specData = null;
                        if (StringUtils.isNotBlank(l.getSpecData())) {
                            specData = JSONArray.parseArray(l.getSpecData());
                        }
                        for (String specNameUnit : dto.getSpecNames()) {
                            String specName = specNameUnitMaps.get(specNameUnit);
                            String specValue = "";
                            if (specData != null && specData.size() > 0 && needSpecValue) {
                                for (int i = 0; i < specData.size(); i++) {
                                    JSONObject spec = specData.getJSONObject(i);
                                    if (spec != null) {
                                        if (spec.get("specName") != null && specName.equals(spec.get("specName"))) {
                                            if (spec.get("specValue") != null) {
                                                specValue = spec.getString("specValue");
                                            }
                                        }
                                    }

                                }
                            }
                            object.add(specValue);
                        }
                    }
                    objects.add(object);
                }
                // 列加锁
                columLockIndex.add(0);
                columLockIndex.add(1);
            } else {
                fileName = "批量导入商品";
                // 商品申请-新增的需要增加示例行
                if (dto.getEntrance().equals("1")) {
                    PurchaseScmProductApplyVo.SupplierSameSearchVo l = purchaseScmProductApplyMapper.getCommonProductExample(dto);
                    if (l != null) {
                        List<Object> object = new ArrayList<>();
                        object.add("示例：" + (StringUtils.isBlank(l.getProductType()) ? "" : l.getProductType()));
                        object.add("示例：" + (StringUtils.isBlank(l.getPropName()) ? "" : l.getPropName()));
                        object.add("示例：" + (StringUtils.isBlank(l.getMaterialName()) ? "" : l.getMaterialName()));
                        object.add("示例：" + (StringUtils.isBlank(l.getSkuCode()) ? "" : l.getSkuCode()));
                        object.add("示例：" + (StringUtils.isBlank(l.getProductCode()) ? "" : l.getProductCode()));
                        object.add("示例：" + (l.getStock() == null ? "" : (l.getStock().equals(1) ? "现货" : "订货")));
                        object.add("示例：" + (StringUtils.isBlank(l.getDeliveryDate()) ? "" : l.getDeliveryDate()));
                        object.add("示例：" + (StringUtils.isBlank(l.getWeight()) ? "" : l.getWeight()));
                        object.add("示例：" + (StringUtils.isBlank(l.getUnit()) ? "" : l.getUnit()));
                        object.add("示例：" + (l.getMinimunRequire() == null ? "1" : l.getMinimunRequire()));
                        object.add("示例：" + (l.getPrice() == null ? "" : l.getPrice()));
                        object.add("示例：" + (l.getSupplyPrice() == null ? "" : l.getSupplyPrice()));
                        object.add("示例：" + (l.getSuggestPrice() == null ? "" : l.getSuggestPrice()));
                        // 处理规格
                        if (hasSpec) {
                            JSONArray specData = null;
                            if (StringUtils.isNotBlank(l.getSpecData())) {
                                specData = JSONArray.parseArray(l.getSpecData());
                            }
                            for (String specName : dto.getSpecNames()) {
                                String specValue = "";
                                if (specData != null && specData.size() > 0) {
                                    for (int i = 0; i < specData.size(); i++) {
                                        JSONObject spec = specData.getJSONObject(i);
                                        if (spec != null) {
                                            if (spec.get("specName") != null && specName.equals(spec.get("specName"))) {
                                                if (spec.get("specValue") != null) {
                                                    specValue = spec.getString("specValue");
                                                }
                                            }
                                        }

                                    }
                                }
                                object.add("示例：" + specValue);
                            }
                        }
                        object.add("示例数据导入需删除");
                        objects.add(object);
                    }
                }
            }
            // 查询规格示例值
            List<List<Object>> sampleSpecs = new ArrayList<>();
            int maxSize = 0;
            if (hasSpec) {
                CorpHelper.skipCorpCode(true);
                List<PurchaseScmProductApplyVo.CommonSpecVo> commonSpecs = purchaseScmProductApplyMapper.getCommonSpec(dto.getFirstLevelCataName(), dto.getSecondLevelCataName(), dto.getThreeLevelCataName());
                Map<String, PurchaseScmProductApplyVo.CommonSpecVo> commonSpecMap = commonSpecs.stream().collect(Collectors.toMap(PurchaseScmProductApplyVo.CommonSpecVo::getSpecName, c -> c, (c1, c2) -> c1));
                for (String specName : dto.getSpecNames()) {
                    PurchaseScmProductApplyVo.CommonSpecVo commonSpec = commonSpecMap.get(specName);
                    if (commonSpec != null) {
                        CorpHelper.skipCorpCode(true);
                        List<String> specValues = purchaseScmProductApplyMapper.getCommonSpecValue(commonSpec.getSpecId());
                        commonSpec.setSpecValues(specValues);
                        if (maxSize < specValues.size()) {
                            maxSize = specValues.size();
                        }
                    }
                }
                for (int i = 0; i < maxSize; i++) {
                    List<Object> sampleSpec = new ArrayList<>();
                    for (String specName : dto.getSpecNames()) {
                        PurchaseScmProductApplyVo.CommonSpecVo commonSpec = commonSpecMap.get(specName);
                        if (commonSpec != null) {
                            List<String> specValues = commonSpec.getSpecValues();
                            if (specValues.size() > i) {
                                sampleSpec.add(StringUtils.isBlank(specValues.get(i)) ? "" : specValues.get(i));
                            } else {
                                sampleSpec.add("");
                            }
                        } else {
                            sampleSpec.add("");
                        }
                    }
                    sampleSpecs.add(sampleSpec);
                }
            }
            new MultiTitleExportExcelUtil("商品明细", titleList)
                    .setDataColumLock(sheetPassword, columLockIndex)
                    .setDropDownList(titleList.size(), 5 + offset, new String[]{"现货", "订货"})
                    .setDataListObject(objects)
                    .dddSampleSheet("规格参数示例", specTitle3, sampleSpecs)
                    .write(request, response, fileName + "(" + title.replaceAll(" >> ", "-") + ").xlsx");
        } catch (Exception e) {
            log.error("下载导入模板/导出数据excel导出异常：{}", e.getMessage(), e);
            ZydExceptions.re(true, "下载导入模板/导出数据导出失败");
        }
    }

    /**
     * 供应商-读取导入模板数据
     *
     * @param file
     * @param type                类型（1=新增，2=修改）
     * @param specNames
     * @param firstLevelCataName
     * @param secondLevelCataName
     * @param threeLevelCataName
     * @Author: loine
     * @Date: 2024/10/16 17:39
     */
    public List<Map<String, String>> supplierReadImportTemplate(MultipartFile file, String type, List<String> specNames, String firstLevelCataName, String secondLevelCataName, String threeLevelCataName) {
        List<Map<String, String>> data = new ArrayList<>();
        List<ArrayList<String>> readList = null;
        try {
            ReadExcelUtil readExcelUtil = new ReadExcelUtil();
            readList = readExcelUtil.readExcelOne(file, 2);
        } catch (Exception e) {
            log.error("读取excel异常" + e.getMessage());
            ZydExceptions.re("读取excel异常：" + e.getMessage());
        }
        ZydExceptions.re(readList == null || readList.size() <= 1, "上传数据为空");
        // 转换数据
        if (readList != null) {
            ArrayList<String> title = readList.get(0);
            if (specNames != null) {
                for (String specName : specNames) {
                    ZydExceptions.re(!title.contains("*" + specName), "上传文件格式有误");
                }
            }
            int offset = 0;
            if (type.equals("1")) {
                ZydExceptions.re(readList.size() - 1 > 2000, "最大支持导入2000行数据");
                ZydExceptions.re(!title.get(0).equals("*产品型号") || !title.get(1).equals("产品系列") || !title.get(2).contains("产品名称") || !title.get(3).equals("厂家物料号") || !title.get(4).equals("商品编码") || !title.get(5).contains("库存") || !title.get(6).contains("交货期") || !title.get(7).equals("重量"), "上传文件格式有误");
            } else {
                ZydExceptions.re(!title.get(0).equals("状态") || !title.get(2).equals("*产品型号") || !title.get(3).equals("产品系列") || !title.get(4).contains("产品名称") || !title.get(5).equals("厂家物料号") || !title.get(6).equals("商品编码") || !title.get(7).contains("库存") || !title.get(8).contains("交货期") || !title.get(9).equals("重量"), "上传文件格式有误");
                offset = 2;
            }
            Map<String, String> specNameUnitMaps = assembleSpecUnit(firstLevelCataName, secondLevelCataName, threeLevelCataName);
            Set<String> propNames = new HashSet<>();
            for (int i = 1; i < readList.size(); i++) {
                StringJoiner specUnitError = new StringJoiner("，");
                ArrayList<String> rows = readList.get(i);
                Map<String, String> dataRow = new HashMap<>();
                for (int j = 0; j < title.size(); j++) {
                    String col;
                    if (rows.size() <= j) {
                        col = "";
                    } else {
                        col = rows.get(j);
                    }
                    ZydExceptions.re(j == offset && StringUtils.isBlank(col), "产品型号不能为空，请检查");
                    ZydExceptions.re(StringUtils.isNotBlank(col) && col.startsWith("示例："), "示例数据导入需删除");
                    if (StringUtils.isNotBlank(title.get(j))) {
                        // 判断长度
                        if (j == offset) {
                            ZydExceptions.re(col.length() > 150, "第" + (i + 3) + "行产品型号不得超过150个字符");
                        }
                        if (j == 1 + offset) {
                            if (StringUtils.isNotBlank(col)) {
                                ZydExceptions.re(col.length() > 150, "第" + (i + 3) + "行" + title.get(j) + "不得超过150个字符");
                                propNames.add(col);
                            }
                        }
                        if (j == 2 + offset) {
                            ZydExceptions.re(StringUtils.isNotBlank(col) && col.length() > 100, "第" + (i + 3) + "行" + title.get(j) + "不得超过150个字符");
                        }
                        if (j == 3 + offset) {
                            ZydExceptions.re(StringUtils.isNotBlank(col) && col.length() > 150, "第" + (i + 3) + "行" + title.get(j) + "不得超过150个字符");
                        }
                        if (j == 4 + offset) {
                            ZydExceptions.re(StringUtils.isNotBlank(col) && col.length() > 50, "第" + (i + 3) + "行" + title.get(j) + "不得超过50个字符");
                        }
                        if (j == 6 + offset) {
                            ZydExceptions.re(StringUtils.isNotBlank(col) && col.length() > 10, "第" + (i + 3) + "行" + title.get(j) + "不得超过10个字符");
                        }
                        // 判断库存
                        if (j == 5 + offset) {
                            if (StringUtils.isNotBlank(col)) {
                                ZydExceptions.re(!col.equals("现货") && !col.equals("订货"), "第" + (i + 3) + "行库存只允许填写“现货”或者“订货”");
                            }
                        }
//                        // 判断重量
//                        if (j == 7 + offset) {
//                            if (StringUtils.isNotBlank(col)) {
//                                Integer num = null;
//                                try {
//                                    num = Integer.parseInt(col);
//                                } catch (Exception e) {
//                                    ZydExceptions.re(true, "第" + (i + 3) + "行" + title.get(j) + "有误");
//                                }
//                                if (num != null) {
//                                    ZydExceptions.re(num <= 0, "产品重量不能为0，请检查");
//                                }
//                            }
//                        }
                        // 判断单位
                        if (j == 8 + offset) {
                            if (StringUtils.isNotBlank(col)) {
                                ZydExceptions.re(StringUtils.isNotBlank(col) && col.length() > 10, "第" + (i + 3) + "行" + title.get(j) + "不得超过10个字符");
                            }
                        }
                        // 判断最小起订量
                        if (j == 9 + offset) {
                            if (StringUtils.isBlank(col)) {
                                col = "1";
                            } else {
                                Integer num = null;
                                try {
                                    num = Integer.parseInt(col);
                                } catch (Exception e) {
                                    ZydExceptions.re(true, "第" + (i + 3) + "行" + title.get(j) + "有误");
                                }
                                if (num != null) {
                                    ZydExceptions.re(num <= 0, "第" + (i + 3) + "行" + title.get(j) + "不能为0，请检查");
                                    ZydExceptions.re(num > 9999, "第" + (i + 3) + "行" + title.get(j) + "不能超过9999，请检查");
                                }
                            }
                        }
                        // 判断金额列类型
                        if (j >= 10 + offset && j <= 12 + offset) {
                            if (StringUtils.isNotBlank(col)) {
                                BigDecimal price = null;
                                try {
                                    price = new BigDecimal(col).setScale(4, RoundingMode.DOWN);
                                    col = price.toString();
                                } catch (Exception e) {
                                    ZydExceptions.re(true, "第" + (i + 3) + "行" + title.get(j) + "有误");
                                }
                                if (price != null) {
                                    ZydExceptions.re(price.compareTo(BigDecimal.ZERO) <= 0, "第" + (i + 3) + "行" + title.get(j) + "不得小于0");
                                    ZydExceptions.re(price.compareTo(new BigDecimal("9999999.9999")) > 0, "第" + (i + 3) + "行" + title.get(j) + "不得超过9999999.9999");
//                                    String[] cols = col.split("\\.");
//                                    ZydExceptions.re(cols.length == 2 && cols[1].length() > 2, "第" + (i + 3) + "行" + title.get(j) + "小数位不得超过2位");
                                }
                            }
                        }
                        // 判断规格（有单位的，单位是否正确）
                        String specNameTitle = "";
                        if (j >= 13 + offset) {
                            if (specNames != null && !specNames.isEmpty()) {
                                String specNameUnit = specNames.get(j - (13 + offset));
                                String specName = specNameUnitMaps.get(specNameUnit);
                                col = checkSpecUnit(specNameUnit, specName, col, specUnitError);
                                specNameTitle = specName;
                            }
                        }
                        if (title.get(j).contains("*")) {
                            if (StringUtils.isNotBlank(specNameTitle)) {
                                dataRow.put(specNameTitle.replace("*", ""), col);
                            } else {
                                dataRow.put(title.get(j).replace("*", ""), col);
                            }
                        } else {
                            dataRow.put(title.get(j), col);
                        }
                    }
                }
                dataRow.put("供货价折扣", "");
                dataRow.put("建议销售折扣", "");
                String price = dataRow.get("面价");
                String supplyPrice = dataRow.get("供货价");
                String suggestPrice = dataRow.get("建议销售价");
                if (StringUtils.isNotBlank(price)) {
                    dataRow.put("面价", formatBigDecimalData(price));
                }
                if (StringUtils.isNotBlank(supplyPrice)) {
                    if (StringUtils.isNotBlank(price)) {
                        ZydExceptions.re(new BigDecimal(price).compareTo(new BigDecimal(supplyPrice)) < 0, "第" + (i + 3) + "行供货价必须小于等于面价");
                    }
                    dataRow.put("供货价", formatBigDecimalData(supplyPrice));
                    if (StringUtils.isNotBlank(price) && new BigDecimal(price).compareTo(BigDecimal.ZERO) != 0) {
                        dataRow.put("供货价折扣", new BigDecimal(supplyPrice).divide(new BigDecimal(price), 4, RoundingMode.HALF_UP).toString());
                    }
                }
                if (StringUtils.isNotBlank(suggestPrice)) {
                    if (StringUtils.isNotBlank(price)) {
                        ZydExceptions.re(new BigDecimal(price).compareTo(new BigDecimal(suggestPrice)) < 0, "第" + (i + 3) + "行建议销售价必须小于等于面价");
                    }
                    dataRow.put("建议销售价", formatBigDecimalData(suggestPrice));
                    if (StringUtils.isNotBlank(price) && new BigDecimal(price).compareTo(BigDecimal.ZERO) != 0) {
                        dataRow.put("建议销售折扣", new BigDecimal(suggestPrice).divide(new BigDecimal(price), 4, RoundingMode.HALF_UP).toString());
                    }
                }
                // 计量单位有误时提示
                if (specUnitError.length() > 0) {
                    ZydExceptions.re(true, "计量单位有误，请按照规范重新填写。" + specUnitError + "，如有问题请联系业务对接人");
                }
                data.add(dataRow);
            }
            // 校验系列是否存在
            if (propNames.size() > 0) {
                Set<String> existPropNames = purchaseScmProductApplyMapper.checkIsExistCommonPropName(propNames);
                propNames.removeAll(existPropNames);
                if (propNames.size() > 0) {
                    for (String propName : propNames) {
                        ZydExceptions.re(true, "产品系列【" + propName + "】不存在，请联系运营专员");
                    }
                }
            }
        }
        return data;
    }

    /**
     * 供应商-相同型号搜索
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/16 11:51
     */
    public Page<PurchaseScmProductApplyVo.SupplierSameSearchVo> supplierSameSearch(PurchaseScmProductApplyDto.SupplierSameSearchDto dto) {
        Page<PurchaseScmProductApplyVo.SupplierSameSearchVo> page = new Page<>();
        int pageNum = BeanUtil.isEmpty(dto.getPageNum()) ? 1 : dto.getPageNum();
        int pageSize = BeanUtil.isEmpty(dto.getPageSize()) ? 12 : dto.getPageSize();
        List<PurchaseScmProductApplyVo.SupplierSameSearchVo> datas = new ArrayList<>();
        if (dto.getEntrance().equals("1")) {
            PurchaseScmProductApplyDto.SupplierSearchDto searchDto = new PurchaseScmProductApplyDto.SupplierSearchDto();
            BeanUtils.copyProperties(dto, searchDto);
            if (pageNum > 0 && pageSize > 0) {
                PageHelper.startPage(pageNum, pageSize);
            }
            if (searchDto.getAuditStatus() == null) {
                if (StringUtils.isBlank(dto.getIsAudit())) {
                    dto.setIsAudit("N");
                }
                if (dto.getIsAudit().equals("Y")) {
                    searchDto.setAuditStatus(4);
                } else {
                    // 除审核通过
                    searchDto.setAuditStatus(1235);
                }
            }
            List<PurchaseScmProductApplyVo.SupplierSearchVo> list = getSupplierApplySearch(searchDto);
            PageInfo<PurchaseScmProductApplyVo.SupplierSearchVo> pageInfo = new PageInfo<>(list);
            BeanUtils.copyProperties(pageInfo, page);
            for (PurchaseScmProductApplyVo.SupplierSearchVo l : list) {
                PurchaseScmProductApplyVo.SupplierSameSearchVo d = new PurchaseScmProductApplyVo.SupplierSameSearchVo();
                BeanUtils.copyProperties(l, d);
                d.setSupplyPrice(formatBigDecimalData(d.getSupplyPrice()));
                d.setPrice(formatBigDecimalData(d.getPrice()));
                d.setSuggestPrice(formatBigDecimalData(d.getSuggestPrice()));
                datas.add(d);
            }
        } else {
            PurchaseScmProductApplyDto.SupplierMySearchDto searchDto = new PurchaseScmProductApplyDto.SupplierMySearchDto();
            BeanUtils.copyProperties(dto, searchDto);
            if (pageNum > 0 && pageSize > 0) {
                PageHelper.startPage(pageNum, pageSize);
            }
            List<PurchaseScmProductApplyVo.SupplierMySearchVo> list = getSupplierMySearch(searchDto);
            PageInfo<PurchaseScmProductApplyVo.SupplierMySearchVo> pageInfo = new PageInfo<>(list);
            BeanUtils.copyProperties(pageInfo, page);
            for (PurchaseScmProductApplyVo.SupplierMySearchVo l : list) {
                PurchaseScmProductApplyVo.SupplierSameSearchVo d = new PurchaseScmProductApplyVo.SupplierSameSearchVo();
                BeanUtils.copyProperties(l, d);
                d.setSupplyPrice(formatBigDecimalData(d.getSupplyPrice()));
                d.setPrice(formatBigDecimalData(d.getPrice()));
                d.setSuggestPrice(formatBigDecimalData(d.getSuggestPrice()));
                datas.add(d);
            }
        }
        // 处理规格值
        for (PurchaseScmProductApplyVo.SupplierSameSearchVo data : datas) {
            StringBuilder sb = new StringBuilder();
            if (StringUtils.isNotBlank(data.getSpecData())) {
                JSONArray specData = JSONArray.parseArray(data.getSpecData());
                if (specData.size() > 0) {
                    for (int i = 0; i < specData.size(); i++) {
                        JSONObject spec = specData.getJSONObject(i);
                        if (spec != null) {
                            if (spec.get("specName") != null && spec.get("specValue") != null) {
                                sb.append(spec.get("specValue")).append("|");
                            }
                        }
                    }
                    if (sb.toString().length() > 0) {
                        sb.deleteCharAt(sb.length() - 1);
                    }
                }
            }
            data.setSpecValueString(sb.toString());
        }
        page.setList(datas);
        return page;
    }

    /**
     * 供应商-相同型号搜索选择器
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/17 14:16
     */
    public PurchaseScmProductApplyVo.SupplierSameSelectorVo supplierSameSelector(PurchaseScmProductApplyDto.SupplierSameSearchDto dto) {
        PurchaseScmProductApplyVo.SupplierSameSelectorVo vo = new PurchaseScmProductApplyVo.SupplierSameSelectorVo();
        List<PurchaseScmProductApplyVo.SpecVo> list;
        String supplierId = (String) ContextHandler.get("supplierId");
        String corpCode = ContextHandler.getCorpCode();
        try {
            if (dto.getEntrance().equals("1")) {
                PurchaseScmProductApplyDto.SupplierSearchDto searchDto = new PurchaseScmProductApplyDto.SupplierSearchDto();
                BeanUtils.copyProperties(dto, searchDto);
                if (searchDto.getAuditStatus() == null) {
                    if (StringUtils.isBlank(dto.getIsAudit())) {
                        dto.setIsAudit("N");
                    }
                    if (dto.getIsAudit().equals("Y")) {
                        searchDto.setAuditStatus(4);
                    } else {
                        // 除审核通过
                        searchDto.setAuditStatus(1235);
                    }
                }
                list = purchaseScmProductApplyMapper.supplierSelectSpec(searchDto, supplierId, corpCode);
            } else {
                PurchaseScmProductApplyDto.SupplierMySearchDto searchDto = new PurchaseScmProductApplyDto.SupplierMySearchDto();
                BeanUtils.copyProperties(dto, searchDto);
                list = purchaseScmProductApplyMapper.supplierMySelectSpec(searchDto, supplierId, corpCode);
            }
        } catch (Exception e) {
            list = new ArrayList<>();
        }
        List<PurchaseScmProductApplyVo.SupplierSameSelectorListVo> specs = new ArrayList<>();
        if (list.size() > 0) {
            Map<String, List<PurchaseScmProductApplyVo.SpecVo>> specMap = list.stream().filter(s -> StringUtils.isNotBlank(s.getSpecName())).collect(Collectors.groupingBy(PurchaseScmProductApplyVo.SpecVo::getSpecName));
            for (String specName : specMap.keySet()) {
                List<PurchaseScmProductApplyVo.SpecVo> specVos = specMap.get(specName);
                PurchaseScmProductApplyVo.SupplierSameSelectorListVo spec = new PurchaseScmProductApplyVo.SupplierSameSelectorListVo();
                spec.setSpecName(specName);
                List<PurchaseScmProductApplyVo.SupplierSameSelectorSpecValueVo> specValues = new ArrayList<>();
                for (PurchaseScmProductApplyVo.SpecVo specVo : specVos) {
                    PurchaseScmProductApplyVo.SupplierSameSelectorSpecValueVo specValue = new PurchaseScmProductApplyVo.SupplierSameSelectorSpecValueVo();
                    if (StringUtils.isBlank(specVo.getSpecValue())) {
                        continue;
                    }
                    specValue.setSpecValue(specVo.getSpecValue());
                    specValue.setSelected(false);
                    // 判断是否选中
                    for (PurchaseScmProductApplyDto.SpecDto specNameValue : dto.getSpecNameValues()) {
                        if (specNameValue.getSpecName().equals(specName) && specNameValue.getSpecValue().equals(specVo.getSpecValue())) {
                            specValue.setSelected(true);
                            break;
                        }
                    }
                    specValues.add(specValue);
                }
                specValues = specValues.stream().sorted(Comparator.comparing(PurchaseScmProductApplyVo.SupplierSameSelectorSpecValueVo::getSpecValue)).collect(Collectors.toList());
                spec.setSpecValues(specValues);
                specs.add(spec);
            }
            specs = specs.stream().sorted(Comparator.comparing(PurchaseScmProductApplyVo.SupplierSameSelectorListVo::getSpecName)).collect(Collectors.toList());
        }
        vo.setSpecs(specs);
        return vo;
    }

    /**
     * 供应商-批量撤销
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 13:01
     */
    @Transactional(rollbackFor = Exception.class)
    public JsonResult supplierCancel(PurchaseScmProductApplyDto.SupplierCancelDto dto) {
        String userId = ContextHandler.getUserId();
        List<PurchaseScmProductApplyDto.SupplierPublishCancelDto> cancels = new ArrayList<>();
        if (!CollectionUtils.isEmpty(dto.getIds()) && dto.getIds().contains("all")) {
            dto.setIds(null);
        }
        if (!CollectionUtils.isEmpty(dto.getIds())) {
            // 按勾选更新
            for (String id : dto.getIds()) {
                PurchaseScmProductApplyDto.SupplierPublishCancelDto cancel = new PurchaseScmProductApplyDto.SupplierPublishCancelDto();
                cancel.setId(id);
                cancel.setAuditRemark(dto.getAuditRemark());
                cancels.add(cancel);
            }
        } else {
            // 按满足条件下更新
            List<PurchaseScmProductApplyVo.SupplierSearchVo> list = getSupplierApplySearch(dto);
            for (PurchaseScmProductApplyVo.SupplierSearchVo l : list) {
                PurchaseScmProductApplyDto.SupplierPublishCancelDto cancel = new PurchaseScmProductApplyDto.SupplierPublishCancelDto();
                cancel.setId(l.getId());
                cancel.setAuditRemark(dto.getAuditRemark());
                cancels.add(cancel);
            }
        }
        commonCancel(cancels, userId, null);
        return new JsonResult(true, "");
    }

    /**
     * 供应商-批量删除
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 13:01
     */
    @Transactional(rollbackFor = Exception.class)
    public JsonResult supplierDelete(PurchaseScmProductApplyDto.SupplierSearchDto dto) {
        if (!CollectionUtils.isEmpty(dto.getIds()) && dto.getIds().contains("all")) {
            dto.setIds(null);
        }
        if (!CollectionUtils.isEmpty(dto.getIds())) {
            // 按勾选删除
            for (String id : dto.getIds()) {
                PurchaseScmProductApply detail = getDetail(id);
                if (detail != null) {
                    if (detail.getAuditStatus() == 0 || detail.getAuditStatus() == 5) {
                        delete(id);
                    } else {
                        if (dto.getIds().size() > 1) {
                            ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                        } else {
                            ZydExceptions.re(true, "商品状态已变更，请检查");
                        }
                    }
                }
            }
        } else {
            // 按满足条件下删除
            List<PurchaseScmProductApplyVo.SupplierSearchVo> list = getSupplierApplySearch(dto);
            for (PurchaseScmProductApplyVo.SupplierSearchVo l : list) {
                if (l.getAuditStatus() == 0 || l.getAuditStatus() == 5) {
                    delete(l.getId());
                } else {
                    ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                }
            }
        }
        return new JsonResult(true, "");
    }

    /**
     * 供应商-商品申请列表导出
     *
     * @param request
     * @param response
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 13:56
     */
    public void supplierApplyExport(HttpServletRequest request, HttpServletResponse response, PurchaseScmProductApplyDto.SupplierSearchDto dto) {
        if (!CollectionUtils.isEmpty(dto.getIds()) && dto.getIds().contains("all")) {
            dto.setIds(null);
        }
        List<PurchaseScmProductApplyVo.SupplierSearchVo> list = getSupplierApplySearch(dto);
        try {
            // 处理导出标题
            List<String> titleFields = new LinkedList<>();
            List<String> titleTexts = new LinkedList<>();
            if (!CollectionUtils.isEmpty(dto.getExportTitleFields()) && !CollectionUtils.isEmpty(dto.getExportTitleTexts())) {
                titleFields.addAll(dto.getExportTitleFields());
                titleTexts.addAll(dto.getExportTitleTexts());
            } else {
                titleFields.addAll(Arrays.asList("applyNo", "auditStatus", "auditType", "materialName", "productType", "skuCode", "productCode", "stock", "deliveryDate", "price", "supplyPrice", "suggestPrice", "brandName", "propName", "firstLevelCataName", "specName", "specValue", "productPicName", "productContentPicName", "productSampleName", "weight", "unit", "minimunRequire", "createdAt", "updatedAt", "auditTimeMerge"));
                titleTexts.addAll(Arrays.asList("申请编号", "状态", "申请类型", "产品名称", "产品型号", "厂家物料号", "商品编码", "库存", "交货期", "面价", "供货价", "建议销售价", "产品品牌", "产品系列", "分类", "规格名", "规格值", "产品主图", "产品详情图", "产品样本", "重量", "单位", "最小起订量", "申请时间", "修改时间", "审核时间"));
            }
            // 处理分类
            if (titleFields.contains("firstLevelCataName")) {
                int index = titleFields.indexOf("firstLevelCataName");
                titleTexts.set(index, "一级分类");
                titleFields.add(index + 1, "secondLevelCataName");
                titleTexts.add(index + 1, "二级分类");
                titleFields.add(index + 2, "threeLevelCataName");
                titleTexts.add(index + 2, "三级分类");
            }
            List<List<MultiTitleExportExcelUtil.Title>> titleList = new ArrayList<>();
            List<MultiTitleExportExcelUtil.Title> titles = new ArrayList<>();
            for (String titleText : titleTexts) {
                titles.add(new MultiTitleExportExcelUtil.Title(titleText, 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            }
            titleList.add(titles);
            // 处理导出数据
            List<List<Object>> objects = new ArrayList<>();
            for (PurchaseScmProductApplyVo.SupplierSearchVo l : list) {
                PurchaseScmProductApplyVo.SupplierExportVo eL = new PurchaseScmProductApplyVo.SupplierExportVo();
                BeanUtils.copyProperties(l, eL);
                if (l.getAuditStatus() == 0) {
                    eL.setAuditStatus("待提交");
                } else if (l.getAuditStatus() == 1) {
                    eL.setAuditStatus("待分部审核");
                } else if (l.getAuditStatus() == 2) {
                    eL.setAuditStatus("待资料审核");
                } else if (l.getAuditStatus() == 3) {
                    eL.setAuditStatus("待价格审核");
                } else if (l.getAuditStatus() == 4) {
                    eL.setAuditStatus("通过");
                } else if (l.getAuditStatus() == 5) {
                    eL.setAuditStatus("驳回");
                }
                if (l.getAuditType() == 1) {
                    eL.setAuditType("商品新增");
                } else if (l.getAuditType() == 2) {
                    eL.setAuditType("资料修改");

                } else if (l.getAuditType() == 3) {
                    eL.setAuditType("价格修改");

                } else if (l.getAuditType() == 4) {
                    eL.setAuditType("资料价格修改");

                } else if (l.getAuditType() == 5) {
                    eL.setAuditType("图片修改");
                }
                if (l.getStock() == 1) {
                    eL.setStock("现货");
                } else {
                    eL.setStock("订货");
                }
                // 处理价格
                eL.setSupplyPrice(formatBigDecimalData(l.getSupplyPrice()));
                eL.setPrice(formatBigDecimalData(l.getPrice()));
                eL.setSuggestPrice(formatBigDecimalData(l.getSuggestPrice()));
                // 处理图片、视频等
                eL.setProductPicName(changeToFullUrl(eL.getProductVideoName(), eL.getProductPicName()));
                eL.setProductContentPicName(changeToFullUrl(eL.getProductContentPicName()));
                eL.setProductSampleName(changeToFullUrl(eL.getProductSampleName()));
                // 处理规格
                Map<String, String> newSpec = handleSpecToTwoColumn(l.getSpecData());
                eL.setSpecName(newSpec.get("specName"));
                eL.setSpecValue(newSpec.get("specValue"));
                // 处理时间
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                if (l.getCreatedAt() != null) {
                    eL.setCreatedAt(l.getCreatedAt().format(formatter));
                }
                if (l.getUpdatedAt() != null) {
                    eL.setUpdatedAt(l.getUpdatedAt().format(formatter));
                }
                if (l.getAuditTime3() != null) {
                    eL.setAuditTimeMerge(l.getAuditTime3().format(formatter));
                } else if (l.getAuditTime2() != null) {
                    eL.setAuditTimeMerge(l.getAuditTime2().format(formatter));
                } else if (l.getAuditTime1() != null) {
                    eL.setAuditTimeMerge(l.getAuditTime1().format(formatter));
                }
                // 添加到表格
                List<Object> object = new ArrayList<>();
                for (String titleField : titleFields) {
                    object.add(getFieldValue(eL, titleField));
                }
                objects.add(object);
            }
            new MultiTitleExportExcelUtil("商品明细", titleList)
                    .setDataListObject(objects)
                    .write(request, response, "商品审核明细导出（" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + "）.xlsx");
        } catch (Exception e) {
            log.error("商品申请excel导出异常：{}", e.getMessage(), e);
            ZydExceptions.re(true, "商品申请导出失败");
        }
    }

    /**
     * 供应商-我的商品搜索
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 16:21
     */
    public Page<PurchaseScmProductApplyVo.SupplierMySearchVo> supplierMySearch(PurchaseScmProductApplyDto.SupplierMySearchDto dto) {
        Page<PurchaseScmProductApplyVo.SupplierMySearchVo> page = new Page<>();
        page.setPageNum(BeanUtil.isEmpty(dto.getPageNum()) ? 1 : dto.getPageNum());
        page.setPageSize(BeanUtil.isEmpty(dto.getPageSize()) ? 12 : dto.getPageSize());
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<PurchaseScmProductApplyVo.SupplierMySearchVo> list = getSupplierMySearch(dto);
        for (PurchaseScmProductApplyVo.SupplierMySearchVo l : list) {
            l.setSupplyPrice(formatBigDecimalData(l.getSupplyPrice()));
            l.setPrice(formatBigDecimalData(l.getPrice()));
            l.setSuggestPrice(formatBigDecimalData(l.getSuggestPrice()));
            Map<String, String> newSpec = handleSpecToTwoColumn(l.getSpecData());
            l.setSpecName(newSpec.get("specName"));
            l.setSpecValue(newSpec.get("specValue"));
        }
        return new Page<>(list);
    }

    /**
     * 供应商-我的商品搜索角标
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 16:31
     */
    public PurchaseScmProductApplyVo.SupplierMySearchCountVo supplierMySearchCount(PurchaseScmProductApplyDto.SupplierMySearchDto dto) {
        String supplierId = (String) ContextHandler.get("supplierId");
        String corpCode = ContextHandler.getCorpCode();
        return purchaseScmProductApplyMapper.supplierMySearchCount(dto, supplierId, corpCode);
    }

    /**
     * 供应商-我的商品上下架
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 16:37
     */
    @Transactional(rollbackFor = Exception.class)
    public JsonResult supplierMyOnsale(PurchaseScmProductApplyDto.SupplierMyOnsaleDto dto) {
        List<PurchaseScmProductApply> details = new ArrayList<>();
        if (!CollectionUtils.isEmpty(dto.getIds()) && dto.getIds().contains("all")) {
            dto.setIds(null);
        }
        if (!CollectionUtils.isEmpty(dto.getIds())) {
            // 按勾选更新    
            for (String id : dto.getIds()) {
                PurchaseScmProductApply detail = getDetail(id);
                if (detail != null) {
                    if (!detail.getIsOnsale().equals(dto.getEditOnsale())) {
                        detail.setIsOnsale(dto.getEditOnsale());
                        if (dto.getEditOnsale().equals("Y")) {
                            detail.setOffsaleType(null);
                            detail.setOffsaleReason("");
                        } else {
                            detail.setOffsaleType(2);
                            detail.setOffsaleReason(dto.getOffsaleReason());
                        }
                        details.add(detail);
                    } else {
                        if (dto.getIds().size() > 1) {
                            ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                        } else {
                            ZydExceptions.re(true, "商品状态已变更，请检查");
                        }
                    }
                }
            }
        } else {
            // 按满足条件下更新
            List<PurchaseScmProductApplyVo.SupplierMySearchVo> list = getSupplierMySearch(dto);
            if (list.size() > 0) {
                // 根据id组获取完整数据
                Set<String> ids = list.stream().map(PurchaseScmProductApplyVo.SupplierMySearchVo::getId).collect(Collectors.toSet());
                Example example = new Example(entityClass);
                example.orderBy(PurchaseScmProductApply.CREATED_AT).desc();
                Example.Criteria criteria = example.createCriteria();
                criteria.andIn(PurchaseScmProductApply.ID, ids);
                List<PurchaseScmProductApply> detailList = purchaseScmProductApplyMapper.selectByExample(example);
                for (PurchaseScmProductApply detail : detailList) {
                    if (!detail.getIsOnsale().equals(dto.getEditOnsale())) {
                        detail.setIsOnsale(dto.getEditOnsale());
                        if (dto.getEditOnsale().equals("Y")) {
                            detail.setOffsaleType(null);
                            detail.setOffsaleReason("");
                        } else {
                            detail.setOffsaleType(2);
                            detail.setOffsaleReason(dto.getOffsaleReason());
                        }
                        details.add(detail);
                    } else {
                        ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                    }
                }
            }
        }
        if (details.size() > 0) {
            // 获取公司信息
            Map<Integer, String> companyMap = getCompanyMap(details);
            for (PurchaseScmProductApply detail : details) {
                // 产品同步至公海
                PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
                BeanUtils.copyProperties(detail, purchaseProductSync);
                purchaseProductSync.setProductVedioName(detail.getProductVideoName());
                purchaseProductSync.setSample(detail.getProductSampleName());
                purchaseProductSync.setProductContent(detail.getProductContentPicName());
                purchaseProductSync.setIsOnsale(dto.getEditOnsale());
                purchaseProductSync.setSubCompany(companyMap.get(detail.getCompanyId()));
                purchaseProductSync.setSpecData(handleSyncCommonSpec(detail.getSpecData()));
                purchaseProductSync.setReason(detail.getOffsaleReason());
                purchaseProductSync.setPurchasePrice(detail.getDistributePrice());
                purchaseProductSync.setPurchaseDiscount(detail.getDistributeDiscount());
                purchaseProductSync.setPurchaseCalcWay(detail.getDistributeCalcWay());
                purchaseProductSync.setAuditTime(detail.getAuditTime3());
                JsonResult<Long> jsonResult = publicProductFeignClient.purchaseProductSync(purchaseProductSync);
                if (null != jsonResult && BooleanUtils.isTrue(jsonResult.isSuccess())) {
                    // 公海更新成功才更新申请表状态
                    purchaseScmProductApplyMapper.updateOnsale(detail);
                }
            }
        }
        return new JsonResult(true, "");
    }

    /**
     * 供应商-我的商品导出
     *
     * @param request
     * @param response
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 17:21
     */
    public void supplierMyExport(HttpServletRequest request, HttpServletResponse response, PurchaseScmProductApplyDto.SupplierMySearchDto dto) {
        if (!CollectionUtils.isEmpty(dto.getIds()) && dto.getIds().contains("all")) {
            dto.setIds(null);
        }
        List<PurchaseScmProductApplyVo.SupplierMySearchVo> list = getSupplierMySearch(dto);
        try {
            // 处理导出标题
            List<String> titleFields = new LinkedList<>();
            List<String> titleTexts = new LinkedList<>();
            if (!CollectionUtils.isEmpty(dto.getExportTitleFields()) && !CollectionUtils.isEmpty(dto.getExportTitleTexts())) {
                titleFields.addAll(dto.getExportTitleFields());
                titleTexts.addAll(dto.getExportTitleTexts());
            } else {
                titleFields.addAll(Arrays.asList("productId", "isOnsale", "materialName", "productType", "skuCode", "productCode", "stock", "deliveryDate", "price", "supplyPrice", "suggestPrice", "brandName", "propName", "firstLevelCataName", "specName", "specValue", "productPicName", "productContentPicName", "productSampleName", "weight", "unit", "minimunRequire", "createdAt", "updatedAt"));
                titleTexts.addAll(Arrays.asList("商品ID", "状态", "产品名称", "产品型号", "厂家物料号", "商品编码", "库存", "交货期", "面价", "供货价", "建议销售价", "产品品牌", "产品系列", "分类", "规格名", "规格值", "产品主图", "产品详情图", "产品样本", "重量", "单位", "最小起订量", "申请时间", "最后修改时间"));
            }
            // 处理分类
            if (titleFields.contains("firstLevelCataName")) {
                int index = titleFields.indexOf("firstLevelCataName");
                titleTexts.set(index, "一级分类");
                titleFields.add(index + 1, "secondLevelCataName");
                titleTexts.add(index + 1, "二级分类");
                titleFields.add(index + 2, "threeLevelCataName");
                titleTexts.add(index + 2, "三级分类");
            }
            List<List<MultiTitleExportExcelUtil.Title>> titleList = new ArrayList<>();
            List<MultiTitleExportExcelUtil.Title> titles = new ArrayList<>();
            for (String titleText : titleTexts) {
                titles.add(new MultiTitleExportExcelUtil.Title(titleText, 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            }
            titleList.add(titles);
            // 处理导出数据
            List<List<Object>> objects = new ArrayList<>();
            for (PurchaseScmProductApplyVo.SupplierMySearchVo l : list) {
                PurchaseScmProductApplyVo.SupplierMyExportVo eL = new PurchaseScmProductApplyVo.SupplierMyExportVo();
                BeanUtils.copyProperties(l, eL);
                if (l.getIsOnsale().equals("Y")) {
                    eL.setIsOnsale("上架中");
                } else {
                    eL.setIsOnsale("已下架");
                }
                if (l.getStock() == 1) {
                    eL.setStock("现货");
                } else {
                    eL.setStock("订货");
                }
                // 处理价格
                eL.setSupplyPrice(formatBigDecimalData(l.getSupplyPrice()));
                eL.setPrice(formatBigDecimalData(l.getPrice()));
                eL.setSuggestPrice(formatBigDecimalData(l.getSuggestPrice()));
                // 处理图片、视频等
                eL.setProductPicName(changeToFullUrl(eL.getProductVideoName(), eL.getProductPicName()));
                eL.setProductContentPicName(changeToFullUrl(eL.getProductContentPicName()));
                eL.setProductSampleName(changeToFullUrl(eL.getProductSampleName()));
                // 处理规格
                Map<String, String> newSpec = handleSpecToTwoColumn(l.getSpecData());
                eL.setSpecName(newSpec.get("specName"));
                eL.setSpecValue(newSpec.get("specValue"));
                // 处理时间
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                if (l.getCreatedAt() != null) {
                    eL.setCreatedAt(l.getCreatedAt().format(formatter));
                }
                if (l.getUpdatedAt() != null) {
                    eL.setUpdatedAt(l.getUpdatedAt().format(formatter));
                }
                // 添加到表格
                List<Object> object = new ArrayList<>();
                for (String titleField : titleFields) {
                    object.add(getFieldValue(eL, titleField));
                }
                objects.add(object);

            }
            new MultiTitleExportExcelUtil("商品明细", titleList)
                    .setDataListObject(objects)
                    .write(request, response, "商品明细导出（" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + "）.xlsx");
        } catch (Exception e) {
            log.error("我的商品excel导出异常：{}", e.getMessage(), e);
            ZydExceptions.re(true, "我的商品导出失败");
        }
    }

    /**
     * 供应商-批量发布
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/17 15:01
     */
    @Transactional(rollbackFor = Exception.class)
    public JsonResult supplierPublish(PurchaseScmProductApplyDto.SupplierPublishDto dto) {
        List<String> productTypes = dto.getList().stream().map(PurchaseScmProductApplyDto.SupplierPublishListDto::getProductType).collect(Collectors.toList());
        ZydExceptions.re(productTypes.stream().distinct().count() != productTypes.size(), "产品型号存在重复提交，申请失败");

        if (StringUtils.isBlank(dto.getEntrance())) {
            dto.setEntrance("1");
        }
        if (StringUtils.isBlank(dto.getIsDraft())) {
            dto.setIsDraft("N");
        }
        // 如果是待提交，数据需要先删除，再新增
        Map<String, Long> productTypeNoMap = null;
        if (dto.getIsDraft().equals("Y")) {
            productTypeNoMap = new HashMap<>();
            List<String> ids = dto.getList().stream().map(PurchaseScmProductApplyDto.SupplierPublishListDto::getId).collect(Collectors.toList());
            for (String id : ids) {
                PurchaseScmProductApply detail = getDetail(id);
                if (detail != null) {
                    productTypeNoMap.put(detail.getProductType(), detail.getApplyNo());
                    if (detail.getAuditStatus() == 0) {
                        delete(id);
                    } else {
                        ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                    }
                }
            }
        }
        String supplierId = (String) ContextHandler.get("supplierId");
        String companyId = (String) ContextHandler.get("companyId");
        String userId = ContextHandler.getUserId();
        Set<String> deliveryDates = new HashSet<>();
        List<PurchaseScmProductApply> applies = new ArrayList<>();
        List<PurchaseScmProductApplyChangeRecord> applyChangeRecords = new ArrayList<>();
        List<PurchaseDeliveryDate> dates = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        for (PurchaseScmProductApplyDto.SupplierPublishListDto l : dto.getList()) {
            ZydExceptions.re(StringUtils.isBlank(l.getProductPicName()) && StringUtils.isBlank(l.getProductVideoName()), "请上传产品图片或视频");
            ZydExceptions.re(l.getPrice() != null && l.getSupplyPrice() != null && l.getPrice().compareTo(l.getSupplyPrice()) < 0, "供货价必须小于等于面价");
            ZydExceptions.re(l.getPrice() != null && l.getSuggestPrice() != null && l.getPrice().compareTo(l.getSuggestPrice()) < 0, "建议销售价必须小于等于面价");

            // 判断规格（有单位的，单位是否正确）
            StringJoiner specUnitError = new StringJoiner("，");
            JSONArray newSpecDatas = new JSONArray();
            Map<String, String> specNameUnitMaps = assembleSpecUnit(l.getFirstLevelCataName(), l.getSecondLevelCataName(), l.getThreeLevelCataName());
            Map<String, String> specMap = getSpecValue(l.getSpecData());
            for (String specNameUnit : specNameUnitMaps.keySet()) {
                String specName = specNameUnitMaps.get(specNameUnit);
                String specValue = checkSpecUnit(specNameUnit, specName, specMap.get(specName), specUnitError);
                JSONObject newSpecData = new JSONObject();
                newSpecData.put("specName", specName);
                newSpecData.put("specValue", specValue);
                newSpecDatas.add(newSpecData);
            }
            l.setSpecData(newSpecDatas.toJSONString());
            if (specUnitError.length() > 0) {
                ZydExceptions.re(true, "计量单位有误，请按照规范重新填写。" + specUnitError + "，如有问题请联系业务对接人");
            }

            if (l.getMinimunRequire() == null) {
                l.setMinimunRequire(1);
            }
            // 重量去掉g
            if (StringUtils.isNotBlank(l.getWeight())) {
                l.setWeight(l.getWeight().replaceAll("g", ""));
            }
            // 我的商品的新增，获取旧数据
            PurchaseScmProductApply applyOld = null;
            if (dto.getEntrance().equals("2")) {
                if (StringUtils.isNotBlank(l.getId())) {
                    applyOld = getDetail(l.getId());
                }
            }
            // 处理申请数据
            l.setProductType(l.getProductType().trim());
            PurchaseScmProductApply applyNew = handleApply(applyOld, l, dto.getEntrance());
            if (applyNew == null) {
                continue;
            }
            Example example = new Example(entityClass);
            example.orderBy(PurchaseScmProductApply.CREATED_AT).desc();
            Example.Criteria criteria = example.createCriteria();
            criteria.andEqualTo(PurchaseScmProductApply.SUPPLIER_ID, supplierId);
            criteria.andEqualTo(PurchaseScmProductApply.PRODUCT_TYPE, l.getProductType());
            if (dto.getEntrance().equals("2")) {
                criteria.andNotEqualTo(PurchaseScmProductApply.AUDIT_STATUS, 4);
            }
            ZydExceptions.re(purchaseScmProductApplyMapper.selectCountByExample(example) > 0, "产品型号：" + l.getProductType() + "已存在，申请失败");

            deliveryDates.add(l.getDeliveryDate());

            // 处理图片和视频
            handleImageVideo(applyNew);

            applyNew.setId(IDUtils.getUUID19());
            if (productTypeNoMap != null && productTypeNoMap.get(applyNew.getProductType()) != null) {
                applyNew.setApplyNo(productTypeNoMap.get(applyNew.getProductType()));
            } else {
                applyNew.setApplyNo(getMaxApplyNo());
            }
            applyNew.setApplySource("publish");
            applyNew.setSupplierId(supplierId);
            if (StringUtils.isNotBlank(companyId)) {
                applyNew.setCompanyId(Integer.parseInt(companyId));
            }
            if (!isScm(null)) {
                applyNew.setIsSupply("Y");
                applyNew.setDistributePrice(applyNew.getSupplyPrice());
                applyNew.setDistributeDiscount(BigDecimal.ONE);
                applyNew.setDistributeCalcWay("*");
            } else {
                applyNew.setIsSupply("N");
            }
            applyNew.setCreatedBy(userId);
            applyNew.setCreatedAt(now);
            applyNew.setUpdatedBy(userId);
            applyNew.setUpdatedAt(now);
            applyNew.setCorpCode(ContextHandler.getCorpCode());
            applies.add(applyNew);
            // 添加变更记录
            List<PurchaseScmProductApplyChangeRecord> changeRecords = applyNew.getChangeRecords();
            if (!CollectionUtils.isEmpty(changeRecords)) {
                for (PurchaseScmProductApplyChangeRecord changeRecord : changeRecords) {
                    changeRecord.setId(IDUtils.getUUID19());
                    changeRecord.setApplyNo(applyNew.getApplyNo());
                    changeRecord.setCreatedBy(userId);
                    changeRecord.setCreatedAt(now);
                    changeRecord.setUpdatedBy(userId);
                    changeRecord.setUpdatedAt(now);
                }
                applyChangeRecords.addAll(changeRecords);
            }
        }
        for (String deliveryDate : deliveryDates) {
            if (purchaseDeliveryDateMapper.selectExist(supplierId, deliveryDate) == 0) {
                PurchaseDeliveryDate date = new PurchaseDeliveryDate();
                date.setSupplierId(supplierId);
                date.setDeliveryDate(deliveryDate);
                date.setId(getMaxDeliveryId());
                date.setCreatedBy(userId);
                date.setCreatedAt(now);
                date.setUpdatedBy(userId);
                date.setUpdatedAt(now);
                dates.add(date);
            }
        }
        // 处理数据
        ZydExceptions.re(applies.size() == 0 && CollectionUtils.isEmpty(dto.getCancels()) && CollectionUtils.isEmpty(dto.getDeleteIds()), "提交的清单未作任何修改，申请失败");
        if (!CollectionUtils.isEmpty(dto.getCancels())) {
            // 撤销数据
            commonCancel(dto.getCancels(), userId, null);
        }
        if (!CollectionUtils.isEmpty(dto.getDeleteIds())) {
            // 删除数据
            for (String id : dto.getDeleteIds()) {
                PurchaseScmProductApply detail = getDetail(id);
                if (detail != null) {
                    if (detail.getAuditStatus() != 4) {
                        delete(id);
                    } else {
                        ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                    }
                }
            }
        }
        if (applies.size() > 0) {
            this.batchInsert(applies);
        }
        if (dates.size() > 0) {
            for (PurchaseDeliveryDate date : dates) {
                purchaseDeliveryDateMapper.insert(date);
            }
        }
        if (applyChangeRecords.size() > 0) {
            for (PurchaseScmProductApplyChangeRecord applyChangeRecord : applyChangeRecords) {
                purchaseScmProductApplyChangeRecordMapper.insert(applyChangeRecord);
            }
        }
        // 添加审核统计
        addAuditSum(applies, applyChangeRecords, now, userId, (String) ContextHandler.get("name"), null);
        // 发送审核消息
        sendAuditMsg(applies, now);
        return new JsonResult(true, "");
    }

    /**
     * 供应商-批量发布待提交
     *
     * @param dto
     * @Author loine
     * @Date 2026/2/25 10:28
     */
    @Transactional(rollbackFor = Exception.class)
    public JsonResult supplierPublishDraft(PurchaseScmProductApplyDto.SupplierPublishDraftDto dto) {
        List<String> productTypes = dto.getList().stream().map(PurchaseScmProductApplyDto.SupplierPublishListDto::getProductType).filter(StringUtils::isNotBlank).collect(Collectors.toList());
        ZydExceptions.re(productTypes.isEmpty(), "产品型号不能为空");
        ZydExceptions.re(productTypes.stream().distinct().count() != productTypes.size(), "产品型号存在重复提交，保存失败");

        String supplierId = (String) ContextHandler.get("supplierId");
        String companyId = (String) ContextHandler.get("companyId");
        String userId = ContextHandler.getUserId();
        Set<String> deliveryDates = new HashSet<>();
        List<PurchaseScmProductApply> applies = new ArrayList<>();
        List<PurchaseDeliveryDate> dates = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        for (PurchaseScmProductApplyDto.SupplierPublishListDto l : dto.getList()) {
               if (l.getMinimunRequire() == null) {
                l.setMinimunRequire(1);
            }
            // 重量去掉g
            if (StringUtils.isNotBlank(l.getWeight())) {
                l.setWeight(l.getWeight().replaceAll("g", ""));
            }
            // 处理申请数据
            l.setProductType(l.getProductType().trim());
            PurchaseScmProductApply applyNew = handleApply(null, l, "1");
            if (applyNew == null) {
                continue;
            }
            deliveryDates.add(l.getDeliveryDate());

            // 处理图片和视频
            handleImageVideo(applyNew);

            applyNew.setId(IDUtils.getUUID19());
            applyNew.setApplyNo(getMaxApplyNo());
            applyNew.setAuditStatus(0);// 待提交固定值
            applyNew.setAuditType(1);// 待提交固定值
            applyNew.setApplySource("publish");
            applyNew.setSupplierId(supplierId);
            if (StringUtils.isNotBlank(companyId)) {
                applyNew.setCompanyId(Integer.parseInt(companyId));
            }
            if (!isScm(null)) {
                applyNew.setIsSupply("Y");
                applyNew.setDistributePrice(applyNew.getSupplyPrice());
                applyNew.setDistributeDiscount(BigDecimal.ONE);
                applyNew.setDistributeCalcWay("*");
            } else {
                applyNew.setIsSupply("N");
            }
            applyNew.setCreatedBy(userId);
            applyNew.setCreatedAt(now);
            applyNew.setUpdatedBy(userId);
            applyNew.setUpdatedAt(now);
            applyNew.setCorpCode(ContextHandler.getCorpCode());
            applies.add(applyNew);
        }
        for (String deliveryDate : deliveryDates) {
            if (purchaseDeliveryDateMapper.selectExist(supplierId, deliveryDate) == 0) {
                PurchaseDeliveryDate date = new PurchaseDeliveryDate();
                date.setSupplierId(supplierId);
                date.setDeliveryDate(deliveryDate);
                date.setId(getMaxDeliveryId());
                date.setCreatedBy(userId);
                date.setCreatedAt(now);
                date.setUpdatedBy(userId);
                date.setUpdatedAt(now);
                dates.add(date);
            }
        }
        // 处理数据
        if (!CollectionUtils.isEmpty(dto.getDeleteIds())) {
            // 删除数据
            for (String id : dto.getDeleteIds()) {
                PurchaseScmProductApply detail = getDetail(id);
                if (detail != null) {
                    if (detail.getAuditStatus() != 4) {
                        delete(id);
                    } else {
                        ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                    }
                }
            }
        }
        if (!applies.isEmpty()) {
            this.batchInsert(applies);
        }
        if (!dates.isEmpty()) {
            for (PurchaseDeliveryDate date : dates) {
                purchaseDeliveryDateMapper.insert(date);
            }
        }
        return new JsonResult(true, "");
    }

    /**
     * 供应商-批量编辑修改
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/18 9:30
     */
    @Transactional(rollbackFor = Exception.class)
    public JsonResult supplierEdit(PurchaseScmProductApplyDto.SupplierPublishDto dto) {
        List<String> productTypes = dto.getList().stream().map(PurchaseScmProductApplyDto.SupplierPublishListDto::getProductType).collect(Collectors.toList());
        ZydExceptions.re(productTypes.stream().distinct().count() != productTypes.size(), "产品型号存在重复提交，申请失败");

        if (StringUtils.isBlank(dto.getEntrance())) {
            dto.setEntrance("1");
        }
        String supplierId = (String) ContextHandler.get("supplierId");
        String userId = ContextHandler.getUserId();
        Set<String> deliveryDates = new HashSet<>();
        List<PurchaseScmProductApply> applies = new ArrayList<>();
        List<PurchaseScmProductApplyChangeRecord> applyChangeRecords = new ArrayList<>();
        List<PurchaseDeliveryDate> dates = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        for (PurchaseScmProductApplyDto.SupplierPublishListDto l : dto.getList()) {
            ZydExceptions.re(StringUtils.isBlank(l.getId()), "不允许新增申请");
            ZydExceptions.re(StringUtils.isBlank(l.getProductPicName()) && StringUtils.isBlank(l.getProductVideoName()), "请上传产品图片或视频");
            ZydExceptions.re(l.getPrice() != null && l.getSupplyPrice() != null && l.getPrice().compareTo(l.getSupplyPrice()) < 0, "供货价必须小于等于面价");
            ZydExceptions.re(l.getPrice() != null && l.getSuggestPrice() != null && l.getPrice().compareTo(l.getSuggestPrice()) < 0, "建议销售价必须小于等于面价");
            l.setProductType(l.getProductType().trim());

            // 判断规格（有单位的，单位是否正确）
            StringJoiner specUnitError = new StringJoiner("，");
            JSONArray newSpecDatas = new JSONArray();
            Map<String, String> specNameUnitMaps = assembleSpecUnit(l.getFirstLevelCataName(), l.getSecondLevelCataName(), l.getThreeLevelCataName());
            Map<String, String> specMap = getSpecValue(l.getSpecData());
            for (String specNameUnit : specNameUnitMaps.keySet()) {
                String specName = specNameUnitMaps.get(specNameUnit);
                String specValue = checkSpecUnit(specNameUnit, specName, specMap.get(specName), specUnitError);
                JSONObject newSpecData = new JSONObject();
                newSpecData.put("specName", specName);
                newSpecData.put("specValue", specValue);
                newSpecDatas.add(newSpecData);
            }
            l.setSpecData(newSpecDatas.toJSONString());
            if (specUnitError.length() > 0) {
                ZydExceptions.re(true, "计量单位有误，请按照规范重新填写。" + specUnitError + "，如有问题请联系业务对接人");
            }

            if (l.getMinimunRequire() == null) {
                l.setMinimunRequire(1);
            }
            // 重量去掉g
            if (StringUtils.isNotBlank(l.getWeight())) {
                l.setWeight(l.getWeight().replaceAll("g", ""));
            }

            Example example = new Example(entityClass);
            example.orderBy(PurchaseScmProductApply.CREATED_AT).desc();
            Example.Criteria criteria = example.createCriteria();
            criteria.andEqualTo(PurchaseScmProductApply.SUPPLIER_ID, supplierId);
            criteria.andEqualTo(PurchaseScmProductApply.PRODUCT_TYPE, l.getProductType());
            criteria.andNotEqualTo(PurchaseScmProductApply.ID, l.getId());
            criteria.andNotEqualTo(PurchaseScmProductApply.AUDIT_STATUS, 4);
            ZydExceptions.re(purchaseScmProductApplyMapper.selectCountByExample(example) > 0, "产品型号：" + l.getProductType() + "已存在，申请失败");

            // 组装
            PurchaseScmProductApply applyOld = getDetail(l.getId());
            if (applyOld != null) {
                ZydExceptions.re(applyOld.getAuditStatus() == 4, "产品型号：" + l.getProductType() + "已审核通过，不允许修改");
                // 处理申请数据
                PurchaseScmProductApply applyNew = handleApply(applyOld, l, dto.getEntrance());
                if (applyNew == null) {
                    continue;
                }
                deliveryDates.add(l.getDeliveryDate());

                // 处理图片和视频
                handleImageVideo(applyNew);

                BeanUtils.copyProperties(l, applyOld);
                applyOld.setDistributePrice(applyNew.getDistributePrice());
                applyOld.setAuditType(applyNew.getAuditType());
                // 驳回的，清空之前的审核时间
                if (applyOld.getAuditStatus() == 5) {
                    if (applyNew.getAuditStatus() == 1) {
                        applyOld.setAuditTime1(null);
                        applyOld.setAuditTime2(null);
                        applyOld.setAuditTime3(null);
                    } else if (applyNew.getAuditStatus() == 2) {
                        applyOld.setAuditTime2(null);
                        applyOld.setAuditTime3(null);
                    } else if (applyNew.getAuditStatus() == 3) {
                        applyOld.setAuditTime3(null);
                    }
                }
                applyOld.setAuditStatus(applyNew.getAuditStatus());
                applyOld.setProductPicName(applyNew.getProductPicName());
                applyOld.setProductVideoName(applyNew.getProductVideoName());
                applyOld.setProductContentPicName(applyNew.getProductContentPicName());
                applyOld.setEditColumns(applyNew.getEditColumns());
                applyOld.setEditSpecs(applyNew.getEditSpecs());
                applyOld.setUpdatedBy(userId);
                applyOld.setUpdatedAt(now);
                applies.add(applyOld);
                // 添加变更记录
                List<PurchaseScmProductApplyChangeRecord> changeRecords = applyNew.getChangeRecords();
                if (!CollectionUtils.isEmpty(changeRecords)) {
                    for (PurchaseScmProductApplyChangeRecord changeRecord : changeRecords) {
                        changeRecord.setId(IDUtils.getUUID19());
                        changeRecord.setApplyNo(applyOld.getApplyNo());
                        changeRecord.setCreatedBy(userId);
                        changeRecord.setCreatedAt(now);
                        changeRecord.setUpdatedBy(userId);
                        changeRecord.setUpdatedAt(now);
                    }
                    applyChangeRecords.addAll(changeRecords);
                }
            }
        }
        for (String deliveryDate : deliveryDates) {
            if (purchaseDeliveryDateMapper.selectExist(supplierId, deliveryDate) == 0) {
                PurchaseDeliveryDate date = new PurchaseDeliveryDate();
                date.setSupplierId(supplierId);
                date.setDeliveryDate(deliveryDate);
                date.setId(getMaxDeliveryId());
                date.setCreatedBy(userId);
                date.setCreatedAt(now);
                date.setUpdatedBy(userId);
                date.setUpdatedAt(now);
                dates.add(date);
            }
        }
        // 处理数据
        ZydExceptions.re(applies.size() == 0 && CollectionUtils.isEmpty(dto.getCancels()) && CollectionUtils.isEmpty(dto.getDeleteIds()), "提交的清单未作任何修改，申请失败");
        if (!CollectionUtils.isEmpty(dto.getCancels())) {
            // 撤销数据
            commonCancel(dto.getCancels(), userId, null);
        }
        if (!CollectionUtils.isEmpty(dto.getDeleteIds())) {
            // 删除数据
            for (String id : dto.getDeleteIds()) {
                PurchaseScmProductApply detail = getDetail(id);
                if (detail != null) {
                    if (detail.getAuditStatus() != 4) {
                        delete(id);
                    } else {
                        ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                    }
                }
            }
        }
        if (applies.size() > 0) {
            for (PurchaseScmProductApply apply : applies) {
                purchaseScmProductApplyMapper.updateByPrimaryKey(apply);
            }
        }
        if (dates.size() > 0) {
            for (PurchaseDeliveryDate date : dates) {
                purchaseDeliveryDateMapper.insert(date);
            }
        }
        if (applyChangeRecords.size() > 0) {
            for (PurchaseScmProductApplyChangeRecord applyChangeRecord : applyChangeRecords) {
                purchaseScmProductApplyChangeRecordMapper.insert(applyChangeRecord);
            }
        }
        // 添加审核统计
        addAuditSum(applies, applyChangeRecords, now, userId, (String) ContextHandler.get("name"), null);
        // 发送审核消息
        sendAuditMsg(applies, now);
        return new JsonResult(true, "");
    }

    /**
     * 供应商-批量编辑待提交
     *
     * @param dto
     * @Author loine
     * @Date 2026/2/25 10:40
     */
    public JsonResult supplierEditDraft(PurchaseScmProductApplyDto.SupplierPublishDraftDto dto) {
        List<String> productTypes = dto.getList().stream().map(PurchaseScmProductApplyDto.SupplierPublishListDto::getProductType).filter(StringUtils::isNotBlank).collect(Collectors.toList());
        ZydExceptions.re(productTypes.isEmpty(), "产品型号不能为空");
        ZydExceptions.re(productTypes.stream().distinct().count() != productTypes.size(), "产品型号存在重复提交，保存失败");

        String supplierId = (String) ContextHandler.get("supplierId");
        String userId = ContextHandler.getUserId();
        Set<String> deliveryDates = new HashSet<>();
        List<PurchaseScmProductApply> applies = new ArrayList<>();
        List<PurchaseDeliveryDate> dates = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        for (PurchaseScmProductApplyDto.SupplierPublishListDto l : dto.getList()) {
            ZydExceptions.re(StringUtils.isBlank(l.getId()), "不允许新增申请");
            l.setProductType(l.getProductType().trim());
            if (l.getMinimunRequire() == null) {
                l.setMinimunRequire(1);
            }
            // 重量去掉g
            if (StringUtils.isNotBlank(l.getWeight())) {
                l.setWeight(l.getWeight().replaceAll("g", ""));
            }

            // 组装
            PurchaseScmProductApply applyOld = getDetail(l.getId());
            if (applyOld != null) {
                // 处理申请数据
                PurchaseScmProductApply applyNew = handleApply(applyOld, l, "1");
                if (applyNew == null) {
                    continue;
                }
                deliveryDates.add(l.getDeliveryDate());

                // 处理图片和视频
                handleImageVideo(applyNew);

                BeanUtils.copyProperties(l, applyOld);
                applyOld.setDistributePrice(applyNew.getDistributePrice());
                applyOld.setAuditStatus(0);// 待提交固定值
                applyOld.setAuditType(1);// 待提交固定值
                applyOld.setProductPicName(applyNew.getProductPicName());
                applyOld.setProductVideoName(applyNew.getProductVideoName());
                applyOld.setProductContentPicName(applyNew.getProductContentPicName());
                applyOld.setEditColumns(applyNew.getEditColumns());
                applyOld.setEditSpecs(applyNew.getEditSpecs());
                applyOld.setUpdatedBy(userId);
                applyOld.setUpdatedAt(now);
                applies.add(applyOld);
            }
        }
        for (String deliveryDate : deliveryDates) {
            if (purchaseDeliveryDateMapper.selectExist(supplierId, deliveryDate) == 0) {
                PurchaseDeliveryDate date = new PurchaseDeliveryDate();
                date.setSupplierId(supplierId);
                date.setDeliveryDate(deliveryDate);
                date.setId(getMaxDeliveryId());
                date.setCreatedBy(userId);
                date.setCreatedAt(now);
                date.setUpdatedBy(userId);
                date.setUpdatedAt(now);
                dates.add(date);
            }
        }
        if (!CollectionUtils.isEmpty(dto.getDeleteIds())) {
            // 删除数据
            for (String id : dto.getDeleteIds()) {
                PurchaseScmProductApply detail = getDetail(id);
                if (detail != null) {
                    if (detail.getAuditStatus() != 4) {
                        delete(id);
                    } else {
                        ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                    }
                }
            }
        }
        if (!applies.isEmpty()) {
            for (PurchaseScmProductApply apply : applies) {
                purchaseScmProductApplyMapper.updateByPrimaryKey(apply);
            }
        }
        if (!dates.isEmpty()) {
            for (PurchaseDeliveryDate date : dates) {
                purchaseDeliveryDateMapper.insert(date);
            }
        }
        return new JsonResult(true, "");
    }

    /**
     * 获取引导启用状态
     *
     * @Author: loine
     * @Date: 2024/11/5 14:31
     */
    public PurchaseScmProductApplyVo.SupplierGetGuideVo supplierGetGuide(PurchaseScmProductApplyDto.SupplierGetGuideDto dto) {
        PurchaseScmProductApplyVo.SupplierGetGuideVo vo = new PurchaseScmProductApplyVo.SupplierGetGuideVo();
        vo.setIsEnable("N");
        Example example = new Example(PurchaseScmGuideConfig.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(PurchaseScmGuideConfig.TYPE, dto.getType());
        List<PurchaseScmGuideConfig> configs = purchaseScmGuideConfigMapper.selectByExample(example);
        if (configs.size() > 0) {
            PurchaseScmGuideConfig config = configs.get(0);
            if ("Y".equals(config.getIsEnable())) {
                // 启用时，判断次数
                String userId = ContextHandler.getUserId();
                example = new Example(PurchaseScmGuideRecord.class);
                criteria = example.createCriteria();
                criteria.andEqualTo(PurchaseScmGuideRecord.TYPE, dto.getType());
                criteria.andEqualTo(PurchaseScmGuideRecord.USER_ID, userId);
                if (purchaseScmGuideRecordMapper.selectCountByExample(example) < config.getCount()) {
                    vo.setIsEnable("Y");
                }
            }
        }
        return vo;
    }

    /**
     * 供应商-添加引导记录
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/11/5 14:49
     */
    public JsonResult addGuide(PurchaseScmProductApplyDto.SupplierGetGuideDto dto) {
        String userId = ContextHandler.getUserId();
        PurchaseScmGuideRecord record = new PurchaseScmGuideRecord();
        record.setId(IDUtils.getUUID19());
        record.setType(dto.getType());
        record.setUserId(userId);
        record.setCreatedBy(userId);
        record.setCreatedAt(LocalDateTime.now());
        record.setUpdatedBy(userId);
        record.setUpdatedAt(LocalDateTime.now());
        purchaseScmGuideRecordMapper.insert(record);
        return new JsonResult(true, "");
    }

    /**
     * 后台-搜索
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 14:57
     */
    public Page<PurchaseScmProductApplyVo.AdminSearchVo> adminSearch(PurchaseScmProductApplyDto.AdminSearchDto dto) {
        Page<PurchaseScmProductApplyVo.AdminSearchVo> page = new Page<>();
        page.setPageNum(BeanUtil.isEmpty(dto.getPageNum()) ? 1 : dto.getPageNum());
        page.setPageSize(BeanUtil.isEmpty(dto.getPageSize()) ? 12 : dto.getPageSize());
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<PurchaseScmProductApplyVo.AdminSearchVo> list = getAdminSearch(dto);
        list.stream()
                .map(p -> {
                    Map<String, String> specMap = handleSpecToTwoColumn(p.getSpecData());
                    p.setSpecName(specMap.getOrDefault("specName", ""));  // 添加默认值防止NPE
                    p.setSpecValue(specMap.getOrDefault("specValue", ""));
                    return p;
                })
                .collect(Collectors.toList());
        for (PurchaseScmProductApplyVo.AdminSearchVo l : list) {
            l.setSupplyPrice(formatBigDecimalData(l.getSupplyPrice()));
            l.setPrice(formatBigDecimalData(l.getPrice()));
            l.setSuggestPrice(formatBigDecimalData(l.getSuggestPrice()));
            l.setDistributePrice(formatBigDecimalData(l.getDistributePrice()));
        }
        return new Page<>(list);
    }

    /**
     * 后台-搜索角标
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 14:57
     */
    public PurchaseScmProductApplyVo.SearchCountVo adminSearchCount(PurchaseScmProductApplyDto.AdminSearchDto dto) {
        String corpCode = ContextHandler.getCorpCode();
        String companyShortName = (String) ContextHandler.get("companyShortName");
        if ("上海供应链公司".equals(companyShortName) || "众业达集团".equals(companyShortName)) {
            companyShortName = null;
        }
        return purchaseScmProductApplyMapper.adminSearchCount(dto, corpCode, companyShortName);
    }

    /**
     * 后台-批量通过
     *
     * @param list
     * @param approveType
     * @param task
     * @param createName
     * @Author: loine
     * @Date: 2024/10/15 15:27
     */
    public JsonResult adminApprove(List<PurchaseScmProductApplyVo.AdminSearchVo> list, String approveType, TaskManageDto task, String createName) {
        // 审核列表（状态不等于4）
        List<PurchaseScmProductApply> details = new ArrayList<>();
        // 审核通过列表（状态等于4）
        List<PurchaseScmProductApply> approveDetails = new ArrayList<>();
        // 审核记录
        List<PurchaseScmProductApplyAuditRecord> auditRecords = new ArrayList<>();
        // 操作
        Set<String> doSomethings = new HashSet<>();
        // 审核时间
        LocalDateTime auditTime = LocalDateTime.now();
        if (list.size() > 0) {
            // 根据id组获取完整数据
            Set<String> ids = list.stream().map(PurchaseScmProductApplyVo.AdminSearchVo::getId).collect(Collectors.toSet());
            Example example = new Example(entityClass);
            example.orderBy(PurchaseScmProductApply.CREATED_AT).desc();
            Example.Criteria criteria = example.createCriteria();
            criteria.andIn(PurchaseScmProductApply.ID, ids);
            List<PurchaseScmProductApply> detailList = purchaseScmProductApplyMapper.selectByExample(example);
            for (PurchaseScmProductApply detail : detailList) {
                if (detail.getAuditStatus() == 1 || detail.getAuditStatus() == 2 || detail.getAuditStatus() == 3) {
                    int auditStatusBefore = detail.getAuditStatus();
                    if (detail.getAuditType() == 2) {
                        if (detail.getAuditStatus() == 1) {
                            detail.setAuditStatus(2);
                            detail.setAuditTime1(auditTime);
                        } else {
                            detail.setAuditStatus(4);
                            detail.setAuditTime2(auditTime);
                        }
                    } else if (detail.getAuditType() == 3) {
                        if (detail.getAuditStatus() == 1) {
                            detail.setAuditStatus(3);
                            detail.setAuditTime1(auditTime);
                        } else {
                            detail.setAuditStatus(4);
                            detail.setAuditTime3(auditTime);
                        }
                    } else if (detail.getAuditType() == 5) {
                        detail.setAuditStatus(4);
                        detail.setAuditTime2(auditTime);
                    } else if (detail.getAuditType() == 4) {
                        detail.setAuditStatus(detail.getAuditStatus() + 1);
                        if (detail.getAuditStatus() == 2) {
                            detail.setAuditTime1(auditTime);
                        } else if (detail.getAuditStatus() == 3) {
                            detail.setAuditTime2(auditTime);
                        } else if (detail.getAuditStatus() == 4) {
                            detail.setAuditTime3(auditTime);
                        }
                    } else if (detail.getAuditType() == 1) {
                        if (detail.getAuditStatus() == 1) {
                            detail.setAuditStatus(2);
                            detail.setAuditTime1(auditTime);
                        } else if (detail.getAuditStatus() == 2) {
                            detail.setAuditStatus(4);
                            detail.setAuditTime2(auditTime);
                        } else {
                            detail.setAuditStatus(4);
                            detail.setAuditTime3(auditTime);
                        }
                    }
                    if (detail.getAuditStatus() == 4) {
                        detail.setIsOnsale("Y");
                        approveDetails.add(detail);
                    } else {
                        details.add(detail);
                    }
                    auditRecords.add(getAuditRecord(detail, auditStatusBefore, auditTime, task.getCreatedBy()));
                    if (auditStatusBefore == 2) {
                        doSomethings.add("资料审核");
                    } else {
                        doSomethings.add("价格审核");
                    }
                } else {
                    ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                }
            }
        }
        // 公海同步成功列表-审核通过列表（状态等于4）
        List<PurchaseScmProductApply> approveSuccessDetails = new ArrayList<>();
        if (approveDetails.size() > 0) {
            // 获取公司信息
            Map<Integer, String> companyMap = getCompanyMap(approveDetails);
            for (PurchaseScmProductApply detail : approveDetails) {
                // 产品同步至公海
                PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
                BeanUtils.copyProperties(detail, purchaseProductSync);
                purchaseProductSync.setProductVedioName(detail.getProductVideoName());
                purchaseProductSync.setSample(detail.getProductSampleName());
                purchaseProductSync.setProductContent(detail.getProductContentPicName());
                purchaseProductSync.setIsOnsale("Y");
                purchaseProductSync.setSubCompany(companyMap.get(detail.getCompanyId()));
                purchaseProductSync.setSpecData(handleSyncCommonSpec(detail.getSpecData()));
                purchaseProductSync.setReason(detail.getOffsaleReason());
                purchaseProductSync.setPurchasePrice(detail.getDistributePrice());
                purchaseProductSync.setPurchaseDiscount(detail.getDistributeDiscount());
                purchaseProductSync.setPurchaseCalcWay(detail.getDistributeCalcWay());
                purchaseProductSync.setAuditTime(detail.getAuditTime3());
                purchaseProductSync.setZydmallFlag("0");
                if (StringUtils.isNotBlank(approveType) && approveType.equals("2")) {
                    purchaseProductSync.setZydmallFlag("1");
                }
                JsonResult<Long> jsonResult = publicProductFeignClient.purchaseProductSync(purchaseProductSync);
                if (null != jsonResult && BooleanUtils.isTrue(jsonResult.isSuccess())) {
                    // 公海更新成功才更新申请表状态
                    detail.setPublicProductId(jsonResult.getData());
                    if ("Y".equals(detail.getIsSupply())) {
                        detail.setProductErpCode(detail.getProductCode());
                    }
                    approveSuccessDetails.add(detail);
                } else {
                    return JsonResult.error("同步公海请求异常，请联系管理员");
                }
            }
        }
        if (details.size() > 0 || approveSuccessDetails.size() > 0) {
            // 更新申请数据
            List<PurchaseScmProductApply> temp = new ArrayList<>();
            temp.addAll(details);
            temp.addAll(approveSuccessDetails);
            batchUpdate(temp);
            // 发送审核消息
            if (!temp.isEmpty()) {
                sendAuditMsg(temp, auditTime);
            }
            // 标记加入zydmall商城表
            if (approveSuccessDetails.size() > 0) {
                if (StringUtils.isNotBlank(approveType) && approveType.equals("2")) {
                    List<Long> productIds = approveSuccessDetails.stream().map(PurchaseScmProductApply::getPublicProductId).filter(Objects::nonNull).collect(Collectors.toList());
                    publicProductFeignClient.purchaseZydmallAdd(productIds);
                }
                // 对标记上架zydmall的商品，如果产品有再次修改审核后，需要通知对应人员去同步更新
                List<PurchaseScmProductApplyVo.AdminSearchVo> zydmallList = list.stream().filter(l -> StringUtils.isNotBlank(l.getZydmallFlag()) && l.getZydmallFlag().equals("1")).collect(Collectors.toList());
                if (!CollectionUtils.isEmpty(zydmallList)) {
                    ByteArrayOutputStream ba = new ByteArrayOutputStream();
                    try {
                        // 查询变更记录
                        Set<Long> applyNos = zydmallList.stream().map(PurchaseScmProductApplyVo.AdminSearchVo::getApplyNo).collect(Collectors.toSet());
                        Map<Long, List<PurchaseScmProductApplyChangeRecord>> changeRecordMap = null;
                        if (applyNos.size() > 0) {
                            List<PurchaseScmProductApplyChangeRecord> changeRecords = purchaseScmProductApplyChangeRecordMapper.getByApplyNos(applyNos);
                            changeRecordMap = changeRecords.stream().collect(Collectors.groupingBy(PurchaseScmProductApplyChangeRecord::getApplyNo));
                        }
                        // 写入excel
                        List<PurchaseScmProductApplyVo.AdminAuditZydmallExportVo> exportList = new ArrayList<>();
                        for (PurchaseScmProductApplyVo.AdminSearchVo l : zydmallList) {
                            PurchaseScmProductApplyVo.AdminAuditZydmallExportVo eL = new PurchaseScmProductApplyVo.AdminAuditZydmallExportVo();
                            BeanUtils.copyProperties(l, eL);
                            eL.setCataName(l.getFirstLevelCataName() + ">" + l.getSecondLevelCataName() + ">" + l.getThreeLevelCataName());
                            eL.setProductId(l.getPublicProductId());
                            // 设置变更记录
                            if (changeRecordMap != null) {
                                List<PurchaseScmProductApplyChangeRecord> changeRecords = changeRecordMap.get(l.getApplyNo());
                                if (!CollectionUtils.isEmpty(changeRecords)) {
                                    StringBuilder sb = new StringBuilder();
                                    for (int i = 0; i < changeRecords.size(); i++) {
                                        PurchaseScmProductApplyChangeRecord changeRecord = changeRecords.get(i);
                                        String oldValue = StringUtils.isNotBlank(changeRecord.getOldValue()) ? changeRecord.getOldValue() : "-";
                                        String newValue = StringUtils.isNotBlank(changeRecord.getNewValue()) ? changeRecord.getNewValue() : "-";
                                        if (changeRecord.getFieldCode().equals("stock")) {
                                            if (oldValue.equals("1")) {
                                                oldValue = "现货";
                                            } else {
                                                oldValue = "订货";
                                            }
                                            if (newValue.equals("1")) {
                                                newValue = "现货";
                                            } else {
                                                newValue = "订货";
                                            }
                                        }
                                        if (i == changeRecords.size() - 1) {
                                            sb.append(changeRecord.getFieldName()).append("（变更前：").append(oldValue).append("，变更后：").append(newValue).append("）");
                                        } else {
                                            sb.append(changeRecord.getFieldName()).append("（变更前：").append(oldValue).append("，变更后：").append(newValue).append("）\n");
                                        }
                                    }
                                    eL.setEditDetail(sb.toString());
                                }
                            } else {
                                eL.setEditDetail(changeEditDetailToCn(l.getEditColumns(), l.getEditSpecs()));
                            }
                            exportList.add(eL);
                        }
                        new MultiTitleExportExcelUtil("商品明细", 18, MultiTitleExportExcelUtil.STYLE_TITLE3, PurchaseScmProductApplyVo.AdminAuditZydmallExportVo.class)
                                .setDataListColWidth(exportList)
                                .write(ba);
                        // 这一步保存excel到oss
                        ByteArrayInputStream is = new ByteArrayInputStream(ba.toByteArray());
                        String newPath = "purchase/scm/zydmall/" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "/上架zydmall商品数据变更-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
                        String fileUrl = ossMaterialService.uploadResourceByIs(newPath, is);
                        // 发送上架zydmall的商品，信息修改消息
                        sendAuditZydmallErpMsg(fileUrl);
                    } catch (Exception e) {
                        log.error("保存上架zydmall的商品明细excel到oss失败：" + e);
                    } finally {
                        IoUtil.close(ba);
                    }
                }
            }
            // 添加审核统计
            addAuditSum(temp, null, auditTime, task.getCreatedBy(), createName, doSomethings);
        }
        if (auditRecords.size() > 0) {
            for (PurchaseScmProductApplyAuditRecord auditRecord : auditRecords) {
                purchaseScmProductApplyAuditRecordMapper.insert(auditRecord);
            }
        }
        return new JsonResult(true, "");
    }

    /**
     * 后台-批量驳回
     *
     * @param list
     * @param auditRemark
     * @param task
     * @param createName
     * @Author: loine
     * @Date: 2024/10/25 9:35
     */
    public JsonResult adminReject(List<PurchaseScmProductApplyVo.AdminSearchVo> list, String auditRemark, TaskManageDto task, String createName) {
        List<PurchaseScmProductApplyDto.SupplierPublishCancelDto> cancels = new ArrayList<>();
        for (PurchaseScmProductApplyVo.AdminSearchVo l : list) {
            PurchaseScmProductApplyDto.SupplierPublishCancelDto cancel = new PurchaseScmProductApplyDto.SupplierPublishCancelDto();
            cancel.setId(l.getId());
            cancel.setAuditRemark(auditRemark);
            cancels.add(cancel);
        }
        // 操作
        Set<String> doSomethings = new HashSet<>();
        // 取消
        List<PurchaseScmProductApply> cancelDetails = commonCancel(cancels, task.getCreatedBy(), doSomethings);
        if (!cancelDetails.isEmpty()) {
            // 添加审核统计
            addAuditSum(cancelDetails, null, cancelDetails.get(0).getCancelTime(), task.getCreatedBy(), createName, doSomethings);
        }
        return new JsonResult(true, "");
    }

    /**
     * 后台-商品审核列表导出
     *
     * @param ba
     * @param list
     * @param isChangeRecord
     * @Author: loine
     * @Date: 2024/10/15 15:30
     */
    public void adminAuditExport(ByteArrayOutputStream ba, List<PurchaseScmProductApplyVo.AdminSearchVo> list, boolean isChangeRecord) {
        list.stream().map(p -> {
            Map<String, String> specMap = handleSpecToTwoColumn(p.getSpecData());
            p.setSpecName(specMap.getOrDefault("specName", ""));  // 添加默认值防止NPE
            p.setSpecValue(specMap.getOrDefault("specValue", ""));
            return p;
        }).collect(Collectors.toList());
        // 查询变更记录
        isChangeRecord = isChangeRecord && !list.isEmpty() && list.get(0).getAuditStatus() <= 3;
        Map<Long, List<PurchaseScmProductApplyChangeRecord>> changeRecordMap = null;
        if (isChangeRecord) {
            Set<Long> applyNos = list.stream().map(PurchaseScmProductApplyVo.AdminSearchVo::getApplyNo).collect(Collectors.toSet());
            List<PurchaseScmProductApplyChangeRecord> changeRecords = purchaseScmProductApplyChangeRecordMapper.getByApplyNos(applyNos);
            changeRecordMap = changeRecords.stream().collect(Collectors.groupingBy(PurchaseScmProductApplyChangeRecord::getApplyNo));
        }
        try {
            // 处理导出标题
            List<String> titleFields = new LinkedList<>();
            List<String> titleTexts = new LinkedList<>();
            // 获取页面列表配置
            TableSettings tableSettings = new TableSettings();
            tableSettings.setMenuPage("scm-admin-product-apply");
            tableSettings.setUserId(ContextHandler.getUserId());
            tableSettings = tableSettingsMapper.selectOne(tableSettings);
            if (tableSettings != null && StringUtils.isNotBlank(tableSettings.getTableConfig())) {
                List<TableConfigDto> tableConfigs = JSONArray.parseArray(tableSettings.getTableConfig(), TableConfigDto.class);
                tableConfigs = tableConfigs.stream().filter(TableConfigDto::isShow).sorted(Comparator.comparing(TableConfigDto::getOrder).reversed()).collect(Collectors.toList());
                for (TableConfigDto tableConfig : tableConfigs) {
                    if (tableConfig.getField().equalsIgnoreCase("checkbox")) {
                        continue;
                    }
                    titleFields.add(tableConfig.getField());
                    titleTexts.add(tableConfig.getText());
                }
            } else {
                titleFields.addAll(Arrays.asList("applyNo", "auditStatus", "auditType", "companyShortName", "supplierName", "materialName", "productType", "skuCode", "productCode", "stock", "deliveryDate", "price", "supplyDiscount", "supplyPrice", "distributeDiscount", "distributePrice", "suggestPrice", "brandName", "propName", "firstLevelCataName", "specName", "specValue", "productPicName", "productContentPicName", "productSampleName", "weight", "unit", "minimunRequire", "createdAt", "updatedAt", "auditTime1", "auditTime2", "auditTime3"));
                titleTexts.addAll(Arrays.asList("申请编号", "状态", "申请类型", "所属子公司", "供应商", "产品名称", "产品型号", "厂家物料号", "商品编码", "库存", "交货期", "面价", "供货折扣", "供货价", "调货折扣（基于供货价）", "调货价", "建议销售价", "产品品牌", "产品系列", "分类", "规格名", "规格值", "产品主图", "产品详情图", "产品样本", "重量", "单位", "最小起订量", "申请时间", "修改时间", "审核时间（分部）", "审核时间（资料）", "审核时间（价格）"));
            }
            // 处理分类
            if (titleFields.contains("firstLevelCataName")) {
                int index = titleFields.indexOf("firstLevelCataName");
                titleTexts.set(index, "一级分类");
                titleFields.add(index + 1, "secondLevelCataName");
                titleTexts.add(index + 1, "二级分类");
                titleFields.add(index + 2, "threeLevelCataName");
                titleTexts.add(index + 2, "三级分类");
            }
            // 处理变更记录
            if (isChangeRecord) {
                titleFields.add("changeRecords");
                titleTexts.add("变更详情");
            }
            List<List<MultiTitleExportExcelUtil.Title>> titleList = new ArrayList<>();
            List<MultiTitleExportExcelUtil.Title> titles = new ArrayList<>();
            for (String titleText : titleTexts) {
                titles.add(new MultiTitleExportExcelUtil.Title(titleText, 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            }
            titleList.add(titles);
            // 处理导出数据
            List<List<Object>> objects = new ArrayList<>();
            for (PurchaseScmProductApplyVo.AdminSearchVo l : list) {
                PurchaseScmProductApplyVo.AdminExportVo eL = new PurchaseScmProductApplyVo.AdminExportVo();
                BeanUtils.copyProperties(l, eL);
                if (l.getAuditStatus() == 0) {
                    eL.setAuditStatus("待提交");
                } else if (l.getAuditStatus() == 1) {
                    eL.setAuditStatus("待分部审核");
                } else if (l.getAuditStatus() == 2) {
                    eL.setAuditStatus("待资料审核");
                } else if (l.getAuditStatus() == 3) {
                    eL.setAuditStatus("待价格审核");
                } else if (l.getAuditStatus() == 4) {
                    eL.setAuditStatus("通过");
                } else if (l.getAuditStatus() == 5) {
                    eL.setAuditStatus("驳回");
                }
                if (l.getAuditType() == 1) {
                    eL.setAuditType("商品新增");
                } else if (l.getAuditType() == 2) {
                    eL.setAuditType("资料修改");

                } else if (l.getAuditType() == 3) {
                    eL.setAuditType("价格修改");

                } else if (l.getAuditType() == 4) {
                    eL.setAuditType("资料价格修改");

                } else if (l.getAuditType() == 5) {
                    eL.setAuditType("图片修改");
                }
                if (l.getStock() == 1) {
                    eL.setStock("现货");
                } else {
                    eL.setStock("订货");
                }
                // 处理价格
                eL.setSupplyDiscount(l.getSupplyDiscount() != null ? l.getSupplyDiscount().toString() : null);
                eL.setSupplyPrice(formatBigDecimalData(l.getSupplyPrice()));
                eL.setPrice(formatBigDecimalData(l.getPrice()));
                eL.setSuggestPrice(formatBigDecimalData(l.getSuggestPrice()));
                eL.setDistributeDiscount(l.getDistributeDiscount() != null ? l.getDistributeDiscount().toString() : null);
                eL.setDistributePrice(formatBigDecimalData(l.getDistributePrice()));
                // 处理图片、视频等
                eL.setProductPicName(changeToFullUrl(eL.getProductVideoName(), eL.getProductPicName()));
                eL.setProductContentPicName(changeToFullUrl(eL.getProductContentPicName()));
                eL.setProductSampleName(changeToFullUrl(eL.getProductSampleName()));
                // 处理规格
//                eL.setSpecData(handleExportSpec(eL.getSpecData()));
                // 处理时间
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                if (l.getCreatedAt() != null) {
                    eL.setCreatedAt(l.getCreatedAt().format(formatter));
                }
                if (l.getUpdatedAt() != null) {
                    eL.setUpdatedAt(l.getUpdatedAt().format(formatter));
                }
                if (l.getAuditTime1() != null) {
                    eL.setAuditTime1(l.getAuditTime1().format(formatter));
                }
                if (l.getAuditTime2() != null) {
                    eL.setAuditTime2(l.getAuditTime2().format(formatter));
                }
                if (l.getAuditTime3() != null) {
                    eL.setAuditTime3(l.getAuditTime3().format(formatter));
                }
                // 处理变更记录
                if (isChangeRecord) {
                    if (l.getAuditType() == 1) {
                        eL.setChangeRecords("");
                    } else {
                        List<PurchaseScmProductApplyChangeRecord> changeRecords = changeRecordMap.get(l.getApplyNo());
                        if (!CollectionUtils.isEmpty(changeRecords)) {
                            StringBuilder sb = new StringBuilder();
                            for (int i = 0; i < changeRecords.size(); i++) {
                                PurchaseScmProductApplyChangeRecord changeRecord = changeRecords.get(i);
                                String oldValue = StringUtils.isNotBlank(changeRecord.getOldValue()) ? changeRecord.getOldValue() : "-";
                                String newValue = StringUtils.isNotBlank(changeRecord.getNewValue()) ? changeRecord.getNewValue() : "-";
                                if (changeRecord.getFieldCode().equals("stock")) {
                                    if (oldValue.equals("1")) {
                                        oldValue = "现货";
                                    } else {
                                        oldValue = "订货";
                                    }
                                    if (newValue.equals("1")) {
                                        newValue = "现货";
                                    } else {
                                        newValue = "订货";
                                    }
                                }
                                if (i == changeRecords.size() - 1) {
                                    sb.append(changeRecord.getFieldName()).append("（变更前：").append(oldValue).append("，变更后：").append(newValue).append("）");
                                } else {
                                    sb.append(changeRecord.getFieldName()).append("（变更前：").append(oldValue).append("，变更后：").append(newValue).append("）\n");
                                }
                            }
                            eL.setChangeRecords(sb.toString());
                        } else {
                            eL.setChangeRecords("");
                        }
                    }
                }
                // 添加到表格
                List<Object> object = new ArrayList<>();
                for (String titleField : titleFields) {
                    object.add(getFieldValue(eL, titleField));
                }
                objects.add(object);
            }
            new MultiTitleExportExcelUtil("商品明细", titleList)
                    .setDataListObject(objects)
                    .write(ba);
        } catch (Exception e) {
            log.error("商品审核excel导出异常：{}", e.getMessage(), e);
            ZydExceptions.re(true, "商品审核导出失败");
        }
    }

    /**
     * 后台-详情
     *
     * @param id
     * @Author: loine
     * @Date: 2024/11/11 11:48
     */
    public PurchaseScmProductApplyVo.SupplierDetailVo adminDetail(String id) {
        PurchaseScmProductApplyVo.SupplierDetailVo detailVo = new PurchaseScmProductApplyVo.SupplierDetailVo();
        PurchaseScmProductApply detail = get(id);
        if (detail != null) {
            BeanUtils.copyProperties(detail, detailVo);
            detailVo.setSupplyPrice(formatBigDecimalData(detail.getSupplyPrice()));
            detailVo.setPrice(formatBigDecimalData(detail.getPrice()));
            detailVo.setSuggestPrice(formatBigDecimalData(detail.getSuggestPrice()));
            detailVo.setDistributePrice(formatBigDecimalData(detail.getDistributePrice()));
            detailVo.setProductPicName(resizeImage(detailVo.getProductPicName()));
            // 获取公司简称
            Set<Integer> companyIds = new HashSet<>();
            companyIds.add(detail.getCompanyId());
            List<PurchaseScmProductApplyVo.CompanyVo> companyVos = purchaseScmProductApplyMapper.getCompany(companyIds);
            if (!CollectionUtils.isEmpty(companyVos)) {
                detailVo.setCompanyShortName(companyVos.get(0).getSubCompany());
            }
            // 产品名称为空，需要按商城拼接
            handleMaterialName(detailVo);
        }
        detailVo.setUrlPrefix(ossConf.getOssUrl());
        return detailVo;
    }

    /**
     * 后台-相同型号搜索
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/11/11 11:49
     */
    public Page<PurchaseScmProductApplyVo.SupplierSameSearchVo> adminSameSearch(PurchaseScmProductApplyDto.AdminSameSearchDto dto) {
        Page<PurchaseScmProductApplyVo.SupplierSameSearchVo> page = new Page<>();
        int pageNum = BeanUtil.isEmpty(dto.getPageNum()) ? 1 : dto.getPageNum();
        int pageSize = BeanUtil.isEmpty(dto.getPageSize()) ? 12 : dto.getPageSize();
        List<PurchaseScmProductApplyVo.SupplierSameSearchVo> datas = new ArrayList<>();
        PurchaseScmProductApplyDto.AdminSearchDto searchDto = new PurchaseScmProductApplyDto.AdminSearchDto();
        BeanUtils.copyProperties(dto, searchDto);
        if (pageNum > 0 && pageSize > 0) {
            PageHelper.startPage(pageNum, pageSize);
        }
        if ("Y".equals(dto.getIsAudit())) {
            searchDto.setAuditStatus(4);
        } else if ("N".equals(dto.getIsAudit())) {
            // 除审核通过
            searchDto.setAuditStatus(1235);
        } else {
            searchDto.setAuditStatus(dto.getAuditStatus());
        }
        searchDto.setSupplierId(dto.getSupplierId());
        List<PurchaseScmProductApplyVo.AdminSearchVo> list = getAdminSearch(searchDto);
        list.stream()
                .map(p -> {
                    Map<String, String> specMap = handleSpecToTwoColumn(p.getSpecData());
                    p.setSpecName(specMap.getOrDefault("specName", ""));  // 添加默认值防止NPE
                    p.setSpecValue(specMap.getOrDefault("specValue", ""));
                    return p;
                })
                .collect(Collectors.toList());
        PageInfo<PurchaseScmProductApplyVo.AdminSearchVo> pageInfo = new PageInfo<>(list);
        BeanUtils.copyProperties(pageInfo, page);
        for (PurchaseScmProductApplyVo.AdminSearchVo l : list) {
            PurchaseScmProductApplyVo.SupplierSameSearchVo d = new PurchaseScmProductApplyVo.SupplierSameSearchVo();
            BeanUtils.copyProperties(l, d);
            d.setSupplyPrice(formatBigDecimalData(d.getSupplyPrice()));
            d.setPrice(formatBigDecimalData(d.getPrice()));
            d.setSuggestPrice(formatBigDecimalData(d.getSuggestPrice()));
            d.setDistributePrice(formatBigDecimalData(d.getDistributePrice()));
            datas.add(d);
        }
        // 处理规格值
        for (PurchaseScmProductApplyVo.SupplierSameSearchVo data : datas) {
            StringBuilder sb = new StringBuilder();
            if (StringUtils.isNotBlank(data.getSpecData())) {
                JSONArray specData = JSONArray.parseArray(data.getSpecData());
                if (specData.size() > 0) {
                    for (int i = 0; i < specData.size(); i++) {
                        JSONObject spec = specData.getJSONObject(i);
                        if (spec != null) {
                            if (spec.get("specName") != null && spec.get("specValue") != null) {
                                sb.append(spec.get("specValue")).append("|");
                            }
                        }
                    }
                    if (sb.toString().length() > 0) {
                        sb.deleteCharAt(sb.length() - 1);
                    }
                }
            }
            data.setSpecValueString(sb.toString());
        }
        page.setList(datas);
        return page;
    }

    /**
     * 后台-相同型号搜索选择器
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/11/11 11:49
     */
    public PurchaseScmProductApplyVo.SupplierSameSelectorVo adminSameSelector(PurchaseScmProductApplyDto.AdminSameSearchDto dto) {
        PurchaseScmProductApplyVo.SupplierSameSelectorVo vo = new PurchaseScmProductApplyVo.SupplierSameSelectorVo();
        List<PurchaseScmProductApplyVo.SpecVo> list;
        String corpCode = ContextHandler.getCorpCode();
        try {
            PurchaseScmProductApplyDto.AdminSearchDto searchDto = new PurchaseScmProductApplyDto.AdminSearchDto();
            BeanUtils.copyProperties(dto, searchDto);
            if (StringUtils.isBlank(dto.getIsAudit())) {
                dto.setIsAudit("N");
            }
            if (dto.getIsAudit().equals("Y")) {
                searchDto.setAuditStatus(4);
            } else {
                // 除审核通过
                searchDto.setAuditStatus(1235);
            }
            searchDto.setSupplierId(dto.getSupplierId());
            String companyShortName = (String) ContextHandler.get("companyShortName");
            if ("上海供应链公司".equals(companyShortName) || "众业达集团".equals(companyShortName)) {
                companyShortName = null;
            }
            list = purchaseScmProductApplyMapper.adminSelectSpec(searchDto, corpCode, companyShortName);
        } catch (Exception e) {
            list = new ArrayList<>();
        }
        List<PurchaseScmProductApplyVo.SupplierSameSelectorListVo> specs = new ArrayList<>();
        if (list.size() > 0) {
            Map<String, List<PurchaseScmProductApplyVo.SpecVo>> specMap = list.stream().filter(s -> StringUtils.isNotBlank(s.getSpecName())).collect(Collectors.groupingBy(PurchaseScmProductApplyVo.SpecVo::getSpecName));
            for (String specName : specMap.keySet()) {
                List<PurchaseScmProductApplyVo.SpecVo> specVos = specMap.get(specName);
                PurchaseScmProductApplyVo.SupplierSameSelectorListVo spec = new PurchaseScmProductApplyVo.SupplierSameSelectorListVo();
                spec.setSpecName(specName);
                List<PurchaseScmProductApplyVo.SupplierSameSelectorSpecValueVo> specValues = new ArrayList<>();
                for (PurchaseScmProductApplyVo.SpecVo specVo : specVos) {
                    PurchaseScmProductApplyVo.SupplierSameSelectorSpecValueVo specValue = new PurchaseScmProductApplyVo.SupplierSameSelectorSpecValueVo();
                    if (StringUtils.isBlank(specVo.getSpecValue())) {
                        continue;
                    }
                    specValue.setSpecValue(specVo.getSpecValue());
                    specValue.setSelected(false);
                    // 判断是否选中
                    for (PurchaseScmProductApplyDto.SpecDto specNameValue : dto.getSpecNameValues()) {
                        if (specNameValue.getSpecName().equals(specName) && specNameValue.getSpecValue().equals(specVo.getSpecValue())) {
                            specValue.setSelected(true);
                            break;
                        }
                    }
                    specValues.add(specValue);
                }
                specValues = specValues.stream().sorted(Comparator.comparing(PurchaseScmProductApplyVo.SupplierSameSelectorSpecValueVo::getSpecValue)).collect(Collectors.toList());
                spec.setSpecValues(specValues);
                specs.add(spec);
            }
            specs = specs.stream().sorted(Comparator.comparing(PurchaseScmProductApplyVo.SupplierSameSelectorListVo::getSpecName)).collect(Collectors.toList());
        }
        vo.setSpecs(specs);
        return vo;
    }

    /**
     * 后台-批量设置调货价
     *
     * @param list
     * @param distributeDiscount
     * @param distributeCalcWay
     * @Author: loine
     * @Date: 2024/12/16 11:40
     */
    private JsonResult adminEditDistribute(List<PurchaseScmProductApplyVo.AdminSearchVo> list, BigDecimal distributeDiscount, String distributeCalcWay) {
        ZydExceptions.re(distributeDiscount == null || distributeCalcWay == null, "调货价折扣不能为空");
        List<PurchaseScmProductApply> details = new ArrayList<>();
        for (PurchaseScmProductApplyVo.AdminSearchVo l : list) {
            PurchaseScmProductApply detail = get(l.getId());
            if (detail != null) {
                details.add(detail);
            }
        }
        if (details.size() > 0) {
            Map<Integer, String> companyMap = getCompanyMap(details);
            for (PurchaseScmProductApply detail : details) {
                ZydExceptions.re(!isScm(companyMap.get(detail.getCompanyId())), "直供供应商不支持修改调货价，请检查");
                detail.setDistributeCalcWay(distributeCalcWay);
                detail.setDistributeDiscount(distributeDiscount);
                // 设置调货价
                setDistributePrice(detail);
            }
            batchUpdate(details);
        }
        return new JsonResult(true, "");
    }

    /**
     * 处理商品审核的消息
     *
     * @param message
     * @Author: loine
     * @Date: 2024/12/27 9:38
     */
    public void readProductApproveQueue(String message) {
        if (StringUtils.isBlank(message)) {
            return;
        }
        String executeStatus = "";
        String newPath = "taskDetail/excel/" + message + ".xlsx";
        // 获取任务信息
        JSONObject feignRequestParam = new JSONObject();
        feignRequestParam.put("id", message);
        JSONObject taskResult = taskClient.taskDetail(feignRequestParam);
        if (taskResult != null && taskResult.get("code") != null && taskResult.getInteger("code") == 0 && taskResult.get("data") != null) {
            TaskManageDto task = JSONObject.parseObject(taskResult.getJSONObject("data").toJSONString(), TaskManageDto.class);
            if (task.getStatus().equals("0") || task.getStatus().equals("3")) {
                // 更新任务状态为执行中
                feignRequestParam = new JSONObject();
                feignRequestParam.put("id", message);
                feignRequestParam.put("status", "1");
                feignRequestParam.put("resultType", "1");
                feignRequestParam.put("resultContent", ossConf.getOssUrl() + newPath);
                taskClient.taskUpdate(feignRequestParam);
                try {
                    JSONObject requestParam = JSONObject.parseObject(task.getRequestParam());
                    requestParam.putIfAbsent("source", "商品审核");
                    if (requestParam.getString("source").equals("商品审核")) {
                        // 查询数据
                        int num = 0;
                        PurchaseScmProductApplyDto.AdminTaskDto taskDto = JSONObject.parseObject(task.getRequestParam(), PurchaseScmProductApplyDto.AdminTaskDto.class);
                        PurchaseScmProductApplyDto.AdminSearchDto searchDto = new PurchaseScmProductApplyDto.AdminSearchDto();
                        BeanUtils.copyProperties(taskDto, searchDto);
                        if (!CollectionUtils.isEmpty(taskDto.getIds())) {
                            if (taskDto.getIds().contains("all")) {
                                searchDto.setIds(null);
                                num = -1;
                            } else {
                                searchDto.setIds(taskDto.getIds());
                                num = taskDto.getIds().size();
                            }
                        }
                        List<PurchaseScmProductApplyVo.AdminSearchVo> list = getAdminSearch(searchDto);
                        ByteArrayOutputStream ba = new ByteArrayOutputStream();
                        try {
                            adminAuditExport(ba, list, false);
                            // 这一步保存excel到oss
                            ByteArrayInputStream is = new ByteArrayInputStream(ba.toByteArray());
                            ossMaterialService.uploadResourceByIs(newPath, is);
                        } catch (Exception e) {
                            log.error("任务【" + message + "】执行失败：保存商品明细excel到oss失败：" + e);
                            executeStatus = "任务【" + message + "】执行失败：保存商品明细excel到oss失败：" + e.getMessage();
                        } finally {
                            IoUtil.close(ba);
                        }
                        if (CollectionUtils.isEmpty(list) || (num != -1 && num != list.size())) {
                            executeStatus = "任务【" + message + "】执行失败：已勾选商品不满足批量处理，请检查";
                        }
                        // 执行审核操作
                        if (StringUtils.isBlank(executeStatus)) {
                            switch (task.getType()) {
                                case "审核通过": {
                                    JsonResult result = adminApprove(list, taskDto.getApproveType(), task, requestParam.get("createName") + "");
                                    if (result.isSuccess()) {
                                        executeStatus = "";
                                    } else {
                                        executeStatus = "任务【" + message + "】执行失败：" + result.getMsg();
                                    }
                                    break;
                                }
                                case "审核驳回": {
                                    JsonResult result = adminReject(list, taskDto.getAuditRemark(), task, requestParam.get("createName") + "");
                                    if (result.isSuccess()) {
                                        executeStatus = "";
                                    } else {
                                        executeStatus = "任务【" + message + "】执行失败：" + result.getMsg();
                                    }
                                    break;
                                }
                                case "设置调货价": {
                                    JsonResult result = adminEditDistribute(list, taskDto.getDistributeDiscount(), taskDto.getDistributeCalcWay());
                                    if (result.isSuccess()) {
                                        executeStatus = "";
                                    } else {
                                        executeStatus = "任务【" + message + "】执行失败：" + result.getMsg();
                                    }
                                    break;
                                }
                            }
                        }
                    } else if (requestParam.getString("source").equals("商品池")) {
                        // 查询数据
                        int num = 0;
                        CommonProductTaskDto taskDto = JSONObject.parseObject(task.getRequestParam(), CommonProductTaskDto.class);
                        if (!CollectionUtils.isEmpty(taskDto.getIds())) {
                            if (taskDto.getIds().contains("all")) {
                                taskDto.setIds(null);
                                num = -1;
                            } else {
                                num = taskDto.getIds().size();
                            }
                        }
                        List<CommonProductVo> list = publicProductFeignClient.purchaseProductList(taskDto);
                        ByteArrayOutputStream ba = new ByteArrayOutputStream();
                        try {
                            // 写入excel
                            List<PurchaseScmProductApplyVo.AdminAuditExportVo> exportList = new ArrayList<>();
                            for (CommonProductVo l : list) {
                                PurchaseScmProductApplyVo.AdminAuditExportVo eL = new PurchaseScmProductApplyVo.AdminAuditExportVo();
                                BeanUtils.copyProperties(l, eL);
                                eL.setApplyNo(Long.parseLong(l.getApplyId()));
                                eL.setCompanyShortName(l.getSubCompany());
                                eL.setSupplierName(l.getSupplier());
                                exportList.add(eL);
                            }
                            new MultiTitleExportExcelUtil("商品明细", 18, MultiTitleExportExcelUtil.STYLE_TITLE3, PurchaseScmProductApplyVo.AdminAuditExportVo.class)
                                    .setDataListColWidth(exportList)
                                    .write(ba);
                            // 这一步保存excel到oss
                            ByteArrayInputStream is = new ByteArrayInputStream(ba.toByteArray());
                            ossMaterialService.uploadResourceByIs(newPath, is);
                        } catch (Exception e) {
                            log.error("任务【" + message + "】执行失败：保存商品明细excel到oss失败：" + e);
                            executeStatus = "任务【" + message + "】执行失败：保存商品明细excel到oss失败：" + e.getMessage();
                        } finally {
                            IoUtil.close(ba);
                        }
                        if (CollectionUtils.isEmpty(list) || (num != -1 && num != list.size())) {
                            executeStatus = "任务【" + message + "】执行失败：已勾选商品不满足批量处理，请检查";
                        }
                        // 执行审核操作
                        if (StringUtils.isBlank(executeStatus)) {
                            switch (task.getType()) {
                                case "设置调货价": {
                                    JsonResult result = adminCommonProductEditDistribute(list, taskDto.getDistributeDiscount(), taskDto.getDistributeCalcWay(), task);
                                    if (result.isSuccess()) {
                                        executeStatus = "";
                                    } else {
                                        executeStatus = "任务【" + message + "】执行失败：" + result.getMsg();
                                    }
                                    break;
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error("任务【" + message + "】执行失败：" + e);
                    executeStatus = "任务【" + message + "】执行失败：" + e.getMessage();
                }
            } else {
                if (task.getStatus().equals("1")) {
                    executeStatus = "任务【" + message + "】执行失败，当前任务正在执行";
                } else if (task.getStatus().equals("2")) {
                    executeStatus = "任务【" + message + "】执行失败，当前任务已执行完成";
                }
            }
        } else {
            executeStatus = "任务【" + message + "】执行失败，获取任务详情失败";
        }
        if (StringUtils.isBlank(executeStatus)) {
            // 更新任务状态为成功
            feignRequestParam = new JSONObject();
            feignRequestParam.put("id", message);
            feignRequestParam.put("status", "2");
            taskClient.taskUpdate(feignRequestParam);
        } else {
            // 更新任务状态为失败
            feignRequestParam = new JSONObject();
            feignRequestParam.put("id", message);
            feignRequestParam.put("status", "3");
            feignRequestParam.put("remark", executeStatus);
            taskClient.taskUpdate(feignRequestParam);
        }
    }

    /**
     * 处理商品导出的消息
     *
     * @param message
     * @Author loine
     * @Date 2025/12/13 14:07
     */
    public void readProductExportQueue(String message) {
        if (StringUtils.isBlank(message)) {
            return;
        }
        String executeStatus = "";
        String newPath = "taskDetail/excel/" + message + ".xlsx";
        // 获取任务信息
        JSONObject feignRequestParam = new JSONObject();
        feignRequestParam.put("id", message);
        JSONObject taskResult = taskClient.taskDetail(feignRequestParam);
        if (taskResult != null && taskResult.get("code") != null && taskResult.getInteger("code") == 0 && taskResult.get("data") != null) {
            TaskManageDto task = JSONObject.parseObject(taskResult.getJSONObject("data").toJSONString(), TaskManageDto.class);
            if (task.getStatus().equals("0") || task.getStatus().equals("3")) {
                // 更新任务状态为执行中
                feignRequestParam = new JSONObject();
                feignRequestParam.put("id", message);
                feignRequestParam.put("status", "1");
                feignRequestParam.put("resultType", "1");
                feignRequestParam.put("resultContent", ossConf.getOssUrl() + newPath);
                taskClient.taskUpdate(feignRequestParam);
                if (task.getType().equals("商品导出")) {
                    PurchaseScmProductApplyDto.AdminSearchDto searchDto = JSONObject.parseObject(task.getRequestParam(), PurchaseScmProductApplyDto.AdminSearchDto.class);
                    List<PurchaseScmProductApplyVo.AdminSearchVo> list = getAdminSearch(searchDto);
                    ByteArrayOutputStream ba = new ByteArrayOutputStream();
                    try {
                        adminAuditExport(ba, list, true);
                        // 这一步保存excel到oss
                        ByteArrayInputStream is = new ByteArrayInputStream(ba.toByteArray());
                        ossMaterialService.uploadResourceByIs(newPath, is);
                    } catch (Exception e) {
                        log.error("任务【" + message + "】执行失败：" + e);
                        executeStatus = "任务【" + message + "】执行失败：" + e.getMessage();
                    } finally {
                        IoUtil.close(ba);
                    }
                } else if (task.getType().equals("商品审核考核分析")) {
                    PurchaseScmProductApplyDto.AuditSumExportDto searchDto = JSONObject.parseObject(task.getRequestParam(), PurchaseScmProductApplyDto.AuditSumExportDto.class);
                    List<PurchaseScmProductApplyVo.AuditSumExportVo> list = purchaseScmProductApplyAuditSumMapper.export(searchDto);
                    int index = 1;
                    for (PurchaseScmProductApplyVo.AuditSumExportVo l : list) {
                        l.setIndex(index);
                        index++;
                    }
                    ByteArrayOutputStream ba = new ByteArrayOutputStream();
                    try {
                        new MultiTitleExportExcelUtil("数据分析", 18, MultiTitleExportExcelUtil.STYLE_TITLE4, PurchaseScmProductApplyVo.AuditSumExportVo.class)
                                .setDataListColWidth(list)
                                .write(ba);
                        // 这一步保存excel到oss
                        ByteArrayInputStream is = new ByteArrayInputStream(ba.toByteArray());
                        ossMaterialService.uploadResourceByIs(newPath, is);
                    } catch (Exception e) {
                        log.error("任务【" + message + "】执行失败：" + e);
                        executeStatus = "任务【" + message + "】执行失败：" + e.getMessage();
                    } finally {
                        IoUtil.close(ba);
                    }
                } else if (task.getType().equals("编码申请导出")) {
                    PurchaseScmErpProductCodeApplyDto.ErpAdminSearchDto searchDto = JSONObject.parseObject(task.getRequestParam(), PurchaseScmErpProductCodeApplyDto.ErpAdminSearchDto.class);
                    List<PurchaseScmErpProductCodeApplyVo.ErpAdminExportVo> list = purchaseScmErpProductCodeApplyService.adminExport(searchDto);
                    ByteArrayOutputStream ba = new ByteArrayOutputStream();
                    try {
                        new MultiTitleExportExcelUtil("编码申请", 18, MultiTitleExportExcelUtil.STYLE_TITLE4, PurchaseScmErpProductCodeApplyVo.ErpAdminExportVo.class)
                                .setDataListColWidth(list)
                                .write(ba);
                        // 这一步保存excel到oss
                        ByteArrayInputStream is = new ByteArrayInputStream(ba.toByteArray());
                        ossMaterialService.uploadResourceByIs(newPath, is);
                    } catch (Exception e) {
                        log.error("任务【" + message + "】执行失败：" + e);
                        executeStatus = "任务【" + message + "】执行失败：" + e.getMessage();
                    } finally {
                        IoUtil.close(ba);
                    }
                } else {
                    executeStatus = "任务【" + message + "】执行失败：类型有误";
                }
            } else {
                if (task.getStatus().equals("1")) {
                    executeStatus = "任务【" + message + "】执行失败，当前任务正在执行";
                } else if (task.getStatus().equals("2")) {
                    executeStatus = "任务【" + message + "】执行失败，当前任务已执行完成";
                }
            }
        } else {
            executeStatus = "任务【" + message + "】执行失败，获取任务详情失败";
        }
        if (StringUtils.isBlank(executeStatus)) {
            // 更新任务状态为成功
            feignRequestParam = new JSONObject();
            feignRequestParam.put("id", message);
            feignRequestParam.put("status", "2");
            taskClient.taskUpdate(feignRequestParam);
        } else {
            // 更新任务状态为失败
            feignRequestParam = new JSONObject();
            feignRequestParam.put("id", message);
            feignRequestParam.put("status", "3");
            feignRequestParam.put("remark", executeStatus);
            taskClient.taskUpdate(feignRequestParam);
        }
    }

    /**
     * 后台-商品池-批量设置调货价
     *
     * @param list
     * @param distributeDiscount
     * @param distributeCalcWay
     * @param task
     * @Author: loine
     * @Date: 2025/1/14 14:23
     */
    private JsonResult adminCommonProductEditDistribute(List<CommonProductVo> list, BigDecimal distributeDiscount, String distributeCalcWay, TaskManageDto task) {
        ZydExceptions.re(distributeDiscount == null || distributeCalcWay == null, "调货价折扣不能为空");
        LocalDateTime now = LocalDateTime.now();
        List<PurchaseScmProductApply> inserts = new ArrayList<>();
        List<PurchaseScmProductApply> updates = new ArrayList<>();
        List<PurchaseScmProductApplyChangeRecord> applyChangeRecords = new ArrayList<>();
        for (CommonProductVo l : list) {
            PurchaseScmProductApply applyOld = null;
            boolean isInsert = false;
            if (StringUtils.isNotBlank(l.getApplyId())) {
                // 先获取审核通过的这条数据（无审核通过的，说明是错误数据）
                Example example = new Example(entityClass);
                Example.Criteria criteria = example.createCriteria();
                criteria.andEqualTo(PurchaseScmProductApply.APPLY_NO, l.getApplyId());
                applyOld = purchaseScmProductApplyMapper.selectOneByExample(example);
                if (applyOld != null) {
                    // 再去判断有无待审核数据
                    example = new Example(entityClass);
                    criteria = example.createCriteria();
                    criteria.andEqualTo(PurchaseScmProductApply.SUPPLIER_ID, applyOld.getSupplierId());
                    criteria.andEqualTo(PurchaseScmProductApply.PRODUCT_TYPE, applyOld.getProductType());
                    criteria.andNotEqualTo(PurchaseScmProductApply.AUDIT_STATUS, 4);
                    PurchaseScmProductApply applyOld2 = purchaseScmProductApplyMapper.selectOneByExample(example);
                    if (applyOld2 != null) {
                        // 有待审核的数据，赋值
                        BeanUtils.copyProperties(applyOld2, applyOld);
                        if (applyOld.getAuditType() != 3 && applyOld.getAuditType() != 4) {
                            applyOld.setAuditType(4);
                        }
                    } else {
                        // 没有待审核的数据
                        applyOld.setAuditType(3);
                        applyOld.setAuditStatus(3);
                        isInsert = true;
                    }
                }
            }
            // 处理数据
            if (applyOld == null) {
                continue;
            }
            if (isInsert) {
                PurchaseScmProductApply applyNew = new PurchaseScmProductApply();
                BeanUtils.copyProperties(applyOld, applyNew);
                applyNew.setDistributeDiscount(distributeDiscount);
                applyNew.setDistributeCalcWay(distributeCalcWay);
                // 设置调货价
                setDistributePrice(applyNew);
                applyNew.setId(IDUtils.getUUID19());
                applyNew.setApplyNo(getMaxApplyNo());
                applyNew.setEditColumns("distribute_price");
                applyNew.setCreatedBy(task.getCreatedBy());
                applyNew.setCreatedAt(now);
                applyNew.setUpdatedBy(task.getCreatedBy());
                applyNew.setUpdatedAt(now);
                inserts.add(applyNew);
                // 添加变更记录
                PurchaseScmProductApplyChangeRecord changeRecord = new PurchaseScmProductApplyChangeRecord();
                changeRecord.setId(IDUtils.getUUID19());
                changeRecord.setApplyNo(applyNew.getApplyNo());
                changeRecord.setFieldCode("distribute_price");
                changeRecord.setFieldName(PurchaseScmProductApply.EDIT_COLUMN_MAP.get(changeRecord.getFieldCode()));
                if (applyOld.getDistributePrice() != null) {
                    changeRecord.setOldValue(applyOld.getDistributePrice().toString());
                }
                if (applyNew.getDistributePrice() != null) {
                    changeRecord.setNewValue(applyNew.getDistributePrice().toString());
                }
                changeRecord.setCreatedBy(task.getCreatedBy());
                changeRecord.setCreatedAt(now);
                changeRecord.setUpdatedBy(task.getCreatedBy());
                changeRecord.setUpdatedAt(now);
                String corpCode = ContextHandler.getCorpCode();
                if (StringUtils.isBlank(corpCode)) {
                    corpCode = "default";
                }
                changeRecord.setCorpCode(corpCode);
                applyChangeRecords.add(changeRecord);
            } else {
                applyOld.setDistributeDiscount(distributeDiscount);
                applyOld.setDistributeCalcWay(distributeCalcWay);
                BigDecimal oldDistributePrice = applyOld.getDistributePrice();
                // 设置调货价
                setDistributePrice(applyOld);
                String editColumns = applyOld.getEditColumns();
                if (StringUtils.isNoneBlank(editColumns)) {
                    if (!editColumns.contains("distribute_price")) {
                        editColumns += ",distribute_price";
                    }
                } else {
                    editColumns = "distribute_price";
                }
                applyOld.setEditColumns(editColumns);
                applyOld.setUpdatedBy(task.getCreatedBy());
                applyOld.setUpdatedAt(now);
                updates.add(applyOld);
                // 添加变更记录
                PurchaseScmProductApplyChangeRecord changeRecord = new PurchaseScmProductApplyChangeRecord();
                changeRecord.setId(IDUtils.getUUID19());
                changeRecord.setApplyNo(applyOld.getApplyNo());
                changeRecord.setFieldCode("distribute_price");
                changeRecord.setFieldName(PurchaseScmProductApply.EDIT_COLUMN_MAP.get(changeRecord.getFieldCode()));
                if (oldDistributePrice != null) {
                    changeRecord.setOldValue(oldDistributePrice.toString());
                }
                if (applyOld.getDistributePrice() != null) {
                    changeRecord.setNewValue(applyOld.getDistributePrice().toString());
                }
                changeRecord.setCreatedBy(task.getCreatedBy());
                changeRecord.setCreatedAt(now);
                changeRecord.setUpdatedBy(task.getCreatedBy());
                changeRecord.setUpdatedAt(now);
                applyChangeRecords.add(changeRecord);
            }
        }
        // 新增或修改申请数据
        List<PurchaseScmProductApply> details = new ArrayList<>();
        details.addAll(inserts);
        details.addAll(updates);
        Map<Integer, String> companyMap = getCompanyMap(details);
        for (PurchaseScmProductApply detail : details) {
            ZydExceptions.re(!isScm(companyMap.get(detail.getCompanyId())), "直供供应商不支持修改调货价，请检查");
        }
        if (inserts.size() > 0) {
            batchInsert(inserts);
            // 发送审核消息
            sendAuditMsg(inserts, now);
        }
        if (updates.size() > 0) {
            batchUpdate(updates);
            // 发送审核消息
            sendAuditMsg(updates, now);
        }
        if (applyChangeRecords.size() > 0) {
            for (PurchaseScmProductApplyChangeRecord applyChangeRecord : applyChangeRecords) {
                purchaseScmProductApplyChangeRecordMapper.insert(applyChangeRecord);
            }
        }
        return new JsonResult(true, "");
    }

    /**
     * 供应商-商品申请列表搜索
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/25 9:28
     */
    private List<PurchaseScmProductApplyVo.SupplierSearchVo> getSupplierApplySearch(PurchaseScmProductApplyDto.SupplierSearchDto dto) {
        String supplierId = (String) ContextHandler.get("supplierId");
        String corpCode = ContextHandler.getCorpCode();
        return purchaseScmProductApplyMapper.supplierApplySearch(dto, supplierId, corpCode);
    }

    /**
     * 供应商-我的商品列表搜索
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/25 9:28
     */
    private List<PurchaseScmProductApplyVo.SupplierMySearchVo> getSupplierMySearch(PurchaseScmProductApplyDto.SupplierMySearchDto dto) {
        String supplierId = (String) ContextHandler.get("supplierId");
        String corpCode = ContextHandler.getCorpCode();
        return purchaseScmProductApplyMapper.supplierMySearch(dto, supplierId, corpCode);
    }

    /**
     * 后台-商品审核列表搜索
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/25 9:46
     */
    private List<PurchaseScmProductApplyVo.AdminSearchVo> getAdminSearch(PurchaseScmProductApplyDto.AdminSearchDto dto) {
        String corpCode = ContextHandler.getCorpCode();
        if (StringUtils.isBlank(corpCode)) {
            corpCode = "default";
        }
        String companyShortName = (String) ContextHandler.get("companyShortName");
        if ("上海供应链公司".equals(companyShortName) || "众业达集团".equals(companyShortName)) {
            companyShortName = null;
        }
        return purchaseScmProductApplyMapper.adminSearch(dto, corpCode, companyShortName);
    }

    /**
     * 供应商获取商品申请详情
     *
     * @param id
     * @Author: loine
     * @Date: 2024/10/26 9:41
     */
    private PurchaseScmProductApply getDetail(String id) {
        String supplierId = (String) ContextHandler.get("supplierId");
        String corpCode = ContextHandler.getCorpCode();
        if (StringUtils.isBlank(corpCode)) {
            corpCode = "default";
        }
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(PurchaseScmProductApply.ID, id);
        criteria.andEqualTo(PurchaseScmProductApply.SUPPLIER_ID, supplierId);
        criteria.andEqualTo(PurchaseScmProductApply.CORP_CODE, corpCode);
        return purchaseScmProductApplyMapper.selectOneByExample(example);
    }

    /**
     * 获取公司信息
     *
     * @param details
     * @Author: loine
     * @Date: 2024/10/30 16:25
     */
    private Map<Integer, String> getCompanyMap(List<PurchaseScmProductApply> details) {
        Set<Integer> companyIds = details.stream().map(PurchaseScmProductApply::getCompanyId).collect(Collectors.toSet());
        List<PurchaseScmProductApplyVo.CompanyVo> companyVos = purchaseScmProductApplyMapper.getCompany(companyIds);
        return companyVos.stream().collect(Collectors.toMap(PurchaseScmProductApplyVo.CompanyVo::getCompanyId, PurchaseScmProductApplyVo.CompanyVo::getSubCompany, (c1, c2) -> c1));
    }

    /**
     * 处理申请数据
     *
     * @param applyOld
     * @param dtoNew
     * @param entrance
     * @Author: loine
     * @Date: 2024/10/29 11:13
     */
    private PurchaseScmProductApply handleApply(PurchaseScmProductApply applyOld, PurchaseScmProductApplyDto.SupplierPublishListDto dtoNew, String entrance) {
        String supplierId = (String) ContextHandler.get("supplierId");
        boolean isScm = isScm(null);
        PurchaseScmProductApply applyNew = new PurchaseScmProductApply();
        BeanUtils.copyProperties(dtoNew, applyNew);
        if (applyOld == null) {
            // 首次的流程新增
            if (isScm) {
                applyNew.setAuditType(1);
                applyNew.setAuditStatus(1);
            } else {
                applyNew.setAuditType(1);
                applyNew.setAuditStatus(2);
            }
        } else {
            if (applyOld.getPublicProductId() == null) {
                // 首次的流程修改
                Map<String, Object> editColumnMap = applyOld.ownCompare(applyNew, true);
                Set<String> notEquals = (Set<String>) editColumnMap.get("notEquals");
                Set<String> editSpec = (Set<String>) editColumnMap.get("editSpec");
                List<PurchaseScmProductApplyChangeRecord> changeRecords = (List<PurchaseScmProductApplyChangeRecord>) editColumnMap.get("changeRecords");
                // 没有修改数据的，直接跳过
                boolean isNewEdit = (boolean) editColumnMap.get("isNewEdit");
                if (!isNewEdit) {
                    return null;
                }
                applyNew.setAuditType(1);
                if (isScm) {
                    applyNew.setAuditStatus(1);
                } else {
                    applyNew.setAuditStatus(2);
                }
                applyNew.setEditColumns(notEquals.size() > 0 ? Joiner.on(",").join(notEquals) : "");
                applyNew.setEditSpecs(editSpec.size() > 0 ? Joiner.on(",").join(editSpec) : "");
                applyNew.setChangeRecords(changeRecords);
            } else {
                // 非首次的流程
                boolean isReadLastUpdate = true;
                if (entrance.equals("2")) {
                    // 我的商品的修改，不需获取之前修改的字段
                    isReadLastUpdate = false;
                }
                Map<String, Object> editColumnMap = applyOld.ownCompare(applyNew, isReadLastUpdate);
                Set<String> notEquals = (Set<String>) editColumnMap.get("notEquals");
                Set<String> editSpec = (Set<String>) editColumnMap.get("editSpec");
                List<PurchaseScmProductApplyChangeRecord> changeRecords = (List<PurchaseScmProductApplyChangeRecord>) editColumnMap.get("changeRecords");
                // 没有修改数据的，直接跳过
                boolean isNewEdit = (boolean) editColumnMap.get("isNewEdit");
                if (!isNewEdit) {
                    return null;
                }
                applyNew.setAuditType(Integer.parseInt(editColumnMap.get("auditType").toString()));
                if (isScm) {
                    applyNew.setAuditStatus(1);
                    if (applyNew.getAuditType() == 5) {
                        applyNew.setAuditStatus(2);
                    }
                } else {
                    applyNew.setAuditStatus(2);
                    if (applyNew.getAuditType() == 3) {
                        applyNew.setAuditStatus(3);
                    }
                }
                applyNew.setEditColumns(notEquals.size() > 0 ? Joiner.on(",").join(notEquals) : "");
                applyNew.setEditSpecs(editSpec.size() > 0 ? Joiner.on(",").join(editSpec) : "");
                applyNew.setChangeRecords(changeRecords);
                if (entrance.equals("2")) {
                    // 我的商品的修改，将产品id赋值给新申请数据
                    applyNew.setPublicProductId(applyOld.getPublicProductId());
                    Example example = new Example(entityClass);
                    example.orderBy(PurchaseScmProductApply.CREATED_AT).desc();
                    Example.Criteria criteria = example.createCriteria();
                    criteria.andEqualTo(PurchaseScmProductApply.SUPPLIER_ID, supplierId);
                    criteria.andEqualTo(PurchaseScmProductApply.PUBLIC_PRODUCT_ID, applyOld.getPublicProductId());
                    criteria.andNotEqualTo(PurchaseScmProductApply.AUDIT_STATUS, 4);
                    ZydExceptions.re(purchaseScmProductApplyMapper.selectCountByExample(example) > 0, "产品型号：" + applyNew.getProductType() + "，该商品已有申请记录，请到商品申请列表继续修改");
                }
            }
            // 重新设置调货价
            applyNew.setDistributePrice(applyOld.getDistributePrice());
            applyNew.setDistributeDiscount(applyOld.getDistributeDiscount());
            applyNew.setDistributeCalcWay(applyOld.getDistributeCalcWay());
            // 设置调货价
            setDistributePrice(applyNew);
        }
        return applyNew;
    }

    /**
     * 公共取消
     *
     * @param cancels
     * @param userId
     * @param doSomethings
     * @Author: loine
     * @Date: 2025/2/20 10:44
     */
    private List<PurchaseScmProductApply> commonCancel(List<PurchaseScmProductApplyDto.SupplierPublishCancelDto> cancels, String userId, Set<String> doSomethings) {
        if (!CollectionUtils.isEmpty(cancels)) {
            // 取消列表
            List<PurchaseScmProductApply> cancelDetails = new ArrayList<>();
            // 审核时间
            LocalDateTime auditTime = LocalDateTime.now();
            // 审核记录
            List<PurchaseScmProductApplyAuditRecord> auditRecords = new ArrayList<>();
            for (PurchaseScmProductApplyDto.SupplierPublishCancelDto cancelDto : cancels) {
                PurchaseScmProductApply detail = getDetail(cancelDto.getId());
                if (detail != null) {
                    if (detail.getAuditStatus() == 1 || detail.getAuditStatus() == 2 || detail.getAuditStatus() == 3) {
                        int auditStatusBefore = detail.getAuditStatus();
                        detail.setAuditStatus(5);
                        detail.setCancelTime(auditTime);
                        detail.setAuditRemark(cancelDto.getAuditRemark());
                        cancelDetails.add(detail);
                        auditRecords.add(getAuditRecord(detail, auditStatusBefore, auditTime, userId));
                        if (doSomethings != null) {
                            if (auditStatusBefore == 2) {
                                doSomethings.add("资料审核");
                            } else {
                                doSomethings.add("价格审核");
                            }
                        }
                    } else {
                        if (cancels.size() > 1) {
                            ZydExceptions.re(true, "已勾选商品不满足批量处理，请检查");
                        } else {
                            ZydExceptions.re(true, "商品状态已变更，请检查");
                        }
                    }
                }
            }
            if (cancelDetails.size() > 0) {
                batchUpdate(cancelDetails);
            }
            if (auditRecords.size() > 0) {
                for (PurchaseScmProductApplyAuditRecord auditRecord : auditRecords) {
                    purchaseScmProductApplyAuditRecordMapper.insert(auditRecord);
                }
            }
            return cancelDetails;
        }
        return new LinkedList<>();
    }

    /**
     * 判断是否分部供应商（true为分部，false为直供）
     *
     * @Author: loine
     * @Date: 2024/12/18 16:29
     */
    private boolean isScm(String companyShortName) {
        if (companyShortName == null) {
            companyShortName = (String) ContextHandler.get("companyShortName");
        }
        // 是否分部供应商
        return !"上海供应链公司".equals(companyShortName);
    }

    /**
     * 获取最大申请编码+1
     *
     * @return
     */
    private Long getMaxApplyNo() {
        Long num = RedisUtils.genCode("scm_apply_no", redisTemplate, () -> {
            return purchaseScmProductApplyMapper.getMaxApplyNo();
        });
        try {
            DecimalFormat df = new DecimalFormat("000000000");
            String numTemp = "8" + df.format(num);
            num = Long.parseLong(numTemp);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return num;
    }

    /**
     * 获取最大货期id+1
     *
     * @return
     */
    private Long getMaxDeliveryId() {
        Long num = RedisUtils.genCode("scm_delivery_id", redisTemplate, () -> {
            return purchaseDeliveryDateMapper.getMaxDeliveryId();
        });
        return num + 1;
    }

    /**
     * 处理图片和视频
     *
     * @param applyNew
     * @Author: loine
     * @Date: 2024/10/23 17:54
     */
    private void handleImageVideo(PurchaseScmProductApply applyNew) {
        String path = "/" + applyNew.getBrandName() + "/" + applyNew.getFirstLevelCataName() + "/" + applyNew.getSecondLevelCataName() + "/" + applyNew.getThreeLevelCataName() + "/" + (StringUtils.isNotBlank(applyNew.getPropName()) ? applyNew.getPropName() : "暂无系列");
        if (StringUtils.isNotBlank(applyNew.getProductPicName())) {
            StringBuilder sb = new StringBuilder();
            String[] picNames = applyNew.getProductPicName().split("@");
            for (String picName : picNames) {
                if (picName.contains("http://") || picName.contains("https")) {
                    String result = ossMaterialService.scmUploadResourceByUrl(path + "/产品主图/", picName);
                    sb.append(result).append("@");
                } else {
                    sb.append(picName).append("@");
                }
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
            }
            applyNew.setProductPicName(sb.toString());
        }
        if (StringUtils.isNotBlank(applyNew.getProductVideoName())) {
            StringBuilder sb = new StringBuilder();
            String[] videoNames = applyNew.getProductVideoName().split("@");
            for (String videoName : videoNames) {
                if (videoName.contains("http://") || videoName.contains("https")) {
                    String result = ossMaterialService.scmUploadResourceByUrl(path + "/产品主图/", videoName);
                    sb.append(result).append("@");
                } else {
                    sb.append(videoName).append("@");
                }
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
            }
            applyNew.setProductVideoName(sb.toString());
        }
        if (StringUtils.isNotBlank(applyNew.getProductContentPicName())) {
            StringBuilder sb = new StringBuilder();
            String[] picNames = applyNew.getProductContentPicName().split("@");
            for (String picName : picNames) {
                if (picName.contains("http://") || picName.contains("https")) {
                    String result = ossMaterialService.scmUploadResourceByUrl(path + "/产品主图/", picName);
                    sb.append(result).append("@");
                } else {
                    sb.append(picName).append("@");
                }
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
            }
            applyNew.setProductContentPicName(sb.toString());
        }
    }

    /**
     * 格式化价格
     *
     * @param bigDecimalObject
     * @Author: loine
     * @Date: 2024/10/15 13:00
     */
    private String formatBigDecimalData(Object bigDecimalObject) {
        if (bigDecimalObject == null) {
            return "";
        }
        BigDecimal bigDecimal;
        if (bigDecimalObject instanceof String) {
            if (StringUtils.isBlank(bigDecimalObject.toString())) {
                return "";
            }
            bigDecimal = new BigDecimal(bigDecimalObject.toString());
        } else if (bigDecimalObject instanceof BigDecimal) {
            bigDecimal = (BigDecimal) bigDecimalObject;
        } else {
            return "";
        }
        // 获取实际小数位数
        String plainStr = bigDecimal.setScale(4, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
        int decimals = plainStr.contains(".") ? plainStr.split("\\.")[1].length() : 0;
        // 限制小数位数在0-4之间
        decimals = Math.min(decimals, 4);
        return String.format("%." + (decimals <= 1 ? 2 : decimals) + "f", bigDecimal);
    }

    /**
     * 图片、视频资源转为全路径
     *
     * @param originNames
     * @Author: loine
     * @Date: 2024/10/31 10:55
     */
    private String changeToFullUrl(String... originNames) {
        if (originNames != null && originNames.length > 0) {
            StringBuilder sb = new StringBuilder();
            for (String originName : originNames) {
                if (StringUtils.isBlank(originName)) {
                    continue;
                }
                String[] names = originName.split("@");
                for (String name : names) {
                    if (name.contains("http://") || name.contains("https")) {
                        sb.append(name).append("@");
                    } else {
                        sb.append(ossConf.getOssUrl()).append(name).append("@");
                    }
                }
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
            }
            return sb.toString();
        }
        return "";
    }

    /**
     * 返回强制缩放图片的地址
     *
     * @param originImageName
     * @Author: loine
     * @Date: 2025/2/24 15:55
     */
    private String resizeImage(String originImageName) {
        if (StringUtils.isNotBlank(originImageName)) {
            StringJoiner sj = new StringJoiner("@");
            String[] names = originImageName.split("@");
            for (String name : names) {
                if (name.contains("?")) {
                    sj.add(name);
                } else {
                    sj.add(name + "?x-oss-process=image/resize,m_pad,w_800,h_800");
                }
            }
            return sj.toString();
        }
        return "";
    }

    /**
     * 处理导出规格
     *
     * @param specData
     * @Author: loine
     * @Date: 2024/10/31 11:03
     */
    private String handleExportSpec(String specData) {
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotBlank(specData)) {
            JSONArray specArray = JSONArray.parseArray(specData);
            if (specArray.size() > 0) {
                for (int i = 0; i < specArray.size(); i++) {
                    JSONObject spec = specArray.getJSONObject(i);
                    if (spec != null) {
                        if (spec.get("specName") != null && spec.get("specValue") != null) {
                            sb.append(spec.get("specName")).append("=").append(spec.get("specValue")).append("@");
                        }
                    }
                }
                if (sb.toString().length() > 0) {
                    sb.deleteCharAt(sb.length() - 1);
                }
            }
        }
        return sb.toString();
    }

    /**
     * 处理同步公海的规格数据
     *
     * @param specData
     * @Author: loine
     * @Date: 2024/11/11 13:42
     */
    private String handleSyncCommonSpec(String specData) {
        JSONArray newSpecArray = new JSONArray();
        if (StringUtils.isNotBlank(specData)) {
            JSONArray specArray = JSONArray.parseArray(specData);
            if (specArray.size() > 0) {
                for (int i = 0; i < specArray.size(); i++) {
                    JSONObject spec = specArray.getJSONObject(i);
                    if (spec != null) {
                        if (spec.get("specName") != null && spec.get("specValue") != null) {
                            JSONObject newSpec = new JSONObject();
                            newSpec.put("spec", spec.get("specName"));
                            newSpec.put("specValue", spec.get("specValue"));
                            newSpecArray.add(newSpec);
                        }
                    }
                }
            }
        }
        return newSpecArray.toJSONString();
    }

    /**
     * 处理规格按公海排序
     *
     * @param firstLevelCataName
     * @param secondLevelCataName
     * @param threeLevelCataName
     * @param specData
     * @Author: loine
     * @Date: 2024/12/12 13:10
     */
    private String handleSpecToCommonSort(String firstLevelCataName, String secondLevelCataName, String threeLevelCataName, String specData) {
        JSONArray newSpecArray = new JSONArray();
        if (StringUtils.isNotBlank(specData)) {
            JSONArray specArray = JSONArray.parseArray(specData);
            if (specArray.size() > 0) {
                // 获取公海规格
                List<PurchaseScmProductApplyVo.CommonSpecVo> commonSpecs = purchaseScmProductApplyMapper.getCommonSpec(firstLevelCataName, secondLevelCataName, threeLevelCataName);
                for (PurchaseScmProductApplyVo.CommonSpecVo commonSpec : commonSpecs) {
                    for (int i = 0; i < specArray.size(); i++) {
                        JSONObject spec = specArray.getJSONObject(i);
                        if (spec != null) {
                            if (commonSpec.getSpecName().equals(spec.get("specName"))) {
                                JSONObject newSpec = new JSONObject();
                                newSpec.put("specName", spec.get("specName"));
                                newSpec.put("specValue", spec.get("specValue"));
                                newSpecArray.add(newSpec);
                            }
                        }
                    }
                }
            }
        }
        return newSpecArray.toJSONString();
    }

    /**
     * 处理规格转成规格名和规格值的两个独立字段
     *
     * @param specData
     * @Author: loine
     * @Date: 2025/3/14 15:59
     */
    private Map<String, String> handleSpecToTwoColumn(String specData) {
        Map<String, String> newSpec = new HashMap<>();
        newSpec.put("specName", "");
        newSpec.put("specValue", "");
        if (StringUtils.isNotBlank(specData)) {
            JSONArray specArray = JSONArray.parseArray(specData);
            if (specArray.size() > 0) {
                StringJoiner specName = new StringJoiner("@");
                StringJoiner specValue = new StringJoiner("@");
                for (int i = 0; i < specArray.size(); i++) {
                    JSONObject spec = specArray.getJSONObject(i);
                    if (spec != null) {
                        if (spec.get("specName") != null) {
                            specName.add(spec.get("specName").toString());
                        }
                        if (spec.get("specValue") != null) {
                            specValue.add(spec.get("specValue").toString());
                        }
                    }
                }
                newSpec.put("specName", specName.toString());
                newSpec.put("specValue", specValue.toString());
            }
        }
        return newSpec;
    }

    /**
     * 转换修改字段信息为中文名称
     *
     * @param editColumns
     * @param editSpecs
     * @Author: loine
     * @Date: 2025/1/20 17:12
     */
    private String changeEditDetailToCn(String editColumns, String editSpecs) {
        if (StringUtils.isNotBlank(editColumns)) {
            StringBuilder sb = new StringBuilder();
            for (String editColumn : editColumns.split(",")) {
                String cn = PurchaseScmProductApply.EDIT_COLUMN_MAP.get(editColumn);
                if (StringUtils.isNotBlank(cn)) {
                    if (editColumn.contains("spec_data")) {
                        sb.append(cn).append("（").append(editSpecs).append("）、");
                    } else {
                        sb.append(cn).append("、");
                    }
                }
            }
            if (sb.toString().length() > 0) {
                sb.deleteCharAt(sb.toString().length() - 1);
            }
            return sb.toString();
        }
        return "";
    }

    /**
     * 发送审核消息
     *
     * @param list
     * @param time
     * @Author: loine
     * @Date: 2024/11/13 13:44
     */
    private void sendAuditMsg(List<PurchaseScmProductApply> list, LocalDateTime time) {
        Map<String, List<PurchaseScmProductApply>> applyMap = list.stream().collect(Collectors.groupingBy(l -> l.getSupplierId() + "_" + l.getAuditStatus()));
        for (List<PurchaseScmProductApply> applies : applyMap.values()) {
            Integer auditStatus = applies.get(0).getAuditStatus();
            String supplierId = applies.get(0).getSupplierId();
            Integer companyId = applies.get(0).getCompanyId();
            String corpCode = ContextHandler.getCorpCode();
            if (StringUtils.isBlank(corpCode)) {
                corpCode = "default";
            }
            // 获取供应商信息及全数据、各状态数量
            PurchaseScmProductApplyVo.SupplierVo supplierVo = purchaseScmProductApplyMapper.getSupplierInfo(supplierId);
            PurchaseScmProductApplyDto.SupplierSearchDto searchDto = new PurchaseScmProductApplyDto.SupplierSearchDto();
            searchDto.setAuditStatus(auditStatus);
            List<PurchaseScmProductApplyVo.SupplierSearchVo> applyAlls = purchaseScmProductApplyMapper.supplierApplySearch(searchDto, supplierId, corpCode);
            PurchaseScmProductApplyVo.SearchCountVo countVo = purchaseScmProductApplyMapper.supplierSearchCount(new PurchaseScmProductApplyDto.SupplierSearchDto(), supplierId, corpCode);
            if (supplierVo != null && applyAlls != null && countVo != null) {
                // 按品牌分组
                StringJoiner applyBrandStr = new StringJoiner("/");
                Map<String, List<PurchaseScmProductApplyVo.SupplierSearchVo>> applyBrandMap = applyAlls.stream()
                        .sorted(Comparator.comparing(PurchaseScmProductApplyVo.SupplierSearchVo::getCreatedAt))
                        .collect(Collectors.groupingBy(PurchaseScmProductApplyVo.SupplierSearchVo::getBrandName, LinkedHashMap::new, Collectors.toList()));
                if (applyBrandMap.size() == 1) {
                    applyBrandStr.add(applyBrandMap.keySet().iterator().next());
                } else {
                    applyBrandMap.forEach((brandName, l) ->
                            applyBrandStr.add(brandName + "（" + l.size() + "个）")
                    );
                }
                TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
                triggerMsgRequest.setBusiness("scmProduct");
                String mainTitleText = "您有新的商品待审核（国内SCM）";
                String emphasisTitleText = "待审核：";
                String status;
                String scene;
                int num;
                // 企业微信参数
                JSONObject qywxParam = new JSONObject();
                if (auditStatus == 1) {
                    status = "待分部审核";
                    scene = "productApplyBranch";
                    num = countVo.getAuditStatus1();
                    List<PurchaseMsgCompanyUser> companyUsers = purchaseMsgCompanyUserMapper.selectByCompanyId(companyId);
                    if (!CollectionUtils.isEmpty(companyUsers)) {
                        List<String> userCodes = companyUsers.stream().map(PurchaseMsgCompanyUser::getUserCode).collect(Collectors.toList());
                        qywxParam.put("noticeUser", String.join(",", userCodes));
                    }
                } else if (auditStatus == 2) {
                    status = "待资料审核";
                    scene = "productApplyData";
                    num = countVo.getAuditStatus2();
                } else if (auditStatus == 3) {
                    status = "待价格审核";
                    scene = "productApplyPrice";
                    num = countVo.getAuditStatus3();
                } else if (auditStatus == 4) {
                    // 首次商品新增审核通过通知上架处理
                    if (applies.get(0).getAuditType() == 1) {
                        mainTitleText = "商品待上架zydmall（国内SCM）";
                        emphasisTitleText = "待处理：";
                        status = "审核通过";
                        scene = "productApplyApproveToZydmall";
                        num = countVo.getAuditStatus4();
                    } else {
                        return;
                    }
                } else {
                    return;
                }
                triggerMsgRequest.setScene(scene);

                qywxParam.put("msgtype", "template_card");
                JSONObject templateCard = new JSONObject();
                templateCard.put("card_type", "text_notice");
                JSONObject mainTitle = new JSONObject();
                mainTitle.put("title", mainTitleText);
                mainTitle.put("desc", status);
                templateCard.put("main_title", mainTitle);
                List<JSONObject> horizontalContentList = new ArrayList<>();
                JSONObject keyName1 = new JSONObject();
                keyName1.put("keyname", "供应商名称");
                keyName1.put("value", supplierVo.getName());
                horizontalContentList.add(keyName1);
                JSONObject keyName2 = new JSONObject();
                keyName2.put("keyname", "登录账号");
                keyName2.put("value", supplierVo.getLoginName());
                horizontalContentList.add(keyName2);
                JSONObject keyName3 = new JSONObject();
                keyName3.put("keyname", "创建时间");
                keyName3.put("value", ZydDateUtils.format(ZydDateUtils.ymdhmsSlant, Date.from(time.atZone(ZoneId.systemDefault()).toInstant())));
                horizontalContentList.add(keyName3);
                JSONObject keyName4 = new JSONObject();
                keyName4.put("keyname", "待审核品牌");
                keyName4.put("value", applyBrandStr.toString());
                horizontalContentList.add(keyName4);
                templateCard.put("horizontal_content_list", horizontalContentList);

                JSONObject emphasisContent = new JSONObject();
                emphasisContent.put("title", emphasisTitleText + num + "个");
                emphasisContent.put("desc", "");
                templateCard.put("emphasis_content", emphasisContent);

                List<JSONObject> jumpList = new ArrayList<>();
                JSONObject jumpList1 = new JSONObject();
                jumpList1.put("type", 1);
                jumpList1.put("title", "跳转运营管理后台");
                jumpList1.put("url", odsUrl + "/#/scm/admin/product/apply?auditStatus=" + URLUtil.encode(auditStatus + "") + "&supplierId=" + URLUtil.encode(supplierId));
                jumpList.add(jumpList1);
                templateCard.put("jump_list", jumpList);

                JSONObject cardAction = new JSONObject();
                cardAction.put("type", 1);
                cardAction.put("url", odsUrl + "/#/scm/admin/product/apply?auditStatus=" + URLUtil.encode(auditStatus + "") + "&supplierId=" + URLUtil.encode(supplierId));
                templateCard.put("card_action", cardAction);
                qywxParam.put("template_card", templateCard);
                triggerMsgRequest.setQywxParam(qywxParam);

                try {
                    log.error("商品申请业务消息发送入参：" + JSONObject.toJSONString(triggerMsgRequest));
                    msgClient.triggerMsg(triggerMsgRequest);
                } catch (Exception e) {
                    log.error("商品申请业务消息发送异常：" + e);
                }
            }
        }
    }

    /**
     * 发送上架zydmall的商品，信息修改消息
     *
     * @param fileUrl
     * @Author: loine
     * @Date: 2025/1/20 17:01
     */
    private void sendAuditZydmallErpMsg(String fileUrl) {
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("scmProduct");
        triggerMsgRequest.setScene("scmZydmallListUpdate");
        JSONObject qywxParam = new JSONObject();
        qywxParam.put("msgtype", "text");
        qywxParam.put("text", new JSONObject() {{
            put("content", "标记上架zydmall的SCM商品资料已变更，请尽快到ODS做对应数据变更。");
        }});
        triggerMsgRequest.setQywxParam(qywxParam);
        try {
            log.error("上架zydmall的商品，信息修改消息发送1入参：" + JSONObject.toJSONString(triggerMsgRequest));
            msgClient.triggerMsg(triggerMsgRequest);
        } catch (Exception e) {
            log.error("上架zydmall的商品，信息修改消息发送1异常：" + e);
        }
        qywxParam = new JSONObject();
        qywxParam.put("msgtype", "file");
        qywxParam.put("fileUrl", fileUrl);
        qywxParam.put("fileName", "上架zydmall商品数据变更.xlsx");
        triggerMsgRequest.setQywxParam(qywxParam);
        try {
            log.error("上架zydmall的商品，信息修改消息发送2入参：" + JSONObject.toJSONString(triggerMsgRequest));
            msgClient.triggerMsg(triggerMsgRequest);
        } catch (Exception e) {
            log.error("上架zydmall的商品，信息修改发送2异常：" + e);
        }
    }

    /**
     * 根据字段名获取字段值
     *
     * @param obj
     * @param fieldName
     * @Author: loine
     * @Date: 2025/2/11 10:55
     */
    private Object getFieldValue(Object obj, String fieldName) {
        try {
            Class<?> clazz = obj.getClass();
            Field field = clazz.getDeclaredField(fieldName);
            field.setAccessible(true); // 设置访问权限
            return field.get(obj);
        } catch (Exception e) {
            log.error("根据字段名获取字段值异常：" + e);
            return null;
        }
    }

    /**
     * 生成审核记录
     *
     * @param detail
     * @param auditStatusBefore
     * @param auditTime
     * @param userId
     * @Author: loine
     * @Date: 2025/2/20 10:53
     */
    private PurchaseScmProductApplyAuditRecord getAuditRecord(PurchaseScmProductApply detail, int auditStatusBefore, LocalDateTime auditTime, String userId) {
        PurchaseScmProductApplyAuditRecord record = new PurchaseScmProductApplyAuditRecord();
        record.setId(IDUtils.getUUID19());
        record.setApplyNo(detail.getApplyNo());
        record.setAuditStatusBefore(auditStatusBefore);
        record.setAuditStatusAfter(detail.getAuditStatus());
        record.setAuditTime(auditTime);
        record.setAuditRemark(detail.getAuditRemark());
        record.setCreatedBy(userId);
        record.setCreatedAt(LocalDateTime.now());
        record.setUpdatedBy(userId);
        record.setUpdatedAt(LocalDateTime.now());
        String corpCode = ContextHandler.getCorpCode();
        if (StringUtils.isBlank(corpCode)) {
            corpCode = "default";
        }
        record.setCorpCode(corpCode);
        return record;
    }

    /**
     * 处理产品名称（产品名称为空，需要按商城拼接）
     *
     * @param detailVo
     * @Author: loine
     * @Date: 2025/4/15 16:41
     */
    private void handleMaterialName(PurchaseScmProductApplyVo.SupplierDetailVo detailVo) {
        CorpHelper.skipCorpCode(true);
        String isShowProp = purchaseScmProductApplyMapper.getCommonCataIsShowProp(detailVo.getFirstLevelCataName(), detailVo.getSecondLevelCataName(), detailVo.getThreeLevelCataName());
        if (StringUtils.isBlank(isShowProp)) {
            isShowProp = "N";
        }
        if (StringUtils.isBlank(detailVo.getMaterialName())) {
            String cataName = detailVo.getThreeLevelCataName();
            String brandName = detailVo.getBrandName();
            String propName = detailVo.getPropName();
            if (StringUtils.isNotBlank(propName) && isShowProp.equalsIgnoreCase("Y")) {
                detailVo.setMaterialName(brandName + " " + propName + " " + cataName);
            } else {
                detailVo.setMaterialName(brandName + " " + cataName);
            }
        }
        detailVo.setCataIsShowProp(isShowProp);
    }

    /**
     * 设置调货价
     *
     * @param detail
     * @Author loine
     * @Date 2025/8/25 11:01
     */
    private void setDistributePrice(PurchaseScmProductApply detail) {
        if (detail.getDistributeCalcWay() != null && detail.getDistributeDiscount() != null) {
            if (detail.getSupplyPrice() != null) {
                if (detail.getDistributeCalcWay().equals("*")) {
                    detail.setDistributePrice(detail.getSupplyPrice().multiply(detail.getDistributeDiscount()).setScale(4, RoundingMode.DOWN));
                } else if (detail.getDistributeCalcWay().equals("/")) {
                    detail.setDistributePrice(detail.getSupplyPrice().divide(detail.getDistributeDiscount(), 4, RoundingMode.DOWN));
                }
            } else {
                detail.setDistributePrice(null);
            }
        }
    }

    /**
     * 添加审核统计
     *
     * @param applies
     * @param applyChangeRecords
     * @param now
     * @param userId
     * @param createName
     * @param doSomethings
     * @Author loine
     * @Date 2025/12/15 15:31
     */
    private void addAuditSum(List<PurchaseScmProductApply> applies, List<PurchaseScmProductApplyChangeRecord> applyChangeRecords, LocalDateTime now, String userId, String createName, Set<String> doSomethings) {
        if (!applies.isEmpty()) {
            if (doSomethings != null) {
                if (!doSomethings.isEmpty()) {
                    Map<String, List<PurchaseScmProductApply>> applyMap = applies.stream().collect(Collectors.groupingBy(a -> a.getSupplierId() + "_" + a.getBrandName()));
                    String type;
                    for (String key : applyMap.keySet()) {
                        List<PurchaseScmProductApply> temps = applyMap.get(key);
                        // 获取供应商信息及全数据、各状态数量
                        String supplierId = temps.get(0).getSupplierId();
                        PurchaseScmProductApplyVo.SupplierVo supplierVo = purchaseScmProductApplyMapper.getSupplierInfo(supplierId);
                        String supplierName = supplierVo.getName();
                        // 新增
                        PurchaseScmProductApplyAuditSum applyAuditSum = new PurchaseScmProductApplyAuditSum();
                        applyAuditSum.setId(IDUtils.getUUID19());
                        applyAuditSum.setDoName(createName);
                        applyAuditSum.setDoTime(now);
                        if (doSomethings.contains("价格审核") && !doSomethings.contains("资料审核")) {
                            applyAuditSum.setDoSomething("价格审核");
                            type = "审核价格";
                        } else {
                            applyAuditSum.setDoSomething("资料审核");
                            type = "审核数据";
                        }
                        applyAuditSum.setResultNum(applies.size());
                        Integer num = purchaseScmProductApplyAuditSumMapper.getLastResultNum(supplierId, applies.get(0).getBrandName());
                        if (num == null) {
                            num = 0;
                        }
                        applyAuditSum.setResultContent("应审核" + num + "个产品");
                        applyAuditSum.setBrandName(applies.get(0).getBrandName());
                        applyAuditSum.setSupplierId(supplierId);
                        applyAuditSum.setSupplierName(supplierName);
                        if (applies.get(0).getAuditStatus() == 1) {
                            applyAuditSum.setStatus("待分部审核");
                        } else if (applies.get(0).getAuditStatus() == 2) {
                            applyAuditSum.setStatus("待资料审核");
                        } else if (applies.get(0).getAuditStatus() == 3) {
                            applyAuditSum.setStatus("待价格审核");
                        } else if (applies.get(0).getAuditStatus() == 4) {
                            applyAuditSum.setStatus("审核通过");
                        } else if (applies.get(0).getAuditStatus() == 5) {
                            applyAuditSum.setStatus("审核驳回");
                        }
                        applyAuditSum.setType(type);
                        applyAuditSum.setCreatedBy(userId);
                        applyAuditSum.setCreatedAt(now);
                        applyAuditSum.setUpdatedBy(userId);
                        applyAuditSum.setUpdatedAt(now);
                        String corpCode = ContextHandler.getCorpCode();
                        if (StringUtils.isBlank(corpCode)) {
                            corpCode = "default";
                        }
                        applyAuditSum.setCorpCode(corpCode);
                        purchaseScmProductApplyAuditSumMapper.insert(applyAuditSum);
                    }
                }
            } else {
                String supplierId = (String) ContextHandler.get("supplierId");
                String supplierName = (String) ContextHandler.get("name");
                Set<Integer> auditTypes = applies.stream().map(PurchaseScmProductApply::getAuditType).collect(Collectors.toSet());
                // 新增
                PurchaseScmProductApplyAuditSum applyAuditSum = new PurchaseScmProductApplyAuditSum();
                applyAuditSum.setId(IDUtils.getUUID19());
                applyAuditSum.setDoName(createName);
                applyAuditSum.setDoTime(now);
                if (auditTypes.contains(1)) {
                    applyAuditSum.setDoSomething("商品新增");
                } else {
                    if (auditTypes.contains(3) && !auditTypes.contains(2) && !auditTypes.contains(4) && !auditTypes.contains(5)) {
                        applyAuditSum.setDoSomething("价格修改");
                    } else if (auditTypes.contains(5) && !auditTypes.contains(2) && !auditTypes.contains(3) && !auditTypes.contains(4)) {
                        applyAuditSum.setDoSomething("图片修改");
                    } else if (auditTypes.contains(2) && !auditTypes.contains(3) && !auditTypes.contains(4)) {
                        applyAuditSum.setDoSomething("资料修改");
                    } else {
                        applyAuditSum.setDoSomething("资料价格修改");
                    }
                }
                Integer num = purchaseScmProductApplyMapper.getSupplierBrandAuditNum(supplierId, applies.get(0).getBrandName());
                if (num == null) {
                    num = 0;
                }
                applyAuditSum.setResultNum(num);
                if (auditTypes.contains(1)) {
                    if (applyChangeRecords.isEmpty()) {
                        applyAuditSum.setResultContent("新增" + applies.size() + "个产品");
                    } else {
                        Set<String> changeFieldNames = applyChangeRecords.stream().map(PurchaseScmProductApplyChangeRecord::getFieldName).collect(Collectors.toSet());
                        applyAuditSum.setResultContent("修改" + applies.size() + "个产品，" + String.join(",", changeFieldNames));
                    }
                } else {
                    Set<String> changeFieldNames = applyChangeRecords.stream().map(PurchaseScmProductApplyChangeRecord::getFieldName).collect(Collectors.toSet());
                    applyAuditSum.setResultContent("修改" + applies.size() + "个产品，" + String.join(",", changeFieldNames));
                }
                applyAuditSum.setBrandName(applies.get(0).getBrandName());
                applyAuditSum.setSupplierId(supplierId);
                applyAuditSum.setSupplierName(supplierName);
                if (applies.get(0).getAuditStatus() == 1) {
                    applyAuditSum.setStatus("待分部审核");
                } else if (applies.get(0).getAuditStatus() == 2) {
                    applyAuditSum.setStatus("待资料审核");
                } else if (applies.get(0).getAuditStatus() == 3) {
                    applyAuditSum.setStatus("待价格审核");
                } else if (applies.get(0).getAuditStatus() == 4) {
                    applyAuditSum.setStatus("审核通过");
                } else if (applies.get(0).getAuditStatus() == 5) {
                    applyAuditSum.setStatus("审核驳回");
                }
                applyAuditSum.setType("提报数据");
                applyAuditSum.setCreatedBy(userId);
                applyAuditSum.setCreatedAt(now);
                applyAuditSum.setUpdatedBy(userId);
                applyAuditSum.setUpdatedAt(now);
                String corpCode = ContextHandler.getCorpCode();
                if (StringUtils.isBlank(corpCode)) {
                    corpCode = "default";
                }
                applyAuditSum.setCorpCode(corpCode);
                purchaseScmProductApplyAuditSumMapper.insert(applyAuditSum);
            }
        }
    }

    /**
     * 组装规格单位
     *
     * @param firstLevelCataName
     * @param secondLevelCataName
     * @param threeLevelCataName
     * @Author loine
     * @Date 2026/4/10 15:19
     */
    private Map<String, String> assembleSpecUnit(String firstLevelCataName, String secondLevelCataName, String threeLevelCataName) {
        List<String> specNames = new ArrayList<>();
        Map<String, String> specNameMap = new LinkedHashMap<>();
        CorpHelper.skipCorpCode(true);
        List<PurchaseScmProductApplyVo.CommonSpecVo> commonSpecs = purchaseScmProductApplyMapper.getCommonSpec(firstLevelCataName, secondLevelCataName, threeLevelCataName);
        for (PurchaseScmProductApplyVo.CommonSpecVo commonSpec : commonSpecs) {
            if (StringUtils.isNotBlank(commonSpec.getSpecUnit())) {
                specNameMap.put(commonSpec.getSpecName() + "（" + commonSpec.getSpecUnit() + "）", commonSpec.getSpecName());
            } else {
                specNameMap.put(commonSpec.getSpecName(), commonSpec.getSpecName());
            }
        }
        return specNameMap;
    }

    /**
     * 校验规格单位
     *
     * @param specNameUnit  带单位的规格名称
     * @param specName      原始规格名
     * @param specValue     原始规格值
     * @param specUnitError
     * @Author loine
     * @Date 2026/4/10 15:20
     */
    private String checkSpecUnit(String specNameUnit, String specName, String specValue, StringJoiner specUnitError) {
        if (StringUtils.isNotBlank(specNameUnit) && StringUtils.isNotBlank(specName) && StringUtils.isNotBlank(specValue)) {
            if (specNameUnit.contains("（") && specNameUnit.contains("）") && !specNameUnit.equals(specName)) {
                // 截取出规格单位
                int left = specNameUnit.indexOf("（");
                int right = specNameUnit.indexOf("）");
                if (left != -1 && right != -1 && left < right) {
                    String specUnit = specNameUnit.substring(left + 1, right);
                    // 截取出当前填写值的规格单位
                    int index = 0;
                    while (index < specValue.length() && Character.isDigit(specValue.charAt(index))) {
                        index++;
                    }
                    String colUnit = specValue.substring(index);
                    // 校验单位是否有误
                    String[] specUnits = specUnit.split("@");
                    boolean isError1 = false;
                    boolean isError2 = false;
                    for (String tempUnit : specUnits) {
                        if (tempUnit.equals(colUnit)) {
                            isError1 = false;
                            break;
                        } else {
                            isError1 = true;
                        }
                    }
                    if (isError1) {
                        for (String tempUnit : specUnits) {
                            if (tempUnit.equals(colUnit)) {
                                isError2 = false;
                                break;
                            } else {
                                if (tempUnit.equalsIgnoreCase(colUnit)) {
                                    // 大小写有误的，直接更正
                                    specValue = specValue.substring(0, index) + tempUnit;
                                    isError2 = false;
                                    break;
                                } else {
                                    isError2 = true;
                                }
                            }
                        }
                    }
                    // 错误的情况，添加进提示
                    if (isError1 && isError2) {
                        specUnitError.add(specNameUnit.substring(0, left) + "：" + specUnit);
                    }
                }
            }
        }
        return specValue;
    }

    /**
     * 从json数组取出对应规格名的规格值
     *
     * @param specData
     * @Author loine
     * @Date 2026/4/10 15:21
     */
    private Map<String, String> getSpecValue(String specData) {
        Map<String, String> specMap = new HashMap<>();
        if (StringUtils.isNotBlank(specData)) {
            JSONArray specArray = JSONArray.parseArray(specData);
            if (!specArray.isEmpty()) {
                for (int i = 0; i < specArray.size(); i++) {
                    JSONObject spec = specArray.getJSONObject(i);
                    if (spec != null) {
                        if (spec.get("specName") != null && spec.get("specValue") != null) {
                            specMap.put(spec.getString("specName"), spec.getString("specValue"));
                        }
                    }
                }
            }
        }
        return specMap;
    }

}