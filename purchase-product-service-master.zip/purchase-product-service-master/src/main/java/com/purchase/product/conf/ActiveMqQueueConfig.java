package com.purchase.product.conf;

import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.jms.Queue;

/**
 * @author jidonglin
 * @Description: 队列配置
 * @date 2024/12/24  14:15
 */
@Configuration
public class ActiveMqQueueConfig {
    //任务队列
    @Value("${mq.queue.task.product-approve}")
    private String productApproveQueue;


    //商品审核队列
    @Bean(name = "productApproveQueue")
    public Queue productApproveQueue() {
        return new ActiveMQQueue(productApproveQueue);
    }

}
