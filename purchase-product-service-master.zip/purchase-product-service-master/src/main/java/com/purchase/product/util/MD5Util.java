package com.purchase.product.util;

import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Map;
import java.util.Set;

/**
 * @Description: MD5工具类
 * @Author: loine
 * @Date: 2024/10/18 15:40
 **/
@Slf4j
public class MD5Util {

    /**
     * MD5加密
     *
     * @param encryString
     * @return
     */
    public static String MD5(String encryString) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(encryString.getBytes(StandardCharsets.UTF_8));
            byte[] b = digest.digest();
            int i;
            StringBuilder buf = new StringBuilder();
            for (byte value : b) {
                i = value;
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            return buf.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
