package com.purchase.product.service;

import com.github.pagehelper.PageHelper;
import com.purchase.product.mapper.PurchaseProductApplyBatchMapper;
import com.purchase.product.model.PurchaseProductApplyBatch;
import com.qgutech.qgyun.dev.client.uc.UcFeignClient;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *  PurchaseProductApplyBatchService 服务提供类
 *
 * @author zhangcheng
 * @Date: 2022-08-10
 */
@Service
public class PurchaseProductApplyBatchService extends BaseServiceImpl<PurchaseProductApplyBatch> {

    @Resource
    private PurchaseProductApplyBatchMapper batchMapper;
    @Resource
    private UcFeignClient ucFeignClient;

    public List<PurchaseProductApplyBatch> listAll() {
        return batchMapper.selectAll();
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<PurchaseProductApplyBatch> search(PurchaseProductApplyBatch batch, Page<PurchaseProductApplyBatch> page) {
        Assert.notNull(batch, "batch can not be null!");
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<PurchaseProductApplyBatch> list = batchMapper.search(batch);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packPurchaseProductApplyBatchData(list);
        return page;
    }

    private Example genConditionExample(PurchaseProductApplyBatch model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        String batchNo = model.getBatchNo();
        if (StringUtils.isNotBlank(batchNo)) {
            criteria.andEqualTo(PurchaseProductApplyBatch.BATCH_NO, batchNo);
        }

        String fileUrl = model.getFileUrl();
        if (StringUtils.isNotBlank(fileUrl)) {
            criteria.andEqualTo(PurchaseProductApplyBatch.FILE_URL, fileUrl);
        }

        Integer type = model.getType();
        if (null != type) {
            criteria.andEqualTo(PurchaseProductApplyBatch.TYPE, type);
        }


        return example;
    }

    /**
     * 分页数据处理
     */
    private void packPurchaseProductApplyBatchData(List<PurchaseProductApplyBatch> batchList) {
        if (CollectionUtils.isEmpty(batchList)) {
            return;
        }

        List<String> userIds = batchList.stream().map(PurchaseProductApplyBatch::getUpdatedBy).collect(Collectors.toList());
        List<String> createdIds = batchList.stream().map(PurchaseProductApplyBatch::getCreatedBy).collect(Collectors.toList());
        userIds.addAll(createdIds);
        userIds = userIds.stream().distinct().collect(Collectors.toList());
        Map<String, String> userMap = ucFeignClient.getUserIdAndNameMap(userIds);
        for (PurchaseProductApplyBatch batch : batchList) {
            if (!MapUtils.isNotEmpty(userMap)) {
                continue;
            }

            batch.setCreatedByName(userMap.get(batch.getCreatedBy()));
            batch.setUpdatedByName(userMap.get(batch.getUpdatedBy()));
        }
    }

    /**
     * 通过id获取详情
     */
    @Override
    public PurchaseProductApplyBatch get(String id) {
        PurchaseProductApplyBatch batch = super.get(id);
        String createdBy = batch.getCreatedBy();
        String updatedBy = batch.getUpdatedBy();
        List<String> userIds = new ArrayList<>();
        if (StringUtils.isNotEmpty(createdBy)) {
            userIds.add(createdBy);
        }

        if (StringUtils.isNotEmpty(updatedBy)) {
            userIds.add(updatedBy);
        }

        userIds = userIds.stream().distinct().collect(Collectors.toList());
        Map<String, String> userMap = ucFeignClient.getUserIdAndNameMap(userIds);
        batch.setCreatedByName(userMap.get(createdBy));
        batch.setUpdatedByName(userMap.get(updatedBy));
        return batch;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(PurchaseProductApplyBatch batch) {
        Assert.notNull(batch, "batch can not be null");
        Example example = genConditionExample(batch);
        example.selectProperties(PurchaseProductApplyBatch.ID);
        List<PurchaseProductApplyBatch> batchList = batchMapper.selectByExample(example);
        return CollectionUtils.isEmpty(batchList) ? new ArrayList<>(0) :
                batchList.stream().map(PurchaseProductApplyBatch::getId).collect(Collectors.toList());
    }

    /**
     * 新增
     */
    public String add(PurchaseProductApplyBatch batch) {
        return super.insert(batch);
    }

    /**
     * 修改
     */
    public void edit(PurchaseProductApplyBatch batch) {
        super.update(batch);
    }

    /**
     * 批量删除
     */
    public void deleteByIds(List<String> ids) {
         super.batchDelete(ids);
    }

}
