package com.purchase.product.model;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import javax.persistence.Table;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.persistence.Transient;
/**
 * 商品管理规格配置 model
 *
 * @author auto
 * @version 1.0
 * @since 2022-11-04 11:46:23
 */
@Getter
@Setter
@ToString
@ApiModel(value = "ProductProperties", description = "商品管理规格配置")
@Table(name = "t_pd_purchase_product_properties")
public class ProductProperties extends BaseCorpModel {

    public static final String PARAM = "param";
    public static final String STATUS = "status";

    /**
     * 字段
     */
    @ApiModelProperty(value = "字段")
    private String param;

    /**
     * 是否需要审核（Y：需要，N：不需要）
     */
    @ApiModelProperty(value = "是否需要审核（Y：需要，N：不需要）")
    private String status;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    @Transient
    private String createdByName;

    @Transient
    private String updatedByName;
}
