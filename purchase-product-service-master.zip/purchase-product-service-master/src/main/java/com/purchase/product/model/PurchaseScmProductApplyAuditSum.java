package com.purchase.product.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/12/15 13:50
 **/
@Data
@ApiModel("供应商_SCM产品申请_审核考核统计表")
@Table(name = "t_pd_purchase_scm_product_apply_audit_sum")
public class PurchaseScmProductApplyAuditSum extends BaseCorpModel {

    public static final String ID = "id";

    @ApiModelProperty("操作人")
    private String doName;
    @ApiModelProperty("操作时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime doTime;
    @ApiModelProperty("操作")
    private String doSomething;
    @ApiModelProperty("结果数量")
    private Integer resultNum;
    @ApiModelProperty("结果内容")
    private String resultContent;
    @ApiModelProperty("品牌名称")
    private String brandName;
    @ApiModelProperty("供应商id")
    private String supplierId;
    @ApiModelProperty("供应商名称")
    private String supplierName;
    @ApiModelProperty("最终状态")
    private String status;
    @ApiModelProperty("类型")
    private String type;
}
