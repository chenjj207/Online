package com.purchase.product.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/1/14 14:05
 **/
@Data
@ApiModel("后台-商品池页面异步任务-入参")
public class CommonProductTaskDto {
    // 公共
    @ApiModelProperty("产品状态 1: 上架中 2：下架  3：所有上下架状态")
    private Integer productStatus;
    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;
    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;
    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;
    @ApiModelProperty("商品品牌名称")
    private String brandName;
    @ApiModelProperty("商品系列名称")
    private String propName;
    @ApiModelProperty("关键字")
    private String key;
    @ApiModelProperty("供应商id")
    private String supplierId;
    @ApiModelProperty("商品申请来源 来源： inquiry | publish")
    private String applySource;
    @ApiModelProperty("产品来源")
    private String productSrc;
    @ApiModelProperty("产品型号列表")
    private List<String> productTypeList;
    @ApiModelProperty("商品id列表")
    private List<String> productIdList;
    @ApiModelProperty("厂家物料号列表")
    private List<String> skuCodeList;
    @ApiModelProperty("供应商商品编码列表")
    private List<String> supplierProductCodeList;
    @ApiModelProperty("商品编码列表")
    private List<String> productCodeList;
    @ApiModelProperty("所属子公司")
    private String subCompany;
    @ApiModelProperty("包含的主键ids（全部传all）")
    private List<String> ids;
    @ApiModelProperty("不包含的主键ids")
    private List<String> notInIds;

    // 设置调货价
    @ApiModelProperty("调货价折扣")
    private BigDecimal distributeDiscount;
    @ApiModelProperty("调货价折扣 计算方式（乘：*、除：/）")
    private String distributeCalcWay;
}
