package com.purchase.product.mapper;

import com.purchase.product.dto.BusinessRecommendProductListDto;
import com.purchase.product.model.PurchaseRecommendProduct;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @since 2024-01-11
 */
public interface PurchaseRecommendProductMapper extends QguBaseMapper<PurchaseRecommendProduct> {

    List<PurchaseRecommendProduct> selectBusinessRecommendProductList(@Param("dto") BusinessRecommendProductListDto businessRecommendProductListDto , @Param("supplierId")String supplierId);
}
