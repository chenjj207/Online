package com.purchase.product.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.purchase.utils.excel.export.ExcelField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * @Description:
 * @Author: loine
 * @Date: 2026/3/10 16:02
 */
@Data
@ApiModel("慧采SCM_ERP产品编码申请-出参")
public class PurchaseScmErpProductCodeApplyVo {

    @Data
    @ApiModel("后台-搜索-出参")
    public static class ErpAdminSearchVo {
        @ApiModelProperty("主键id")
        private String id;
        @ApiModelProperty("申请编号")
        private String applyNo;
        @ApiModelProperty("来源（1：手工申请，2：报价申请）")
        private String source;
        @ApiModelProperty("供应商品牌")
        private String supplierBrand;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号")
        private String skuCode;
        @ApiModelProperty("ERP产品编码")
        private String erpProductCode;
        @ApiModelProperty("参考编码")
        private String referenceCode;
        @ApiModelProperty("产品凭证（多个@隔开）")
        private String productVoucher;
        @ApiModelProperty("物料名称")
        private String materialName;
        @ApiModelProperty("产地")
        private String productArea;
        @ApiModelProperty("单位")
        private String unit;
        @ApiModelProperty("产品属性2-品牌")
        private String sifsBrand;
        @ApiModelProperty("产品属性3-产品大类")
        private String sifsPdBcata;
        @ApiModelProperty("产品属性8-商品小类")
        private String sifsPdScata;
        @ApiModelProperty("产品属性11-统计大类")
        private String sifsStBcata;
        @ApiModelProperty("产品属性10-统计小类")
        private String sifsStScata;
        @ApiModelProperty("产品属性6-产品系列")
        private String sifsProp;
        @ApiModelProperty("产品属性4-产品细分")
        private String sifsSubversion;
        @ApiModelProperty("产品属性12-主采购组")
        private String sifsMainProcurement;
        @ApiModelProperty("产品属性5-供应商属性")
        private String sapplerAttribute;
        @ApiModelProperty("产品属性14-主配套分类")
        private String smainSubCat;
        @ApiModelProperty("税务分类编码（关联税务分类关系表）")
        private String taxCataCode;
        @ApiModelProperty("税务分类名称")
        private String taxCataName;
        @ApiModelProperty("供应商编码（关联供应商对应关系表）")
        private String supplierCode;
        @ApiModelProperty("需求人所属公司编码")
        private String demandComBm;
        @ApiModelProperty("需求人的用户id")
        private String demandUserId;
        @ApiModelProperty("审核状态（0=待提交，1=待资料审核，2=待新增审核，3=建编码中，4=通过，5=驳回")
        private Integer auditStatus;
        @ApiModelProperty("审核备注")
        private String auditRemark;
        @ApiModelProperty("创建时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime createdAt;

        @ApiModelProperty("供应商名称")
        private String supplierName;
        @ApiModelProperty("提报人的用户名称")
        private String userName;
    }

    @Data
    @ApiModel("搜索角标-出参")
    public static class ErpSearchCountVo {
        @ApiModelProperty("待提交数量")
        private int auditStatus0;
        @ApiModelProperty("待资料审核数量")
        private int auditStatus1;
        @ApiModelProperty("待新增审核数量")
        private int auditStatus2;
        @ApiModelProperty("建编码中数量")
        private int auditStatus3;
        @ApiModelProperty("通过数量")
        private int auditStatus4;
        @ApiModelProperty("驳回数量")
        private int auditStatus5;
    }

    @Data
    @ApiModel("详情-出参")
    public static class ErpDetailVo {
        @ApiModelProperty("主键id")
        private String id;
        @ApiModelProperty("申请编号")
        private String applyNo;
        @ApiModelProperty("来源（1：手工申请，2：报价申请）")
        private String source;
        @ApiModelProperty("供应商品牌")
        private String supplierBrand;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号")
        private String skuCode;
        @ApiModelProperty("ERP产品编码")
        private String erpProductCode;
        @ApiModelProperty("参考编码")
        private String referenceCode;
        @ApiModelProperty("产品凭证（多个@隔开）")
        private String productVoucher;
        @ApiModelProperty("物料名称")
        private String materialName;
        @ApiModelProperty("产地")
        private String productArea;
        @ApiModelProperty("单位")
        private String unit;
        @ApiModelProperty("产品属性2-品牌")
        private String sifsBrand;
        @ApiModelProperty("产品属性3-产品大类")
        private String sifsPdBcata;
        @ApiModelProperty("产品属性8-商品小类")
        private String sifsPdScata;
        @ApiModelProperty("产品属性11-统计大类")
        private String sifsStBcata;
        @ApiModelProperty("产品属性10-统计小类")
        private String sifsStScata;
        @ApiModelProperty("产品属性6-产品系列")
        private String sifsProp;
        @ApiModelProperty("产品属性4-产品细分")
        private String sifsSubversion;
        @ApiModelProperty("产品属性12-主采购组")
        private String sifsMainProcurement;
        @ApiModelProperty("产品属性5-供应商属性")
        private String sapplerAttribute;
        @ApiModelProperty("产品属性14-主配套分类")
        private String smainSubCat;
        @ApiModelProperty("税务分类编码（关联税务分类关系表）")
        private String taxCataCode;
        @ApiModelProperty("税务分类名称")
        private String taxCataName;
        @ApiModelProperty("供应商编码（关联供应商对应关系表）")
        private String supplierCode;
        @ApiModelProperty("需求人所属公司编码")
        private String demandComBm;
        @ApiModelProperty("需求人的用户id")
        private String demandUserId;
        @ApiModelProperty("审核状态（0=待提交，1=待资料审核，2=待新增审核，3=建编码中，4=通过，5=驳回")
        private Integer auditStatus;
        @ApiModelProperty("审核备注")
        private String auditRemark;
        @ApiModelProperty("创建时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime createdAt;

        @ApiModelProperty("供应商名称")
        private String supplierName;
        @ApiModelProperty("需求人的公司名称")
        private String demandComName;
        @ApiModelProperty("需求人的用户名称")
        private String demandUserName;
        @ApiModelProperty("提报人的用户名称")
        private String userName;
        @ApiModelProperty("资源文件地址前缀")
        private String urlPrefix;
    }

    @Data
    @ApiModel("参考详情-出参")
    public static class ErpReferenceDetailVo {
        @ApiModelProperty("订货号")
        private String skuCode;
        @ApiModelProperty("物料名称")
        private String materialName;
        @ApiModelProperty("产地")
        private String productArea;
        @ApiModelProperty("单位")
        private String unit;
        @ApiModelProperty("产品属性2-品牌")
        private String sifsBrand;
        @ApiModelProperty("产品属性3-产品大类")
        private String sifsPdBcata;
        @ApiModelProperty("产品属性8-商品小类")
        private String sifsPdScata;
        @ApiModelProperty("产品属性11-统计大类")
        private String sifsStBcata;
        @ApiModelProperty("产品属性10-统计小类")
        private String sifsStScata;
        @ApiModelProperty("产品属性6-产品系列")
        private String sifsProp;
        @ApiModelProperty("产品属性4-产品细分")
        private String sifsSubversion;
        @ApiModelProperty("产品属性12-主采购组")
        private String sifsMainProcurement;
        @ApiModelProperty("产品属性5-供应商属性")
        private String sapplerAttribute;
        @ApiModelProperty("产品属性14-主配套分类")
        private String smainSubCat;
        @ApiModelProperty("税务分类编码（关联税务分类关系表）")
        private String taxCataCode;
        @ApiModelProperty("税务分类名称")
        private String taxCataName;
    }

    @Data
    @ApiModel("税务分类关系表-出参")
    public static class ErpTaxCataRelateVo {
        @ApiModelProperty("编码")
        private String code;
        @ApiModelProperty("名称（大类）")
        private String nameBig;
        @ApiModelProperty("名称（小类）")
        private String nameSmall;
    }

    @Data
    @ApiModel("供应商对应关系表-出参")
    public static class ErpSupplierRelateVo {
        @ApiModelProperty("编码")
        private String code;
        @ApiModelProperty("名称")
        private String name;
    }

    @Data
    @ApiModel("日志列表-出参")
    public static class ErpLogListVo {
        @ApiModelProperty("类型")
        private String type;
        @ApiModelProperty("处理信息")
        private String message;
        @ApiModelProperty("创建时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime createdAt;
        @ApiModelProperty("创建人")
        private String createdName;
    }

    @Data
    @ApiModel("后台-导出-出参")
    public static class ErpAdminExportVo {
        @ApiModelProperty("申请编号")
        @ExcelField(title = "申请ID")
        private String applyNo;
        @ApiModelProperty("审核状态（0=待提交，1=待资料审核，2=待新增审核，3=建编码中，4=通过，5=驳回")
        @ExcelField(title = "状态")
        private String auditStatus;
        @ApiModelProperty("供应商品牌")
        @ExcelField(title = "供应商品牌")
        private String supplierBrand;
        @ApiModelProperty("产品型号")
        @ExcelField(title = "产品型号")
        private String productType;
        @ApiModelProperty("订货号")
        @ExcelField(title = "订货号")
        private String skuCode;
        @ApiModelProperty("ERP产品编码")
        @ExcelField(title = "ERP产品编码")
        private String erpProductCode;
        @ApiModelProperty("参考编码")
        @ExcelField(title = "参考编码")
        private String referenceCode;
        @ApiModelProperty("物料名称")
        @ExcelField(title = "产品名称")
        private String materialName;
        @ApiModelProperty("产地")
        @ExcelField(title = "产地")
        private String productArea;
        @ApiModelProperty("单位")
        @ExcelField(title = "单位")
        private String unit;
        @ApiModelProperty("产品属性2-品牌")
        @ExcelField(title = "产品属性2-品牌")
        private String sifsBrand;
        @ApiModelProperty("产品属性3-产品大类")
        @ExcelField(title = "产品属性3-产品大类")
        private String sifsPdBcata;
        @ApiModelProperty("产品属性4-产品细分")
        @ExcelField(title = "产品属性4-产品细分")
        private String sifsSubversion;
        @ApiModelProperty("产品属性5-供应商属性")
        @ExcelField(title = "产品属性5-供应商属性")
        private String sapplerAttribute;
        @ApiModelProperty("产品属性6-产品系列")
        @ExcelField(title = "产品属性6-产品系列")
        private String sifsProp;
        @ApiModelProperty("产品属性8-商品小类")
        @ExcelField(title = "产品属性8-商品小类")
        private String sifsPdScata;
        @ApiModelProperty("产品属性10-统计小类")
        @ExcelField(title = "产品属性10-统计小类")
        private String sifsStScata;
        @ApiModelProperty("产品属性11-统计大类")
        @ExcelField(title = "产品属性11-统计大类")
        private String sifsStBcata;
        @ApiModelProperty("产品属性12-主采购组")
        @ExcelField(title = "产品属性12-主采购组")
        private String sifsMainProcurement;
        @ApiModelProperty("产品属性14-主配套分类")
        @ExcelField(title = "产品属性14-主配套分类")
        private String smainSubCat;
        @ApiModelProperty("供应商编码（关联供应商对应关系表）")
        @ExcelField(title = "供应商编码")
        private String supplierCode;
        @ApiModelProperty("供应商名称")
        @ExcelField(title = "供应商")
        private String supplierName;
        @ApiModelProperty("提报人的用户名称")
        @ExcelField(title = "提报人")
        private String userName;
        @ApiModelProperty("创建时间")
        @ExcelField(title = "提报时间")
        private String createdAt;
        @ApiModelProperty("来源（1：手工申请，2：报价申请）")
        @ExcelField(title = "数据来源")
        private String source;
    }

    @Data
    @ApiModel("反推用户列表-出参")
    public static class ErpAdminUserListVo {
        @ApiModelProperty("用户id")
        private String id;
        @ApiModelProperty("用户名称")
        private String name;
    }
}
