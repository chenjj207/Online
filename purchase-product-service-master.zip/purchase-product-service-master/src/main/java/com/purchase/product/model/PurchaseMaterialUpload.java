package com.purchase.product.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *  model
 *
 * @author auto
 * @version 1.0
 * @since 2021-09-01 17:11:06
 */
@Getter
@Setter
@ToString
@ApiModel(value = "PurchaseMaterialUpload", description = "")
@Table(name = "t_pd_purchase_material_upload")
public class PurchaseMaterialUpload extends BaseCorpModel {

    public static final String FILE_PATH = "filePath";
    public static final String FILE_NAME = "fileName";
    public static final String OSS_PATH = "ossPath";
    public static final String IS_UPLOAD_OVER = "isUploadOver";
    public static final String IS_SUPPLY = "isSupply";
    public static final String SUPPLIER_ID = "supplierId";

    /**
     * 文件名称
     */
    @ApiModelProperty(value = "文件名称")
    private String fileName;
    /**
     * 文件路径
     */
    @ApiModelProperty(value = "文件路径")
    private String filePath;

    /**
     * 对应oss路径
     */
    @ApiModelProperty(value = "对应oss路径")
    private String ossPath;

    /**
     * 是否上传完成
     */
    @ApiModelProperty(value = "是否上传完成")
    private String isUploadOver;

    @ApiModelProperty("供应商id")
    private String supplierId;
    @ApiModelProperty("是否是供应链（Y：是，N：否）")
    private String isSupply;
    
    @Transient
    private String createdByName;

    @Transient
    private String updatedByName; 
}
