package com.purchase.product.client;

import com.purchase.model.Supplier;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Collection;
import java.util.Map;

/**
 * 对外服务接口
 *
 * @author zhangcheng
 */
@FeignClient(value = "purchase-user", path = "/ucFeign", fallbackFactory = PurchaseUserFeignClient.PurchaseUserFeignClientHystrix.class)
public interface PurchaseUserFeignClient {

    /**
     * 根据供应商id，获取对象map
     *
     * @param ids 主键
     * @return 供应商对象map
     */
    @PostMapping(value = "/mapSupplierByIds")
    Map<String, Supplier> mapSupplierByIds(@RequestBody Collection<String> ids);

    @Slf4j
    @Component
    class PurchaseUserFeignClientHystrix implements FallbackFactory<PurchaseUserFeignClient> {
        @Override
        public PurchaseUserFeignClient create(Throwable throwable) {
            return new PurchaseUserFeignClient() {
                @Override
                public Map<String, Supplier> mapSupplierByIds(Collection<String> ids) {
                    return null;
                }
            };
        }
    }
}
