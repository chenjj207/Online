package com.purchase.product.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Table;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/2/10 16:49
 **/
@Data
@ApiModel("供应商_SCM产品申请_变更记录表")
@Table(name = "t_pd_purchase_scm_product_apply_change_record")
public class PurchaseScmProductApplyChangeRecord extends BaseCorpModel {

    public static final String ID = "id";
    public static final String APPLY_NO = "applyNo";

    @ApiModelProperty("申请编号")
    private Long applyNo;
    @ApiModelProperty("变更字段代码")
    private String fieldCode;
    @ApiModelProperty("变更字段")
    private String fieldName;
    @ApiModelProperty("变更前字段值")
    private String oldValue;
    @ApiModelProperty("变更后字段值")
    private String newValue;
}
