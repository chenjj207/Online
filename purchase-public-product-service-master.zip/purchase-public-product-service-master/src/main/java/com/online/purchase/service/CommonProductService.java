package com.online.purchase.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.io.IoUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.*;
import com.aliyuncs.CommonResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.fasterxml.jackson.core.type.TypeReference;
import com.online.purchase.base.PdConstants;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.client.MsgClient;
import com.online.purchase.client.PublicProductFeignServer;
import com.online.purchase.client.TaskClient;
import com.online.purchase.client.UcFeignClient;
import com.online.purchase.client.dto.TaskManageDTO;
import com.online.purchase.client.dto.TriggerMsgRequest;
import com.online.purchase.config.CommonOssConf;
import com.online.purchase.config.OssConf;
import com.online.purchase.controller.CommonProductController;
import com.online.purchase.controller.preview.DisplaySettingDTO;
import com.online.purchase.mapper.*;
import com.online.purchase.model.*;
import com.online.purchase.model.dto.*;
import com.online.purchase.model.vo.*;
import com.online.purchase.service.dto.ProductIdDTO;
import com.online.purchase.utils.GenericDataListener;
import com.online.purchase.utils.MultiTitleExportExcelUtil;
import com.online.purchase.utils.OssUtil;
import com.online.purchase.utils.RedisUtil;
import com.purchase.exception.ExceptionDictionary;
import com.purchase.exception.ZydExceptions;
import com.purchase.model.PurchaseProductSync;
import com.purchase.model.Supplier;
import com.purchase.model.dto.CommonProductDto;
import com.purchase.model.dto.DetailResponse;
import com.purchase.model.dto.SpecAndValDTO;
import com.purchase.utils.date.ZydDateUtils;
import com.purchase.utils.excel.JxlsExcelView;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.io.*;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.BiConsumer;
import java.util.function.Function;

/**
 * CommonProductService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Service
@Slf4j
public class CommonProductService extends BaseServiceImpl<CommonProduct> {

    @Resource
    private CommonProductMapper commonProductMapper;
    @Resource
    private CommonCatalogService commonCatalogService;
    @Resource
    private CommonBrandService commonBrandService;
    @Resource
    private CommonPropService commonPropService;
    @Resource
    private CommonSpecService commonSpecService;
    @Resource
    private CommonSpecValService commonSpecValService;
    @Resource
    private CommonProductSpecService commonProductSpecService;
    @Resource
    private RedisTemplate redisTemplate;
    @Resource
    private UcFeignClient ucFeignClient;
    @Resource
    private CommonOssConf commonOssConf;
    @Resource
    private OssConf ossConf;
    @Resource
    private CommonCatalogMapper commonCatalogMapper;
    @Value("${commonWatermark}")
    private String commonWatermark;
    @Value("${watermarksize}")
    private String watermarksize;
    @Value("${textmarksize}")
    private String textmarksize;
    @Value("${supplierId}")
    private String supplierId;
    @Resource
    private CommonEsService commonEsService;
    @Resource
    private MsgClient msgClient;
    @Resource
    private TaskClient taskClient;
    @Resource
    private PublicProductFeignServer publicProductFeignServer;
    @Resource
    CommonProductMallRecMapper commonProductMallRecMapper;
    @Resource
    CommonProductModiRecMapper commonProductModiRecMapper;
    @Autowired
    private OssUtil ossUtil;

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<CommonProduct> search(CommonProduct commonProduct, Page<CommonProduct> page) {
        Assert.notNull(commonProduct, "commonProduct can not be null!");
        Long cataId = commonProduct.getCataId();
        if (null != cataId) {
            Set<Long> cataIds = commonCatalogService.listChildIdByCataId(cataId);
            cataIds.add(cataId);
            commonProduct.setCataIds(cataIds);
        }

        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<CommonProduct> list = commonProductMapper.search(commonProduct);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packCommonProductData(list);
        return page;
    }

    private Example genConditionExample(CommonProduct model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        Long productId = model.getProductId();
        if (null != productId) {
            criteria.andEqualTo(CommonProduct.PRODUCT_ID, productId);
        }

        String productName = model.getProductName();
        if (StringUtils.isNotBlank(productName)) {
            criteria.andEqualTo(CommonProduct.PRODUCT_NAME, productName);
        }

        String productType = model.getProductType();
        if (StringUtils.isNotBlank(productType)) {
            criteria.andEqualTo(CommonProduct.PRODUCT_TYPE, productType);
        }

        String skuCode = model.getSkuCode();
        if (StringUtils.isNotBlank(skuCode)) {
            criteria.andEqualTo(CommonProduct.SKU_CODE, skuCode);
        }

        Long cataId = model.getCataId();
        if (null != cataId) {
            criteria.andEqualTo(CommonProduct.CATA_ID, cataId);
        }

        Long brandId = model.getBrandId();
        if (null != brandId) {
            criteria.andEqualTo(CommonProduct.BRAND_ID, brandId);
        }

        Long propId = model.getPropId();
        if (null != propId) {
            criteria.andEqualTo(CommonProduct.PROP_ID, propId);
        }

        String isOnsale = model.getIsOnsale();
        if (StringUtils.isNotBlank(isOnsale)) {
            criteria.andEqualTo(CommonProduct.IS_ONSALE, isOnsale);
        }

        String productSrc = model.getProductSrc();
        if (StringUtils.isNotBlank(productSrc)) {
            criteria.andEqualTo(CommonProduct.PRODUCT_SRC, productSrc);
        }

        Integer syncStatus = model.getSyncStatus();
        if (null != syncStatus) {
            criteria.andEqualTo(CommonProduct.SYNC_STATUS, syncStatus);
        }

        return example;
    }

    /**
     * 分页数据处理
     */
    private void packCommonProductData(List<CommonProduct> commonProductList) {
        if (CollectionUtils.isEmpty(commonProductList)) {
            return;
        }

        Set<String> supplierIds = new HashSet<>();
        Set<Long> brandIds = new HashSet<>();
        Set<Long> cataIds = new HashSet<>();
        Set<Long> propIds = new HashSet<>();
        for (CommonProduct product : commonProductList) {
            supplierIds.add(product.getSupplierId());
            brandIds.add(product.getBrandId());
            cataIds.add(product.getCataId());
            propIds.add(product.getPropId());
        }

        Map<Long, String> brandNameMap = Maps.newHashMap();
        Map<Long, Map<Integer, String>> cataNameMap = Maps.newHashMap();
        Map<Long, String> propNameMap = Maps.newHashMap();
        Map<String, Supplier> supplierMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(supplierIds)) {
            supplierMap = ucFeignClient.mapSupplierByIds(supplierIds);
        }

        if (CollectionUtils.isNotEmpty(brandIds)) {
            brandNameMap = commonBrandService.mapNameByBrandIds(brandIds);
        }

        if (CollectionUtils.isNotEmpty(cataIds)) {
            cataNameMap = commonCatalogService.mapNameByCataIds(cataIds);
        }

        if (CollectionUtils.isNotEmpty(propIds)) {
            propNameMap = commonPropService.mapNameByPropIds(propIds);
        }

        String productSrc;
        for (CommonProduct product : commonProductList) {
            product.setBrandName(brandNameMap.get(product.getBrandId()));
            if (product.getCataId() != null){
                if (cataNameMap.containsKey(product.getCataId())){
                    product.setCataNameOne(cataNameMap.get(product.getCataId()).get(1));
                    product.setCataNameTwo(cataNameMap.get(product.getCataId()).get(2));
                    product.setCataNameThree(cataNameMap.get(product.getCataId()).get(3));
                }
            }
            product.setPropName(propNameMap.get(product.getPropId()));
            if (StringUtils.isNotEmpty(product.getSupplierId())) {
                Supplier supplier = supplierMap.get(product.getSupplierId());
                product.setSupplierName(null == supplier ? null : supplier.getName());
            } else if (PuPrConstants.ZYDMALL.equals(product.getProductSrc()) && !StringUtils.equals("上海供应链", product.getIfsMainProcurement())){
                //来源为ZYDMALL 并且 主采购组不是上海供应链
                product.setSupplierName("zydmall");
            } else {
                product.setSupplierName("供应链公司");
            }

            productSrc = product.getProductSrc();
            if (PuPrConstants.SUPPLIER.equals(productSrc)) {
                product.setProductSrc(PuPrConstants.ONLINE_MARKETING);
            } else {
                product.setProductSrc(PuPrConstants.ZYDMALL);
            }
            /*product.setProductSrc(StringUtils.equalsAny(productSrc, PuPrConstants.SUPPLIER)
                    ? PuPrConstants.ONLINE_MARKETING : productSrc);*/
        }
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(CommonProduct commonProduct) {
        Assert.notNull(commonProduct, "commonProduct can not be null");
        Example example = genConditionExample(commonProduct);
        example.selectProperties(CommonProduct.ID);
        List<CommonProduct> commonProductList = commonProductMapper.selectByExample(example);
        return CollectionUtils.isEmpty(commonProductList) ? new ArrayList<>(0) :
                commonProductList.stream().map(CommonProduct::getId).collect(Collectors.toList());
    }

    /**
     * 新增
     */
    public String add(CommonProduct commonProduct) {
        commonProduct.setProductId(getMaxProductId());
        return super.insert(commonProduct);
    }

    /**
     * 修改
     */
    public void edit(CommonProduct commonProduct) {
        super.update(commonProduct);
    }

    /**
     * 根据品牌编号，批量修改品牌编号关联
     *
     * @param oldBrandId 原品牌编号
     * @param brandId    品牌编号
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void batchUpdateBrandId(Long oldBrandId, Long brandId) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(oldBrandId).isNotNull(brandId);
        commonProductMapper.batchUpdateBrandId(oldBrandId, brandId);
    }

    /**
     * 根据系列编号，批量修改系列编号关联
     *
     * @param oldPropId 原系列编号
     * @param propId    系列编号
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void batchUpdatePropId(Long oldPropId, Long propId) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(oldPropId).isNotNull(propId);
        commonProductMapper.batchUpdatePropId(oldPropId, propId);
    }

    /**
     * 根据分类编号，批量修改分类编号关联
     *
     * @param oldCataId 原分类编号
     * @param cataId    分类编号
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void batchUpdateCataId(Long oldCataId, Long cataId) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(oldCataId).isNotNull(cataId);
        commonProductMapper.batchUpdateCataId(oldCataId, cataId);
    }


    /**
     * 规格数据同步
     *
     * @param purchaseProductSync
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Long purchaseProductSync(PurchaseProductSync purchaseProductSync) {
        Long productId = null;
        Long type = null;
        if (null != purchaseProductSync) {
            String productSrc = null;
            if (StringUtils.isNotEmpty(purchaseProductSync.getProductSrc())) {
                //来源是zydmall，即使供应商id不为空 ，productSrc还是取值zydmall
                productSrc = purchaseProductSync.getProductSrc();
            }else {
                if (StringUtils.isBlank(purchaseProductSync.getSupplierId())){
                    productSrc = PuPrConstants.SUPPLY;
                }else {
                    productSrc = PuPrConstants.SUPPLIER;
                }
            }

            Long cataId = null;
            String firstLevelCataName = purchaseProductSync.getFirstLevelCataName();
            String secondLevelCataName = purchaseProductSync.getSecondLevelCataName();
            String threeLevelCataName = purchaseProductSync.getThreeLevelCataName();
            if (StringUtils.isNotEmpty(firstLevelCataName) && StringUtils.isNotEmpty(secondLevelCataName) && StringUtils.isNotEmpty(threeLevelCataName)){
                Long firstLevelCataId = commonCatalogService.syncCataLog(firstLevelCataName, 0L, 1, "", purchaseProductSync.getIsShowProp(), purchaseProductSync.getProductSrc());
                Long secondLevelCataId = commonCatalogService.syncCataLog(secondLevelCataName, firstLevelCataId, 2, firstLevelCataId+",", purchaseProductSync.getIsShowProp(), purchaseProductSync.getProductSrc());
                Long threeLevelCataId = commonCatalogService.syncCataLog(threeLevelCataName, secondLevelCataId, 3, firstLevelCataId+","+secondLevelCataId+",", purchaseProductSync.getIsShowProp(), purchaseProductSync.getProductSrc());
                cataId = threeLevelCataId;
            }
            String brandName = purchaseProductSync.getBrandName();
            Long brandId = null;
            Long propId = null;
            if (StringUtils.isNotEmpty(brandName)){
                brandId = commonBrandService.syncBrand(brandName, productSrc);
            }
            String propName = purchaseProductSync.getPropName();
            if (StringUtils.isNotEmpty(propName)){
                propId = commonPropService.syncProp(propName, brandId, productSrc);
            }
            CommonProduct commonProduct = null;
            CommonProduct commonProductOld = new CommonProduct();
            List<CommonProductSpec> commonProductSpecListOld = null;
            productId = getMaxProductId();
            if (null != purchaseProductSync.getPublicProductId()) {
                commonProduct = getByProductId(purchaseProductSync.getPublicProductId());
                if (null != commonProduct) {
                    productId = commonProduct.getProductId();
                    if(null != productId) {
                        commonProductSpecListOld = commonProductSpecService.selectByProductId(productId);
                    }
                    commonProductSpecService.deleteByProductId(productId);
                }
            } else if (null != purchaseProductSync.getZydmallProductId()) {
                commonProduct = getByZydmallProductId(purchaseProductSync.getZydmallProductId());
                if (null != commonProduct) {
                    productId = commonProduct.getProductId();
                    if(null != productId) {
                        commonProductSpecListOld = commonProductSpecService.selectByProductId(productId);
                    }
                    commonProductSpecService.deleteByProductId(productId);
                }
                //commonProduct.setZydmallProductId(purchaseProductSync.getZydmallProductId());
            }
            String erpProductCodeOld = null;
            if (null == commonProduct) {
                commonProduct = new CommonProduct();
            }else{
                erpProductCodeOld = commonProduct.getErpProductCode();
                BeanUtils.copyProperties(commonProduct, commonProductOld);
            }
            if(null != purchaseProductSync.getZydmallProductId()) {
                commonProduct.setZydmallProductId(purchaseProductSync.getZydmallProductId());
            }
            commonProduct.setProductId(productId);
            commonProduct.setIsValid(PuPrConstants.IS_VALID_Y);
            commonProduct.setApplyId(purchaseProductSync.getId());
            commonProduct.setProductType(purchaseProductSync.getProductType());
            if (null != purchaseProductSync.getProductErpCode()) {
                commonProduct.setErpProductCode(purchaseProductSync.getProductErpCode());
            }
            if (null != purchaseProductSync.getErpProductId()) {
                commonProduct.setErpProductId(purchaseProductSync.getErpProductId());
            }
            commonProduct.setSupplierProductCode(purchaseProductSync.getProductCode());
            commonProduct.setSkuCode(purchaseProductSync.getSkuCode());
            commonProduct.setApplyNo(purchaseProductSync.getApplyNo());
            commonProduct.setStock(purchaseProductSync.getStock());
            commonProduct.setPrice(purchaseProductSync.getPrice());
            commonProduct.setSupplyPrice(purchaseProductSync.getSupplyPrice());
            commonProduct.setSupplyDiscount(purchaseProductSync.getSupplyDiscount());
            commonProduct.setPurchasePrice(purchaseProductSync.getPurchasePrice());
            commonProduct.setPurchaseDiscount(purchaseProductSync.getPurchaseDiscount());
            commonProduct.setPurchaseCalcWay(purchaseProductSync.getPurchaseCalcWay());
            if (StringUtils.equals(purchaseProductSync.getSubCompany(), "上海供应链公司")){
                //直供供应商 才会有调货价 调货价=供货价
                commonProduct.setPurchasePrice(purchaseProductSync.getSupplyPrice());
            }
            commonProduct.setSuggestPrice(purchaseProductSync.getSuggestPrice());

            if (cataId != null){
                commonProduct.setCataId(cataId);
            }
            commonProduct.setBrandId(brandId);
            commonProduct.setPropId(propId);
            commonProduct.setUnit(purchaseProductSync.getUnit());
            commonProduct.setWeight(purchaseProductSync.getWeight());
            commonProduct.setIsOnsale(purchaseProductSync.getIsOnsale());
            commonProduct.setDeliveryDate(purchaseProductSync.getDeliveryDate());
            commonProduct.setAuditTime(purchaseProductSync.getAuditTime());
            commonProduct.setApplySource(purchaseProductSync.getApplySource());
            commonProduct.setMaterialName(purchaseProductSync.getMaterialName());
            if (StringUtils.equalsIgnoreCase("上海供应链", purchaseProductSync.getIfsMainProcurement())){
                commonProduct.setSupplierId(supplierId);
            }else{
                commonProduct.setSupplierId(purchaseProductSync.getSupplierId());
            }
            //供应商名称设置
            Map<String, Supplier> supplierMap = ucFeignClient.mapSupplierByIds(Arrays.asList(commonProduct.getSupplierId()));
            Supplier supplier = supplierMap.get(commonProduct.getSupplierId());
            commonProduct.setSupplierName(null == supplier ? null : supplier.getName());
            //所属子公司设置
            commonProduct.setSubCompany(purchaseProductSync.getSubCompany());
            commonProduct.setProductContent(purchaseProductSync.getProductContent());
            commonProduct.setProductVedioName(purchaseProductSync.getProductVedioName());
            commonProduct.setProductPicName(purchaseProductSync.getProductPicName());
            commonProduct.setProductSrc(productSrc);
            commonProduct.setIfsMainProcurement(purchaseProductSync.getIfsMainProcurement());
            commonProduct.setIfsStBcata(purchaseProductSync.getIfsStBcata());
            commonProduct.setIfsStScata(purchaseProductSync.getIfsStScata());
            commonProduct.setIfsSupplierDistribution(purchaseProductSync.getIfsSupplierDistribution());
            commonProduct.setReason(purchaseProductSync.getReason());
            commonProduct.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
            commonProduct.setProductSimpleName(purchaseProductSync.getSample());
            //商品的店铺信息
            commonProduct.setStoreId(purchaseProductSync.getStoreId());
            commonProduct.setStoreName(purchaseProductSync.getStoreName());
            commonProduct.setStoreType(purchaseProductSync.getStoreType());
            commonProduct.setStoreDesc(purchaseProductSync.getStoreDesc());
            //最小起订量
            commonProduct.setMinimunRequire(purchaseProductSync.getMinimunRequire());

            if (StringUtils.isNotEmpty(purchaseProductSync.getUpdatedBy())) {
                commonProduct.setUpdatedBy(purchaseProductSync.getUpdatedBy());
            }

            if (StringUtils.isNotEmpty(purchaseProductSync.getRemark())) {
                commonProduct.setRamark(purchaseProductSync.getRemark());
            }
            commonProduct.setUpdatedAt(null);
            if (org.apache.commons.lang3.StringUtils.isNotEmpty(commonProduct.getId())) {
                type =2L;
                commonProductMapper.updateByPrimaryKey(commonProduct);
            } else {
                type =1L;
                commonProduct.setId(IDUtils.getUUID19());
                commonProduct.setSyncStatus(PuPrConstants.PRODUCT_SYNCED);
                commonProductMapper.insert(commonProduct);
            }
            String specData = purchaseProductSync.getSpecData();
            if (org.apache.commons.lang3.StringUtils.isNotEmpty(specData) && !"[]".equals(specData)) {
                JSONArray jsonArray = (JSONArray) JSONObject.parse(specData);
                if (null != jsonArray && !jsonArray.isEmpty()) {
                    for (int i = 0; i < jsonArray.size(); i++) {
                        try {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            String spec = jsonObject.getString("spec");
                            String specVal = jsonObject.getString("specValue");
                            Long specId = commonSpecService.syncSpec(spec, cataId, productSrc);
                            Long specValId = commonSpecValService.syncSpecVal(specVal, specId, productSrc);
                            CommonProductSpec commonProductSpec = new CommonProductSpec();
                            commonProductSpec.setProductId(productId);
                            commonProductSpec.setSpecId(specId);
                            commonProductSpec.setSpecValueId(specValId);
                            commonProductSpecService.compareAndSave(commonProductSpec);
                        } catch (Exception e) {
                            log.error("产品同步处理规格数据异常");
                            e.printStackTrace();
                        }
                    }
                }
            }
            // 增加es
            commonEsService.addByProductId(productId);
//            log.info("supplierId:" + commonProduct.getSupplierId() + "  brandId:" + brandId);
//            if (StringUtils.isNotEmpty(commonProduct.getSupplierId()) && brandId != null){
//                CheckProductDTO checkProductDTO = new CheckProductDTO();
//                checkProductDTO.setProductId(productId);
//                checkProductDTO.setBrandId(brandId);
//                checkProductDTO.setSupplierId(commonProduct.getSupplierId());
//                //取消店铺商品逻辑
//                configClient.checkProduct(checkProductDTO);
//            }

             // 修改-推送消息
            //根据产品id查询对应的规格信息
            List<String> commonSpecListOld = null;
            List<String> commonSpecValListOld = null;
            if(null != productId && null != commonProductSpecListOld) {
                //根据规格id查询对应的规格名称
                List<Long> specIdsOld = commonProductSpecListOld.stream().map(CommonProductSpec::getSpecId).collect(Collectors.toList());
                if (specIdsOld != null && specIdsOld.size() > 0) {
                    List<CommonSpec> commonSpecsOld = commonSpecService.listBySpecIds(specIdsOld);
                    commonSpecListOld = commonSpecsOld.stream().map(CommonSpec::getSpecName).collect(Collectors.toList());
                    //根据规格值id查询对应的规格值名称
                    List<Long> specValueIdsOld = commonProductSpecListOld.stream().map(CommonProductSpec::getSpecValueId).collect(Collectors.toList());
                    List<CommonSpecVal> commonSpecValsOld = commonSpecValService.listBySpecValueIds(specValueIdsOld);
                    commonSpecValListOld = commonSpecValsOld.stream().map(CommonSpecVal::getSpecValue).collect(Collectors.toList());
                }
            }
            commonProductOld.setCommonSpecList(commonSpecListOld);
            commonProductOld.setCommonSpecValList(commonSpecValListOld);

            commonProduct.setSpecData(specData);
            joinSpecData(specData,commonProduct);

            commonProduct.setCataNameOne(firstLevelCataName);
            commonProduct.setCataNameTwo(secondLevelCataName);
            commonProduct.setCataNameThree(threeLevelCataName);
            commonProduct.setBrandName(brandName);
            commonProduct.setPropName(propName);

            //如果同步参数：zydmallFlag 为空，取公共海数据的 zydmallFlag
            String zydmallFlag = purchaseProductSync.getZydmallFlag();
            if (StringUtils.isNotEmpty(zydmallFlag)) {
                zydmallFlag = commonProductOld.getZydmallFlag();
            }

            if (null != type && 2L == type) {
                // 有标记上架zydmall并且已关联上ERP产品编码的数据
                if(StringUtils.isNotEmpty(zydmallFlag)
                        && StringUtils.equals(zydmallFlag,"1")
                        && StringUtils.isNotEmpty(erpProductCodeOld)) {
                    dataSend(type,commonProductOld,commonProduct);
                }
            }


        }
        return productId;
    }


    /**
     * 数据发送
     * @param commonProduclNew: 产品新数据
     * @param commonProduclOld: 产品旧数据
     * @param type: 1-新增,2-修改
     */
    private void dataSend(Long type,CommonProduct commonProduclOld,CommonProduct commonProduclNew) {
        if(null == commonProduclOld){
            commonProduclOld = new CommonProduct();
        }
        LocalDateTime dateNow = LocalDateTime.now();
        // 使用LinkedHashMap保持字段顺序
        Map<String, Function<CommonProduct, Object>> fieldGetters2
                = new LinkedHashMap<String, Function<CommonProduct, Object>>() {{
            put("cataId", CommonProduct::getCataId);
            put("brandId", CommonProduct::getBrandId);
            put("propId", CommonProduct::getPropId);
            put("cataNameOne", CommonProduct::getCataNameOne);
            put("cataNameTwo", CommonProduct::getCataNameTwo);
            put("cataNameThree", CommonProduct::getCataNameThree);
            put("brandName", CommonProduct::getBrandName);
            put("propName", CommonProduct::getPropName);
            put("commonSpecList", CommonProduct::getCommonSpecList);
            put("commonSpecValList", CommonProduct::getCommonSpecValList);
            put("productPicName", CommonProduct::getProductPicName);
            put("productVedioName", CommonProduct::getProductVedioName); // 保持与类定义一致
            put("productContent", CommonProduct::getProductContent);
            put("productSimpleName", CommonProduct::getProductSimpleName);
            put("weight", CommonProduct::getWeight);
        }};
        List<String> differentFields2 = findDifferentFields(commonProduclOld, commonProduclNew,fieldGetters2);
        if(1L == type
                || (2L == type && null != differentFields2 && differentFields2.size()>0)) {
            //1.1 记录变更并推送给zydmall
            CommonProductMallRec commonProductMallRec = new CommonProductMallRec();
            commonProductMallRec.setId(IDUtils.getUUID19());
            commonProductMallRec.setType(type);
            commonProductMallRec.setScmProductId(commonProduclNew.getProductId());
            commonProductMallRec.setMallProductId(commonProduclNew.getZydmallProductId());
            commonProductMallRec.setErpProductCode(commonProduclNew.getErpProductCode());
            commonProductMallRec.setCataId(commonProduclNew.getCataId());
            commonProductMallRec.setBrandId(commonProduclNew.getBrandId());
            commonProductMallRec.setPropId(commonProduclNew.getPropId());
            commonProductMallRec.setCataNameOne(commonProduclNew.getCataNameOne());
            commonProductMallRec.setCataNameTwo(commonProduclNew.getCataNameTwo());
            commonProductMallRec.setCataNameThree(commonProduclNew.getCataNameThree());
            commonProductMallRec.setBrandName(commonProduclNew.getBrandName());
            commonProductMallRec.setPropName(commonProduclNew.getPropName());
            commonProductMallRec.setSpecName(commonProduclNew.getSpecName());
            commonProductMallRec.setSpecValue(commonProduclNew.getSpecValue());
            commonProductMallRec.setProductPicName(commonProduclNew.getProductPicName());
            commonProductMallRec.setProductVedioName(commonProduclNew.getProductVedioName());
            commonProductMallRec.setProductContent(commonProduclNew.getProductContent());
            commonProductMallRec.setProductSimpleName(commonProduclNew.getProductSimpleName());
            commonProductMallRec.setWeight(commonProduclNew.getWeight());
            commonProductMallRec.setCreatedAt(dateNow);
            commonProductMallRec.setUpdatedAt(dateNow);

            commonProductMallRecMapper.insert(commonProductMallRec);
        }

        //1.2 记录变更并定时推送给产线专员
        if(null != type && 2L == type) {
            //判断是否有变更字段
            CommonProductModiRec modiRecs = compare(commonProduclOld, commonProduclNew);
            boolean bool = modiRecs.areSpecifiedFieldsNull();
            if (!bool) {
                modiRecs.setId(IDUtils.getUUID19());
                modiRecs.setSupplierName(commonProduclNew.getSupplierName());
                //数据插入
                commonProductModiRecMapper.insert(modiRecs);
            }
        }

    }

    /**
     * 相同实体类，对应字段值的比较
     * @param oldObj
     * @param newObj
     * @param fieldGetters 需要比较的字段
     * @return
     */
    public List<String> findDifferentFields(CommonProduct oldObj, CommonProduct newObj,Map<String, Function<CommonProduct, Object>> fieldGetters) {
        // 空安全处理
        if (oldObj == null && newObj == null) return Collections.emptyList();
        if (oldObj == null || newObj == null) return Collections.singletonList("all_fields");

        return fieldGetters.entrySet().stream()
                .filter(entry -> {
                    try {
                        Object v1 = entry.getValue().apply(oldObj);
                        Object v2 = entry.getValue().apply(newObj);
                        String fieldName = entry.getKey();

                        // 特殊处理集合字段
                        if ("commonSpecList".equals(fieldName) || "commonSpecValList".equals(fieldName)) {
                            return !isCollectionContentEqual(v1, v2);
                        }

                        return !Objects.equals(v1, v2);
                    } catch (NullPointerException e) {
                        return true;
                    }
                })
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    /**
     * 检查两个集合内容是否相等（忽略顺序）
     * @param obj1
     * @param obj2
     * @return
     */
    private boolean isCollectionContentEqual(Object obj1, Object obj2) {
        // 处理null情况
        if (obj1 == null && obj2 == null) return true;
        if (obj1 == null || obj2 == null) return false;

        // 类型检查
        if (!(obj1 instanceof Collection) || !(obj2 instanceof Collection)) {
            return Objects.equals(obj1, obj2);
        }

        Collection<?> col1 = (Collection<?>) obj1;
        Collection<?> col2 = (Collection<?>) obj2;

        // 快速长度检查
        if (col1.size() != col2.size()) return false;

        // 使用频率计数器比较内容
        Map<Object, Integer> freqMap = new HashMap<>();
        for (Object o : col1) freqMap.put(o, freqMap.getOrDefault(o, 0) + 1);
        for (Object o : col2) {
            int count = freqMap.getOrDefault(o, 0);
            if (count == 0) return false;
            freqMap.put(o, count - 1);
        }
        return true;
    }


    /**
     * 比较两个CommonProduct对象的字段
     * 并将字段值不同的数据设置到新的CommonProductModiRec对象
     *
     * @param oldCommonProduct 旧的CommonProduct对象
     * @param newCommonProduct 新的CommonProduct对象
     * @return
     */
    public static CommonProductModiRec compare(CommonProduct oldCommonProduct, CommonProduct newCommonProduct) {
        CommonProductModiRec modiRec = new CommonProductModiRec();
        BeanUtils.copyProperties(newCommonProduct, modiRec);

        // 定义需要比较的字段及其对应的getter和setter
        List<FieldComparison<?, ?>> fieldComparisons = Arrays.asList(
                new FieldComparison<>(
                        CommonProduct::getProductType,
                        CommonProductModiRec::setProductTypeOld,
                        CommonProductModiRec::setProductTypeNew
                ),
                new FieldComparison<>(
                        CommonProduct::getSkuCode,
                        CommonProductModiRec::setSkuCodeOld,
                        CommonProductModiRec::setSkuCodeNew
                ),
                new FieldComparison<>(
                        CommonProduct::getStock,
                        CommonProductModiRec::setStockOld,
                        CommonProductModiRec::setStockNew
                ),
                new FieldComparison<>(
                        CommonProduct::getPrice,
                        CommonProductModiRec::setPriceOld,
                        CommonProductModiRec::setPriceNew
                ),
                new FieldComparison<>(
                        CommonProduct::getDeliveryDate,
                        CommonProductModiRec::setDeliveryDateOld,
                        CommonProductModiRec::setDeliveryDateNew
                ),
                new FieldComparison<>(
                        CommonProduct::getUnit,
                        CommonProductModiRec::setUnitOld,
                        CommonProductModiRec::setUnitNew
                ),
                new FieldComparison<>(
                        CommonProduct::getPrice,
                        CommonProductModiRec::setPriceOld,
                        CommonProductModiRec::setPriceNew
                ),
                new FieldComparison<>(
                        CommonProduct::getSupplyPrice,
                        CommonProductModiRec::setSupplyPriceOld,
                        CommonProductModiRec::setSupplyPriceNew
                ),
                new FieldComparison<>(
                        CommonProduct::getSuggestPrice,
                        CommonProductModiRec::setSuggestPriceOld,
                        CommonProductModiRec::setSuggestPriceNew
                ),
                new FieldComparison<>(
                        CommonProduct::getMinimunRequire,
                        CommonProductModiRec::setMinimunRequireOld,
                        CommonProductModiRec::setMinimunRequireNew
                )
        );

        // 使用Stream处理每个字段的比较
        fieldComparisons.stream().forEach(fc -> fc.compareAndSet(oldCommonProduct, newCommonProduct, modiRec));

        return modiRec;
    }

    /**
     * 获取未发送的公海_产品变更商城记录列表
     *
     * @Author: loine
     * @Date: 2025/4/2 17:20
     */
    public List<CommonProductMallRecVo> getProductMallRecNotSendList() {
        return commonProductMallRecMapper.getProductMallRecNotSendList();
    }

    /**
     * 更新公海_产品变更商城记录发送状态
     *
     * @param ids
     * @Author: loine
     * @Date: 2025/4/2 17:29
     */
    public JsonResult productMallRecUpdateSend(List<String> ids) {
        if (CollectionUtils.isNotEmpty(ids)) {
            commonProductMallRecMapper.productMallRecUpdateSend(ids);
        }
        return new JsonResult<>(true, "操作成功");
    }

    // 辅助类，封装字段比较逻辑
    private static class FieldComparison<T, U> {
        private final Function<CommonProduct, T> getter;
        private final BiConsumer<CommonProductModiRec, T> oldSetter;
        private final BiConsumer<CommonProductModiRec, T> newSetter;

        public FieldComparison(
                Function<CommonProduct, T> getter,
                BiConsumer<CommonProductModiRec, T> oldSetter,
                BiConsumer<CommonProductModiRec, T> newSetter
        ) {
            this.getter = getter;
            this.oldSetter = oldSetter;
            this.newSetter = newSetter;
        }

        public void compareAndSet(CommonProduct oldProduct, CommonProduct newProduct, CommonProductModiRec modiRec) {
            // 安全获取新旧值：如果对象为 null，则值为 null
            T oldValue = (oldProduct != null) ? getter.apply(oldProduct) : null;
            T newValue = (newProduct != null) ? getter.apply(newProduct) : null;

            // 比较值是否不同（包括处理 null 的情况）
            if (!Objects.equals(oldValue, newValue)) {
                oldSetter.accept(modiRec, oldValue);
                newSetter.accept(modiRec, newValue);
            }
        }
    }

    /**
     * 解析JSON并合并规格名和值
     */
    public void joinSpecData(String specData,CommonProduct commonProduct) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            List<SpecItem> items = mapper.readValue(specData, new TypeReference<List<SpecItem>>() {});

            // 提取并合并规格名和值
            String specName = items.stream()
                    .map(SpecItem::getSpec)
                    .collect(Collectors.joining("@"));

            String specValue = items.stream()
                    .map(SpecItem::getSpecValue)
                    .collect(Collectors.joining("@"));

            // 处理List集合
            commonProduct.setCommonSpecList(
                    items.stream()
                            .map(SpecItem::getSpec)
                            .collect(Collectors.toList())
            );

            commonProduct.setCommonSpecValList(
                    items.stream()
                            .map(SpecItem::getSpecValue)
                            .collect(Collectors.toList())
            );
            // 设置到目标对象
            commonProduct.setSpecName(specName);
            commonProduct.setSpecValue(specValue);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 内部类用于解析JSON
    @Data
    private static class SpecItem {
        private String spec;
        private String specValue;

        private List<String> commonSpecList;

        private List<String> commonSpecValList;
    }

    private CommonProduct getByZydmallProductId(Long zydmallProductId) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CommonProduct.ZYDMALL_PRODUCT_ID, zydmallProductId);
        List<CommonProduct> commonProducts = commonProductMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(commonProducts)) {
            return commonProducts.get(0);
        }
        return null;
    }

    private CommonProduct getByProductId(Long publicProductId) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CommonProduct.PRODUCT_ID, publicProductId);
        List<CommonProduct> commonProducts = commonProductMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(commonProducts)) {
            return commonProducts.get(0);
        }
        return null;
    }

    /**
     * 获取最大产品id+1
     *
     * @return
     */
    private Long getMaxProductId() {
        Long num = RedisUtil.genCode("common_product_id", redisTemplate, () -> {
            return commonProductMapper.getMaxProductId();
        });
        try{
            DecimalFormat df = new DecimalFormat("00000000000");
            String numTemp = "1688" + df.format(num);
            num = Long.parseLong(numTemp);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return num;
    }

    /**
     * 根据主键，编辑erp商品编码
     *
     * @param product 编码
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void updateErpProductId(CommonProduct product) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(product).isNotEmpty(product.getId());
        String erpProductCode = product.getErpProductCode();
        if (StringUtils.isNotEmpty(erpProductCode)) {
            // 合法校验
            boolean matches = erpProductCode.matches(PuPrConstants.REGEX_ERP_PRODUCT_CODE);
            CheckFlow.start(PuPrErrorCode.COMMON_ERP_PRODUCT_CODE_ERROR).isTrue(matches);
            // 重复校验
            validateErpProductCode(erpProductCode, product.getId());
        }

        String id = product.getId();
        CommonProduct dbProduct = get(id);
        if (null == dbProduct) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }

        dbProduct.setErpProductCode(erpProductCode);
        dbProduct.setUpdatedAt(LocalDateTime.now());
        dbProduct.setUpdatedBy(ContextHandler.getUserId());
        dbProduct.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        commonProductMapper.updateByPrimaryKey(dbProduct);
    }

    /**
     * erp商品编码重复校验
     *
     * @param erpProductCode erp商品编码
     */
    private void validateErpProductCode(String erpProductCode, String id) {
        /*List<String> idList = listIdsByExample(new CommonProduct().setErpProductCode(erpProductCode));
        if (CollectionUtils.isEmpty(idList)) {
            return;
        }*/
        Example example = new Example(entityClass);
        example.createCriteria().andEqualTo(CommonProduct.ERP_PRODUCT_CODE, erpProductCode)
                .andNotEqualTo(CommonProduct.ID, id);
        List<CommonProduct> products = commonProductMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(products)) {
            return;
        }
        throw new BaseException(PuPrErrorCode.COMMON_ERP_PRODUCT_CODE_EXIST_ERROR);
    }

    /**
     * 根据主键，获取商品详情
     *
     * @param id 主键
     * @return 商品详情
     */
    @Transactional(readOnly = true)
    public CommonProduct getDetail(String id, Long productId) {
        CommonProduct product = null;
        if (id != null) {
            product = get(id);
        } else if (productId != null) {
            product = commonProductMapper.selectByProductId(productId);
        } else {
            CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(id);
        }
        if (null == product) {
            return null;
        }

        Long brandId = product.getBrandId();
        if (null != brandId) {
            CommonBrand brand = commonBrandService.getByProperty(CommonBrand.BRAND_ID, brandId, CommonBrand.BRAND_NAME);
            product.setBrandName(null == brand ? null : brand.getBrandName());
        }

        Long propId = product.getPropId();
        if (null != propId) {
            CommonProp prop = commonPropService.getByProperty(CommonProp.PROP_ID, propId, CommonProp.PROP_NAME);
            product.setPropName(null == prop ? null : prop.getPropName());
        }

        Long cataId = product.getCataId();
        if (null != cataId) {
            Map<Long, Map<Integer, String>> cataIdNamePathMap = commonCatalogService.mapNameByCataIds(Sets.newHashSet(cataId));
            Map<Integer, String> levelNameMap = cataIdNamePathMap.get(cataId);
            if (MapUtils.isNotEmpty(levelNameMap)) {
                product.setCataNameOne(levelNameMap.get(1));
                product.setCataNameTwo(levelNameMap.get(2));
                product.setCataNameThree(levelNameMap.get(3));
            }
        }

        List<CommonProductSpec> productSpecList = commonProductSpecService.listByProperty(CommonProductSpec.PRODUCT_ID,
                product.getProductId(), CommonProductSpec.SPEC_ID, CommonProductSpec.SPEC_VALUE_ID);
        if (CollectionUtils.isNotEmpty(productSpecList)) {
            List<CommonSpecVal> specValList = getSpecValList(productSpecList);
            product.setSpecValList(specValList);
        }

        return product;
    }

    public List<CommonSpecVal> getSpecValList(List<CommonProductSpec> productSpecList) {
        Set<Long> specIds = Sets.newHashSet();
        Set<Long> specValIds = Sets.newHashSet();
        productSpecList.forEach(p -> {
            specIds.add(p.getSpecId());
            specValIds.add(p.getSpecValueId());
        });
        CommonSpecVal commonSpecVal = new CommonSpecVal();
        commonSpecVal.setSpecIds(specIds);
        commonSpecVal.setSpecValIds(specValIds);
        return commonSpecValService.selectSpecAndSpecVal(commonSpecVal);
    }

    /**
     * 根据条件，获取对象集合
     *
     * @param product 条件
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public List<CommonProduct> listByExample(CommonProduct product) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(product);
        Example example = genConditionExample(product);
        List<CommonProduct> list = commonProductMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(list)) {
            return list;
        }

        Set<Long> productIds = list.stream().map(CommonProduct::getProductId).collect(Collectors.toSet());
        Map<Long, List<CommonProductSpec>> specMap = commonProductSpecService.mapByProductId(productIds);
        if (MapUtils.isEmpty(specMap)) {
            return list;
        }

        list.forEach(l -> {
            List<CommonProductSpec> productSpecs = specMap.get(l.getProductId());
            if (CollectionUtils.isEmpty(productSpecs)) {
                return;
            }

            List<CommonSpecVal> specValList = getSpecValList(productSpecs);
            l.setSpecValList(specValList);
        });
        return list;
    }

    /**
     * 根据产品id获取产品集合
     * @param productIds
     * @return
     */
    public List<CommonProductDto> listProductByProductIds(List<Long> productIds) {
        if (CollectionUtils.isEmpty(productIds)) {
            return Collections.emptyList();
        }
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andIn(CommonProduct.PRODUCT_ID, productIds);
        List<CommonProduct> list = commonProductMapper.selectByExample(example);
        packCommonProductData(list);
        if (CollectionUtils.isNotEmpty(list)) {
            List<CommonProductDto> commonProductDtos = new ArrayList<>(list.size());
            for (CommonProduct commonProduct : list) {
                List<CommonProductSpec> productSpecList = commonProductSpecService.listByProperty(CommonProductSpec.PRODUCT_ID,
                        commonProduct.getProductId(), CommonProductSpec.SPEC_ID, CommonProductSpec.SPEC_VALUE_ID);
                CommonProductDto commonProductDto = new CommonProductDto();
                commonProductDto.setId(commonProduct.getId());
                commonProductDto.setProductId(commonProduct.getProductId());
                commonProductDto.setErpProductCode(commonProduct.getErpProductCode());
                commonProductDto.setSupplierProductCode(commonProduct.getSupplierProductCode());
                commonProductDto.setProductName(commonProduct.getProductName());
                commonProductDto.setProductType(commonProduct.getProductType());
                commonProductDto.setSkuCode(commonProduct.getSkuCode());
                commonProductDto.setPrice(commonProduct.getPrice());
                commonProductDto.setCataId(commonProduct.getCataId());
                commonProductDto.setBrandId(commonProduct.getBrandId());
                commonProductDto.setBrandName(commonProduct.getBrandName());
                commonProductDto.setPropId(commonProduct.getPropId());
                commonProductDto.setPropName(commonProduct.getPropName());
                commonProductDto.setUnit(commonProduct.getUnit());
                commonProductDto.setWeight(commonProduct.getWeight());
                commonProductDto.setIsOnsale(commonProduct.getIsOnsale());
                commonProductDto.setProductPicName(commonProduct.getProductPicName());
                commonProductDto.setProductModelName(commonProduct.getProductModelName());
                commonProductDto.setProductSimpleName(commonProduct.getProductSimpleName());
                commonProductDto.setProductVedioName(commonProduct.getProductVedioName());
                commonProductDto.setProductContent(commonProduct.getProductContent());
                commonProductDto.setIsAdjustPrice(commonProduct.getIsAdjustPrice());
                commonProductDto.setProductSrc(commonProduct.getProductSrc());
                commonProductDto.setIsValid(commonProduct.getIsValid());
                commonProductDto.setExistsAttachment(commonProduct.getExistsAttachment());
                commonProductDto.setPackageUnit(commonProduct.getPackageUnit());
                commonProductDto.setStock(commonProduct.getStock());
                commonProductDto.setPurchasePrice(commonProduct.getPurchasePrice());
                commonProductDto.setSupplyPrice(commonProduct.getSupplyPrice());
                commonProductDto.setSuggestPrice(commonProduct.getSuggestPrice());
                commonProductDto.setDeliveryDate(commonProduct.getDeliveryDate());
                commonProductDto.setSupplierId(commonProduct.getSupplierId());
                commonProductDto.setCataNameOne(commonProduct.getCataNameOne());
                commonProductDto.setCataNameTwo(commonProduct.getCataNameTwo());
                commonProductDto.setCataNameThree(commonProduct.getCataNameThree());
                commonProductDto.setSample(commonProduct.getProductSimpleName());
                commonProductDto.setApplyNo(commonProduct.getApplyNo());
                commonProductDto.setApplySource(commonProduct.getApplySource());
                commonProductDto.setMaterialName(commonProduct.getMaterialName());
                if (CollectionUtils.isNotEmpty(productSpecList)) {
                    List<CommonSpecVal> specValList = getSpecValList(productSpecList);
                    log.info("productSpecList:{}", productSpecList);
                    log.info("specValList:{}", specValList);
                    commonProduct.setSpecValList(specValList);
                    JSONArray jsonArray = new JSONArray(specValList.size());
                    for (CommonSpecVal commonSpecVal:specValList) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("spec", commonSpecVal.getSpecName());
                        jsonObject.put("specValue", commonSpecVal.getSpecValue());
                        jsonArray.add(jsonObject);
                    }
                    commonProductDto.setSpecData(jsonArray.toJSONString());
                }
                commonProductDtos.add(commonProductDto);
            }
            log.info("commonProductDtos:{}", commonProductDtos);
            return commonProductDtos;
        }

        return Collections.emptyList();
    }

    public Page<CommonProduct> list(CommonProduct commonProduct, Page<CommonProduct> page) {
        Assert.notNull(commonProduct, "commonProduct can not be null!");
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        String supplierId = (String) ContextHandler.get("supplierId");
//        commonProduct.setProductSrc(PuPrConstants.SUPPLY);
        if (StringUtils.isNotBlank(supplierId)) {
            commonProduct.setSupplierId(supplierId);
//            commonProduct.setProductSrc(PuPrConstants.SUPPLIER);
        }
        List<CommonProduct> list = commonProductMapper.list(commonProduct);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packCommonProductData(list);
        return page;
    }

    public List<CommonProduct> list(CommonProduct commonProduct) {
        Assert.notNull(commonProduct, "commonProduct can not be null!");
        String supplierId = (String) ContextHandler.get("supplierId");
        commonProduct.setProductSrc(PuPrConstants.SUPPLY);
        if (StringUtils.isNotBlank(supplierId)) {
            commonProduct.setSupplierId(supplierId);
            commonProduct.setProductSrc(PuPrConstants.SUPPLIER);
        }
        List<CommonProduct> list = commonProductMapper.list(commonProduct);
        packCommonProductData(list);
        return list;
    }

    /**
     * 查询所有三方关系
     *
     * @return 三方关系
     */
    @Transactional(readOnly = true)
    public List<CommonCataBrandProp> listToRebuildTripartiteRelationship() {
        return commonProductMapper.listToRebuildTripartiteRelationship();
    }

    /**
     * 校验分类名称与erpCode
     * @param firstLevelCataName
     * @param secondLevelCataName
     * @param threeLevelCataName
     * @param erpProductCode
     * @param productId
     * @return
     */
    public JsonResult checkCataAndCode(String firstLevelCataName, String secondLevelCataName, String threeLevelCataName, String erpProductCode, Long productId) {

//        if (StringUtils.isBlank(firstLevelCataName)) {
//            return new JsonResult<>(false, "一级分类信息有误");
//        }
//        if (StringUtils.isBlank(secondLevelCataName)) {
//            return new JsonResult<>(false, "二级分类信息有误");
//        }
//        if (StringUtils.isBlank(threeLevelCataName)) {
//            return new JsonResult<>(false, "三级分类信息有误");
//        }
        if (StringUtils.isNotEmpty(firstLevelCataName) && StringUtils.isNotEmpty(secondLevelCataName) && StringUtils.isNotEmpty(threeLevelCataName)){
            String checkCataResult = commonCatalogService.checkCata(firstLevelCataName, secondLevelCataName, threeLevelCataName);
            if (StringUtils.isNotBlank(checkCataResult)) {
                return new JsonResult<>(false, checkCataResult);
            }
        }

        if (StringUtils.isNotBlank(erpProductCode)) {
            // 合法校验
            boolean matches = erpProductCode.matches(PuPrConstants.REGEX_ERP_PRODUCT_CODE);
            if (BooleanUtils.isNotTrue(matches)) {
                return new JsonResult<>(false, "商品编码只能使用字母和数字，请重新填写");
            }
            Example example = new Example(entityClass);
            Example.Criteria criteria = example.createCriteria();
            criteria.andEqualTo(CommonProduct.ERP_PRODUCT_CODE, erpProductCode);
            if (productId != null) {
                criteria.andNotEqualTo(CommonProduct.PRODUCT_ID, productId);
            }
            List<CommonProduct> list = commonProductMapper.selectByExample(example);
            if (CollectionUtils.isNotEmpty(list)) {
                return new JsonResult<>(false, "ERP商品编码已存在");
            }
        }

        return new JsonResult<>(true, "验证通过");
    }

    public JsonResult<DetailResponse> baseXInfo(CommonProduct request) {
        Assert.notNull(request, "request can not be null!");
        // String supplierCode =(String) ContextHandler.get("supplierCode");
//         String prefix = ossConfig.getOssUrl() + "purchase" + (StringUtils.isEmpty(supplierCode) ? "" : "_"+supplierCode) + ossConfig.getCorpOssPrex();
        String prefix = ossConf.getOssUrl();
        // 公海产品
        JsonResult<DetailResponse> result = commonBaseInfo(request.getProductId());
        result.getData().setUrlPrefix(prefix);
        return result;
    }

    private JsonResult<DetailResponse> commonBaseInfo(Long productId) {
        Assert.notNull(productId, "request can not be null!");
        DetailResponse detailResponse = new DetailResponse();

        //公海产品
        CommonProduct tenantProduct = getByProductId(productId);
        if (null == tenantProduct) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }
        // 规格
        CommonProductSpec commonProductSpec = new CommonProductSpec();
        commonProductSpec.setProductId(productId);
        List<CommonProductSpec> commonProductSpecs = commonProductSpecService.listByExample(commonProductSpec);
        List<SpecAndValDTO> specAndValDTOList = new ArrayList<>(commonProductSpecs.size());
        List<CommonSpecVal> specValList = getSpecValList(commonProductSpecs);
        if (CollectionUtils.isNotEmpty(specValList)) {
            for (CommonSpecVal specVal : specValList) {
                SpecAndValDTO specAndVal = new SpecAndValDTO();
                specAndVal.setSpecName(specVal.getSpecName());
                specAndVal.setSpecValue(specVal.getSpecValue());
                specAndValDTOList.add(specAndVal);
            }
        }

        // 品牌
        Long brandId = tenantProduct.getBrandId();
        CommonBrand commonBrand = null;
        String brandImgUrl = null;
        if (null != brandId) {
            CommonBrand commonBrandExample = new CommonBrand();
            commonBrandExample.setBrandId(brandId);
            commonBrand = commonBrandService.getByExample(commonBrandExample);
            if (StringUtils.isNotEmpty(commonBrand.getPicUrl())){
                brandImgUrl = commonBrand.getPicUrl();
            }
        }

        // 分类
        Long paramCataId = tenantProduct.getCataId();
        CommonCatalog commonCatalog = null;
        if (null != paramCataId) {
            CommonCatalog commonCatalogExample = new CommonCatalog();
            commonCatalogExample.setCataId(paramCataId);
            commonCatalog = commonCatalogService.getByExample(commonCatalogExample);
        }

        // 系列
        Long propId = tenantProduct.getPropId();
        CommonProp commonProp = null;
        if (null != propId) {
            CommonProp commonPropExample = new CommonProp();
            commonPropExample.setPropId(propId);
            commonProp = commonPropService.getByExample(commonPropExample);
        }

        DetailResponse.Info info = new DetailResponse.Info();
        BeanUtils.copyProperties(tenantProduct, info);
        info.setIsCataShowProp(null == commonCatalog ? null : commonCatalog.getIsShowProp());
        String brandName = null == commonBrand ? "" : commonBrand.getBrandName();
        info.setBrandName(brandName);
        String propName = null == commonProp ? "" : commonProp.getPropName();
        info.setPropName(propName);
        info.setCataName(null == commonCatalog ? null : commonCatalog.getCataName());
        info.setSpecAndVals(specAndValDTOList);
        String supplierCode =(String) ContextHandler.get("supplierCode");
        supplierCode = StringUtils.isEmpty(supplierCode) ? "" : supplierCode;
        String key = "companySetting:" + supplierCode;
        ValueOperations<String, DisplaySettingDTO> ops = redisTemplate.opsForValue();
        DisplaySettingDTO displaySetting = ops.get(key);
        info.setDisplayName(displaySetting != null ? displaySetting.getName() : "");

        List<CommonCatalog> commonCatalogs = Lists.newArrayList();
        if (null != commonCatalog) {
            List<String> cataIdList = new ArrayList<>();
            Collections.addAll(cataIdList, commonCatalog.getCataIds().split(","));
            List<Long> cataIdLongs = new ArrayList<>(cataIdList.size());
            if (CollectionUtils.isNotEmpty(cataIdList)) {
                for (String cataId : cataIdList) {
                    cataIdLongs.add(Long.valueOf(cataId));
                }

                CommonCatalog commonCatalog2 = new CommonCatalog();
                commonCatalog2.setCataIdList(cataIdLongs);
                commonCatalogs = commonCatalogService.selectByCataIds(commonCatalog2);
                info.setCataIdList(commonCatalogs.stream().map(CommonCatalog::getCataName).collect(Collectors.toList()));
            }
        }

        // 设置品牌图
        String name = "";
        try {
            name = URLEncoder.encode(brandName, "UTF-8");
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        if (StringUtils.isEmpty(brandImgUrl)){
            if (StringUtils.isNotEmpty(name)){
                brandImgUrl = commonOssConf.getOssUrl() + "product/brand/" + name + "/" + name + "logo.png";
            }
        }
        info.setBrandImgUrl(brandImgUrl);
        boolean zydmall = PuPrConstants.ZYDMALL.equals(tenantProduct.getProductSrc());
        if (zydmall) {
            if (StringUtils.isNotEmpty(name)){
                brandImgUrl = commonOssConf.getOssUrl() + "product/brand/" + name + "/" + name + "logo.png";
            }
        }

        detailResponse.setInfo(info);
        if (!zydmall) {
            notZydmallData(detailResponse, tenantProduct);
            return JsonResult.ok("查询成功", detailResponse);
        }

        String domainName = (String) redisTemplate.opsForHash().get("domain_corp", supplierCode);
        String domainNameEncode = null;
        //公海产品详情
        String filePath = "product/image" + "/" + brandName + "/" + commonCatalogs.get(0).getCataName() +
                "/" + commonCatalogs.get(1).getCataName() + "/" + commonCatalogs.get(2).getCataName() +
                "/" + brandName + "_" + (null == commonCatalogs.get(0) ? "" : commonCatalogs.get(0).getCataName())
                + "_" + (null == commonCatalogs.get(1) ? "" : commonCatalogs.get(1).getCataName())
                + "_" + (null == commonCatalogs.get(2) ? "" : commonCatalogs.get(2).getCataName()) + "_" + propName;

        OSS ossClient = new OSSClientBuilder().build(commonOssConf.getEndpoint(), commonOssConf.getAccessKeyId(), commonOssConf.getAccessKeySecret());
        //编码水印
        //租户公海产品空间水印图
        OSS commonOssClient = new OSSClientBuilder().build(commonOssConf.getEndpoint(), commonOssConf.getAccessKeyId(), commonOssConf.getAccessKeySecret());
        ListObjectsRequest commonListObjectsRequest = new ListObjectsRequest(commonOssConf.getBucketName());
        String commonWatermarkReplace = commonWatermark.replace("{corp}", supplierCode);
        commonListObjectsRequest.setPrefix(commonWatermarkReplace);
        ObjectListing commonlisting = commonOssClient.listObjects(commonListObjectsRequest);
        String commonWatermarkEncode = null;
        if (CollectionUtils.isNotEmpty(commonlisting.getObjectSummaries())) {
            //判断是否有公海产品水印
            commonWatermarkEncode = Base64.getEncoder().encodeToString((commonWatermarkReplace + watermarksize).getBytes()).replace("+", "-").replace("/", "_");
        } else {
            domainNameEncode = Base64.getEncoder().encodeToString(StringUtils.isEmpty(domainName) ? "".getBytes() : domainName.getBytes());
        }
        commonOssClient.shutdown();
        //获取图片
        List<DetailResponse.Image> imageList = getImageList(info, filePath, commonWatermarkEncode, domainNameEncode);
        detailResponse.setImageList(imageList);
        //获取视频
        List<DetailResponse.Vedio> vedioList = getVedioList(info, ossClient, filePath);
        detailResponse.setVedioList(vedioList);
        //样本信息
        List<DetailResponse.Sample> sampleList = getSampleList(ossClient, filePath);
        detailResponse.setSampleList(sampleList);
        //3D信息
        List<DetailResponse.ThreeD> threeDList = getThreeDList(ossClient, filePath);
        detailResponse.setThreeDList(threeDList);
        //获取内容（产品系列图，系列概述，特性描述，选型指南，产品尺寸图，组装图）
        getContent(detailResponse, info, ossClient, filePath, commonWatermarkEncode, domainNameEncode);
        //关闭ossclient
        ossClient.shutdown();
        return JsonResult.ok("查询成功", detailResponse);
    }

    private void notZydmallData(DetailResponse detailResponse, CommonProduct tenantProduct) {
        String productPicName = tenantProduct.getProductPicName();
        String productVedioName = tenantProduct.getProductVedioName();
        String sample = tenantProduct.getProductSimpleName();
        String[] productPicList = null;
        if (StringUtils.isNotBlank(productPicName)) {
            productPicList = productPicName.split("@");
        }
        String[] productVedioList = null;
        if (StringUtils.isNotBlank(productVedioName)) {
            productVedioList = productVedioName.split("@");
        }
        String[] sampleList = null;
        if (StringUtils.isNotBlank(sample)) {
            sampleList = sample.split("@");
        }
        List<DetailResponse.Image> imageList = new ArrayList<>();
        if (null != productPicList && productPicList.length > 0) {
            for (int i=0;i<productPicList.length;i++) {
                DetailResponse.Image image = new DetailResponse.Image();
                image.setImgSrcUrl(productPicList[i]);
                image.setImgSmallUrl(productPicList[i]);
                imageList.add(image);
            }
        }
        detailResponse.setImageList(imageList);
        List<DetailResponse.Vedio> vedioList = new ArrayList<>();
        if (null != productVedioList && productVedioList.length > 0) {
            for (int i=0;i<productVedioList.length;i++) {
                DetailResponse.Vedio vedio = new DetailResponse.Vedio();
                vedio.setVedioUrl(productVedioList[i]);
                vedioList.add(vedio);
            }
        }
        detailResponse.setVedioList(vedioList);

        List<DetailResponse.Sample> samples = new ArrayList<>();
        if (null != sampleList && sampleList.length > 0) {
            for (int i=0;i<sampleList.length;i++) {
                String temp = sampleList[i];
                if (StringUtils.isNotBlank(temp)) {
                    DetailResponse.Sample sample1 = new DetailResponse.Sample();
                    sample1.setFileUrl(temp);
                    sample1.setFileName(temp);
                    if (temp.contains("/")) {
                        sample1.setFileName(temp.substring(temp.lastIndexOf("/")+1));
                    }
                    if (temp.contains("%2F")) {
                        sample1.setFileName(temp.substring(temp.lastIndexOf("%2F")+3));
                    }
                    samples.add(sample1);
                }

            }
        }
        detailResponse.setSampleList(samples);
    }

    public List<DetailResponse.Image> getImageList(DetailResponse.Info info, String filePath, String commonWatermarkEncode, String domainNameEncode) {
        List<DetailResponse.Image> imageList = new ArrayList<>();
        if(BeanUtil.isEmpty(info.getProductPicName())){
            return imageList;
        }
        String[] productPicNames = info.getProductPicName().split("@");
        for (String productPicName : productPicNames) {
            DetailResponse.Image image = new DetailResponse.Image();
            StringBuilder imageSmallUrl = new StringBuilder();
            imageSmallUrl.append(commonOssConf.getOssUrl()).append(filePath).append("/" + PdConstants.CommonProductOssType.IMAGE.value).append("/" + productPicName + ".jpg");
            StringBuilder imgSrcUrl = new StringBuilder();
            imgSrcUrl.append(commonOssConf.getOssUrl()).append(filePath).append("/" + PdConstants.CommonProductOssType.IMAGE.value).append("/" + productPicName + ".jpg");
            if (StringUtils.isNotEmpty(domainNameEncode)) {
                imageSmallUrl.append("?x-oss-process=image").append("/resize,w_135,h_135").append(textmarksize).append(domainNameEncode).append(",size_10").append("&random=" + System.currentTimeMillis());
                imgSrcUrl.append("?x-oss-process=image").append(textmarksize).append(domainNameEncode).append(",size_50").append("&random=" + System.currentTimeMillis());
            } else if (StringUtils.isNotEmpty(commonWatermarkEncode)) {
                imageSmallUrl.append("?x-oss-process=image").append("/resize,w_135,h_135").append("/watermark,image_" + commonWatermarkEncode + ",g_center").append("&random=" + System.currentTimeMillis());
                imgSrcUrl.append("?x-oss-process=image").append("/watermark,image_" + commonWatermarkEncode + ",g_center").append("&random=" + System.currentTimeMillis());
            }
            image.setImgSmallUrl(imageSmallUrl.toString());
            image.setImgSrcUrl(imgSrcUrl.toString());
            imageList.add(image);
        }
        return imageList;
    }

    public List<DetailResponse.Vedio> getVedioList(DetailResponse.Info info, OSS ossClient, String filePath) {
        List<DetailResponse.Vedio> vedioList = new ArrayList<>();
        StringBuilder filePathStringBuilder = new StringBuilder();
        filePathStringBuilder.append(filePath).append("/" + PdConstants.CommonProductOssType.VEDIO.value).append("/" + info.getProductVedioName());
        ListObjectsRequest listObjectsRequest = new ListObjectsRequest(commonOssConf.getBucketName());
        listObjectsRequest.setPrefix(filePathStringBuilder.toString());
        ObjectListing listing = ossClient.listObjects(listObjectsRequest);
        DetailResponse.Vedio vedio = new DetailResponse.Vedio();
        for (OSSObjectSummary objectSummary : listing.getObjectSummaries()) {
            String[] keySpilt = objectSummary.getKey().split("[.]");
            StringBuilder vedioUrl = new StringBuilder();
            vedioUrl.append(commonOssConf.getOssUrl());
            vedioUrl.append(objectSummary.getKey());
            if (keySpilt.length == 2) {
                if (StringUtils.equalsIgnoreCase("jpg", keySpilt[1])) {
                    vedio.setVedioImgUrl(vedioUrl.toString() + "?random=" + System.currentTimeMillis());
                } else if (StringUtils.equalsIgnoreCase("mp4", keySpilt[1])) {
                    vedio.setVedioUrl(vedioUrl.toString());
                }
            }
        }
        if (StringUtils.isNotEmpty(vedio.getVedioImgUrl()) || org.apache.commons.lang.StringUtils.isNotEmpty(vedio.getVedioUrl())) {
            vedioList.add(vedio);
        }
        return vedioList;
    }

    public List<DetailResponse.Sample> getSampleList(OSS ossClient, String filePath) {
        List<DetailResponse.Sample> sampleList = new ArrayList<>();
        StringBuilder filePathStringBuilder = new StringBuilder();
        filePathStringBuilder.append(filePath).append("/" + PdConstants.CommonProductOssType.SAMPLE.value);
        ListObjectsRequest listObjectsRequest = new ListObjectsRequest(commonOssConf.getBucketName());
        listObjectsRequest.setPrefix(filePathStringBuilder.toString());
        ObjectListing listing = ossClient.listObjects(listObjectsRequest);
        for (OSSObjectSummary objectSummary : listing.getObjectSummaries()) {
            String[] keySpilt = objectSummary.getKey().split("[.]");
            if (keySpilt.length == 2) {
                if (StringUtils.equalsIgnoreCase("pdf", keySpilt[1])) {
                    StringBuilder sampleUrl = new StringBuilder();
                    sampleUrl.append(commonOssConf.getOssUrl()).append(URLEncoder.encode(objectSummary.getKey()));
                    DetailResponse.Sample sample = new DetailResponse.Sample();
                    String[] keySpiltByName = objectSummary.getKey().split("/");
                    sample.setFileUrl(sampleUrl.toString());
                    sample.setFileName(keySpiltByName[keySpiltByName.length - 1]);
                    sample.setFileSize(objectSummary.getSize());
                    sampleList.add(sample);
                }
            } else if (keySpilt.length > 2) {
                if (StringUtils.equalsIgnoreCase("pdf", keySpilt[keySpilt.length - 1])) {
                    StringBuilder sampleUrl = new StringBuilder();
                    sampleUrl.append(commonOssConf.getOssUrl()).append(URLEncoder.encode(objectSummary.getKey()));
                    DetailResponse.Sample sample = new DetailResponse.Sample();
                    String[] keySpiltByName = objectSummary.getKey().split("/");
                    sample.setFileUrl(sampleUrl.toString());
                    sample.setFileName(keySpiltByName[keySpiltByName.length - 1]);
                    sample.setFileSize(objectSummary.getSize());
                    sampleList.add(sample);
                }
            }
        }
        return sampleList;
    }

    public List<DetailResponse.ThreeD> getThreeDList(OSS ossClient, String filePath) {
        List<DetailResponse.ThreeD> threeDList = new ArrayList<>();

        StringBuilder filePathStringBuilder = new StringBuilder();
        filePathStringBuilder.append(filePath).append("/" + PdConstants.CommonProductOssType.THREE_D.value);
        ListObjectsRequest listObjectsRequest = new ListObjectsRequest(commonOssConf.getBucketName());
        listObjectsRequest.setPrefix(filePathStringBuilder.toString());
        ObjectListing listing = ossClient.listObjects(listObjectsRequest);
        try {
            for (OSSObjectSummary objectSummary : listing.getObjectSummaries()) {
                String[] keySpilt = objectSummary.getKey().split("[.]");
                if (keySpilt.length == 2) {
                    if (StringUtils.equalsIgnoreCase("txt", keySpilt[1])) {
                        StringBuilder threeDUrl = new StringBuilder();
                        threeDUrl.append(commonOssConf.getOssUrl()).append(objectSummary.getKey());
                        OSSObject ossObject = ossClient.getObject(commonOssConf.getBucketName(), objectSummary.getKey());
                        InputStreamReader inputStreamReader = new InputStreamReader(ossObject.getObjectContent(), "UTF-8");
                        BufferedReader br = new BufferedReader(inputStreamReader);
                        String line = null;
                        while ((line = br.readLine()) != null) {
                            if (line.contains("=")) {
                                DetailResponse.ThreeD threeD = new DetailResponse.ThreeD();
                                threeD.setName(line.substring(0, line.indexOf("=")));
                                threeD.setUrl(line.substring(line.indexOf("=") + 1));
                                threeDList.add(threeD);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.info("获取3D资源异常：", e);
        }
        return threeDList;
    }

    /**
     * 获取公海的系列概述、全家福等，commonWatermarkEncode和domainNameEncode都为空是，使用原图
     *
     * @param detailResponse
     * @param info
     * @param ossClient
     * @param filePath
     * @param commonWatermarkEncode 图片水印
     * @param domainNameEncode      域名水印
     */
    public void getContent(DetailResponse detailResponse, DetailResponse.Info info, OSS ossClient, String filePath, String commonWatermarkEncode, String domainNameEncode) {
        List<DetailResponse.Content> contentList = new ArrayList<>();

        if (StringUtils.equalsIgnoreCase(info.getProductContent(), PdConstants.CommonProductContent.CHECK_PROP_CONTENT.value)) {
            StringBuilder filePathStringBuilder = new StringBuilder();
            filePathStringBuilder.append(filePath).append("/" + PdConstants.CommonProductOssType.CONTENT.value);
            ListObjectsRequest listObjectsRequest = new ListObjectsRequest(commonOssConf.getBucketName());
            listObjectsRequest.setPrefix(filePathStringBuilder.toString());
            ObjectListing listing = ossClient.listObjects(listObjectsRequest);

            StringBuilder charDescBuilder = new StringBuilder();
            HashMap<String, List<String>> contentMap = new HashMap<>();

            for (OSSObjectSummary objectSummary : listing.getObjectSummaries()) {
                String[] keySpilt = objectSummary.getKey().split("/");
                String lastKeySpilt = keySpilt[keySpilt.length - 1];
                StringBuilder url = new StringBuilder();
                url.append(commonOssConf.getOssUrl()).append(objectSummary.getKey());
                if (lastKeySpilt.contains("全家福") && lastKeySpilt.contains(".jpg") && !lastKeySpilt.contains("有水印")) {
                    List<String> urls = new LinkedList<>();
                    if (contentMap.containsKey(PdConstants.CommonProductImage.PRODCUT_PROP_IMAGE.value)) {
                        urls = contentMap.get(PdConstants.CommonProductImage.PRODCUT_PROP_IMAGE.value);
                    }
                    if (StringUtils.isNotEmpty(domainNameEncode)) {
                        urls.add(url + "?x-oss-process=image" + textmarksize + domainNameEncode + ",size_50" + "&random=" + System.currentTimeMillis());
                    } else if (StringUtils.isNotEmpty(commonWatermarkEncode)) {
                        urls.add(url + "?x-oss-process=image/watermark,image_" + commonWatermarkEncode + ",g_center" + "&random=" + System.currentTimeMillis());
                    } else {
                        urls.add(url.toString());
                    }
                    contentMap.put(PdConstants.CommonProductImage.PRODCUT_PROP_IMAGE.value, urls);
                } else if (lastKeySpilt.contains("系列概述") && lastKeySpilt.contains("jpg") && !lastKeySpilt.contains("有水印")) {
                    List<String> urls = new LinkedList<>();
                    if (contentMap.containsKey(PdConstants.CommonProductImage.PROP_SUMMARY.value)) {
                        urls = contentMap.get(PdConstants.CommonProductImage.PROP_SUMMARY.value);
                    }
                    if (StringUtils.isNotEmpty(domainNameEncode)) {
                        urls.add(url + "?x-oss-process=image" + textmarksize + domainNameEncode + ",size_50" + "&random=" + System.currentTimeMillis());
                    } else if (StringUtils.isNotEmpty(commonWatermarkEncode)) {
                        urls.add(url + "?x-oss-process=image/watermark,image_" + commonWatermarkEncode + ",g_center" + "&random=" + System.currentTimeMillis());
                    } else {
                        urls.add(url.toString());
                    }
                    contentMap.put(PdConstants.CommonProductImage.PROP_SUMMARY.value, urls);
                } else if (lastKeySpilt.contains(".dwt") && lastKeySpilt.contains("技术参数")) {
                    OSSObject ossObject = ossClient.getObject(commonOssConf.getBucketName(), objectSummary.getKey());
                    BufferedReader reader = null;
                    try {
                        reader = new BufferedReader(new InputStreamReader(ossObject.getObjectContent(), "UTF-8"));
                        String line;
                        while ((line = reader.readLine()) != null) {
                            charDescBuilder.append(line);
                        }
                    } catch (UnsupportedEncodingException e) {
                        log.error("特性描述:UnsupportedEncodingException", e);
                    } catch (IOException e) {
                        log.error("特性描述:IOException", e);
                    } finally {
                        IoUtil.close(reader);
                        IoUtil.close(ossObject);
                    }
                } else if (lastKeySpilt.contains("型号说明") && lastKeySpilt.contains(".jpg") && !lastKeySpilt.contains("有水印")) {
                    List<String> urls = new LinkedList<>();
                    if (contentMap.containsKey(PdConstants.CommonProductImage.MODEL_GUIDE.value)) {
                        urls = contentMap.get(PdConstants.CommonProductImage.MODEL_GUIDE.value);
                    }
                    if (StringUtils.isNotEmpty(domainNameEncode)) {
                        urls.add(url + "?x-oss-process=image" + textmarksize + domainNameEncode + ",size_50" + "&random=" + System.currentTimeMillis());
                    } else if (StringUtils.isNotEmpty(commonWatermarkEncode)) {
                        urls.add(url + "?x-oss-process=image/watermark,image_" + commonWatermarkEncode + ",g_center" + "&random=" + System.currentTimeMillis());
                    } else {
                        urls.add(url.toString());
                    }
                    contentMap.put(PdConstants.CommonProductImage.MODEL_GUIDE.value, urls);
                } else if (lastKeySpilt.contains("尺寸图") && lastKeySpilt.contains(".jpg") && !lastKeySpilt.contains("有水印")) {
                    List<String> urls = new LinkedList<>();
                    if (contentMap.containsKey(PdConstants.CommonProductImage.SIZE_IMAGE.value)) {
                        urls = contentMap.get(PdConstants.CommonProductImage.SIZE_IMAGE.value);
                    }
                    if (StringUtils.isNotEmpty(domainNameEncode)) {
                        urls.add(url + "?x-oss-process=image" + textmarksize + domainNameEncode + ",size_50" + "&random=" + System.currentTimeMillis());
                    } else if (StringUtils.isNotEmpty(commonWatermarkEncode)) {
                        urls.add(url + "?x-oss-process=image/watermark,image_" + commonWatermarkEncode + ",g_center" + "&random=" + System.currentTimeMillis());
                    } else {
                        urls.add(url.toString());
                    }
                    contentMap.put(PdConstants.CommonProductImage.SIZE_IMAGE.value, urls);
                } else if (lastKeySpilt.contains("组装图") && lastKeySpilt.contains(".jpg") && !lastKeySpilt.contains("有水印")) {
                    List<String> urls = new LinkedList<>();
                    if (contentMap.containsKey(PdConstants.CommonProductImage.ASSEMBLY_IMAGE.value)) {
                        urls = contentMap.get(PdConstants.CommonProductImage.ASSEMBLY_IMAGE.value);
                    }
                    if (StringUtils.isNotEmpty(domainNameEncode)) {
                        urls.add(url + "?x-oss-process=image" + textmarksize + domainNameEncode + ",size_50" + "&random=" + System.currentTimeMillis());
                    } else if (StringUtils.isNotEmpty(commonWatermarkEncode)) {
                        urls.add(url + "?x-oss-process=image/watermark,image_" + commonWatermarkEncode + ",g_center" + "&random=" + System.currentTimeMillis());
                    } else {
                        urls.add(url.toString());
                    }
                    contentMap.put(PdConstants.CommonProductImage.ASSEMBLY_IMAGE.value, urls);
                }
            }
            contentMap.forEach((k, v) -> {
                DetailResponse.Content content = new DetailResponse.Content();
                content.setType(k);
                content.setSort(PdConstants.CommonProductImage.getSort(k));
                content.setUrls(v);
                contentList.add(content);
            });
            if (StringUtils.isNotEmpty(charDescBuilder.toString())) {
                DetailResponse.Content content = new DetailResponse.Content();
                content.setType(PdConstants.CommonProductImage.CHAR_DESC.value);
                content.setHtml(charDescBuilder.toString());
                content.setSort(PdConstants.CommonProductImage.getSort(PdConstants.CommonProductImage.CHAR_DESC.value));
                contentList.add(content);
            }
            //排序Content
            contentList.sort((o1, o2) -> {
                int diff = o1.getSort() - o2.getSort();
                if (diff > 0) {
                    return 1;
                } else if (diff < 0) {
                    return -1;
                }
                return 0;
            });
            detailResponse.setContentList(contentList);
        } else if (StringUtils.equalsIgnoreCase(info.getProductContent(), PdConstants.CommonProductContent.CHECK_ERP_CONTENT.value)) {
            StringBuilder filePathStringBuilder = new StringBuilder();
            filePathStringBuilder.append(filePath).append("/" + PdConstants.CommonProductOssType.CONTENT.value).append("/" + info.getErpProductId() + ".jpg" + "?random=" + System.currentTimeMillis());
            StringBuilder contentImgUrl = new StringBuilder();
            contentImgUrl.append(commonOssConf.getOssUrl()).append(filePathStringBuilder);
            detailResponse.setContentImgUrl(contentImgUrl.toString());
        } else if (StringUtils.equalsIgnoreCase(info.getProductContent(), PdConstants.CommonProductContent.CHECK_SKU_CONTENT.value)) {
            StringBuilder filePathStringBuilder = new StringBuilder();
            filePathStringBuilder.append(filePath).append("/" + PdConstants.CommonProductOssType.CONTENT.value).append("/" + info.getSkuCode() + ".jpg" + "?random=" + System.currentTimeMillis());
            StringBuilder contentImgUrl = new StringBuilder();
            contentImgUrl.append(commonOssConf.getOssUrl()).append(filePathStringBuilder);
            detailResponse.setContentImgUrl(contentImgUrl.toString());
        }
    }

    public List<CommonProductDto> fndExistProductCode(List<String> productCodes) {
        if (CollectionUtils.isEmpty(productCodes)) {
            return Collections.emptyList();
        }
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andIn(CommonProduct.ERP_PRODUCT_CODE, productCodes);
        List<CommonProduct> list = commonProductMapper.selectByExample(example);
        packCommonProductData(list);
        if (CollectionUtils.isNotEmpty(list)) {
            List<CommonProductDto> commonProductDtos = new ArrayList<>(list.size());
            for (CommonProduct commonProduct : list) {
                List<CommonProductSpec> productSpecList = commonProductSpecService.listByProperty(CommonProductSpec.PRODUCT_ID,
                        commonProduct.getProductId(), CommonProductSpec.SPEC_ID, CommonProductSpec.SPEC_VALUE_ID);
                CommonProductDto commonProductDto = new CommonProductDto();
                commonProductDto.setId(commonProduct.getId());
                commonProductDto.setProductId(commonProduct.getProductId());
                commonProductDto.setErpProductCode(commonProduct.getErpProductCode());
                commonProductDto.setProductName(commonProduct.getProductName());
                commonProductDto.setProductType(commonProduct.getProductType());
                commonProductDto.setSkuCode(commonProduct.getSkuCode());
                commonProductDto.setPrice(commonProduct.getPrice());
                commonProductDto.setCataId(commonProduct.getCataId());
                commonProductDto.setBrandId(commonProduct.getBrandId());
                commonProductDto.setBrandName(commonProduct.getBrandName());
                commonProductDto.setPropId(commonProduct.getPropId());
                commonProductDto.setPropName(commonProduct.getPropName());
                commonProductDto.setUnit(commonProduct.getUnit());
                commonProductDto.setWeight(commonProduct.getWeight());
                commonProductDto.setIsOnsale(commonProduct.getIsOnsale());
                commonProductDto.setProductPicName(commonProduct.getProductPicName());
                commonProductDto.setProductModelName(commonProduct.getProductModelName());
                commonProductDto.setProductSimpleName(commonProduct.getProductSimpleName());
                commonProductDto.setProductVedioName(commonProduct.getProductVedioName());
                commonProductDto.setProductContent(commonProduct.getProductContent());
                commonProductDto.setIsAdjustPrice(commonProduct.getIsAdjustPrice());
                commonProductDto.setProductSrc(commonProduct.getProductSrc());
                commonProductDto.setIsValid(commonProduct.getIsValid());
                commonProductDto.setExistsAttachment(commonProduct.getExistsAttachment());
                commonProductDto.setPackageUnit(commonProduct.getPackageUnit());
                commonProductDto.setStock(commonProduct.getStock());
                commonProductDto.setPurchasePrice(commonProduct.getPurchasePrice());
                commonProductDto.setSupplyPrice(commonProduct.getSupplyPrice());
                commonProductDto.setSuggestPrice(commonProduct.getSuggestPrice());
                commonProductDto.setDeliveryDate(commonProduct.getDeliveryDate());
                commonProductDto.setSupplierId(commonProduct.getSupplierId());
                commonProductDto.setCataNameOne(commonProduct.getCataNameOne());
                commonProductDto.setCataNameTwo(commonProduct.getCataNameTwo());
                commonProductDto.setCataNameThree(commonProduct.getCataNameThree());
                commonProductDto.setSample(commonProduct.getProductSimpleName());
                commonProductDto.setApplyNo(commonProduct.getApplyNo());
                commonProductDto.setSupplierProductCode(commonProduct.getSupplierProductCode());
                if (CollectionUtils.isNotEmpty(productSpecList)) {
                    List<CommonSpecVal> specValList = getSpecValList(productSpecList);
                    commonProduct.setSpecValList(specValList);
                    JSONArray jsonArray = new JSONArray(specValList.size());
                    for (CommonSpecVal commonSpecVal:specValList) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("spec", commonSpecVal.getSpecName());
                        jsonObject.put("specValue", commonSpecVal.getSpecValue());
                        jsonArray.add(jsonObject);
                    }
                    commonProductDto.setSpecData(jsonArray.toJSONString());
                }
                commonProductDtos.add(commonProductDto);
            }
            return commonProductDtos;
        }

        return Collections.emptyList();
    }

    public String getImportTemplateUrl() {
        String targetUrl;
        List<Map<String, String>> list = publicProductFeignServer.listCataBrandProp();
        Map<String, Object> model = new HashMap<>();
        model.put("appendix", list);
        // 模板上传oss
        targetUrl = ossConf.getOssUrl() + exportTemplateToOss(model);
        return targetUrl;
    }

    public List<CommonCataBrandProp> listAppendixData() {
        List<CommonCataBrandProp> commonCataBrandPropList = listToRebuildTripartiteRelationship();
        if (CollectionUtils.isNotEmpty(commonCataBrandPropList)) {
            Set<Long> cataIds = commonCataBrandPropList.stream().map(CommonCataBrandProp::getCataId).collect(Collectors.toSet());
            Set<Long> brandIds = commonCataBrandPropList.stream().map(CommonCataBrandProp::getBrandId).collect(Collectors.toSet());
            Set<Long> propIds = commonCataBrandPropList.stream().map(CommonCataBrandProp::getPropId).collect(Collectors.toSet());
            Map<Long, String> cataIdMap = Maps.newHashMap();
            if (CollectionUtils.isNotEmpty(cataIds)) {
                List<CommonCatalog> commonCatalogList = commonCatalogService.listByCataIds(cataIds);
                cataIdMap = commonCatalogList.stream().collect(Collectors.toMap(t -> t.getCataId(), CommonCatalog::getCataName));
            }
            Map<Long, String> brandIdMap = Maps.newHashMap();
            if (CollectionUtils.isNotEmpty(brandIds)) {
                List<CommonBrand> commonBrandList = commonBrandService.listByBrandIds(brandIds);
                brandIdMap = commonBrandList.stream().collect(Collectors.toMap(t -> t.getBrandId(), CommonBrand::getBrandName));
            }

            Map<Long, String> propIdMap = Maps.newHashMap();
            if (CollectionUtils.isNotEmpty(propIds)) {
                List<CommonProp> propList = commonPropService.listByPropIds(propIds);
                propIdMap = propList.stream().collect(Collectors.toMap(t -> t.getPropId(), CommonProp::getPropName));
            }

            // 规格
            Map<Long, String> specNameMap = Maps.newHashMap();
            List<CommonSpec> specList = commonSpecService.listAllGroupByCataId();
            if (CollectionUtils.isNotEmpty(specList)) {
                specNameMap = specList.stream().collect(Collectors.toMap(CommonSpec::getCataId, CommonSpec::getSpecName));
            }

            for (CommonCataBrandProp commonCataBrandProp : commonCataBrandPropList) {
                if (null != commonCataBrandProp) {
                    commonCataBrandProp.setCataName(cataIdMap.get(commonCataBrandProp.getCataId()));
                    commonCataBrandProp.setBrandName(brandIdMap.get(commonCataBrandProp.getBrandId()));
                    commonCataBrandProp.setPropName(propIdMap.get(commonCataBrandProp.getPropId()));
                    commonCataBrandProp.setSpecName(specNameMap.get(commonCataBrandProp.getCataId()));
                }
            }
            return commonCataBrandPropList;
        }
        return new ArrayList<>();
    }

    private String exportTemplateToOss(Map<String, Object> model) {
        //保存oss
        ClassLoader classLoader = CommonProductService.class.getClassLoader();
        InputStream is = null;
        Workbook workbook = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ByteArrayInputStream swapStream = null;
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        String name = "批量添加商品导入模板.xlsx";
        String targetUrl = "purchase" + ossConf.getTmp() + name;
        try {
            is = classLoader.getResourceAsStream("template/supplierProductLead.xlsx");
            if (is != null) {
                //转换成excel并输出
                XLSTransformer transformer = new XLSTransformer();
                workbook = transformer.transformXLS(is, model);
                //将内容写入输出流并把缓存的内容全部发出去
                workbook.write(baos);
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "获取不到商品导入模板");
            }
            swapStream = new ByteArrayInputStream(baos.toByteArray());
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(),
                    targetUrl, swapStream));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            if (result == null) {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "批量导入模板失败");
            }
            return targetUrl;
        } catch (Exception ex) {
            log.error("【批量导入模板】导入oss的错误结果异常：{}", JSONObject.toJSONString(ex));
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "批量导入模板失败");
        } finally {
            try {
                baos.flush();
            } catch (IOException e) {
                log.error("【批量导入模板】导入oss ByteArrayOutputStream类io异常：{}", JSONObject.toJSONString(e));
            }
            IoUtil.close(is);
            IoUtil.close(swapStream);
            IoUtil.close(workbook);
            IoUtil.close(baos);
            ossClient.shutdown();
        }
    }

    @Transactional(readOnly = true)
    public List<CommonProduct> listByCondition(CommonProduct product, String... properties) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(product);
        Example example = genConditionExample(product);
        example.selectProperties(properties);
        return commonProductMapper.selectByExample(example);
    }

    public ProductInfo getInfo(String id) {
        //校验id是否为空
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(id);
        //获取当前产品信息
        ProductInfo productInfo = new ProductInfo();
        ProductInfo.Info info = commonProductMapper.getJsonInfo(id);
        if (info.getStock() == null){
            info.setStock(0);
        }
        CheckFlow.start(PuPrErrorCode.THIS_PRODUCT_DOES_NOT_EXIST).isFalse(BeanUtil.isEmpty(info,id));
        // 分类
        if(StringUtils.isNotEmpty(info.getCataName())){
            List<String> cataList = Arrays.asList(info.getCataName().split(","));
            if(cataList.size()==3){
                info.setCataIdList(cataList);
                info.setCataName(cataList.get(2));
            }
        }
        //规格
        if(StringUtils.isNotEmpty(info.getSpec())){
            List<String> spec = Arrays.asList(info.getSpec().split("   "));
            List<SpecAndValDTO> specAndValDTOList = new ArrayList<>();
            spec.forEach(e->{
                SpecAndValDTO specAndValDTO = new SpecAndValDTO();
                specAndValDTO.setSpecName(e.substring(0,e.indexOf(":")));
                specAndValDTO.setSpecValue(e.substring(specAndValDTO.getSpecName().length()+1, e.length()));
                specAndValDTOList.add(specAndValDTO);
                info.setSpecAndVals(specAndValDTOList);
            });
        }
        //获取产品水印
        String domainNameEncode = Base64.getEncoder().encodeToString("huicai.zydonline.com".getBytes());
        // 设置品牌图
        String name = "";
        try {
            name = URLEncoder.encode(info.getBrandName(), "UTF-8");
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }

        if (StringUtils.isEmpty(info.getBrandImgUrl())) {
            info.setBrandImgUrl(commonOssConf.getOssUrl() + "product/brand/" + name + "/" + name + "logo.png");
        }
        //确认产品来源是否为zydmall
        boolean zydmall = PuPrConstants.ZYDMALL.equals(info.getProductSrc());

        //创建一个detailResponse对象接受
        DetailResponse detailResponse = new DetailResponse();
        DetailResponse.Info detailInfo = new DetailResponse.Info();
        BeanUtil.copyProperties(info,detailInfo);
        productInfo.setInfo(info);

        //如果为供应商添加产品
        if (!zydmall) {
            CommonProduct commonProduct = new CommonProduct();
            BeanUtil.copyProperties(info,commonProduct);
            detailResponse.setInfo(detailInfo);
            notZydmallData(detailResponse,commonProduct);
            List<DetailResponse.Image> imageList = new ArrayList<>();
            if(BeanUtil.isNotEmpty(info.getProductPicName())){
                Arrays.asList(info.getProductPicName().split("@")).forEach(e->{
                    DetailResponse.Image image = new DetailResponse.Image();
                    String smallPath = e+"?x-oss-process=image"+"/resize,w_135,h_135"+textmarksize+ domainNameEncode + ",size_10&random=" + System.currentTimeMillis();
                    String srcPath =e+"?x-oss-process=image"+textmarksize+ domainNameEncode + ",size_50"+"&random="+System.currentTimeMillis();
                    image.setImgSmallUrl(smallPath);
                    image.setImgSrcUrl(srcPath);
                    imageList.add(image);
                });
                detailResponse.setImageList(imageList);
            }
            BeanUtil.copyProperties(detailResponse,productInfo);
            productInfo.setInfo(info);

            return productInfo;
        }
        //获取OSS地址
        OSS ossClient = new OSSClientBuilder().build(commonOssConf.getEndpoint(), commonOssConf.getAccessKeyId(), commonOssConf.getAccessKeySecret());
        String filePath = "product/image" + "/" + info.getBrandName()+ "/" + info.getCataIdList().get(0) +
                "/" + info.getCataIdList().get(1) + "/" + info.getCataIdList().get(2) +
                "/" + info.getBrandName() + "_" + (null == info.getCataIdList().get(0) ? "" : info.getCataIdList().get(0))
                + "_" + (null == info.getCataIdList().get(1) ? "" : info.getCataIdList().get(1))
                + "_" + (null == info.getCataIdList().get(2) ? "" : info.getCataIdList().get(2)) + "_" + info.getPropName();

        List<DetailResponse.Image> imageList = getImageList(detailInfo, filePath, null, domainNameEncode);
        detailResponse.setImageList(imageList);
        //获取视频
        List<DetailResponse.Vedio> vedioList = getVedioList(detailInfo, ossClient, filePath);
        detailResponse.setVedioList(vedioList);
        //样本信息
        List<DetailResponse.Sample> sampleList = getSampleList(ossClient, filePath);
        detailResponse.setSampleList(sampleList);
        //3D信息
        List<DetailResponse.ThreeD> threeDList = getThreeDList(ossClient, filePath);
        detailResponse.setThreeDList(threeDList);
        //获取内容（产品系列图，系列概述，特性描述，选型指南，产品尺寸图，组装图）
        getContent(detailResponse, detailInfo, ossClient, filePath, null, domainNameEncode);
        //关闭ossclient
        ossClient.shutdown();
        BeanUtil.copyProperties(detailResponse,productInfo);
        productInfo.setInfo(info);
        return productInfo;
    }

    @Transactional
    public Boolean onSale(ProductIdDTO productIdDTO) {
        CommonProduct commonProduct = new CommonProduct();
        commonProduct.setId(productIdDTO.getId());
        List<CommonProduct> commonProducts = commonProductMapper.select(commonProduct);
        if (CollectionUtils.isEmpty(commonProducts)){
            return false;
        }
        CommonProduct commonProduct1 = commonProducts.get(0);
        commonProduct.setIsOnsale(productIdDTO.getIsOnsale());
        commonProduct.setReason(productIdDTO.getReason());
        int i = commonProductMapper.updateByPrimaryKeySelective(commonProduct);
        if (i == 1){
            int i1 = commonProductMapper.updatePurchaseProductSale(commonProduct1.getApplyId(), productIdDTO.getIsOnsale());
            if (i1 != 1){
                throw new BaseException(PuPrErrorCode.ERROR_UPDATE_DATA);
            }
            return true;
        }else {
            return false;
        }
    }

    public List<PurchaseCommonProductDto> PurchaseProductListById(List<Long> productIds) {
        if (CollectionUtils.isEmpty(productIds)) {
            return Collections.emptyList();
        }
        List<SelectCommonProductDto> commonProductDtos = commonProductMapper.selectList(productIds);
        return completeInfoProduct(commonProductDtos);
    }

    private List<PurchaseCommonProductDto> completeInfoProduct(List<SelectCommonProductDto> commonProductDtos) {
        if (CollectionUtils.isEmpty(commonProductDtos)) {
            return null;
        }

        Set<String> supplierIds = new HashSet<>();
        Set<Long> brandIds = new HashSet<>();
        Set<Long> cataIds = new HashSet<>();
        Set<Long> propIds = new HashSet<>();
        for (SelectCommonProductDto product : commonProductDtos) {
            supplierIds.add(product.getSupplierId());
            brandIds.add(product.getBrandId());
            cataIds.add(product.getCataId());
            propIds.add(product.getPropId());
        }

        Map<Long, String> brandNameMap = Maps.newHashMap();
        Map<Long, Map<Integer, String>> cataNameMap = Maps.newHashMap();
        Map<Long, String> propNameMap = Maps.newHashMap();
        Map<String, Supplier> supplierMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(supplierIds)) {
            supplierMap = ucFeignClient.mapSupplierByIds(supplierIds);
        }

        if (CollectionUtils.isNotEmpty(brandIds)) {
            brandNameMap = commonBrandService.mapNameByBrandIds(brandIds);
        }

        if (CollectionUtils.isNotEmpty(cataIds)) {
            cataNameMap = commonCatalogService.mapNameByCataIds(cataIds);
        }

        if (CollectionUtils.isNotEmpty(propIds)) {
            propNameMap = commonPropService.mapNameByPropIds(propIds);
        }

        List<PurchaseCommonProductDto> purchaseCommonProductDtos = new ArrayList<>(commonProductDtos.size());

        String productSrc;
        for (SelectCommonProductDto product : commonProductDtos) {
            product.setBrandName(brandNameMap.get(product.getBrandId()));
            if (product.getCataId() != null){
                if (cataNameMap.containsKey(product.getCataId())){
                    product.setCataNameOne(cataNameMap.get(product.getCataId()).get(1));
                    product.setCataNameTwo(cataNameMap.get(product.getCataId()).get(2));
                    product.setCataNameThree(cataNameMap.get(product.getCataId()).get(3));
                }
            }

            product.setPropName(propNameMap.get(product.getPropId()));
            if (StringUtils.isNotEmpty(product.getSupplierId())) {
                Supplier supplier = supplierMap.get(product.getSupplierId());
                product.setSupplierName(null == supplier ? null : supplier.getName());
            } else if (PuPrConstants.ZYDMALL.equals(product.getProductSrc()) && !StringUtils.equals("上海供应链", product.getIfsMainProcurement())){
                //来源为ZYDMALL 并且 主采购组不是上海供应链
                product.setSupplierName("zydmall");
            } else {
                product.setSupplierName("供应链公司");
            }

            productSrc = product.getProductSrc();
            if (PuPrConstants.SUPPLIER.equals(productSrc)) {
                product.setProductSrc(PuPrConstants.ONLINE_MARKETING);
            } else {
                product.setProductSrc(PuPrConstants.ZYDMALL);
            }
            PurchaseCommonProductDto productDto = new PurchaseCommonProductDto();
            BeanUtil.copyProperties(product,productDto);

            if (StringUtils.isEmpty(productDto.getBrandUrl())){
                StringBuilder brandImgUrl = new StringBuilder();
                brandImgUrl.append(commonOssConf.getOssUrl()).append("product/brand/").append(productDto.getBrandName() + "/").append(productDto.getBrandName() + "logo.png");
                productDto.setBrandUrl(brandImgUrl.toString());
            }

            //获取规格属性
            List<CommonProductSpec> productSpecList = commonProductSpecService.listByProperty(CommonProductSpec.PRODUCT_ID,
                    product.getProductId(), CommonProductSpec.SPEC_ID, CommonProductSpec.SPEC_VALUE_ID);
            if (CollectionUtils.isNotEmpty(productSpecList)) {
                List<CommonSpecVal> specValList = getSpecValList(productSpecList);
                log.info("productSpecList:{}", productSpecList);
                log.info("specValList:{}", specValList);
                product.setSpecValList(specValList);
                JSONArray jsonArray = new JSONArray(specValList.size());
                for (CommonSpecVal commonSpecVal:specValList) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("spec", commonSpecVal.getSpecName());
                    jsonObject.put("specValue", commonSpecVal.getSpecValue());
                    jsonArray.add(jsonObject);
                }
                productDto.setSpecData(jsonArray.toJSONString());
            }
            purchaseCommonProductDtos.add(productDto);
        }

        return purchaseCommonProductDtos;
    }

    public List<CommonCataBrandProp> listBrandCataPropSpecData() {
        List<CommonCataBrandProp> commonCataBrandPropList = listToRebuildTripartiteRelationship();
        if (CollectionUtils.isNotEmpty(commonCataBrandPropList)) {
            Set<Long> cataIds = commonCataBrandPropList.stream().filter(a -> (a !=null && a.getCataId() != null)).map(CommonCataBrandProp::getCataId).collect(Collectors.toSet());
            Set<Long> brandIds = commonCataBrandPropList.stream().filter(a -> (a !=null && a.getCataId() != null)).map(CommonCataBrandProp::getBrandId).collect(Collectors.toSet());
            Set<Long> propIds = commonCataBrandPropList.stream().filter(a -> (a !=null && a.getCataId() != null)).map(CommonCataBrandProp::getPropId).collect(Collectors.toSet());
            Map<Long, String> cataIdMap = Maps.newHashMap();
            if (CollectionUtils.isNotEmpty(cataIds)) {
                List<Long> cataId = new ArrayList<>(cataIds);
                List<CommonCatalog> commonCatalogList = commonCatalogMapper.selectCataName(cataId);
                commonCatalogList.forEach(e->{
                    if(BeanUtil.isNotEmpty(e.getCataName())) {
                        cataIdMap.put(e.getCataId(),e.getCataName());
                    }
                });
            }
            Map<Long, String> brandIdMap = Maps.newHashMap();
            if (CollectionUtils.isNotEmpty(brandIds)) {
                List<CommonBrand> commonBrandList = commonBrandService.listByBrandIds(brandIds);
                brandIdMap = commonBrandList.stream().collect(Collectors.toMap(t -> t.getBrandId(), CommonBrand::getBrandName));
            }

            Map<Long, String> propIdMap = Maps.newHashMap();
            if (CollectionUtils.isNotEmpty(propIds)) {
                List<CommonProp> propList = commonPropService.listByPropIds(propIds);
                propIdMap = propList.stream().collect(Collectors.toMap(t -> t.getPropId(), CommonProp::getPropName));
            }

            // 规格
            Map<Long, String> specNameMap = Maps.newHashMap();
            List<CommonSpec> specList = commonSpecService.listAllGroupByCataId();
            if (CollectionUtils.isNotEmpty(specList)) {
                specNameMap = specList.stream().collect(Collectors.toMap(CommonSpec::getCataId, CommonSpec::getSpecName));
            }

            for (CommonCataBrandProp commonCataBrandProp : commonCataBrandPropList) {
                if (null != commonCataBrandProp) {
                    commonCataBrandProp.setCataName(cataIdMap.get(commonCataBrandProp.getCataId()));
                    commonCataBrandProp.setBrandName(brandIdMap.get(commonCataBrandProp.getBrandId()));
                    commonCataBrandProp.setPropName(propIdMap.get(commonCataBrandProp.getPropId()));
                    commonCataBrandProp.setSpecName(specNameMap.get(commonCataBrandProp.getCataId()));
                }
            }
            return commonCataBrandPropList;
        }
        return new ArrayList<>();
    }

    public Page<ProductVo> productList(ProductListDTO productListDTO) {
        Page<ProductVo> page = new Page<>();
        page.setPageNum(BeanUtil.isEmpty(productListDTO.getPageNum())?1:productListDTO.getPageNum());
        page.setPageSize(BeanUtil.isEmpty(productListDTO.getPageSize())?12:productListDTO.getPageSize());
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<ProductVo> list = list(productListDTO);
        list.stream()
                .map(p -> {
                    Map<String, String> specMap = handleSpecToTwoColumn(p.getSpecData());
                    p.setSpecName(specMap.getOrDefault("specName", ""));  // 添加默认值防止NPE
                    p.setSpecValue(specMap.getOrDefault("specValue", ""));
                    return p;
                })
                .collect(Collectors.toList());
        for (ProductVo l : list) {
            CommonProductSpec commonProductSpec = new CommonProductSpec();
            commonProductSpec.setProductId(Long.valueOf(l.getProductId()));
            List<CommonProductSpec> productSpecList = commonProductSpecService.listByExample(commonProductSpec);

            if (CollectionUtils.isNotEmpty(productSpecList)) {
                List<CommonSpecVal> specValList = this.getSpecValList(productSpecList);
                String specName = "";
                String specValue = "";
                String specValueStr = "";
                for (CommonSpecVal commonSpecVal : specValList) {
                    specName += (StringUtils.isNotEmpty(specName) ? "@" : "") + commonSpecVal.getSpecName();
                    specValue += (StringUtils.isNotEmpty(specValue) ? "@" : "") + commonSpecVal.getSpecValue();
                    specValueStr += (StringUtils.isNotEmpty(specValueStr) ? "@" : "") + commonSpecVal.getSpecName()
                            + "&" + commonSpecVal.getSpecValue();
                }
                l.setSpecName(specName);//规格名
                l.setSpecValue(specValue);//规格值
                l.setSpecValueStr(specValueStr);//规格@规格值
            }
            // 价格格式化
            l.setSuggestPrice(formatBigDecimalData(l.getSuggestPrice()));
            l.setPurchasePrice(formatBigDecimalData(l.getPurchasePrice()));
            l.setSupplyPrice(formatBigDecimalData(l.getSupplyPrice()));
            l.setPrice(formatBigDecimalData(l.getPrice()));
            l.setPurchasePrice(formatBigDecimalData(l.getPurchasePrice()));
        }

        page = new Page<>(list);
        return page;

    }

    public List<ProductVo> list(ProductListDTO productListDTO){
        return commonProductMapper.productlist(productListDTO);
    }

    public Map<Integer,Integer> getCount(ProductListDTO productListDTO) {
        Map<Integer,Integer> map = new HashMap<>();
        for(int i=0 ;i<3;i++){
            if(i==productListDTO.getProductStatus()){
                map.put(i,commonProductMapper.count(productListDTO));
            }else {
                ProductListDTO productListDTO1 = new ProductListDTO();
                productListDTO1.setProductStatus(i);
                productListDTO1.setProductSrc(productListDTO.getProductSrc());
                map.put(i,commonProductMapper.count(productListDTO1));
            }
        }
        return map;
    }

    /**
     * 慧采列表商品清单导出
     *
     * @param productListDTO
     * @Author loine
     * @Date 2026/4/11 09:37
     */
    public JsonResult<String> listExport(ProductListDTO productListDTO) {
        List<ProductVo> products = list(productListDTO);
        String prefix = ossConf.getOssUrl() + getOssCorpCode();
        List<ProductListExportVo> exports = new ArrayList<>();
        for (ProductVo product : products) {
            ProductListExportVo export = new ProductListExportVo();
            BeanUtils.copyProperties(product, export);
            CommonProductSpec productSpec = new CommonProductSpec();
            productSpec.setProductId(Long.parseLong(product.getProductId()));
            List<CommonProductSpec> productSpecList = commonProductSpecService.listByExample(productSpec);
            if (CollectionUtils.isNotEmpty(productSpecList)) {
                List<CommonSpecVal> specValList = getSpecValList(productSpecList);
                String specNameStr = "";
                String specValueStr = "";
                for (CommonSpecVal commonSpecVal : specValList) {
                    specNameStr += (StringUtils.isNotEmpty(specNameStr) ? "@" : "") + commonSpecVal.getSpecName();
                    specValueStr += (StringUtils.isNotEmpty(specValueStr) ? "@" : "") + commonSpecVal.getSpecValue();
                }
                export.setSpecNameStr(specNameStr);
                export.setSpecValueStr(specValueStr);
            }
            exports.add(export);
        }
        // 上传数据
        String targetUrl = null;
        try {
            Map<String, Object> model = new HashMap<>();
            model.put("items", exports);
            // 同步到oss
            targetUrl = ossConf.getOssUrl() + exportScmToOss(model, "5", null);
        } catch (Exception e) {
            log.error("商品清单excel导出异常：" + e);
            ZydExceptions.re(true, "商品列表导出失败");
        }
        return new JsonResult<>(true, "导出成功", targetUrl);
    }

    /**
     * 慧采列表商品清单导入创建任务
     *
     * @param products
     * @Author loine
     * @Date 2026/4/11 10:16
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String listImportCreateTask(List<ProductListExportVo> products) {
        // 生成Excel
        String newPath = "taskDetail/excel/" + ZydDateUtils.format(ZydDateUtils.ymdhmsGapless, new Date()) + ".xlsx";
        try (ByteArrayOutputStream os = new ByteArrayOutputStream()){
            //write 必须传入输出流，否则OS得不到数据
            ExcelWriter excelWriter = EasyExcel.write(new FileOutputStream("慧采列表修改商品.xlsx")).file(os).build();
            WriteSheet sheet0 = EasyExcel.writerSheet(0, "商品明细").head(ProductListExportVo.class).build();
            excelWriter.write(products, sheet0);
            //关闭流
            excelWriter.finish();
            String url = ossUtil.uploadResourceByIs(newPath, new ByteArrayInputStream(os.toByteArray()));
        } catch (Exception e) {
            log.error("导出异常{}", e.getMessage());
        }

        //发送下载中心
        TaskManageDTO task = new TaskManageDTO();
        task.setType("修改商品");
        task.setModule("商品管理（国内）");
        task.setService("purchase-public-product");
        task.setStatus("1");
        task.setResultType("1");
        task.setResultContent(ossConf.getOssUrl() + newPath);
        task.setDownloadNum(0);
        CommonResponse commonResponse = taskClient.create(task);
        return commonResponse.getData();
    }

    /**
     * zydmall商品上架列表
     *
     * @param productZydmallDTO
     * @Author: loine
     * @Date: 2025/1/3 10:04
     */
    public Page<ProductZydmallVo> getZydmallList(ProductZydmallDTO productZydmallDTO) {
        Page<ProductZydmallVo> page = new Page<>();
        page.setPageNum(BeanUtil.isEmpty(productZydmallDTO.getPageNum()) ? 1 : productZydmallDTO.getPageNum());
        page.setPageSize(BeanUtil.isEmpty(productZydmallDTO.getPageSize()) ? 12 : productZydmallDTO.getPageSize());
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<ProductZydmallVo> list = zydmallList(productZydmallDTO);
        page = new Page<>(list);
        return page;
    }

    /**
     * zydmall商品上架列表
     *
     * @param productZydmallDTO
     * @Author: loine
     * @Date: 2025/1/3 10:04
     */
    public List<ProductZydmallVo> zydmallList(ProductZydmallDTO productZydmallDTO){
        return commonProductMapper.getZydmallList(productZydmallDTO);
    }

    /**
     * zydmall商品上架列表状态计数
     *
     * @param productZydmallDTO
     * @Author: loine
     * @Date: 2025/1/3 10:14
     */
    public Map<Integer, Integer> getZydmallCount(ProductZydmallDTO productZydmallDTO) {
        return commonProductMapper.getZydmallCount(productZydmallDTO);
    }

    /**
     * zydmall商品上架列表添加
     *
     * @param productZydmallIdDTO
     * @Author: loine
     * @Date: 2025/1/3 10:34
     */
    public boolean zydmallAdd(ProductZydmallIdDTO productZydmallIdDTO) {
        ZydExceptions.re(CollectionUtils.isEmpty(productZydmallIdDTO.getIds()) && CollectionUtils.isEmpty(productZydmallIdDTO.getNotInIds()) && CollectionUtils.isEmpty(productZydmallIdDTO.getProductIds()), "主键id和产品id不能同时为空");
        List<CommonProduct> products;
        if (CollectionUtils.isNotEmpty(productZydmallIdDTO.getProductIds())) {
            Example example = new Example(entityClass);
            Example.Criteria criteria = example.createCriteria();
            criteria.andIn(CommonProduct.PRODUCT_ID, productZydmallIdDTO.getProductIds());
            products = commonProductMapper.selectByExample(example);
        } else {
            if (!CollectionUtils.isEmpty(productZydmallIdDTO.getIds())) {
                if (productZydmallIdDTO.getIds().contains("all")) {
                    productZydmallIdDTO.setIds(null);
                }
            }
            products = commonProductMapper.productAddZydmallList(productZydmallIdDTO);
        }
        if (products.size() > 0) {
            LocalDateTime now = LocalDateTime.now();
            for (CommonProduct product : products) {
                if (StringUtils.isBlank(product.getZydmallFlag()) || "0".equals(product.getZydmallFlag())) {
                    product.setZydmallFlag("1");
                    product.setZydmallTime(now);
                }
            }
            // 更新
            batchUpdate(products);
            // 发送建ERP编码消息
            sendZydmallErpMsg(products);
        }
        return true;
    }

    /**
     * zydmall商品上架列表移除
     *
     * @param productZydmallIdDTO
     * @Author: loine
     * @Date: 2025/1/3 10:42
     */
    public boolean zydmallDelete(ProductZydmallIdDTO productZydmallIdDTO) {
        ZydExceptions.re(CollectionUtils.isEmpty(productZydmallIdDTO.getProductIds()), "产品id不能为空");
        // zydmall商品上架移除
        commonProductMapper.clearZydmallFlag(productZydmallIdDTO.getProductIds());
        return true;
    }

    /**
     * 发送建ERP编码消息
     *
     * @param list
     * @Author: loine
     * @Date: 2025/1/13 15:18
     */
    private void sendZydmallErpMsg(List<CommonProduct> list) {
        Map<String, List<CommonProduct>> applyMap = list.stream().collect(Collectors.groupingBy(CommonProduct::getSupplierId));
        // 获取供应商
        Map<String, Supplier> supplierMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(applyMap.keySet())) {
            supplierMap = ucFeignClient.mapSupplierByIds(applyMap.keySet());
        }
        StringBuilder textContent = new StringBuilder();
        textContent.append("以下是SCM本次标记上架zydmall商城的产品，请尽快创建ERP产品编码；\n");
        textContent.append("导出建ERP商品编码模板入口：【SCM运营后台-商品管理-zydmall商品上架】导出；");
        for (List<CommonProduct> applies : applyMap.values()) {
            textContent.append("\n供应商：");
            Supplier supplier = supplierMap.get(applies.get(0).getSupplierId());
            if (supplier != null) {
                textContent.append(supplier.getName());
            }
            textContent.append("，上架zydmall产品个数：").append(applies.size()).append("个；");
        }
        textContent.deleteCharAt(textContent.length() - 1);
        textContent.append("。");
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("scmProduct");
        triggerMsgRequest.setScene("scmZydmallList");
        JSONObject qywxParam = new JSONObject();
        qywxParam.put("msgtype", "text");
        qywxParam.put("text", new JSONObject() {{
            put("content", textContent.toString());
        }});
        triggerMsgRequest.setQywxParam(qywxParam);
        try {
            log.error("建ERP编码消息发送入参：" + JSONObject.toJSONString(triggerMsgRequest));
            msgClient.triggerMsg(triggerMsgRequest);
        } catch (Exception e) {
            log.error("建ERP编码消息发送异常：" + e);
        }
    }

    @Resource
    private TableSettingsMapper tableSettingsMapper;

    public String export(ProductListDTO dto, String filePath) {
        byte[] excelBytes = null;
        List<ProductVo> list = this.list(dto);
        list.stream().map(p -> {
                    Map<String, String> specMap = handleSpecToTwoColumn(p.getSpecData());
                    p.setSpecName(specMap.getOrDefault("specName", ""));  // 添加默认值防止NPE
                    p.setSpecValue(specMap.getOrDefault("specValue", ""));
                    return p;
                }).collect(Collectors.toList());
        String prefix = ossConf.getOssUrl()+getOssCorpCode();

        //数据处理
        for (ProductVo l : list) {
            CommonProductSpec commonProductSpec = new CommonProductSpec();
            commonProductSpec.setProductId(Long.valueOf(l.getProductId()));
            List<CommonProductSpec> productSpecList = commonProductSpecService.listByExample(commonProductSpec);

            if (CollectionUtils.isNotEmpty(productSpecList)) {
                List<CommonSpecVal> specValList = this.getSpecValList(productSpecList);
                String specValueStr = "";
                String specName = "";
                String specValue = "";
                for (CommonSpecVal commonSpecVal : specValList) {
                    specValueStr += (StringUtils.isNotEmpty(specValueStr) ? "@" : "") + commonSpecVal.getSpecName()
                            + "&" + commonSpecVal.getSpecValue();
                    specName += (StringUtils.isNotEmpty(specName) ? "@" : "") + commonSpecVal.getSpecName();
                    specValue += (StringUtils.isNotEmpty(specValue) ? "@" : "") + commonSpecVal.getSpecValue();
                }
                l.setSpecName(specName);
                l.setSpecValue(specValue);
                l.setSpecValueStr(specValueStr);
            }

            if (StringUtils.isNotEmpty(l.getPicName())) {
                l.setPicName(ossConf.getOssUrl() + "/" + l.getPicName().replaceAll(prefix, ""));
            }
            if (StringUtils.isNotEmpty(l.getPicVideoName())) {
                if (StringUtils.isNotEmpty(l.getPicName())) {
                    l.setPicName(l.getPicName() + "@" + ossConf.getOssUrl() + "/" + l.getPicVideoName());
                } else {
                    l.setPicName(ossConf.getOssUrl() + "/" + l.getPicVideoName());
                }
            }
            if (StringUtils.isNotEmpty(l.getProductSimpleName())) {
                String[] productSimpleNames = l.getProductSimpleName().split("@");
                if (productSimpleNames.length >= 1) {
                    StringBuilder productSimpleName = new StringBuilder();
                    for (int i = 0; i < productSimpleNames.length; i++) {
                        productSimpleName.append(ossConf.getOssUrl() + "/" + productSimpleNames[i]);
                        if (i != productSimpleNames.length - 1) {
                            productSimpleName.append("@");
                        }
                    }
                    l.setProductSimpleName(productSimpleName.toString());
                }
            }

            if (StringUtils.isNotEmpty(l.getProductContent())) {
                String[] productContents = l.getProductContent().split("@");
                StringBuilder newProductContent = new StringBuilder();
                for (int i = 0; i < productContents.length; i++) {
                    newProductContent.append(ossConf.getOssUrl() + "/" + productContents[i]);
                    if (i != productContents.length - 1) {
                        newProductContent.append("@");
                    }
                }
                l.setProductContent(newProductContent.toString());
            }
            // 设置库存
            if (l.getStock().equals("1")) {
                l.setStock("现货");
            } else if (l.getStock().equals("0")) {
                l.setStock("订货");
            } else {
                l.setStock("-");
            }
            // 价格格式化
            l.setSuggestPrice(formatBigDecimalData(l.getSuggestPrice()));
            l.setPurchasePrice(formatBigDecimalData(l.getPurchasePrice()));
            l.setSupplyPrice(formatBigDecimalData(l.getSupplyPrice()));
            l.setPrice(formatBigDecimalData(l.getPrice()));
            l.setPurchasePrice(formatBigDecimalData(l.getPurchasePrice()));
        }

        // 表头处理
        try {
            // 处理导出标题
            List<String> titleFields = new ArrayList<>();
            List<String> titleTexts = new ArrayList<>();
            // 获取页面列表配置
            TableSettings tableSettings = new TableSettings();
            tableSettings.setMenuPage("scm-admin-product-pool");
            tableSettings.setUserId(ContextHandler.getUserId());
            tableSettings = tableSettingsMapper.fndOne(tableSettings);
            if (tableSettings != null && StringUtils.isNotBlank(tableSettings.getTableConfig())) {
                List<TableConfigDto> tableConfigs = JSONArray.parseArray(tableSettings.getTableConfig(), TableConfigDto.class);
                tableConfigs = tableConfigs.stream().filter(TableConfigDto::isShow).sorted(Comparator.comparing(TableConfigDto::getOrder).reversed()).collect(Collectors.toList());
                for (TableConfigDto tableConfig : tableConfigs) {
                    if (tableConfig.getField().equalsIgnoreCase("checkbox")) {
                        continue;
                    }
                    titleFields.add(tableConfig.getField());
                    titleTexts.add(tableConfig.getText());
                }
            } else {
                titleFields.addAll(Arrays.asList("state", "productId", "reason", "supplier", "subCompany", "materialName", "productType", "skuCode", "productCode", "stock", "deliveryDate", "price", "supplyDiscount", "supplyPrice", "purchaseDiscount", "purchasePrice", "suggestPrice", "brandName", "propName", "firstLevelCataName", "specName", "specValue", "picName", "productContent", "productSimpleName", "weight", "unit", "minimunRequire", "createdAt", "updatedAt"));
                titleTexts.addAll(Arrays.asList("状态", "商品ID", "下架原因", "供应商", "所属子公司", "产品名称", "产品型号", "厂家物料号", "ERP产品编码", "库存", "交货期", "面价", "供货折扣", "供货价", "调货折扣（基于供货价）", "调货价", "建议销售价", "产品品牌", "产品系列", "分类", "规格名", "规格值", "产品主图", "产品详情图", "产品样本", "重量", "单位", "最小起订量", "申请时间", "最后修改时间"));
            }
            // 处理分类
            if (titleFields.contains("firstLevelCataName")) {
                int index = titleFields.indexOf("firstLevelCataName");
                titleTexts.set(index, "一级分类");
                titleFields.add(index + 1, "secondLevelCataName");
                titleTexts.add(index + 1, "二级分类");
                titleFields.add(index + 2, "threeLevelCataName");
                titleTexts.add(index + 2, "三级分类");
            }
//            // 只有下架状态下才有下架原因
//            if (dto.getProductStatus() == 1) {
//                titleFields.remove("reason");
//                titleTexts.remove("下架原因");
//            }

            List<List<MultiTitleExportExcelUtil.Title>> titleList = new ArrayList<>();
            List<MultiTitleExportExcelUtil.Title> titles = new ArrayList<>();
            for (String titleText : titleTexts) {
                titles.add(new MultiTitleExportExcelUtil.Title(titleText, 1, 18, MultiTitleExportExcelUtil.STYLE_TITLE3));
            }
            titleList.add(titles);
            // 处理导出数据
            List<List<Object>> objects = new ArrayList<>();
            for (ProductVo l : list) {
                // 添加到表格
                List<Object> object = new ArrayList<>();
                for (String titleField : titleFields) {
                    object.add(getFieldValue(l, titleField));
                }
                objects.add(object);
            }
            MultiTitleExportExcelUtil excelUtil = new MultiTitleExportExcelUtil("商品池明细", titleList);
            excelUtil.setDataListObject(objects);

            // 生成 Excel 数据到字节流
            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            excelUtil.write(baos); // 将 Excel 写入字节流
            excelBytes = baos.toByteArray();
        } catch (Exception e) {
            log.error("商品池excel导出异常：{}", e.getMessage(), e);
            ZydExceptions.re(true, "商品池导出失败");
        }
        // OSS上传逻辑
        return uploadToOss(excelBytes, filePath);
    }

    private String uploadToOss(byte[] data, String filePath) {
        OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        try (ByteArrayInputStream inputStream = new ByteArrayInputStream(data)) {
            ossClient.putObject(ossConf.getBucketName(), filePath, inputStream);
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            return ossConf.getOssUrl() + filePath;
        } catch (Exception e) {
            log.error("OSS上传失败", e);
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "上传失败");
        } finally {
            ossClient.shutdown();
        }
    }

    public String getOssCorpCode() {
        String supplierCode =(String) ContextHandler.get("supplierCode");
        return "purchase" + (StringUtils.isEmpty(supplierCode) ? "" : "_"+supplierCode) + ossConf.getCorpOssPrex();
    }

    /**
     * 根据字段名获取字段值
     */
    private Object getFieldValue(Object obj, String fieldName) {
        try {
            Class<?> clazz = obj.getClass();
            Field field = clazz.getDeclaredField(fieldName);
            field.setAccessible(true); // 设置访问权限
            return field.get(obj);
        } catch (Exception e) {
            log.error("根据字段名获取字段值异常：" + e);
            return null;
        }
    }

    /**
     * 处理导出规格
     * @param specData
     */
    private String handleExportSpec(String specData) {
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotBlank(specData)) {
            JSONArray specArray = JSONArray.parseArray(specData);
            if (specArray.size() > 0) {
                for (int i = 0; i < specArray.size(); i++) {
                    JSONObject spec = specArray.getJSONObject(i);
                    if (spec != null) {
                        if (spec.get("specName") != null && spec.get("specValue") != null) {
                            sb.append(spec.get("specName")).append("=").append(spec.get("specValue")).append("@");
                        }
                    }
                }
                if (sb.toString().length() > 0) {
                    sb.deleteCharAt(sb.length() - 1);
                }
            }
        }
        return sb.toString();
    }

    /**
     * 格式化价格
     *
     * @param bigDecimalObject
     * @Author loine
     * @Date 2025/8/25 17:20
     */
    private String formatBigDecimalData(Object bigDecimalObject) {
        if (bigDecimalObject == null) {
            return "";
        }
        BigDecimal bigDecimal;
        if (bigDecimalObject instanceof String) {
            if (StringUtils.isBlank(bigDecimalObject.toString())) {
                return "";
            }
            bigDecimal  = new BigDecimal(bigDecimalObject.toString());
        } else if (bigDecimalObject instanceof BigDecimal) {
            bigDecimal = (BigDecimal) bigDecimalObject;
        } else {
            return "";
        }
        // 获取实际小数位数
        String plainStr = bigDecimal.setScale(4, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
        int decimals = plainStr.contains(".") ? plainStr.split("\\.")[1].length() : 0;
        // 限制小数位数在0-4之间
        decimals = Math.min(decimals, 4);
        return String.format("%." + (decimals <= 1 ? 2 : decimals) + "f", bigDecimal);
    }

    /**
     * 图片、视频资源转为全路径
     * @param originNames
     */
    private String changeToFullUrl(String... originNames) {
        if (originNames != null && originNames.length > 0) {
            StringBuilder sb = new StringBuilder();
            for (String originName : originNames) {
                if (StringUtils.isBlank(originName)) {
                    continue;
                }
                String[] picNames = originName.split("@");
                for (String picName : picNames) {
                    if (picName.contains("http://") || picName.contains("https")) {
                        sb.append(picName).append("@");
                    } else {
                        sb.append(ossConf.getOssUrl()).append(picName).append("@");
                    }
                }
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
            }
            return sb.toString();
        }
        return "";
    }

    /**
     * 关联ERP编码导入创建任务
     *
     * @param products
     * @return
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String relevanceErpCreateTask(List<ProductZydmallRelevanceErpVO> products){
        //生成Excel
        String newPath = "taskDetail/excel/" + ZydDateUtils.format(ZydDateUtils.ymdhmsGapless, new Date()) + ".xlsx";
        try (ByteArrayOutputStream os = new ByteArrayOutputStream()){
            //write 必须传入输出流，否则OS得不到数据
            ExcelWriter excelWriter = EasyExcel.write(new FileOutputStream("关联ERP编码导入模板.xlsx")).file(os).build();
            WriteSheet sheet0 = EasyExcel.writerSheet(0, "商品明细").head(ProductZydmallRelevanceErpVO.class).build();
            excelWriter.write(products, sheet0);
            //关闭流
            excelWriter.finish();
            String url = ossUtil.uploadResourceByIs(newPath, new ByteArrayInputStream(os.toByteArray()));
        } catch (Exception e) {
            log.error("导出异常{}", e.getMessage());
        }

        //发送下载中心
        TaskManageDTO task = new TaskManageDTO();
        task.setType("关联ERP编码");
        task.setModule("商品管理");
        task.setService("purchase-public-product");
        task.setStatus("1");
        task.setResultType("1");
        task.setResultContent(ossConf.getOssUrl() + newPath);
        task.setDownloadNum(0);
//        task.setCreatedBy(StringUtils.isEmpty(ContextHandler.getUserId())  ? "测试用户" : ContextHandler.getUserId());
//        task.setUpdatedBy(StringUtils.isEmpty(ContextHandler.getUserId())  ? "测试用户" : ContextHandler.getUserId());
//        task.setCreatedAt(LocalDateTime.now());
//        task.setUpdatedAt(LocalDateTime.now());
        CommonResponse commonResponse = taskClient.create(task);
//        String textContent = "您的关联ERP产品编码导入任务已执行【任务ID:" + commonResponse.getData() + "】，请登录运营管理后台查看";
        return commonResponse.getData();
    }

    /**
     * 关联ERP编码任务处理
     *
     * @param msg
     * @return
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public String readProductRelevanceErpQueue(String msg) {
        //获取任务数据
        JSONObject feignRequestParam = new JSONObject();
        feignRequestParam.put("id", msg);
        JSONObject taskResult = taskClient.taskDetail(feignRequestParam);
        JSONObject data = taskResult.getJSONObject("data");
        TaskManageDTO task = JSON.parseObject(data.toJSONString(), TaskManageDTO.class);

        List<ProductZydmallRelevanceErpVO> products = null;
        try {
            //重新拿到导入的数据
            URL url = new URL(task.getResultContent());
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            InputStream inputStream = connection.getInputStream();
            // 创建通用监听器实例
            GenericDataListener<ProductZydmallRelevanceErpVO> listener = new GenericDataListener<>();
            // 使用 EasyExcel 读取文件
            EasyExcel.read(inputStream, ProductZydmallRelevanceErpVO.class, listener).sheet().doRead();
            // 获取读取到的数据
            products = listener.getDataList();
            inputStream.close();
            connection.disconnect();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        //zydmall商品关联-ERP数据解析
        List<ProductZydmallRelevanceErpVO> productZydmallRelevanceErpVOS = relevanceErpAnalyze(products);
        // 判断是否有异常,有则发送下载中心,无则更新数据
        boolean flag = true;
        String errorMsg = "";
        for (ProductZydmallRelevanceErpVO productZydmallRelevanceErpVO : productZydmallRelevanceErpVOS) {
            if (StringUtils.isNotEmpty(productZydmallRelevanceErpVO.getRemark())) {
                errorMsg = productZydmallRelevanceErpVO.getRemark();
                flag = false;
                break;
            }
        }
        if(flag){
            // 只有完全无误才更新数据
            LocalDateTime now = LocalDateTime.now();
            products.forEach(product -> {
                CommonProduct commonProduct = new CommonProduct();
                commonProduct.setProductId(Long.valueOf(product.getProductId()));
                commonProduct.setErpProductCode(product.getErpProductCode());
                commonProduct.setErpProductId(product.getErpProductId());
                commonProduct.setZydmallProductId(product.getZydProductId());
                commonProduct.setIsOnsale("Y");
                commonProduct.setZydmallFlag("1");
                commonProduct.setZydmallTime(now);
                commonProductMapper.updateByProductId(commonProduct);
            });
        }
        //生成Excel
        String newPath = "taskDetail/excel/" + ZydDateUtils.format(ZydDateUtils.ymdhmsGapless, new Date()) + ".xlsx";
        try (ByteArrayOutputStream os = new ByteArrayOutputStream()){
            //write 必须传入输出流，否则OS得不到数据
            ExcelWriter excelWriter = EasyExcel.write(new FileOutputStream("关联ERP编码导入模板.xlsx")).file(os).build();
            WriteSheet sheet0 = EasyExcel.writerSheet(0, "商品明细").head(ProductZydmallRelevanceErpVO.class).build();
            excelWriter.write(products, sheet0);
            //关闭流
            excelWriter.finish();
            String url = ossUtil.uploadResourceByIs(newPath, new ByteArrayInputStream(os.toByteArray()));
        } catch (Exception e) {
            log.error("导出异常{}", e.getMessage());
        }

        //发送下载中心
        task.setStatus(flag ? "2" : "3");
        task.setRemark(flag ? "" : "导入失败：" + errorMsg);
        task.setResultContent(ossConf.getOssUrl() + newPath);
//        task.setUpdatedBy(StringUtils.isEmpty(ContextHandler.getUserId())  ? "测试用户" : ContextHandler.getUserId());
//        task.setUpdatedAt(LocalDateTime.now());
        CommonResponse commonResponse = taskClient.update(task);

        //执行发送通知消息
        if (flag) {
            products.forEach(p -> {
                try {
                    CommonProduct commonProduct = getDetail(null, Long.valueOf(p.getProductId()));
                    if(commonProduct != null) {
                        List<String> commonSpecList = new ArrayList<>();
                        List<String> commonSpecValList = new ArrayList<>();
                        StringJoiner specNameJoiner = new StringJoiner("@");
                        StringJoiner specValueJoiner = new StringJoiner("@");
                        if(commonProduct.getSpecValList()!= null && commonProduct.getSpecValList().size()>0) {
                            for (CommonSpecVal commonSpecVal : commonProduct.getSpecValList()) {
                                commonSpecList.add(commonSpecVal.getSpecName());
                                commonSpecValList.add(commonSpecVal.getSpecValue());
                                specNameJoiner.add(commonSpecVal.getSpecName());
                                specValueJoiner.add(commonSpecVal.getSpecValue());
                            }
                        }
                        commonProduct.setSpecName(specNameJoiner.toString());
                        commonProduct.setSpecValue(specValueJoiner.toString());
                        commonProduct.setCommonSpecList(commonSpecList);
                        commonProduct.setCommonSpecValList(commonSpecValList);

                        dataSend(1L, null, commonProduct);
                    }
                } catch (Exception e) {
                   log.error("关联ERP编码导入发送通知消息异常：{}", e.getMessage(), e);
                }
            });
        }
        return commonResponse.getData();
    }

    /**
     * 处理导出
     *
     * @param message
     * @Author loine
     * @Date 2025/12/13 14:48
     */
    public void readProductExportQueue(String message) {
        if (StringUtils.isBlank(message)) {
            return;
        }
        String executeStatus = "";
        String newPath = "taskDetail/excel/" + message + ".xlsx";
        // 获取任务信息
        JSONObject feignRequestParam = new JSONObject();
        feignRequestParam.put("id", message);
        JSONObject taskResult = taskClient.taskDetail(feignRequestParam);
        if (taskResult != null && taskResult.get("code") != null && taskResult.getInteger("code") == 0 && taskResult.get("data") != null) {
            TaskManageDTO task = JSONObject.parseObject(taskResult.getJSONObject("data").toJSONString(), TaskManageDTO.class);
            if (task.getStatus().equals("0") || task.getStatus().equals("3")) {
                // 更新任务状态为执行中
                feignRequestParam = new JSONObject();
                feignRequestParam.put("id", message);
                feignRequestParam.put("status", "1");
                feignRequestParam.put("resultType", "1");
                feignRequestParam.put("resultContent", ossConf.getOssUrl() + newPath);
                taskClient.taskUpdate(feignRequestParam);
                if (task.getModule().contains("商品池")) {
                    ProductListDTO dto = JSONObject.parseObject(task.getRequestParam(), ProductListDTO.class);
                    try {
                        export(dto, newPath);
                    } catch (Exception e) {
                        log.error("任务【" + message + "】执行失败：保存商品池excel到oss失败：" + e);
                        executeStatus = "任务【" + message + "】执行失败：保存商品池excel到oss失败：" + e.getMessage();
                    }
                } else if (task.getModule().contains("zydmall商品上架")) {
                    ProductZydmallDTO dto = JSONObject.parseObject(task.getRequestParam(), ProductZydmallDTO.class);
                    try {
                        zydmallExport(dto, newPath);
                    } catch (Exception e) {
                        log.error("任务【" + message + "】执行失败：保存zydmall商品上架excel到oss失败：" + e);
                        executeStatus = "任务【" + message + "】执行失败：保存zydmall商品上架excel到oss失败：" + e.getMessage();
                    }
                }
            }
        }
        if (StringUtils.isBlank(executeStatus)) {
            // 更新任务状态为成功
            feignRequestParam = new JSONObject();
            feignRequestParam.put("id", message);
            feignRequestParam.put("status", "2");
            taskClient.taskUpdate(feignRequestParam);
        } else {
            // 更新任务状态为失败
            feignRequestParam = new JSONObject();
            feignRequestParam.put("id", message);
            feignRequestParam.put("status", "3");
            feignRequestParam.put("remark", executeStatus);
            taskClient.taskUpdate(feignRequestParam);
        }
    }

    /**
     * 处理商品清单导入
     *
     * @param message
     * @Author loine
     * @Date 2026/4/11 10:47
     */
    public void readProductListImportQueue(String message) {
        // 获取任务数据
        JSONObject feignRequestParam = new JSONObject();
        feignRequestParam.put("id", message);
        JSONObject taskResult = taskClient.taskDetail(feignRequestParam);
        JSONObject data = taskResult.getJSONObject("data");
        TaskManageDTO task = JSON.parseObject(data.toJSONString(), TaskManageDTO.class);

        List<ProductListExportVo> products = null;
        try {
            // 重新拿到导入的数据
            URL url = new URL(task.getResultContent());
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            InputStream inputStream = connection.getInputStream();
            // 创建通用监听器实例
            GenericDataListener<ProductListExportVo> listener = new GenericDataListener<>();
            // 使用 EasyExcel 读取文件
            EasyExcel.read(inputStream, ProductListExportVo.class, listener).sheet().doRead();
            // 获取读取到的数据
            products = listener.getDataList();
            inputStream.close();
            connection.disconnect();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // 判断是否有异常,有则发送下载中心,无则更新数据
        boolean flag = true;
        String errorMsg = "";
        List<ProductListExportErrorVo> errorVos = new ArrayList<>();
        if (CollectionUtils.isEmpty(products)) {
            flag = false;
            errorMsg = "导入的excel为空";
        } else {
            String error = "";
            for (ProductListExportVo product : products) {
                if (StringUtils.isBlank(product.getProductId())) {
                    flag = false;
                    error = "商品ID存在为空";
                } else if (StringUtils.isBlank(product.getFirstLevelCataName()) || StringUtils.isBlank(product.getSecondLevelCataName()) || StringUtils.isBlank(product.getThreeLevelCataName()) || StringUtils.isBlank(product.getSpecNameStr()) || StringUtils.isBlank(product.getSpecValueStr())) {
                    flag = false;
                    error = "一级分类/二级分类/三级分类/规格名/规格值存在为空";
                } else if (product.getSpecNameStr().split("@").length != product.getSpecValueStr().split("@").length) {
                    flag = false;
                    error = "规格名与规格值不匹配";
                }
                // 判断商品池商品ID是否正确
                if (StringUtils.isNotBlank(product.getProductId())) {
                    CommonProduct commonProduct = commonProductMapper.selectByProductId(Long.valueOf(product.getProductId()));
                    if (commonProduct == null) {
                        error = "商品ID有误";
                    }
                }
                ProductListExportErrorVo errorVo = new ProductListExportErrorVo();
                BeanUtils.copyProperties(product, errorVo);
                errorVo.setError(error);
                errorVos.add(errorVo);
            }
            Optional<String> e = errorVos.stream().map(ProductListExportErrorVo::getError).filter(StringUtils::isNotBlank).findFirst();
            if (e.isPresent()) {
                errorMsg = e.get();
            }
        }
        if (flag) {
            // 产品同步至公海
            for (ProductListExportVo product : products) {
                CommonProduct detail = commonProductMapper.selectByProductId(Long.valueOf(product.getProductId()));
                if (detail == null) {
                    continue;
                }
                PurchaseProductSync purchaseProductSync = new PurchaseProductSync();
                BeanUtils.copyProperties(detail, purchaseProductSync);
                purchaseProductSync.setPublicProductId(detail.getProductId());
                purchaseProductSync.setFirstLevelCataName(product.getFirstLevelCataName());
                purchaseProductSync.setSecondLevelCataName(product.getSecondLevelCataName());
                purchaseProductSync.setThreeLevelCataName(product.getThreeLevelCataName());
                purchaseProductSync.setBrandName(product.getBrandName());
                purchaseProductSync.setPropName(product.getPropName());
                purchaseProductSync.setSample(detail.getProductSimpleName());
                purchaseProductSync.setZydmallFlag("1");
                JSONArray newSpecArray = new JSONArray();
                if (StringUtils.isNotBlank(product.getSpecNameStr()) && StringUtils.isNotBlank(product.getSpecValueStr())) {
                    String[] specNameStrs = product.getSpecNameStr().split("@");
                    String[] specValueStrs = product.getSpecValueStr().split("@");
                    for (int i = 0; i < specNameStrs.length; i++) {
                        JSONObject newSpec = new JSONObject();
                        newSpec.put("spec", specNameStrs[i]);
                        newSpec.put("specValue", specValueStrs[i]);
                        newSpecArray.add(newSpec);
                    }
                }
                purchaseProductSync.setSpecData(newSpecArray.toJSONString());
                purchaseProductSync(purchaseProductSync);
            }
        }
        // 生成Excel
        String newPath = "taskDetail/excel/" + ZydDateUtils.format(ZydDateUtils.ymdhmsGapless, new Date()) + ".xlsx";
        try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
            // write 必须传入输出流，否则OS得不到数据
            ExcelWriter excelWriter = EasyExcel.write(new FileOutputStream("慧采列表修改商品.xlsx")).file(os).build();
            WriteSheet sheet0 = EasyExcel.writerSheet(0, "商品明细").head(ProductListExportErrorVo.class).build();
            excelWriter.write(errorVos, sheet0);
            // 关闭流
            excelWriter.finish();
            String url = ossUtil.uploadResourceByIs(newPath, new ByteArrayInputStream(os.toByteArray()));
        } catch (Exception e) {
            log.error("导出异常{}", e.getMessage());
        }

        // 发送下载中心
        task.setStatus(flag ? "2" : "3");
        task.setRemark(flag ? "" : "导入失败：" + errorMsg);
        task.setResultContent(ossConf.getOssUrl() + newPath);
        CommonResponse commonResponse = taskClient.update(task);

        // 执行发送通知消息
        if (flag) {
            TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
            triggerMsgRequest.setBusiness("scmProduct");
            triggerMsgRequest.setScene("productListImport");
            JSONObject qywxParam = new JSONObject();
            qywxParam.put("msgtype", "text");
            qywxParam.put("text", new JSONObject() {{
                put("content", "您的SCM商品修改任务已执行成功【任务ID：" + message + "】，请登录运营管理后台查看；");
            }});
            triggerMsgRequest.setQywxParam(qywxParam);
            try {
                msgClient.triggerMsg(triggerMsgRequest);
            } catch (Exception e) {
                log.error("商品清单导入通知异常：" + e);
            }
        }
    }

    /**
     * zydmall商品关联-ERP数据解析
     *
     * @param products
     */
    public List<ProductZydmallRelevanceErpVO> relevanceErpAnalyze(List<ProductZydmallRelevanceErpVO> products) {
        // 用于记录每个编码出现的次数
        Map<String, Integer> codeCount = new HashMap<>();
        for (ProductZydmallRelevanceErpVO product : products) {
            String code = product.getErpProductCode();
            codeCount.put(code, codeCount.getOrDefault(code, 0) + 1);
        }
        return products.stream()
                .peek(product -> {
                    //判断商品池商品ID是否正确
                    CommonProduct commonProduct = commonProductMapper.selectByProductId(Long.valueOf(product.getProductId()));
                    if (commonProduct == null) {
                        product.setRemark("商品ID错误");
                    } else {
                        if (StringUtils.isEmpty(product.getErpProductCode())) {
                            product.setRemark("产品编码为空");
                        } else {
                            if (codeCount.get(product.getErpProductCode()) > 1) {
                                product.setRemark("产品编码重复");
                            } else {
                                ProductZydmallVo zydProduct = commonProductMapper.getZydProductIdByProCode(product.getErpProductCode());
                                if (zydProduct == null) {
                                    product.setRemark("在t_pd_scm_zydmall_product找不到该产品编码");
                                } else {
                                    if (zydProduct.getProductId() != null && product.getErpProductCode() != null && zydProduct.getNerpProId() != null) {
                                        CommonProduct commonErpProduct = commonProductMapper.selectByErpProductId(product.getErpProductId(), product.getErpProductCode(), zydProduct.getProductId());
                                        if (commonErpProduct != null) {
                                            product.setRemark("ErpProductCode或productId或erpProId已存在");
                                        } else {
                                            product.setZydProductId(Long.valueOf(zydProduct.getProductId()));
                                            product.setErpProductCode(product.getErpProductCode());
                                            product.setErpProductId(zydProduct.getNerpProId());
                                        }
                                    } else {
                                        product.setRemark("在t_pd_scm_zydmall_product中,ErpProductCode或productId或erpProId为空");
                                    }
                                }
                            }
                        }
                    }
                })
                .collect(Collectors.toList());
    }

    /**
     * 处理规格转成规格名和规格值的两个独立字段
     *
     * @param specData
     * @Author: loine
     * @Date: 2025/3/14 15:59
     */
    public Map<String, String> handleSpecToTwoColumn(String specData) {
        Map<String, String> newSpec = new HashMap<>();
        newSpec.put("specName", "");
        newSpec.put("specValue", "");
        if (StringUtils.isNotBlank(specData)) {
            JSONArray specArray = JSONArray.parseArray(specData);
            if (specArray.size() > 0) {
                StringJoiner specName = new StringJoiner("@");
                StringJoiner specValue = new StringJoiner("@");
                for (int i = 0; i < specArray.size(); i++) {
                    JSONObject spec = specArray.getJSONObject(i);
                    if (spec != null) {
                        if (spec.get("specName") != null) {
                            specName.add(spec.get("specName").toString());
                        }
                        if (spec.get("specValue") != null) {
                            specValue.add(spec.get("specValue").toString());
                        }
                    }
                }
                newSpec.put("specName", specName.toString());
                newSpec.put("specValue", specValue.toString());
            }
        }
        return newSpec;
    }

    /**
     * zydmall商品上架列表导出
     *
     * @param productZydmallDTO
     * @param filePath
     * @Author loine
     * @Date 2025/12/13 15:03
     */
    public JsonResult<String> zydmallExport(@RequestBody ProductZydmallDTO productZydmallDTO, String filePath) {
        ZydExceptions.re(StringUtils.isBlank(productZydmallDTO.getExportType()), "导出类型不能为空");
        List<ProductZydmallVo> products = zydmallList(productZydmallDTO);
        String prefix = ossConf.getOssUrl() + getOssCorpCode();
        for (ProductZydmallVo product : products) {
            product.setSupplyPrice(null == product.getSupplyPrice() ? "" : new BigDecimal(product.getSupplyPrice()).setScale(2, RoundingMode.HALF_UP).toString());
            product.setPurchasePrice(null == product.getPurchasePrice() ? "" : new BigDecimal(product.getPurchasePrice()).setScale(2, RoundingMode.HALF_UP).toString());
            product.setPrice(null == product.getPrice() ? "" : new BigDecimal(product.getPrice()).setScale(2, RoundingMode.HALF_UP).toString());
            product.setSuggestPrice(null == product.getSuggestPrice() ? "" : new BigDecimal(product.getSuggestPrice()).setScale(2, RoundingMode.HALF_UP).toString());
            product.setIsOnsale(StringUtils.isNotBlank(product.getIsOnsale()) && product.getIsOnsale().equals("Y") ? "上架中" : "已下架");
            product.setWeight(StringUtils.isNotBlank(product.getWeight()) ? product.getWeight() : "0");

            CommonProductSpec productSpec = new CommonProductSpec();
            productSpec.setProductId(Long.parseLong(product.getProductId()));
            List<CommonProductSpec> productSpecList = commonProductSpecService.listByExample(productSpec);
            if (CollectionUtils.isNotEmpty(productSpecList)) {
                List<CommonSpecVal> specValList = getSpecValList(productSpecList);
                String specNameStr = "";
                String specValueStr = "";
                String specNameValueStr = "";
                for (CommonSpecVal commonSpecVal : specValList) {
                    specNameStr += (StringUtils.isNotEmpty(specNameStr) ? "@" : "") + commonSpecVal.getSpecName();
                    specValueStr += (StringUtils.isNotEmpty(specValueStr) ? "@" : "") + commonSpecVal.getSpecValue();
                    specNameValueStr += (StringUtils.isNotEmpty(specNameValueStr) ? "@" : "") + commonSpecVal.getSpecName() + "&" + commonSpecVal.getSpecValue();
                }
                product.setSpecNameStr(specNameStr);
                product.setSpecValueStr(specValueStr);
                product.setSpecNameValueStr(specNameValueStr);
            }

            if (StringUtils.isNotEmpty(product.getPicName())) {
                product.setPicName(ossConf.getOssUrl() + "/" + product.getPicName().replaceAll(prefix, ""));
            }
            if (StringUtils.isNotEmpty(product.getPicVideoName())) {
                if (StringUtils.isNotEmpty(product.getPicName())) {
                    product.setPicName(product.getPicName() + "@" + ossConf.getOssUrl() + "/" + product.getPicVideoName());
                } else {
                    product.setPicName(ossConf.getOssUrl() + "/" + product.getPicVideoName());
                }
            }
            if (StringUtils.isNotEmpty(product.getProductSimpleName())) {
                String[] productSimpleNames = product.getProductSimpleName().split("@");
                if (productSimpleNames.length >= 1) {
                    StringBuilder productSimpleName = new StringBuilder();
                    for (int i = 0; i < productSimpleNames.length; i++) {
                        productSimpleName.append(ossConf.getOssUrl()).append("/").append(productSimpleNames[i]);
                        if (i != productSimpleNames.length - 1) {
                            productSimpleName.append("@");
                        }
                    }
                    product.setProductSimpleName(productSimpleName.toString());
                }
            }

            if (StringUtils.isNotEmpty(product.getProductContent())) {
                String[] productContents = product.getProductContent().split("@");
                StringBuilder newProductContent = new StringBuilder();
                for (int i = 0; i < productContents.length; i++) {
                    newProductContent.append(ossConf.getOssUrl()).append("/").append(productContents[i]);
                    if (i != productContents.length - 1) {
                        newProductContent.append("@");
                    }
                }
                product.setProductContent(newProductContent.toString());
            }
            // 设置库存
            if (product.getStock().equals("1")) {
                product.setStock("现货");
            } else if (product.getStock().equals("0")) {
                product.setStock("订货");
            } else {
                product.setStock("-");
            }
        }
        // 上传数据
        String targetUrl = null;
        try {
            Map<String, Object> model = new HashMap<>();
            model.put("items", products);
            // 同步到oss
            targetUrl = ossConf.getOssUrl() + exportScmToOss(model, productZydmallDTO.getExportType(), filePath);
        } catch (Exception e) {
            log.error("商品列表excel导出异常：" + e);
            ZydExceptions.re(true, "商品列表导出失败");
        }
        return new JsonResult<>(true, "导出成功", targetUrl);
    }

    /**
     *
     * @param model
     * @param exportType 导出类型
     *                   1：zydmall商品上架-商品明细
     *                   2：zydmall商品上架-建ERP商品编码明细
     *                   3：zydmall商品上架-总表数据
     *                   4：zydmall商品上架-关联ERP编码导入模板
     *                   5：商品池-导出商品清单
     * @param filePath
     */
    private String exportScmToOss(Map<String, Object> model, String exportType, String filePath) {
        // 保存oss
        ClassLoader classLoader = CommonProductController.class.getClassLoader();
        InputStream is = null;
        Workbook workbook = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ByteArrayInputStream swapStream = null;
        OSS ossClient;
        // 初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        String name = "";
        String fileName = "";
        String targetName = "";
        switch (exportType) {
            case "1":
                name = "商品明细-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
                fileName = "scmProductZydmall.xlsx";
                targetName = "zydmall";
                is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + fileName);
                break;
            case "2":
                name = "建ERP商品编码明细-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
                fileName = "scmProductZydmallErp2.xlsx";
                targetName = "zydmall";
                is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + fileName);
                break;
            case "3":
                name = "总表数据-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
                fileName = "purchase/scm/zydmall/template/scmProductZydmallTotal.xlsx";
                targetName = "zydmall";
                OSSObject ossObject = ossClient.getObject(ossConf.getBucketName(), fileName);
                is = ossObject.getObjectContent();
                break;
            case "4":
                name = "关联ERP编码导入模板-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
                fileName = "scmProductZydmallRelevanceErp.xlsx";
                targetName = "zydmall";
                is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + fileName);
                break;
            case "5":
                name = "商品清单-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
                fileName = "scmProductList.xlsx";
                targetName = "list";
                is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + fileName);
                break;
        }
        String targetUrl = "purchase/scm/" + targetName + "/" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "/" + name;
        if (StringUtils.isNotBlank(filePath)) {
            targetUrl = filePath;
        }
        try {
            if (is != null) {
                // 转换成excel并输出
                if (!exportType.equals("2")) {
                    XLSTransformer transformer = new XLSTransformer();
                    workbook = transformer.transformXLS(is, model);
                } else {
                    workbook = new XSSFWorkbook(is);
                    CellStyle style = workbook.createCellStyle();
                    style.setBorderBottom(BorderStyle.THIN);
                    style.setBorderTop(BorderStyle.THIN);
                    style.setBorderLeft(BorderStyle.THIN);
                    style.setBorderRight(BorderStyle.THIN);
                    style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
                    style.setTopBorderColor(IndexedColors.BLACK.getIndex());
                    style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
                    style.setRightBorderColor(IndexedColors.BLACK.getIndex());
                    Sheet sheet = workbook.getSheetAt(0);
                    JSONArray products = JSONArray.parseArray(JSONArray.toJSONString(model.get("items")));
                    String[] titleKeys = new String[]{"skuCode", "productType", "propName", "firstLevelCataName", "secondLevelCataName", "threeLevelCataName", "propName", "price", "purchasePrice", "unit", "brandName", "supplier", "", ""};
                    for (int i = 0; i < products.size(); i++) {
                        int j = 1 + i;
                        Row row;
                        if (i >= 16) {
                            row = sheet.createRow(j);
                        } else {
                            row = sheet.getRow(j);
                        }
                        for (int k = 0; k < titleKeys.length; k++) {
                            Cell cell = row.createCell(k);
                            if (StringUtils.isBlank(titleKeys[k]) || products.getJSONObject(i).get(titleKeys[k]) == null) {
                                cell.setCellValue("");
                            } else {
                                cell.setCellValue(products.getJSONObject(i).get(titleKeys[k]) + "");
                            }
                            cell.setCellStyle(style);
                        }
                    }
                }
                // 将内容写入输出流并把缓存的内容全部发出去
                workbook.write(baos);
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "获取不到商品明细导出的结果模板");
            }
            swapStream = new ByteArrayInputStream(baos.toByteArray());
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(),
                    targetUrl, swapStream));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            if (result == null) {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "zydmall商品上架列表导出的结果失败");
            }
            return targetUrl;
        } catch (Exception ex) {
            log.error("【zydmall商品上架列表导出】导入oss的错误结果异常：{}", JSONObject.toJSONString(ex));
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "zydmall商品上架列表导出的结果失败");
        } finally {
            try {
                baos.flush();
            } catch (IOException e) {
                log.error("【zydmall商品上架列表导出】导入oss ByteArrayOutputStream类io异常：{}", JSONObject.toJSONString(e));
            }
            IoUtil.close(is);
            IoUtil.close(swapStream);
            IoUtil.close(workbook);
            IoUtil.close(baos);
            ossClient.shutdown();
        }
    }

}
