package com.online.purchase.model.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 公海产品结构删除
 *
 * @Author: loine
 * @Date: 2022/8/17 10:09
 **/
@Data
public class CommonStructureDeleteDto {
    @ApiModelProperty(value = "类型（1：标记删除，2：结构删除）")
    private String type;
    @ApiModelProperty(value = "分类id组")
    private List<Long> cataIds;
    @ApiModelProperty(value = "品牌id组")
    private List<Long> brandIds;
    @ApiModelProperty(value = "系列id组")
    private List<Long> propIds;
    @ApiModelProperty(value = "规格id组")
    private List<Long> specIds;
    @ApiModelProperty(value = "规格值id组")
    private List<Long> specValIds;
}
