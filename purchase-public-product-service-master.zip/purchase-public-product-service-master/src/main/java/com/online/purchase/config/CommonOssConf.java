package com.online.purchase.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 公海OSS
 *
 * @author lwl
 */
@Component
@ConfigurationProperties(prefix = "commonoss")
@Data
public class CommonOssConf {
    private String endpoint;
    private String accessKeySecret;
    private String accessKeyId;
    private String bucketName;
    private String ossUrl;
}

