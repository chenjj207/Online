package com.online.purchase.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @ClassName: OssConf
 * @Author: 陈培坤
 * @Date: 2019年10月15日16:40:01
 **/
@Component
@ConfigurationProperties(prefix = "oss")
@Data
public class OssConf {
    private String endpoint;
    private String accessKeySecret;
    private String accessKeyId;
    private String bucketName;
    private String ossUrl;
    private String corpOssPrex;
    private String smallPreix;
    private String tenantwatemartName;
    private String tmp;
    private String productUpload;
    private String productApply;
}
