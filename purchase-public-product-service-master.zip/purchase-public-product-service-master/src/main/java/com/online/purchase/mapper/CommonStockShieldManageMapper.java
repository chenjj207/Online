package com.online.purchase.mapper;

import com.online.purchase.model.CommonStockShieldManage;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;


/**
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
public interface CommonStockShieldManageMapper extends BaseMapper<CommonStockShieldManage> {

    List<CommonStockShieldManage> selectOrderById();
}
