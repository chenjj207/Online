package com.online.purchase.service;

import cn.hutool.core.io.IoUtil;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.CannedAccessControlList;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyun.oss.model.PutObjectResult;
import com.online.purchase.client.MsgClient;
import com.online.purchase.client.dto.TriggerMsgRequest;
import com.online.purchase.config.OssConf;
import com.online.purchase.controller.CommonProductController;
import com.online.purchase.mapper.CommonProductModiRecMapper;
import com.online.purchase.model.CommonProductModiRec;
import com.purchase.exception.ExceptionDictionary;
import com.purchase.utils.excel.JxlsExcelView;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import net.sf.jxls.transformer.XLSTransformer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.poi.ss.usermodel.*;





@Slf4j
@Service
public class CommonProductModiRecService extends BaseServiceImpl<CommonProductModiRec> {

    @Resource
    MsgClient msgClient;

    @Value("${oss.ossUrl:}")
    private String ossUrl;
    @Resource
    private OssConf ossConf;

    @Resource
    private CommonProductModiRecMapper commonProductModiRecMapper;

    public void modiRecNotice(){
        List<CommonProductModiRec> notSendList = commonProductModiRecMapper.selectByNotSend();
        if(notSendList==null || notSendList.size()==0){
            return;
        }
        //导出字段转换
        notSendList.stream().forEach(CommonProductModiRec::StrChange);

        String template = "commonProductModiRec.xlsx";
        String fileName = "公海_产品变更记录-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
        String targetUrl = "purchase/scm/" + fileName;

        Map<String, Object> model = new HashMap<>();
        model.put("items", notSendList);
        String fileUrl = exportToOss(model, targetUrl, template);
        // 发送公海_产品变更记录，信息修改消息
        Integer errCount = sendProductModiMsg(fileUrl);
        // 发送成功，修改发送状态
        if(null != errCount && errCount==0){
            commonProductModiRecMapper.updateSendStatusById(
                    notSendList.stream()
                            .map(CommonProductModiRec::getId)
                            .collect(Collectors.toList()));
        }
    }


    private Integer sendProductModiMsg(String fileUrl) {
        Integer errCount = 0;
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("scmProduct");
        triggerMsgRequest.setScene("productModi");
        JSONObject qywxParam = new JSONObject();
        qywxParam.put("msgtype", "text");
        qywxParam.put("text", new JSONObject() {{
            put("content", "SCM产品基础信息变更，请留意到ERP系统同步修改。");
        }});
        triggerMsgRequest.setQywxParam(qywxParam);
        try {
            log.error("SCM产品基础信息变更，信息修改消息发送1入参：" + JSONObject.toJSONString(triggerMsgRequest));
            msgClient.triggerMsg(triggerMsgRequest);
        } catch (Exception e) {
            errCount++;
            log.error("SCM产品基础信息变更，信息修改消息发送1异常：" + e);
        }
        qywxParam = new JSONObject();
        qywxParam.put("msgtype", "file");
        qywxParam.put("fileUrl", fileUrl);
        qywxParam.put("fileName", "产品变更.xlsx");
        triggerMsgRequest.setQywxParam(qywxParam);
        try {
            log.error("SCM产品基础信息变更，信息修改消息发送2入参：" + JSONObject.toJSONString(triggerMsgRequest));
            msgClient.triggerMsg(triggerMsgRequest);
        } catch (Exception e) {
            errCount++;
            log.error("SCM产品基础信息变更，信息修改发送2异常：" + e);
        }
        return errCount;
    }


    private String exportToOss(Map<String, Object> model,String targetUrl,String template) {
        //保存oss
        ClassLoader classLoader = CommonProductController.class.getClassLoader();
        InputStream is = null;
        Workbook workbook = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ByteArrayInputStream swapStream = null;
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        try {
            is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + template);
            if (is != null) {
                //转换成excel并输出
                XLSTransformer transformer = new XLSTransformer();
                workbook = transformer.transformXLS(is, model);
                //将内容写入输出流并把缓存的内容全部发出去
                workbook.write(baos);
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "获取不到【公海_产品变更记录】导出的结果模板");
            }
            swapStream = new ByteArrayInputStream(baos.toByteArray());
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(),
                    targetUrl, swapStream));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            if (result == null) {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "【公海_产品变更记录】导出的结果失败");
            }
            return ossConf.getOssUrl() + targetUrl;
        } catch (Exception ex) {
            log.error("【公海_产品变更记录】导入oss的错误结果异常：{}", JSONObject.toJSONString(ex));
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "【公海_产品变更记录】导出的结果失败");
        } finally {
            try {
                baos.flush();
            } catch (IOException e) {
                log.error("【公海_产品变更记录】导入oss ByteArrayOutputStream类io异常：{}", JSONObject.toJSONString(e));
            }
            IoUtil.close(is);
            IoUtil.close(swapStream);
            IoUtil.close(workbook);
            IoUtil.close(baos);
            ossClient.shutdown();
        }
    }

    private String uploadToOss(String targetPath,byte[] data) {
        OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        try (ByteArrayInputStream inputStream = new ByteArrayInputStream(data)) {
            ossClient.putObject(ossConf.getBucketName(), targetPath, inputStream);
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            return ossConf.getOssUrl() + targetPath;
        } catch (Exception e) {
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "上传失败");
        } finally {
            ossClient.shutdown();
        }
    }

}
