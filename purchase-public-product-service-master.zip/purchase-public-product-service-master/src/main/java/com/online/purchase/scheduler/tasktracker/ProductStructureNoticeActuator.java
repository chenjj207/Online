package com.online.purchase.scheduler.tasktracker;

import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.online.purchase.base.JobConstant;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.model.*;
import com.online.purchase.model.dto.CommonStructureDeleteDto;
import com.online.purchase.service.*;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 公海产品结构变更通知
 *
 * @author lwl
 */
@Component("productStructureNoticeActuator")
@Slf4j
public class ProductStructureNoticeActuator implements BaseJobRunnerActuator {

    @Resource
    private CommonBrandService commonBrandService;
    @Resource
    private CommonPropService commonPropService;
    @Resource
    private CommonCatalogService commonCatalogService;
    @Resource
    private CommonSpecService commonSpecService;
    @Resource
    private CommonSpecValService commonSpecValService;
    @Value("${zydonline.product.structure.noticeUrl:}")
    private String noticeUrl;

    @Override
    public Result run(JobContext jobContext) {
        log.info("公海产品结构变更通知开始 ==> " + LocalDateTime.now());
        // 同步数据
        dealData();
        log.info("公海产品结构变更通知结束 ==> " + LocalDateTime.now());
        return new Result(Action.EXECUTE_SUCCESS, StringUtils.EMPTY);
    }

    private void dealData() {
        // 待同步产品结构
        List<CommonBrand> brandList = commonBrandService.listAll(
                new CommonBrand().setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC));
        List<CommonProp> propList = commonPropService.listByCondition(
                new CommonProp().setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC), CommonProp.ID, CommonProp.PROP_ID);
        List<CommonCatalog> catalogList = commonCatalogService.listByCondition(
                new CommonCatalog().setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC), CommonCatalog.ID, CommonCatalog.CATA_ID);
        List<CommonSpec> specList = commonSpecService.listByCondition(
                new CommonSpec().setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC), CommonSpec.ID, CommonSpec.SPEC_ID);
        List<CommonSpecVal> specValList = commonSpecValService.listByExample(
                new CommonSpecVal().setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC), CommonSpecVal.ID, CommonSpecVal.SPEC_VALUE_ID);
        if (CollectionUtils.isEmpty(brandList) && CollectionUtils.isEmpty(propList) && CollectionUtils.isEmpty(catalogList)
                && CollectionUtils.isEmpty(specList) && CollectionUtils.isEmpty(specValList)) {
            return;
        }

        CommonStructureDeleteDto deleteDto = new CommonStructureDeleteDto();
        deleteDto.setType(String.valueOf(1));
        if (CollectionUtils.isNotEmpty(brandList)) {
            deleteDto.setBrandIds(brandList.stream().distinct().map(CommonBrand::getBrandId).collect(Collectors.toList()));
        }

        if (CollectionUtils.isNotEmpty(propList)) {
            deleteDto.setPropIds(propList.stream().distinct().map(CommonProp::getPropId).collect(Collectors.toList()));
        }

        if (CollectionUtils.isNotEmpty(catalogList)) {
            deleteDto.setCataIds(catalogList.stream().distinct().map(CommonCatalog::getCataId).collect(Collectors.toList()));
        }

        if (CollectionUtils.isNotEmpty(specList)) {
            deleteDto.setSpecIds(specList.stream().distinct().map(CommonSpec::getSpecId).collect(Collectors.toList()));
        }

        if (CollectionUtils.isNotEmpty(specValList)) {
            deleteDto.setSpecValIds(specValList.stream().distinct().map(CommonSpecVal::getSpecValueId).collect(Collectors.toList()));
        }

        // 通知租户
        if (!noticeTenant(deleteDto)) {
            return;
        }

        // 处理同步结果
        dealSyncResult(brandList, propList, catalogList, specList, specValList);
    }

    private boolean noticeTenant(CommonStructureDeleteDto deleteDto) {
        try {
            String paramStr = JSONUtil.toJsonStr(deleteDto);
            log.info("公海产品结构变更通知入参:[{}][{}]", noticeUrl, paramStr);
            String resStr = HttpUtil.post(noticeUrl, paramStr, 10000);
            log.info("公海产品结构变更通知出参:[{}]", resStr);
            JsonResult res = JSONUtil.toBean(resStr, JsonResult.class);
            if (null == res || !res.isSuccess()) {
                return false;
            }
        } catch (Exception e) {
            log.error("公海产品结构变更通知ERROR:[{}]", e.getMessage());
            return false;
        }

        return true;
    }

    private void dealSyncResult(List<CommonBrand> brandList, List<CommonProp> propList,
                                List<CommonCatalog> catalogList, List<CommonSpec> specList, List<CommonSpecVal> specValList) {
        if (CollectionUtils.isNotEmpty(brandList)) {
            brandList.forEach(b -> b.setSyncStatus(PuPrConstants.PRODUCT_SYNCED).setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_NOTICE));
            commonBrandService.batchUpdate(brandList);
        }

        if (CollectionUtils.isNotEmpty(propList)) {
            propList.forEach(b -> b.setSyncStatus(PuPrConstants.PRODUCT_SYNCED).setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_NOTICE));
            commonPropService.batchUpdate(propList);
        }

        if (CollectionUtils.isNotEmpty(catalogList)) {
            catalogList.forEach(b -> b.setSyncStatus(PuPrConstants.PRODUCT_SYNCED).setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_NOTICE));
            commonCatalogService.batchUpdate(catalogList);
        }

        if (CollectionUtils.isNotEmpty(specList)) {
            specList.forEach(b -> b.setSyncStatus(PuPrConstants.PRODUCT_SYNCED).setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_NOTICE));
            commonSpecService.batchUpdate(specList);
        }

        if (CollectionUtils.isNotEmpty(specValList)) {
            specValList.forEach(b -> b.setSyncStatus(PuPrConstants.PRODUCT_SYNCED).setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_NOTICE));
            commonSpecValService.batchUpdate(specValList);
        }
    }
}
