package com.online.purchase.scheduler.tasktracker;

import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.online.purchase.service.CommonEsService;
import com.online.purchase.service.CommonProductModiRecService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;

/**
 * SCM产品基础信息变更
 */
@Component("productModiRecActuator")
@Slf4j
public class ProductModiRecActuator implements BaseJobRunnerActuator {

    @Resource
    private CommonProductModiRecService commonProductModiRecService;

    @Override
    public Result run(JobContext jobContext) {
        log.info("SCM产品基础信息变更开始 ==> " + LocalDateTime.now());

        commonProductModiRecService.modiRecNotice();

        log.info("SCM产品基础信息变更结束 ==> " + LocalDateTime.now());
        return new Result(Action.EXECUTE_SUCCESS, StringUtils.EMPTY);
    }
}
