package com.online.purchase.service;

import cn.hutool.extra.pinyin.PinyinUtil;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Maps;
import com.online.purchase.base.JobConstant;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.config.CommonOssConf;
import com.online.purchase.mapper.CommonBrandMapper;
import com.online.purchase.model.CommonBrand;
import com.online.purchase.model.CommonProduct;
import com.online.purchase.model.CommonProp;
import com.online.purchase.scheduler.tasktracker.*;
import com.online.purchase.utils.RedisUtil;
import com.online.purchase.utils.ReflectUtils;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.common.exception.ErrorCode;
import com.qgutech.qgyun.framework.database.mybatis.helper.CorpHelper;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.net.URLEncoder;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * CommonBrandService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Slf4j
@Service
public class CommonBrandService extends BaseServiceImpl<CommonBrand> {

    @Resource
    private CommonBrandMapper commonBrandMapper;
    @Resource
    private CommonProductService commonProductService;
    @Resource
    private CommonPropService commonPropService;
    @Resource
    private RedisTemplate redisTemplate;
    @Resource
    private CommonOssConf commonOssConf;

    private static final String[] FIELD_LIST = {"brandId","brandName","picUrl","remark"};

    /**
     * 根据条件，获取所有数据
     *
     * @param brand 条件
     * @return 数据集合
     */
    @Transactional(readOnly = true)
    public List<CommonBrand> listAll(CommonBrand brand) {
        if (null == brand) {
            return commonBrandMapper.selectAll();
        }

        return commonBrandMapper.selectAllByCondition(brand);
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<CommonBrand> search(CommonBrand commonBrand, Page<CommonBrand> page) {
        Assert.notNull(commonBrand, "commonBrand can not be null!");
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<CommonBrand> list = commonBrandMapper.search(commonBrand);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packCommonBrandData(list);
        return page;
    }

    private Example genConditionExample(CommonBrand model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        String id = model.getId();
        if (StringUtils.isNotEmpty(id)) {
            criteria.andEqualTo(CommonBrand.ID, id);
        }

        Boolean deleted = model.getDeleted();
        if (null != deleted) {
            criteria.andEqualTo(CommonBrand.DELETED, deleted);
        }

        Long brandId = model.getBrandId();
        if (null != brandId) {
            criteria.andEqualTo(CommonBrand.BRAND_ID, brandId);
        }

        Collection<String> brandNames = model.getBrandNames();
        if (CollectionUtils.isNotEmpty(brandNames)) {
            criteria.andIn(CommonBrand.BRAND_NAME, brandNames);
        }

        String brandName = model.getBrandName();
        if (StringUtils.isNotBlank(brandName)) {
            criteria.andEqualTo(CommonBrand.BRAND_NAME, brandName);
        }

        String brandNameLetter = model.getBrandNameLetter();
        if (StringUtils.isNotBlank(brandNameLetter)) {
            criteria.andEqualTo(CommonBrand.BRAND_NAME_LETTER, brandNameLetter);
        }

        String isValid = model.getIsValid();
        if (StringUtils.isNotBlank(isValid)) {
            criteria.andEqualTo(CommonBrand.IS_VALID, isValid);
        }

        return example;
    }

    /**
     * 分页数据处理
     */
    private void packCommonBrandData(List<CommonBrand> commonBrandList) {
        if (CollectionUtils.isEmpty(commonBrandList)) {
            return;
        }
        dealCommonBrandImage(commonBrandList);
    }

    private void dealCommonBrandImage(List<CommonBrand> commonBrandList) {
        if (CollectionUtils.isEmpty(commonBrandList)) {
            return;
        }
        for (CommonBrand commonBrand : commonBrandList) {
            if (null != commonBrand) {
                String brandName = commonBrand.getBrandName();
                // 设置品牌图
                String name = "";
                try {
                    name = URLEncoder.encode(brandName, "UTF-8");
                } catch (Exception ex) {
                    log.error(ex.getMessage(), ex);
                }

                boolean zydmall = PuPrConstants.ZYDMALL.equals(commonBrand.getSource()) || "zydmall".equals(commonBrand.getSource());
                if (zydmall) {
                    commonBrand.setPicUrl(commonOssConf.getOssUrl() + "product/brand/" + name + "/" + name + "logo.png");
                }
            }
        }
    }

    /**
     * 通过id获取详情
     */
    @Override
    @Transactional(readOnly = true)
    public CommonBrand get(String id) {
        CommonBrand commonBrand = super.get(id);
        dealCommonBrandImage(Collections.singletonList(commonBrand));
        return commonBrand;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(CommonBrand commonBrand) {
        Assert.notNull(commonBrand, "commonBrand can not be null");
        Example example = genConditionExample(commonBrand);
        example.selectProperties(CommonBrand.ID);
        CorpHelper.skipCorpCode(true);
        List<CommonBrand> commonBrandList = commonBrandMapper.selectByExample(example);
        return CollectionUtils.isEmpty(commonBrandList) ? new ArrayList<>(0) :
                commonBrandList.stream().map(CommonBrand::getId).collect(Collectors.toList());
    }

    /**
     * 新增
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String add(CommonBrand commonBrand, String source) {
        CheckFlow.start(ErrorCode.ILLEGAL_PARAM).isNotNull(commonBrand)
                .error(ErrorCode.ILLEGAL_PARAM).isNotEmpty(commonBrand.getBrandName());
        // 新增
        String brandName = commonBrand.getBrandName();
        if (!PuPrConstants.EDIT.equals(source)) {
            int maxBrandSort = commonBrand.getSort() == null ? commonBrandMapper.getMaxBrandSort() + 1 : commonBrand.getSort();
            commonBrand.setBrandId(genBrandId());
            commonBrand.setIsValid(PuPrConstants.IS_VALID_Y);
            commonBrand.setIsShopCenter(PuPrConstants.IS_SHOP_CENTER_N);
            commonBrand.setSort(maxBrandSort);
        }

        // 名称重复校验
        validateBrandName(brandName);
        commonBrand.setBrandNameLetter(PinyinUtil.getFirstLetter(brandName, "").substring(0, 1).toUpperCase());
        commonBrand.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        return super.insert(commonBrand);
    }

    /**
     * 生成品牌编号
     *
     * @return 编号
     */
    private Long genBrandId() {
        return RedisUtil.genCode("common_brand_id", redisTemplate, () -> {
            return commonBrandMapper.getMaxBrandId();
        });
    }

    /**
     * 名称重复校验
     *
     * @param brandName 名称
     */
    private void validateBrandName(String brandName) {
        List<String> idList = listIdsByExample(new CommonBrand().setBrandName(brandName).setDeleted(false));
        if (CollectionUtils.isEmpty(idList)) {
            return;
        }

        throw new BaseException(PuPrErrorCode.COMMON_BRAND_NAME_ERROR);
    }

    /**
     * 修改
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void edit(CommonBrand commonBrand) {
        CheckFlow.start(ErrorCode.ILLEGAL_PARAM).isNotNull(commonBrand)
                .error(ErrorCode.ILLEGAL_PARAM).isNotEmpty(commonBrand.getBrandName());
        String id = commonBrand.getId();
        CommonBrand param = new CommonBrand();
        param.setDeleted(false).setId(id);
        CommonBrand brand = getByExample(param);
        if (null == brand) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }
        if ("ZYDMALL".equals(commonBrand.getSource()) || "zydmall".equals(commonBrand.getSource())) {
            commonBrand.setPicUrl(brand.getPicUrl());
        }

        Boolean hasEdit = ReflectUtils.hasEdit(brand, commonBrand, FIELD_LIST, this.entityClass);

        if (BooleanUtils.isTrue(hasEdit)) {
            // 标记删除
            CommonBrand deletedBrand = new CommonBrand();
            deletedBrand.setId(id);
            deletedBrand.setDeleted(true);
            deletedBrand.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
            super.update(deletedBrand);
            // 新增
            commonBrand.setId(null);
            commonBrand.setCreatedAt(null);
            commonBrand.setCreatedBy(null);
            commonBrand.setUpdatedAt(null);
            commonBrand.setUpdatedBy(null);
            commonBrand.setIsValid(brand.getIsValid());
            commonBrand.setIsShopCenter(brand.getIsShopCenter());
            Long brandId = genBrandId();
            commonBrand.setBrandId(brandId);
            commonBrand.setSource(brand.getSource());
            add(commonBrand, PuPrConstants.EDIT);
            // 关联关系-系列
            Long oldBrandId = brand.getBrandId();
            commonPropService.batchUpdateBrandId(oldBrandId, brandId);
            // 关联关系-商品
            commonProductService.batchUpdateBrandId(oldBrandId, brandId);
        } else {
            this.update(commonBrand);
        }
    }

    /**
     * 标记删除数据
     *
     * @param id 主键id
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void deleteById(String id) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(id);
        CommonBrand param = new CommonBrand();
        param.setDeleted(false).setId(id);
        CommonBrand brand = getByExample(param);
        if (null == brand) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }

        // 慧采商品关联校验
        Long brandId = brand.getBrandId();
        List<String> productIdList = commonProductService.listIdsByExample(new CommonProduct().setBrandId(brandId));
        if (CollectionUtils.isNotEmpty(productIdList)) {
            throw new BaseException(PuPrErrorCode.COMMON_BRAND_EXIST_PRODUCT_ERROR);
        }

        // 系列关联关系校验
        List<String> propIdList = commonPropService.listIdsByExample(new CommonProp().setBrandId(brandId).setDeleted(false));
        if (CollectionUtils.isNotEmpty(propIdList)) {
            throw new BaseException(PuPrErrorCode.COMMON_BRAND_EXIST_PROP_ERROR);
        }

        CommonBrand commonBrand = new CommonBrand();
        commonBrand.setId(id);
        commonBrand.setDeleted(true);
        commonBrand.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        super.update(commonBrand);
    }

    @Transactional(readOnly = true)
    public CommonBrand getByExample(CommonBrand brand) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(brand);
        Example example = genConditionExample(brand);
        return commonBrandMapper.selectOneByExample(example);
    }

    public Long syncBrand(String brandName, String productSrc) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CommonBrand.BRAND_NAME, brandName);
        criteria.andEqualTo(CommonBrand.DELETED, false);
        List<CommonBrand> brandList = commonBrandMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(brandList)) {
            return brandList.get(0).getBrandId();
        }
        CommonBrand commonBrand = new CommonBrand();
        Long brandId = genBrandId();
        commonBrand.setBrandId(brandId);
        commonBrand.setBrandName(brandName);
        commonBrand.setIsValid(PuPrConstants.IS_VALID_Y);
        commonBrand.setIsShopCenter(PuPrConstants.IS_SHOP_CENTER_N);
        commonBrand.setBrandNameLetter(PinyinUtil.getFirstLetter(brandName, "").substring(0, 1).toUpperCase());
        commonBrand.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        commonBrand.setSource(StringUtils.equalsIgnoreCase(productSrc, "ZYDMALL") ? "zydmall" : PuPrConstants.DATA_SOURCE_APPLY);
        super.insert(commonBrand);
        return brandId;
    }

    /**
     * 根据编号，获取编号名称map
     *
     * @param brandIds 编号
     * @return 编号名称map
     */
    @Transactional(readOnly = true)
    public Map<Long, String> mapNameByBrandIds(Set<Long> brandIds) {
        Map<Long, String> resMap = Maps.newHashMap();
        if (CollectionUtils.isEmpty(brandIds)) {
            return resMap;
        }

        List<CommonBrand> list = listAll(new CommonBrand().setBrandIds(brandIds));
        if (CollectionUtils.isEmpty(list)) {
            return resMap;
        }

        resMap = list.stream().collect(Collectors.toMap(CommonBrand::getBrandId, CommonBrand::getBrandName));
        return resMap;
    }

    /**
     * 获取侍标记删除数据-用于定时任务
     *
     * @return 主键集合
     */
    public Set<String> listIdsToDel() {
        return commonBrandMapper.listIdsToDel();
    }

    public List<CommonBrand> listByBrandIds(Set<Long> brandIds) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andIn(CommonBrand.BRAND_ID, brandIds);
        return commonBrandMapper.selectByExample(example);
    }

    /**
     * 根据条件，获取对象集合
     *
     * @param brand 条件
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public List<CommonBrand> listByCondition(CommonBrand brand) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(brand);
        Example example = genConditionExample(brand);
        return commonBrandMapper.selectByExample(example);
    }
}
