package com.online.purchase.mapper;

import com.online.purchase.model.CommonBrand;
import com.online.purchase.model.CommonCataBrandProp;
import com.online.purchase.model.CommonCatalog;
import com.online.purchase.model.CommonProp;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

/**
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
public interface CommonCataBrandPropMapper extends QguBaseMapper<CommonCataBrandProp> {

    /**
     * 根据实体字段条件获取对应实体集合--分页公用（分页由PageHelper实现-解耦合）
     *
     * @param commonCataBrandProp 实体对象
     * @return 对象集合
     */
    List<CommonCataBrandProp> search(@Param("con") CommonCataBrandProp commonCataBrandProp);

    /**
     * 商品分类第三级查看接口-分类下品牌接口
     *
     * @param cataId 分类编号
     * @return 品牌集合
     */
    List<CommonBrand> listBrandByCataId(Long cataId);

    /**
     * 第三级查看接口-分类、品牌下系列接口
     *
     * @param cataId  分类编号
     * @param brandId 品牌编号
     * @return 系列集合
     */
    List<CommonProp> listPropByCataIdAndBrandId(Long cataId, Long brandId);

    /**
     * 清空数据
     */
    void deleteAll();

    /**
     * 查出所有未删除三级分类
     *
     * @return 分类集合
     */
    List<CommonCatalog> listAllCatalog();

    /**
     * 分类下品牌接口
     *
     * @param cataIds 分类编号集合
     * @return 品牌集合
     */
    List<CommonBrand> listBrandByCataIds(@Param("cataIds") Set<Long> cataIds);

    /**
     * 分类、品牌下系列接口
     *
     * @param cataIds 分类编号集合
     * @param brandId 品牌编号
     * @return 系列集合
     */
    List<CommonProp> listPropByCataIdsAndBrandId(@Param("cataIds") Set<Long> cataIds, Long brandId);
}
