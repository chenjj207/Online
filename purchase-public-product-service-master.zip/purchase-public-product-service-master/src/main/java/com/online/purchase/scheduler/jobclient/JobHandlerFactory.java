package com.online.purchase.scheduler.jobclient;

import com.github.ltsopensource.core.domain.Job;
import com.github.ltsopensource.core.properties.TaskTrackerProperties;
import com.github.ltsopensource.jobclient.JobClient;
import com.online.purchase.base.JobConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 任务处理工厂
 *
 * @author zhangcheng
 * @since 2022-08-18
 */
@Component
@Slf4j
public class JobHandlerFactory {

    @Resource
    private JobClient jobClient;
    @Resource
    private TaskTrackerProperties taskTrackerProperties;
    @Resource
    private ApplicationContext applicationContext;

    private static final ConcurrentHashMap<String, Class<?>> JOB_HANDLER_MAP = new ConcurrentHashMap<>();

    static {
        JOB_HANDLER_MAP.put(JobConstant.TRIPARTITE_RELATIONSHIP, TripartiteRelationshipJobHandler.class);
        JOB_HANDLER_MAP.put(JobConstant.PRODUCT_NOTICE, ProductChangeNoticeJobHandler.class);
        JOB_HANDLER_MAP.put(JobConstant.PRODUCT_STRUCTURE_NOTICE, ProductStructureNoticeJobHandler.class);
        JOB_HANDLER_MAP.put(JobConstant.PRODUCT_STRUCTURE_DEL, ProductStructureDelJobHandler.class);
        JOB_HANDLER_MAP.put(JobConstant.ES_REBUILD, EsRebuildJobHandler.class);
        JOB_HANDLER_MAP.put(JobConstant.PRODUCT_MODI_REC, ProductModiRecJobHandler.class);
        JOB_HANDLER_MAP.put(JobConstant.THREE_CATA_PIC, ThreeCataPicJobHandler.class);
    }

    public boolean create(String id, String type, Map<String, String> paramMap) {
        Job job = new Job();
        job.setTaskId(type + JobConstant.TASK_ID_SEPARATOR + id);
        job.setParam(JobConstant.TASK_TYPE_KEY, type);
        job.setTaskTrackerNodeGroup(taskTrackerProperties.getNodeGroup());
        BaseJobHandler baseJobHandler = (BaseJobHandler) applicationContext.getBean(JOB_HANDLER_MAP.get(type));
        baseJobHandler.customJob(job, paramMap);
        return jobClient.submitJob(job).isSuccess();
    }

}
