package com.online.purchase.model;

import com.qgutech.qgyun.framework.database.model.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;

/**
 * 公海es model
 *
 * @author lwl
 */
@Getter
@Setter
@ToString
@ApiModel(value = "CommonEs", description = "")
@Table(name = "t_pd_common_es")
public class CommonEs extends BaseModel {

    public static final String PRODUCT_ID = "productId";
    public static final String ERP_PRODUCT_ID = "erpProductId";
    public static final String IS_ONSALE = "isOnsale";
    public static final String SKU_CODE = "skuCode";
    public static final String PRODUCT_TYPE = "productType";
    public static final String PRODUCT_SRC = "productSrc";
    public static final String PRODUCT_PIC_NAME = "productPicName";
    public static final String PROP_NAME = "propName";
    public static final String CATA_NAME = "cataName";
    public static final String THREE_CATA_NAME = "threeCataName";
    public static final String CATA_ORDER = "cataOrder";
    public static final String BRAND_ID = "brandId";
    public static final String BRAND_ORDER = "brandOrder";
    public static final String BRAND_NAME = "brandName";
    public static final String SEARCHSET = "searchset";
    public static final String SPEC_VALS = "specVals";
    public static final String SPECS = "specs";
    public static final String PRICE = "price";
    public static final String SPECSARR = "specsArr";
    public static final String TENANT_PRODUCT_SRC = "tenantProductSrc";
    public static final String ISCATASHOWPROP = "isCataShowProp";

    /**
     * 产品id
     */
    @ApiModelProperty(value = "产品id")
    private Long productId;

    /**
     * erp产品id
     */
    @ApiModelProperty(value = "erp产品id")
    private Long erpProductId;

    /**
     * 是否上架
     */
    @ApiModelProperty(value = "是否上架")
    private String isOnsale;

    /**
     * 产品货号
     */
    @ApiModelProperty(value = "产品货号")
    private String skuCode;

    /**
     * 产品型号
     */
    @ApiModelProperty(value = "产品型号")
    private String productType;

    /**
     * 产品来源
     */
    @ApiModelProperty(value = "产品来源")
    private String productSrc;

    /**
     * 产品图名称
     */
    @ApiModelProperty(value = "产品图名称")
    private String productPicName;

    /**
     * 系列名称
     */
    @ApiModelProperty(value = "系列名称")
    private String propName;

    /**
     * 分类名称
     */
    @ApiModelProperty(value = "分类名称")
    private String cataName;

    /**
     * 三级分类名称
     */
    @ApiModelProperty(value = "三级分类名称")
    private String threeCataName;

    /**
     * 分类排序
     */
    @ApiModelProperty(value = "分类排序")
    private BigDecimal cataOrder;

    /**
     * 品牌id
     */
    @ApiModelProperty(value = "品牌id")
    private Long brandId;

    /**
     * 品牌排序
     */
    @ApiModelProperty(value = "品牌排序")
    private Integer brandOrder;

    /**
     * 品牌名称
     */
    @ApiModelProperty(value = "品牌名称")
    private String brandName;

    /**
     * 搜索集
     */
    @ApiModelProperty(value = "搜索集")
    private String searchset;

    /**
     * 规格参数
     */
    @ApiModelProperty(value = "规格参数")
    private String specVals;

    /**
     * 规格值:规格参数
     */
    @ApiModelProperty(value = "规格值:规格参数")
    private String specs;

    /**
     * 价格
     */
    @ApiModelProperty(value = "价格")
    private BigDecimal price;

    /**
     * 惠采价格
     */
    @ApiModelProperty(value = "惠采价格")
    private BigDecimal purchasePrice;

    /**
     * 规格值:规格参数，三个空格
     */
    @ApiModelProperty(value = "规格值:规格参数，三个空格")
    private String specsArr;

    /**
     * 默认common
     */
    @ApiModelProperty(value = "默认common")
    private String tenantProductSrc;

    /**
     * 分类是否展示系列
     */
    @ApiModelProperty(value = "分类是否展示系列")
    private String isCataShowProp;

    /**
     * 供应商id
     */
    @ApiModelProperty(value = "供应商id")
    private String supplierId;

    @Transient
    private String createdByName;

    @Transient
    private String updatedByName;
}
