package com.online.purchase.model.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDateTime;


@Data
public class PurchaseCommonProductDto {




    private String id;
    /**
     * 产品编码
     */
    @ApiModelProperty(value = "产品编码")
    private Long productId;

    /**
     * ERP产品id
     */
    @ApiModelProperty(value = "ERP产品ID")
    private Long erpProductId;

    /**
     * ERP产品编码
     */
    @ApiModelProperty(value = "ERP产品编码")
    private String erpProductCode;

    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称")
    private String productName;

    /**
     * 产品型号
     */
    @ApiModelProperty(value = "产品型号")
    private String productType;

    /**
     * 产品货号
     */
    @ApiModelProperty(value = "产品货号")
    private String skuCode;

    /**
     * 面价
     */
    @ApiModelProperty(value = "面价")
    private BigDecimal price;

    /**
     * 分类id
     */
    @ApiModelProperty(value = "分类id")
    private Long cataId;

    /**
     * 品牌id
     */
    @ApiModelProperty(value = "品牌id")
    private Long brandId;

    /**
     * 品牌链接
     */
    @ApiModelProperty(value = "品牌链接")
    private String brandUrl;

    /**
     * 系列id
     */
    @ApiModelProperty(value = "系列id")
    private Long propId;

    /**
     * 物料名称
     */
    @ApiModelProperty(value = "物料名称")
    private String materialName;

    /**
     * 供应商商品申请来源
     */
    @ApiModelProperty(value = "供应商商品申请来源：inquiry | publish")
    private String applySource;

    /**
     * 申请表id
     */
    @ApiModelProperty(value = "申请表id")
    private String applyId;

    /**
     * 计量单位
     */
    @ApiModelProperty(value = "计量单位")
    private String unit;

    /**
     * 净重
     */
    @ApiModelProperty(value = "净重")
    private String weight;

    /**
     * 是否上架
     */
    @ApiModelProperty(value = "是否上架")
    private String isOnsale;

    /**
     * 产品图名称
     */
    @ApiModelProperty(value = "产品图名称")
    private String productPicName;

    /**
     * 3D模型名称
     */
    @ApiModelProperty(value = "3D模型名称")
    private String productModelName;

    /**
     * 视频名称
     */
    @ApiModelProperty(value = "视频名称")
    private String productVedioName;

    /**
     * 样本名称
     */
    @ApiModelProperty(value = "样本名称")
    private String productSimpleName;

    /**
     * 系列概述
     */
    @ApiModelProperty(value = "系列概述")
    private String productContent;

    /**
     * 是否正在调价中
     */
    @ApiModelProperty(value = "是否正在调价中")
    private String isAdjustPrice;

    /**
     * 产品来源
     */
    @ApiModelProperty(value = "产品来源")
    private String productSrc;

    /**
     * 是否有效
     */
    @ApiModelProperty(value = "是否有效")
    private String isValid;

    /**
     * 是否存在附件
     */
    @ApiModelProperty(value = "是否存在附件")
    private String existsAttachment;

    /**
     * 打包单位
     */
    @ApiModelProperty(value = "打包单位")
    private String packageUnit;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String ramark;

    /**
     * 库存
     */
    @ApiModelProperty(value = "库存")
    private Integer stock;

    /**
     * 供货价
     */
    private BigDecimal supplyPrice;

    /**
     * 慧采价
     */
    private BigDecimal purchasePrice;

    /**
     * 建议零售价
     */
    private BigDecimal suggestPrice;

    /**
     * 货期
     */
    private String deliveryDate;

    /**
     * 审核时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime;

    /**
     * 通知租户状态（1：等待通知，2：已通知）
     */
    @ApiModelProperty(value = "通知租户状态（1：等待通知，2：已通知）")
    private Integer syncStatus;

    /**
     * 供应商id
     */
    private String supplierId;

    /**
     * 关键字
     */
    @Transient
    private String keywords;

    /**
     * 品牌名称
     */
    @Transient
    private String brandName;

    /**
     * 系列名
     */
    @Transient
    private String propName;

    /**
     * 分类名称-一级分类
     */
    @Transient
    private String cataNameOne;

    /**
     * 分类名称-二级分类
     */
    @Transient
    private String cataNameTwo;

    /**
     * 分类名称-三级分类
     */
    @Transient
    private String cataNameThree;

    /**
     * 供应商名称
     */
    @Transient
    private String supplierName;

    /**
     * 规格
     */
    @Transient
    private String specData;
    /**
     * 样本
     */
    @Transient
    private String sample;

    /**
     * 供应商产品编码
     */
    @ApiModelProperty(value = "供应商产品编码")
    private String supplierProductCode;

    /**
     * 序号
     */
    @ApiModelProperty(value = "序号")
    private Long applyNo;

    /**
     * 一级店铺产品分类名
     */
    @ApiModelProperty(value = "一级店铺产品分类名")
    private String firstStoreCataName;

    /**
     * 二级店铺产品分类名
     */
    @ApiModelProperty(value = "二级店铺产品分类名")
    private String secondStoreCataName;
}
