package com.online.purchase.controller;

import cn.hutool.core.map.MapUtil;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.model.CommonProp;
import com.online.purchase.service.CommonPropService;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * CommonPropController 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@RestController
@RequestMapping(value = "/common-prop")
@Api(value = "CommonPropController", tags = {"公海系列服务"})
public class CommonPropController {

    @Resource
    private CommonPropService commonPropService;

    @PostMapping(value = "/page")
    @ApiOperation(value = "获取未标记删除分页数据")
    public JsonResult<Page<CommonProp>> search(@RequestBody CommonProp commonProp) {
        commonProp.setDeleted(false);
        Page<CommonProp> page = commonProp.getPage();
        page = null == page ? new Page<>() : page;
        page = commonPropService.search(commonProp, page);
        return new JsonResult<>(true, "查询成功", page);
    }

    @PostMapping(value = "/list")
    @ApiOperation(value = "获取所有未标记删除数据")
    public JsonResult<List<CommonProp>> listAll() {
        return new JsonResult<>(true, "查询成功", commonPropService.listAll(new CommonProp().setDeleted(false)));
    }

    @PostMapping("/add")
    @ApiOperation(value = "供应链新增接口")
    public JsonResult<Map<String, String>> addCommonProp(@RequestBody CommonProp commonProp) {
        commonProp.setSource(PuPrConstants.DATA_SOURCE);
        String id = commonPropService.add(commonProp, null);
        Map<String, String> data = MapUtil.newHashMap(1);
        data.put("id", id);
        return new JsonResult<>(true, "添加成功", data);
    }

    @PostMapping("/batchAdd")
    @ApiOperation(value = "批量系列新增接口")
    public JsonResult<Map<String, List<String>>> batchAddCommonProp(@RequestBody CommonProp commonProp) {
        commonProp.setSource(PuPrConstants.DATA_SOURCE);
        //批量新增规格参数解析
        List<CommonProp> commonProps = commonPropService.parseCommonProp(commonProp);
        List<String> ids = commonPropService.batchAdd(commonProps, null);
        Map<String, List<String>> data = MapUtil.newHashMap(1);
        data.put("ids", ids);
        return new JsonResult<>(true, "添加成功", data);
    }

    @PostMapping("/update")
    @ApiOperation(value = "编辑接口")
    public JsonResult editCommonProp(@RequestBody @Check(field = {"id"}) CommonProp commonProp) {
        commonPropService.edit(commonProp);
        return new JsonResult(true, "编辑成功");
    }

    @PostMapping(value = "/del")
    @ApiOperation(value = "根据传入的Id，删除数据")
    public JsonResult<String> delete(@RequestBody @Check(field = {"id"}) CommonProp commonProp) {
        commonPropService.deleteById(commonProp.getId());
        return new JsonResult<>(true, "删除成功");
    }

    @PostMapping(value = "/listAll")
    @ApiOperation(value = "获取所有未标记删除数据")
    public JsonResult<List<CommonProp>> listAll(@RequestBody CommonProp commonProp) {
        if (null == commonProp || null == commonProp.getBrandId()) {
            return new JsonResult<>(true, "查询成功", Collections.emptyList());
        }
        commonProp.setDeleted(false);
        return new JsonResult<>(true, "查询成功", commonPropService.listAll(commonProp));
    }
}