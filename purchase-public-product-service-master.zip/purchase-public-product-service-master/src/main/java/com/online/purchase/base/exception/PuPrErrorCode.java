package com.online.purchase.base.exception;

import com.qgutech.qgyun.framework.common.exception.ErrorEnum;

/**
 * 错误码
 *
 * @author lwl
 */
public enum PuPrErrorCode implements ErrorEnum {

    /**
     * 错误码
     */
    PARAMS_EMPTY_ERROR("PARAMS_EMPTY_ERROR", "参数不可为空"),
    DATA_EMPTY_ERROR("DATA_EMPTY_ERROR", "数据不存在"),
    DATA_ERROR("DATA_ERROR", "错误数据"),
    COMMON_BRAND_NAME_ERROR("COMMON_BRAND_NAME_ERROR", "品牌名称重复，请重新填写"),
    COMMON_BRAND_EXIST_PRODUCT_ERROR("COMMON_BRAND_EXIST_PRODUCT_ERROR", "当前品牌下存在挂靠的商品，请先移除处理！"),
    COMMON_BRAND_EXIST_PROP_ERROR("COMMON_BRAND_EXIST_PROP_ERROR", "当前品牌下存在挂靠的系列，请先移除处理！"),
    COMMON_PROP_NAME_ERROR("COMMON_PROP_NAME_ERROR", "系列名称重复，请重新填写"),
    COMMON_PROP_EXIST_PRODUCT_ERROR("COMMON_PROP_EXIST_PRODUCT_ERROR", "当前系列下存在挂靠的商品，请先移除处理！"),
    COMMON_CATA_NAME_ERROR("COMMON_CATA_NAME_ERROR", "分类名称重复，请重新填写"),
    COMMON_CATA_EXIST_CHILD_ERROR("COMMON_CATA_EXIST_CHILD_ERROR", "当前分类下存在子分类，不能删除!"),
    COMMON_CATA_EXIST_PRODUCT_ERROR("COMMON_BRAND_EXIST_PRODUCT_ERROR", "当前分类下存在挂靠的商品，请先移除处理！"),
    COMMON_CATA_HIERARCHY_ERROR("COMMON_CATA_HIERARCHY_ERROR", "请同级修改！"),
    COMMON_CATA_MAX_LEVEL_ERROR("COMMON_CATA_MAX_LEVEL_ERROR", "最多支持三级！"),
    COMMON_CATA_EXIST_SPEC_ERROR("COMMON_CATA_EXIST_SPEC_ERROR", "当前分类下存在挂靠的规格，请先移除处理！"),
    COMMON_SPEC_NAME_ERROR("COMMON_SPEC_NAME_ERROR", "规格名称重复，请重新填写"),
    COMMON_SPEC_CATA_LEVEL_ERROR("COMMON_SPEC_CATA_LEVEL_ERROR", "请选择三级分类"),
    COMMON_SPEC_EXIST_PRODUCT_ERROR("COMMON_SPEC_EXIST_PRODUCT_ERROR", "当前规格下存在挂靠的商品，请先移除处理！"),
    COMMON_SPEC_VAL_EXIST_PRODUCT_ERROR("COMMON_SPEC_VAL_EXIST_PRODUCT_ERROR", "规格值下存在挂靠的商品，请先移除处理！"),
    COMMON_SPEC_VAL_ERROR("COMMON_SPEC_VAL_ERROR", "规格值重复，请重新填写"),
    COMMON_ERP_PRODUCT_CODE_ERROR("COMMON_ERP_PRODUCT_CODE_ERROR", "最大长度为15，支持大小写字母和数字组成"),
    COMMON_ERP_PRODUCT_CODE_EXIST_ERROR("COMMON_ERP_PRODUCT_CODE_EXIST_ERROR", "商品编码重复，请重新填写"),
    THIS_PRODUCT_DOES_NOT_EXIST("THIS_PRODUCT_DOES_NOT_EXIST", "商品不存在"),
    ERROR_UPDATE_DATA("ERROR_UPDATE_DATA", "数据更新失败"),
    ERROR_DIGITAL_CONVERSION("ERROR_DIGITAL_CONVERSION", "数值转换异常"),
    ;

    private final String code;
    private final String text;

    PuPrErrorCode(String code, String text) {
        this.code = code;
        this.text = text;
    }

    @Override
    public String getText() {
        return text;
    }

    @Override
    public String getCode() {
        return code;
    }
}
