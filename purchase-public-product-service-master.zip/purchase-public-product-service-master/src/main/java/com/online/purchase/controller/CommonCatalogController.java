package com.online.purchase.controller;

import cn.hutool.core.map.MapUtil;
import com.github.pagehelper.Page;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.model.CommonCatalog;
import com.online.purchase.service.CommonCatalogService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * CommonCatalogController 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@RestController
@RequestMapping(value = "/common-catalog")
@Api(value = "CommonCatalogController", tags = {"公海分类服务"})
public class CommonCatalogController {

    @Resource
    private CommonCatalogService commonCatalogService;

    @PostMapping(value = "/tree-list")
    @ApiOperation(value = "获取所有未标记删除分类树")
    public JsonResult<List<CommonCatalog>> listAll() {
        return new JsonResult<>(true, "查询成功", commonCatalogService.getTree(new CommonCatalog().setDeleted(false)));
    }

    @PostMapping("/add")
    @ApiOperation(value = "供应链新增接口")
    public JsonResult<Map<String, String>> addCommonCatalog(@RequestBody CommonCatalog commonCatalog) {
        commonCatalog.setSource(PuPrConstants.DATA_SOURCE);
        String id = commonCatalogService.add(commonCatalog, null);
        Map<String, String> data = MapUtil.newHashMap(1);
        data.put("id", id);
        return new JsonResult<>(true, "添加成功", data);
    }

    @PostMapping("/update")
    @ApiOperation(value = "编辑接口")
    public JsonResult editCommonCatalog(@RequestBody @Check(field = {"id"}) CommonCatalog commonCatalog) {
        commonCatalogService.edit(commonCatalog);
        return new JsonResult(true, "编辑成功");
    }

    @PostMapping(value = "/del")
    @ApiOperation(value = "根据传入的Id，删除数据")
    public JsonResult<String> delete(@RequestBody @Check(field = {"id"}) CommonCatalog commonCatalog) {
        commonCatalogService.deleteById(commonCatalog.getId());
        return new JsonResult<>(true, "删除成功");
    }

    @PostMapping(value = "/checkCata")
    @ApiOperation(value = "校验分类是否存在")
    public JsonResult<String> checkCataName(@RequestBody CommonCatalog commonCatalog) {
        return new JsonResult<>(commonCatalogService.checkCataName(commonCatalog), "操作成功");
    }

    @PostMapping(value = "/name/query")
    @ApiOperation(value = "分类查询")
    public JsonResult<List<CommonCatalog>> queryCataName(@RequestBody CommonCatalog commonCatalog) {
        return new JsonResult<>(true, "查询成功", commonCatalogService.query(commonCatalog));
    }
}
