package com.online.purchase.scheduler.tasktracker;

import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.online.purchase.base.JobConstant;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.model.*;
import com.online.purchase.service.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * 公海产品结构无关联产品标记删除
 * (供应链新增不可删除)
 *
 * @author lwl
 */
@Component("productStructureDelActuator")
@Slf4j
public class ProductStructureDelActuator implements BaseJobRunnerActuator {

    @Resource
    private CommonBrandService commonBrandService;
    @Resource
    private CommonPropService commonPropService;
    @Resource
    private CommonCatalogService commonCatalogService;
    @Resource
    private CommonSpecService commonSpecService;
    @Resource
    private CommonSpecValService commonSpecValService;

    @Override
    public Result run(JobContext jobContext) {
        log.info("公海产品结构无关联产品标记删除开始 ==> " + LocalDateTime.now());
        dealData();
        log.info("公海产品结构无关联产品标记删除结束 ==> " + LocalDateTime.now());
        return new Result(Action.EXECUTE_SUCCESS, StringUtils.EMPTY);
    }

    private void dealData() {
        // 系列标记删除
        Set<String> delPropIds = commonPropService.listIdsToDel();
        if (CollectionUtils.isNotEmpty(delPropIds)) {
            List<CommonProp> delPropList = new ArrayList<>(delPropIds.size());
            CommonProp prop;
            for (String id : delPropIds) {
                prop = new CommonProp();
                prop.setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_DEL);
                prop.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC).setId(id);
                delPropList.add(prop);
            }

            commonPropService.batchUpdate(delPropList);
        }

        // 品牌标记删除
        Set<String> delBrandIds = commonBrandService.listIdsToDel();
        if (CollectionUtils.isNotEmpty(delBrandIds)) {
            List<CommonBrand> delBrandList = new ArrayList<>(delBrandIds.size());
            CommonBrand brand;
            for (String id : delBrandIds) {
                brand = new CommonBrand();
                brand.setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_DEL);
                brand.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC).setId(id);
                delBrandList.add(brand);
            }

            commonBrandService.batchUpdate(delBrandList);
        }

        // 规格值标记删除
        Set<String> delSpecValIds = commonSpecValService.listIdsToDel();
        if (CollectionUtils.isNotEmpty(delSpecValIds)) {
            List<CommonSpecVal> delSpecValList = new ArrayList<>(delSpecValIds.size());
            CommonSpecVal specVal;
            for (String id : delSpecValIds) {
                specVal = new CommonSpecVal();
                specVal.setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_DEL);
                specVal.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC).setId(id);
                delSpecValList.add(specVal);
            }

            commonSpecValService.batchUpdate(delSpecValList);
        }

        // 规格标记删除
        Set<String> delSpecIds = commonSpecService.listIdsToDel();
        if (CollectionUtils.isNotEmpty(delSpecIds)) {
            List<CommonSpec> delSpecList = new ArrayList<>(delSpecIds.size());
            CommonSpec spec;
            for (String id : delSpecIds) {
                spec = new CommonSpec();
                spec.setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_DEL);
                spec.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC).setId(id);
                delSpecList.add(spec);
            }

            commonSpecService.batchUpdate(delSpecList);
        }

        // 分类标记删除
        Set<String> delCataIds = commonCatalogService.listIdsToDel();
        if (CollectionUtils.isNotEmpty(delCataIds)) {
            List<CommonCatalog> delCataList = new ArrayList<>(delCataIds.size());
            CommonCatalog catalog;
            for (String id : delCataIds) {
                catalog = new CommonCatalog();
                catalog.setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_DEL);
                catalog.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC).setId(id);
                delCataList.add(catalog);
            }

            commonCatalogService.batchUpdate(delCataList);
        }
        delCataIds = commonCatalogService.listIdsToDel();
        if (CollectionUtils.isNotEmpty(delCataIds)) {
            List<CommonCatalog> delCataList = new ArrayList<>(delCataIds.size());
            CommonCatalog catalog;
            for (String id : delCataIds) {
                catalog = new CommonCatalog();
                catalog.setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_DEL);
                catalog.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC).setId(id);
                delCataList.add(catalog);
            }

            commonCatalogService.batchUpdate(delCataList);
        }
        delCataIds = commonCatalogService.listIdsToDel();
        if (CollectionUtils.isNotEmpty(delCataIds)) {
            List<CommonCatalog> delCataList = new ArrayList<>(delCataIds.size());
            CommonCatalog catalog;
            for (String id : delCataIds) {
                catalog = new CommonCatalog();
                catalog.setUpdatedBy(JobConstant.PRODUCT_STRUCTURE_DEL);
                catalog.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC).setId(id);
                delCataList.add(catalog);
            }

            commonCatalogService.batchUpdate(delCataList);
        }
    }
}
