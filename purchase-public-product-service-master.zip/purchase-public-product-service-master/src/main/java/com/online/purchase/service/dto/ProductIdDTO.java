package com.online.purchase.service.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProductIdDTO {
    @ApiModelProperty(value = "产品id")
    private String id ;

    @ApiModelProperty("是否上下架（Y=上架，N=下架）")
    private String isOnsale;

    @ApiModelProperty("原因")
    private String reason;


}
