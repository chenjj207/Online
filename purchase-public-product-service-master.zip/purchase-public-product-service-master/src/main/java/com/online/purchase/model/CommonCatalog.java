package com.online.purchase.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Collection;
import java.util.List;

/**
 * 分类 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Accessors(chain = true)
@ApiModel(value = "CommonCatalog", description = "分类")
@Table(name = "online_common.t_pd_common_catalog")
public class CommonCatalog extends BaseCorpModel {

    public static final String CATA_ID = "cataId";
    public static final String CATA_NAME = "cataName";
    public static final String LEVEL = "level";
    public static final String PARENT_CATA_ID = "parentCataId";
    public static final String ATTACH_CATA_ID = "attachCataId";
    public static final String SORT = "sort";
    public static final String IS_VALID = "isValid";
    public static final String CATA_IDS = "cataIds";
    public static final String IS_SHOW_PROP = "isShowProp";
    public static final String PIC_URL = "picUrl";
    public static final String REMARK = "remark";
    public static final String DELETED = "deleted";
    public static final String SOURCE = "source";
    public static final String SYNC_STATUS = "syncStatus";

    /**
     * 分类编码
     */
    @ApiModelProperty(value = "分类编码")
    private Long cataId;

    /**
     * 分类名称
     */
    @ApiModelProperty(value = "分类名称")
    private String cataName;

    /**
     * 分类等级
     */
    @ApiModelProperty(value = "分类等级")
    private Integer level;

    /**
     * 父分类id，默认为0，即为根分类
     */
    @ApiModelProperty(value = "父分类id，默认为0，即为根分类")
    private Long parentCataId;

    /**
     * 附件分类编号
     */
    @ApiModelProperty(value = "附件分类编号")
    private Long attachCataId;

    /**
     * 排序
     */
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /**
     * 是否有效 Y：是 N：否
     */
    @ApiModelProperty(value = "是否有效 Y：是 N：否")
    private String isValid;

    /**
     * 分类路径
     */
    @ApiModelProperty(value = "分类路径")
    private String cataIds;

    /**
     * 是否显示系列
     */
    @ApiModelProperty(value = "是否显示系列")
    private String isShowProp;

    /**
     * 分类图片地址
     */
    @ApiModelProperty(value = "分类图片地址")
    private String picUrl;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 标记删除
     */
    private Boolean deleted;

    /**
     * 数据来源
     */
    private String source;

    /**
     * 通知租户状态（1：等待通知，2：已通知）
     */
    @ApiModelProperty(value = "通知租户状态（1：等待通知，2：已通知）")
    private Integer syncStatus;

    /**
     * 子集
     */
    @Transient
    private List<CommonCatalog> children;

    /**
     * 编号集合
     */
    @Transient
    private Collection<Long> cataIdList;

    /**
     * 父分类编号集合
     */
    @Transient
    private Collection<Long> parentCataIds;
}
