package com.online.purchase.mapper;

import com.online.purchase.model.CommonProp;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

/**
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
public interface CommonPropMapper extends QguBaseMapper<CommonProp> {

    /**
     * 根据实体字段条件获取对应实体集合--分页公用（分页由PageHelper实现-解耦合）
     *
     * @param commonProp 实体对象
     * @return 对象集合
     */
    List<CommonProp> search(@Param("con") CommonProp commonProp);

    /**
     * 根据条件，获取所有数据
     *
     * @param commonProp 条件
     * @return 数据集合
     */
    List<CommonProp> selectAllByCondition(@Param("con") CommonProp commonProp);

    /**
     * 根据品牌id，批量修改品牌id关联
     *  @param oldBrandId 原品牌id
     * @param brandId    品牌id
     */
    void batchUpdateBrandId(Long oldBrandId, Long brandId);

    /**
     * 生成系列编号
     *
     * @return 编号
     */
    Long getMaxPropId();

    int getMaxPropSort();

    /**
     * 获取侍标记删除数据-用于定时任务
     *
     * @return 主键集合
     */
    Set<String> listIdsToDel();
}
