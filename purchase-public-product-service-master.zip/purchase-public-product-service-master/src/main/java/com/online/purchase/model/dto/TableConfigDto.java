package com.online.purchase.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("表格配置")
public class TableConfigDto {
    @ApiModelProperty("字段")
    private String field;
    @ApiModelProperty("字段文本")
    private String text;
    @ApiModelProperty("是否固定")
    private boolean fixed;
    @ApiModelProperty("是否展示")
    private boolean show;
    @ApiModelProperty("序号")
    private int order;

}
