package com.online.purchase.client.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class CheckProductDTO {

    @NotNull
    private Long productId;

    @NotBlank
    private String supplierId;

    @NotNull
    private Long brandId;
}
