package com.online.purchase.mapper;

import com.online.purchase.model.CommonProductMallRec;
import com.online.purchase.model.vo.CommonProductMallRecVo;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CommonProductMallRecMapper extends QguBaseMapper<CommonProductMallRec> {

    /**
     * 获取未发送的公海_产品变更商城记录列表
     *
     * @Author: loine
     * @Date: 2025/4/2 17:21
     */
    List<CommonProductMallRecVo> getProductMallRecNotSendList();

    /**
     * 更新公海_产品变更商城记录发送状态
     *
     * @param ids
     * @Author: loine
     * @Date: 2025/4/2 17:30
     */
    void productMallRecUpdateSend(@Param("ids") List<String> ids);
}
