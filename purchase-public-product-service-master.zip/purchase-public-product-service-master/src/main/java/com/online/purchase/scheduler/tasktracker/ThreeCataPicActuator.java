package com.online.purchase.scheduler.tasktracker;

import cn.hutool.core.bean.BeanUtil;
import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.online.purchase.config.CommonOssConf;
import com.online.purchase.mapper.CommonCataPicMapper;
import com.online.purchase.model.CommonCataPic;
import com.online.purchase.service.CommonEsService;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 三级分类确定产品图
 *
 * @author jdl
 * @since 2024-07-03
 */
@Component("threeCataPicActuator")
@Slf4j
public class ThreeCataPicActuator implements BaseJobRunnerActuator {

    @Resource
    CommonCataPicMapper commonCataPicMapper;
    @Resource
    private CommonOssConf commonOssConf;

    @Override
    @Transactional
    public Result run(JobContext jobContext) {
        log.info("三级分类确定产品图开始 ==> " + LocalDateTime.now());
        //先删除所有
        commonCataPicMapper.deleteAll();
        List<CommonCataPic> queryCommonCataPics = commonCataPicMapper.selectCataInfo();
        LocalDateTime now = LocalDateTime.now();
        if (CollectionUtils.isNotEmpty(queryCommonCataPics)){
            for (CommonCataPic c :  queryCommonCataPics) {
                CommonCataPic commonCataPic = new CommonCataPic();
                BeanUtil.copyProperties(c, commonCataPic);
                String id = IDUtils.getUUID19();
                commonCataPic.setId(id);
                if (StringUtils.isNotEmpty(c.getCataName())){
                    String[] cataSplit = c.getCataName().split(" ");
                    commonCataPic.setOneCataName(cataSplit[0]);
                    commonCataPic.setTwoCataName(cataSplit[1]);
                    commonCataPic.setThreeCataName(cataSplit[2]);
                }else {
                    commonCataPic.setOneCataName("");
                    commonCataPic.setTwoCataName("");
                    commonCataPic.setThreeCataName("");
                    commonCataPic.setCataName("");
                }
                commonCataPic.setBrandName(StringUtils.isEmpty(c.getBrandName()) ? "" : c.getBrandName());
                commonCataPic.setPropName(StringUtils.isEmpty(c.getPropName()) ? "" : c.getPropName());
                if (StringUtils.isNotEmpty(c.getProductPicName())){
                    if (StringUtils.equals(c.getProductSrc(), "ZYDMALL")){
                        String filePath = "product/image" + "/" + c.getBrandName() + "/" + commonCataPic.getOneCataName() +
                                "/" + commonCataPic.getTwoCataName() + "/" + commonCataPic.getThreeCataName() +
                                "/" + commonCataPic.getBrandName() + "_" + commonCataPic.getOneCataName() + "_" +
                                commonCataPic.getTwoCataName() + "_" + commonCataPic.getThreeCataName() + "_" + commonCataPic.getPropName();
                        commonCataPic.setProductPicName(commonOssConf.getOssUrl() + filePath + "/产品主图/" + c.getProductPicName().split("@")[0] + ".jpg");
                    }
                }
                commonCataPic.setCreatedAt(now);
                commonCataPic.setCreatedBy("初始化");
                commonCataPicMapper.insertSelective(commonCataPic);
            }
        }

        log.info("三级分类确定产品图结束 ==> " + LocalDateTime.now());
        return new Result(Action.EXECUTE_SUCCESS, StringUtils.EMPTY);
    }

}
