package com.online.purchase.utils;

import cn.hutool.core.io.IoUtil;
import cn.hutool.core.thread.ThreadUtil;
import com.aliyun.oss.HttpMethod;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.*;
import com.online.purchase.config.OssConf;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.*;

/**
 *  OssMaterialService 服务提供类
 *
 * @author zhangcheng
 * @version 1.0
 * @since 2022-08-10
 */
@Service
@Slf4j
public class OssUtil {

    @Autowired
    private OssConf ossConf;

    /**
     * 上传接口（根据流）
     *
     * @param newPath
     * @param is
     * @Author: loine
     * @Date: 2024/12/27 11:38
     */
    public String uploadResourceByIs(String newPath, ByteArrayInputStream is) {
        OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        try {
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(), newPath, is));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(is);
            ossClient.shutdown();
        }
        return ossConf.getOssUrl() + newPath;
    }
}
