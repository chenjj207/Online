package com.online.purchase.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 公海_产品变更商城记录表
 */
@Data
@ApiModel("公海_产品变更商城记录列表-出参")
public class CommonProductMallRecVo {
    @ApiModelProperty("主键")
    private String id;
    @ApiModelProperty("类型:1-新增,2-修改")
    private Long type;
    @ApiModelProperty("SCM产品ID")
    private Long scmProductId;
    @ApiModelProperty("商城产品ID")
    private Long mallProductId;
    @ApiModelProperty("ERP产品编码")
    private String erpProductCode;
    @ApiModelProperty("分类id")
    private Long cataId;
    @ApiModelProperty("品牌id")
    private Long brandId;
    @ApiModelProperty("系列id")
    private Long propId;
    @ApiModelProperty("一级分类")
    private String cataNameOne;
    @ApiModelProperty("二级分类")
    private String cataNameTwo;
    @ApiModelProperty("三级分类")
    private String cataNameThree;
    @ApiModelProperty("品牌")
    private String brandName;
    @ApiModelProperty("系列")
    private String propName;
    @ApiModelProperty("规格名,多个以@分开")
    private String specName;
    @ApiModelProperty("规格值,多个以@分开")
    private String specValue;
    @ApiModelProperty("产品主图")
    private String productPicName;
    @ApiModelProperty("产品视频")
    private String productVedioName;
    @ApiModelProperty("产品详情图")
    private String productContent;
    @ApiModelProperty("产品样本")
    private String productSimpleName;
    @ApiModelProperty("重量")
    private String weight;
    @ApiModelProperty("是否发送：0-未发送，1-已发送")
    private Integer sendStatus;

    @ApiModelProperty("产品型号")
    private String productType;
    @ApiModelProperty("订货号")
    private String skuCode;
    @ApiModelProperty("计量单位")
    private String unit;
    @ApiModelProperty("最小起订量")
    private Integer minimunRequire;
    @ApiModelProperty("品牌名称首字母")
    private String brandNameLetter;
}
