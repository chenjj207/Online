package com.online.purchase.service;

import com.github.pagehelper.PageHelper;
import com.google.common.collect.Maps;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.mapper.CommonProductSpecMapper;
import com.online.purchase.model.CommonProductSpec;
import com.online.purchase.model.CommonSpecVal;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * CommonProductSpecService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Service
public class CommonProductSpecService extends BaseServiceImpl<CommonProductSpec> {

    @Resource
    private CommonProductSpecMapper commonProductSpecMapper;

    @Resource
    private RedisTemplate redisTemplate;

    public List<CommonProductSpec> listAll() {
        return commonProductSpecMapper.selectAll();
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<CommonProductSpec> search(CommonProductSpec commonProductSpec, Page<CommonProductSpec> page) {
        Assert.notNull(commonProductSpec, "commonProductSpec can not be null!");
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<CommonProductSpec> list = commonProductSpecMapper.search(commonProductSpec);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packCommonProductSpecData(list);
        return page;
    }

    private Example genConditionExample(CommonProductSpec model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        Long productId = model.getProductId();
        if (null != productId) {
            criteria.andEqualTo(CommonProductSpec.PRODUCT_ID, productId);
        }

        Collection<Long> productIds = model.getProductIds();
        if (CollectionUtils.isNotEmpty(productIds)) {
            criteria.andIn(CommonProductSpec.PRODUCT_ID, productIds);
        }

        Long specId = model.getSpecId();
        if (null != specId) {
            criteria.andEqualTo(CommonProductSpec.SPEC_ID, specId);
        }

        Long specValueId = model.getSpecValueId();
        if (null != specValueId) {
            criteria.andEqualTo(CommonProductSpec.SPEC_VALUE_ID, specValueId);
        }

        Collection<Long> specValueIds = model.getSpecValueIds();
        if (CollectionUtils.isNotEmpty(specValueIds)) {
            criteria.andIn(CommonProductSpec.SPEC_VALUE_ID, specValueIds);
        }

        return example;
    }

    /**
     * 分页数据处理
     */
    private void packCommonProductSpecData(List<CommonProductSpec> commonProductSpecList) {
        if (CollectionUtils.isEmpty(commonProductSpecList)) {
            return;
        }

    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(CommonProductSpec commonProductSpec) {
        Assert.notNull(commonProductSpec, "commonProductSpec can not be null");
        Example example = genConditionExample(commonProductSpec);
        example.selectProperties(CommonProductSpec.ID);
        List<CommonProductSpec> commonProductSpecList = commonProductSpecMapper.selectByExample(example);
        return CollectionUtils.isEmpty(commonProductSpecList) ? new ArrayList<>(0) :
                commonProductSpecList.stream().map(CommonProductSpec::getId).collect(Collectors.toList());
    }

    /**
     * 新增
     */
    public String add(CommonProductSpec commonProductSpec) {
        return super.insert(commonProductSpec);
    }

    /**
     * 修改
     */
    public void edit(CommonProductSpec commonProductSpec) {
        super.update(commonProductSpec);
    }

    /**
     * 批量删除
     */
    public void deleteByIds(List<String> ids) {
        super.batchDelete(ids);
    }

    /**
     * 根据条件，获取对象集合
     *
     * @param productSpec 条件
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public List<CommonProductSpec> listByExample(CommonProductSpec productSpec) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(productSpec);
        Example example = genConditionExample(productSpec);
        return commonProductSpecMapper.selectByExample(example);
    }

    /**
     * 根据产品ID，获取对象map
     *
     * @param productIds 产品ID
     * @return 对象map
     */
    @Transactional(readOnly = true)
    public Map<Long, List<CommonProductSpec>> mapByProductId(Set<Long> productIds) {
        if (CollectionUtils.isEmpty(productIds)) {
            return Maps.newHashMap();
        }

        List<CommonProductSpec> list = listByExample(new CommonProductSpec().setProductIds(productIds));
        if (CollectionUtils.isEmpty(list)) {
            return Maps.newHashMap();
        }

        return list.stream().collect(Collectors.groupingBy(CommonProductSpec::getProductId));
    }

    public void compareAndSave(CommonProductSpec commonProductSpec) {
        Long productId = commonProductSpec.getProductId();
        Long specId = commonProductSpec.getSpecId();
        Long specValueId = commonProductSpec.getSpecValueId();
        if (null == productId || specId == null || specValueId == null) {
            return;
        }
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CommonProductSpec.SPEC_VALUE_ID, productId);
        criteria.andEqualTo(CommonProductSpec.PRODUCT_ID, specValueId);
        criteria.andEqualTo(CommonProductSpec.SPEC_ID, specId);
        List<CommonProductSpec> commonProductSpecs = commonProductSpecMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(commonProductSpecs)) {
            super.insert(commonProductSpec);
        }
    }

    public void deleteByProductId(Long productId) {
        commonProductSpecMapper.deleteByProductId(productId);
    }


    public List<CommonProductSpec> selectByProductId(Long productId) {
        return commonProductSpecMapper.selectByProductId(productId);
    }
}
