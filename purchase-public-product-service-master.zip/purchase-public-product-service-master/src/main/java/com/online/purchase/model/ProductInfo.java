package com.online.purchase.model;


import com.purchase.model.dto.CommonProductDto;
import com.purchase.model.dto.SpecAndValDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class ProductInfo {
        @ApiModelProperty("产品详情基础信息")
        private Info info;
        @ApiModelProperty("产品样本信息")
        private List<Sample> sampleList;
        @ApiModelProperty("产品图片信息")
        private List<Image> imageList;
        @ApiModelProperty("产品视频信息")
        private List<Vedio> vedioList;
        @ApiModelProperty("内容")
        private List<Content> contentList;
        @ApiModelProperty("3D")
        private List<ThreeD> threeDList;
        @ApiModelProperty("订货号文描的商品详细信息")
        private String contentImgUrl;
        @ApiModelProperty(value = "URL前缀")
        private String urlPrefix;

        @Data
        @ApiModel("产品基础信息")
        public static class Info extends CommonProductDto {
            @ApiModelProperty("门户名称")
            private String displayName;
            @ApiModelProperty("品牌名")
            private String brandName;
            @ApiModelProperty("品牌图链接")
            private String brandImgUrl;
            @ApiModelProperty("系列名")
            private String propName;
            @ApiModelProperty("分类名")
            private String cataName;
            @ApiModelProperty("分类id")
            private String cataIds;
            @ApiModelProperty("完整分类名")
            private List<String> cataIdList;
            @ApiModelProperty("规格")
            private List<SpecAndValDTO> specAndVals;
            @ApiModelProperty("规格:规格值")
            private String spec;
            @ApiModelProperty("是否显示系列")
            private String isCataShowProp;
            @ApiModelProperty("所属店铺id")
            private Integer storeId;
            @ApiModelProperty("所属店铺类型")
            private Integer storeType;
            @ApiModelProperty("所属店铺名")
            private String storeName;
        }

        @Data
        @ApiModel("产品样本信息")
        public static class Sample {
            @ApiModelProperty("文件名")
            private String fileName;
            @ApiModelProperty("文件大小")
            private long fileSize;
            @ApiModelProperty("文件地址")
            private String fileUrl;
        }

        @Data
        @ApiModel("产品图片信息")
        public static class Image {
            @ApiModelProperty("小图片地址")
            private String imgSmallUrl;
            @ApiModelProperty("源图片地址")
            private String imgSrcUrl;
            @ApiModelProperty("类型 oss")
            private String mimeType = "oss";
        }

        @Data
        @ApiModel("产品视频信息")
        public static class Vedio {
            @ApiModelProperty("视频的图片地址")
            private String vedioImgUrl;
            @ApiModelProperty("视频地址")
            private String vedioUrl;
        }

        @Data
        @ApiModel("内容")
        public static class Content {
            @ApiModelProperty("内容类型：产品系列图 系列概述 特性描述")
            private String type;
            @ApiModelProperty("地址")
            private List<String> urls;
            @ApiModelProperty("html")
            private String html;
            @ApiModelProperty("排序")
            private int sort;
            @ApiModelProperty("产品内容")
            private String productContent;
            @ApiModelProperty("水印图片字符串")
            private String waterMarkImg;
        }

        @Data
        @ApiModel("3D")
        public static class ThreeD {
            @ApiModelProperty("3D 模型名字")
            private String name;
            @ApiModelProperty("地址")
            private String url;
        }

}
