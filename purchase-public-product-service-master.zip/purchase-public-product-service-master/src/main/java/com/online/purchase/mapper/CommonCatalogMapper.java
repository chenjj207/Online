package com.online.purchase.mapper;

import com.online.purchase.model.CommonCatalog;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

/**
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
public interface CommonCatalogMapper extends QguBaseMapper<CommonCatalog> {

    /**
     * 生成分类编号
     *
     * @return 编号
     */
    Long getMaxCataId();

    /**
     * 获取最大排序
     * @param parentCataId
     * @return
     */
    Integer getMaxSortByParentId(@Param("parentCataId")Long parentCataId);

    /**
     * 获取侍标记删除数据-用于定时任务
     *
     * @return 主键集合
     */
    Set<CommonCatalog> listIdsToDel();

    /**
     * 根据编号查询对象
     *
     * @param commonCatalog 编号条件
     * @return 对象集合
     */
    List<CommonCatalog> selectByCataIds(CommonCatalog commonCatalog);

    /**
     * 获取所有未删除分类
     *
     * @return 分类信任
     */
    List<CommonCatalog> listAllForTree();

    List<CommonCatalog> selectCataName(@Param("list") List<Long> cataIds);
}
