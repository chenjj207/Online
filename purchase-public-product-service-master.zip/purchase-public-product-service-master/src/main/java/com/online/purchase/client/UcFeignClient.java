package com.online.purchase.client;

import com.purchase.model.Supplier;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Collection;
import java.util.Map;

/**
 * 对外服务接口
 *
 * @author lwl
 */
@FeignClient(value = "purchase-user", path = "/ucFeign")
public interface UcFeignClient {

    /**
     * 根据供应商id，获取对象map
     *
     * @param ids 主键
     * @return 供应商对象map
     */
    @PostMapping(value = "/mapSupplierByIds")
    Map<String, Supplier> mapSupplierByIds(@RequestBody Collection<String> ids);
}
