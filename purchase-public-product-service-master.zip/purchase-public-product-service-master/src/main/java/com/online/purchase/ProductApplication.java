package com.online.purchase;

import com.github.ltsopensource.spring.boot.annotation.EnableJobClient;
import com.github.ltsopensource.spring.boot.annotation.EnableTaskTracker;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import tk.mybatis.spring.annotation.MapperScan;

/**
 * purchase 项目启动类文件
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@SpringCloudApplication
@ComponentScan({"com.online.purchase.**", "com.purchase.**"})
@MapperScan({"com.online.purchase.**.mapper"})
@EnableTaskTracker
@EnableJobClient
@EnableFeignClients({"com.online.purchase.client","com.qgutech.qgyun.dev.client.**"})
public class ProductApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProductApplication.class, args);
        System.out.println("------------ product服务 启动完成--------------");
    }
}
