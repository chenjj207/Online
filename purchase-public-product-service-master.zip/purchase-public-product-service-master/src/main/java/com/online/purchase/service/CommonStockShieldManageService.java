package com.online.purchase.service;

import com.github.pagehelper.PageHelper;
import com.online.purchase.mapper.CommonProductMapper;
import com.online.purchase.mapper.CommonStockShieldManageMapper;
import com.online.purchase.model.CommonStockShieldManage;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;

/**
 * CommonPropService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Service
public class CommonStockShieldManageService {

    @Resource
    private CommonStockShieldManageMapper commonStockShieldManageMapper;

    @Resource
    private CommonProductMapper commonProductMapper;


    public JsonResult shieldStock(){
        int pageNum = 1;
        while (true){
            PageHelper.startPage(pageNum, 5000);
            List<CommonStockShieldManage> commonStockShieldManages = commonStockShieldManageMapper.selectOrderById();
            if (CollectionUtils.isEmpty(commonStockShieldManages)){
                break;
            }
            for (CommonStockShieldManage commonStockShieldManage : commonStockShieldManages){
                if (StringUtils.isNotEmpty(commonStockShieldManage.getTypeKey())){
                    commonProductMapper.updateStockByDynamics(commonStockShieldManage.getTypeKey(), commonStockShieldManage.getPropertyValue());
                }
            }
            pageNum++;
        }
        //执行es库存更新
        commonProductMapper.updateEsStock();
        return JsonResult.ok();
    }

    public JsonResult add(CommonStockShieldManage commonStockShieldManage){
        if (StringUtils.equals(commonStockShieldManage.getTypeKey(), "product_id")
                || StringUtils.equals(commonStockShieldManage.getTypeKey(), "erp_product_id")
                || StringUtils.equals(commonStockShieldManage.getTypeKey(), "erp_product_code")
                || StringUtils.equals(commonStockShieldManage.getTypeKey(), "sku_code")
                || StringUtils.equals(commonStockShieldManage.getTypeKey(), "product_type")){
            String[] propertyS = commonStockShieldManage.getPropertyValue().split(",");
            if (propertyS != null && propertyS.length > 0){
                for (int i = 0; i < propertyS.length; i++) {
                    CommonStockShieldManage c = new CommonStockShieldManage();
                    c.setTypeKey(commonStockShieldManage.getTypeKey());
                    c.setPropertyValue(propertyS[i]);
                    c.setCreatedAt(LocalDateTime.now());
                    c.setCreatedBy("init");
                    c.setCorpCode("default");
                    commonStockShieldManageMapper.insert(c);
                }
            }
        }else {
            CommonStockShieldManage c = new CommonStockShieldManage();
            c.setTypeKey(commonStockShieldManage.getTypeKey());
            c.setPropertyValue(commonStockShieldManage.getPropertyValue());
            c.setCreatedAt(LocalDateTime.now());
            c.setCreatedBy("init");
            c.setCorpCode("default");
            commonStockShieldManageMapper.insert(c);
        }
        return JsonResult.ok();
    }
}
