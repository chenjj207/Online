package com.online.purchase.client.dto;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * @author
 * @Description:
 * @date 2024/11/13  9:14
 */
@Data
@ApiModel("消息请求")
public class TriggerMsgRequest {
    @ApiModelProperty("业务")
    private String business;
    @ApiModelProperty("场景")
    private String scene;
    @ApiModelProperty("短信参数")
    private JSONObject smsParam;
    @ApiModelProperty("微信公众号参数")
    private JSONObject wxpfParam;
    @ApiModelProperty("企业微信参数")
    private JSONObject qywxParam;

}
