package com.online.purchase.service;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.mapper.CommonSpecMapper;
import com.online.purchase.mapper.CommonSpecUnitMapper;
import com.online.purchase.model.CommonSpecUnit;
import com.online.purchase.model.vo.SpecUnitVo;
import com.online.purchase.utils.GenericDataListener;
import com.online.purchase.utils.OssUtil;
import com.purchase.exception.ZydExceptions;
import com.purchase.utils.date.ZydDateUtils;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author auto
 * @version 1.0
 * @since 2026-01-06 09:45:02
 */
@Service
@Slf4j
public class CommonSpecUnitService extends BaseServiceImpl<CommonSpecUnit> {

    @Resource
    private CommonSpecMapper commonSpecMapper;
    @Resource
    private CommonSpecUnitMapper commonSpecUnitMapper;
    @Autowired
    private OssUtil ossUtil;

    /**
     * 规格参数标准计量单位导出
     *
     * @Author loine
     * @Date 2026/1/6 10:05
     */
    public JsonResult<String> unitExport() {
        List<SpecUnitVo> list = commonSpecMapper.getSpecUnitAll();
        for (SpecUnitVo l : list) {
            if (StringUtils.isNotBlank(l.getSpecValue())) {
                // excel单元格有最大长度，超过则截取
                if (l.getSpecValue().length() > 32000) {
                    l.setSpecValue(l.getSpecValue().substring(0, 32000));
                }
            }
        }
        // 执行导出
        String newPath = "commonSpecUnit/excel/" + ZydDateUtils.format(ZydDateUtils.ymdGapless, new Date()) + "/规格名称计量单位规范表.xlsx";
        try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
            ExcelWriter excelWriter = EasyExcel.write(Files.newOutputStream(Paths.get("规格名称计量单位数据.xlsx"))).file(os).build();
            WriteSheet sheet = EasyExcel.writerSheet(0, "明细").head(SpecUnitVo.class).build();
            excelWriter.write(list, sheet);
            excelWriter.finish();

            String url = ossUtil.uploadResourceByIs(newPath, new ByteArrayInputStream(os.toByteArray()));
            return new JsonResult<>(true, "导出成功", url);
        } catch (Exception e) {
            log.error("导出异常{}", e.getMessage());
            throw new BaseException(PuPrErrorCode.DATA_ERROR.getCode(), "导出异常：" + e.getMessage());
        }
    }

    /**
     * 规格参数标准计量单位导入
     *
     * @Author loine
     * @Date 2026/1/6 10:05
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public JsonResult<String> unitImport(MultipartFile file) {
        try {
            // 创建通用监听器实例
            GenericDataListener<SpecUnitVo> listener = new GenericDataListener<>();
            // 使用 EasyExcel 读取文件
            EasyExcel.read(file.getInputStream(), SpecUnitVo.class, listener).sheet().doRead();
            // 获取读取到的数据
            List<SpecUnitVo> dataList = listener.getDataList();
            if (CollectionUtils.isNotEmpty(dataList)) {
                List<CommonSpecUnit> insert = new LinkedList<>();
                List<CommonSpecUnit> update = new LinkedList<>();
                // 获取原本规格参数计量单位
                Map<Long, CommonSpecUnit> commonSpecUnitMap = null;
                Set<Long> specIds = dataList.stream().map(SpecUnitVo::getSpecId).collect(Collectors.toSet());
                Example example = new Example(CommonSpecUnit.class);
                Example.Criteria criteria = example.createCriteria();
                criteria.andIn(CommonSpecUnit.SPEC_ID, specIds);
                List<CommonSpecUnit> commonSpecUnits = commonSpecUnitMapper.selectByExample(example);
                if (CollectionUtils.isNotEmpty(commonSpecUnits)) {
                    commonSpecUnitMap = commonSpecUnits.stream().collect(Collectors.toMap(CommonSpecUnit::getSpecId, c -> c));
                }
                for (SpecUnitVo l : dataList) {
                    if (StringUtils.isBlank(l.getSpecUnit())) {
                        l.setSpecUnit("");
                    }
                    CommonSpecUnit commonSpecUnit = new CommonSpecUnit();
                    commonSpecUnit.setSpecId(l.getSpecId());
                    commonSpecUnit.setSpecUnit(l.getSpecUnit());
                    if (commonSpecUnitMap != null && commonSpecUnitMap.get(l.getSpecId()) != null) {
                        CommonSpecUnit oldSpecUnit = commonSpecUnitMap.get(l.getSpecId());
                        commonSpecUnit.setId(oldSpecUnit.getId());
                        if (StringUtils.isBlank(oldSpecUnit.getSpecUnit()) && StringUtils.isBlank(l.getSpecUnit())) {
                            continue;
                        }
                        if (Objects.equals(oldSpecUnit.getSpecUnit(), l.getSpecUnit())) {
                            continue;
                        }
                        update.add(commonSpecUnit);
                    } else {
                        if (StringUtils.isBlank(l.getSpecUnit())) {
                            continue;
                        }
                        insert.add(commonSpecUnit);
                    }
                }
                if (!insert.isEmpty()) {
                    this.batchInsert(insert);
                }
                if (!update.isEmpty()) {
                    this.batchUpdate(update);
                }
            }
            return new JsonResult<>(true, "导入成功");
        } catch (Exception e) {
            ZydExceptions.re("导入失败：" + e.getMessage());
        }
        return null;
    }

    /**
     * 获取规格单位
     *
     * @param specIds
     * @Author loine
     * @Date 2026/4/10 11:21
     */
    public Map<Long, CommonSpecUnit> getUnitByIds(Set<Long> specIds) {
        Map<Long, CommonSpecUnit> commonSpecUnitMap = new HashMap<>();
        Example example = new Example(CommonSpecUnit.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andIn(CommonSpecUnit.SPEC_ID, specIds);
        List<CommonSpecUnit> commonSpecUnits = commonSpecUnitMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(commonSpecUnits)) {
            commonSpecUnitMap = commonSpecUnits.stream().collect(Collectors.toMap(CommonSpecUnit::getSpecId, c -> c));
        }
        return commonSpecUnitMap;
    }
}
