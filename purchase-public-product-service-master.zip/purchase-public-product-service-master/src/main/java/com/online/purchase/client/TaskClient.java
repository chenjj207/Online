package com.online.purchase.client;

import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.CommonResponse;
import com.online.purchase.client.dto.TaskManageDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @Description: 任务中心-对外服务接口
 * @Author: czh
 * @Date: 2025-3-18 16:01:37
 **/
@FeignClient(value = "purchase-task")
public interface TaskClient {

    /**
     * 任务详情
     *
     * @return
     */
    @PostMapping("/feign/task-manage/detail")
    JSONObject taskDetail(@RequestBody JSONObject object);

    /**
     * 创建任务
     *
     * @return
     */
    @PostMapping("/feign/task-manage/create")
    CommonResponse create(@RequestBody TaskManageDTO dto);

    /**
     * 任务更新
     *
     * @return
     */
    @PostMapping("/feign/task-manage/update")
    CommonResponse taskUpdate(@RequestBody JSONObject object);

    /**
     * 更新任务
     *
     * @return
     */
    @PostMapping("/feign/task-manage/new/update")
    CommonResponse update(@RequestBody TaskManageDTO dto);
}
