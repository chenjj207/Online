package com.online.purchase.base;

import org.apache.commons.lang.StringUtils;

/**
 * @author jidonglin
 * @Description: 枚举、错误码
 * @date 2021/8/13  11:45
 */
public class PdConstants {

    public enum CommonProductOssType {

        VEDIO("VEDIO", "视频"),
        IMAGE("IMAGE", "产品主图"),
        SAMPLE("SAMPLE", "样本"),
        THREE_D("3D", "3D"),
        CONTENT("CONTENT", "产品详情介绍"),
        ;
        public final String code;
        public final String value;

        CommonProductOssType(String code, String value) {
            this.code = code;
            this.value = value;
        }

        public String getCode() {
            return code;
        }

        public String getValue() {
            return value;
        }
    }

    public enum CommonProductContent {
        CHECK_PROP_CONTENT("check_prop_content", "系列文描"),
        CHECK_SKU_CONTENT("check_sku_content", "订货号文描"),
        CHECK_ERP_CONTENT("check_erp_content", "ERP编号文描");;
        public final String code;
        public final String value;

        CommonProductContent(String code, String value) {
            this.code = code;
            this.value = value;
        }

        public String getCode() {
            return code;
        }


        public String getValue() {
            return value;
        }
    }

    public enum CommonProductImage {
        PRODCUT_PROP_IMAGE("PRODCUT_PROP_IMAGE", "产品系列图", 1),
        PROP_SUMMARY("PROP_SUMMARY", "系列概述", 2),
        CHAR_DESC("CHAR_DESC", "特性描述", 3),
        MODEL_GUIDE("MODEL_GUIDE", "选型指南", 4),
        SIZE_IMAGE("SIZE_IMAGE", "产品尺寸图", 5),
        ASSEMBLY_IMAGE("ASSEMBLY_IMAGE", "产品组装图", 6),
        ;
        public final String code;
        public final String value;
        public final int sort;

        CommonProductImage(String code, String value, int sort) {
            this.code = code;
            this.value = value;
            this.sort = sort;
        }

        public String getCode() {
            return code;
        }


        public String getValue() {
            return value;
        }

        public static int getSort(String value) {
            CommonProductImage[] commonProductImages = values();
            int sort = 0;
            for (CommonProductImage commonProductImage : commonProductImages) {
                if (StringUtils.equals(value, commonProductImage.getValue())) {
                    sort = commonProductImage.sort;
                    return sort;
                }
            }
            return sort;
        }
    }

}
