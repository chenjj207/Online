package com.online.purchase.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.mapper.CommonCatalogMapper;
import com.online.purchase.model.CommonBrand;
import com.online.purchase.model.CommonCatalog;
import com.online.purchase.model.CommonProduct;
import com.online.purchase.model.CommonSpec;
import com.online.purchase.utils.RedisUtil;
import com.online.purchase.utils.ReflectUtils;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.database.mybatis.helper.CorpHelper;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * CommonCatalogService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Service
public class CommonCatalogService extends BaseServiceImpl<CommonCatalog> {

    @Resource
    private CommonCatalogMapper commonCatalogMapper;
    @Resource
    private CommonProductService commonProductService;
    @Resource
    private CommonSpecService commonSpecService;

    @Resource
    private RedisTemplate redisTemplate;

    private static final String[] FIELD_LIST = {"cataId","cataName","level","parentCataId"};

    public List<CommonCatalog> listAll(CommonCatalog commonCatalog) {
        Example example = genConditionExample(commonCatalog);
        example.orderBy(CommonCatalog.LEVEL).desc().orderBy(CommonCatalog.SORT).asc().orderBy(CommonCatalog.CREATED_AT).asc();
        return commonCatalogMapper.selectByExample(example);
    }

    public List<CommonCatalog> listAllForTree() {
        return commonCatalogMapper.listAllForTree();
    }

    /**
     * 根据条件，返回对象列表
     * @param commonCatalog 条件
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public List<CommonCatalog> query(CommonCatalog commonCatalog) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CommonCatalog.DELETED, 0);

        String id = commonCatalog.getId();
        if (StringUtils.isNotEmpty(id)) {
            criteria.andEqualTo(CommonCatalog.ID, id);
        }

        Long cataId = commonCatalog.getCataId();
        if (null != cataId) {
            criteria.andEqualTo(CommonCatalog.CATA_ID, cataId);
        }

        Collection<Long> cataIdList = commonCatalog.getCataIdList();
        if (CollectionUtils.isNotEmpty(cataIdList)) {
            criteria.andIn(CommonCatalog.CATA_ID, cataIdList);
        }

        Collection<Long> parentCataIds = commonCatalog.getParentCataIds();
        if (CollectionUtils.isNotEmpty(parentCataIds)) {
            criteria.andIn(CommonCatalog.PARENT_CATA_ID, parentCataIds);
        }

        String cataName = commonCatalog.getCataName();
        if (StringUtils.isNotBlank(cataName)) {
            criteria.andLike(CommonCatalog.CATA_NAME, "%" + cataName + "%");
        }

        Integer level = commonCatalog.getLevel();
        if (null != level) {
            criteria.andEqualTo(CommonCatalog.LEVEL, level);
        }

        Long parentCataId = commonCatalog.getParentCataId();
        if (null != parentCataId) {
            criteria.andEqualTo(CommonCatalog.PARENT_CATA_ID, parentCataId);
        }

        Integer syncStatus = commonCatalog.getSyncStatus();
        if (null != syncStatus) {
            criteria.andEqualTo(CommonCatalog.SYNC_STATUS, syncStatus);
        }

        String source = commonCatalog.getSource();
        if (StringUtils.isNotEmpty(source)) {
            criteria.andEqualTo(CommonCatalog.SOURCE, source);
        }
        example.selectProperties(CommonCatalog.CATA_NAME);
        return commonCatalogMapper.selectByExample(example);
    }

    /**
     * 根据条件，获取对象集合树
     *
     * @param commonCatalog 条件
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public List<CommonCatalog> getTree(CommonCatalog commonCatalog) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonCatalog);
        List<CommonCatalog> list = listAllForTree();
        if (CollectionUtils.isEmpty(list)) {
            return Collections.emptyList();
        }

        int level = 1;
        return listToTree(list, level);
    }

    protected List<CommonCatalog> listToTree(List<CommonCatalog> list, int level) {
        List<CommonCatalog> tree = new LinkedList<>();
        Map<Long, List<CommonCatalog>> listMap = new HashMap<>(list.size());
        for (CommonCatalog one : list) {
            List<CommonCatalog> childList = listMap.get(one.getCataId());
            if (CollectionUtils.isNotEmpty(childList)) {
                one.setChildren(childList);
            } else if (3 != one.getLevel()) {
                one.setChildren(Collections.emptyList());
            }

            if (level != one.getLevel()) {
                List<CommonCatalog> parentList = listMap.get(one.getParentCataId());
                if (CollectionUtils.isEmpty(parentList)) {
                    parentList = new LinkedList<>();
                }

                parentList.add(one);
                listMap.put(one.getParentCataId(), parentList);
            } else {
                tree.add(one);
            }
        }

        return tree;
    }

    private Example genConditionExample(CommonCatalog model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        Boolean deleted = model.getDeleted();
        if (null != deleted) {
            criteria.andEqualTo(CommonCatalog.DELETED, deleted);
        }

        String id = model.getId();
        if (StringUtils.isNotEmpty(id)) {
            criteria.andEqualTo(CommonCatalog.ID, id);
        }

        Long cataId = model.getCataId();
        if (null != cataId) {
            criteria.andEqualTo(CommonCatalog.CATA_ID, cataId);
        }

        Collection<Long> cataIdList = model.getCataIdList();
        if (CollectionUtils.isNotEmpty(cataIdList)) {
            criteria.andIn(CommonCatalog.CATA_ID, cataIdList);
        }

        Collection<Long> parentCataIds = model.getParentCataIds();
        if (CollectionUtils.isNotEmpty(parentCataIds)) {
            criteria.andIn(CommonCatalog.PARENT_CATA_ID, parentCataIds);
        }

        String cataName = model.getCataName();
        if (StringUtils.isNotBlank(cataName)) {
            criteria.andEqualTo(CommonCatalog.CATA_NAME, cataName);
        }

        Integer level = model.getLevel();
        if (null != level) {
            criteria.andEqualTo(CommonCatalog.LEVEL, level);
        }

        Long parentCataId = model.getParentCataId();
        if (null != parentCataId) {
            criteria.andEqualTo(CommonCatalog.PARENT_CATA_ID, parentCataId);
        }

        Integer syncStatus = model.getSyncStatus();
        if (null != syncStatus) {
            criteria.andEqualTo(CommonCatalog.SYNC_STATUS, syncStatus);
        }

        String source = model.getSource();
        if (StringUtils.isNotEmpty(source)) {
            criteria.andEqualTo(CommonCatalog.SOURCE, source);
        }

        return example;
    }

    /**
     * 通过id获取详情
     */
    @Override
    public CommonCatalog get(String id) {
        return super.get(id);
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(CommonCatalog commonCatalog) {
        Assert.notNull(commonCatalog, "commonCatalog can not be null");
        Example example = genConditionExample(commonCatalog);
        example.selectProperties(CommonCatalog.ID);
        List<CommonCatalog> commonCatalogList = commonCatalogMapper.selectByExample(example);
        return CollectionUtils.isEmpty(commonCatalogList) ? new ArrayList<>(0) :
                commonCatalogList.stream().map(CommonCatalog::getId).collect(Collectors.toList());
    }

    /**
     * 新增
     *
     * @param commonCatalog 入参
     * @return 主键id
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String add(CommonCatalog commonCatalog, String source) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonCatalog)
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonCatalog.getCataName());
        Long parentCataId = commonCatalog.getParentCataId();
        if (null != parentCataId && 0L != parentCataId) {
            // 上级是否合法
            CommonCatalog parent = getByExample(new CommonCatalog().setDeleted(false).setCataId(parentCataId));
            if (null == parent) {
                throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
            }

            // 最多3级
            if (2 < parent.getLevel()) {
                throw new BaseException(PuPrErrorCode.COMMON_CATA_MAX_LEVEL_ERROR);
            }

            commonCatalog.setCataIds(parent.getCataIds());
        }

        parentCataId = null == parentCataId ? 0L : parentCataId;
        commonCatalog.setParentCataId(parentCataId);
        // 同级名称重复校验
        validateCataName(commonCatalog.getCataName(), parentCataId);



        // 新增
        Long cataId = commonCatalog.getCataId();
        if (!PuPrConstants.EDIT.equals(source)) {
            cataId = genCataId();
            Integer maxSortByParentId = commonCatalogMapper.getMaxSortByParentId(parentCataId);
            Integer maxSort = commonCatalog.getSort() == null ? (maxSortByParentId == null ? 0 :  maxSortByParentId)  + 1 : commonCatalog.getSort();
            commonCatalog.setCataId(cataId);
            commonCatalog.setIsValid(PuPrConstants.IS_VALID_Y);
            commonCatalog.setSort(maxSort);
            // TODO: 2022/8/10 其他字段维护
        }

        String parentCataIds = commonCatalog.getCataIds();
        parentCataIds = StringUtils.isEmpty(parentCataIds) ? "" : parentCataIds;
        String cataIds = parentCataIds + cataId + ",";
        commonCatalog.setCataIds(cataIds);
        commonCatalog.setLevel(cataIds.split(",").length);
        commonCatalog.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        commonCatalog.setIsShowProp("Y");
        return super.insert(commonCatalog);
    }

    /**
     * 同级名称重复校验
     *
     * @param cataName     名称
     * @param parentCataId 父类编号
     */
    private void validateCataName(String cataName, Long parentCataId) {
        Integer level;
        if (null == parentCataId || 0L == parentCataId) {
            level = 1;
        } else {
            CommonCatalog parent = getByExample(new CommonCatalog().setDeleted(false).setCataId(parentCataId));
            if (null == parent) {
                throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
            }

            level = parent.getLevel() + 1;
        }

        List<String> idList = listIdsByExample(new CommonCatalog().setCataName(cataName).setDeleted(false).setLevel(level));
        if (CollectionUtils.isEmpty(idList)) {
            return;
        }

        throw new BaseException(PuPrErrorCode.COMMON_CATA_NAME_ERROR);
    }

    /**
     * 根据条件，获取对象
     *
     * @param catalog 条件
     * @return 对象
     */
    @Transactional(readOnly = true)
    public CommonCatalog getByExample(CommonCatalog catalog) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(catalog);
        Example example = genConditionExample(catalog);
        CorpHelper.skipCorpCode(true);
        return commonCatalogMapper.selectOneByExample(example);
    }

    /**
     * 生成分类编号
     *
     * @return 编号
     */
    private Long genCataId() {
        return RedisUtil.genCode("common_catalog_id", redisTemplate, () -> {
            return commonCatalogMapper.getMaxCataId();
        });
    }

    /**
     * 修改，标记删除后新增
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void edit(CommonCatalog commonCatalog) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonCatalog)
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonCatalog.getCataName())
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonCatalog.getId())
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonCatalog.getParentCataId());
        CommonCatalog param = new CommonCatalog();
        param.setDeleted(false).setId(commonCatalog.getId());
        CommonCatalog catalog = getByExample(param);
        if (null == catalog) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }

        Boolean hasEdit = ReflectUtils.hasEdit(catalog, commonCatalog, FIELD_LIST, this.entityClass);

        if (BooleanUtils.isTrue(hasEdit)) {
            // 同级更换上级分类校验
            Long parentCataId = commonCatalog.getParentCataId();
            Long oldParentCataId = catalog.getParentCataId();
            if (!oldParentCataId.equals(parentCataId)) {
                if (0L == parentCataId) {
                    throw new BaseException(PuPrErrorCode.COMMON_CATA_HIERARCHY_ERROR);
                }

                CommonCatalog parent = getByExample(new CommonCatalog().setCataId(parentCataId).setDeleted(false));
                if (null == parent) {
                    throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
                }

                if (parent.getParentCataId().equals(oldParentCataId)) {
                    throw new BaseException(PuPrErrorCode.COMMON_CATA_HIERARCHY_ERROR);
                }

                if (((catalog.getLevel() - 1) != (parent.getLevel()))) {
                    throw new BaseException(PuPrErrorCode.COMMON_CATA_HIERARCHY_ERROR);
                }
            }

            // 标记删除
            param.setDeleted(true);
            param.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
            super.update(param);
            // 新增
            commonCatalog.setId(null);
            commonCatalog.setCreatedAt(null);
            commonCatalog.setCreatedBy(null);
            commonCatalog.setUpdatedAt(null);
            commonCatalog.setUpdatedBy(null);
            commonCatalog.setIsValid(catalog.getIsValid());
            commonCatalog.setAttachCataId(catalog.getAttachCataId());
            commonCatalog.setIsShowProp(catalog.getIsShowProp());
            commonCatalog.setRemark(catalog.getRemark());
            Long cataId = genCataId();
            commonCatalog.setCataId(cataId);
            commonCatalog.setSource(catalog.getSource());
            CommonCatalog newCatalog = get(add(commonCatalog, PuPrConstants.EDIT));
            // 维护所有子类别parentCataId cataIds
            Integer level = catalog.getLevel();
            dealChildCata(catalog, cataId, newCatalog, level);
            // 关联关系-规格
            commonSpecService.batchUpdateCataId(catalog.getCataId(), cataId);
            // 关联关系-商品
            commonProductService.batchUpdateCataId(catalog.getCataId(), cataId);
        } else {
            this.update(commonCatalog);
        }

    }

    private void dealChildCata(CommonCatalog catalog, Long cataId, CommonCatalog newCatalog, Integer level) {
        if (2 < level) {
            return;
        }
        // 1 level = 1 修改1
        // 2 level = 2 修改2的父级
        // 3 level = 2 不修改2的父级，只修改本身
        // 所有子孙类别
        List<CommonCatalog> childList = listChildByCataId(catalog.getCataId());
        if (CollectionUtils.isEmpty(childList)) {
            return;
        }

        List<CommonCatalog> list = new ArrayList<>(childList.size());
        CommonCatalog c;
        if (1 == level) {
            // 1 level = 1 修改1
            for (CommonCatalog log : childList) {
                c = new CommonCatalog();
                c.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
                c.setId(log.getId());
                c.setCataIds(log.getCataIds().replace(catalog.getCataId().toString(), cataId.toString()));
                if (log.getLevel() == 2) {
                    c.setParentCataId(cataId);
                }
                list.add(c);
            }

        } else if (2 == level && newCatalog.getParentCataId().equals(catalog.getParentCataId())) {
            // 3 level = 2 不修改2的父级，只修改本身
            for (CommonCatalog log : childList) {
                c = new CommonCatalog();
                c.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
                c.setId(log.getId());
                c.setCataIds(log.getCataIds().replace(catalog.getCataId().toString(), cataId.toString()));
                c.setParentCataId(cataId);
                list.add(c);
            }
        } else if (2 == level) {
            // 2 level = 2 修改2的父级
            for (CommonCatalog log : childList) {
                c = new CommonCatalog();
                c.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
                c.setId(log.getId());
                c.setCataIds(log.getCataIds().replace(catalog.getCataIds(), newCatalog.getCataIds()));
                c.setParentCataId(cataId);
                list.add(c);
            }
        }

        if (CollectionUtils.isEmpty(list)) {
            return;
        }

        batchUpdate(list);
    }

    /**
     * 根据父类编号，获取所有子类
     *
     * @param cataId 父类编号
     * @param properties 返回字段
     * @return 子类
     */
    @Transactional(readOnly = true)
    public List<CommonCatalog> listChildByCataId(Long cataId, String... properties) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(cataId);
        CommonCatalog catalog = getByExample(new CommonCatalog().setCataId(cataId));
        if (null == catalog) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }

        List<CommonCatalog> resList = Lists.newArrayList();
        Integer level = catalog.getLevel();
        if (null == level || 3 == level) {
            return resList;
        }

        if (2 == level) {
            return listByCondition(new CommonCatalog().setDeleted(false).setParentCataId(cataId), properties);
        }

        if (1 == level) {
            // 2级
            List<CommonCatalog> catalogList2 = listByCondition(new CommonCatalog().setDeleted(false).setParentCataId(cataId), properties);
            if (CollectionUtils.isEmpty(catalogList2)) {
                return catalogList2;
            }

            // 3级
            List<CommonCatalog> cataId3 = listByCondition(new CommonCatalog().setDeleted(false).setParentCataIds(
                    catalogList2.stream().map(CommonCatalog::getCataId).collect(Collectors.toSet())), properties);
            catalogList2.addAll(cataId3);
            return catalogList2;
        }

        return resList;
    }

    /**
     * 标记删除
     *
     * @param id 主键
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void deleteById(String id) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(id);
        CommonCatalog param = new CommonCatalog();
        param.setDeleted(false).setId(id);
        CommonCatalog catalog = getByExample(param);
        if (null == catalog) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }

        // 子分类关联校验
        param.setId(null);
        Long cataId = catalog.getCataId();
        param.setParentCataId(cataId);
        List<String> childIdList = listIdsByExample(param);
        if (CollectionUtils.isNotEmpty(childIdList)) {
            throw new BaseException(PuPrErrorCode.COMMON_CATA_EXIST_CHILD_ERROR);
        }

        // 慧采商品关联校验
        List<String> productIdList = commonProductService.listIdsByExample(new CommonProduct().setCataId(cataId));
        if (CollectionUtils.isNotEmpty(productIdList)) {
            throw new BaseException(PuPrErrorCode.COMMON_CATA_EXIST_PRODUCT_ERROR);
        }

        // 商品规格关联校验
        List<String> specIdList = commonSpecService.listIdsByExample(new CommonSpec().setCataId(cataId).setDeleted(false));
        if (CollectionUtils.isNotEmpty(specIdList)) {
            throw new BaseException(PuPrErrorCode.COMMON_CATA_EXIST_SPEC_ERROR);
        }

        CommonCatalog del = new CommonCatalog();
        del.setDeleted(true).setId(id);
        del.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        update(del);
    }

    public Long syncCataLog(String catalogName, Long pCataId, Integer level, String cataIds, String isShowProp, String productSrc) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CommonCatalog.LEVEL, level);
        criteria.andEqualTo(CommonCatalog.PARENT_CATA_ID, pCataId);
        criteria.andEqualTo(CommonCatalog.CATA_NAME, catalogName);
        criteria.andEqualTo(CommonCatalog.DELETED, false);
        List<CommonCatalog> catalogs = commonCatalogMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(catalogs)) {
            return catalogs.get(0).getCataId();
        }
        CommonCatalog commonCatalog = new CommonCatalog();
        Long cataId = genCataId();
        commonCatalog.setCataId(cataId);
        commonCatalog.setCataIds(cataIds+cataId+",");
        commonCatalog.setParentCataId(pCataId);
        commonCatalog.setCataName(catalogName);
        Integer maxSortByParentId = commonCatalogMapper.getMaxSortByParentId(pCataId);
        if (maxSortByParentId == null){
            maxSortByParentId = 0;
        }
        commonCatalog.setSort(maxSortByParentId +1);
        commonCatalog.setSource(StringUtils.equalsIgnoreCase(productSrc, "ZYDMALL") ? "zydmall" : PuPrConstants.DATA_SOURCE_APPLY);
        commonCatalog.setLevel(level);
        commonCatalog.setIsValid(PuPrConstants.IS_VALID_Y);
        commonCatalog.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        if (StringUtils.equalsIgnoreCase(productSrc, "ZYDMALL")){
            commonCatalog.setIsShowProp(isShowProp);
        }else {
            commonCatalog.setIsShowProp("Y");
        }
        super.insert(commonCatalog);
        return cataId;
    }

    /**
     * 根据编号，获取编号名称路径map
     *
     * @param cataIdSet 编号
     * @return 编号名称路径map
     */
    @Transactional(readOnly = true)
    public Map<Long, Map<Integer, String>> mapNameByCataIds(Set<Long> cataIdSet) {
        Map<Long, Map<Integer, String>> resMap = Maps.newHashMap();
        if (CollectionUtils.isEmpty(cataIdSet)) {
            return resMap;
        }

        List<CommonCatalog> list = listByCondition(new CommonCatalog().setCataIdList(cataIdSet));
        if (CollectionUtils.isEmpty(list)) {
            return resMap;
        }

        // 路径集合
        Set<String> cataIdsSet = list.stream().map(CommonCatalog::getCataIds).filter(Objects::nonNull).collect(Collectors.toSet());
        Set<Long> allCataIds = new HashSet<>();
        for (String cataIds : cataIdsSet) {
            for (String cataId : cataIds.split(",")) {
                allCataIds.add(Long.valueOf(cataId));
            }
        }

        List<CommonCatalog> allCatalogList = listByCondition(new CommonCatalog().setCataIdList(allCataIds));
        Map<Long, String> allNameMap = allCatalogList.stream().collect(Collectors.toMap(CommonCatalog::getCataId, CommonCatalog::getCataName));
        for (CommonCatalog catalog : list) {
            Map<Integer, String> levelMap = Maps.newHashMap();
            String cataIds = catalog.getCataIds();
            if (null != cataIds) {
                String[] cataIdArray = cataIds.split(",");
                for (int i = 0; i < cataIdArray.length; i++) {
                    levelMap.put(i + 1, allNameMap.get(Long.valueOf(cataIdArray[i])));
                }
            }

            resMap.put(catalog.getCataId(), levelMap);
        }

        return resMap;
    }

    /**
     * 根据条件，获取对象集合
     *
     * @param catalog 条件
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public List<CommonCatalog> listByCondition(CommonCatalog catalog, String... properties) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(catalog);
        Example example = genConditionExample(catalog);
        example.selectProperties(properties);
        return commonCatalogMapper.selectByExample(example);
    }

    /**
     * 获取侍标记删除数据-用于定时任务
     *
     * @return 主键集合
     */
    @Transactional(readOnly = true)
    public Set<String> listIdsToDel() {
        Set<CommonCatalog> catalogs = commonCatalogMapper.listIdsToDel();
        if (CollectionUtils.isEmpty(catalogs)) {
            return Collections.emptySet();
        }

        // 所有供应链分类
        List<CommonCatalog> gylCatalogList = listByCondition(
                new CommonCatalog().setDeleted(false).setSource(PuPrConstants.DATA_SOURCE), CommonCatalog.CATA_IDS);
        if (CollectionUtils.isEmpty(gylCatalogList)) {
            return catalogs.stream().map(CommonCatalog::getId).collect(Collectors.toSet());
        }

        Set<String> excludeCataIds = Sets.newHashSet();
        String cataIds;
        for (CommonCatalog catalog : gylCatalogList) {
            cataIds = catalog.getCataIds();
            if (StringUtils.isEmpty(cataIds)) {
                continue;
            }

            String[] cataIdArray = cataIds.split(",");
            excludeCataIds.addAll(Sets.newHashSet(cataIdArray));
        }

        // 去除供应链的父类
        return catalogs.stream().filter(c -> !excludeCataIds.contains(c.getCataId().toString())).map(CommonCatalog::getId).collect(Collectors.toSet());
    }

    public String checkCata(String firstLevelCataName, String secondLevelCataName, String threeLevelCataName) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CommonCatalog.LEVEL, 1);
        criteria.andEqualTo(CommonCatalog.CATA_NAME, firstLevelCataName);
        criteria.andEqualTo(CommonCatalog.DELETED, false);
        List<CommonCatalog> catalogs = commonCatalogMapper.selectByExample(example);
        Long pCataId = null;
        if (CollectionUtils.isNotEmpty(catalogs)) {
            pCataId = catalogs.get(0).getCataId();
        }
        example = new Example(entityClass);
        criteria = example.createCriteria();
        criteria.andEqualTo(CommonCatalog.LEVEL, 2);
        criteria.andEqualTo(CommonCatalog.CATA_NAME, secondLevelCataName);
        criteria.andEqualTo(CommonCatalog.DELETED, false);
        catalogs = commonCatalogMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(catalogs)) {
            for (CommonCatalog commonCatalog:catalogs) {
                if (pCataId != null && pCataId.longValue() != commonCatalog.getParentCataId().longValue()) {
                    return "该二级分类已存在、请重新申请！";
                }
            }
            pCataId = catalogs.get(0).getCataId();
        } else {
            pCataId = null;
        }
        example = new Example(entityClass);
        criteria = example.createCriteria();
        criteria.andEqualTo(CommonCatalog.LEVEL, 3);
        criteria.andEqualTo(CommonCatalog.CATA_NAME, threeLevelCataName);
        criteria.andEqualTo(CommonCatalog.DELETED, false);
        catalogs = commonCatalogMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(catalogs)) {
            for (CommonCatalog commonCatalog:catalogs) {
                if (pCataId != null && pCataId.longValue() != commonCatalog.getParentCataId().longValue()) {
                    return "该三级分类已存在、请重新申请！";
                }
            }
        }
        return null;
    }

    /**
     * 根据编号查询对象
     *
     * @param catalog 编号条件
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public List<CommonCatalog> selectByCataIds(CommonCatalog catalog) {
        return commonCatalogMapper.selectByCataIds(catalog);
    }

    /**
     * 根据父类编号，获取所有子类编号
     *
     * @param cataId 父类编号
     * @return 子类编号
     */
    public Set<Long> listChildIdByCataId(Long cataId) {
        List<CommonCatalog> catalogList = listChildByCataId(cataId, CommonCatalog.CATA_ID);
        if (CollectionUtils.isEmpty(catalogList)) {
            return Sets.newHashSet();
        }

        return catalogList.stream().map(CommonCatalog::getCataId).collect(Collectors.toSet());
    }

    /**
     * 校验分类名称是否重复
     * @param commonCatalog
     * @return
     */
    public Boolean checkCataName(CommonCatalog commonCatalog) {
        if (null == commonCatalog
                || StringUtils.isBlank(commonCatalog.getCataName())
                || (null == commonCatalog.getLevel())) {
            return true;
        }
        String cataName = commonCatalog.getCataName();
        Integer level = commonCatalog.getLevel();
        List<String> idList = listIdsByExample(new CommonCatalog().setCataName(cataName).setDeleted(false).setLevel(level));
        if (CollectionUtils.isNotEmpty(idList)) {
            return false;
        }
        return true;
    }

    public List<CommonCatalog> listByCataIds(Set<Long> cataIds) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andIn(CommonCatalog.CATA_ID, cataIds);
        return commonCatalogMapper.selectByExample(example);
    }
}
