package com.online.purchase.controller.preview;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 门户 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-09-01 15:21:57
 */
@Data
public class DisplaySettingDTO {

    @ApiModelProperty(value = "主题色")
    private String themeColor;

    @ApiModelProperty(value = "公司全称")
    private String companyName;

    @ApiModelProperty(value = "门户名称")
    private String name;

    @ApiModelProperty(value = "门户logo")
    private String logo;

    @ApiModelProperty(value = "浏览器标题logo")
    private String browserLogo;

    @ApiModelProperty(value = "版权所有")
    private String copyright;

    @ApiModelProperty(value = "客服热线")
    private String customerServiceHotLine;

    @ApiModelProperty(value = "公司地址")
    private String address;

    @ApiModelProperty(value = "邮箱地址")
    private String email;

    @ApiModelProperty(value = "公众号二维码")
    private String officialAccountQrCode;

    @ApiModelProperty(value = "描述")
    private String description;

    @ApiModelProperty(value = "是否删除")
    private Boolean deleted;

    @ApiModelProperty(value = "logoUrl")
    private String logoUrl;

    @ApiModelProperty(value = "浏览器标题logoUrl")
    private String browserLogoUrl;

    @ApiModelProperty(value = "公众号二维码Url")
    private String officialAccountQrCodeUrl;

    @ApiModelProperty(value = "营业时间")
    private String businessTime;
}
