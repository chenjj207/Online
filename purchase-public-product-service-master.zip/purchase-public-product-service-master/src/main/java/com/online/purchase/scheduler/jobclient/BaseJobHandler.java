package com.online.purchase.scheduler.jobclient;

import com.github.ltsopensource.core.domain.Job;

import java.util.Map;

/**
 * 任务处理器
 *
 * @author zhangcheng
 * @since 2022-08-18
 */
public interface BaseJobHandler {

    void customJob(Job job, Map<String, String> paramMap);

}
