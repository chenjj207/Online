package com.online.purchase.scheduler.tasktracker;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.github.pagehelper.PageHelper;
import com.online.purchase.base.JobConstant;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.mapper.CommonProductMapper;
import com.online.purchase.model.CommonProduct;
import com.online.purchase.model.dto.CommonProductChangeDto;
import com.online.purchase.service.CommonProductService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 公海产品变更通知
 *
 * @author zhangcheng
 * @since 2022-08-18
 */
@Component("productChangeNoticeActuator")
@Slf4j
public class ProductChangeNoticeActuator implements BaseJobRunnerActuator {

    @Resource
    private CommonProductService commonProductService;
    @Value("${zydonline.product.change.noticeUrl:}")
    private String noticeUrl;

    @Resource
    private CommonProductMapper commonProductMapper;

    @Override
    public Result run(JobContext jobContext) {
        log.info("公海产品变更通知开始 ==> " + LocalDateTime.now());
        // 同步数据
        dealData();
        log.info("公海产品变更通知结束 ==> " + LocalDateTime.now());
        return new Result(Action.EXECUTE_SUCCESS, StringUtils.EMPTY);
    }

    private void dealData() {
        // 待同步产品
        while (true){
            try {
                int limit = 2000;
                List<CommonProduct> commonProducts = commonProductMapper.selectIdsByWaitSync(limit);
                if (CollectionUtils.isEmpty(commonProducts)){
                    break;
                }
                List<CommonProductChangeDto> changeList = new ArrayList<>(commonProducts.size());
                CommonProductChangeDto dto;
                for (CommonProduct commonProduct : commonProducts) {
                    dto = new CommonProductChangeDto();
                    dto.setProductId(commonProduct.getProductId());
                    changeList.add(dto);
                }
                // 通知租户
                if (!noticeTenant(changeList)) {
                    return;
                }
                // 处理同步结果
                dealSyncResult(commonProducts);
            }catch (Exception e){
                log.error("公海产品变更异常通知：" + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private boolean noticeTenant(List<CommonProductChangeDto> list) {
        try {
            String paramStr = JSONUtil.toJsonStr(list);
            log.info("公海产品变更通知入参:url[{}]，参数[{}]", noticeUrl, paramStr);
            String resStr = HttpUtil.post(noticeUrl, paramStr, 20000);
            log.info("公海产品变更通知出参:[{}]", resStr);
            JsonResult res = JSONUtil.toBean(resStr, JsonResult.class);
            if (null == res || !res.isSuccess()) {
                return false;
            }
        } catch (Exception e) {
            log.error("公海产品变更通知ERROR:[{}]", e.getMessage());
            return false;
        }

        return true;
    }

    private void dealSyncResult(List<CommonProduct> list) {
        List<CommonProduct> updateList = new ArrayList<>();
        CommonProduct updateProduct;
        for (CommonProduct product : list) {
            updateProduct = new CommonProduct();
            updateProduct.setUpdatedBy(JobConstant.PRODUCT_NOTICE);
            updateProduct.setId(product.getId());
            updateProduct.setSyncStatus(PuPrConstants.PRODUCT_SYNCED);
            updateList.add(updateProduct);
        }

        commonProductService.batchUpdate(updateList);
    }
}
