package com.online.purchase.scheduler.jobclient;

import com.github.ltsopensource.core.domain.Job;
import com.online.purchase.base.JobConstant;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 公海产品结构变更通知任务
 *
 * @author lwl
 */
@Component("productStructureNoticeJobHandler")
public class ProductStructureNoticeJobHandler implements BaseJobHandler {

    @Override
    public void customJob(Job job, Map<String, String> paramMap) {
        job.setCronExpression(paramMap.get(JobConstant.CRON_EXPRESSION_KEY));
        String triggerTime = paramMap.get(JobConstant.TASK_TRIGGER_TIME_KEY);
        if (StringUtils.isNotEmpty(triggerTime)) {
            job.setTriggerTime(Long.valueOf(triggerTime));
        }
    }

}
