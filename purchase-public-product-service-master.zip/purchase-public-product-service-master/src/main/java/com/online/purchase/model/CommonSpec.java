package com.online.purchase.model;

import com.purchase.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Collection;
import java.util.List;

/**
 * 规格名 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Getter
@Setter
@ToString
@Accessors(chain = true)
@ApiModel(value = "CommonSpec", description = "规格名")
@Table(name = "online_common.t_pd_common_spec")
public class CommonSpec extends PageBean<CommonSpec> {

    public static final String CATA_ID = "cataId";
    public static final String SPEC_ID = "specId";
    public static final String SPEC_NAME = "specName";
    public static final String SORT = "sort";
    public static final String IS_VALID = "isValid";
    public static final String REMARK = "remark";
    public static final String DELETED = "deleted";
    public static final String SOURCE = "source";
    public static final String SYNC_STATUS = "syncStatus";

    /**
     * 分类ID
     */
    @ApiModelProperty(value = "分类ID")
    private Long cataId;

    /**
     * 规格编码
     */
    @ApiModelProperty(value = "规格编码")
    private Long specId;

    /**
     * 规格名称
     */
    @ApiModelProperty(value = "规格名称")
    private String specName;

    /**
     * 同个三级分类下规格的排序
     */
    @ApiModelProperty(value = "同个三级分类下规格的排序")
    private Integer sort;

    /**
     * 是否有效 Y：是 N：否
     */
    @ApiModelProperty(value = "是否有效 Y：是 N：否")
    private String isValid;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 标记删除
     */
    private Boolean deleted;

    /**
     * 数据来源
     */
    private String source;

    /**
     * 通知租户状态（1：等待通知，2：已通知）
     */
    @ApiModelProperty(value = "通知租户状态（1：等待通知，2：已通知）")
    private Integer syncStatus;

    /**
     * 关键字
     */
    @Transient
    private String keywords;

    /**
     * 关联分类
     */
    @Transient
    private CommonCatalog commonCatalog;

    /**
     * 规格值
     */
    @Transient
    private List<CommonSpecVal> specValList;

    /**
     * 分类编号集合
     */
    @Transient
    private Collection<Long> cataIds;

    /**
     * 批量参数
     */
    @Transient
    private String text;

    /**
     * 规格参数标准计量单位
     */
    @Transient
    private String specUnit;
}
