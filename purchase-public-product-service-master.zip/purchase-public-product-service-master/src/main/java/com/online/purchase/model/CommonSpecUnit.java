package com.online.purchase.model;

import com.purchase.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Collection;
import java.util.List;

/**
 * 规格参数标准计量单位 model
 *
 * @author auto
 * @version 1.0
 * @since 2026-01-06 09:45:02
 */
@Getter
@Setter
@ToString
@Accessors(chain = true)
@ApiModel(value = "CommonSpecUnit", description = "规格参数标准计量单位")
@Table(name = "online_common.t_pd_common_spec_unit")
public class CommonSpecUnit extends PageBean<CommonSpecUnit> {

    public static final String SPEC_ID = "specId";
    public static final String SPEC_UNIT = "specUnit";

    /**
     * 规格编码
     */
    @ApiModelProperty(value = "规格编码")
    private Long specId;

    /**
     * 规格参数标准计量单位
     */
    @ApiModelProperty(value = "规格参数标准计量单位")
    private String specUnit;

}
