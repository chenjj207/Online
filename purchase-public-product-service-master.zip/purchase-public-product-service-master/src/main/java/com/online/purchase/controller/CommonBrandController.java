package com.online.purchase.controller;

import cn.hutool.core.map.MapUtil;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.model.CommonBrand;
import com.online.purchase.service.CommonBrandService;
import com.online.purchase.service.CommonCataBrandPropService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * CommonBrandController 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@RestController
@RequestMapping(value = "/common-brand")
@Api(value = "CommonBrandController", tags = {"公海品牌"})
public class CommonBrandController {

    @Resource
    private CommonBrandService commonBrandService;

    @PostMapping(value = "/page")
    @ApiOperation(value = "获取未标记删除品牌分页")
    public JsonResult<Page<CommonBrand>> search(@RequestBody CommonBrand commonBrand) {
        commonBrand.setDeleted(false);
        Page<CommonBrand> page = commonBrand.getPage();
        page = null == page ? new Page<>() : page;
        page = commonBrandService.search(commonBrand, page);
        return new JsonResult<>(true, "查询成功", page);
    }

    @PostMapping(value = "/list")
    @ApiOperation(value = "获取所有未标记删除数据")
    public JsonResult<List<CommonBrand>> listAll() {
        return new JsonResult<>(true, "查询成功", commonBrandService.listAll(new CommonBrand().setDeleted(false)));
    }

    @PostMapping(value = "/detail")
    @ApiOperation(value = "根据id获取数据")
    public JsonResult<CommonBrand> getCommonBrand(@RequestBody @Check(field = {"id"}) CommonBrand commonBrand) {
        return new JsonResult<>(true, "查询成功", commonBrandService.get(commonBrand.getId()));
    }

    @PostMapping("/add")
    @ApiOperation(value = "供应链新增接口")
    public JsonResult<Map<String, String>> addCommonBrand(@RequestBody CommonBrand commonBrand) {
        commonBrand.setSource(PuPrConstants.DATA_SOURCE);
        String id = commonBrandService.add(commonBrand, null);
        Map<String, String> data = MapUtil.newHashMap(1);
        data.put("id", id);
        return new JsonResult<>(true, "添加成功", data);
    }

    @PostMapping("/update")
    @ApiOperation(value = "编辑接口")
    public JsonResult editCommonBrand(@RequestBody @Check(field = {"id"}) CommonBrand commonBrand) {
        commonBrandService.edit(commonBrand);
        return new JsonResult(true, "编辑成功");
    }

    @PostMapping(value = "/del")
    @ApiOperation(value = "根据传入的Id，删除数据")
    public JsonResult<String> delete(@RequestBody @Check(field = {"id"}) CommonBrand commonBrand) {
        commonBrandService.deleteById(commonBrand.getId());
        return new JsonResult<>(true, "删除成功");
    }
}
