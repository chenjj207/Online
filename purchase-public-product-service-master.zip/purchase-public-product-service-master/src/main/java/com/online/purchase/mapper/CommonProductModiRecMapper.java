package com.online.purchase.mapper;

import com.online.purchase.model.CommonProductModiRec;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CommonProductModiRecMapper extends QguBaseMapper<CommonProductModiRec> {

    List<CommonProductModiRec> selectByNotSend();

    Integer updateSendStatusById(@Param("ids")  List<String> ids);
}
