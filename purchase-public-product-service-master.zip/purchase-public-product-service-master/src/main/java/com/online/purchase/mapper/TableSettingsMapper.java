package com.online.purchase.mapper;

import com.online.purchase.model.TableSettings;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

@Mapper
public interface TableSettingsMapper extends BaseMapper<TableSettings> {

    TableSettings fndOne(@Param("param") TableSettings param);

}
