package com.online.purchase.utils;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import java.util.ArrayList;
import java.util.List;

// 定义一个泛型监听器，T 表示 Excel 数据对应的实体类类型
public class GenericDataListener<T> extends AnalysisEventListener<T> {
    // 用于存储读取到的数据
    private List<T> dataList = new ArrayList<>();

    // 每读取一行数据时调用
    @Override
    public void invoke(T data, AnalysisContext context) {
        dataList.add(data);
    }

    // 读取完成后调用
    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        System.out.println("数据读取完成，共读取 " + dataList.size() + " 条记录。");
    }

    // 获取读取到的数据
    public List<T> getDataList() {
        return dataList;
    }
}