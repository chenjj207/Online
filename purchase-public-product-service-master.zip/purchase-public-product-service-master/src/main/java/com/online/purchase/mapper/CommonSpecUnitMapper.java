package com.online.purchase.mapper;

import com.online.purchase.model.CommonSpecUnit;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 * @author auto
 * @version 1.0
 * @since 2026-01-06 09:45:02
 */
public interface CommonSpecUnitMapper extends QguBaseMapper<CommonSpecUnit> {

}
