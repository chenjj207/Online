package com.online.purchase.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.purchase.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * 公海_产品变更商城记录表
 */
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
@ApiModel(value = "CommonProductMallRec", description = "公海_产品变更商城记录表")
@Table(name = "online_common.t_pd_common_product_mall_rec")
public class CommonProductMallRec extends PageBean<CommonProductMallRec> {
    @ApiModelProperty(value = "类型:1-新增,2-修改")
    private Long type;
    @ApiModelProperty(value = "SCM产品ID")
    private Long scmProductId;
    @ApiModelProperty(value = "商城产品ID")
    private Long mallProductId;
    @ApiModelProperty(value = "ERP产品编码")
    private String erpProductCode;
    @ApiModelProperty(value = "分类id")
    private Long cataId;
    @ApiModelProperty(value = "品牌id")
    private Long brandId;
    @ApiModelProperty(value = "系列id")
    private Long propId;
    @ApiModelProperty(value = "一级分类")
    private String cataNameOne;
    @ApiModelProperty(value = "二级分类")
    private String cataNameTwo;
    @ApiModelProperty(value = "三级分类")
    private String cataNameThree;
    @ApiModelProperty(value = "品牌")
    private String brandName;
    @ApiModelProperty(value = "系列")
    private String propName;
    @ApiModelProperty(value = "规格名,多个以@分开")
    private String specName;
    @ApiModelProperty(value = "规格值,多个以@分开")
    private String specValue;
    @ApiModelProperty(value = "产品主图")
    private String productPicName;
    @ApiModelProperty(value = "产品视频")
    private String productVedioName;
    @ApiModelProperty("产品详情图")
    private String productContent;
    @ApiModelProperty("产品样本")
    private String productSimpleName;
    @ApiModelProperty("重量")
    private String weight;
    @ApiModelProperty("是否发送：0-未发送，1-已发送")
    private Integer sendStatus = 0;
}
