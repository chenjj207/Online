package com.online.purchase.model;

import com.alibaba.excel.annotation.ExcelProperty;
import com.purchase.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.Accessors;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;

/**
 * 公海_产品变更记录表
 */
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
@ApiModel(value = "CommonProductModiRec", description = "公海_产品变更记录表")
@Table(name = "online_common.t_pd_common_product_modi_rec")
public class CommonProductModiRec extends PageBean<CommonProductModiRec> {
    @ApiModelProperty("所属子公司")
    private String subCompany;

    @ApiModelProperty("供应商名称")
    private String supplierName;

    @ApiModelProperty("产品编码（SCM 商品 ID）")
    private Long productId;

    @ApiModelProperty("erp 产品编码")
    private String erpProductCode;

    @ApiModelProperty("产品型号")
    private String productType;

    @ApiModelProperty("产品型号（变更前）")
    private String productTypeOld;

    @ApiModelProperty("产品型号（变更后）")
    private String productTypeNew;

    @ApiModelProperty("产品货号（厂家物料号）（变更前）")
    private String skuCodeOld;

    @ApiModelProperty("产品货号（厂家物料号）（变更后）")
    private String skuCodeNew;

    @ApiModelProperty("库存（变更前）")
    private Integer stockOld;

    @ApiModelProperty("库存（变更后）")
    private Integer stockNew;

    @ApiModelProperty("货期（变更前）")
    private String deliveryDateOld;

    @ApiModelProperty("货期（变更后）")
    private String deliveryDateNew;

    @ApiModelProperty("计量单位（变更前）")
    private String unitOld;

    @ApiModelProperty("计量单位（变更后）")
    private String unitNew;

    @ApiModelProperty("面价（变更前）")
    private BigDecimal priceOld;

    @ApiModelProperty("面价（变更后）")
    private BigDecimal priceNew;

    @ApiModelProperty("供货价（变更前）")
    private BigDecimal supplyPriceOld;

    @ApiModelProperty("供货价（变更后）")
    private BigDecimal supplyPriceNew;

    @ApiModelProperty("建议零售价（变更前）")
    private BigDecimal suggestPriceOld;

    @ApiModelProperty("建议零售价（变更后）")
    private BigDecimal suggestPriceNew;

    @ApiModelProperty("最小起订量（变更前）")
    private Integer minimunRequireOld;
    @ApiModelProperty("最小起订量（变更后）")
    private Integer minimunRequireNew;

    @ApiModelProperty("是否发送：0-未发送，1-已发送")
    private Integer sendStatus = 0;


    /**
     * excel 导出字段
     * 库存（变更前）
     */
    @Transient
    private String stockOldStr;

    /**
     * excel 导出字段
     * 库存（变更后）
     */
    @Transient
    private String stockNewStr;

    public void StrChange(){
        if(stockOld != null) {
            switch (stockOld) {
                case 0:
                    stockOldStr = "订货";
                    break;
                case 1:
                    stockOldStr = "现货";
                    break;
            }
        }
        if(stockNew != null) {
            switch (stockNew) {
                case 0:
                    stockNewStr = "订货";
                    break;
                case 1:
                    stockNewStr = "现货";
                    break;
            }
        }
    }

    public boolean areSpecifiedFieldsNull() {
        return productTypeOld == null &&
               productTypeNew == null &&
               skuCodeOld == null &&
               skuCodeNew == null &&
               stockOld == null &&
               stockNew == null &&
               deliveryDateOld == null &&
               deliveryDateNew == null &&
               unitOld == null &&
               unitNew == null &&
               priceOld == null &&
               priceNew == null &&
               supplyPriceOld == null &&
               supplyPriceNew == null &&
               suggestPriceOld == null &&
               suggestPriceNew == null &&
               minimunRequireOld == null &&
               minimunRequireNew == null;
    }
}
