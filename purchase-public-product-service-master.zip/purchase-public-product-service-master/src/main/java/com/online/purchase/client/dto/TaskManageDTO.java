package com.online.purchase.client.dto;


import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;


@Data
@ApiModel("消息请求")
public class TaskManageDTO {

    private Integer id;
    @ApiModelProperty("类型，指按钮操作（审核通过、审核驳回、设置调货价、批量发布商品、关联ERP编码）")
    private String type;
    @ApiModelProperty("模块：页面菜单名称，如商品管理")
    private String module;
    @ApiModelProperty("服务名称：例如purchase-product")
    private String service;
    @ApiModelProperty("状态：0：未执行 1：执行中 2：执行成功 3：执行失败")
    private String status;
    @ApiModelProperty("请求参数，用于保存用户当前执行的参数")
    private String requestParam;
    @ApiModelProperty("执行结果类型：1: url  2：text")
    private String resultType;
    @ApiModelProperty("执行结果内容")
    private String resultContent;
    @ApiModelProperty("下载次数")
    private Integer downloadNum;
    @ApiModelProperty("备注")
    private String remark;
    @ApiModelProperty("创建者")
    private String createdBy;
    @ApiModelProperty("更新者")
    private String updatedBy;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
//    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("创建时间")
    private LocalDateTime createdAt;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
//    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("更新时间")
    private LocalDateTime updatedAt;
}
