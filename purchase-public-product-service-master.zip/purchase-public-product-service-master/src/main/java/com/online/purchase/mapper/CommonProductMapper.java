package com.online.purchase.mapper;

import com.online.purchase.model.CommonCataBrandProp;
import com.online.purchase.model.CommonProduct;
import com.online.purchase.model.ProductInfo;
import com.online.purchase.model.dto.ProductListDTO;
import com.online.purchase.model.dto.ProductZydmallDTO;
import com.online.purchase.model.dto.ProductZydmallIdDTO;
import com.online.purchase.model.dto.SelectCommonProductDto;
import com.online.purchase.model.vo.ProductVo;
import com.online.purchase.model.vo.ProductZydmallVo;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
public interface CommonProductMapper extends QguBaseMapper<CommonProduct> {

    /**
     * 根据实体字段条件获取对应实体集合--分页公用（分页由PageHelper实现-解耦合）
     *
     * @param commonProduct 实体对象
     * @return 对象集合
     */
    List<CommonProduct> search(@Param("con") CommonProduct commonProduct);

    /**
     * 根据品牌id，批量修改品牌编号关联
     *
     * @param oldBrandId 原品牌编号
     * @param brandId    品牌编号
     */
    void batchUpdateBrandId(Long oldBrandId, Long brandId);

    /**
     * 根据系列id，批量修改系列编号关联
     *
     * @param oldPropId 原系列编号
     * @param propId    系列编号
     */
    void batchUpdatePropId(Long oldPropId, Long propId);

    /**
     * 根据分类编号，批量修改分类编号关联
     *
     * @param oldCataId 原分类编号
     * @param cataId    分类编号
     */
    void batchUpdateCataId(Long oldCataId, Long cataId);

    Long getMaxProductId();

    List<CommonProduct> list(@Param("con") CommonProduct commonProduct);

    /**
     * 查询所有三方关系
     *
     * @return 三方关系
     */
    List<CommonCataBrandProp> listToRebuildTripartiteRelationship();

    List<String> fndExistProductCode(List<String> productCodes);

    ProductInfo.Info getInfo(@Param("id")String id);

    String getCataList(@Param("id")Long cataId);

    ProductInfo.Info getJsonInfo(@Param("id") String id);

    String selectSupplierByName(@Param("company") String company);

    List<SelectCommonProductDto> selectList(@Param("list")List<Long> productIds);

    List<ProductVo> productlist(@Param("dto")ProductListDTO productListDTO);

    Integer count(@Param("dto")ProductListDTO productListDTO);

    List<CommonProduct> selectIdsByWaitSync(@Param("limit") int limit);

    int updateStockByDynamics(@Param("typeKey")String typeKey, @Param("propertyValue")String propertyValue);

    int updateEsStock();

    int updatePurchaseProductSale(@Param("applyId")String applyId, @Param("isOnsale")String isOnsale);

    List<ProductZydmallVo> getZydmallList(@Param("dto") ProductZydmallDTO productZydmallDTO);

    Map<Integer, Integer> getZydmallCount(@Param("dto") ProductZydmallDTO productZydmallDTO);

    List<CommonProduct> productAddZydmallList(@Param("dto") ProductZydmallIdDTO productZydmallIdDTO);

    /**
     * zydmall商品上架移除
     *
     * @param productIds
     * @Author: loine
     * @Date: 2025/1/16 17:41
     */
    void clearZydmallFlag(@Param("productIds") List<Long> productIds);

    /**
     * 根据erp商品编码获取zydmall商品id
     *
     * @param proCode
     * @return
     */
    @Select("SELECT nproduct_id as productId,nerp_pro_code as erp_product_code,nerp_pro_id  FROM `online_common`.`t_pd_scm_zydmall_product` WHERE `nerp_pro_code` =#{proCode} ")
    ProductZydmallVo getZydProductIdByProCode(@Param("proCode") String proCode);

    /**
     * 根据商品ID更新商品信息
     *
     * @param product
     * @return
     */
    int updateByProductId(@Param("product") CommonProduct product);

    /**
     * 根据商品ID查询商品信息
     *
     * @param productId
     * @return
     */
    @Select("select * from t_pd_common_product where product_id = #{productId}")
    CommonProduct selectByProductId(@Param("productId") Long productId);

    /**
     *根据ID查询商品信息
     *
     * @param erpProductId
     * @param erpProductCode
     * @param zydmallProductId
     * @return
     */
    @Select("select * from t_pd_common_product where erp_product_id =#{erpProductId} or erp_product_code =#{erpProductCode} or zydmall_product_id =#{zydmallProductId} ")
    CommonProduct selectByErpProductId(@Param("erpProductId") Long erpProductId, @Param("erpProductCode") String erpProductCode, @Param("zydmallProductId") String zydmallProductId);
}
