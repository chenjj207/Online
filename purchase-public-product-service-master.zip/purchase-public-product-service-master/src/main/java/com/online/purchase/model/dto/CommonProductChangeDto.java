package com.online.purchase.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * 公海商品变更
 *
 * @author 博为
 * @Date 2022/8/15 10:59
 */
@Data
public class CommonProductChangeDto {
    @ApiModelProperty(value = "产品编码")
    private Long productId;
    @ApiModelProperty(value = "产品编码（租户产品为导入产品编码、公海产品为公海产品id）")
    private String productCode;
    @ApiModelProperty(value = "产品编码（租户产品为导入产品编码、公海产品为erp）")
    private String productCodeEdit;
    @ApiModelProperty(value = "产品名称")
    private String productName;
    @ApiModelProperty(value = "产品型号")
    private String productType;
    @ApiModelProperty(value = "产品货号")
    private String skuCode;
    @ApiModelProperty("供货价")
    private BigDecimal supplyPrice;
    @ApiModelProperty("慧采价")
    private BigDecimal commonPrice;
    @ApiModelProperty("面价")
    private BigDecimal price;
    @ApiModelProperty("建议零售价")
    private BigDecimal retailPrice;
    @ApiModelProperty(value = "库存")
    private Integer stock;
    @ApiModelProperty(value = "货期")
    private String deliveryDate;
    @ApiModelProperty(value = "计量单位")
    private String unit;
    @ApiModelProperty(value = "净重")
    private String weight;
    @ApiModelProperty(value = "是否上架")
    private String isOnsale;
    @ApiModelProperty(value = "产品图名称")
    private String productPicName;
    @ApiModelProperty(value = "3D模型名称")
    private String productModelName;
    @ApiModelProperty(value = "视频名称")
    private String productVedioName;
    @ApiModelProperty(value = "样本名称")
    private String productSimpleName;
    @ApiModelProperty(value = "系列概述")
    private String productContent;
    @ApiModelProperty(value = "是否正在调价中")
    private String isAdjustPrice;
    @ApiModelProperty(value = "公海产品来源")
    private String commonProductSrc;
    @ApiModelProperty(value = "是否有效")
    private String isValid;
    @ApiModelProperty(value = "是否存在附件")
    private String existsAttachment;
    @ApiModelProperty(value = "打包单位")
    private String packageUnit;
    @ApiModelProperty(value = "备注")
    private String ramark;
    @ApiModelProperty("3级分类Id")
    private Long cataId;
    @ApiModelProperty(value = "品牌编码")
    private Long brandId;
    @ApiModelProperty("品牌名称")
    private String brandName;
    @ApiModelProperty(value = "系列id")
    private Long propId;
    @ApiModelProperty("系列名称")
    private String propName;
    @ApiModelProperty("规格属性")
    private List<ProductConfirmDetailsSpecDto> specList;

    @Data
    @ApiModel("规格属性")
    public static class ProductConfirmDetailsSpecDto {
        @ApiModelProperty(value = "规格ID")
        private Long specId;
        @ApiModelProperty(value = "规格名称")
        private String specName;
        @ApiModelProperty(value = "规格值")
        private String specValue;
    }

}
