package com.online.purchase.service;

import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.mapper.CommonSpecValMapper;
import com.online.purchase.model.CommonSpecVal;
import com.online.purchase.utils.RedisUtil;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * CommonSpecValService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Service
public class CommonSpecValService extends BaseServiceImpl<CommonSpecVal> {

    @Resource
    private CommonSpecValMapper commonSpecValMapper;
    @Resource
    private RedisTemplate redisTemplate;

    /**
     * 根据 specValueIds 查询数据
     * @param specValueIds
     * @return
     */
    List<CommonSpecVal> listBySpecValueIds(List<Long> specValueIds){
        return commonSpecValMapper.listBySpecValueIds(specValueIds);
    }

    public List<CommonSpecVal> listAll() {
        return commonSpecValMapper.selectAll();
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<CommonSpecVal> search(CommonSpecVal commonSpecVal, Page<CommonSpecVal> page) {
        Assert.notNull(commonSpecVal, "commonSpecVal can not be null!");
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<CommonSpecVal> list = commonSpecValMapper.search(commonSpecVal);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packCommonSpecValData(list);
        return page;
    }

    private Example genConditionExample(CommonSpecVal model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        Long specValueId = model.getSpecValueId();
        Boolean deleted = model.getDeleted();
        if (null != deleted) {
            criteria.andEqualTo(CommonSpecVal.DELETED, deleted);
        }

        Integer syncStatus = model.getSyncStatus();
        if (null != syncStatus) {
            criteria.andEqualTo(CommonSpecVal.SYNC_STATUS, specValueId);
        }

        if (null != specValueId) {
            criteria.andEqualTo(CommonSpecVal.SPEC_VALUE_ID, specValueId);
        }

        Long specId = model.getSpecId();
        if (null != specId) {
            criteria.andEqualTo(CommonSpecVal.SPEC_ID, specId);
        }

        String specValue = model.getSpecValue();
        if (StringUtils.isNotBlank(specValue)) {
            criteria.andEqualTo(CommonSpecVal.SPEC_VALUE, specValue);
        }

        Collection<String> specValues = model.getSpecValues();
        if (CollectionUtils.isNotEmpty(specValues)) {
            criteria.andIn(CommonSpecVal.SPEC_VALUE, specValues);
        }

        return example;
    }

    /**
     * 分页数据处理
     */
    private void packCommonSpecValData(List<CommonSpecVal> commonSpecValList) {
        if (CollectionUtils.isEmpty(commonSpecValList)) {
            return;
        }

    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(CommonSpecVal commonSpecVal) {
        Assert.notNull(commonSpecVal, "commonSpecVal can not be null");
        Example example = genConditionExample(commonSpecVal);
        example.selectProperties(CommonSpecVal.ID);
        List<CommonSpecVal> commonSpecValList = commonSpecValMapper.selectByExample(example);
        return CollectionUtils.isEmpty(commonSpecValList) ? new ArrayList<>(0) :
                commonSpecValList.stream().map(CommonSpecVal::getId).collect(Collectors.toList());
    }

    /**
     * 根据条件，获取规格值
     *
     * @param specVal    条件
     * @param properties 返回字段
     * @return 规格值集合
     */
    @Transactional(readOnly = true)
    public List<CommonSpecVal> listByExample(CommonSpecVal specVal, String... properties) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(specVal);
        Example example = genConditionExample(specVal);
        example.selectProperties(properties);
        example.orderBy(CommonSpecVal.SORT).asc().orderBy(CommonSpecVal.CREATED_AT).asc();
        return commonSpecValMapper.selectByExample(example);
    }

    /**
     * 新增
     *
     * @param specVal 对象
     * @return 规格值编号集合
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Long add(CommonSpecVal specVal) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(specVal).isNotNull(specVal.getSpecId())
                .isNotEmpty(specVal.getSpecValue());
        validateSpecValue(Collections.singleton(specVal.getSpecValue()), specVal.getSpecId());
        Long specValueId = genSpecValId();
        specVal.setSpecValueId(specValueId);
        specVal.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        specVal.setCreatedAt(null);
        specVal.setCreatedBy(null);
        specVal.setUpdatedAt(null);
        specVal.setUpdatedBy(null);
        insert(specVal);
        return specValueId;
    }

    /**
     * 批量新增
     *
     * @param valList 对象集合
     * @param specId  统一规格名编号
     * @return 规格值编号集合
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<Long> batchAdd(List<CommonSpecVal> valList, Long specId) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(valList).isNotNull(specId);
        Set<String> values = valList.stream().map(CommonSpecVal::getSpecValue).collect(Collectors.toSet());
        if (values.size() != valList.size()) {
            throw new BaseException(PuPrErrorCode.COMMON_SPEC_VAL_ERROR);
        }

        validateSpecValue(values, specId);
        Long specValueId;
        List<Long> valIdList = Lists.newArrayList();
        for (CommonSpecVal val : valList) {
            if (StringUtils.isEmpty(val.getSpecValue())) {
                throw new BaseException(PuPrErrorCode.PARAMS_EMPTY_ERROR.getCode(), "具体参数值不可为空");
            }

            specValueId = genSpecValId();
            val.setSpecValueId(specValueId);
            valIdList.add(specValueId);
            val.setSpecId(specId);
            val.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
            val.setCreatedAt(null);
            val.setCreatedBy(null);
            val.setUpdatedAt(null);
            val.setUpdatedBy(null);
        }

        batchInsert(valList);
        return valIdList;
    }

    /**
     * 规格值重复校验
     *
     * @param specValues 规格值集合
     * @param specId     规格编号
     */
    private void validateSpecValue(Set<String> specValues, Long specId) {
        List<CommonSpecVal> specValList = listByExample(new CommonSpecVal().setSpecId(specId).setSpecValues(specValues)
                .setDeleted(false), CommonSpecVal.ID);
        if (CollectionUtils.isEmpty(specValList)) {
            return;
        }

        throw new BaseException(PuPrErrorCode.COMMON_SPEC_VAL_ERROR);
    }

    /**
     * 生成规格值编号
     *
     * @return 编号
     */
    private Long genSpecValId() {
        return RedisUtil.genCode("common_specVal_id", redisTemplate, () -> {
            return commonSpecValMapper.getMaxSpecValId();
        });
    }

    /**
     * 根据规格名编号，标记删除
     *
     * @param specId 规格名编号
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void batchDeleteBySpecId(Long specId) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(specId);
        commonSpecValMapper.batchDeleteBySpecId(specId);
    }

    public Long syncSpecVal(String specVal, Long specId, String productSrc) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CommonSpecVal.SPEC_VALUE, specVal);
        criteria.andEqualTo(CommonSpecVal.DELETED, false);
        criteria.andEqualTo(CommonSpecVal.SPEC_ID, specId);
        List<CommonSpecVal> specValList = commonSpecValMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(specValList)) {
            return specValList.get(0).getSpecValueId();
        }
        CommonSpecVal commonSpecVal = new CommonSpecVal();
        Long specValId = genSpecValId();
        commonSpecVal.setSpecValueId(specValId);
        commonSpecVal.setSpecId(specId);
        commonSpecVal.setSpecValue(specVal);
        commonSpecVal.setIsValid(PuPrConstants.IS_VALID_Y);
        commonSpecVal.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        commonSpecVal.setSort(1);
        commonSpecVal.setSource(StringUtils.equalsIgnoreCase(productSrc, "ZYDMALL") ? "zydmall" : PuPrConstants.DATA_SOURCE_APPLY);
        super.insert(commonSpecVal);
        return specValId;
    }

    /**
     * 根据规格编号和规格值编号，获取规格对
     *
     * @param specVal 条件
     * @return 规格对
     */
    @Transactional(readOnly = true)
    public List<CommonSpecVal> selectSpecAndSpecVal(CommonSpecVal specVal) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(specVal);
        Collection<Long> specIds = specVal.getSpecIds();
        Collection<Long> specValIds = specVal.getSpecValIds();
        if (CollectionUtils.isEmpty(specIds) && CollectionUtils.isEmpty(specValIds)) {
            return Lists.newArrayList();
        }

        return commonSpecValMapper.selectSpecAndSpecVal(specVal);
    }

    /**
     * 获取侍标记删除数据-用于定时任务
     *
     * @return 主键集合
     */
    public Set<String> listIdsToDel() {
        return commonSpecValMapper.listIdsToDel();
    }
}
