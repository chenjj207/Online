package com.online.purchase.controller.open;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import com.online.purchase.base.JobConstant;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.model.*;
import com.online.purchase.model.dto.CommonProductChangeDto;
import com.online.purchase.model.dto.CommonStructureDeleteDto;
import com.online.purchase.model.dto.SelectCommonProductDto;
import com.online.purchase.scheduler.jobclient.JobHandlerFactory;
import com.online.purchase.service.*;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import org.apache.commons.collections4.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 开放接口
 *
 * @author lwl
 */
@RestController
@RequestMapping(value = "/public")
public class OpenController {
    @Resource
    private JobHandlerFactory jobHandlerFactory;
    @Value("${product.structure.del.corn:}")
    private String structureDelCorn;
    @Value("${product.tripartite.relationship.corn:}")
    private String tripartiteRelationshipCorn;
    @Value("${zydonline.product.structure.corn:}")
    private String structureCorn;
    @Value("${zydonline.product.change.corn:}")
    private String productChangeCorn;
    @Value("${zydonline.product.esRebuild.corn:}")
    private String esRebuildCorn;
    @Resource
    private CommonBrandService commonBrandService;
    @Resource
    private CommonPropService commonPropService;
    @Resource
    private CommonCatalogService commonCatalogService;
    @Resource
    private CommonSpecService commonSpecService;
    @Resource
    private CommonSpecValService commonSpecValService;
    @Resource
    private CommonProductService commonProductService;
    @Resource
    private CommonProductSpecService commonProductSpecService;

    /**
     * 创建公海产品结构无关联产品标记删除任务
     */
    @PostMapping(value = "/product-structure-del")
    public JsonResult<Boolean> productStructureDel(@RequestBody Map<String, Object> param) {
        String taskId = "公海产品结构无关联产品标记删除任务";
        Map<String, String> paramMap = new HashMap<>(2);
        Object corn = param.get(JobConstant.CRON_EXPRESSION_KEY);
        structureDelCorn = null == corn ? structureDelCorn : (String) corn;
        paramMap.put(JobConstant.CRON_EXPRESSION_KEY, structureDelCorn);
        Object time = param.get(JobConstant.TASK_TRIGGER_TIME_KEY);
        if (null != time) {
            paramMap.put(JobConstant.TASK_TRIGGER_TIME_KEY, String.valueOf(DateUtil.parse((String) time).getTime()));
        }

        boolean success = jobHandlerFactory.create(taskId, JobConstant.PRODUCT_STRUCTURE_DEL, paramMap);
        return new JsonResult<>(true, "", success);
    }

    /**
     * 创建公海产品重建三方关系定时任务
     */
    @PostMapping(value = "/tripartite-relationship")
    public JsonResult<Boolean> tripartiteRelationship(@RequestBody Map<String, Object> param) {
        String taskId = "公海产品重建三方关系定时任务";
        Map<String, String> paramMap = new HashMap<>(2);
        Object corn = param.get(JobConstant.CRON_EXPRESSION_KEY);
        tripartiteRelationshipCorn = null == corn ? tripartiteRelationshipCorn : (String) corn;
        paramMap.put(JobConstant.CRON_EXPRESSION_KEY, tripartiteRelationshipCorn);
        Object time = param.get(JobConstant.TASK_TRIGGER_TIME_KEY);
        if (null != time) {
            paramMap.put(JobConstant.TASK_TRIGGER_TIME_KEY, String.valueOf(DateUtil.parse((String) time).getTime()));
        }

        boolean success = jobHandlerFactory.create(taskId, JobConstant.TRIPARTITE_RELATIONSHIP, paramMap);
        return new JsonResult<>(true, "", success);
    }

    /**
     * 创建公海产品结构变更通知定时任务
     */
    @PostMapping(value = "/product-structure-notice")
    public JsonResult<Boolean> productStructureNotice(@RequestBody Map<String, Object> param) {
        String taskId = "公海产品结构变更通知定时任务";
        Map<String, String> paramMap = new HashMap<>(2);
        Object corn = param.get(JobConstant.CRON_EXPRESSION_KEY);
        structureCorn = null == corn ? structureCorn : (String) corn;
        paramMap.put(JobConstant.CRON_EXPRESSION_KEY, structureCorn);
        Object time = param.get(JobConstant.TASK_TRIGGER_TIME_KEY);
        if (null != time) {
            paramMap.put(JobConstant.TASK_TRIGGER_TIME_KEY, String.valueOf(DateUtil.parse((String) time).getTime()));
        }

        boolean success = jobHandlerFactory.create(taskId, JobConstant.PRODUCT_STRUCTURE_NOTICE, paramMap);
        return new JsonResult<>(true, "", success);
    }

    /**
     * 创建公海产品变更通知定时任务
     */
    @PostMapping(value = "/product-notice")
    public JsonResult<Boolean> createProductNotice(@RequestBody Map<String, Object> param) {
        String taskId = "公海产品变更通知定时任务";
        Map<String, String> paramMap = new HashMap<>(2);
        Object corn = param.get(JobConstant.CRON_EXPRESSION_KEY);
        productChangeCorn = null == corn ? productChangeCorn : (String) corn;
        paramMap.put(JobConstant.CRON_EXPRESSION_KEY, productChangeCorn);
        Object time = param.get(JobConstant.TASK_TRIGGER_TIME_KEY);
        if (null != time) {
            paramMap.put(JobConstant.TASK_TRIGGER_TIME_KEY, String.valueOf(DateUtil.parse((String) time).getTime()));
        }

        boolean success = jobHandlerFactory.create(taskId, JobConstant.PRODUCT_NOTICE, paramMap);
        return new JsonResult<>(true, "", success);
    }

    /**
     * 创建公海产品es重建定时任务
     */
    @PostMapping(value = "/es-rebuild")
    public JsonResult<Boolean> esRebuild(@RequestBody Map<String, Object> param) {
        String taskId = "公海产品es重建定时任务";
        Map<String, String> paramMap = new HashMap<>(2);
        Object corn = param.get(JobConstant.CRON_EXPRESSION_KEY);
        esRebuildCorn = null == corn ? esRebuildCorn : (String) corn;
        paramMap.put(JobConstant.CRON_EXPRESSION_KEY, esRebuildCorn);
        Object time = param.get(JobConstant.TASK_TRIGGER_TIME_KEY);
        if (null != time) {
            paramMap.put(JobConstant.TASK_TRIGGER_TIME_KEY, String.valueOf(DateUtil.parse((String) time).getTime()));
        }

        boolean success = jobHandlerFactory.create(taskId, JobConstant.ES_REBUILD, paramMap);
        return new JsonResult<>(true, "", success);
    }

    /**
     * 查看待同步产品结构
     */
    @GetMapping(value = "/dealJieGouData")
    public JsonResult<CommonStructureDeleteDto> dealJieGouData() {
        // 待同步产品结构
        List<CommonBrand> brandList = commonBrandService.listAll(
                new CommonBrand().setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC));
        List<CommonProp> propList = commonPropService.listByCondition(
                new CommonProp().setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC), CommonProp.ID, CommonProp.PROP_ID);
        List<CommonCatalog> catalogList = commonCatalogService.listByCondition(
                new CommonCatalog().setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC), CommonCatalog.ID, CommonCatalog.CATA_ID);
        List<CommonSpec> specList = commonSpecService.listByCondition(
                new CommonSpec().setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC), CommonSpec.ID, CommonSpec.SPEC_ID);
        List<CommonSpecVal> specValList = commonSpecValService.listByExample(
                new CommonSpecVal().setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC), CommonSpecVal.ID, CommonSpecVal.SPEC_VALUE_ID);
        if (CollectionUtils.isEmpty(brandList) && CollectionUtils.isEmpty(propList) && CollectionUtils.isEmpty(catalogList)
                && CollectionUtils.isEmpty(specList) && CollectionUtils.isEmpty(specValList)) {
            return new JsonResult<>();
        }

        CommonStructureDeleteDto deleteDto = new CommonStructureDeleteDto();
        deleteDto.setType(String.valueOf(1));
        if (CollectionUtils.isNotEmpty(brandList)) {
            deleteDto.setBrandIds(brandList.stream().distinct().map(CommonBrand::getBrandId).collect(Collectors.toList()));
        }

        if (CollectionUtils.isNotEmpty(propList)) {
            deleteDto.setPropIds(propList.stream().distinct().map(CommonProp::getPropId).collect(Collectors.toList()));
        }

        if (CollectionUtils.isNotEmpty(catalogList)) {
            deleteDto.setCataIds(catalogList.stream().distinct().map(CommonCatalog::getCataId).collect(Collectors.toList()));
        }

        if (CollectionUtils.isNotEmpty(specList)) {
            deleteDto.setSpecIds(specList.stream().distinct().map(CommonSpec::getSpecId).collect(Collectors.toList()));
        }

        if (CollectionUtils.isNotEmpty(specValList)) {
            deleteDto.setSpecValIds(specValList.stream().distinct().map(CommonSpecVal::getSpecValueId).collect(Collectors.toList()));
        }

        return new JsonResult<>(true, null, deleteDto);

    }

    /**
     * 查看待同步产品
     */
    @GetMapping(value = "/dealChanPinData")
    public JsonResult<List<CommonProductChangeDto>> dealChanPinData() {
        // 待同步产品
        List<CommonProduct> list = commonProductService.listByExample(new CommonProduct().setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC));
        if (CollectionUtils.isEmpty(list)) {
            return new JsonResult<>();
        }

        List<CommonProductChangeDto> changeList = new ArrayList<>(list.size());
        CommonProductChangeDto dto;
        for (CommonProduct product : list) {
            dto = BeanUtil.copyProperties(product, CommonProductChangeDto.class, "specValList");
            dto.setProductCode(product.getProductId().toString());
            dto.setProductCodeEdit(product.getErpProductCode());
            dto.setCommonPrice(product.getPurchasePrice());
            dto.setRetailPrice(product.getSuggestPrice());
            dto.setCommonProductSrc(product.getProductSrc());
            Collection<CommonSpecVal> specValList = product.getSpecValList();
            if (CollectionUtils.isNotEmpty(specValList)) {
                List<CommonProductChangeDto.ProductConfirmDetailsSpecDto> specDtoList = new ArrayList<>(specValList.size());
                CommonProductChangeDto.ProductConfirmDetailsSpecDto specDto;
                for (CommonSpecVal specVal : specValList) {
                    specDto = BeanUtil.copyProperties(specVal, CommonProductChangeDto.ProductConfirmDetailsSpecDto.class);
                    specDtoList.add(specDto);
                }

                dto.setSpecList(specDtoList);
            }

            changeList.add(dto);
        }

        return new JsonResult<>(true, null, changeList);
    }


    @GetMapping(value = "/addJieGouData/{max}")
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public JsonResult<?> addJieGouData(@PathVariable int max) {
        int j = 5;
        for (int i = 0; i < j; i++) {
            int num = max + 1 + i;
            String brandPrimaryId = commonBrandService.add(new CommonBrand().setBrandName("sync测试品牌" + num).setSort(i + 1), null);
            CommonBrand brand = commonBrandService.getById(brandPrimaryId, CommonBrand.BRAND_ID);
            String propPrimaryId = commonPropService.add(new CommonProp().setPropName("sync测试系列" + num).setSort(i + 1).setBrandId(brand.getBrandId()), null);
            String cataPrimaryId = commonCatalogService.add(new CommonCatalog().setCataName("sync测试分类" + num).setSort(i + 1).setParentCataId(2413L), null);
            CommonCatalog catalog = commonCatalogService.getById(cataPrimaryId, CommonCatalog.CATA_ID);
            List<CommonSpecVal> specVals = Lists.newArrayList(new CommonSpecVal().setDeleted(true).setSpecValue("sync测试规格值" + num).setSort(i + 1));
            String specPrimaryId = commonSpecService.add(new CommonSpec().setDeleted(true).setSpecName("sync测试规格" + num).setCataId(catalog.getCataId()).setSort(i + 1).setSpecValList(specVals));
            // 产品
            CommonProduct commonProduct = new CommonProduct();
            commonProduct.setIsValid(PuPrConstants.IS_VALID_Y);
            commonProduct.setProductName("sync测试产品" + num);
            commonProduct.setProductType("sync测试产品型号");
            long l = 99999999999L - num - i;
            commonProduct.setErpProductId(l);
            commonProduct.setErpProductCode(l + "");
            commonProduct.setSkuCode("12334");
            commonProduct.setPrice(BigDecimal.valueOf(10));
            commonProduct.setSupplyPrice(BigDecimal.valueOf(10));
            commonProduct.setSuggestPrice(BigDecimal.valueOf(10));
            commonProduct.setPurchasePrice(BigDecimal.valueOf(10));
            commonProduct.setCataId(catalog.getCataId());
            commonProduct.setBrandId(brand.getBrandId());
            commonProduct.setPropId(commonPropService.getById(propPrimaryId, CommonProp.PROP_ID).getPropId());
            commonProduct.setUnit("只");
            commonProduct.setWeight("10");
            commonProduct.setIsOnsale("N");
            commonProduct.setDeliveryDate("预计9天");
            // commonProduct.setAuditTime(purchaseProductSync.getAuditTime());
            commonProduct.setSupplierId("1");
            commonProduct.setProductContent("系列概述");
            commonProduct.setProductVedioName("视频名称");
            commonProduct.setProductPicName("产品图名称");
            if (i == 0) {
                commonProduct.setProductSrc("ZYDMALL");
            } else {
                commonProduct.setProductSrc(0 == i / 2 ? PuPrConstants.SUPPLY : PuPrConstants.SUPPLIER);
            }
            commonProduct.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
            String productPrimaryId = commonProductService.add(commonProduct);
            CommonProduct product = commonProductService.getById(productPrimaryId, CommonProduct.PRODUCT_ID);
            CommonProductSpec productSpec = new CommonProductSpec();
            productSpec.setProductId(product.getProductId());
            CommonSpec comSpec = commonSpecService.getByProperty(CommonSpec.ID, specPrimaryId, CommonSpec.SPEC_ID);
            productSpec.setSpecId(comSpec.getSpecId());
            CommonSpecVal val = new CommonSpecVal();
            val.setSpecId(comSpec.getSpecId()).setDeleted(true);
            List<CommonSpecVal> valList = commonSpecValService.listByExample(val);
            productSpec.setSpecValueId(valList.get(0).getSpecValueId());
            productSpec.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
            commonProductSpecService.add(productSpec);

            CommonBrand delBrand = new CommonBrand();
            delBrand.setDeleted(true).setId(brandPrimaryId);
            commonBrandService.update(delBrand);
            CommonProp delProp = new CommonProp();
            delProp.setDeleted(true).setId(propPrimaryId);
            commonPropService.update(delProp);
            CommonCatalog delCata = new CommonCatalog();
            delCata.setDeleted(true).setId(cataPrimaryId);
            commonCatalogService.update(delCata);
        }

        return new JsonResult<>();
    }
}
