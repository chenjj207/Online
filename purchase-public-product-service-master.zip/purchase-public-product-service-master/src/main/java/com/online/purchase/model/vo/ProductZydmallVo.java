package com.online.purchase.model.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@ApiModel("zydmall商品上架-出参")
public class ProductZydmallVo {
    @ApiModelProperty("主键id")
    private String id;
    @ApiModelProperty("产品id")
    private String productId;
    @ApiModelProperty("ERP产品编号")
    private String erpProductCode;
    @ApiModelProperty("商品名称")
    private String productName;
    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;
    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;
    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;
    @ApiModelProperty("商品品牌名称")
    private String brandName;
    @ApiModelProperty("商品系列名称")
    private String propName;
    @ApiModelProperty("产品型号")
    private String productType;
    @ApiModelProperty("规格@规格名")
    private String specNameStr;
    @ApiModelProperty("规格@规格值")
    private String specValueStr;
    @ApiModelProperty("规格@规格名&规格值")
    private String specNameValueStr;
    @ApiModelProperty("订货号")
    private String skuCode;
    @ApiModelProperty("物料名称")
    private String materialName;
    @ApiModelProperty("供货价")
    private String supplyPrice;
    @ApiModelProperty("慧采价")
    private String purchasePrice;
    @ApiModelProperty("面价")
    private String price;
    @ApiModelProperty("建议销售价")
    private String suggestPrice;
    @ApiModelProperty("库存")
    private String stock;
    @ApiModelProperty("货期")
    private String deliveryDate;
    @ApiModelProperty("计量单位")
    private String unit;
    @ApiModelProperty("重量")
    private String weight;
    @ApiModelProperty("最小起订量")
    private Integer minimunRequire;
    @ApiModelProperty("规格属性")
    private String specData;
    @ApiModelProperty("图片")
    private String picName;
    @ApiModelProperty("视频")
    private String picVideoName;
    @ApiModelProperty("产品详情图")
    private String productContent;
    @ApiModelProperty("产品样本")
    private String productSimpleName;
    @ApiModelProperty("所属子公司")
    private String subCompany;
    @ApiModelProperty("创建者")
    private String supplier;
    @ApiModelProperty(value = "创建时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createdAt;
    @ApiModelProperty(value = "zydmall上架标识 1：上架 0或空：未上架")
    private String zydmallFlag;
    @ApiModelProperty(value = "上架zydmall时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime zydmallTime;
    @ApiModelProperty(value = "原因")
    private String reason;
    @ApiModelProperty("是否上架(Y:上架,N:下架)")
    private String isOnsale;

    @ApiModelProperty("ERP产品ID")
    private Long nerpProId;
    @ApiModelProperty("zydmall最小起订量")
    private Long nminimunRequire;
    @ApiModelProperty("zydmall单位")
    private String sunit;
    @ApiModelProperty("IFS上下架")
    private String sisIfsOnsale;
    @ApiModelProperty("最后更新时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime lastUpdatedAt;

}
