package com.online.purchase.model.dto;

import com.online.purchase.model.CommonProduct;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class SelectCommonProductDto extends CommonProduct {

    /**
     * 一级店铺产品分类名
     */
    @ApiModelProperty(value = "一级店铺产品分类名")
    private String firstStoreCataName;

    /**
     * 二级店铺产品分类名
     */
    @ApiModelProperty(value = "二级店铺产品分类名")
    private String secondStoreCataName;

    @ApiModelProperty(value = "店铺id")
    private Integer storeCataId;
}
