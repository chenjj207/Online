package com.online.purchase.mapper;

import com.online.purchase.model.CommonSpecVal;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

/**
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
public interface CommonSpecValMapper extends QguBaseMapper<CommonSpecVal> {


    /**
     * 根据 specValueIds 查询数据
     * @param specValueIds
     * @return
     */
    List<CommonSpecVal> listBySpecValueIds(@Param("specValueIds") List<Long> specValueIds);

    /**
     * 根据实体字段条件获取对应实体集合--分页公用（分页由PageHelper实现-解耦合）
     *
     * @param commonSpecVal 实体对象
     * @return 对象集合
     */
    List<CommonSpecVal> search(@Param("con") CommonSpecVal commonSpecVal);

    /**
     * 生成规格值编号
     *
     * @return 编号
     */
    Long getMaxSpecValId();

    /**
     * 根据规格名编号，标记删除
     *
     * @param specId 规格名编号
     */
    void batchDeleteBySpecId(Long specId);

    /**
     * 根据规格编号和规格值编号，获取规格对
     *
     * @param specVal 条件
     * @return 规格对
     */
    List<CommonSpecVal> selectSpecAndSpecVal(@Param("specVal") CommonSpecVal specVal);

    /**
     * 获取侍标记删除数据-用于定时任务
     *
     * @return 主键集合
     */
    Set<String> listIdsToDel();
}
