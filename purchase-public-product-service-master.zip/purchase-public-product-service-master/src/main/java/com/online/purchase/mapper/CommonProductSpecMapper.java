package com.online.purchase.mapper;

import com.online.purchase.model.CommonProductSpec;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
public interface CommonProductSpecMapper extends QguBaseMapper<CommonProductSpec> {

    /**
     * 根据实体字段条件获取对应实体集合--分页公用（分页由PageHelper实现-解耦合）
     *
     * @param commonProductSpec 实体对象
     * @return 对象集合
     */
    List<CommonProductSpec> search(@Param("con") CommonProductSpec commonProductSpec);

    void deleteByProductId(@Param("productId") Long productId);

    List<CommonProductSpec> selectByProductId(@Param("productId") Long productId);
}
