package com.online.purchase.model;

import com.purchase.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Collection;

/**
 * 品牌 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Getter
@Setter
@ToString
@Accessors(chain = true)
@ApiModel(value = "CommonBrand", description = "品牌")
@Table(name = "online_common.t_pd_common_brand")
public class CommonBrand extends PageBean<CommonBrand> {

    public static final String BRAND_ID = "brandId";
    public static final String BRAND_NAME = "brandName";
    public static final String BRAND_NAME_LETTER = "brandNameLetter";
    public static final String SORT = "sort";
    public static final String PIC_URL = "picUrl";
    public static final String IS_VALID = "isValid";
    public static final String IS_SHOP_CENTER = "isShopCenter";
    public static final String REMARK = "remark";
    public static final String DELETED = "deleted";
    public static final String SOURCE = "source";
    public static final String SYNC_STATUS = "syncStatus";

    /**
     * 品牌编码
     */
    @ApiModelProperty(value = "品牌编码")
    private Long brandId;

    /**
     * 品牌名称
     */
    @ApiModelProperty(value = "品牌名称")
    private String brandName;

    /**
     * 名称首字母
     */
    @ApiModelProperty(value = "名称首字母")
    private String brandNameLetter;

    /**
     * 排序
     */
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /**
     * 品牌图
     */
    @ApiModelProperty(value = "品牌图")
    private String picUrl;

    /**
     * 是否有效 Y：是 N：否
     */
    @ApiModelProperty(value = "是否有效 Y：是 N：否")
    private String isValid;

    /**
     * 是否体验店
     */
    @ApiModelProperty(value = "是否体验店")
    private String isShopCenter;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 标记删除
     */
    private Boolean deleted;

    /**
     * 数据来源
     */
    private String source;

    /**
     * 通知租户状态（1：等待通知，2：已通知）
     */
    @ApiModelProperty(value = "通知租户状态（1：等待通知，2：已通知）")
    private Integer syncStatus;

    /**
     * 关键字查询(编码/名称)
     */
    @Transient
    private String keywords;

    /**
     * 品牌编号集合
     */
    @Transient
    private Collection<Long> brandIds;

    /**
     * 品牌名称集合
     */
    @Transient
    private Collection<String> brandNames;
}
