package com.online.purchase.scheduler.tasktracker;

import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.spring.boot.annotation.JobRunner4TaskTracker;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.github.ltsopensource.tasktracker.runner.JobRunner;
import com.online.purchase.base.JobConstant;
import org.springframework.context.ApplicationContext;

import javax.annotation.Resource;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 任务调度器
 *
 * @author zhangcheng
 * @since 2022-08-18
 */
@JobRunner4TaskTracker
public class TaskTrackerJobRunner implements JobRunner {

    @Resource
    private ApplicationContext applicationContext;

    private static final ConcurrentHashMap<String, Class<?>> JOB_RUNNER_MAP = new ConcurrentHashMap<>();

    static {
        JOB_RUNNER_MAP.put(JobConstant.PRODUCT_NOTICE, ProductChangeNoticeActuator.class);
        JOB_RUNNER_MAP.put(JobConstant.TRIPARTITE_RELATIONSHIP, TripartiteRelationshipActuator.class);
        JOB_RUNNER_MAP.put(JobConstant.PRODUCT_STRUCTURE_NOTICE, ProductStructureNoticeActuator.class);
        JOB_RUNNER_MAP.put(JobConstant.PRODUCT_STRUCTURE_DEL, ProductStructureDelActuator.class);
        JOB_RUNNER_MAP.put(JobConstant.ES_REBUILD, EsRebuildActuator.class);
        JOB_RUNNER_MAP.put(JobConstant.PRODUCT_MODI_REC, ProductModiRecActuator.class);
        JOB_RUNNER_MAP.put(JobConstant.THREE_CATA_PIC, ThreeCataPicActuator.class);
    }

    @Override
    public Result run(JobContext jobContext) {
        try {
            String type = jobContext.getJob().getParam(JobConstant.TASK_TYPE_KEY);
            BaseJobRunnerActuator baseJobRunnerActuator = (BaseJobRunnerActuator) applicationContext.getBean(JOB_RUNNER_MAP.get(type));
            return baseJobRunnerActuator.run(jobContext);
        } catch (Throwable e) {
            return new Result(Action.EXECUTE_EXCEPTION, e.getMessage());
        }
    }

}
