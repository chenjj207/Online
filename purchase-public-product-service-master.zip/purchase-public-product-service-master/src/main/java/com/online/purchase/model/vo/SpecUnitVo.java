package com.online.purchase.model.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.*;
import com.alibaba.excel.enums.poi.BorderStyleEnum;
import com.alibaba.excel.enums.poi.HorizontalAlignmentEnum;
import com.alibaba.excel.enums.poi.VerticalAlignmentEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * @Description:
 * @Author: loine
 * @Date: 2026/1/6 10:09
 */
@Data
@ApiModel("规格参数标准计量单位-出参")
@HeadStyle(horizontalAlignment = HorizontalAlignmentEnum.LEFT, verticalAlignment = VerticalAlignmentEnum.CENTER, fillForegroundColor = 5)
@HeadFontStyle(color = 0, fontName = "微软雅黑", fontHeightInPoints = 12)
@ContentStyle(horizontalAlignment = HorizontalAlignmentEnum.LEFT, verticalAlignment = VerticalAlignmentEnum.CENTER, borderTop = BorderStyleEnum.THIN, borderBottom = BorderStyleEnum.THIN, borderLeft = BorderStyleEnum.THIN, borderRight = BorderStyleEnum.THIN)
@ContentFontStyle(fontName = "微软雅黑")
@ColumnWidth(20)
public class SpecUnitVo {
    @ApiModelProperty(value = "规格编码")
    @ExcelProperty("规格编码")
    private Long specId;
    @ApiModelProperty(value = "一级分类")
    @ExcelProperty("一级分类")
    private String cataName1;
    @ApiModelProperty(value = "二级分类")
    @ExcelProperty("二级分类")
    private String cataName2;
    @ApiModelProperty(value = "三级分类")
    @ExcelProperty("三级分类")
    private String cataName3;
    @ApiModelProperty(value = "规格名")
    @ExcelProperty("规格名")
    private String specName;
    @ApiModelProperty(value = "计量单位格式")
    @ExcelProperty(value = "计量单位格式")
    @HeadFontStyle(color = 2, fontName = "微软雅黑", fontHeightInPoints = 12)
    private String specUnit;
    @ApiModelProperty(value = "规格值")
    @ExcelProperty("规格值")
    @ColumnWidth(100)
    private String specValue;
    @ApiModelProperty(value = "首次创建规范时间")
    @ExcelProperty("首次创建规范时间")
    private String createdAt;
    @ApiModelProperty(value = "首次创建规范人员")
    @ExcelProperty("首次创建规范人员")
    private String createdName;
    @ApiModelProperty(value = "最后更新规范时间")
    @ExcelProperty("最后更新规范时间")
    private String updatedAt;
    @ApiModelProperty(value = "最后更新规范人员")
    @ExcelProperty("最后更新规范人员")
    private String updatedName;
}
