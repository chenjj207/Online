package com.online.purchase.service;

import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.mapper.CommonSpecMapper;
import com.online.purchase.model.*;
import com.online.purchase.utils.RedisUtil;
import com.online.purchase.utils.ReflectUtils;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * CommonSpecService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Service
public class CommonSpecService extends BaseServiceImpl<CommonSpec> {

    @Resource
    private CommonSpecMapper commonSpecMapper;
    @Resource
    private CommonCatalogService commonCatalogService;
    @Resource
    private CommonProductSpecService commonProductSpecService;
    @Resource
    private CommonSpecValService commonSpecValService;
    @Resource
    private CommonSpecUnitService commonSpecUnitService;
    @Resource
    private RedisTemplate redisTemplate;

    private static final String[] SPEC_FIELD_LIST = {"cataId", "specId", "specName"};
    private static final String[] SPEC_VAL_FIELD_LIST = {"id", "specId", "specValue", "specValueId"};

    @Transactional(readOnly = true)
    public List<CommonSpec> listBySpecIds(List<Long> specIds) {
        return commonSpecMapper.selectListBySpecIds(specIds);
    }

    @Transactional(readOnly = true)
    public List<CommonSpec> listByCondition(CommonSpec commonSpec, String... properties) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonSpec);
        Example example = genConditionExample(commonSpec);
        example.selectProperties(properties);
        return commonSpecMapper.selectByExample(example);
    }

    /**
     * 根据条件分页获取数据
     *
     * @param commonSpec 条件
     * @param page       分页对象
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public Page<CommonSpec> search(CommonSpec commonSpec, Page<CommonSpec> page) {
        Assert.notNull(commonSpec, "commonSpec can not be null!");
        Long cataId = commonSpec.getCataId();
        if (null != cataId) {
            Set<Long> cataIds = commonCatalogService.listChildIdByCataId(cataId);
            cataIds.add(cataId);
            commonSpec.setCataIds(cataIds);
        }

        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<CommonSpec> list = commonSpecMapper.search(commonSpec);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packCommonSpecData(list);
        return page;
    }

    private Example genConditionExample(CommonSpec model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        Boolean deleted = model.getDeleted();
        if (null != deleted) {
            criteria.andEqualTo(CommonSpec.DELETED, deleted);
        }

        String id = model.getId();
        if (StringUtils.isNotEmpty(id)) {
            criteria.andEqualTo(CommonSpec.ID, id);
        }

        Long cataId = model.getCataId();
        if (null != cataId) {
            criteria.andEqualTo(CommonSpec.CATA_ID, cataId);
        }

        Long specId = model.getSpecId();
        if (null != specId) {
            criteria.andEqualTo(CommonSpec.SPEC_ID, specId);
        }

        String specName = model.getSpecName();
        if (StringUtils.isNotBlank(specName)) {
            criteria.andEqualTo(CommonSpec.SPEC_NAME, specName);
        }

        Integer syncStatus = model.getSyncStatus();
        if (null != syncStatus) {
            criteria.andEqualTo(CommonSpec.SYNC_STATUS, syncStatus);
        }
        example.orderBy(CommonSpec.SORT).asc().orderBy(CommonSpec.CREATED_AT).asc();
        return example;
    }

    /**
     * 分页数据处理
     */
    private void packCommonSpecData(List<CommonSpec> commonSpecList) {
        if (CollectionUtils.isEmpty(commonSpecList)) {
            return;
        }

        Set<Long> cataIds = commonSpecList.stream().map(CommonSpec::getCataId).collect(Collectors.toSet());
        if (CollectionUtils.isEmpty(cataIds)) {
            return;
        }

        List<CommonCatalog> cataList = commonCatalogService.listAll(new CommonCatalog().setCataIdList(cataIds));
        if (CollectionUtils.isEmpty(cataList)) {
            return;
        }

        Map<Long, CommonCatalog> cataIdMap = cataList.stream().collect(Collectors.toMap(CommonCatalog::getCataId, c -> c));

        for (CommonSpec spec : commonSpecList) {
            spec.setCommonCatalog(cataIdMap.get(spec.getCataId()));
        }
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(CommonSpec commonSpec) {
        Assert.notNull(commonSpec, "commonSpec can not be null");
        Example example = genConditionExample(commonSpec);
        example.selectProperties(CommonSpec.ID);
        List<CommonSpec> commonSpecList = commonSpecMapper.selectByExample(example);
        return CollectionUtils.isEmpty(commonSpecList) ? new ArrayList<>(0) :
                commonSpecList.stream().map(CommonSpec::getId).collect(Collectors.toList());
    }

    /**
     * 根据主键id，获取对象
     *
     * @param id 主键
     * @return 对象
     */
    public CommonSpec getById(String id) {
        CommonSpec commonSpec = new CommonSpec();
        commonSpec.setId(id);
        commonSpec = getByExample(commonSpec);
        if (null == commonSpec) {
            return null;
        }

        Long cataId = commonSpec.getCataId();
        if (null != cataId) {
            commonSpec.setCommonCatalog(commonCatalogService.getByExample(new CommonCatalog().setCataId(cataId)));
        }

        CommonSpecVal val = new CommonSpecVal();
        val.setSpecId(commonSpec.getSpecId()).setDeleted(false);
        List<CommonSpecVal> valList = commonSpecValService.listByExample(val);
        commonSpec.setSpecValList(valList);
        return commonSpec;
    }

    /**
     * 新增
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String add(CommonSpec commonSpec) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonSpec)
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonSpec.getSpecName())
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonSpec.getCataId());
        // 分类id+规格名称不能重复
        validateSpecName(commonSpec.getSpecName(), commonSpec.getCataId());
        // 分类合法校验
        CommonCatalog catalog = commonCatalogService.getByExample(new CommonCatalog().setCataId(commonSpec.getCataId()).setDeleted(false));
        if (null == catalog) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }

        if (3 != catalog.getLevel()) {
            throw new BaseException(PuPrErrorCode.COMMON_SPEC_CATA_LEVEL_ERROR);
        }


        Long specId = genSpecId();
        commonSpec.setSpecId(specId);
        commonSpec.setIsValid(PuPrConstants.IS_VALID_Y);
        Integer maxCataSpecSort1 = commonSpecMapper.getMaxSpecSort(commonSpec.getCataId());
        int maxSpecSort = commonSpec.getSort() == null ? (maxCataSpecSort1 == null ? 0 : maxCataSpecSort1) + 1 : commonSpec.getSort();
        commonSpec.setSort(maxSpecSort);

        // 规格值
        List<CommonSpecVal> specValList = commonSpec.getSpecValList();
        if (CollectionUtils.isNotEmpty(specValList)) {
            if (PuPrConstants.DATA_SOURCE.equals(commonSpec.getSource())) {
                int sort = 1;
                for (CommonSpecVal s : specValList) {
                    s.setSource(PuPrConstants.DATA_SOURCE);
                    s.setSort(sort);
                    sort++;
                }
            }

            commonSpecValService.batchAdd(specValList, specId);
        }

        commonSpec.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        return super.insert(commonSpec);
    }

    /**
     * 批量新增
     *
     * @param commonSpecs
     * @return
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public List<String> batchAdd(List<CommonSpec> commonSpecs) {
        List<String> ids = new ArrayList<>();
        for (CommonSpec newSpec : commonSpecs) {
            String id = add(newSpec);
            ids.add(id);
        }
        return ids;
    }

    /**
     * 生成规格编号
     *
     * @return 编号
     */
    private Long genSpecId() {
        return RedisUtil.genCode("common_spec_id", redisTemplate, () -> {
            return commonSpecMapper.getMaxSpecId();
        });
    }

    /**
     * 分类id+规格名称不能重复
     *
     * @param specName 名称
     */
    private void validateSpecName(String specName, Long cataId) {
        //20241210 分类id+规格名称不能重复
        List<String> idList = listIdsByExample(new CommonSpec().setSpecName(specName).setCataId(cataId).setDeleted(false));
        if (CollectionUtils.isEmpty(idList)) {
            return;
        }

        throw new BaseException(PuPrErrorCode.COMMON_SPEC_NAME_ERROR);
    }

    /**
     * 修改，标记删除后新增
     *
     * @return 主键
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String edit(CommonSpec commonSpec) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonSpec)
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonSpec.getSpecName())
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonSpec.getId());
        String id = commonSpec.getId();
        CommonSpec param = new CommonSpec();
        param.setDeleted(false).setId(id);
        CommonSpec spec = getByExample(param);
        if (null == spec) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }

        CommonSpec commonSpecOld = getById(commonSpec.getId());
        Boolean hasEdit = ReflectUtils.hasEdit(commonSpecOld, commonSpec, SPEC_FIELD_LIST, this.entityClass)
                || hasEditSpecVal(commonSpecOld.getSpecValList(), commonSpec.getSpecValList());

        if (BooleanUtils.isTrue(hasEdit)) {
            if (StringUtils.equals(commonSpec.getSpecName(), spec.getSpecName())) {
                // 没有修改规格名称
                return editNoUpdateName(commonSpec, spec);
            }

            // 原规格值
            List<CommonSpecVal> dbValList = commonSpecValService.listByExample(
                    new CommonSpecVal().setSpecId(spec.getSpecId()).setDeleted(false), CommonSpecVal.ID, CommonSpecVal.SPEC_VALUE_ID);
            // 新规格值
            List<CommonSpecVal> valList = commonSpec.getSpecValList();
            valList = null == valList ? Lists.newArrayList() : valList;
            // 新增规格值
            List<CommonSpecVal> addList = Lists.newArrayList();
            // 更改的规格值
            List<CommonSpecVal> valListEdit = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(valList)) {
                for (CommonSpecVal val : valList) {
                    if (null == val.getSpecValueId()) {
                        addList.add(val);
                        continue;
                    }

                    valListEdit.add(val);
                }

                valList = valListEdit;
            }

            // 原关联商品
            List<CommonProductSpec> cpsList = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(dbValList)) {
                Set<Long> dbValIds = dbValList.stream().map(CommonSpecVal::getSpecValueId).collect(Collectors.toSet());
                Set<Long> valIds = valList.stream().map(CommonSpecVal::getSpecValueId).collect(Collectors.toSet());
                if (CollectionUtils.isNotEmpty(valIds) && CollectionUtils.isNotEmpty(CollectionUtils.subtract(valIds, dbValIds))) {
                    // 更改的规格值不能是原来不存在的数据
                    throw new BaseException(PuPrErrorCode.DATA_ERROR);
                }

                // 删除的规格值
                Collection<Long> subValIds = CollectionUtils.subtract(dbValIds, valIds);
                if (CollectionUtils.isNotEmpty(subValIds)) {
                    // 删除校验
                    List<String> psIds = commonProductSpecService.listIdsByExample(new CommonProductSpec().setSpecId(spec.getSpecId()).setSpecValueIds(subValIds));
                    CheckFlow.start(PuPrErrorCode.COMMON_SPEC_VAL_EXIST_PRODUCT_ERROR).isEmpty(psIds);
                }

                // 原关联商品
                cpsList = commonProductSpecService.listByExample(new CommonProductSpec().setSpecId(spec.getSpecId()).setSpecValueIds(dbValIds));
                // 标记删除原规格值
                dbValList.forEach(d -> d.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC));
                commonSpecValService.batchUpdate(dbValList);
            } else if (CollectionUtils.isNotEmpty(valListEdit)) {
                // 全部新增规格值，specValId不可有值
                throw new BaseException(PuPrErrorCode.DATA_ERROR.getCode(), "新增的规格值，specValId不可有值");
            }

            // 标记删除
            CommonSpec delSpec = new CommonSpec();
            delSpec.setDeleted(true).setId(id);
            delSpec.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
            super.update(delSpec);
            // 名称重复校验
            if (!StringUtils.equals(commonSpecOld.getSpecName(), commonSpec.getSpecName())) {
                //已存在和新修改的不一致，才需要校验
                validateSpecName(commonSpec.getSpecName(), commonSpec.getCataId());
            }

            // 新增
            commonSpec.setId(null);
            commonSpec.setCreatedAt(null);
            commonSpec.setCreatedBy(null);
            commonSpec.setUpdatedAt(null);
            commonSpec.setUpdatedBy(null);
            commonSpec.setIsValid(spec.getIsValid());
            commonSpec.setRemark(spec.getRemark());
            commonSpec.setSource(spec.getSource());
            Long specId = genSpecId();
            commonSpec.setSpecId(specId);
            commonSpec.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
            commonSpec.setCataId(spec.getCataId());
            String newId = super.insert(commonSpec);

            if (CollectionUtils.isNotEmpty(cpsList)) {
                Map<Long, CommonSpecVal> valIdMap = valList.stream().collect(Collectors.toMap(CommonSpecVal::getSpecValueId, s -> s));
                Map<Long, Long> oldNewSpecValIdMap = new HashMap<>(valIdMap.size());
                for (CommonProductSpec productSpec : cpsList) {
                    Long specValueId = productSpec.getSpecValueId();
                    CommonSpecVal val = valIdMap.get(specValueId);
                    val.setSpecId(specId);
                    if (PuPrConstants.DATA_SOURCE.equals(commonSpec.getSource())) {
                        val.setSource(PuPrConstants.DATA_SOURCE);
                    }

                    val.setId(null);
                    Long newSpecValId = oldNewSpecValIdMap.get(specValueId);
                    if (null == newSpecValId) {
                        newSpecValId = commonSpecValService.add(val);
                        oldNewSpecValIdMap.put(specValueId, newSpecValId);
                        // 移除已新增
                        Long finalNewSpecValId = newSpecValId;
                        valList = valList.stream().filter(v -> !finalNewSpecValId.equals(v.getSpecValueId())).collect(Collectors.toList());
                    }

                    productSpec.setSpecValueId(newSpecValId);
                    productSpec.setSpecId(specId);
                    productSpec.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
                }

                commonProductSpecService.batchUpdate(cpsList);
            }

            addList.addAll(valList);
            // 新增规格值
            if (CollectionUtils.isNotEmpty(addList)) {
                if (PuPrConstants.DATA_SOURCE.equals(commonSpec.getSource())) {
                    addList.forEach(s -> s.setSource(PuPrConstants.DATA_SOURCE).setId(null));
                }
                for (CommonSpecVal commonSpecVal : addList) {
                    if (null != commonSpecVal) {
                        commonSpecVal.setCreatedAt(null);
                        commonSpecVal.setCreatedBy(null);
                        commonSpecVal.setUpdatedAt(null);
                        commonSpecVal.setUpdatedBy(null);
                    }
                }

                commonSpecValService.batchAdd(addList, specId);
            }

            return newId;
        } else {
            this.update(commonSpec);
        }
        return commonSpec.getId();

    }

    private Boolean hasEditSpecVal(List<CommonSpecVal> specValListOld, List<CommonSpecVal> specValList) {
        if (CollectionUtils.isEmpty(specValList)) {
            if (CollectionUtils.isEmpty(specValListOld)) {
                return false;
            } else {
                return true;
            }
        }
        if (CollectionUtils.isEmpty(specValListOld)) {
            if (CollectionUtils.isEmpty(specValList)) {
                return false;
            } else {
                return true;
            }
        }

        if (specValList.size() != specValListOld.size()) {
            return true;
        }

        for (int i = 0; i < specValList.size(); i++) {
            if (ReflectUtils.hasEdit(specValList.get(i), specValListOld.get(i), SPEC_VAL_FIELD_LIST, CommonSpecVal.class)) {
                return true;
            }
        }

        return false;
    }

    private String editNoUpdateName(CommonSpec commonSpec, CommonSpec spec) {
        spec.setSort(commonSpec.getSort());
        spec.setUpdatedBy(ContextHandler.getUserId());
        spec.setUpdatedAt(LocalDateTime.now());
        commonSpecMapper.updateByPrimaryKey(spec);
        // 数据库中原规格值
        List<CommonSpecVal> dbValList = commonSpecValService.listByExample(
                new CommonSpecVal().setSpecId(spec.getSpecId()).setDeleted(false), CommonSpecVal.ID, CommonSpecVal.SPEC_VALUE_ID, CommonSpecVal.SPEC_VALUE);
        // 新规格值
        List<CommonSpecVal> valList = commonSpec.getSpecValList();
        valList = null == valList ? Lists.newArrayList() : valList;
        /*
         * 1、dbValList为空 valList为空 没有规格值直接返回
         * 2、dbValList为空 valList不为空 新增规格值后直接返回
         * 3、dbValList不为空 valList为空 全部删除规格值校验商口并删除规格值
         * 4、dbValList不为空 valList不为空 删除、编辑、新增
         * */

        // 1、dbValList为空 valList为空 没有规格值直接返回
        if (CollectionUtils.isEmpty(dbValList) && CollectionUtils.isEmpty(valList)) {
            return spec.getId();
        }

        // 2、dbValList为空 valList不为空 新增规格值后直接返回
        if (CollectionUtils.isEmpty(dbValList) && CollectionUtils.isNotEmpty(valList)) {
            if (PuPrConstants.DATA_SOURCE.equals(commonSpec.getSource())) {
                valList.forEach(s -> s.setSource(PuPrConstants.DATA_SOURCE).setId(null));
            }

            commonSpecValService.batchAdd(valList, spec.getSpecId());
            return spec.getId();
        }

        // 3、dbValList不为空 valList为空 全部删除规格值校验商口并删除规格值
        if (CollectionUtils.isNotEmpty(dbValList) && CollectionUtils.isEmpty(valList)) {
            Set<Long> dbValIds = dbValList.stream().map(CommonSpecVal::getSpecValueId).collect(Collectors.toSet());
            // 删除校验
            List<String> psIds = commonProductSpecService.listIdsByExample(new CommonProductSpec().setSpecId(spec.getSpecId()).setSpecValueIds(dbValIds));
            CheckFlow.start(PuPrErrorCode.COMMON_SPEC_VAL_EXIST_PRODUCT_ERROR).isEmpty(psIds);
            // 标记删除原规格值
            dbValList.forEach(d -> d.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC));
            commonSpecValService.batchUpdate(dbValList);
            return spec.getId();
        }

        // 4、dbValList不为空 valList不为空 删除、编辑、新增
        if (CollectionUtils.isNotEmpty(dbValList) && CollectionUtils.isNotEmpty(valList)) {
            // 新增规格值
            List<CommonSpecVal> addList = Lists.newArrayList();
            // 更改的规格值
            List<CommonSpecVal> valListEdit = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(valList)) {
                for (CommonSpecVal val : valList) {
                    if (null == val.getSpecValueId()) {
                        addList.add(val);
                        continue;
                    }

                    valListEdit.add(val);
                }
            }

            Set<Long> dbValIds = dbValList.stream().map(CommonSpecVal::getSpecValueId).collect(Collectors.toSet());
            Set<Long> valIds = valListEdit.stream().map(CommonSpecVal::getSpecValueId).collect(Collectors.toSet());
            if (CollectionUtils.isNotEmpty(valIds) && CollectionUtils.isNotEmpty(CollectionUtils.subtract(valIds, dbValIds))) {
                // 更改的规格值不能是原来不存在的数据
                throw new BaseException(PuPrErrorCode.DATA_ERROR);
            }

            // 删除
            // 删除的规格值
            Collection<Long> subValIds = CollectionUtils.subtract(dbValIds, valIds);
            if (CollectionUtils.isNotEmpty(subValIds)) {
                // 删除校验
                List<String> psIds = commonProductSpecService.listIdsByExample(new CommonProductSpec().setSpecId(spec.getSpecId()).setSpecValueIds(subValIds));
                CheckFlow.start(PuPrErrorCode.COMMON_SPEC_VAL_EXIST_PRODUCT_ERROR).isEmpty(psIds);
                // 标记删除原规格值
                List<CommonSpecVal> delVals = dbValList.stream().filter(d -> subValIds.contains(d.getSpecValueId())).collect(Collectors.toList());
                delVals.forEach(d -> d.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC));
                commonSpecValService.batchUpdate(delVals);
            }

            // 编辑
            // 标记删除，新增，维护商品关联关系
            if (CollectionUtils.isNotEmpty(valListEdit)) {
                // 有更改规格值Map
                Map<Long, Long> editMap = new HashMap<>(valListEdit.size());
                // 检验是否更改，没有更改不做处理
                Map<Long, CommonSpecVal> dbValMap = dbValList.stream().collect(Collectors.toMap(CommonSpecVal::getSpecValueId, v -> v));
                for (CommonSpecVal val : valListEdit) {
                    Long specValueId = val.getSpecValueId();
                    CommonSpecVal dbVal = dbValMap.get(specValueId);
                    if (dbVal.getSpecValue().equals(val.getSpecValue())) {
                        continue;
                    }

                    // 标记删除原规格值
                    dbVal.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
                    commonSpecValService.update(dbVal);
                    val.setId(null);
                    val.setSpecId(spec.getSpecId());
                    if (PuPrConstants.DATA_SOURCE.equals(commonSpec.getSource())) {
                        val.setSource(PuPrConstants.DATA_SOURCE);
                    }

                    Long newValId = commonSpecValService.add(val);
                    editMap.put(specValueId, newValId);
                }

                // 原关联商品
                if (MapUtils.isNotEmpty(editMap)) {
                    List<CommonProductSpec> cpsList = commonProductSpecService.listByExample(new CommonProductSpec().setSpecId(spec.getSpecId()).setSpecValueIds(editMap.keySet()));
                    if (CollectionUtils.isNotEmpty(cpsList)) {
                        for (CommonProductSpec productSpec : cpsList) {
                            productSpec.setSpecValueId(editMap.get(productSpec.getSpecValueId()));
                            productSpec.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
                        }

                        commonProductSpecService.batchUpdate(cpsList);
                    }
                }
            }

            // 新增
            if (CollectionUtils.isNotEmpty(addList)) {
                if (PuPrConstants.DATA_SOURCE.equals(commonSpec.getSource())) {
                    addList.forEach(s -> s.setSource(PuPrConstants.DATA_SOURCE).setId(null));
                }

                commonSpecValService.batchAdd(addList, spec.getSpecId());
            }

            return spec.getId();
        }

        return spec.getId();
    }

    /**
     * 根据分类编号，批量修改分类编号关联
     *
     * @param oldCataId 原分类编号
     * @param cataId    分类编号
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void batchUpdateCataId(Long oldCataId, Long cataId) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(oldCataId).isNotNull(cataId);
        commonSpecMapper.batchUpdateCataId(oldCataId, cataId);
    }

    /**
     * 标记删除
     *
     * @param id 主键
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void deleteById(String id) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(id);
        CommonSpec param = new CommonSpec();
        param.setDeleted(false).setId(id);
        CommonSpec commonSpec = getByExample(param);
        if (null == commonSpec) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }

        // 慧采商品关联校验
        List<String> psIdList = commonProductSpecService.listIdsByExample(new CommonProductSpec().setSpecId(commonSpec.getSpecId()));
        if (CollectionUtils.isNotEmpty(psIdList)) {
            throw new BaseException(PuPrErrorCode.COMMON_SPEC_EXIST_PRODUCT_ERROR);
        }

        // 规格值关联标记删除
        commonSpecValService.batchDeleteBySpecId(commonSpec.getSpecId());
        CommonSpec del = new CommonSpec();
        del.setDeleted(true).setId(id);
        del.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        super.update(del);
    }

    /**
     * 根据条件获取对象
     *
     * @param commonSpec 条件
     * @return 对象
     */
    @Transactional(readOnly = true)
    public CommonSpec getByExample(CommonSpec commonSpec) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonSpec);
        Example example = genConditionExample(commonSpec);
        return commonSpecMapper.selectOneByExample(example);
    }

    public Long syncSpec(String spec, Long cataId, String productSrc) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CommonSpec.SPEC_NAME, spec);
        criteria.andEqualTo(CommonSpec.DELETED, false);
        if (cataId != null) {
            criteria.andEqualTo(CommonSpec.CATA_ID, cataId);
        }
        List<CommonSpec> specList = commonSpecMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(specList)) {
            return specList.get(0).getSpecId();
        }
        CommonSpec commonSpec = new CommonSpec();
        Long specId = genSpecId();
        commonSpec.setSpecId(specId);
        commonSpec.setCataId(cataId);
        commonSpec.setSpecName(spec);
        commonSpec.setIsValid(PuPrConstants.IS_VALID_Y);
        commonSpec.setSort(1);
        commonSpec.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        commonSpec.setSource(org.apache.commons.lang3.StringUtils.equalsIgnoreCase(productSrc, "ZYDMALL") ? "zydmall" : PuPrConstants.DATA_SOURCE_APPLY);
        super.insert(commonSpec);
        return specId;
    }

    public List<CommonSpec> listAll(CommonSpec commonSpec) {
        Example example = genConditionExample(commonSpec);
        List<CommonSpec> commonSpecList = commonSpecMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(commonSpecList)) {
            // 获取规格单位
            Map<Long, CommonSpecUnit> commonSpecUnitMap = commonSpecUnitService.getUnitByIds(commonSpecList.stream().map(CommonSpec::getSpecId).collect(Collectors.toSet()));
            for (CommonSpec data : commonSpecList) {
                CommonSpecVal val = new CommonSpecVal();
                val.setSpecId(data.getSpecId()).setDeleted(false);
                List<CommonSpecVal> valList = commonSpecValService.listByExample(val);
                data.setSpecValList(valList);
                // 设置规格单位
                CommonSpecUnit commonSpecUnit = commonSpecUnitMap.get(data.getSpecId());
                if (commonSpecUnit != null) {
                    data.setSpecUnit(commonSpecUnit.getSpecUnit());
                }

            }
        }
        return commonSpecList;
    }

    /**
     * 获取侍标记删除数据-用于定时任务
     *
     * @return 主键集合
     */
    public Set<String> listIdsToDel() {
        return commonSpecMapper.listIdsToDel();
    }

    public List<CommonSpec> listAllGroupByCataId() {
        return commonSpecMapper.listAllGroupByCataId();
    }

    /**
     * 批量新增规格参数解析
     *
     * @param commonSpec
     * @return
     */
    public List<CommonSpec> parseCommonSpec(CommonSpec commonSpec) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonSpec.getText());
        List<CommonSpec> commonSpecs = new ArrayList<>();
        String[] lines = commonSpec.getText().split("\n");

        for (String line : lines) {
          /*  String[] parts = line.trim().split("\\s+");
            if (line.trim().isEmpty() || parts.length == 0) {
                continue;
            } else if (parts.length == 1) {
                String specName = parts[0];
                if (specName.length() > 13) {
                    throw new BaseException(PuPrErrorCode.DATA_ERROR.getCode(), "规格名称长度不能超过13");
                }
//                List<CommonSpecVal> commonSpecVals = specSpilt(parts[1]);//规格值
                newSpec.setSpecName(specName);
//                newSpec.setSpecValList(commonSpecVals);
            }*/
          /*  else if (parts.length == 2) {

                String specName = parts[0];
                if (specName.length() > 13) {
                    throw new BaseException(PuPrErrorCode.DATA_ERROR.getCode(), "规格名称长度不能超过13");
                }
                newSpec.setSpecName(specName);
//                    List<CommonSpecVal> commonSpecVals = specSpilt(parts[1]);//规格值
                try {
                    int sort = Integer.parseInt(parts[1]);
//                    newSpec.setSpecValList(commonSpecVals);
                    newSpec.setSort(sort);
                } catch (NumberFormatException e) {
                    throw new BaseException(PuPrErrorCode.ERROR_DIGITAL_CONVERSION.getCode(), "请检查排序字段是否为数字");
                }
            }*/
            if (line.trim().isEmpty()) {
                continue;
            }
            if (line.length() > 13) {
                throw new BaseException(PuPrErrorCode.DATA_ERROR.getCode(), "规格名称长度不能超过13");
            }
            CommonSpec newSpec = new CommonSpec();
            newSpec.setSpecName(line);
            newSpec.setSource(commonSpec.getSource());
            newSpec.setCataId(commonSpec.getCataId());
            commonSpecs.add(newSpec);
        }
        return commonSpecs;
    }

    /**
     * 规格值拆分
     *
     * @param spec
     * @return
     */
    public List<CommonSpecVal> specSpilt(String spec) {
        String[] spesc = spec.split(",");//规格
        List<CommonSpecVal> specValList = new ArrayList<>();
        for (int i = 0; i < spesc.length; i++) {
            CommonSpecVal val = new CommonSpecVal();
            val.setSpecValue(spesc[i]);
            val.setSort(i);
            specValList.add(val);
        }
        return specValList;
    }
}
