package com.online.purchase.utils;

import com.qgutech.qgyun.framework.common.utils.ReflectUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * 反射工具类
 * @author zhangcheng
 */
public class ReflectUtils {

    public static Boolean hasEdit(Object oldObj, Object newObj, String[] fieldList, Class entityClass) {
        if (ArrayUtils.isNotEmpty(fieldList)) {
            for (String fieldName : fieldList) {
                Object newValue;
                Object oldValue;
                java.lang.reflect.Field modelField = ReflectUtil.getField(entityClass, fieldName);
                newValue = ReflectUtil.getFieldValue(modelField, newObj);
                oldValue = ReflectUtil.getFieldValue(modelField, oldObj);
                if (!checkIsEqual(newValue, oldValue)) {
                    return true;
                }
            }
        }
        return false;
    }

    protected static Boolean checkIsEqual(Object newValue, Object oldValue) {
        if (newValue instanceof BigDecimal) {
            if ((newValue == null || ((BigDecimal) newValue).compareTo(BigDecimal.ZERO) == 0) &&
                    (oldValue == null || ((BigDecimal) oldValue).compareTo(BigDecimal.ZERO) == 0)) {
                return true;
            }

            if ((newValue != null && oldValue != null) && ((BigDecimal) oldValue).compareTo((BigDecimal) newValue) == 0) {
                return true;
            }

            newValue = newValue != null ? ((BigDecimal) newValue).setScale(2, RoundingMode.HALF_UP) : null;
            oldValue = oldValue != null ? ((BigDecimal) oldValue).setScale(2, RoundingMode.HALF_UP) : null;
        }

        String newStringValue = newValue == null ? "" : StringUtils.trim(String.valueOf(newValue));
        String oldStringValue = oldValue == null ? "" : StringUtils.trim(String.valueOf(oldValue));
        return newStringValue.equals(oldStringValue);
    }

}
