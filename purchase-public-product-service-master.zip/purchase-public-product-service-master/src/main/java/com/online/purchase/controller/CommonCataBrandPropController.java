package com.online.purchase.controller;

import com.online.purchase.base.JobConstant;
import com.online.purchase.model.CommonBrand;
import com.online.purchase.model.CommonCataBrandProp;
import com.online.purchase.model.CommonCatalog;
import com.online.purchase.model.CommonProp;
import com.online.purchase.service.CommonCataBrandPropService;
import com.online.purchase.service.CommonProductService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * CommonCataBrandPropController 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@RestController
@RequestMapping(value = "/common-cata-brand-prop")
@Api(value = "CommonCataBrandPropController", tags = {"公海分类品牌系列服务"})
public class CommonCataBrandPropController {

    @Resource
    private CommonCataBrandPropService commonCataBrandPropService;
    @Autowired
    CommonProductService commonProductService;

    @PostMapping("/brand-list")
    @ApiOperation(value = "商品分类第三级查看接口-分类下品牌接口")
    public JsonResult<List<CommonBrand>> listBrand(@RequestBody CommonCataBrandProp cataBrandProp) {
        List<CommonBrand> brandList = commonCataBrandPropService.listBrand(cataBrandProp);
        return new JsonResult<>(true, "查询成功", brandList);
    }

    @PostMapping("/prop-list")
    @ApiOperation(value = "第三级查看接口-分类、品牌下系列接口")
    public JsonResult<List<CommonProp>> listProp(@RequestBody CommonCataBrandProp cataBrandProp) {
        List<CommonProp> brandList = commonCataBrandPropService.listProp(cataBrandProp);
        return new JsonResult<>(true, "查询成功", brandList);
    }

    @PostMapping(value = "/catalog/tree-list")
    @ApiOperation(value = "获取分类树")
    public JsonResult<List<CommonCatalog>> getCatalogTree() {
        return new JsonResult<>(true, "查询成功", commonCataBrandPropService.getCatalogTree());
    }

    @PostMapping("/catalog/brand-list")
    @ApiOperation(value = "分类下品牌接口")
    public JsonResult<List<CommonBrand>> listCatalogBrand(@RequestBody CommonCataBrandProp cataBrandProp) {
        List<CommonBrand> brandList = commonCataBrandPropService.listCatalogBrand(cataBrandProp);
        return new JsonResult<>(true, "查询成功", brandList);
    }

    @PostMapping("/catalog/prop-list")
    @ApiOperation(value = "分类、品牌下系列接口")
    public JsonResult<List<CommonProp>> listCatalogBrandProp(@RequestBody CommonCataBrandProp cataBrandProp) {
        List<CommonProp> brandList = commonCataBrandPropService.listCatalogBrandProp(cataBrandProp);
        return new JsonResult<>(true, "查询成功", brandList);
    }

    @PostMapping("/rebuild")
    @ApiOperation(value = "重建")
    public JsonResult<Boolean> rebuild() {
        List<CommonCataBrandProp> relationShipList = commonProductService.listToRebuildTripartiteRelationship();
        // 清空关系
        commonCataBrandPropService.deleteAll();
        if (CollectionUtils.isEmpty(relationShipList)) {
            return new JsonResult<Boolean>(true, "", false);
        }

        relationShipList.forEach(r -> r.setUpdatedBy(JobConstant.TRIPARTITE_RELATIONSHIP));
        commonCataBrandPropService.batchInsert(relationShipList);
        return new JsonResult<Boolean>(true, "", true);
    }
}