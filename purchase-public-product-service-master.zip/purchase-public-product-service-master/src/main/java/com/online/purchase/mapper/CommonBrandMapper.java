package com.online.purchase.mapper;

import com.online.purchase.model.CommonBrand;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

/**
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
public interface CommonBrandMapper extends QguBaseMapper<CommonBrand> {

    /**
     * 根据实体字段条件获取对应实体集合--分页公用（分页由PageHelper实现-解耦合）
     *
     * @param commonBrand 实体对象
     * @return 对象集合
     */
    List<CommonBrand> search(@Param("con") CommonBrand commonBrand);

    /**
     * 根据条件，获取所有数据
     *
     * @param brand 条件
     * @return 对象集合
     */
    List<CommonBrand> selectAllByCondition(@Param("con") CommonBrand brand);

    /**
     * 生成品牌编号
     *
     * @return 编号
     */
    Long getMaxBrandId();

    /**
     * 生成品牌排序
     * @return
     */
    int getMaxBrandSort();

    /**
     * 获取侍标记删除数据-用于定时任务
     *
     * @return 主键集合
     */
    Set<String> listIdsToDel();
}
