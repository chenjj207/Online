package com.online.purchase.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.mapper.CommonCataBrandPropMapper;
import com.online.purchase.model.CommonBrand;
import com.online.purchase.model.CommonCataBrandProp;
import com.online.purchase.model.CommonCatalog;
import com.online.purchase.model.CommonProp;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * CommonCataBrandPropService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Service
public class CommonCataBrandPropService extends BaseServiceImpl<CommonCataBrandProp> {

    @Resource
    private CommonCataBrandPropMapper commonCataBrandPropMapper;
    @Resource
    private CommonCatalogService commonCatalogService;
    @Resource
    private CommonBrandService commonBrandService;

    private Example genConditionExample(CommonCataBrandProp model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        Long cataId = model.getCataId();
        if (null != cataId) {
            criteria.andEqualTo(CommonCataBrandProp.CATA_ID, cataId);
        }

        Long brandId = model.getBrandId();
        if (null != brandId) {
            criteria.andEqualTo(CommonCataBrandProp.BRAND_ID, brandId);
        }

        Long propId = model.getPropId();
        if (null != propId) {
            criteria.andEqualTo(CommonCataBrandProp.PROP_ID, propId);
        }

        String remark = model.getRemark();
        if (StringUtils.isNotBlank(remark)) {
            criteria.andEqualTo(CommonCataBrandProp.REMARK, remark);
        }


        return example;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(CommonCataBrandProp commonCataBrandProp) {
        Assert.notNull(commonCataBrandProp, "commonCataBrandProp can not be null");
        Example example = genConditionExample(commonCataBrandProp);
        example.selectProperties(CommonCataBrandProp.ID);
        List<CommonCataBrandProp> commonCataBrandPropList = commonCataBrandPropMapper.selectByExample(example);
        return CollectionUtils.isEmpty(commonCataBrandPropList) ? new ArrayList<>(0) :
                commonCataBrandPropList.stream().map(CommonCataBrandProp::getId).collect(Collectors.toList());
    }

    /**
     * 商品分类第三级查看接口-分类下品牌接口
     *
     * @param cataBrandProp 条件
     * @return 品牌集合
     */
    @Transactional(readOnly = true)
    public List<CommonBrand> listBrand(CommonCataBrandProp cataBrandProp) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(cataBrandProp)
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(cataBrandProp.getCataId());
        return commonCataBrandPropMapper.listBrandByCataId(cataBrandProp.getCataId());
    }

    /**
     * 第三级查看接口-分类、品牌下系列接口
     *
     * @param cataBrandProp 条件
     * @return 品牌集合
     */
    @Transactional(readOnly = true)
    public List<CommonProp> listProp(CommonCataBrandProp cataBrandProp) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(cataBrandProp)
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(cataBrandProp.getCataId())
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(cataBrandProp.getBrandId());
        List<CommonProp> propList = commonCataBrandPropMapper.listPropByCataIdAndBrandId(cataBrandProp.getCataId(), cataBrandProp.getBrandId());
        List<CommonProp> props = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(propList)) {
            boolean flag = true;
            for (CommonProp commonProp:propList) {
                if (null != commonProp) {
                    if (StringUtils.isEmpty(commonProp.getPropName())) {
                        if (flag) {
                            CommonProp commonProp1 = new CommonProp();
                            commonProp1.setPropId(999999999L);
                            commonProp1.setPropName("暂无数据");
                            props.add(0, commonProp1);
                            flag = false;
                        }
                    } else {
                        props.add(commonProp);
                    }
                } else {
                    if (flag) {
                        CommonProp commonProp1 = new CommonProp();
                        commonProp1.setPropId(999999999L);
                        commonProp1.setPropName("暂无数据");
                        props.add(0, commonProp1);
                        flag = false;
                    }
                }
            }
        }
        return props;
    }

    /**
     * 清空数据
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void deleteAll() {
        commonCataBrandPropMapper.deleteAll();
    }

    /**
     * 获取分类树
     *
     * @return 分类树
     */
    @Transactional(readOnly = true)
    public List<CommonCatalog> getCatalogTree() {
        // 三级分类
        List<CommonCatalog> allList = commonCataBrandPropMapper.listAllCatalog();
        if (CollectionUtils.isEmpty(allList)) {
            return Lists.newArrayList();
        }
        // 一、二级分类
        Set<Long> oneAndTwoCataIds = new HashSet<>();
        for (CommonCatalog catalog : allList) {
            String cataIds = catalog.getCataIds();
            String[] cataIdArray = cataIds.split(",");
            for (int i = 0; i < cataIdArray.length; i++){
                if (i == 2) {
                    break;
                }

                oneAndTwoCataIds.add(Long.valueOf(cataIdArray[i]));
            }
        }

        List<CommonCatalog> list = commonCatalogService.listByCondition(new CommonCatalog().setDeleted(false).setCataIdList(oneAndTwoCataIds));
        allList.addAll(list);
        /*for (CommonCatalog catalog:allList) {
            if (null != catalog && null != catalog.getLevel() && 3 != catalog.getLevel()) {
                catalog.setChildren(getChildren(catalog, allList));
            }
        }

        allList = allList.stream().sorted(Comparator.comparingInt(catalog -> (catalog.getSort() == null ? 0 : catalog.getSort()))).collect(Collectors.toList());
        return allList;*/


        return allList.stream().filter(catalog ->
                catalog.getParentCataId() == 0
        ).peek((catalog) -> catalog.setChildren(getChildren(catalog, allList)))
                .sorted(Comparator.comparingInt(catalog -> (catalog.getSort() == null ? 0 : catalog.getSort()))).collect(Collectors.toList());
    }

    private List<CommonCatalog> getChildren(CommonCatalog root, List<CommonCatalog> allList) {
        return allList.stream().filter(catalog -> catalog.getParentCataId().equals(root.getCataId()))
                .peek(catalog -> catalog.setChildren(3 != catalog.getLevel() ? getChildren(catalog, allList) : null))
                .sorted(Comparator.comparingInt(catalog -> (catalog.getSort() == null ? 0 : catalog.getSort()))).collect(Collectors.toList());
    }

    /**
     * 分类下品牌接口
     *
     * @param cataBrandProp 入参
     * @return 品牌集合
     */
    @Transactional(readOnly = true)
    public List<CommonBrand> listCatalogBrand(CommonCataBrandProp cataBrandProp) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(cataBrandProp);
        Integer level = cataBrandProp.getLevel();
        Long cataId = cataBrandProp.getCataId();
        Set<Long> cataIds = Sets.newHashSet();
        if (null != level && 3 == level && null != cataId){
            cataIds.add(cataId);
        } else if (null != cataId) {
            cataIds = commonCatalogService.listChildIdByCataId(cataId);
            if (CollectionUtils.isEmpty(cataIds)) {
                return Lists.newArrayList();
            }
        }

        return commonCataBrandPropMapper.listBrandByCataIds(cataIds);
    }

    /**
     * 分类、品牌下系列接口
     *
     * @param cataBrandProp 入参
     * @return 系列集合
     */
    @Transactional(readOnly = true)
    public List<CommonProp> listCatalogBrandProp(CommonCataBrandProp cataBrandProp) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(cataBrandProp);
        Long cataId = cataBrandProp.getCataId();
        Set<Long> cataIds = Sets.newHashSet();
        Integer level = cataBrandProp.getLevel();
        if (null != level && 3 == level && null != cataId){
            cataIds.add(cataId);
        } else if (null != cataId) {
            cataIds = commonCatalogService.listChildIdByCataId(cataId);
            if (CollectionUtils.isEmpty(cataIds)) {
                return Lists.newArrayList();
            }
        }

        List<CommonProp> propList = commonCataBrandPropMapper.listPropByCataIdsAndBrandId(cataIds, cataBrandProp.getBrandId());
        List<CommonProp> props = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(propList)) {
            boolean flag = true;
            for (CommonProp commonProp:propList) {
                if (null != commonProp) {
                    if (StringUtils.isEmpty(commonProp.getPropName())) {
                        if (flag) {
                            CommonProp commonProp1 = new CommonProp();
                            commonProp1.setPropId(999999999L);
                            commonProp1.setPropName("暂无数据");
                            props.add(0, commonProp1);
                            flag = false;
                        }
                    } else {
                        props.add(commonProp);
                    }
                } else {
                    if (flag) {
                        CommonProp commonProp1 = new CommonProp();
                        commonProp1.setPropId(999999999L);
                        commonProp1.setPropName("暂无数据");
                        props.add(0, commonProp1);
                        flag = false;
                    }
                }
            }
        }
        return props;
    }
}
