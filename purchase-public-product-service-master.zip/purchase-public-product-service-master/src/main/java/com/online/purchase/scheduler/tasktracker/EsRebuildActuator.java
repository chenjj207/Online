package com.online.purchase.scheduler.tasktracker;

import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.online.purchase.base.JobConstant;
import com.online.purchase.service.CommonEsService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;

/**
 * 公海产品es重建
 *
 * @author zhangcheng
 * @since 2022-08-18
 */
@Component("esRebuildActuator")
@Slf4j
public class EsRebuildActuator implements BaseJobRunnerActuator {

    @Resource
    private CommonEsService commonEsService;

    @Override
    public Result run(JobContext jobContext) {
        log.info("公海产品es重建开始 ==> " + LocalDateTime.now());
        String onlySyncToES = jobContext.getJob().getParam("onlySyncToES");
        if (StringUtils.equals(onlySyncToES, "Y")){
            //仅重新同步数据到es
            dealData(true);
        }else {
            //需重构t_pd_common_es表 并 同步数据到es
            dealData(false);
        }

        log.info("公海产品es重建结束 ==> " + LocalDateTime.now());
        return new Result(Action.EXECUTE_SUCCESS, StringUtils.EMPTY);
    }

    private void dealData(boolean onlySyncToES) {
        commonEsService.rebuildEs(onlySyncToES);
    }
}
