package com.online.purchase.scheduler.tasktracker;

import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.online.purchase.base.JobConstant;
import com.online.purchase.model.CommonCataBrandProp;
import com.online.purchase.service.CommonCataBrandPropService;
import com.online.purchase.service.CommonProductService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 公海产品重建三方关系
 *
 * @author zhangcheng
 * @since 2022-08-18
 */
@Component("tripartiteRelationshipActuator")
@Slf4j
public class TripartiteRelationshipActuator implements BaseJobRunnerActuator {

    @Resource
    private CommonCataBrandPropService commonCataBrandPropService;
    @Resource
    private CommonProductService commonProductService;

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Result run(JobContext jobContext) {
        log.info("公海产品重建三方关系开始 ==> " + LocalDateTime.now());
        dealData();
        log.info("公海产品重建三方关系结束 ==> " + LocalDateTime.now());
        return new Result(Action.EXECUTE_SUCCESS, StringUtils.EMPTY);
    }

    private void dealData() {
        List<CommonCataBrandProp> relationShipList = commonProductService.listToRebuildTripartiteRelationship();
        // 清空关系
        commonCataBrandPropService.deleteAll();
        if (CollectionUtils.isEmpty(relationShipList)) {
            return;
        }

        relationShipList.forEach(r -> r.setUpdatedBy(JobConstant.TRIPARTITE_RELATIONSHIP));
        commonCataBrandPropService.batchInsert(relationShipList);
    }
}
