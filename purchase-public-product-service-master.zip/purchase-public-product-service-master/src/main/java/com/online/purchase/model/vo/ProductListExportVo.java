package com.online.purchase.model.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:
 * @Author: loine
 * @Date: 2026/4/11 10:08
 */
@Data
@ApiModel("商品清单导入导出类")
public class ProductListExportVo {
    @ExcelProperty("商品ID")
    @ColumnWidth(20)
    @ApiModelProperty("商品ID")
    private String productId;
    @ExcelProperty("产品型号")
    @ColumnWidth(20)
    @ApiModelProperty("产品型号")
    private String productType;
    @ExcelProperty("厂家物料号")
    @ColumnWidth(20)
    @ApiModelProperty("订货号")
    private String skuCode;
    @ExcelProperty("产品品牌")
    @ColumnWidth(20)
    @ApiModelProperty("产品品牌")
    private String brandName;
    @ExcelProperty("产品系列")
    @ColumnWidth(20)
    @ApiModelProperty("产品系列")
    private String propName;
    @ExcelProperty("一级分类")
    @ColumnWidth(20)
    @ApiModelProperty("一级分类")
    private String firstLevelCataName;
    @ExcelProperty("二级分类")
    @ColumnWidth(20)
    @ApiModelProperty("二级分类")
    private String secondLevelCataName;
    @ExcelProperty("三级分类")
    @ColumnWidth(20)
    @ApiModelProperty("三级分类")
    private String threeLevelCataName;
    @ExcelProperty("规格名")
    @ColumnWidth(20)
    @ApiModelProperty("规格@规格名")
    private String specNameStr;
    @ExcelProperty("规格值")
    @ColumnWidth(20)
    @ApiModelProperty("规格@规格值")
    private String specValueStr;
}
