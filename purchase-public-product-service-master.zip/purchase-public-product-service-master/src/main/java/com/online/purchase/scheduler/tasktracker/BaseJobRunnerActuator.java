package com.online.purchase.scheduler.tasktracker;

import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;


/**
 * 任务执行器
 *
 * @author zhangcheng
 * @since 2022-08-18
 */
public interface BaseJobRunnerActuator {

    Result run(JobContext jobContext);

}
