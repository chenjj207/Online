-- 增加标记删除字段
ALTER TABLE t_pd_common_prop ADD COLUMN deleted boolean DEFAULT FALSE COMMENT '标记删除';
ALTER TABLE t_pd_common_prop ADD COLUMN source VARCHAR(20) COMMENT '数据来源(GYL_ADD:供应链新增(用于标识定时任务不可删除))';
ALTER TABLE t_pd_common_catalog ADD COLUMN deleted boolean DEFAULT FALSE COMMENT '标记删除';
ALTER TABLE t_pd_common_catalog ADD COLUMN source VARCHAR(20) COMMENT '数据来源(GYL_ADD:供应链新增(用于标识定时任务不可删除))';
ALTER TABLE t_pd_common_spec ADD COLUMN deleted boolean DEFAULT FALSE COMMENT '标记删除';
ALTER TABLE t_pd_common_spec ADD COLUMN source VARCHAR(20) COMMENT '数据来源(GYL_ADD:供应链新增(用于标识定时任务不可删除))';
ALTER TABLE t_pd_common_spec_val ADD COLUMN deleted boolean DEFAULT FALSE COMMENT '标记删除';
ALTER TABLE t_pd_common_spec_val ADD COLUMN source VARCHAR(20) COMMENT '数据来源(GYL_ADD:供应链新增(用于标识定时任务不可删除))';
-- 增加供应商冗余字段
ALTER TABLE t_pd_common_product ADD COLUMN supply_price DECIMAL(15, 4) COMMENT '供货价';
ALTER TABLE t_pd_common_product ADD COLUMN purchase_price DECIMAL(15, 4) COMMENT '慧采价';
ALTER TABLE t_pd_common_product ADD COLUMN suggest_price DECIMAL(15, 4) COMMENT '建议零售价';
ALTER TABLE t_pd_common_product ADD COLUMN delivery_date VARCHAR(200) COMMENT '货期';
ALTER TABLE t_pd_common_product ADD COLUMN audit_time DATETIME COMMENT '审核时间';
ALTER TABLE t_pd_common_product ADD COLUMN supplier_id VARCHAR(32) COMMENT '供应商id';
-- 增加通知租户状态字段
ALTER TABLE t_pd_common_product ADD COLUMN sync_status int(0) NULL COMMENT '通知租户状态（1：等待通知，2：已通知）';
ALTER TABLE t_pd_common_product_spec ADD COLUMN sync_status int(0) NULL COMMENT '通知租户状态（1：等待通知，2：已通知）';
ALTER TABLE t_pd_common_brand ADD COLUMN sync_status int(0) NULL COMMENT '通知租户状态（1：等待通知，2：已通知）';
ALTER TABLE t_pd_common_prop ADD COLUMN sync_status int(0) NULL COMMENT '通知租户状态（1：等待通知，2：已通知）';
ALTER TABLE t_pd_common_catalog ADD COLUMN sync_status int(0) NULL COMMENT '通知租户状态（1：等待通知，2：已通知）';
ALTER TABLE t_pd_common_spec ADD COLUMN sync_status int(0) NULL COMMENT '通知租户状态（1：等待通知，2：已通知）';
ALTER TABLE t_pd_common_spec_val ADD COLUMN sync_status int(0) NULL COMMENT '通知租户状态（1：等待通知，2：已通知）';
-- 修改字段长度
alter table online_common.t_pd_common_es modify searchset varchar(1000) comment '搜索集';
alter table online_common.t_pd_common_es modify spec_vals varchar(1000) comment '规格参数';
alter table online_common.t_pd_common_es modify specs varchar(1000) comment '规格值:规格参数';
--  todo GROUP_CONCAT()长度不够 要放在my.ini中 否则重启后失效
SET SESSION group_concat_max_len = 10240000;
SET GLOBAL group_concat_max_len = 10240000;
