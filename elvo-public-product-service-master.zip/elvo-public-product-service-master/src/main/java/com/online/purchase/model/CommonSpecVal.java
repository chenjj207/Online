package com.online.purchase.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Collection;

/**
 * 规格值 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Getter
@Setter
@ToString
@Accessors(chain = true)
@ApiModel(value = "CommonSpecVal", description = "规格值")
@Table(name = "elvo_common.t_pd_common_spec_val")
public class CommonSpecVal extends BaseCorpModel {

    public static final String SPEC_VALUE_ID = "specValueId";
    public static final String SPEC_ID = "specId";
    public static final String SPEC_VALUE = "specValue";
    public static final String SORT = "sort";
    public static final String IS_VALID = "isValid";
    public static final String REMARK = "remark";
    public static final String DELETED = "deleted";
    public static final String SOURCE = "source";
    public static final String SYNC_STATUS = "syncStatus";

    /**
     * 规格值ID
     */
    @ApiModelProperty(value = "规格值ID")
    private Long specValueId;

    /**
     * 规格编码
     */
    @ApiModelProperty(value = "规格编码")
    private Long specId;

    /**
     * 具体参数值
     */
    @ApiModelProperty(value = "具体参数值")
    private String specValue;

    /**
     * 排序
     */
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /**
     * 是否有效
     */
    @ApiModelProperty(value = "是否有效")
    private String isValid;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 删除标识
     */
    private Boolean deleted;

    /**
     * 数据来源
     */
    private String source;

    /**
     * 通知租户状态（1：等待通知，2：已通知）
     */
    @ApiModelProperty(value = "通知租户状态（1：等待通知，2：已通知）")
    private Integer syncStatus;

    /**
     * 规格名称
     */
    @Transient
    private String specName;

    /**
     * 规格编码集合
     */
    @Transient
    private Collection<Long> specIds;

    /**
     * 规格值ID集合
     */
    @Transient
    private Collection<Long> specValIds;

    /**
     * 具体参数值集合
     */
    @Transient
    private Collection<String> specValues;
}
