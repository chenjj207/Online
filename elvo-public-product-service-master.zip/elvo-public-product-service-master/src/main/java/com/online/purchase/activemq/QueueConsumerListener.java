package com.online.purchase.activemq;

import com.online.purchase.service.CommonProductService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author jidonglin
 * @Description: 商家队列消费
 * @date 2024/12/24  14:30
 */
@Component
@Slf4j
public class QueueConsumerListener {

    @Resource
    private CommonProductService commonProductService;

    // 导出
    @JmsListener(destination = "${mq.queue.task.elvo-public-product-export}", containerFactory = "queueListener", concurrency = "1")
    public void readProductExportQueue(String message) {
        commonProductService.readProductExportQueue(message);
    }

}
