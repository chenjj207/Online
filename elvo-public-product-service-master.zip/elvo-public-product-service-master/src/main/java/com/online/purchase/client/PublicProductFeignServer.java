package com.online.purchase.client;

import cn.hutool.core.bean.BeanUtil;
import com.online.purchase.model.CommonCataBrandProp;
import com.online.purchase.model.dto.ProductListDTO;
import com.online.purchase.model.vo.ProductVo;
import com.online.purchase.service.CommonProductService;
import com.purchase.model.PurchaseProductSync;
import com.purchase.model.dto.CommonProductDto;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 公海对外提供服务接口
 *
 * @author zhangcheng
 * @since 2022-08-17
 */
@RestController
@RequestMapping(value = "/publicProductFeign")
public class PublicProductFeignServer {

    @Resource
    private CommonProductService commonProductService;

    @PostMapping(value = "/public/elvoProductSync")
    @ApiOperation(value = "产品同步至公海")
    public JsonResult<Long> purchaseProductSync(@RequestBody PurchaseProductSync purchaseProductSync) {
        return new JsonResult<>(true, "产品同步至公海成功", commonProductService.purchaseProductSync(purchaseProductSync));
    }

    @PostMapping(value = "/public/elvoProductList")
    @ApiOperation(value = "慧采列表")
    public List<ProductVo> getList(@RequestBody @Validated ProductListDTO productListDTO) {
        return commonProductService.list(productListDTO).stream()
                .map(p -> {
                    Map<String, String> specMap = commonProductService.handleSpecToTwoColumn(p.getSpecData());
                    p.setSpecName(specMap.getOrDefault("specName", ""));  // 添加默认值防止NPE
                    p.setSpecValue(specMap.getOrDefault("specValue", ""));
                    return p;
                })
                .collect(Collectors.toList());
    }

  /*  @PostMapping(value = "/public/listProductByProductIds")
    @ApiOperation(value = "根据产品id获取产品集合")
    public List<CommonProductDto> listProductByProductIds(@RequestBody List<Long> productIds) {
        return commonProductService.listProductByProductIds(productIds);
    }*/

  /*  @PostMapping(value = "/public/checkCataAndCode")
    @ApiOperation(value = "校验分类名称与erpCode")
    public JsonResult checkCataAndCode(@RequestBody PurchaseProductSync purchaseProductSync) {
        return commonProductService.checkCataAndCode(purchaseProductSync.getFirstLevelCataName(),
                                                    purchaseProductSync.getSecondLevelCataName(),
                                                    purchaseProductSync.getThreeLevelCataName(),
                                                    purchaseProductSync.getProductErpCode(),
                                                    purchaseProductSync.getPublicProductId());
    }*/

 /*   @PostMapping(value = "/public/fndExistProductCode")
    @ApiOperation(value = "根据产品code获取产品集合")
    List<CommonProductDto> fndExistProductCode(@RequestBody List<String> productCodes) {
        return commonProductService.fndExistProductCode(productCodes);
    }*/

    @GetMapping(value = "/public/listCataBrandProp")
    @ApiOperation(value = "查询三方关系集合")
    public List<Map<String, String>> listCataBrandProp() {
        List<CommonCataBrandProp> commonCataBrandPropList = commonProductService.listBrandCataPropSpecData();
        List<Map<String,String>> list = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(commonCataBrandPropList)) {
            for (CommonCataBrandProp commonCataBrandProp:commonCataBrandPropList) {
                if (null != commonCataBrandProp) {
                    Map<String,String> map = new HashMap<>(6);
                    if(BeanUtil.isNotEmpty(commonCataBrandProp.getCataName())){
                        String [] cataName = commonCataBrandProp.getCataName().split("@");
                        if(cataName.length!=0){
                            List<String> list1 = Arrays.asList(cataName);
                            map.put("threeCataName", null == list1.get(2)?null:list1.get(2));
                            map.put("secondCataName", null == list1.get(1)?null:list1.get(1));
                            map.put("firstCataName", null == list1.get(0)?null:list1.get(0));
                        }
                    }
                    map.put("brandName", commonCataBrandProp.getBrandName());
                    map.put("propName", commonCataBrandProp.getPropName());
                    map.put("specName", commonCataBrandProp.getSpecName());
                    list.add(map);
                }
            }
        }
        return list;
    }

 /*   @PostMapping(value = "/public/purchaseProductListById")
    @ApiOperation(value = "根据产品id获取产品集合")
    List<PurchaseCommonProductDto>  PurchaseProductListById(@RequestBody List<Long> productIds) {
        return commonProductService.PurchaseProductListById(productIds);
    }*/

  /*  @PostMapping(value = "/public/purchaseZydmallAdd")
    @ApiOperation(value = "zydmall商品上架列表添加")
    public JsonResult purchaseZydmallAdd(@RequestBody List<Long> productIds) {
        ProductZydmallIdDTO productZydmallIdDTO = new ProductZydmallIdDTO();
        productZydmallIdDTO.setProductIds(productIds);
        return new JsonResult<>(true, "操作成功", commonProductService.zydmallAdd(productZydmallIdDTO));
    }*/

 /*   @PostMapping(value = "/public/purchaseZydmallDelete")
    @ApiOperation(value = "zydmall商品上架列表删除")
    public JsonResult purchaseZydmallDelete(@RequestBody List<Long> productIds) {
        ProductZydmallIdDTO productZydmallIdDTO = new ProductZydmallIdDTO();
        productZydmallIdDTO.setProductIds(productIds);
        return new JsonResult<>(true, "操作成功", commonProductService.zydmallDelete(productZydmallIdDTO));
    }*/

}
