package com.online.purchase.model;

import com.purchase.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Collection;

/**
 * 产品系列--公海基础 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Getter
@Setter
@ToString
@Accessors(chain = true)
@ApiModel(value = "CommonProp", description = "产品系列--公海基础")
@Table(name = "elvo_common.t_pd_common_prop")
public class CommonProp extends PageBean<CommonProp> {

    public static final String PROP_ID = "propId";
    public static final String BRAND_ID = "brandId";
    public static final String PROP_NAME = "propName";
    public static final String PROP_ALIAS = "propAlias";
    public static final String PROP_NAME_LETTER = "propNameLetter";
    public static final String SORT = "sort";
    public static final String IS_VALID = "isValid";
    public static final String REMARK = "remark";
    public static final String DELETED = "deleted";
    public static final String SOURCE = "source";
    public static final String SYNC_STATUS = "syncStatus";

    /**
     * 系列编码
     */
    @ApiModelProperty(value = "系列编码")
    private Long propId;

    /**
     * 品牌编码
     */
    @ApiModelProperty(value = "品牌编码")
    private Long brandId;

    /**
     * 系列名
     */
    @ApiModelProperty(value = "系列名")
    private String propName;

    /**
     * 系列别名
     */
    @ApiModelProperty(value = "系列别名")
    private String propAlias;

    /**
     * 名称首字母
     */
    @ApiModelProperty(value = "名称首字母")
    private String propNameLetter;

    /**
     * 排序
     */
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /**
     * 是否有效 Y：是 N：否
     */
    @ApiModelProperty(value = "是否有效 Y：是 N：否")
    private String isValid;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 标记删除
     */
    private Boolean deleted;

    /**
     * 数据来源
     */
    private String source;

    /**
     * 通知租户状态（1：等待通知，2：已通知）
     */
    @ApiModelProperty(value = "通知租户状态（1：等待通知，2：已通知）")
    private Integer syncStatus;

    /**
     * 关键字查询(编码/名称)
     */
    @Transient
    private String keywords;

    /**
     * 关联品牌
     */
    @Transient
    private CommonBrand commonBrand;

    /**
     * 编号集合
     */
    @Transient
    private Collection<Long> propIds;

    /**
     * 批量参数
     */
    @Transient
    private String text;

}
