package com.online.purchase.service;

import cn.hutool.extra.pinyin.PinyinUtil;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Maps;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.mapper.CommonPropMapper;
import com.online.purchase.model.CommonBrand;
import com.online.purchase.model.CommonProduct;
import com.online.purchase.model.CommonProp;
import com.online.purchase.utils.RedisUtil;
import com.online.purchase.utils.ReflectUtils;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * CommonPropService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Service
public class CommonPropService extends BaseServiceImpl<CommonProp> {

    @Resource
    private CommonPropMapper commonPropMapper;
    @Resource
    private CommonProductService commonProductService;
    @Resource
    private CommonBrandService commonBrandService;
    @Resource
    private RedisTemplate redisTemplate;

    private static final String[] FIELD_LIST = {"brandId","propId","propName"};

    /**
     * 根据条件，获取所有数据
     *
     * @param commonProp 条件
     * @return 数据集合
     */
    @Transactional(readOnly = true)
    public List<CommonProp> listAll(CommonProp commonProp) {
        if (null == commonProp) {
            return commonPropMapper.selectAll();
        }

        return commonPropMapper.selectAllByCondition(commonProp);
    }

    /**
     * 分页列表
     *
     * @param commonProp 条件
     * @param page       分页对象
     * @return 系列列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<CommonProp> search(CommonProp commonProp, Page<CommonProp> page) {
        Assert.notNull(commonProp, "commonProp can not be null!");
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<CommonProp> list = commonPropMapper.search(commonProp);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }

        page = new Page<>(list);
        packCommonPropData(list);
        return page;
    }

    private Example genConditionExample(CommonProp model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        String id = model.getId();
        if (StringUtils.isNotEmpty(id)) {
            criteria.andEqualTo(CommonProp.ID, id);
        }

        Boolean deleted = model.getDeleted();
        if (null != deleted) {
            criteria.andEqualTo(CommonProp.DELETED, deleted);
        }

        Long propId = model.getPropId();
        if (null != propId) {
            criteria.andEqualTo(CommonProp.PROP_ID, propId);
        }

        Long brandId = model.getBrandId();
        if (null != brandId) {
            criteria.andEqualTo(CommonProp.BRAND_ID, brandId);
        }

        String propName = model.getPropName();
        if (StringUtils.isNotBlank(propName)) {
            criteria.andEqualTo(CommonProp.PROP_NAME, propName);
        }

        String propAlias = model.getPropAlias();
        if (StringUtils.isNotBlank(propAlias)) {
            criteria.andEqualTo(CommonProp.PROP_ALIAS, propAlias);
        }

        String propNameLetter = model.getPropNameLetter();
        if (StringUtils.isNotBlank(propNameLetter)) {
            criteria.andEqualTo(CommonProp.PROP_NAME_LETTER, propNameLetter);
        }

        Collection<Long> propIds = model.getPropIds();
        if (CollectionUtils.isNotEmpty(propIds)) {
            criteria.andIn(CommonProp.PROP_ID, propIds);
        }

        Integer syncStatus = model.getSyncStatus();
        if (null != syncStatus) {
            criteria.andEqualTo(CommonProp.SYNC_STATUS, syncStatus);
        }

        return example;
    }

    /**
     * 分页数据处理
     */
    private void packCommonPropData(List<CommonProp> commonPropList) {
        if (CollectionUtils.isEmpty(commonPropList)) {
            return;
        }

        // 关联品牌
        Set<Long> brandIds = commonPropList.stream().map(CommonProp::getBrandId).collect(Collectors.toSet());
        if (CollectionUtils.isEmpty(brandIds)) {
            return;
        }

        List<CommonBrand> brandList = commonBrandService.listAll(new CommonBrand().setBrandIds(brandIds));
        if (CollectionUtils.isEmpty(brandList)) {
            return;
        }

        Map<Long, CommonBrand> brandIdMap = brandList.stream().collect(Collectors.toMap(CommonBrand::getBrandId, c -> c));
        for (CommonProp prop : commonPropList) {
            prop.setCommonBrand(brandIdMap.get(prop.getBrandId()));
        }
    }

    /**
     * 通过id获取详情
     */
    @Override
    public CommonProp get(String id) {
        return super.get(id);

    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(CommonProp commonProp) {
        Assert.notNull(commonProp, "commonProp can not be null");
        Example example = genConditionExample(commonProp);
        example.selectProperties(CommonProp.ID);
        List<CommonProp> commonPropList = commonPropMapper.selectByExample(example);
        return CollectionUtils.isEmpty(commonPropList) ? new ArrayList<>(0) :
                commonPropList.stream().map(CommonProp::getId).collect(Collectors.toList());
    }

    /**
     * 新增
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String add(CommonProp commonProp, String source) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonProp)
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonProp.getPropName())
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonProp.getBrandId());
        // 新增
        String propName = commonProp.getPropName();
        Long brandId = commonProp.getBrandId();
        if (!PuPrConstants.EDIT.equals(source)) {
            int maxSort = commonProp.getSort() == null ? commonPropMapper.getMaxPropSort() + 1 : commonProp.getSort();
            commonProp.setPropId(genPropId());
            commonProp.setIsValid(PuPrConstants.IS_VALID_Y);
            commonProp.setSort(maxSort);
        }

        // 名称重复校验
        validatePropName(propName, brandId);
        commonProp.setPropNameLetter(PinyinUtil.getFirstLetter(propName, "").substring(0, 1).toUpperCase());
        commonProp.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        return super.insert(commonProp);
    }

    /**
     * 批量新增
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> batchAdd(List<CommonProp> commonProps, String source) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonProps);
        // 校验名称是否重复
        Set<String> propNames = commonProps.stream()
                .map(CommonProp::getPropName)
                .collect(Collectors.toSet());
        if (propNames.size() != commonProps.size()) {
            throw new BaseException(PuPrErrorCode.COMMON_PROP_NAME_ERROR);
        }

        // 批量处理
        commonProps.forEach(commonProp -> {
            CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR)
                    .isNotNull(commonProp)
                    .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonProp.getPropName())
                    .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonProp.getBrandId());

            String propName = commonProp.getPropName();
            Long brandId = commonProp.getBrandId();
            if (!PuPrConstants.EDIT.equals(source)) {
                int maxSort = commonProp.getSort() == null ? commonPropMapper.getMaxPropSort() + 1 : commonProp.getSort();
                commonProp.setPropId(genPropId());
                commonProp.setIsValid(PuPrConstants.IS_VALID_Y);
                commonProp.setSort(maxSort);
            }
            // 名称重复校验
            validatePropName(propName, brandId);
            commonProp.setPropNameLetter(PinyinUtil.getFirstLetter(propName, "").substring(0, 1).toUpperCase());
            commonProp.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        });
        List<String> ids = super.batchInsert(commonProps);
        return ids;
    }

    /**
     * 名称重复校验
     *
     * @param propName 名称
     */
    private void validatePropName(String propName, Long brandId) {
        List<String> idList = listIdsByExample(new CommonProp().setPropName(propName).setBrandId(brandId).setDeleted(false));
        if (CollectionUtils.isEmpty(idList)) {
            return;
        }

        throw new BaseException(PuPrErrorCode.COMMON_PROP_NAME_ERROR);
    }

    /**
     * 修改
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void edit(CommonProp commonProp) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(commonProp)
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonProp.getPropName())
                .error(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonProp.getId());
        String id = commonProp.getId();
        CommonProp param = new CommonProp();
        param.setDeleted(false).setId(id);
        CommonProp prop = getByExample(param);
        if (null == prop) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }
        Boolean hasEdit = ReflectUtils.hasEdit(prop, commonProp, FIELD_LIST, this.entityClass);

        if (BooleanUtils.isTrue(hasEdit)) {
            // 标记删除
            CommonProp deletedProp = new CommonProp();
            deletedProp.setId(id);
            deletedProp.setDeleted(true);
            deletedProp.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
            super.update(deletedProp);
            // 新增
            commonProp.setId(null);
            commonProp.setCreatedAt(null);
            commonProp.setCreatedBy(null);
            commonProp.setUpdatedAt(null);
            commonProp.setUpdatedBy(null);
            commonProp.setIsValid(prop.getIsValid());
            commonProp.setPropAlias(prop.getPropAlias());
            commonProp.setRemark(prop.getRemark());
            Long propId = genPropId();
            commonProp.setPropId(propId);
            commonProp.setSource(prop.getSource());
            commonProp.setBrandId(prop.getBrandId());
            add(commonProp, PuPrConstants.EDIT);
            // 关联关系-商品
            commonProductService.batchUpdatePropId(prop.getPropId(), propId);
        } else {
            this.update(commonProp);
        }

    }

    @Transactional(readOnly = true)
    public CommonProp getByExample(CommonProp prop) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(prop);
        Example example = genConditionExample(prop);
        return commonPropMapper.selectOneByExample(example);
    }

    /**
     * 生成系列编号
     *
     * @return 编号
     */
    private Long genPropId() {
        return RedisUtil.genCode("common_prop_id", redisTemplate, () -> {
            return commonPropMapper.getMaxPropId();
        });
    }

    /**
     * 标记删除
     *
     * @param id 主键
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void deleteById(String id) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(id);
        CommonProp param = new CommonProp();
        param.setDeleted(false).setId(id);
        CommonProp prop = getByExample(param);
        if (null == prop) {
            throw new BaseException(PuPrErrorCode.DATA_EMPTY_ERROR);
        }

        // 慧采商品关联校验
        Long propId = prop.getPropId();
        List<String> productIdList = commonProductService.listIdsByExample(new CommonProduct().setPropId(propId));
        if (CollectionUtils.isNotEmpty(productIdList)) {
            throw new BaseException(PuPrErrorCode.COMMON_PROP_EXIST_PRODUCT_ERROR);
        }

        CommonProp commonProp = new CommonProp();
        commonProp.setId(id);
        commonProp.setDeleted(true).setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        super.update(commonProp);
    }

    /**
     * 根据品牌编号，批量修改品牌编号关联
     *
     * @param oldBrandId 原品牌编号
     * @param brandId    品牌编号
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void batchUpdateBrandId(Long oldBrandId, Long brandId) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(oldBrandId).isNotNull(brandId);
        commonPropMapper.batchUpdateBrandId(oldBrandId, brandId);
    }

    public Long syncProp(String propName, Long brandId, String productSrc) {
        if (StringUtils.isEmpty(propName)) {
            return null;
        }
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CommonProp.PROP_NAME, propName);
        criteria.andEqualTo(CommonProp.DELETED, false);
        if (brandId != null){
            criteria.andEqualTo(CommonProp.BRAND_ID, brandId);
        }

        List<CommonProp> propList = commonPropMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(propList)) {
            return propList.get(0).getPropId();
        }
        CommonProp commonProp = new CommonProp();
        Long propId = genPropId();
        commonProp.setPropId(propId);
        commonProp.setBrandId(brandId);
        commonProp.setPropName(propName);
        commonProp.setIsValid(PuPrConstants.IS_VALID_Y);
        commonProp.setSort(1);
        commonProp.setPropNameLetter(PinyinUtil.getFirstLetter(propName, "").substring(0, 1).toUpperCase());
        commonProp.setSyncStatus(PuPrConstants.PRODUCT_WAIT_SYNC);
        commonProp.setSource(StringUtils.equalsIgnoreCase(productSrc, "ZYDMALL") ? "zydmall" : PuPrConstants.ELVO_PRODUCT_APPLY);
        super.insert(commonProp);
        return propId;
    }

    /**
     * 根据编号，获取编号名称map
     *
     * @param propIds 编号
     * @return 编号名称map
     */
    @Transactional(readOnly = true)
    public Map<Long, String> mapNameByPropIds(Set<Long> propIds) {
        Map<Long, String> resMap = Maps.newHashMap();
        if (CollectionUtils.isEmpty(propIds)) {
            return resMap;
        }

        List<CommonProp> list = listByCondition(new CommonProp().setPropIds(propIds));
        if (CollectionUtils.isEmpty(list)) {
            return resMap;
        }

        resMap = list.stream().collect(Collectors.toMap(CommonProp::getPropId, CommonProp::getPropName));
        return resMap;
    }

    /**
     * 根据条件，获取对象集合
     *
     * @param prop 条件
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public List<CommonProp> listByCondition(CommonProp prop, String... properties) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(prop);
        Example example = genConditionExample(prop);
        example.selectProperties(properties);
        return commonPropMapper.selectByExample(example);
    }

    /**
     * 获取侍标记删除数据-用于定时任务
     *
     * @return 主键集合
     */
    @Transactional(readOnly = true)
    public Set<String> listIdsToDel() {
        return commonPropMapper.listIdsToDel();
    }

    public List<CommonProp> listByPropIds(Set<Long> propIds) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andIn(CommonProp.PROP_ID, propIds);
        return commonPropMapper.selectByExample(example);
    }

    /**
     * 批量新增产品系列参数解析
     * @param commonProp
     * @return
     */
    public List<CommonProp> parseCommonProp(CommonProp commonProp) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotEmpty(commonProp.getText());
        List<CommonProp> commonProps = new ArrayList<>();
        String[] lines = commonProp.getText().split("\n");

        for (String line : lines) {
            if (line.trim().isEmpty()) {
                continue;
            }
            if (line.length() > 255) {
                throw new BaseException(PuPrErrorCode.DATA_ERROR.getCode(), "系列名称长度不能超过255");
            }
            CommonProp newProp = new CommonProp();
            newProp.setPropName(line);
            newProp.setBrandId(commonProp.getBrandId());
            newProp.setSource(commonProp.getSource());
            commonProps.add(newProp);
        }
        return commonProps;
    }
}
