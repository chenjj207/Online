package com.online.purchase.mapper;

import com.online.purchase.model.CommonSpec;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

/**
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
public interface CommonSpecMapper extends QguBaseMapper<CommonSpec> {

    /**
     * 根据 specIds 查询数据
     * @param specIds
     * @return
     */
    List<CommonSpec> selectListBySpecIds(@Param("specIds") List<Long> specIds);

    /**
     * 根据实体字段条件获取对应实体集合--分页公用（分页由PageHelper实现-解耦合）
     *
     * @param commonSpec 实体对象
     * @return 对象集合
     */
    List<CommonSpec> search(@Param("commonSpec") CommonSpec commonSpec);

    /**
     * 根据分类编号，批量修改分类编号关联
     *
     * @param oldCataId 原分类编号
     * @param cataId    分类编号
     */
    void batchUpdateCataId(Long oldCataId, Long cataId);

    /**
     * 获取规格编号最大值
     *
     * @return
     */
    Long getMaxSpecId();

    /**
     * 获取分类下，规格的最大排序
     * @return
     */
    Integer getMaxSpecSort(@Param("cataId")Long cataId);

    /**
     * 获取侍标记删除数据-用于定时任务
     *
     * @return 主键集合
     */
    Set<String> listIdsToDel();

    List<CommonSpec> listAllGroupByCataId();
}
