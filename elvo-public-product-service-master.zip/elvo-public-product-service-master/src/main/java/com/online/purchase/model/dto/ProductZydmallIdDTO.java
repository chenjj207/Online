/*
package com.online.purchase.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@ApiModel("zydmall商品上架ID-入参")
public class ProductZydmallIdDTO {
    @ApiModelProperty("产品状态")
    private Integer productStatus;
    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;
    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;
    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;
    @ApiModelProperty("商品品牌名称")
    private String brandName;
    @ApiModelProperty("商品系列名称")
    private String propName;
    @ApiModelProperty("关键字")
    private String key;
    @ApiModelProperty("供应商id")
    private String supplierId;
    @ApiModelProperty("商品申请来源 来源： inquiry | publish")
    private String applySource;
    @ApiModelProperty(value = "产品来源")
    private String productSrc;
    @ApiModelProperty("产品型号列表")
    private List<String> productTypeList;
    @ApiModelProperty("商品id列表")
    private List<String> productIdList;
    @ApiModelProperty("厂家物料号列表")
    private List<String> skuCodeList;
    @ApiModelProperty("商品编码列表")
    private List<String> supplierProductCodeList;
    @ApiModelProperty("所属子公司")
    private String subCompany;
    @ApiModelProperty("zydmall上架标识 1：上架 0：未上架")
    private String zydmallFlag;
    @ApiModelProperty("包含的主键ids（全部传all）")
    private List<String> ids;
    @ApiModelProperty("不包含的主键ids")
    private List<String> notInIds;

    @ApiModelProperty(value = "产品id组")
    private List<Long> productIds;
}
*/
