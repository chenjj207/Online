package com.online.purchase.controller;

import cn.hutool.core.map.MapUtil;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.model.CommonSpec;
import com.online.purchase.service.CommonSpecService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * CommonSpecController 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@RestController
@RequestMapping(value = "/elvo-common-spec")
@Api(value = "CommonSpecController", tags = {"公海规格服务"})
public class CommonSpecController {

    @Resource
    private CommonSpecService commonSpecService;

    @PostMapping(value = "/list")
    @ApiOperation(value = "第三级查看接口-分类下规格名称接口")
    public JsonResult<List<CommonSpec>> list(@RequestBody CommonSpec commonSpec) {
        commonSpec.setDeleted(false);
        List<CommonSpec> specList = commonSpecService.listByCondition(commonSpec);
        return new JsonResult<>(true, "查询成功", specList);
    }

    @PostMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    public JsonResult<Page<CommonSpec>> search(@RequestBody CommonSpec commonSpec) {
        commonSpec.setDeleted(false);
        Page<CommonSpec> page = commonSpec.getPage();
        page = null == page ? new Page<>() : page;
        page = commonSpecService.search(commonSpec, page);
        return new JsonResult<>(true, "查询成功", page);
    }

    @PostMapping("/add")
    @ApiOperation(value = "供应链新增接口")
    public JsonResult<Map<String, String>> addCommonSpec(@RequestBody CommonSpec commonSpec) {
        commonSpec.setSource(PuPrConstants.ELVO_PRODUCT_APPLY);
        String id = commonSpecService.add(commonSpec);
        Map<String, String> data = MapUtil.newHashMap(1);
        data.put("id", id);
        return new JsonResult<>(true, "添加成功", data);
    }

    @PostMapping("/batchAdd")
    @ApiOperation(value = "规格批量新增接口")
    public JsonResult<Map<String, List<String>>> batchAddCommonSpec(@RequestBody CommonSpec commonSpec) {
        commonSpec.setSource(PuPrConstants.ELVO_PRODUCT_APPLY);
        List<CommonSpec> commonSpecs = commonSpecService.parseCommonSpec(commonSpec);
        List<String> ids = commonSpecService.batchAdd(commonSpecs);
        Map<String, List<String>> data = MapUtil.newHashMap(1);
        data.put("ids", ids);
        return new JsonResult<>(true, "添加成功", data);
    }

    @PostMapping("/update")
    @ApiOperation(value = "供应链编辑接口")
    public JsonResult editCommonSpec(@RequestBody @Check(field = {"id"}) CommonSpec commonSpec) {
        //commonSpec.setSource(PuPrConstants.ELVO_PRODUCT_APPLY);
        String id = commonSpecService.edit(commonSpec);
        Map<String, String> data = MapUtil.newHashMap(1);
        data.put("id", id);
        return new JsonResult(true, "编辑成功", data);
    }

    @PostMapping(value = "/detail")
    @ApiOperation(value = "根据id获取数据")
    public JsonResult<CommonSpec> getCommonSpec(@RequestBody @Check(field = {"id"}) CommonSpec commonSpec) {
        return new JsonResult<>(true, "查询成功", commonSpecService.getById(commonSpec.getId()));
    }

    @PostMapping(value = "/del")
    @ApiOperation(value = "根据传入的Id，标记删除数据")
    public JsonResult<String> delete(@RequestBody @Check(field = {"id"}) CommonSpec commonSpec) {
        commonSpecService.deleteById(commonSpec.getId());
        return new JsonResult<>(true, "删除成功");
    }

    @PostMapping(value = "/listAll")
    @ApiOperation(value = "第三级查看接口-分类下规格名称及规格值接口")
    public JsonResult<List<CommonSpec>> listAll(@RequestBody CommonSpec commonSpec) {
        if (null == commonSpec || null == commonSpec.getCataId()) {
            return new JsonResult<>(true, "查询成功", Collections.emptyList());
        }
        commonSpec.setDeleted(false);
        List<CommonSpec> specList = commonSpecService.listAll(commonSpec);
        return new JsonResult<>(true, "查询成功", specList);
    }
}
