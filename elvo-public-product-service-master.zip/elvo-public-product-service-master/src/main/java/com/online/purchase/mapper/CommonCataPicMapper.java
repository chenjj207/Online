/*
package com.online.purchase.mapper;

import com.online.purchase.model.CommonCataPic;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


*/
/**
 * 公海分类图片url Mapper
 *
 * @author jdl
 *//*

public interface CommonCataPicMapper extends QguBaseMapper<CommonCataPic> {


    List<CommonCataPic> selectCataInfo();

    int deleteAll();
}
*/
