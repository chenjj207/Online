/*
package com.online.purchase.model;

import com.qgutech.qgyun.framework.database.model.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;

*/
/**
 * 公海分类图片url model
 *
 * @author jdl
 *//*

@Getter
@Setter
@ToString
@ApiModel(value = "CommonCataPic", description = "")
@Table(name = "t_pd_common_cata_pic")
public class CommonCataPic extends BaseModel {

    */
/**
     * 三级分类ID
     *//*

    @ApiModelProperty(value = "三级分类ID")
    private Long cataId;

    */
/**
     * 产品id
     *//*

    @ApiModelProperty(value = "产品id")
    private Long productId;


    */
/**
     * 产品图名称
     *//*

    @ApiModelProperty(value = "产品图名称")
    private String productPicName;

    */
/**
     * 一级分类名称
     *//*

    @ApiModelProperty(value = "一级分类名称")
    private String oneCataName;

    */
/**
     * 二级分类名称
     *//*

    @ApiModelProperty(value = "二级分类名称")
    private String twoCataName;

    */
/**
     * 三级分类名称
     *//*

    @ApiModelProperty(value = "三级分类名称")
    private String threeCataName;

    */
/**
     * 分类名称
     *//*

    @ApiModelProperty(value = "分类名称")
    private String cataName;

    */
/**
     * 系列名称
     *//*

    @ApiModelProperty(value = "系列名称")
    private String propName;


    */
/**
     * 品牌名称
     *//*

    @ApiModelProperty(value = "品牌名称")
    private String brandName;

    */
/**
     * 产品来源
     *//*

    @ApiModelProperty(value = "产品来源")
    private String productSrc;

}
*/
