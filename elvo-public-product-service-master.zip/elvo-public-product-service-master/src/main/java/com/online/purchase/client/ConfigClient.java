package com.online.purchase.client;

import com.alibaba.fastjson.JSONObject;
import com.online.purchase.client.dto.CheckProductDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;


/**
 * 搜索对外服务接口
 */
@FeignClient(value = "purchase-config-service")
public interface ConfigClient {

/*    @PostMapping("/purchase-store-product/check-store-product")
    public JSONObject checkProduct(@RequestBody @Validated CheckProductDTO checkProductDTO);*/
}
