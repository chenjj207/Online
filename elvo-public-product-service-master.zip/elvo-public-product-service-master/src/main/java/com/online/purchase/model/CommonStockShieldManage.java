/*
package com.online.purchase.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

*/
/**
 * 产品系列--公海库存屏蔽管理 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 *//*

@Getter
@Setter
@ToString
@Accessors(chain = true)
@ApiModel(value = "CommonStockShieldManage", description = "产品系列--公海库存屏蔽管理")
@Table(name = "online_common.t_pd_stock_shield_manage")
public class CommonStockShieldManage {

    */
/**
     * 业务主键
     *//*

    @Id
    private Integer id;

    */
/**
     * 创建者
     *//*

    @ApiModelProperty(value = "创建人", hidden = true)
    private String createdBy;

    */
/**
     * 创建时间
     *//*

    @ApiModelProperty(value = "创建时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createdAt;

    */
/**
     * 最后更新者
     *//*

    @ApiModelProperty(value = "更新人", hidden = true)
    private String updatedBy;

    */
/**
     * 更新时间
     *//*

    @ApiModelProperty(value = "更新时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime updatedAt;

    */
/**
     * 屏蔽属性，字段名
     *//*

    @ApiModelProperty(value = "屏蔽属性，字段名")
    private String typeKey;

    */
/**
     * 具体属性名或单品的商品id
     *//*

    @ApiModelProperty(value = "具体属性名或单品的商品id")
    private String propertyValue;

    @ApiModelProperty(value = "公司编号", hidden = true)
    private String corpCode;

}
*/
