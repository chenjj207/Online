/*
package com.online.purchase.service;

import com.github.pagehelper.PageHelper;
import com.online.purchase.base.exception.PuPrErrorCode;
import com.online.purchase.client.ESClient;
import com.online.purchase.mapper.CommonEsMapper;
import com.online.purchase.model.CommonEs;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

*/
/**
 * 公海es 服务提供类
 *
 * @author lwl
 *//*

@Service
public class CommonEsService extends BaseServiceImpl<CommonEs> {

    @Resource
    private CommonEsMapper commonEsMapper;
    @Resource
    private ESClient esClient;

    */
/**
     * 清空数据
     *//*

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void deleteAll() {
        commonEsMapper.deleteAll();
    }

    */
/**
     * es重建
     *//*

   */
/* @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void rebuildEs(boolean onlySyncToES) {
        if (!onlySyncToES){
            deleteAll();
            commonEsMapper.rebuildEs();
        }
        //远程调用purchase-es接口，同步到elasticsearch
        esClient.syncDataToES();
    }*//*


    */
/**
     * 新增
     *//*

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void addByProductId(Long productId) {
        CheckFlow.start(PuPrErrorCode.PARAMS_EMPTY_ERROR).isNotNull(productId);
        this.delByProperty(CommonEs.PRODUCT_ID, productId);
        commonEsMapper.addByProductId(productId);
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<CommonEs> search(List<String> skuCodeOrTypeList, Page<CommonEs> page) {
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<CommonEs> list = commonEsMapper.selectSkuOrProduct(skuCodeOrTypeList);
        if (CollectionUtils.isEmpty(list)) {
            return page;
        }
        page = new Page<>(list);
        return page;
    }

    public List<CommonEs> productIdList(List<Long> productIdList){
        return commonEsMapper.selectByProductIdList(productIdList);
    }
}
*/
