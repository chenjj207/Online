package com.online.purchase.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;


/**
 * 搜索对外服务接口
 */
@FeignClient(value = "purchase-es")
public interface ESClient {

    /**
     * 同步数据到es
     * @return
     */
 /*   @PostMapping("/sync/init")
    public String syncDataToES();*/
}
