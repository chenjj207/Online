
package com.online.purchase.base;


/**
 * 任务常量
 *
 * @author gxh
 * @version 1.0
 * @since 2021-5-23
 */
public class JobConstant {

    /**
     * 任务类型-PRODUCT_STRUCTURE_DEL：公海产品结构无关联产品标记删除任务
     */
    public static final String PRODUCT_STRUCTURE_DEL = "PRODUCT_STRUCTURE_DEL";

    /**
     * 任务类型-PRODUCT_NOTICE：公海产品变更通知任务
     */
    public static final String PRODUCT_NOTICE = "PRODUCT_NOTICE";

    /**
     * 任务类型-PRODUCT_STRUCTURE_NOTICE：公海产品结构变更通知任务
     */
    public static final String PRODUCT_STRUCTURE_NOTICE = "PRODUCT_STRUCTURE_NOTICE";

    /**
     * 任务类型-TRIPARTITE_RELATIONSHIP：公海产品重建三方关系
     */
    public static final String TRIPARTITE_RELATIONSHIP = "TRIPARTITE_RELATIONSHIP";

    /**
     * 任务类型-ES_REBUILD：公海产品es重建任务
     */
    public static final String ES_REBUILD = "ES_REBUILD";

    /**
     * 任务类型-PRODUCT_MODI_REC：SCM产品基础信息变更任务
     */
    public static final String PRODUCT_MODI_REC = "PRODUCT_MODI_REC";

    /**
     * 任务类型-THREE_CATA_PIC：三级分类确定产品图
     */
    public static final String THREE_CATA_PIC = "THREE_CATA_PIC";

    /**
     * 任务类型KEY
     */
    public static final String TASK_TYPE_KEY = "type";

    /**
     * 任务触发时间KEY
     */
    public static final String TASK_TRIGGER_TIME_KEY = "triggerTime";

    /**
     * 执行表达式KEY
     */
    public static final String CRON_EXPRESSION_KEY = "cronExpression";

    /**
     * 任务ID分隔符
     */
    public static final String TASK_ID_SEPARATOR = "-";

}
