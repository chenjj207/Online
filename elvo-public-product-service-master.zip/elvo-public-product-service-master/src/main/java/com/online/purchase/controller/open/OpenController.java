
package com.online.purchase.controller.open;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import com.online.purchase.base.JobConstant;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.model.*;
import com.online.purchase.model.dto.SelectCommonProductDto;
import com.online.purchase.scheduler.jobclient.JobHandlerFactory;
import com.online.purchase.service.*;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import org.apache.commons.collections4.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 开放接口
 *
 * @author lwl
 */
@RestController
@RequestMapping(value = "/public")
public class OpenController {
    @Resource
    private JobHandlerFactory jobHandlerFactory;
    @Value("${product.tripartite.relationship.corn:}")
    private String tripartiteRelationshipCorn;



    /**
     * 创建公海产品重建三方关系定时任务
     */
    @PostMapping(value = "/tripartite-relationship")
    public JsonResult<Boolean> tripartiteRelationship(@RequestBody Map<String, Object> param) {
        String taskId = "公海产品重建三方关系定时任务";
        Map<String, String> paramMap = new HashMap<>(2);
        Object corn = param.get(JobConstant.CRON_EXPRESSION_KEY);
        tripartiteRelationshipCorn = null == corn ? tripartiteRelationshipCorn : (String) corn;
        paramMap.put(JobConstant.CRON_EXPRESSION_KEY, tripartiteRelationshipCorn);
        Object time = param.get(JobConstant.TASK_TRIGGER_TIME_KEY);
        if (null != time) {
            paramMap.put(JobConstant.TASK_TRIGGER_TIME_KEY, String.valueOf(DateUtil.parse((String) time).getTime()));
        }

        boolean success = jobHandlerFactory.create(taskId, JobConstant.TRIPARTITE_RELATIONSHIP, paramMap);
        return new JsonResult<>(true, "", success);
    }

}
