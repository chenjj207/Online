/*
package com.online.purchase.model.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentFontStyle;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
//@HeadFontStyle(color = 9, fontName = "微软雅黑", fontHeightInPoints = 12)
//@ContentFontStyle(fontName = "微软雅黑")
//@HeadStyle(fillForegroundColor = 49)
@Data
@ApiModel("关联ERP编码导入模板导入导出类")
public class ProductZydmallRelevanceErpVO {

    @ColumnWidth(18)
    @ExcelProperty("商品ID")
    @ApiModelProperty("商品ID")
    private String productId;
    @ColumnWidth(25)
    @ExcelProperty("所属子公司")
    @ApiModelProperty("所属子公司")
    private String subCompany;
    @ColumnWidth(27)
    @ExcelProperty("供应商")
    @ApiModelProperty("供应商")
    private String supplier;
    @ColumnWidth(26)
    @ExcelProperty("产品型号")
    @ApiModelProperty("产品型号")
    private String productType;
    @ColumnWidth(18)
    @ExcelProperty("厂家物料号")
    @ApiModelProperty("厂家物料号")
    private String materialName;
    @ColumnWidth(15)
    @ExcelProperty("产品品牌")
    @ApiModelProperty("产品品牌")
    private String brandName;
    @ColumnWidth(15)
    @ExcelProperty("产品系列")
    @ApiModelProperty("产品系列")
    private String propName;
    @ColumnWidth(15)
    @ExcelProperty("一级分类")
    @ApiModelProperty("一级分类")
    private String firstLevelCataName;
    @ColumnWidth(15)
    @ExcelProperty("二级分类")
    @ApiModelProperty("二级分类")
    private String secondLevelCataName;
    @ColumnWidth(15)
    @ExcelProperty("三级分类")
    @ApiModelProperty("三级分类")
    private String threeLevelCataName;
    @ColumnWidth(30)
    @ExcelProperty("关联ERP产品编码")
    @ApiModelProperty("关联ERP产品编码")
    private String erpProductCode;
    @ColumnWidth(20)
    @ExcelProperty("导入结果备注")
    @ApiModelProperty("导入结果备注")
    private String remark;

    @ExcelIgnore
    @ApiModelProperty("众业达商城ID")
    private Long zydProductId;
    @ExcelIgnore
    @ApiModelProperty("erp产品id")
    private Long erpProductId;
}
*/
