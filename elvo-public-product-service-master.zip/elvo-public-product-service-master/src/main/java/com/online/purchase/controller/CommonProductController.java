package com.online.purchase.controller;

import cn.hutool.core.io.IoUtil;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.*;
import com.online.purchase.config.OssConf;
import com.online.purchase.model.*;
import com.online.purchase.model.dto.ProductListDTO;
import com.online.purchase.model.vo.ProductVo;
import com.online.purchase.service.CommonProductService;
import com.online.purchase.service.CommonProductSpecService;
import com.online.purchase.service.dto.ProductIdDTO;
import com.purchase.exception.ExceptionDictionary;
import com.purchase.utils.excel.JxlsExcelView;
import com.purchase.model.dto.DetailResponse;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * CommonProductController 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@RestController
@Slf4j
@RequestMapping(value = "/elvo-common-product")
@Api(value = "CommonProductController", tags = {"公海产品服务"})
public class CommonProductController {

    @Resource
    private CommonProductService commonProductService;
    @Value("${oss.ossUrl:}")
    private String ossUrl;
    @Resource
    private OssConf ossConf;
    @Resource
    private CommonProductSpecService commonProductSpecService;
//    @Resource
//    private CommonEsService commonEsService;
/*
    private static final Collection<String> ZYDMALL_BRAND = Lists.newArrayList("施耐德","西门子", "ABB", "德力西", "菲尼克斯",
            "常熟", "上海人民", "天正电气", "乐超", "环宇", "杭申电气", "上海华通", "欧姆龙", "上海二工", "研华", "德威克", "罗格朗",
            "凯帆", "博世", "宝合", "天逸", "许继", "三利电气", "百塔", "得力", "WD-40", "宁容", "为乐电气", "常州森源");
*/


 /*   @PostMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    public JsonResult<Page<CommonProduct>> search(@RequestBody CommonProduct commonProduct) {
        Page<CommonProduct> page = commonProduct.getPage();
        page = null == page ? new Page<>() : page;
        //2023-05-22 去掉品牌限制
//        List<CommonBrand> brandList = commonBrandService.listByCondition(new CommonBrand().setDeleted(false).setBrandNames(ZYDMALL_BRAND));
//        commonProduct.setBrandIds(brandList.stream().map(CommonBrand::getBrandId).collect(Collectors.toSet()));
        page = commonProductService.search(commonProduct, page);
        return new JsonResult<>(true, "查询成功", page);
    }*/

 /*   @PostMapping(value = "/es/page")
    @ApiOperation(value = "获取分页")
    public JsonResult<Page<CommonEs>> esSearch(@RequestBody List<String> skuCodeOrTypeList) {
        Page<CommonEs> page = new Page<>();
        page = commonEsService.search(skuCodeOrTypeList, page);
        return new JsonResult<>(true, "查询成功", page);
    }*/

   /* @PostMapping(value = "/productId/list")
    @ApiOperation(value = "根据商品id列表获取商品")
    public JsonResult<List<CommonEs>> productIdList(@RequestBody List<Long> productIdList){
        List<CommonEs> commonEsList = commonEsService.productIdList(productIdList);
        return new JsonResult<>(true, "查询成功", commonEsList);
    }*/

   /* @PostMapping(value = "/erp-product-id-update")
    @ApiOperation(value = "编辑erp商品编码")
    public JsonResult<String> updateErpProductId(@RequestBody @Check(field = {"id"}) CommonProduct product) {
        commonProductService.updateErpProductId(product);
        return new JsonResult<>(true, "修改成功");
    }*/

  /*  @PostMapping(value = "/detail")
    @ApiOperation(value = "商品预览")
    public JsonResult<CommonProduct> getDetail(@RequestBody @Check(field = {"id"}) CommonProduct product) {
        product = commonProductService.getDetail(product.getId(),null);
        return new JsonResult<>(true, "查询成功", product);
    }*/

  /*  @PostMapping(value = "/detail2")
    @ApiOperation(value = "商品预览2")
    public JsonResult<CommonProduct> getDetail2(@RequestBody CommonProduct product) {
        product = commonProductService.getDetail(null,product.getProductId());
        return new JsonResult<>(true, "查询成功", product);
    }*/

    @PostMapping(value = "/detail1")
    @ApiOperation(value = "商品预览")
    public JsonResult<DetailResponse> baseXInfo(@RequestBody CommonProduct request) {
        return commonProductService.baseXInfo(request);
    }

  /*  @PostMapping(value = "/list")
    @ApiOperation(value = "获取分页")
    public JsonResult<Page<CommonProduct>> list(@RequestBody CommonProduct commonProduct) {
        Page<CommonProduct> page = commonProduct.getPage();
        page = null == page ? new Page<>() : page;
        log.info("commonProduct==={}", commonProduct);
        page = commonProductService.list(commonProduct, page);
        return new JsonResult<>(true, "查询成功", page);
    }*/

   /* @PostMapping("/list/excel")
    @ApiOperation("商品列表excel导出")
    public JsonResult<String> download(@RequestBody CommonProduct dto){
        List<CommonProduct> list = commonProductService.list(dto);
        String prefix = ossUrl+getOssCorpCode();
        for (CommonProduct commonProduct : list) {
            // 格式化价格
            commonProduct.setPrice((null == commonProduct.getPrice()) ? new BigDecimal(0).setScale(2, BigDecimal.ROUND_HALF_UP) : commonProduct.getPrice().setScale(2, BigDecimal.ROUND_HALF_UP));
            commonProduct.setSuggestPrice((null == commonProduct.getSuggestPrice()) ? new BigDecimal(0).setScale(2, BigDecimal.ROUND_HALF_UP) : commonProduct.getSuggestPrice().setScale(2, BigDecimal.ROUND_HALF_UP));
            commonProduct.setSupplyPrice((null == commonProduct.getSupplyPrice()) ? new BigDecimal(0).setScale(2, BigDecimal.ROUND_HALF_UP) : commonProduct.getSupplyPrice().setScale(2, BigDecimal.ROUND_HALF_UP));
            commonProduct.setPurchasePrice((null == commonProduct.getPurchasePrice()) ? new BigDecimal(0).setScale(2, BigDecimal.ROUND_HALF_UP) : commonProduct.getPurchasePrice().setScale(2, BigDecimal.ROUND_HALF_UP));

            List<CommonProductSpec> productSpecList = commonProductSpecService.listByProperty(CommonProductSpec.PRODUCT_ID,
                    commonProduct.getProductId(), CommonProductSpec.SPEC_ID, CommonProductSpec.SPEC_VALUE_ID);

            if (CollectionUtils.isNotEmpty(productSpecList)) {
                List<CommonSpecVal> specValList = commonProductService.getSpecValList(productSpecList);
                String specValueStr = "";
                for (CommonSpecVal commonSpecVal:specValList) {
                    specValueStr += (StringUtils.isNotEmpty(specValueStr) ? "@" : "") + commonSpecVal.getSpecName()
                            + "=" + commonSpecVal.getSpecValue();
                }
                commonProduct.setSpecValueStr(specValueStr);
            }
            if (StringUtils.isNotEmpty(commonProduct.getProductVedioName())) {
                commonProduct.setProductVedioName(commonProduct.getProductVedioName().replaceAll(prefix,""));
            }
            if (StringUtils.isNotEmpty(commonProduct.getProductSimpleName())) {
                commonProduct.setProductSimpleName(commonProduct.getProductSimpleName().replaceAll(prefix,""));
            }
            if (StringUtils.isNotEmpty(commonProduct.getProductPicName())) {
                commonProduct.setProductPicName(commonProduct.getProductPicName().replaceAll(prefix,""));
            }
            commonProduct.setApplyNoStr("");
            if (null != commonProduct.getApplyNo()) {
                commonProduct.setApplyNoStr(""+commonProduct.getApplyNo());
            }
        }
        //上传数据
        String targetUrl = null;
        try {
            List<CommonCataBrandProp> commonCataBrandPropList = commonProductService.listAppendixData();
            Map<String, Object> model = new HashMap<>();
            model.put("appendix", commonCataBrandPropList);
            model.put("items", list);
            //同步到oss
            targetUrl = ossConf.getOssUrl() + exportToOss(model);

            *//*new ZydExportExcel("", CommonProduct.class)
                    .setDataListColSize(list)
                    .write(getRequest(), getResponse(),
                            "商品明细-" + LocalDateTime.now().format(
                                    DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))+".xlsx");*//*
        }catch (Exception e){
            log.error("商品列表excel导出异常：{}",e);
            ZydExceptions.re(true,"商品列表导出失败");
        }
        return new JsonResult<>(true, "导出成功", targetUrl);
    }*/

    /*public String getOssCorpCode() {
        String supplierCode =(String) ContextHandler.get("supplierCode");
        return "purchase" + (StringUtils.isEmpty(supplierCode) ? "" : "_"+supplierCode) + ossConf.getCorpOssPrex();
    }*/

    /**
     * 组合租户的oss路径
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    public String getOssCorpCodeTwo(){
        String supplierCode =(String) ContextHandler.get("supplierCode");
        return "purchase" + (StringUtils.isEmpty(supplierCode) ? "" : "_"+supplierCode);
    }

    /**
     * 上传OSS
     */
    private String exportToOss(Map<String, Object> model) {
        //保存oss
        ClassLoader classLoader = CommonProductController.class.getClassLoader();
        InputStream is = null;
        Workbook workbook = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ByteArrayInputStream swapStream = null;
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        String name = "商品明细-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))+".xlsx";
        String targetUrl = getOssCorpCodeTwo() + ossConf.getTmp() + name;
        try {
            is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + "productExport.xlsx");
            if (is != null) {
                //转换成excel并输出
                XLSTransformer transformer = new XLSTransformer();
                workbook = transformer.transformXLS(is, model);
                //将内容写入输出流并把缓存的内容全部发出去
                workbook.write(baos);
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "获取不到商品明细导出的结果模板");
            }
            swapStream = new ByteArrayInputStream(baos.toByteArray());
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(),
                    targetUrl, swapStream));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            if (result == null) {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "商品明细导出的结果失败");
            }
            return targetUrl;
        } catch (Exception ex) {
            log.error("【商品明细导出】导入oss的错误结果异常：{}", JSONObject.toJSONString(ex));
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "商品明细导出的结果失败");
        } finally {
            try {
                baos.flush();
            } catch (IOException e) {
                log.error("【商品明细导出】导入oss ByteArrayOutputStream类io异常：{}", JSONObject.toJSONString(e));
            }
            IoUtil.close(is);
            IoUtil.close(swapStream);
            IoUtil.close(workbook);
            IoUtil.close(baos);
            ossClient.shutdown();
        }
    }

    /***
     * 获得请求对象
     * @return
     */
    public HttpServletRequest getRequest() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
    }

    /***
     * 获得response对象
     *
     * @return
     */
    public HttpServletResponse getResponse() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
    }

    @GetMapping(value = "/templateUrl")
    @ApiOperation(value = "获取导入模板地址")
    public JsonResult<String> templateUrl(){
        String tempUrl = commonProductService.getImportTemplateUrl();
        return new JsonResult<>(true,tempUrl);
    }

    @PostMapping(value = "/info")
    @ApiOperation(value = "慧采商品详情")
    public JsonResult<ProductInfo> getInfo(@RequestBody ProductIdDTO productIdDTO) {
        ProductInfo product = commonProductService.getInfo(productIdDTO.getId());
        return new JsonResult<>(true, "查询成功", product);
    }

    @PostMapping(value = "/elvo/list")
    @ApiOperation(value = "慧采列表")
    public JsonResult<Page<ProductVo>> getList(@RequestBody @Validated ProductListDTO productListDTO) {
        return new JsonResult<>(true, "查询成功", commonProductService.productList(productListDTO));
    }

    @PostMapping(value = "/elvo/count")
    @ApiOperation(value = "慧采列表状态计数")
    public JsonResult<Map<Integer,Integer>> getCount(@RequestBody  ProductListDTO productListDTO) {
        return new JsonResult<>(true, "查询成功", commonProductService.getCount(productListDTO));
    }

    @PostMapping(value = "/elvo/onsale")
    @ApiOperation(value = "商品池列表上下架")
    public JsonResult onSale(@RequestBody ProductIdDTO productIdDTO){
        return new JsonResult<>(true, "操作成功", commonProductService.onSale(productIdDTO));
    }

//    @PostMapping(value = "/purchase/list/export")
//    @ApiOperation(value = "商品池列表导出")
    /*@Deprecated
    public JsonResult<String> exportX(@RequestBody @Validated ProductListDTO productListDTO) {
        List<ProductVo> productVos = commonProductService.list(productListDTO);
        productVos.stream()
                .map(p -> {
                    Map<String, String> specMap = commonProductService.handleSpecToTwoColumn(p.getSpecData());
                    p.setSpecName(specMap.getOrDefault("specName", ""));  // 添加默认值防止NPE
                    p.setSpecValue(specMap.getOrDefault("specValue", ""));
                    return p;
                })
                .collect(Collectors.toList());
        String prefix = ossUrl+getOssCorpCode();
        for (ProductVo productVo : productVos) {
            // 格式化价格
            productVo.setPrice(null == productVo.getPrice() ? null : productVo.getPrice().setScale(2, RoundingMode.HALF_UP));
            productVo.setSuggestPrice(null == productVo.getSuggestPrice() ? null : productVo.getSuggestPrice().setScale(2, RoundingMode.HALF_UP));
            productVo.setPurchasePrice(null == productVo.getPurchasePrice() ? null : productVo.getPurchasePrice().setScale(2, RoundingMode.HALF_UP));


            CommonProductSpec commonProductSpec = new CommonProductSpec();
            commonProductSpec.setProductId(Long.valueOf(productVo.getProductId()));
            List<CommonProductSpec> productSpecList = commonProductSpecService.listByExample(commonProductSpec);

            if (CollectionUtils.isNotEmpty(productSpecList)) {
                List<CommonSpecVal> specValList = commonProductService.getSpecValList(productSpecList);
                String specValueStr = "";
                for (CommonSpecVal commonSpecVal:specValList) {
                    specValueStr += (StringUtils.isNotEmpty(specValueStr) ? "@" : "") + commonSpecVal.getSpecName()
                            + "&" + commonSpecVal.getSpecValue();
                }
                productVo.setSpecValueStr(specValueStr);
            }

            if (StringUtils.isNotEmpty(productVo.getPicName())) {
                productVo.setPicName(ossConf.getOssUrl() + "/" + productVo.getPicName().replaceAll(prefix,""));
            }
            if (StringUtils.isNotEmpty(productVo.getPicVideoName())){
                if (StringUtils.isNotEmpty(productVo.getPicName())){
                    productVo.setPicName(productVo.getPicName() + "@" + ossConf.getOssUrl() + "/" + productVo.getPicVideoName());
                }else {
                    productVo.setPicName(ossConf.getOssUrl() + "/" + productVo.getPicVideoName());
                }
            }
            if (StringUtils.isNotEmpty(productVo.getProductSimpleName())){
                String[] productSimpleNames = productVo.getProductSimpleName().split("@");
                if (productSimpleNames.length >= 1){
                    StringBuilder productSimpleName = new StringBuilder();
                    for (int i = 0; i < productSimpleNames.length; i++) {
                        productSimpleName.append(ossConf.getOssUrl() + "/" + productSimpleNames[i]);
                        if (i != productSimpleNames.length -1){
                            productSimpleName.append("@");
                        }
                    }
                    productVo.setProductSimpleName(productSimpleName.toString());
                }
            }

            if (StringUtils.isNotEmpty(productVo.getProductContent())){
                String[] productContents = productVo.getProductContent().split("@");
                StringBuilder newProductContent = new StringBuilder();
                for (int i = 0; i < productContents.length; i++) {
                    newProductContent.append(ossConf.getOssUrl() + "/" + productContents[i]);
                    if (i != productContents.length - 1){
                        newProductContent.append("@");
                    }
                }
                productVo.setProductContent(newProductContent.toString());
            }
        }
        //上传数据
        String targetUrl = null;
        try {
            Map<String, Object> model = new HashMap<>();
            model.put("items", productVos);
            //同步到oss
            targetUrl = ossConf.getOssUrl() + exportScmToOssX(model);
        }catch (Exception e){
            log.error("商品列表excel导出异常：{}",e);
            ZydExceptions.re(true,"商品列表导出失败");
        }
        return new JsonResult<>(true, "导出成功", targetUrl);
    }*/

/*
    @Deprecated
    private String exportScmToOssX(Map<String, Object> model) {
        //保存oss
        ClassLoader classLoader = CommonProductController.class.getClassLoader();
        InputStream is = null;
        Workbook workbook = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ByteArrayInputStream swapStream = null;
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        String name = "商品明细-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))+".xlsx";
        String targetUrl = "purchase/scm/" + name;
        try {
            is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + "scmProductLead.xlsx");
            if (is != null) {
                //转换成excel并输出
                XLSTransformer transformer = new XLSTransformer();
                workbook = transformer.transformXLS(is, model);
                //将内容写入输出流并把缓存的内容全部发出去
                workbook.write(baos);
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "获取不到商品明细导出的结果模板");
            }
            swapStream = new ByteArrayInputStream(baos.toByteArray());
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(),
                    targetUrl, swapStream));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            if (result == null) {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "商品明细导出的结果失败");
            }
            return targetUrl;
        } catch (Exception ex) {
            log.error("【商品明细导出】导入oss的错误结果异常：{}", JSONObject.toJSONString(ex));
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "商品明细导出的结果失败");
        } finally {
            try {
                baos.flush();
            } catch (IOException e) {
                log.error("【商品明细导出】导入oss ByteArrayOutputStream类io异常：{}", JSONObject.toJSONString(e));
            }
            IoUtil.close(is);
            IoUtil.close(swapStream);
            IoUtil.close(workbook);
            IoUtil.close(baos);
            ossClient.shutdown();
        }
    }*/

  /*  @PostMapping(value = "/purchase/zydmall/add")
    @ApiOperation(value = "zydmall商品上架列表添加")
    public JsonResult zydmallAdd(@RequestBody @Validated ProductZydmallIdDTO productZydmallIdDTO){
        return new JsonResult<>(true, "操作成功", commonProductService.zydmallAdd(productZydmallIdDTO));
    }*/

  /*  @PostMapping(value = "/purchase/zydmall/delete")
    @ApiOperation(value = "zydmall商品上架列表移除")
    public JsonResult zydmallDelete(@RequestBody @Validated ProductZydmallIdDTO productZydmallIdDTO){
        return new JsonResult<>(true, "操作成功", commonProductService.zydmallDelete(productZydmallIdDTO));
    }*/

  /*  @PostMapping(value = "/purchase/relevance/erp/import")
    @ApiOperation(value = "zydmall商品关联ERP导入")
    public JsonResult<String> importExcelRelevanceErp(@RequestParam("file") MultipartFile file) {
        try {
            // 创建通用监听器实例
            GenericDataListener<ProductZydmallRelevanceErpVO> listener = new GenericDataListener<>();
            // 使用 EasyExcel 读取文件
            EasyExcel.read(file.getInputStream(), ProductZydmallRelevanceErpVO.class, listener).sheet().doRead();
            // 获取读取到的数据
            List<ProductZydmallRelevanceErpVO> dataList = listener.getDataList();
            String msg = commonProductService.relevanceErpCreateTask(dataList);
            return new JsonResult<>(true, "导入成功", msg);
        } catch (Exception e) {
            ZydExceptions.re("关联ERP导入失败：" + e.getMessage());
        }
        return null;
    }*/

  /*  @SneakyThrows
    public static void writeExcelResponse(String name, HttpServletResponse response, Consumer<ServletOutputStream> consumer, Exception throwable) {
        try {
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
            // 这里URLEncoder.encode可以防止中文乱码
            String fileName = URLEncoder.encode(name, StandardCharsets.UTF_8.name()).replaceAll("\\+", "%20");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename*=utf-8''" + fileName + ".xlsx");
            consumer.accept(response.getOutputStream());
        } catch (Exception e) {
            // 重置response
            response.reset();
            throw throwable;
        }
    }*/

/*    private String exportScmZydmallToOss(Map<String, Object> model, String exportType) {
        // 保存oss
        ClassLoader classLoader = CommonProductController.class.getClassLoader();
        InputStream is = null;
        Workbook workbook = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ByteArrayInputStream swapStream = null;
        OSS ossClient;
        // 初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        String name = "";
        String fileName = "";
        switch (exportType) {
            case "1":
                name = "商品明细-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
                fileName = "scmProductZydmall.xlsx";
                is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + fileName);
                break;
            case "2":
                name = "建ERP商品编码明细-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
                fileName = "scmProductZydmallErp2.xlsx";
                is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + fileName);
                break;
            case "3":
                name = "总表数据-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
                fileName = "purchase/scm/zydmall/template/scmProductZydmallTotal.xlsx";
                OSSObject ossObject = ossClient.getObject(ossConf.getBucketName(), fileName);
                is = ossObject.getObjectContent();
                break;
            case "4":
                name = "关联ERP编码导入模板-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx";
                fileName = "scmProductZydmallRelevanceErp.xlsx";
                is = classLoader.getResourceAsStream(JxlsExcelView.FILE_TEMPLATE_DIR + fileName);
                break;
        }
        String targetUrl = "purchase/scm/zydmall/" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "/" + name;
        try {
            if (is != null) {
                // 转换成excel并输出
                if (!exportType.equals("2")) {
                    XLSTransformer transformer = new XLSTransformer();
                    workbook = transformer.transformXLS(is, model);
                } else {
                    workbook = new XSSFWorkbook(is);
                    CellStyle style = workbook.createCellStyle();
                    style.setBorderBottom(BorderStyle.THIN);
                    style.setBorderTop(BorderStyle.THIN);
                    style.setBorderLeft(BorderStyle.THIN);
                    style.setBorderRight(BorderStyle.THIN);
                    style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
                    style.setTopBorderColor(IndexedColors.BLACK.getIndex());
                    style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
                    style.setRightBorderColor(IndexedColors.BLACK.getIndex());
                    Sheet sheet = workbook.getSheetAt(0);
                    JSONArray products = JSONArray.parseArray(JSONArray.toJSONString(model.get("items")));
                    String[] titleKeys = new String[]{"skuCode", "productType", "propName", "firstLevelCataName", "secondLevelCataName", "threeLevelCataName", "propName", "price", "purchasePrice", "unit", "brandName", "supplier", "", ""};
                    for (int i = 0; i < products.size(); i++) {
                        int j = 1 + i;
                        Row row;
                        if (i >= 16) {
                            row = sheet.createRow(j);
                        } else {
                            row = sheet.getRow(j);
                        }
                        for (int k = 0; k < titleKeys.length; k++) {
                            Cell cell = row.createCell(k);
                            if (StringUtils.isBlank(titleKeys[k]) || products.getJSONObject(i).get(titleKeys[k]) == null) {
                                cell.setCellValue("");
                            } else {
                                cell.setCellValue(products.getJSONObject(i).get(titleKeys[k]) + "");
                            }
                            cell.setCellStyle(style);
                        }
                    }
                }
                // 将内容写入输出流并把缓存的内容全部发出去
                workbook.write(baos);
            } else {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "获取不到商品明细导出的结果模板");
            }
            swapStream = new ByteArrayInputStream(baos.toByteArray());
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(),
                    targetUrl, swapStream));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            if (result == null) {
                throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "zydmall商品上架列表导出的结果失败");
            }
            return targetUrl;
        } catch (Exception ex) {
            log.error("【zydmall商品上架列表导出】导入oss的错误结果异常：{}", JSONObject.toJSONString(ex));
            throw new BaseException(String.valueOf(ExceptionDictionary.BIZExp.getCode()), "zydmall商品上架列表导出的结果失败");
        } finally {
            try {
                baos.flush();
            } catch (IOException e) {
                log.error("【zydmall商品上架列表导出】导入oss ByteArrayOutputStream类io异常：{}", JSONObject.toJSONString(e));
            }
            IoUtil.close(is);
            IoUtil.close(swapStream);
            IoUtil.close(workbook);
            IoUtil.close(baos);
            ossClient.shutdown();
        }
    }*/

}
