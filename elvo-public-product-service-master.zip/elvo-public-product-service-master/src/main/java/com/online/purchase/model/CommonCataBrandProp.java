package com.online.purchase.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * 公海_分类、系列、品牌关系 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Accessors(chain = true)
@Getter
@Setter
@ToString
@ApiModel(value = "CommonCataBrandProp", description = "公海_分类、系列、品牌关系")
@Table(name = "elvo_common.t_pd_common_cata_brand_prop")
public class CommonCataBrandProp extends BaseCorpModel {

    public static final String CATA_ID = "cataId";
    public static final String BRAND_ID = "brandId";
    public static final String PROP_ID = "propId";
    public static final String REMARK = "remark";

    /**
     * 品牌id
     */
    @ApiModelProperty(value = "品牌id")
    private Long cataId;

    /**
     * 品牌编码
     */
    @ApiModelProperty(value = "品牌编码")
    private Long brandId;

    /**
     * 系列id
     */
    @ApiModelProperty(value = "系列id")
    private Long propId;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 分类等级
     */
    @Transient
    private Integer level;

    /**
     * 三级分类
     */
    @Transient
    private String cataName;
    /**
     * 品牌名
     */
    @Transient
    private String brandName;
    /**
     * 系列名
     */
    @Transient
    private String propName;
    /**
     * 规格名
     */
    @Transient
    private String specName;
}
