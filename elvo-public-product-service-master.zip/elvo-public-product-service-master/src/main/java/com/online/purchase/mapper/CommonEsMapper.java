/*
package com.online.purchase.mapper;

import com.online.purchase.model.CommonEs;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


*/
/**
 * 公海es Mapper
 *
 * @author lwl
 *//*

public interface CommonEsMapper extends QguBaseMapper<CommonEs> {

    */
/**
     * 清空数据
     *//*

    void deleteAll();

    */
/**
     * es重建
     *//*

    void rebuildEs();

    */
/**
     * 新增
     *
     * @param productId 产品id
     *//*

    void addByProductId(Long productId);


    List<CommonEs> selectSkuOrProduct(@Param("skuCodeOrTypeList") List<String> skuCodeOrTypeList);


    List<CommonEs> selectByProductIdList(@Param("productIdList") List<Long> productIdList);
}
*/
