/*
package com.online.purchase.model.dto;

import lombok.Data;

*/
/**
 * @Author ShunJunLiang
 * @Description
 * @Date 2022/01/13
 **//*

@Data
public class CataBrandPropDTO {
    */
/**
     * 三级分类
     *//*

    private String cataName;
    */
/**
     * 品牌名
     *//*

    private String brandName;
    */
/**
     * 系列名
     *//*

    private String propName;
    */
/**
     * 分类id
     *//*

    private Long cataId;

    */
/**
     * 品牌id
     *//*

    private Long brandId;

    */
/**
     * 系列id
     *//*

    private Long propId;

    */
/**
     * 规格名
     *//*

    private String specName;
}
*/
