package com.online.purchase.base;

/**
 * 常量
 *
 * @author lwl
 */
public interface PuPrConstants {

    /**
     * 编辑操作
     */
    String EDIT = "EDIT";

    /**
     * 是否有效字段默认值，
     */
    String IS_VALID_Y = "Y";

    /**
     * 是否体验店字段默认值
     */
    String IS_SHOP_CENTER_N = "N";

    /**
     * 产品来源-在线联营（SUPPLIER, SUPPLY）
     */
    String ONLINE_MARKETING = "ONLINE_MARKETING";

    /**
     * 产品来源-众业达自营
     */
    String ZYDMALL = "ZYDMALL";

    /**
     * 产品来源-供应商
     */
    String SUPPLIER = "SUPPLIER";

    /**
     * 产品来源-供应链
     */
    String SUPPLY = "SUPPLY";

    Integer PRODUCT_WAIT_SYNC = 1;

    Integer PRODUCT_SYNCED = 2;

    /**
     * ERP产品编码
     * 最大长度为 15，支持大小写字母和数字组成
     */
    String REGEX_ERP_PRODUCT_CODE = "^[a-z0-9A-Z]{1,15}+$";

    /**
     * 数据来源-供应链新增（用于标识定时任务不可删除）
     */
//    String DATA_SOURCE = "GYL_ADD";

    /**
     * 数据来源-商品申请
     */
    String ELVO_PRODUCT_APPLY = "ELVO_PRODUCT_APPLY";

    Integer  SELF_SUPPORT = 0;
    Integer  JOINT_OPERATION = 1;

}
