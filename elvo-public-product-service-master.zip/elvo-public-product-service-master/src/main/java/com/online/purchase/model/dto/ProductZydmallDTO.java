/*
package com.online.purchase.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@ApiModel("zydmall商品上架-入参")
public class ProductZydmallDTO {
    @ApiModelProperty("上架状态 Y：上架 N：未上架")
    private String isOnsale;
    @ApiModelProperty("分页页数")
    private Integer pageNum;
    @ApiModelProperty("分页记录数量")
    private Integer pageSize;
    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;
    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;
    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;
    @ApiModelProperty("商品品牌名称")
    private String brandName;
    @ApiModelProperty("商品系列名称")
    private String propName;
    @ApiModelProperty("供应商id")
    private String supplierId;
    @ApiModelProperty("产品型号列表")
    private List<String> productTypeList;
    @ApiModelProperty("商品id列表")
    private List<String> productIdList;
    @ApiModelProperty("厂家物料号列表")
    private List<String> skuCodeList;
    @ApiModelProperty("ERP编码列表")
    private List<String> erpProductCodeList;
    @ApiModelProperty("所属子公司")
    private String subCompany;
    @ApiModelProperty("上架zydmall时间（起始，格式：yyyy-MM-dd HH:mm:ss）")
    private String zydmallTimeStart;
    @ApiModelProperty("上架zydmall时间（截止，格式：yyyy-MM-dd HH:mm:ss）")
    private String zydmallTimeEnd;

    @ApiModelProperty("导出类型（1：商品明细导出，2：建ERP商品编码明细，3：总表数据导出，4：关联ERP编码导入模板）")
    private String exportType;
}
*/
