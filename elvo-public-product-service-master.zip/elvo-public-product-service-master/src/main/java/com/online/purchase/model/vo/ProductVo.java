package com.online.purchase.model.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ProductVo {

    @ApiModelProperty(value = "申请编号")
    private String applyId;

    @ApiModelProperty("商品名称")
    private String productName;

    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;

    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;

    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;

    @ApiModelProperty("分类名称（导出字段格式）：一级分类>二级分类>三级分类")
    private String cataName;

    @ApiModelProperty("商品品牌名称")
    private String brandName;
    @ApiModelProperty("商品品牌名称（中文）")
    private String brandNameCn;

    @ApiModelProperty("商品系列名称")
    private String propName;

    @ApiModelProperty("产品型号")
    private String productType;

    @ApiModelProperty("规格名")
    private String specName;

    @ApiModelProperty(value = "规格值")
    private String specValue;

    @ApiModelProperty("规格@规格值")
    private String specValueStr;

    @ApiModelProperty("订货号")
    private String skuCode;

    @ApiModelProperty("物料名称")
    private String materialName;

    @ApiModelProperty("产品id")
    private String productId;

    @ApiModelProperty("商品编号")
    private String productCode;

    @ApiModelProperty("供货价")
    private String supplyPrice;

    @ApiModelProperty("供货价折扣")
    private BigDecimal supplyDiscount;

    @ApiModelProperty("慧采价/调货价")
    private String purchasePrice;

    @ApiModelProperty("调货价折扣")
    private BigDecimal purchaseDiscount;

    @ApiModelProperty("调货价折扣 计算方式")
    private String purchaseCalcWay;

    @ApiModelProperty("面价（元）")
    private String price;

    @ApiModelProperty("建议销售价")
    private String suggestPrice;

    @ApiModelProperty("库存")
    private String stock;

    @ApiModelProperty("货期")
    private String deliveryDate;

    @ApiModelProperty("一级店铺分类名称")
    private String firstStoreCataName;

    @ApiModelProperty("二级店铺分类名称")
    private String secondStoreCataName;

    @ApiModelProperty("产品状态(待审核：待审核产品 未通过：未通过审核产品 销售中：上架通过审核产品产品 入库中：下架通过审核产品  )")
    private String state;

    @ApiModelProperty("主键id")
    private String id;

    @ApiModelProperty("计量单位")
    private String unit;

    @ApiModelProperty("重量")
    private String weight;

    @ApiModelProperty("最小起订量")
    private Integer minimunRequire;

    @ApiModelProperty("规格属性")
    private String specData;

    @ApiModelProperty("图片")
    private String picName;

    @ApiModelProperty("视频")
    private String picVideoName;

    @ApiModelProperty("产品详情图")
    private String productContent;

    @ApiModelProperty("产品样本")
    private String productSimpleName;

    @ApiModelProperty("是否上架(Y:上架,N:下架)")
    private String isOnsale;

    @ApiModelProperty("审核备注")
    private String auditRemark;

    @ApiModelProperty("待审核状态码（审核状态（0=待审核，2=不通过））")
    private Integer auditStatus;

    @ApiModelProperty("商品申请来源 来源： inquiry | publish")
    private String applySource;

    @ApiModelProperty("所属子公司")
    private String subCompany;

    @ApiModelProperty("创建者")
    private String supplier;

    @ApiModelProperty(value = "创建时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createdAt;

    @ApiModelProperty(value = "更新时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime updatedAt;

    @ApiModelProperty(value = "审核时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime;

    /**
     * 原因
     */
    @ApiModelProperty(value = "下架原因")
    private String reason;


    public void packCataName() {
        StringBuilder cataBuilder = new StringBuilder();
        if (isNotEmpty(firstLevelCataName)) {
            cataBuilder.append(firstLevelCataName.trim());
            if (isNotEmpty(secondLevelCataName)) {
                cataBuilder.append(">").append(secondLevelCataName.trim());
                if (isNotEmpty(threeLevelCataName)) {
                    cataBuilder.append(">").append(threeLevelCataName.trim());
                }
            }
        }
        cataName = cataBuilder.toString();
    }

    // 辅助方法：检查字符串是否非空（包括 null 和空字符串）
    private boolean isNotEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }
}
