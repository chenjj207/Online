/*
package com.online.purchase.controller;

import cn.hutool.core.map.MapUtil;
import com.online.purchase.base.PuPrConstants;
import com.online.purchase.model.CommonProp;
import com.online.purchase.model.CommonStockShieldManage;
import com.online.purchase.service.CommonPropService;
import com.online.purchase.service.CommonStockShieldManageService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Map;

*/
/**
 * CommonStockShieldManageController 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2024-07-11 13:33:02
 *//*

@RestController
@RequestMapping(value = "/stockShield")
@Api(value = "CommonStockShieldManageController", tags = {"库存屏蔽功能"})
public class CommonStockShieldManageController {

    @Resource
    private CommonStockShieldManageService commonStockShieldManageService;

    @GetMapping("/exec")
    @ApiOperation(value = "库存屏蔽执行接口")
    public JsonResult addCommonProp() {
        return commonStockShieldManageService.shieldStock();
    }

    @PostMapping("/add")
    @ApiOperation(value = "库存屏蔽 添加接口")
    public JsonResult add(@RequestBody CommonStockShieldManage commonStockShieldManage){
        return commonStockShieldManageService.add(commonStockShieldManage);
    }

}*/
