/*
package com.online.purchase.mapper;


import com.online.purchase.model.CommonProductMallRec;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

public interface CommonProductMallRecMapper extends QguBaseMapper<CommonProductMallRec> {


}
*/
