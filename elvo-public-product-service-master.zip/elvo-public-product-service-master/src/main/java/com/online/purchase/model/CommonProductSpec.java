package com.online.purchase.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Collection;

/**
 * 公海_产品、规格关系 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Getter
@Setter
@ToString
@Accessors(chain = true)
@ApiModel(value = "CommonProductSpec", description = "公海_产品、规格关系")
@Table(name = "elvo_common.t_pd_common_product_spec")
public class CommonProductSpec extends BaseCorpModel {

    public static final String PRODUCT_ID = "productId";
    public static final String SPEC_ID = "specId";
    public static final String SPEC_VALUE_ID = "specValueId";
    public static final String REMARK = "remark";
    public static final String SYNC_STATUS = "syncStatus";

    /**
     * 产品ID
     */
    @ApiModelProperty(value = "产品ID")
    private Long productId;

    /**
     * 规格ID
     */
    @ApiModelProperty(value = "规格ID")
    private Long specId;

    /**
     * 规格值ID
     */
    @ApiModelProperty(value = "规格值ID")
    private Long specValueId;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 通知租户状态（1：等待通知，2：已通知）
     */
    @ApiModelProperty(value = "通知租户状态（1：等待通知，2：已通知）")
    private Integer syncStatus;

    /**
     * 规格值ID集合
     */
    @Transient
    private Collection<Long> specValueIds;

    /**
     * 产品ID集合
     */
    @Transient
    private Collection<Long> productIds;
}
