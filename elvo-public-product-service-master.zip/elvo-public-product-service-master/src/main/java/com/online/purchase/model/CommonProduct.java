package com.online.purchase.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.purchase.base.PageBean;
import com.purchase.utils.excel.export.ExcelField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import javax.annotation.PostConstruct;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * 公海_产品 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-07-29 17:33:02
 */
@Getter
@Setter
@ToString
@Accessors(chain = true)
@ApiModel(value = "CommonProduct", description = "公海_产品")
@Table(name = "elvo_common.t_pd_common_product")
public class CommonProduct extends PageBean<CommonProduct> {

    public static final String PRODUCT_ID = "productId";
    public static final String ERP_PRODUCT_ID = "erpProductId";
    public static final String ZYDMALL_PRODUCT_ID = "zydmallProductId";
    public static final String ERP_PRODUCT_CODE = "erpProductCode";
    public static final String PRODUCT_NAME = "productName";
    public static final String PRODUCT_TYPE = "productType";
    public static final String SKU_CODE = "skuCode";
    public static final String PRICE = "price";
    public static final String CATA_ID = "cataId";
    public static final String BRAND_ID = "brandId";
    public static final String PROP_ID = "propId";
    public static final String UNIT = "unit";
    public static final String WEIGHT = "weight";
    public static final String IS_ONSALE = "isOnsale";
    public static final String PRODUCT_PIC_NAME = "productPicName";
    public static final String PRODUCT_MODEL_NAME = "productModelName";
    public static final String PRODUCT_VEDIO_NAME = "productVedioName";
    public static final String PRODUCT_SIMPLE_NAME = "productSimpleName";
    public static final String PRODUCT_CONTENT = "productContent";
    public static final String IS_ADJUST_PRICE = "isAdjustPrice";
    public static final String PRODUCT_SRC = "productSrc";
    public static final String IS_VALID = "isValid";
    public static final String EXISTS_ATTACHMENT = "existsAttachment";
    public static final String PACKAGE_UNIT = "packageUnit";
    public static final String RAMARK = "ramark";
    public static final String STOCK = "stock";
    public static final String SYNC_STATUS = "syncStatus";
    public static final String IFS_MAIN_PROCUREMENT = "ifsMainProcurement";

    /**
     * 产品编码
     */
    @ApiModelProperty(value = "产品编码")
    @ExcelField(title = "序号",sort = 9)
    private Long productId;

    /**
     * ERP产品id
     */
    @ApiModelProperty(value = "ERP产品ID")
    private Long erpProductId;

    /**
     * ERP产品编码
     */
    @ApiModelProperty(value = "商品编码")
    @ExcelField(title = "商品编码",sort = 20)
    private String erpProductCode;

    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称")
    private String productName;

    /**
     * 产品型号
     */
    @ApiModelProperty(value = "产品型号")
    @ExcelField(title = "产品型号",sort = 60)
    private String productType;

    /**
     * 产品货号
     */
    @ApiModelProperty(value = "产品货号")
    @ExcelField(title = "订货号",sort = 50)
    private String skuCode;
    /**
     * 物料名称
     */
    @ApiModelProperty(value = "物料名称")
    @ExcelField(title = "物料名称",sort = 50)
    private String materialName;

    /**
     * 面价
     */
    @ApiModelProperty(value = "面价")
    @ExcelField(title = "面价",sort = 90)
    private BigDecimal price;

    /**
     * 分类id
     */
    @ApiModelProperty(value = "分类id")
    private Long cataId;

    /**
     * 品牌id
     */
    @ApiModelProperty(value = "品牌id")
    private Long brandId;

    /**
     * 系列id
     */
    @ApiModelProperty(value = "系列id")
    private Long propId;

    /**
     * 计量单位
     */
    @ApiModelProperty(value = "计量单位")
    private String unit;

    /**
     * 净重
     */
    @ApiModelProperty(value = "净重")
    private String weight;

    @ApiModelProperty("最小起订量")
    private Integer minimunRequire;
    /**
     * 是否上架
     */
    @ApiModelProperty(value = "是否上架")
    private String isOnsale;

    @ApiModelProperty(value = "是否上架")
    @ExcelField(title = "状态",sort = 10)
    @Transient
    private String isOnsalename;

    public String getIsOnsalename() {
        if ("Y".equals(isOnsale)) {
            return "已上架";
        } else if ("N".equals(isOnsale)) {
            return "已下架";
        }
        return "";
    }

    /**
     * 产品图名称
     */
    @ApiModelProperty(value = "产品图名称")
    private String productPicName;

    /**
     * 3D模型名称
     */
    @ApiModelProperty(value = "3D模型名称")
    private String productModelName;

    /**
     * 视频名称
     */
    @ApiModelProperty(value = "视频名称")
    private String productVedioName;

    /**
     * 样本名称
     */
    @ApiModelProperty(value = "样本名称")
    private String productSimpleName;

    /**
     * 系列概述
     */
    @ApiModelProperty(value = "系列概述")
    private String productContent;

    /**
     * 是否正在调价中
     */
    @ApiModelProperty(value = "是否正在调价中")
    private String isAdjustPrice;

    /**
     * 产品来源
     */
    @ApiModelProperty(value = "产品来源")
    private String productSrc;

    /**
     * 是否有效
     */
    @ApiModelProperty(value = "是否有效")
    private String isValid;

    /**
     * 是否存在附件
     */
    @ApiModelProperty(value = "是否存在附件")
    private String existsAttachment;

    /**
     * 打包单位
     */
    @ApiModelProperty(value = "打包单位")
    private String packageUnit;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String ramark;

    /**
     * 原因
     */
    @ApiModelProperty(value = "原因")
    private String reason;

    /**
     * 库存
     */
    @ApiModelProperty(value = "库存")
    @ExcelField(title = "库存",sort = 110)
    private Integer stock;

    /**
     * 供货价
     */
    @ExcelField(title = "供货价",sort = 70)
    @ApiModelProperty(value = "供货价")
    private BigDecimal supplyPrice;

    /**
     * 供货价折扣
     */
    @ExcelField(title = "供货价折扣",sort = 70)
    private BigDecimal supplyDiscount;

    /**
     * 慧采价
     */
    @ExcelField(title = "慧采价/调货价",sort = 80)
    private BigDecimal purchasePrice;

    /**
     * 慧采价折扣/调货价折扣
     */
    @ExcelField(title = "慧采价折扣/调货价折扣",sort = 80)
    private BigDecimal purchaseDiscount;

    @ExcelField(title = "慧采价折扣计算方式",sort = 80)
    private String purchaseCalcWay;

    /**
     * 建议零售价
     */
    @ExcelField(title = "建议销售价",sort = 100)
    @ApiModelProperty(value = "建议销售价")
    private BigDecimal suggestPrice;

    /**
     * 货期
     */
    @ExcelField(title = "货期",sort = 120)
    @ApiModelProperty(value = "货期")
    private String deliveryDate;

    /**
     * 审核时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime;

    /**
     * 通知租户状态（1：等待通知，2：已通知）
     */
    @ApiModelProperty(value = "通知租户状态（1：等待通知，2：已通知）")
    private Integer syncStatus;

    @ApiModelProperty(value = "店铺id")
    private Integer storeId;

    @ApiModelProperty(value = "所属店铺类型（0为自营，1为联营）")
    private Integer storeType;

    @ApiModelProperty(value = "所属店铺名")
    private String storeName;

    @ApiModelProperty(value = "店铺详情")
    private String storeDesc;

    /**
     * 供应商id
     */
    @ApiModelProperty(value = "供应商id")
    private String supplierId;

    @ApiModelProperty(value = "供应商名称")
    private String supplierName;

    @ApiModelProperty("所属子公司")
    private String subCompany;

    /**
     * 申请表id
     */
    private String applyId;

    /**
     * 关键字
     */
    @Transient
    private String keywords;

    /**
     * 品牌名称
     */
    @Transient
    @ExcelField(title = "品牌",sort = 30)
    private String brandName;

    /**
     * 品牌链接
     */
    @Transient
    private String brandUrl;

    /**
     * 系列名
     */
    @Transient
    @ExcelField(title = "系列",sort = 40)
    private String propName;

    /**
     * 分类名称-一级分类
     */
    @Transient
    private String cataNameOne;

    /**
     * 分类名称-二级分类
     */
    @Transient
    private String cataNameTwo;

    /**
     * 分类名称-三级分类
     */
    @Transient
    private String cataNameThree;

    /**
     * 是否是供应链列表
     */
    @Transient
    private String isSupply;

    /**
     * 规格值集合
     */
    @Transient
    private Collection<CommonSpecVal> specValList;

    /**
     * 分类编号集合
     */
    @Transient
    private Collection<Long> cataIds;

    /**
     * 品牌编号集合
     */
    @Transient
    private Collection<Long> brandIds;

    /**
     * zydmallProductId
     */
    @ApiModelProperty(value = "zydmallProductId")
    private Long zydmallProductId;

    /**
     * ERP产品编码
     */
    @ApiModelProperty(value = "商品编码")
    private String supplierProductCode;

    @Transient
    private String firstLevelCataName;
    @Transient
    private String secondLevelCataName;
    @Transient
    private String threeLevelCataName;
    @Transient
    private String specValueStr;

    /**
     * 产品编码
     */
    @ApiModelProperty(value = "产品编码")
    @ExcelField(title = "序号",sort = 9)
    private Long applyNo;

    /**
     * 供应商商品申请来源
     */
    @ApiModelProperty(value = "供应商商品申请来源：inquiry | publish")
    private String applySource;

    @ApiModelProperty(value = "主采购组")
    private String ifsMainProcurement;

    @ApiModelProperty("产品属性11-统计大类")
    private String ifsStBcata;

    @ApiModelProperty("产品属性10-统计小类")
    private String ifsStScata;

    @ApiModelProperty("供应商分货")
    private String ifsSupplierDistribution;
    @Transient
    private String applyNoStr;
    @ApiModelProperty("zydmall上架标识 1：上架  0或空：未上架")
    private String zydmallFlag;
    @ApiModelProperty("上架zydmall时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime zydmallTime;

    /**
     * 规格json数据
     */
    @Transient
    private String specData;

    /**
     * 规格名,多个以@分开
     */
    @Transient
    private String specName;
    /**
     * 规格值,多个以@分开
     */
    @Transient
    private String specValue;
    /**
     * 规格数据
     */
    @Transient
    private List<String> commonSpecList;
    /**
     * 规格值数据
     */
    @Transient
    private List<String> commonSpecValList;

}
