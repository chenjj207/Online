package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
* <p>
* 规格值表--公海基础表
* </p>
*
* @author jidonglin
* @since 2023-04-19
*/
@Data
@TableName("t_pd_common_spec_val")
@Schema(title = "规格值表--公海基础表")
public class CommonSpecVal {

    private static final long serialVersionUID = 1L;

    @Schema(description = "主键")
    @TableId(value = "id" )
    private String id;

    @Schema(description = "规格值ID")
    @TableField("spec_value_id")
    private Long specValueId;

    @Schema(description = "规格编码")
    @TableField("spec_id")
    private Long specId;

    @Schema(description = "具体参数值")
    @TableField("spec_value")
    private String specValue;

    @Schema(description = "排序")
    @TableField("sort")
    private Integer sort;

    @Schema(description = "是否有效")
    @TableField("is_valid")
    private String isValid;

    @Schema(description = "公司标识")
    @TableField("corp_code")
    private String corpCode;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;

    @Schema(description = "标记删除")
    @TableField("deleted")
    private Boolean deleted;

    @Schema(description = "数据来源(GYL_ADD:供应链新增(用于标识定时任务不可删除),zydmall:zydmall,PRODUCT_APPLY:商品申请时新增)")
    @TableField("source")
    private String source;

    @Schema(description = "通知租户状态（1：等待通知，2：已通知）")
    @TableField("sync_status")
    private Integer syncStatus;

    @Schema(description = "创建者")
    @TableField("created_by")
    private String createdBy;

    @Schema(description = "创建时间")
    @TableField("created_at")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class,as = LocalDateTime.class)
    private LocalDateTime createdAt;

    @Schema(description = "更新者")
    @TableField("updated_by")
    private String updatedBy;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class,as = LocalDateTime.class)
    @TableField("updated_at")
    private LocalDateTime updatedAt;
}
