package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
* <p>
* 三级分类--产品关系表
* </p>
*
* @author jidonglin
* @since 2024-07-03
*/
@Data
@TableName("t_pd_common_cata_pic")
@Schema(title = "三级分类--产品关系表")
public class CommonCataPic{

    private static final long serialVersionUID = 1L;

    @Schema(description = "创建者")
    @TableField("created_by")
    private String createdBy;
    @Schema(description = "创建时间")
    @TableField("created_at")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createdAt;
    @Schema(description = "更新者")
    @TableField("updated_by")
    private String updatedBy;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    @Schema(description = "更新时间")
    @TableField("updated_at")
    private LocalDateTime updatedAt;

    @Schema(description = "主键")
    @TableField("id")
    private String id;

    @Schema(description = "三级分类ID")
    @TableField("cata_id")
    private Long cataId;

    @Schema(description = "产品编码")
    @TableField("product_id")
    private Long productId;

    @Schema(description = "产品图名称")
    @TableField("product_pic_name")
    private String productPicName;

    @Schema(description = "产品的 一级分类名称")
    @TableField("one_cata_name")
    private String oneCataName;

    @Schema(description = "产品的 二级分类名称")
    @TableField("two_cata_name")
    private String twoCataName;

    @Schema(description = "产品的 三级分类名称")
    @TableField("three_cata_name")
    private String threeCataName;

    @Schema(description = "分类名称 1 2 3 ")
    @TableField("cata_name")
    private String cataName;

    @Schema(description = "产品的 系列名称")
    @TableField("prop_name")
    private String propName;

    @Schema(description = "产品的 品牌名称")
    @TableField("brand_name")
    private String brandName;

    @Schema(description = "产品来源")
    @TableField("product_src")
    private String productSrc;

    @Schema(description = "公司标识")
    @TableField("corp_code")
    private String corpCode;




}
