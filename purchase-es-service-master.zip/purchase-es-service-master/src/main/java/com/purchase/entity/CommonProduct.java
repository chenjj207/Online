package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
* <p>
* 公海_产品表
* </p>
*
* @author jidonglin
* @since 2023-04-19
*/
@Data
@TableName("t_pd_common_product")
@Schema(title = "公海_产品表")
public class CommonProduct {

    private static final long serialVersionUID = 1L;

    @Schema(description = "主键")
    @TableId(value = "id" )
    private String id;

    @Schema(description = "产品编码")
    @TableField("product_id")
    private Long productId;

    @Schema(description = "erp产品id")
    @TableField("erp_product_id")
    private Long erpProductId;

    @Schema(description = "erp产品编码")
    @TableField("erp_product_code")
    private String erpProductCode;

    @Schema(description = "产品名称")
    @TableField("product_name")
    private String productName;

    @Schema(description = "产品型号")
    @TableField("product_type")
    private String productType;

    @Schema(description = "产品货号")
    @TableField("sku_code")
    private String skuCode;

    @Schema(description = "面价")
    @TableField("price")
    private BigDecimal price;

    @Schema(description = "分类id")
    @TableField("cata_id")
    private Long cataId;

    @Schema(description = "品牌id")
    @TableField("brand_id")
    private Long brandId;

    @Schema(description = "系列id")
    @TableField("prop_id")
    private Long propId;

    @Schema(description = "计量单位")
    @TableField("unit")
    private String unit;

    @Schema(description = "净重")
    @TableField("weight")
    private String weight;

    @Schema(description = "是否上架")
    @TableField("is_onsale")
    private String isOnsale;

    @Schema(description = "产品图名称")
    @TableField("product_pic_name")
    private String productPicName;

    @Schema(description = "3D模型名称")
    @TableField("product_model_name")
    private String productModelName;

    @Schema(description = "视频名称")
    @TableField("product_vedio_name")
    private String productVedioName;

    @Schema(description = "样本名称")
    @TableField("product_simple_name")
    private String productSimpleName;

    @Schema(description = "系列概述")
    @TableField("product_content")
    private String productContent;

    @Schema(description = "是否正在调价中")
    @TableField("is_adjust_price")
    private String isAdjustPrice;

    @Schema(description = "产品来源")
    @TableField("product_src")
    private String productSrc;

    @Schema(description = "是否有效")
    @TableField("is_valid")
    private String isValid;

    @Schema(description = "是否存在附件")
    @TableField("exists_attachment")
    private String existsAttachment;

    @Schema(description = "打包单位")
    @TableField("package_unit")
    private String packageUnit;

    @Schema(description = "公司标识")
    @TableField("corp_code")
    private String corpCode;

    @Schema(description = "备注")
    @TableField("ramark")
    private String ramark;

    @Schema(description = "库存")
    @TableField("stock")
    private Long stock;

    @Schema(description = "供货价")
    @TableField("supply_price")
    private BigDecimal supplyPrice;

    @Schema(description = "慧采价")
    @TableField("purchase_price")
    private BigDecimal purchasePrice;

    @Schema(description = "建议零售价")
    @TableField("suggest_price")
    private BigDecimal suggestPrice;

    @Schema(description = "货期")
    @TableField("delivery_date")
    private String deliveryDate;

    @Schema(description = "审核时间")
    @TableField("audit_time")
    private LocalDateTime auditTime;

    @Schema(description = "供应商id")
    @TableField("supplier_id")
    private String supplierId;

    @Schema(description = "通知租户状态（1：等待通知，2：已通知）")
    @TableField("sync_status")
    private Integer syncStatus;

    @Schema(description = "申请表ID")
    @TableField("apply_id")
    private String applyId;

    @Schema(description = "zydmallProductId")
    @TableField("zydmall_product_id")
    private Long zydmallProductId;

    @Schema(description = "供应商产品code")
    @TableField("supplier_product_code")
    private String supplierProductCode;

    @Schema(description = "商品申请序号")
    @TableField("apply_no")
    private Long applyNo;

    @Schema(description = "主采购组")
    @TableField("ifs_main_procurement")
    private String ifsMainProcurement;

    @Schema(description = "店铺id")
    @TableField("store_id")
    private int storeId;

    @Schema(description = "店铺类型")
    @TableField("store_type")
    private int storeType;

    @Schema(description = "店铺名")
    @TableField("store_name")
    private String storeName;

    @Schema(description = "创建者")
    @TableField("created_by")
    private String createdBy;

    @Schema(description = "创建时间")
    @TableField("created_at")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class,as = LocalDateTime.class)
    private LocalDateTime createdAt;

    @Schema(description = "更新者")
    @TableField("updated_by")
    private String updatedBy;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class,as = LocalDateTime.class)
    @TableField("updated_at")
    private LocalDateTime updatedAt;
}
