package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
* <p>
* 公海_分类、系列、品牌关系表
* </p>
*
* @author jidonglin
* @since 2023-04-19
*/
@Data
@TableName("t_pd_common_cata_brand_prop")
@Schema(title = "公海_分类、系列、品牌关系表")
public class CommonCataBrandProp{

    private static final long serialVersionUID = 1L;

    @Schema(description = "主键")
    @TableId(value = "id" )
    private String id;

    @Schema(description = "品牌id")
    @TableField("cata_id")
    private Long cataId;

    @Schema(description = "品牌编码")
    @TableField("brand_id")
    private Long brandId;

    @Schema(description = "系列id")
    @TableField("prop_id")
    private Long propId;

    @Schema(description = "公司标识")
    @TableField("corp_code")
    private String corpCode;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;


    @Schema(description = "创建者")
    @TableField("created_by")
    private String createdBy;

    @Schema(description = "创建时间")
    @TableField("created_at")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class,as = LocalDateTime.class)
    private LocalDateTime createdAt;

    @Schema(description = "更新者")
    @TableField("updated_by")
    private String updatedBy;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class,as = LocalDateTime.class)
    @TableField("updated_at")
    private LocalDateTime updatedAt;

}
