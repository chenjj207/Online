package com.purchase.common;

import com.purchase.service.model.Spec;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.index.query.*;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.BucketOrder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;

import java.util.List;

/**
 * @author jidonglin
 * @Description: 条件构建器
 * @date 2023/4/20  11:05
 */
public class ProductSearchBuilder {

    /**
     * key term搜索 sku 和 productType
     * 没有过滤下架、来源、价格区间
     * @param key
     * @return
     */
    public static BoolQueryBuilder keyTermAllQuery(String key){
        BoolQueryBuilder boolQueryBuilder =QueryBuilders.boolQuery();
        if (StringUtils.isNotEmpty(key)){
            BoolQueryBuilder shoulds = QueryBuilders.boolQuery();
            shoulds.should(ProductSearchBuilder.skuCodeTermQuery(key))
                    .should(ProductSearchBuilder.productTypeKwTermQuery(key));
            boolQueryBuilder.filter(shoulds);
        }
        return boolQueryBuilder;
    }

    /**
     * key match搜索 searchset
     * 没有过滤下架、来源、价格区间
     * @param key
     * @return
     */
    public static BoolQueryBuilder keyMatchAllQuery(String key){
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        if (StringUtils.isNotEmpty(key)){
            BoolQueryBuilder shoulds = QueryBuilders.boolQuery();
            shoulds.should(ProductSearchBuilder.productStructureMultiMatch(key))
                    .should(ProductSearchBuilder.searchSetIk(key))
                    .should(ProductSearchBuilder.searchSetIkSmartSyno(key))
                    .should(ProductSearchBuilder.searchSetNgram(key));
            String regex = ".*[a-zA-z].*";
            if (key.matches(regex)) {
                //存在拼音，加入相关匹配条件
                shoulds.should(ProductSearchBuilder.pinyinMultiMatch(key));
            }
            boolQueryBuilder.must(shoulds);
        }
        return boolQueryBuilder;
    }

    /**
     * key term搜索 sku 和 productType
     * @param key
     * @return
     */
    public static BoolQueryBuilder keyTermQuery(String key){
        BoolQueryBuilder boolQueryBuilder =QueryBuilders.boolQuery();
        //放开限制
        boolQueryBuilder.filter(ProductSearchBuilder.productSrcQuery());
//                .filter(ProductSearchBuilder.isOnsaleTermQuery())
//                .filter(ProductSearchBuilder.purchasePriceRangQuery());
        if (StringUtils.isNotEmpty(key)){
            BoolQueryBuilder shoulds = QueryBuilders.boolQuery();
            shoulds.should(ProductSearchBuilder.skuCodeTermQuery(key))
                    .should(ProductSearchBuilder.productTypeKwTermQuery(key));
            boolQueryBuilder.filter(shoulds);
        }
        return boolQueryBuilder;
    }

    /**
     * key match搜索 searchset
     * @param key
     * @return
     */
    public static BoolQueryBuilder keyMatchQuery(String key){
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        //放开限制
        boolQueryBuilder.filter(ProductSearchBuilder.productSrcQuery());
//                .filter(ProductSearchBuilder.isOnsaleTermQuery())
//                .filter(ProductSearchBuilder.purchasePriceRangQuery());
        if (StringUtils.isNotEmpty(key)){
            BoolQueryBuilder shoulds = QueryBuilders.boolQuery();
            shoulds.should(ProductSearchBuilder.productStructureMultiMatch(key))
                    .should(ProductSearchBuilder.searchSetIk(key))
                    .should(ProductSearchBuilder.searchSetIkSmartSyno(key))
                    .should(ProductSearchBuilder.searchSetNgram(key));
            String regex = ".*[a-zA-z].*";
            if (key.matches(regex)) {
                //存在拼音，加入相关匹配条件
                shoulds.should(ProductSearchBuilder.pinyinMultiMatch(key));
            }
            boolQueryBuilder.must(shoulds);
        }
        return boolQueryBuilder;
    }

    /**
     *
     *  选型 -- 商品结构【分类、品牌、系列、规格】批量精准匹配
     * @param catas 分类列表 【中低压配电 微型断路器 微型断路器】
     * @param brands  品牌列表
     * @param props 系列列表
     * @param specsList  规格列表【规格名：规格值】
     * @return
     */
    public static BoolQueryBuilder structMatchQuery(List<String> catas, List<String> brands, List<String> props, List<Spec> specsList){
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        if(CollectionUtils.isNotEmpty(catas)){
            boolQueryBuilder.must(ProductSearchBuilder.cataNameTerms(catas));
        }
        if(CollectionUtils.isNotEmpty(brands)){
            boolQueryBuilder.must(ProductSearchBuilder.brandsTerms(brands));
        }
        if(CollectionUtils.isNotEmpty(props)){
            boolQueryBuilder.must(ProductSearchBuilder.propNameTerms(props));
        }
        if (CollectionUtils.isNotEmpty(specsList)){
            BoolQueryBuilder specMustBoolQueryBuilder = QueryBuilders.boolQuery();
            specsList.forEach(e->{
                BoolQueryBuilder specShouldBoolQueryBuilder = QueryBuilders.boolQuery();
                e.getSpecVals().forEach(f->{
                    String specAndVal = e.getName() + ":" + f.getValue();
                    specShouldBoolQueryBuilder.should(ProductSearchBuilder.specsMatch(specAndVal));
                });
                specMustBoolQueryBuilder.must(specShouldBoolQueryBuilder);
            });
            boolQueryBuilder.must(specMustBoolQueryBuilder);
        }
        return boolQueryBuilder;
    }

    /**
     * 高亮字段builder
     * @return
     */
    public static HighlightBuilder highlight(){
        HighlightBuilder highlightBuilder = new HighlightBuilder();
        highlightBuilder.field("searchset").field("searchset.ik").field("propName")
                .field("brandName").field("cataName").field("threeCataName").field("specs")
                .field("productType").field("productType.kw").field("skuCode").preTags("<em>").postTags("</em>");
        return highlightBuilder;
    }

    /**
     * skuCode builder
     * @param key
     * @return
     */
    public static QueryBuilder skuCodeTermQuery(String key){
        return QueryBuilders.termQuery("skuCode", key).boost(100f);
    }

    /**
     * 产品类型 builder
     * @param key
     * @return
     */
    public static QueryBuilder productTypeKwTermQuery(String key){
        return QueryBuilders.termQuery("productType.kw", key).boost(100f);
    }

    /**
     * purchasePrice 大于0
     * @return
     */
    public static QueryBuilder purchasePriceRangQuery(){
        return QueryBuilders.rangeQuery("purchasePrice").gt(0);
    }

    /**
     * (productSrc=ZYDMALL and ifsMainProcurement=上海供应链) 或者  productSrc != ZYDMALL
     * @return
     */
    public static QueryBuilder productSrcQuery(){
        BoolQueryBuilder shoulds = QueryBuilders.boolQuery();
        BoolQueryBuilder musts1 = QueryBuilders.boolQuery();
        musts1.must(QueryBuilders.termQuery("productSrc", "ZYDMALL"))
                .must(QueryBuilders.termQuery("ifsMainProcurement", "上海供应链"));

        BoolQueryBuilder musts2 = QueryBuilders.boolQuery();
        musts2.mustNot(QueryBuilders.termQuery("productSrc", "ZYDMALL"));

        shoulds.should(musts1).should(musts2);
        return shoulds;
    }

    /**
     * stock 大于0 builder
     * @return
     */
    public static QueryBuilder isShowStock(){
        return QueryBuilders.rangeQuery("stock").gt(0);
    }

    /**
     * isOnsale=Y builder
     * @return
     */
    public static QueryBuilder isOnsaleTermQuery(){
        return QueryBuilders.termQuery("isOnsale", "Y");
    }

    /**
     * storeId builder
     * @return
     */
    public static QueryBuilder storeIdTermQuery(Integer storeId){
        return QueryBuilders.termQuery("storeId", storeId);
    }

    /**
     * supplierId builder
     * @return
     */
    public static QueryBuilder supplierIdTermQuery(String supplierId){
        return QueryBuilders.termQuery("supplierId", supplierId);
    }

    /**
     * 品牌、 分类 拼音 multiMatchQuery builder
     * @param key
     * @return
     */
    public static QueryBuilder pinyinMultiMatch(String key){
        return QueryBuilders.multiMatchQuery(key)
                .field("brandName.pinyin", 10f).field("cataName.pinyin", 10f)
                .operator(Operator.AND).boost(5.0f).type(MultiMatchQueryBuilder.Type.BEST_FIELDS);
    }

    /**
     * 商品结构【品牌、分类、系列、规格】multiMatchQuery
     * @param key
     * @return
     */
    public static QueryBuilder productStructureMultiMatch(String key){
        return QueryBuilders.multiMatchQuery(key)
                .field("brandName", 10f).field("cataName", 10f).field("productType", 1f).field("propName", 10f).field("specVals", 10f)
                .operator(Operator.OR).boost(10f).type(MultiMatchQueryBuilder.Type.CROSS_FIELDS).minimumShouldMatch("80%").boost(10.0f);
    }

    /**
     * searchset.ik matchQuery
     * @param key
     * @return
     */
    public static QueryBuilder searchSetIk(String key){
        return QueryBuilders.matchQuery("searchset.ik", key).operator(Operator.OR).minimumShouldMatch("85%").boost(1f);
    }

    /**
     * searchset.ik_smart_syno  matchQuery
     * @param key
     * @return
     */
    public static QueryBuilder searchSetIkSmartSyno(String key){
        return QueryBuilders.matchQuery("searchset.ik_syno", key).operator(Operator.OR).minimumShouldMatch("85%").boost(1f);
    }

    /**
     * searchset.ngram  matchQuery
     * @param key
     * @return
     */
    public static QueryBuilder searchSetNgram(String key){
        return QueryBuilders.matchQuery("searchset.ngram", key).operator(Operator.OR).minimumShouldMatch("100%").boost(1f);
    }

    /**
     * brandName.kw  termsQuery
     * @param brands
     * @return
     */
    public static TermsQueryBuilder brandsTerms(List<String> brands){
        return QueryBuilders.termsQuery("brandName.kw",brands);
    }

    /**
     * cataName.kw termsQuery
     * @param cataName 取值：【中低压配电 微型断路器 微型断路器】
     * @return
     */
    public static TermsQueryBuilder cataNameTerms(List<String> cataName){
        return QueryBuilders.termsQuery("cataName.kw",cataName);
    }

    /**
     * propName.kw termsQuery
     * @param propName 取值
     * @return
     */
    public static TermsQueryBuilder propNameTerms(List<String> propName){
        return QueryBuilders.termsQuery("propName.kw",propName);
    }

    /**
     * specs matchQuery
     * @param specAndVal 取值：【规格名:规格值】
     * @return
     */
    public static MatchQueryBuilder specsMatch(String specAndVal){
        return QueryBuilders.matchQuery("specs", specAndVal);
    }

    /**
     * 分类显示系列
     * @return
     */
    public static QueryBuilder isShowPropTerms (){
        return QueryBuilders.termQuery("isCataShowProp", "Y");
    }

    /**
     * 构建品牌分组
     * @return
     */
    public static AggregationBuilder brandNameAgg() {
        return AggregationBuilders.terms("brandNameAgg").field("brandName.kw").order(BucketOrder.aggregation("max_brand_order", true))
                .subAggregation(AggregationBuilders.max("max_brand_order").field("brandOrder")).size(1000);
    }

    /**
     * 构建分类分组
     * @return
     */
    public static AggregationBuilder cataNameAgg() {
        return AggregationBuilders.terms("cataNameAgg").field("cataName.kw").order(BucketOrder.aggregation("max_cata_order", true))
                .subAggregation(AggregationBuilders.max("max_cata_order").field("cataOrder")).size(2000);
    }

    /**
     * 构建系列分组
     * @return
     */
    public static AggregationBuilder propNameAgg() {
        return AggregationBuilders.terms("propNameAgg").field("propName.kw").size(1000);
    }

    /**
     * 构建 【规格：规格值】 分组
     * @return
     */
    public static AggregationBuilder specValsArrAgg() {
        return AggregationBuilders.nested("specValsArrAgg", "specValsArr")
                .subAggregation(AggregationBuilders.terms("specName").field("specValsArr.specName").size(3000).order(BucketOrder.aggregation("max_spec_order", true))
                        .subAggregation(AggregationBuilders.terms("specValName").field("specValsArr.specValName").size(3000).order(BucketOrder.key(true)))
                        .subAggregation(AggregationBuilders.max("max_spec_order").field("specValsArr.specOrder"))
                );
    }

}
