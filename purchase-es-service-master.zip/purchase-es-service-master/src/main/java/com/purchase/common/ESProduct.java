package com.purchase.common;

import lombok.Data;
import org.springframework.data.elasticsearch.annotations.*;

import java.util.List;

/**
 * @author jidonglin
 * @Description: ES 产品属性
 * @date 2023/3/22  13:44
 */
@Data
@Document(indexName = "purchase", type = "product")
public class ESProduct {

    @Field(type = FieldType.Keyword)
    private String productId;

    @Field(type = FieldType.Keyword)
    private String erpProductId;

    @Field(type = FieldType.Keyword)
    private String isOnsale;

    @Field(type = FieldType.Keyword, normalizer = "uppercase")
    private String skuCode;

    @MultiField(mainField = @Field(type = FieldType.Text, analyzer = "whitespace_low"),
            otherFields = {
                    @InnerField(suffix = "pinyin", type = FieldType.Text, analyzer = "pinyin"),
                    @InnerField(suffix = "kw", type = FieldType.Keyword),
                    @InnerField(suffix = "ik", type = FieldType.Text, analyzer = "ik_smart")})
    private String propName;

    @Field(type = FieldType.Keyword)
    private String propNameFull;

    @MultiField(mainField = @Field(type = FieldType.Text, analyzer = "whitespace_low"),
            otherFields = {
                    @InnerField(suffix = "pinyin", type = FieldType.Text, analyzer = "pinyin"),
                    @InnerField(suffix = "kw", type = FieldType.Keyword)})
    private String cataName;

    @Field(type = FieldType.Keyword)
    private String threeCataName;

    @Field(type = FieldType.Keyword)
    private Long brandId;

    @Field(type = FieldType.Integer)
    private Integer brandOrder;

    @MultiField(mainField = @Field(type = FieldType.Text, analyzer = "whitespace_low"),
            otherFields = {
                    @InnerField(suffix = "pinyin", type = FieldType.Text, analyzer = "brandName_pinyin"),
                    @InnerField(suffix = "kw", type = FieldType.Keyword)})
    private String brandName;

    @MultiField(mainField = @Field(type = FieldType.Text, analyzer = "whitespace_low"),
            otherFields = {
                    @InnerField(suffix = "ik", type = FieldType.Text, analyzer = "ik_max_word"),
                    @InnerField(suffix = "ik_syno",type = FieldType.Text,analyzer = "ik_max_word_syno"),
                    @InnerField(suffix = "ngram",type = FieldType.Text,analyzer = "my_tokenizer_analyzer"),
            })
    private String searchset;

    @Field(type = FieldType.Text, analyzer = "whitespace")
    private String specVals;

    @MultiField(mainField = @Field(type = FieldType.Text, analyzer = "whitespace_low"),
            otherFields = {
                    @InnerField(suffix = "kw", type = FieldType.Keyword)})
    private String specs;

    @MultiField(mainField = @Field(type = FieldType.Text, analyzer = "whitespace_low"),
            otherFields = {
                    @InnerField(suffix = "pinyin", type = FieldType.Text, analyzer = "pinyin"),
                    @InnerField(suffix = "kw", type = FieldType.Keyword)})
    private String productType;

    @Field(type = FieldType.Double)
    private Double cataOrder;

    @Field(type = FieldType.Double)
    private Double price;

    @Field(type = FieldType.Double)
    private Double purchasePrice;

    @Field(type = FieldType.Double)
    private Double disCountPrice;

    @Field(type = FieldType.Keyword)
    private String productPicName;

    @Field(type = FieldType.Keyword)
    private String productSrc;

    @Field(type = FieldType.Keyword)
    private String tenantProductSrc;
    /**
     * 销量
     */
    @Field(type = FieldType.Long)
    private Long saleVolume;

    @Field(type = FieldType.Keyword)
    private String isCataShowProp;

    /**
     * 库存
     */
    @Field(type = FieldType.Integer)
    private int stock;

    /**
     * 主采购组 取值：【上海供应链】
     */
    @Field(type = FieldType.Keyword)
    private String ifsMainProcurement;

    /**
     * 店铺id
     */
    @Field(type = FieldType.Integer)
    private Integer storeId;

    /**
     * 店铺类型 0：自营 1：联营
     */
    @Field(type = FieldType.Integer)
    private Integer storeType;

    /**
     * 店铺名
     */
    @Field(type = FieldType.Keyword)
    private String storeName;

    @Field(type = FieldType.Text)
    private String storeDesc;

    @Field(type = FieldType.Nested)
    public List<SpecValsArr> specValsArr;

    @Data
    public static class SpecValsArr {
        @Field(type = FieldType.Keyword)
        private String specName;

        @Field(type = FieldType.Integer)
        private Integer specOrder;

        @Field(type = FieldType.Keyword)
        private String specValName;

    }

    /**
     * 货期
     */
    @Field(type = FieldType.Keyword)
    private String deliveryDate;
    /**
     * 单位
     */
    @Field(type = FieldType.Keyword)
    private String unit;
    /**
     * 供应商id
     */
    @Field(type = FieldType.Keyword)
    private String supplierId;



}
