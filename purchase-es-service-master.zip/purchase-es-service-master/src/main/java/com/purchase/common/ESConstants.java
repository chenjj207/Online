package com.purchase.common;

import lombok.Data;

/**
 * @author jidonglin
 * @Description: 业务枚举值
 */
@Data
public class ESConstants {
    public enum BrandSource{
        GYL_ADD("GYL_ADD", "供应链新增"),
        ZYDMALL("zydmall", "zydmall"),
        PRODUCT_APPLY("PRODUCT_APPLY", "商品申请时新增"),
        ;

        public String code;
        public String message;
        BrandSource(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum ProductSource{
        SUPPLIER("SUPPLIER", "供应商申请"),
        ZYDMALL("ZYDMALL", "ZYDMALL"),
        SUPPLY("SUPPLY", "供应链"), //目前版本已取消供应链来源
        ;

        public String code;
        public String message;
        ProductSource(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

}
