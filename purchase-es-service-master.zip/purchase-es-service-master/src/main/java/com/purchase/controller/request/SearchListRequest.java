package com.purchase.controller.request;


import com.purchase.service.model.Spec;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Size;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 商品列表接口入参
 * @date 2023/4/20
 */
@Data
public class SearchListRequest {
    @Schema(description = "分类名称")
    @Size(max = 1, message = "分类最大为1")
    private List<String> catas;
    @Schema(description = "品牌名称列表")
    private List<String> brands;
    @Schema(description = "系列名称列表")
    private List<String> props;
    @Schema(description = "规格和规格值对象")
    private List<Spec> specs;
    @Schema(description = "搜索参数")
    private String key;
    @Schema(description = "页面大小")
    private int pageSize = 10;
    @Schema(description = "页码")
    private int pageNum = 1;
    @Schema(description = "仅显示有货")
    private boolean isShowStock = false;
    @Schema(description = "排序")
    private SortObj sortObj;
    @Schema(description = "价格区间")
    private PriceObj priceObj;
    @Schema(description = "店铺id")
    private Integer storeId;
    @Schema(description = "供应商id")
    private String supplierId;

    public SearchListRequest(){
    }

    @Data
    public class PriceObj {
        @Schema(description = "起始价格")
        private String gte;
        @Schema(description = "截止价格")
        private String lte;
    }

    @Data
    public class SortObj {
        @Schema(description = "排序字段")
        private String filed;
        @Schema(description = "升序或降序，取值desc asc")
        private String order;
    }
}
