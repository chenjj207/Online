package com.purchase.controller.request;

import com.purchase.service.model.Spec;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Size;
import java.util.List;

@Data
public class SearchSelectRequest {
    @Schema(description = "搜索参数")
    private String key;
    @Schema(description = "分类名称")
    @Size(max = 1, message = "分类最大为1")
    private List<String> catas;
    @Schema(description = "品牌名称列表")
    private List<String> brands;
    @Schema(description = "系列名称列表")
    private List<String> props;
    @Schema(description = "规格和规格值对象")
    private List<Spec> specs;
    @Schema(description = "店铺id")
    private Integer storeId;
    @Schema(description = "供应商id")
    private String supplierId;
}
