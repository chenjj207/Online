package com.purchase.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 三级分类--产品关系表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-07-03
 */
@RestController
@RequestMapping("/common-cata-pic")
public class CommonCataPicController {

}
