package com.purchase.controller;

import com.purchase.service.IndexService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

/**
 * @author jidonglin
 * @Description: 索引管理控制器
 * @date 2023/4/19  11:50
 */
@RestController
@RequestMapping(value = "/index")
public class IndexController {

    @Autowired
    IndexService indexService;

    @PostMapping(value = "/create")
    @Operation(summary = "创建索引")
    public void create() throws IOException {
        indexService.createdIndex();
    }

}
