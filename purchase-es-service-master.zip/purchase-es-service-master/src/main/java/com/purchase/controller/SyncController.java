package com.purchase.controller;

import com.purchase.service.SyncService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/21  11:24
 */
@RestController
@RequestMapping(value = "/sync")
public class SyncController {

    @Autowired
    SyncService syncService;

    @PostMapping("/init")
    public Boolean syncDataToES(){
        return syncService.syncDataToES();
    }

    /**
     * 根据列表id同步  es数据
     * @param ids
     * @return
     */
    @PostMapping(value = "/updateByIds")
    public Boolean updateByIds(@RequestBody @NotEmpty(message = "产品id列表不能为空") List<String> ids){
        return syncService.update(ids);
    }

    /**
     * 根据品牌id同步 es数据
     * @param brands
     * @return
     */
    @PostMapping(value = "/updateBrand")
    public Boolean updateByBrand(@RequestBody @NotEmpty(message = "品牌id列表不能为空") List<String> brands){
        return syncService.updateByBrand(brands);
    }

    /**
     * 根据供应商id列表同步  es数据
     * @param supplierIds
     * @return
     */
    @PostMapping(value = "/updateBySupplierIds")
    public Boolean updateBySupplierIds(@RequestBody @NotEmpty(message = "供应商列表id") List<String> supplierIds){
        return syncService.updateBySupplierIds(supplierIds);
    }

}
