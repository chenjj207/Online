package com.purchase.controller.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description: 分类树搜索实体
 * @date 2023/4/20  10:23
 */
@Data
public class SearchCataRequest {
    @Schema(description = "选中的分类")
    private String cataSelected;

    @Schema(description = "供应商id")
    private String supplierId;
}
