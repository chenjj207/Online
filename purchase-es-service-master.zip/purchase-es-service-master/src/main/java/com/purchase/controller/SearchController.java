package com.purchase.controller;

import com.purchase.controller.request.SearchBarRequest;
import com.purchase.controller.request.SearchListRequest;
import com.purchase.service.SearchService;
import com.purchase.controller.request.SearchCataRequest;
import com.purchase.controller.request.SearchSelectRequest;
import com.purchase.service.model.Cata;
import com.purchase.service.vo.SearchBarVO;
import com.purchase.service.vo.SearchListVO;
import com.purchase.service.vo.SearchSelectionVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.TreeSet;

/**
 * @author jidonglin
 * @Description: 搜索控制器
 * @date 2023/3/22  11:05
 */
@RestController
@RequestMapping(value = "/search")
public class SearchController {

    @Autowired
    SearchService searchService;

    @PostMapping(value = "/all/bar")
    @Operation(summary = "搜索栏接口")
    @Auth(value = AuthType.NONE)
    public SearchBarVO allBar(@RequestBody @Validated SearchBarRequest searchBarRequest)  {
        return searchService.allBar(searchBarRequest);
    }

    @PostMapping(value = "/bar")
    @Operation(summary = "搜索栏接口")
    @Auth(value = AuthType.NONE)
    public SearchBarVO bar(@RequestBody @Validated SearchBarRequest searchBarRequest)  {
        return searchService.bar(searchBarRequest);
    }

    @PostMapping(value = "/select")
    @Operation(summary = "选型接口")
    @Auth(value = AuthType.NONE)
    public SearchSelectionVO select(@RequestBody @Validated SearchSelectRequest searchSelectRequest)  {
        return searchService.select(searchSelectRequest);
    }

    @PostMapping(value = "/list")
    @Operation(summary = "搜索列表")
    @Auth(value = AuthType.NONE)
    public SearchListVO list(@RequestBody SearchListRequest searchListRequest){
        return searchService.list(searchListRequest);
    }

    @PostMapping(value = "/cata/select")
    @Operation(summary = "商城端--分类树的获取")
    @Auth(value = AuthType.NONE)
    public TreeSet<Cata> cataSelect(@RequestBody SearchCataRequest searchCataRequest){
        return searchService.cataSelect(searchCataRequest);
    }
}
