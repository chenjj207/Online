package com.purchase.controller.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;


@Data
public class SearchBarRequest {
    @Schema(description = "搜索参数")
    @NotNull(message = "搜索参数不能为空")
    private String key;
}
