package com.purchase;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author jidonglin
 * @Description: 慧采商城搜索服务，连接online_common数据库
 * @date 2023/3/20  10:41
 */
@SpringCloudApplication
@ServletComponentScan(basePackages = {"com.purchase.*", "com.zyd.*"})
@ComponentScan(basePackages = {"com.purchase.**", "com.zyd.**"})
@MapperScan("com.purchase.mapper")
@EnableFeignClients
@RefreshScope
@EnableHystrix
@EnableAsync
public class ESApplication {
    public static void main(String[] args) {
        SpringApplication.run(ESApplication.class, args);
    }
}
