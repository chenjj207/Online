package com.purchase.mapper;

import com.purchase.entity.CommonCatalog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 分类表--公海基础表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-19
 */
@Mapper
public interface CommonCatalogMapper extends BaseMapper<CommonCatalog> {

}
