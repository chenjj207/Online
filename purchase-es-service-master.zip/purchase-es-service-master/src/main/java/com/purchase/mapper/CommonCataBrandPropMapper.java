package com.purchase.mapper;

import com.purchase.entity.CommonCataBrandProp;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 公海_分类、系列、品牌关系表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-19
 */
@Mapper
public interface CommonCataBrandPropMapper extends BaseMapper<CommonCataBrandProp> {

}
