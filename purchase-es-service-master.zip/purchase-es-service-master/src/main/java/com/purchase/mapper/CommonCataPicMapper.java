package com.purchase.mapper;

import com.purchase.entity.CommonCataPic;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 三级分类--产品关系表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-07-03
 */
@Mapper
public interface CommonCataPicMapper extends BaseMapper<CommonCataPic> {

}
