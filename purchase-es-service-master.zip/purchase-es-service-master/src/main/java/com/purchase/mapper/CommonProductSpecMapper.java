package com.purchase.mapper;

import com.purchase.entity.CommonProductSpec;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 公海_产品、规格关系表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-19
 */
@Mapper
public interface CommonProductSpecMapper extends BaseMapper<CommonProductSpec> {

}
