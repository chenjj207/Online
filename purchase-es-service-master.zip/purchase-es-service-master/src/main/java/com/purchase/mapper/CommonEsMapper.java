package com.purchase.mapper;

import com.purchase.entity.CommonEs;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 * 公海es字段数据 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-19
 */
@Mapper
public interface CommonEsMapper extends BaseMapper<CommonEs> {

}
