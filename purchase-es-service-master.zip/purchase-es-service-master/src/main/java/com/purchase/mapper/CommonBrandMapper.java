package com.purchase.mapper;

import com.purchase.entity.CommonBrand;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 品牌表--公海基础表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-19
 */
@Mapper
public interface CommonBrandMapper extends BaseMapper<CommonBrand> {

}
