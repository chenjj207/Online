package com.purchase.mapper;

import com.purchase.entity.CommonProp;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 产品系列--公海基础表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-19
 */
@Mapper
public interface CommonPropMapper extends BaseMapper<CommonProp> {

}
