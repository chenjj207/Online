package com.purchase.mapper;

import com.purchase.entity.CommonProduct;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 公海_产品表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-19
 */
@Mapper
public interface CommonProductMapper extends BaseMapper<CommonProduct> {

}
