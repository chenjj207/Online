package com.purchase.service;

import com.purchase.entity.CommonCataPic;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 三级分类--产品关系表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-07-03
 */
public interface CommonCataPicService extends IService<CommonCataPic> {

}
