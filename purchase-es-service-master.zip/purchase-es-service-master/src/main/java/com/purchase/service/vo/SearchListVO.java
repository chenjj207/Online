package com.purchase.service.vo;

import com.purchase.common.ESProduct;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * @author jidonglin
 * @Description: 搜索产品列表
 * @date 2021/7/23  9:54
 */
@Data
@Schema(title = "产品列表实体类")
public class SearchListVO extends PageDTO {
    @Schema(name = "产品列表")
    private List<ProductList> productList;

    @Data
    @Schema(name = "产品列表实体")
    public static class ProductList extends ESProduct {
        @Schema(name = "图片url")
        private String imgUrl;
        @Schema(name = "计量单位")
        private String unit;
        @Schema(name = "没有高亮的分类名")
        private String cataNameNotHighlight;
        @Schema(name = "品牌图片url")
        private String brandImgUrl;
    }

}
