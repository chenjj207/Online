package com.purchase.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.purchase.entity.CommonCataPic;
import com.purchase.mapper.CommonCataPicMapper;
import com.purchase.service.model.Cata;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/20  15:32
 */
@Service
public class CataService {

    @Resource
    CommonCataPicMapper commonCataPicMapper;
    /**
     * 根据分类分组信息构建分类生成树，分类信息中存在分类参数时设置状态为选中
     * @param cataList 结果分类列表
     * @param cataSelectedReqs 入参分类列表
     * @return
     */
    public TreeSet<Cata> createCataTrees(List<String> cataList, List<String> cataSelectedReqs){
        if(CollectionUtils.isEmpty(cataList)){
            return new TreeSet<>();
        }
        List<String> cataStringList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(cataSelectedReqs)){
            //分类只能单选
            String[] cataReq = cataSelectedReqs.get(0).split(" ");
            for(String i:cataReq){
                cataStringList.add(i);
            }
        }
        LinkedHashMap<String, List<String[]>> tempHashMap = new LinkedHashMap<>();

        TreeSet<Cata> rootList = new TreeSet<>();
        HashMap<String, String> rootNameMap = new HashMap<>();
        for (String cataLog : cataList) {
            String[] cataNames = cataLog.split(" ");
            String root = cataNames[0];
            if (tempHashMap.containsKey(root)){
                List<String[]> list = tempHashMap.get(root);
                list.add(cataNames);
                tempHashMap.put(root, list);
            }else {
                List<String[]> list = new ArrayList<>();
                list.add(cataNames);
                tempHashMap.put(root, list);
            }

            for (int j = 0; j < cataNames.length; j++) {
                Cata cata = new Cata();
                cata.setName(cataNames[j]);
                cata.setLevel(j+1);
                cata.setParentName(j==0 ? null : cataNames[j-1]);
                if (j == 0 && !rootNameMap.containsKey(root)){
                    rootList.add(cata);
                    rootNameMap.put(root, root);
                }
            }
        }

        HashMap<String, String> commonCataPicMap = new HashMap<>();
        List<CommonCataPic> commonCataPics = commonCataPicMapper.selectList(new QueryWrapper<>());
        for (CommonCataPic c : commonCataPics) {
            commonCataPicMap.put(c.getThreeCataName(), c.getProductPicName());
        }

        for (Cata root : rootList) {
            List<String[]> list = tempHashMap.get(root.getName());
            for (String[] s : list) {
                boolean isSelected = false;
                if (CollectionUtils.isNotEmpty(cataStringList)){
                    if (s[0].equals(cataStringList.get(0)) && s[1].equals(cataStringList.get(1)) && s[2].equals(cataStringList.get(2))){
                        isSelected = true;
                    }
                }
                if (!root.isSelected()){
                    root.setSelected(isSelected);
                }
                buildTree(root, s, 0, isSelected, commonCataPicMap);
            }
        }
        return rootList;
    }

    private static void buildTree(Cata parent, String[] values, int i, boolean isSelected, HashMap<String, String> commonCataPicMap) {
        if (values.length == 0) {
            return;
        }
        if (i == 2){
            return;
        }
        if (i == 0){
            if (!parent.getName().equals(values[i])){
                return;
            }
        }
        Cata child = new Cata();
        child.setName(values[1]);
        child.setParentName(values[0]);
        child.setLevel(i+2);
        child.setSelected(isSelected);

        if (child.getLevel() == 3){
            //三级分别时，携带图片
            child.setCataPicUrl(commonCataPicMap.get(values[1]));
        }

        if (CollectionUtils.isNotEmpty(parent.getChild())){
            boolean isAdd = true;
            for (Cata c : parent.getChild()) {
                if (c.getName().equals(child.getName())){
                    isAdd = false;
                    child = c;
                    break;
                }
            }
            if (isAdd){
                List<Cata> childCata = parent.getChild();
                childCata.add(child);
                parent.setChild(childCata);
            }
        }else {
            List<Cata> childCata = new ArrayList<>();
            childCata.add(child);
            parent.setChild(childCata);
        }
        i++;
        if (values.length > 1) {
            buildTree(child, Arrays.copyOfRange(values, 1, values.length), i, isSelected, commonCataPicMap);
        }
    }

}
