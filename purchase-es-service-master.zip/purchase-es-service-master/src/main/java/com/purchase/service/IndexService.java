package com.purchase.service;

import com.alibaba.fastjson.JSON;
import com.purchase.common.ESProduct;
import com.purchase.config.ESBusinessExceptionDesc;
import com.zyd.framework.utils.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.IndexOperations;
import org.springframework.data.elasticsearch.core.document.Document;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author jidonglin
 * @Description: 索引管理服务层
 * @date 2023/4/19  11:51
 */
@Service
public class IndexService {

    private Logger logger = LoggerFactory.getLogger(IndexService.class);

    @Resource
    ElasticsearchRestTemplate elasticsearchRestTemplate;

    @Value("${elasticsearch.indexName}")
    private String indexName;

    /**
     * 创建ES索引，使用json文件配置setting，实体类映射mapping
     * @author zenghuanlin
     */
    public void createdIndex() throws IOException {
        String path = "/setting/setting.json";
        InputStream settingConfig = getClass().getResourceAsStream(path);
        if (settingConfig == null) {
            throw BusinessException.newInstance(ESBusinessExceptionDesc.FILE_DOES_NOT_EXIST);
        }
        String json = JSON.parseObject(settingConfig, String.class);
        IndexOperations indexOperations = elasticsearchRestTemplate.indexOps(IndexCoordinates.of(indexName));
        Document settings = Document.parse(json);
        logger.info("创建字段配置：" + settings.toJson());
        indexOperations.create(settings);
        Document mapping = indexOperations.createMapping(ESProduct.class);
        logger.info("创建索引字段：" + mapping.toJson());
        indexOperations.putMapping(mapping);
    }
}
