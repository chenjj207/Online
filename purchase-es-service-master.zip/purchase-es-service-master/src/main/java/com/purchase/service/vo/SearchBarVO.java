package com.purchase.service.vo;

import com.purchase.common.ESProduct;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
@Schema(title = "搜索栏结果")
public class SearchBarVO {
    private List<ESProduct> products;

    private RecommendBrand recommendBrand;

    private RecommendProp recommendProp;

    @Data
    public static class RecommendBrand{
        //品牌id
        private Long id;
        //品牌名称
        private String brandName;
        //品牌图片
        private String imgUrl;
    }

    @Data
    public static class RecommendProp{
        //系列名称
        private String propName;
    }
}
