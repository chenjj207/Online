package com.purchase.service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class Brand {
    @Schema(description = "品牌名")
    private String name;
    @Schema(description = "是否选中")
    private boolean selected = false;
}
