package com.purchase.service;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.common.ESProduct;
import com.purchase.config.ESBusinessExceptionDesc;
import com.purchase.entity.CommonBrand;
import com.purchase.entity.CommonEs;
import com.purchase.mapper.CommonBrandMapper;
import com.purchase.mapper.CommonEsMapper;
import com.purchase.util.StringNameUtils;
import com.zyd.framework.utils.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/21 13:34
 */
@Service
@Slf4j
public class SyncService {

    @Resource
    CommonEsMapper commonEsMapper;
    @Resource
    CommonBrandMapper commonBrandMapper;

    @Autowired
    private RestHighLevelClient esClient;

    @Value("${elasticsearch.indexName}")
    private String index;

    @Async
    public Boolean syncDataToES(){
        int pageNum = 1;
        QueryWrapper<CommonBrand> queryWrapper = new QueryWrapper<>();
        List<CommonBrand> brandList = commonBrandMapper.selectList(queryWrapper);
        List<String> brandNameList = brandList.stream().map(CommonBrand::getBrandName).collect(Collectors.toList());
        while (true) {
            QueryWrapper<CommonEs> wrapper = new QueryWrapper<>();
//            wrapper.eq("ifs_main_procurement", "上海供应链").isNotNull("purchase_price");
            Page<CommonEs> commonEsList = commonEsMapper.selectPage(Page.of(pageNum, 5000), wrapper);
            if (commonEsList == null || CollectionUtils.isEmpty(commonEsList.getRecords())) {
                break;
            }
            createToES(brandNameList, commonEsList.getRecords());
            pageNum++;
        }
        log.info("商品同步结束");
        return true;
    }

    private void createToES(List<String> brandNameList, List<CommonEs> commonEsList) {
        long startTime = System.currentTimeMillis();
        try {
            List<ESProduct> esProductsList = new ArrayList<>();
            BulkRequest bulkRequest = new BulkRequest();
            for (CommonEs commonEs : commonEsList) {

                ESProduct esProducts = BeanUtil.copyProperties(commonEs, ESProduct.class, "brandId", "brandName", "brandOrder");
                if (commonEs.getBrandId() != null){
                    esProducts.setBrandId(commonEs.getBrandId());
                    esProducts.setBrandName(commonEs.getBrandName());
                    esProducts.setBrandOrder(commonEs.getBrandOrder());
                }
                String propName = commonEs.getPropName();
                esProducts.setPropNameFull(propName);
                if (brandNameList.contains(StringNameUtils.getPropNoName(propName))){
                    esProducts.setPropName(StringNameUtils.clearBracket(propName));
                }
                String specs = commonEs.getSpecsArr1();
                if (StringUtils.isNotEmpty(specs)){
                    List<ESProduct.SpecValsArr> specValsArr = new ArrayList<>();
                    //规格:规格值  三个空格隔开
                    String[] specsArr = specs.split("@@@@");
                    int i = 1;
                    for (String specVal : specsArr) {
                        String[] specValArr = specVal.split(":");
                        try {
                            ESProduct.SpecValsArr specSpecVal = new ESProduct.SpecValsArr();
                            specSpecVal.setSpecName(specValArr[0]);
                            specSpecVal.setSpecValName(specValArr[1]);
                            specSpecVal.setSpecOrder(i);
                            specValsArr.add(specSpecVal);
                        }catch (Exception e){
                            log.error(ESBusinessExceptionDesc.ERROR_SYNC_CORP.getDesc(), e);
                        }
                        i++;
                    }
                    esProducts.setSpecValsArr(specValsArr);
                }
                Map<String, Object> jsonMap = JSON.parseObject(JSON.toJSONString(esProducts), Map.class);
                IndexRequest indexRequest = new IndexRequest();
                indexRequest.index(index);
                indexRequest.id(String.valueOf(esProducts.getProductId()));
                indexRequest.source(jsonMap);

                esProductsList.add(esProducts);
                bulkRequest.add(indexRequest);
            }
            BulkResponse bulkResponse = esClient.bulk(bulkRequest, RequestOptions.DEFAULT);
            long endTime = System.currentTimeMillis();
            log.info("同步产品分页数据到es的时间为" + ((endTime-startTime)/1000) +"秒");
        } catch (IOException e) {
            log.error(ESBusinessExceptionDesc.ERROR_SYNC_CORP.getDesc(), e);
            throw BusinessException.newInstance(ESBusinessExceptionDesc.ERROR_SYNC_CORP);
        }catch (Exception e){
            log.error(ESBusinessExceptionDesc.ERROR_SYNC_CORP.getDesc(), e);
            throw BusinessException.newInstance(ESBusinessExceptionDesc.ERROR_SYNC_CORP);
        }
    }

    /**
     * 更新商品列表的es数据
     * @param ids
     * @return
     */
    @Async
    public Boolean update(List<String> ids){
        QueryWrapper<CommonBrand> queryWrapper = new QueryWrapper<>();
        List<CommonBrand> brandList = commonBrandMapper.selectList(queryWrapper);
        List<String> brandNameList = brandList.stream().map(CommonBrand::getBrandName).collect(Collectors.toList());
        List<CommonEs> commonEsList = commonEsMapper.selectBatchIds(ids);
        if (commonEsList == null || CollectionUtils.isEmpty(commonEsList)) {
            log.info("id列表不存在商品数据");
            return true;
        }
        createToES(brandNameList, commonEsList);
        return true;
    }

    /**
     * 更新商品列表的es数据
     * @param brands
     * @return
     */
    @Async
    public Boolean updateByBrand(List<String> brands){
        QueryWrapper<CommonBrand> queryWrapper = new QueryWrapper<>();
        List<CommonBrand> brandList = commonBrandMapper.selectList(queryWrapper);
        List<String> brandNameList = brandList.stream().map(CommonBrand::getBrandName).collect(Collectors.toList());
        int pageNum = 1;
        while (true) {
            QueryWrapper<CommonEs> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.in("brand_id", brands);
            Page<CommonEs> commonEsList = commonEsMapper.selectPage(Page.of(pageNum, 5000), queryWrapper1);
            if (commonEsList == null || CollectionUtils.isEmpty(commonEsList.getRecords())) {
                break;
            }
            createToES(brandNameList, commonEsList.getRecords());
            pageNum++;
        }
        return true;
    }

    @Async
    public Boolean updateBySupplierIds(List<String> supplierIds){
        QueryWrapper<CommonBrand> queryWrapper = new QueryWrapper<>();
        List<CommonBrand> brandList = commonBrandMapper.selectList(queryWrapper);
        List<String> brandNameList = brandList.stream().map(CommonBrand::getBrandName).collect(Collectors.toList());

        QueryWrapper<CommonEs> commonEsQueryWrapper = new QueryWrapper<>();
        commonEsQueryWrapper.in("supplier_id", supplierIds);
        List<CommonEs> commonEsList = commonEsMapper.selectList(commonEsQueryWrapper);
        if (commonEsList == null || CollectionUtils.isEmpty(commonEsList)) {
            log.info("id列表不存在商品数据");
            return true;
        }
        createToES(brandNameList, commonEsList);
        return true;
    }
}
