package com.purchase.service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class Prop {
    @Schema(description = "系列名称")
    private String name;
    @Schema(description = "是否选中")
    private boolean selected = false;
}
