package com.purchase.service.vo;


import com.purchase.service.model.Brand;
import com.purchase.service.model.Cata;
import com.purchase.service.model.Prop;
import com.purchase.service.model.Spec;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;
import java.util.TreeSet;

@Data
@Schema(title = "选型结果")
public class SearchSelectionVO {
    @Schema(name = "品牌列表")
    public List<Brand> brands;
    @Schema(name = "系列列表")
    public List<Prop> props;
    @Schema(name = "分类列表")
    public TreeSet<Cata> catas;
    @Schema(name = "规格列表")
    public List<Spec> specs;
}
