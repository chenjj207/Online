package com.purchase.service;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.purchase.common.ESConstants;
import com.purchase.common.ESProduct;
import com.purchase.config.CommonOssConf;
import com.purchase.config.ESBusinessExceptionDesc;
import com.purchase.controller.request.SearchBarRequest;
import com.purchase.controller.request.SearchCataRequest;
import com.purchase.controller.request.SearchListRequest;
import com.purchase.controller.request.SearchSelectRequest;
import com.purchase.entity.CommonBrand;
import com.purchase.mapper.CommonBrandMapper;
import com.purchase.service.model.Brand;
import com.purchase.service.model.Cata;
import com.purchase.service.model.Prop;
import com.purchase.service.model.Spec;
import com.purchase.service.vo.SearchBarVO;
import com.purchase.service.vo.SearchListVO;
import com.purchase.service.vo.SearchSelectionVO;
import com.purchase.util.StringNameUtils;
import com.zyd.framework.utils.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.bucket.nested.ParsedNested;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedStringTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;


/**
 * @author jidonglin
 * @Description:
 * @date 2023/3/22  13:34
 */
@Service
@Slf4j
public class SearchService {

    @Autowired
    SearchBuilderService searchBuilderService;
    @Autowired
    CataService cataService;

    @Resource
    CommonBrandMapper commonBrandMapper;

    @Autowired
    CommonOssConf commonOssConf;

    @Value("${textmarksize}")
    private String textmarksize;

    /**
     * ES搜索栏 针对所有商品查询
     * @return
     */
    public SearchBarVO allBar(SearchBarRequest searchBarRequest) {
        SearchResponse response = searchBuilderService.search(searchBuilderService.barTermAllQuery(searchBarRequest.getKey()));
        //精准匹配得到数据直接返回
        if (BeanUtil.isNotEmpty(response) && response.getHits().getTotalHits().value != 0) {
            return createSearchBar(response);
        }
        //精准匹配没有数据，使用模糊匹配
        response = searchBuilderService.search(searchBuilderService.barMatchAllQuery(searchBarRequest.getKey()));
        return createSearchBar(response);
    }

    /**
     * ES搜索栏提示框
     * @return
     */
    public SearchBarVO bar(SearchBarRequest searchBarRequest) {
        SearchResponse response = searchBuilderService.search(searchBuilderService.barTermQuery(searchBarRequest.getKey()));
        //精准匹配得到数据直接返回
        if (BeanUtil.isNotEmpty(response) && response.getHits().getTotalHits().value != 0) {
            return createSearchBar(response);
        }
        //精准匹配没有数据，使用模糊匹配
        response = searchBuilderService.search(searchBuilderService.barMatchQuery(searchBarRequest.getKey()));
        return createSearchBar(response);
    }

    /**
     * ES搜索栏结果处理返回
     * @return
     */
    private SearchBarVO createSearchBar(SearchResponse response) {
        SearchHit[] searchHits = response.getHits().getHits();
        List<ESProduct> productsList = new ArrayList<>();
        Set<String> brandSet = new HashSet<>();
        Set<String> propSet = new HashSet<>();
        for (SearchHit searchHit : searchHits) {
            ESProduct products = JSONObject.parseObject(searchHit.getSourceAsString(), ESProduct.class);
            if (products.getPurchasePrice() != null){
                products.setPurchasePrice(new BigDecimal(products.getPurchasePrice()).setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue());
            }
            brandSet.add(products.getBrandName());
            propSet.add(products.getPropName());
            Map<String, HighlightField> map = searchHit.getHighlightFields();
            products.setSkuCode(map.get("skuCode") != null ? map.get("skuCode").fragments()[0].string() : products.getSkuCode());
            products.setBrandName(map.get("brandName") != null ? map.get("brandName").fragments()[0].string() : products.getBrandName());
            products.setCataName(map.get("cataName") != null ? map.get("cataName").fragments()[0].string() : products.getCataName());
            products.setThreeCataName(map.get("threeCataName") != null ? map.get("threeCataName").fragments()[0].string() : products.getThreeCataName());
            products.setPropName(map.get("propName") != null ? map.get("propName").fragments()[0].string() : products.getPropName());
            products.setProductType(map.get("productType") != null ? map.get("productType").fragments()[0].string() : products.getProductType());
            products.setProductType(map.get("productType.kw") != null ? map.get("productType.kw").fragments()[0].string() : products.getProductType());
            products.setSearchset(map.get("searchset") != null ? map.get("searchset").fragments()[0].string() : products.getSearchset());
            products.setSearchset(map.get("searchset.ik") != null ? map.get("searchset.ik").fragments()[0].string() : products.getSearchset());
            products.setUnit(map.get("unit") != null ? map.get("unit").fragments()[0].string() : products.getUnit());
            productsList.add(products);
        }
        SearchBarVO searchBarResponse = new SearchBarVO();
        searchBarResponse.setProducts(productsList);
        //判断是否有推荐品牌，搜索出来的结果都是同一个品牌则推荐该品牌
        if (brandSet.size() == 1){
            List<String> brands = new ArrayList<>(brandSet);
            if (StringUtils.isNotEmpty(brands.get(0))){
                QueryWrapper<CommonBrand> wrapper = new QueryWrapper<>();
                wrapper.eq("brand_name", brands.get(0));
                List<CommonBrand> commonBrands = commonBrandMapper.selectList(wrapper);
                if (CollectionUtils.isNotEmpty(commonBrands)){
                    CommonBrand commonBrand = commonBrands.get(0);
                    SearchBarVO.RecommendBrand recommendBrand = new SearchBarVO.RecommendBrand();
                    recommendBrand.setBrandName(brands.get(0));
                    recommendBrand.setId(commonBrands.get(0).getBrandId());
                    if (StringUtils.equalsIgnoreCase(ESConstants.BrandSource.ZYDMALL.code, commonBrand.getSource())){
                        StringBuilder brandImgUrl = new StringBuilder();
                        brandImgUrl.append(commonOssConf.getOssUrl()).append("product/brand/").append(brands.get(0) + "/").append(brands.get(0) + "logo.png");
                        recommendBrand.setImgUrl(brandImgUrl.toString());
                    }else {
                        //非zydmall的慧采商品品牌，包括供应链或供应商新增，直接获取图片字段
                        if (StringUtils.isNotEmpty(commonBrand.getPicUrl())){
                            recommendBrand.setImgUrl(commonBrand.getPicUrl());
                        }
                    }
                    searchBarResponse.setRecommendBrand(recommendBrand);
                }
            }
        }
        //推荐系列
        if (propSet.size() == 1){
            List<String> props = new ArrayList<>(propSet);
            SearchBarVO.RecommendProp recommendProp = new SearchBarVO.RecommendProp();
            recommendProp.setPropName(props.get(0));
            searchBarResponse.setRecommendProp(recommendProp);
        }
        return searchBarResponse;
    }


    /**
     * ES规格选型接口
     * @param searchSelectRequest 入参
     * @return
     */
    public SearchSelectionVO select(SearchSelectRequest searchSelectRequest) {
        if (BeanUtil.isEmpty(searchSelectRequest)) {
            throw BusinessException.newInstance(ESBusinessExceptionDesc.SEARCH_PARAMETERS_NOT_EXIST);
        }
        //处理系列
        searchSelectRequest.setProps(preDetailProp(searchSelectRequest.getProps()));
        SearchResponse termResponse = searchBuilderService.search(searchBuilderService.selectTermQuery(searchSelectRequest));
        if (BeanUtil.isNotEmpty(termResponse) && termResponse.getHits().getTotalHits().value != 0) {
            return termSearchStruct(searchSelectRequest, termResponse);
        }else {
            SearchResponse matchResponse = searchBuilderService.search(searchBuilderService.selectMatchQuery(searchSelectRequest));
            if (BeanUtil.isNotEmpty(matchResponse) && matchResponse.getHits().getTotalHits().value != 0){
                return matchSearchStruct(searchSelectRequest, matchResponse);
            }
        }
        SearchSelectionVO searchSelectionVo = new SearchSelectionVO();
        return searchSelectionVo;
    }

    /**
     * 处理入参系列，去掉系列括号内容
     * @param props
     * @return
     */
    private List<String>  preDetailProp(List<String> props) {
        List<String> propReq = new ArrayList<>();
        //获取所有的品牌列表
        QueryWrapper<CommonBrand> wrapper = new QueryWrapper<>();
        List<CommonBrand> brandList = commonBrandMapper.selectList(wrapper);
        List<String> brandNameList = brandList.stream().map(CommonBrand::getBrandName).collect(Collectors.toList());
        //去除系列中包含品牌信息的字符
        if (CollectionUtils.isNotEmpty(props)){
            for (String propName: props) {
                if (brandNameList.contains(StringNameUtils.getPropNoName(propName))){
                    propName = StringNameUtils.clearBracket(propName);
                    propReq.add(propName);
                }else {
                    propReq.add(propName);
                }
            }
        }
        return propReq;
    }

    /**
     * term 精准选型
     * @param searchSelectRequest
     * @return
     */
    private SearchSelectionVO termSearchStruct(SearchSelectRequest searchSelectRequest, SearchResponse termResponse) {
        //无【系列】条件 推出【系列】，增加条件是否展示系列
        SearchSelectRequest noPropSearchSelectRequest = BeanUtil.copyProperties(searchSelectRequest, SearchSelectRequest.class, "props");
        SearchResponse propResponse = searchBuilderService.search(searchBuilderService.selectTermQueryWithShowProp(noPropSearchSelectRequest));
        ParsedStringTerms showPropNameTerms = propResponse.getAggregations().get("propNameAgg");

        //无【分类】条件 推出【分类】
        SearchSelectRequest noCataSearchSelectRequest = BeanUtil.copyProperties(searchSelectRequest, SearchSelectRequest.class, "catas");
        SearchResponse cataResponse = searchBuilderService.search(searchBuilderService.selectTermQuery(noCataSearchSelectRequest));
        ParsedStringTerms cataNameTerms = cataResponse.getAggregations().get("cataNameAgg");

        //无【品牌】条件 推出【品牌】
        SearchSelectRequest noBrandSearchSelectRequest = BeanUtil.copyProperties(searchSelectRequest, SearchSelectRequest.class, "brands");
        SearchResponse brandResponse = searchBuilderService.search(searchBuilderService.selectTermQuery(noBrandSearchSelectRequest));
        ParsedStringTerms brandNameterms = brandResponse.getAggregations().get("brandNameAgg");

        //无【规格-规格值】条件 推出【规格-规格值】
        SearchSelectRequest noSepcValSearchSelectRequest = BeanUtil.copyProperties(searchSelectRequest, SearchSelectRequest.class, "specs");
        SearchResponse specResponse = searchBuilderService.search(searchBuilderService.selectTermQuery(noSepcValSearchSelectRequest));
        ParsedNested specspecValTerms = specResponse.getAggregations().get("specValsArrAgg");

        ParsedNested specspecValTermsByAllSelect = termResponse.getAggregations().get("specValsArrAgg");
        return createSelectResponse(showPropNameTerms, cataNameTerms, brandNameterms, specspecValTerms, specspecValTermsByAllSelect, searchSelectRequest, true);
    }

    /**
     * match 选型结构
     * @param searchSelectRequest
     * @return
     */
    private SearchSelectionVO matchSearchStruct(SearchSelectRequest searchSelectRequest, SearchResponse matchResponse) {
        //无【系列】条件 推出【系列】，增加条件是否展示系列
        SearchSelectRequest noPropSearchSelectRequest = BeanUtil.copyProperties(searchSelectRequest, SearchSelectRequest.class, "props");
        SearchResponse propResponse = searchBuilderService.search(searchBuilderService.selectMatchQueryWithShowProp(noPropSearchSelectRequest));
        ParsedStringTerms showPropNameTerms = propResponse.getAggregations().get("propNameAgg");

        //无【分类】条件 推出【分类】
        SearchSelectRequest noCataSearchSelectRequest = BeanUtil.copyProperties(searchSelectRequest, SearchSelectRequest.class, "catas");
        SearchResponse cataResponse = searchBuilderService.search(searchBuilderService.selectMatchQuery(noCataSearchSelectRequest));
        ParsedStringTerms cataNameTerms = cataResponse.getAggregations().get("cataNameAgg");

        //无【品牌】条件 推出【品牌】
        SearchSelectRequest noBrandSearchSelectRequest = BeanUtil.copyProperties(searchSelectRequest, SearchSelectRequest.class, "brands");
        SearchResponse brandResponse = searchBuilderService.search(searchBuilderService.selectMatchQuery(noBrandSearchSelectRequest));
        ParsedStringTerms brandNameterms = brandResponse.getAggregations().get("brandNameAgg");

        //无【规格-规格值】条件 推出【规格-规格值】
        SearchSelectRequest noSepcValSearchSelectRequest = BeanUtil.copyProperties(searchSelectRequest, SearchSelectRequest.class, "specs");
        SearchResponse specResponse = searchBuilderService.search(searchBuilderService.selectMatchQuery(noSepcValSearchSelectRequest));
        ParsedNested specspecValTerms = specResponse.getAggregations().get("specValsArrAgg");

        //所有条件下 推出【规格-规格值】
        ParsedNested specspecValMatchsByAllSelect = matchResponse.getAggregations().get("specValsArrAgg");
        return createSelectResponse(showPropNameTerms, cataNameTerms, brandNameterms, specspecValTerms, specspecValMatchsByAllSelect, searchSelectRequest, false);
    }

    private SearchSelectionVO createSelectResponse(ParsedStringTerms showPropNameTerms, ParsedStringTerms cataNameTerms,
                                                   ParsedStringTerms brandNameterms, ParsedNested specspecValTerms, ParsedNested specspecValTermsByAllSelect,
                                                   SearchSelectRequest searchSelectRequest, boolean isTerm){
        SearchSelectionVO searchSelectionVo = new SearchSelectionVO();
        List<Prop> showProps = new ArrayList<>();
        if (showPropNameTerms != null){
            List<? extends Terms.Bucket> propBuckets = showPropNameTerms.getBuckets();
            if (CollectionUtils.isNotEmpty(propBuckets)){
                for (Terms.Bucket bucket : propBuckets) {
                    String bucketKey = bucket.getKey().toString();
                    if (StringUtils.isNotEmpty(bucketKey)){
                        Prop prop = new Prop();
                        prop.setName(bucketKey);
                        if (CollectionUtils.isNotEmpty(searchSelectRequest.getProps()) && searchSelectRequest.getProps().contains(bucketKey)){
                            prop.setSelected(true);
                        }
                        showProps.add(prop);
                    }
                }
            }
        }
        searchSelectionVo.setProps(showProps);

        List<String> catas = new ArrayList<>();
        if (cataNameTerms != null){
            List<? extends Terms.Bucket> cataBuckets = cataNameTerms.getBuckets();
            if (CollectionUtils.isNotEmpty(cataBuckets)){
                for (Terms.Bucket bucket : cataBuckets) {
                    String bucketKey = bucket.getKey().toString();
                    if (StringUtils.isNotEmpty(bucketKey)){
                        catas.add(bucketKey);
                    }
                }
            }
        }
        searchSelectionVo.setCatas(cataService.createCataTrees(catas, searchSelectRequest.getCatas()));

        List<Brand> brands = new ArrayList<>();
        if (brandNameterms != null){
            List<? extends Terms.Bucket> brandBuckets = brandNameterms.getBuckets();
            if (CollectionUtils.isNotEmpty(brandBuckets)){
                for (Terms.Bucket bucket : brandBuckets) {
                    String bucketKey = bucket.getKey().toString();
                    if (StringUtils.isNotEmpty(bucketKey)){
                        Brand brand = new Brand();
                        brand.setName(bucketKey);
                        if (CollectionUtils.isNotEmpty(searchSelectRequest.getBrands()) && searchSelectRequest.getBrands().contains(bucketKey)){
                            brand.setSelected(true);
                        }
                        brands.add(brand);
                    }
                }
            }
        }

        searchSelectionVo.setBrands(brands);
        //去除规格条件 的其他条件推出的【规格：规格值】
        List<Spec> specsWithNoSpec = getSpecs(specspecValTerms);
        //所有的条件下条件推出的【规格：规格值】
        List<Spec> specsWithAllSelect = getSpecs(specspecValTermsByAllSelect);
        //组成【规格 规格值列表】hashmap
        HashMap<String, List<Spec.SpecVal>> allSelectHashMap = new HashMap<>();
        for (Spec spec : specsWithAllSelect) {
            allSelectHashMap.put(spec.getName(), spec.getSpecVals());
        }


        if (CollectionUtils.isNotEmpty(searchSelectRequest.getSpecs()) && CollectionUtils.isNotEmpty(specsWithNoSpec)){
            //已选的规格值
            List<String> specValList = new ArrayList<>();
            //已选的规格名称
            HashMap<String, Spec> specNameReqMap = new HashMap<>();
            for (Spec spec : searchSelectRequest.getSpecs()) {
                specNameReqMap.put(spec.getName(), spec);
                List<Spec.SpecVal> specVals = spec.getSpecVals();
                for (Spec.SpecVal specVal : specVals) {
                    specValList.add(specVal.getValue());
                }
            }
            Iterator iterator = specsWithNoSpec.iterator();
            while (iterator.hasNext()){
                Spec resultSpec = (Spec) iterator.next();

                //如果查询出的规格不包含入参的条件规格，使用allSelectHashMap对应的规格值列表
                if (!specNameReqMap.containsKey(resultSpec.getName()) && allSelectHashMap.containsKey(resultSpec.getName())){
                    resultSpec.setSpecVals(allSelectHashMap.get(resultSpec.getName()));
                    continue;
                }
                if (!allSelectHashMap.containsKey(resultSpec.getName())){
                    iterator.remove();
                    continue;
                }
                HashMap<String, Spec> tempSpecNameReqMap = new HashMap<>();
                specNameReqMap.forEach((k,v)->{
                    tempSpecNameReqMap.put(k,v);
                });
                tempSpecNameReqMap.remove(resultSpec.getName());
                List<Spec> tempSpecList = new ArrayList<>();
                tempSpecNameReqMap.forEach((k,v)->{
                    tempSpecList.add(v);
                });
                //规格条件使用剔除当前已选的规格进行查询
                SearchSelectRequest noSepcValSearchSelectRequest = BeanUtil.copyProperties(searchSelectRequest, SearchSelectRequest.class, "specs");
                noSepcValSearchSelectRequest.setSpecs(tempSpecList);
                SearchResponse specResponse = null;
                if (isTerm){
                    specResponse = searchBuilderService.search(searchBuilderService.selectTermQuery(noSepcValSearchSelectRequest));
                }else {
                    specResponse = searchBuilderService.search(searchBuilderService.selectMatchQuery(noSepcValSearchSelectRequest));
                }

                List<Spec> specResults = new ArrayList<>();
                ParsedNested specspecValTermsTemp = specResponse.getAggregations().get("specValsArrAgg");
                if (specspecValTermsTemp!= null){
                    //获取规格和规格值
                    ParsedStringTerms specTerms = specspecValTermsTemp.getAggregations().get("specName");
                    List<? extends Terms.Bucket> specBuckets = specTerms.getBuckets();

                    if (CollectionUtils.isNotEmpty(specBuckets)){
                        for (Terms.Bucket bucket : specBuckets) {
                            Spec spec = new Spec();
                            String bucketKey = bucket.getKey().toString();
                            if (StringUtils.isNotEmpty(bucketKey)){
                                spec.setName(bucketKey);
                            }
                            Terms specValName = bucket.getAggregations().get("specValName");
                            List<? extends Terms.Bucket> buckets1 = specValName.getBuckets();
                            List<Spec.SpecVal> specVals = new ArrayList<>();
                            for (Terms.Bucket bucket1 : buckets1) {
                                Spec.SpecVal specVal = new Spec.SpecVal();
                                specVal.setValue(bucket1.getKeyAsString());
                                specVals.add(specVal);
                            }
                            spec.setSpecVals(specVals);
                            specResults.add(spec);
                        }
                    }
                }
                List<Spec> specResults1 = specResults.stream().filter(j->j.getName().equals(resultSpec.getName())).collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(specResults1)){
                    resultSpec.setSpecVals(specResults1.get(0).getSpecVals());
                }
                List<Spec.SpecVal> specVals = resultSpec.getSpecVals();
                if (CollectionUtils.isNotEmpty(specVals)){
                    for (Spec.SpecVal specVal : specVals) {
                        //已选规格名和已选规格值都包含，则设置为选中
                        if (specValList.contains(specVal.getValue()) && specNameReqMap.containsKey(resultSpec.getName())){
                            specVal.setSelected(true);
                        }
                    }
                }
            }
        }

        searchSelectionVo.setSpecs(specsWithNoSpec);
        return searchSelectionVo;
    }

    private List<Spec> getSpecs(ParsedNested specspecValTerms) {
        List<Spec> specs = new ArrayList<>();
        if (specspecValTerms != null){
            //获取规格和规格值
            ParsedStringTerms specTerms = specspecValTerms.getAggregations().get("specName");
            List<? extends Terms.Bucket> specBuckets = specTerms.getBuckets();

            if (CollectionUtils.isNotEmpty(specBuckets)){
                for (Terms.Bucket bucket : specBuckets) {
                    Spec spec = new Spec();
                    String bucketKey = bucket.getKey().toString();
                    if (StringUtils.isNotEmpty(bucketKey)){
                        spec.setName(bucketKey);
                    }
                    Terms specValName = bucket.getAggregations().get("specValName");
                    List<? extends Terms.Bucket> buckets1 = specValName.getBuckets();
                    List<Spec.SpecVal> specVals = new ArrayList<>();
                    for (Terms.Bucket bucket1 : buckets1) {
                        Spec.SpecVal specVal = new Spec.SpecVal();
                        specVal.setValue(bucket1.getKeyAsString());
                        specVals.add(specVal);
                    }
                    spec.setSpecVals(specVals);
                    specs.add(spec);
                }
            }
        }
        return specs;
    }

    /***
     * 分类树获取
     * @param searchCataRequest
     * @return
     */
    public TreeSet<Cata> cataSelect(SearchCataRequest searchCataRequest){
        SearchResponse response = searchBuilderService.search(searchBuilderService.buildCataTree(searchCataRequest));
        List<String> catas = new ArrayList<>();
        // 从分组后的数据中拿到cataNameAgg的数据
        ParsedStringTerms cataNameTerms = response.getAggregations().get("cataNameAgg");
        if (cataNameTerms != null) {
            List<? extends Terms.Bucket> cataBuckets = cataNameTerms.getBuckets();
            if (CollectionUtils.isNotEmpty(cataBuckets)) {
                for (Terms.Bucket bucket : cataBuckets) {
                    String bucketKey = bucket.getKey().toString();
                    if (StringUtils.isNotEmpty(bucketKey)) {
                        catas.add(bucketKey);
                    }
                }
            }
        }
        if (CollectionUtils.isEmpty(catas)) {
            TreeSet<Cata> cataList = new TreeSet<>();
            return cataList;
        }
        String cataSelected = searchCataRequest.getCataSelected();
        if (StringUtils.isEmpty(cataSelected)) {
            cataSelected = catas.get(0);
        }
        List<String> cataSelectedList = new ArrayList<>();
        cataSelectedList.add(cataSelected);
        TreeSet<Cata> cataList = cataService.createCataTrees(catas, cataSelectedList);
        return cataList;
    }

    /**
     * 查询商品列表
     * @param searchListRequest
     * @return
     */
    public SearchListVO list(SearchListRequest searchListRequest){
        if (BeanUtil.isEmpty(searchListRequest)) {
            throw BusinessException.newInstance(ESBusinessExceptionDesc.SEARCH_PARAMETERS_NOT_EXIST);
        }
        //处理系列带括号的名称 去掉
        searchListRequest.setProps(preDetailProp(searchListRequest.getProps()));
        SearchListVO searchListVO = new SearchListVO();
        SearchResponse response = searchBuilderService.search(searchBuilderService.listTermQuery(searchListRequest));
        if (BeanUtil.isEmpty(response) || response.getHits().getTotalHits().value == 0) {
            response = searchBuilderService.search(searchBuilderService.listMatchQuery(searchListRequest));
            if (BeanUtil.isEmpty(response) || response.getHits().getTotalHits().value == 0){
                return searchListVO;
            }
        }
        SearchHit[] searchHits = response.getHits().getHits();
        List<SearchListVO.ProductList> productsList = new ArrayList<>();
        for (SearchHit searchHit : searchHits) {
            SearchListVO.ProductList products = JSONObject.parseObject(searchHit.getSourceAsString(), SearchListVO.ProductList.class);
            Map<String, HighlightField> map = searchHit.getHighlightFields();
            products.setCataNameNotHighlight(products.getCataName());
            products.setSkuCode(map.get("skuCode") != null ? map.get("skuCode").fragments()[0].string() : products.getSkuCode());
            products.setCataName(map.get("cataName") != null ? map.get("cataName").fragments()[0].string() : products.getCataName());
            products.setPropName(map.get("propName") != null ? map.get("propName").fragments()[0].string() : products.getPropName());
            products.setThreeCataName(map.get("threeCataName") != null ? map.get("threeCataName").fragments()[0].string() : products.getThreeCataName());
            products.setSearchset(map.get("searchset") != null ? map.get("searchset").fragments()[0].string() : products.getSearchset());
            products.setSpecs(map.get("specs") != null ? map.get("specs").fragments()[0].string() : products.getSpecs());
            products.setProductType(map.get("productType") != null ? map.get("productType").fragments()[0].string() : products.getProductType());
            productsList.add(products);
        }
        if (CollectionUtils.isNotEmpty(productsList)){
            List<Long> brandIds = productsList.stream().map(SearchListVO.ProductList::getBrandId).collect(Collectors.toList());
            QueryWrapper<CommonBrand> queryWrapper = new QueryWrapper<>();
            queryWrapper.in("brand_id", brandIds);
            List<CommonBrand> commonBrands = commonBrandMapper.selectList(queryWrapper);
            HashMap<Long, String> notZydmallSourceBrand = new HashMap<>();
            for (CommonBrand c : commonBrands) {
                if (!StringUtils.equalsIgnoreCase(c.getSource(), ESConstants.BrandSource.ZYDMALL.code)){
                    notZydmallSourceBrand.put(c.getBrandId(), c.getPicUrl());
                }
            }
            String domainNameEncode = Base64.getEncoder().encodeToString("huicai.zydonline.com".getBytes());
            for (SearchListVO.ProductList p : productsList) {
                StringBuilder brandImgUrl = new StringBuilder();
                brandImgUrl.append(commonOssConf.getOssUrl()).append("product/brand/").append(p.getBrandName() + "/").append(p.getBrandName() + "logo.png");
                p.setBrandImgUrl(brandImgUrl.toString());
                if (StringUtils.equals(p.getProductSrc(), ESConstants.ProductSource.ZYDMALL.code)){
                    //来源 【zydmall】
                    if (!StringUtils.equalsIgnoreCase("默认图", p.getProductPicName())){
                        if (p.getCataNameNotHighlight() != null){
                            String[] catas = p.getCataNameNotHighlight().split(" ");
                            StringBuilder imgUrl = new StringBuilder();
                            imgUrl.append(commonOssConf.getOssUrl()).append("product/image/").append(p.getBrandName()+"/"+catas[0]+"/"+catas[1]+"/"+catas[2]).
                                    append("/"+ p.getBrandName()+"_"+catas[0]+"_"+catas[1]+"_"+catas[2]+"_"+p.getPropNameFull()).
                                    append("/产品主图").append("/" + p.getProductPicName()+".jpg").append("?x-oss-process=image/resize,w_135,h_135");
                            imgUrl.append(textmarksize).append(domainNameEncode).append("&random="+System.currentTimeMillis());
                            p.setImgUrl(imgUrl.toString());
                        }
                    }
                }else {
                    //来源 【供应商申请】
                    if (StringUtils.isNotEmpty(p.getProductPicName())){
                        StringBuilder imgUrl = new StringBuilder();
                        imgUrl.append(p.getProductPicName().split("@")[0]).append("?x-oss-process=image/resize,w_135,h_135")
                               .append(textmarksize).append(domainNameEncode).append("&random="+System.currentTimeMillis());
                        p.setImgUrl(imgUrl.toString());
                    }
                    if (notZydmallSourceBrand.containsKey(p.getBrandId())){
                        //非zydmall的品牌来源
                        p.setBrandImgUrl(notZydmallSourceBrand.get(p.getBrandId()));
                    }
                }
            }
        }
        searchListVO.setProductList(productsList);
        long total = response.getHits().getTotalHits().value;
        searchListVO.setTotal(total);
        searchListVO.setCurrent(searchListRequest.getPageNum());
        searchListVO.setSize(searchListRequest.getPageSize());
        if (total <= 0){
            searchListVO.setPages(0);
        }else {
            searchListVO.setPages((((int)total)-1)/searchListRequest.getPageSize()+1);
        }
        return searchListVO;
    }

}
