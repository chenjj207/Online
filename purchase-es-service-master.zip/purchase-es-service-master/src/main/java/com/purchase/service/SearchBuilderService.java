package com.purchase.service;

import com.purchase.common.ProductSearchBuilder;
import com.purchase.config.ESBusinessExceptionDesc;
import com.purchase.controller.request.SearchCataRequest;
import com.purchase.controller.request.SearchListRequest;
import com.purchase.controller.request.SearchSelectRequest;
import com.zyd.framework.utils.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.*;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * @author jidonglin
 * @Description: 搜索构建器
 * @date 2023/4/20  11:05
 */
@Service
@Slf4j
public class SearchBuilderService {

    @Value("${elasticsearch.indexName}")
    private String index;

    @Autowired
    private RestHighLevelClient esClient;

    /**
     * RestHighLevelClient 调用elasticsearch 接口
     * @param sourceBuilder
     * @return
     */
    public SearchResponse search(SearchSourceBuilder sourceBuilder){
        SearchRequest searchRequest = new SearchRequest(index);
        searchRequest.source(sourceBuilder);
        SearchResponse response = null;
        try {
            response = esClient.search(searchRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            throw BusinessException.newInstance(ESBusinessExceptionDesc.ERROR_ES_SEARCH);
        }
        return response;
    }

    /**
     * 【搜索栏】 精准匹配sku或productType
     * @param key
     * @return
     */
    public SearchSourceBuilder barTermAllQuery(String key) {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.query(ProductSearchBuilder.keyTermAllQuery(key)).highlighter(ProductSearchBuilder.highlight()).timeout(new TimeValue(60, TimeUnit.SECONDS)).from(0).size(10);
        log.info("搜索栏-key精准查询sku或productType:" + sourceBuilder.toString());
        return sourceBuilder;
    }

    /**
     * 【搜索栏】 match匹配 productStructure、searchSet.Ik、searchSet.Ik.SmartSyno、searchSet.Ngram
     * @param key
     * @return
     */
    public SearchSourceBuilder barMatchAllQuery(String key){
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.query(ProductSearchBuilder.keyMatchAllQuery(key)).highlighter(ProductSearchBuilder.highlight()).timeout(new TimeValue(60, TimeUnit.SECONDS)).from(0).size(10);
        log.info("搜索栏-key匹配查询:" + sourceBuilder.toString());
        return sourceBuilder;
    }

    /**
     * 【搜索栏】 精准匹配sku或productType
     * @param key
     * @return
     */
    public SearchSourceBuilder barTermQuery(String key) {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.query(ProductSearchBuilder.keyTermQuery(key)).highlighter(ProductSearchBuilder.highlight()).timeout(new TimeValue(60, TimeUnit.SECONDS)).from(0).size(10);
        log.info("搜索栏-key精准查询sku或productType:" + sourceBuilder.toString());
        return sourceBuilder;
    }

    /**
     * 【搜索栏】 match匹配 productStructure、searchSet.Ik、searchSet.Ik.SmartSyno、searchSet.Ngram
     * @param key
     * @return
     */
    public SearchSourceBuilder barMatchQuery(String key){
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.query(ProductSearchBuilder.keyMatchQuery(key)).highlighter(ProductSearchBuilder.highlight()).timeout(new TimeValue(60, TimeUnit.SECONDS)).from(0).size(10);
        log.info("搜索栏-key匹配查询:" + sourceBuilder.toString());
        return sourceBuilder;
    }

    /**
     * 【选型接口】 term匹配，agg分组分类、品牌、系列、规格
     * @param searchSelectRequest
     * @return
     */
    public SearchSourceBuilder selectTermQuery(SearchSelectRequest searchSelectRequest){
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        //精准查询
        BoolQueryBuilder boolQueryBuilder = ProductSearchBuilder.keyTermQuery(searchSelectRequest.getKey());
        //增加店铺条件
        if (searchSelectRequest.getStoreId() != null){
            boolQueryBuilder.filter(ProductSearchBuilder.storeIdTermQuery(searchSelectRequest.getStoreId()));
        }
        //增加供应商条件
        if (StringUtils.isNotEmpty(searchSelectRequest.getSupplierId())){
            boolQueryBuilder.filter(ProductSearchBuilder.supplierIdTermQuery(searchSelectRequest.getSupplierId()));
        }
        //添加选型条件
        boolQueryBuilder.must(ProductSearchBuilder.structMatchQuery(searchSelectRequest.getCatas(), searchSelectRequest.getBrands(), searchSelectRequest.getProps(), searchSelectRequest.getSpecs()));
        //添加分组条件
        sourceBuilder.aggregation(ProductSearchBuilder.brandNameAgg()).aggregation(ProductSearchBuilder.cataNameAgg()).aggregation(ProductSearchBuilder.propNameAgg()).aggregation(ProductSearchBuilder.specValsArrAgg());
        //添加高亮字段，设置超时时间
        sourceBuilder.query(boolQueryBuilder).highlighter(ProductSearchBuilder.highlight()).timeout(new TimeValue(60, TimeUnit.SECONDS));
        log.info("选型term查询:" + sourceBuilder.toString());
        return sourceBuilder;
    }

    /**
     * 【选型接口】 match匹配，agg分组分类、品牌、系列、规格
     * @param searchSelectRequest
     * @return
     */
    public SearchSourceBuilder selectMatchQuery(SearchSelectRequest searchSelectRequest){
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        //匹配查询
        BoolQueryBuilder boolQueryBuilder = ProductSearchBuilder.keyMatchQuery(searchSelectRequest.getKey());
        //增加店铺条件
        if (searchSelectRequest.getStoreId() != null){
            boolQueryBuilder.filter(ProductSearchBuilder.storeIdTermQuery(searchSelectRequest.getStoreId()));
        }
        //增加供应商条件
        if (StringUtils.isNotEmpty(searchSelectRequest.getSupplierId())){
            boolQueryBuilder.filter(ProductSearchBuilder.supplierIdTermQuery(searchSelectRequest.getSupplierId()));
        }
        //添加选型条件
        boolQueryBuilder.must(ProductSearchBuilder.structMatchQuery(searchSelectRequest.getCatas(), searchSelectRequest.getBrands(), searchSelectRequest.getProps(), searchSelectRequest.getSpecs()));
        //添加分组条件
        sourceBuilder.aggregation(ProductSearchBuilder.brandNameAgg()).aggregation(ProductSearchBuilder.cataNameAgg()).aggregation(ProductSearchBuilder.propNameAgg()).aggregation(ProductSearchBuilder.specValsArrAgg());
        //添加高亮字段，设置超时时间
        sourceBuilder.query(boolQueryBuilder).highlighter(ProductSearchBuilder.highlight()).timeout(new TimeValue(60, TimeUnit.SECONDS));
        log.info("选型match查询:" + sourceBuilder.toString());
        return sourceBuilder;
    }

    /**
     * 【选型接口】 term匹配，agg分组分类、品牌、系列、规格
     *  分类是否展示系列
     * @param searchSelectRequest
     * @return
     */
    public SearchSourceBuilder selectTermQueryWithShowProp(SearchSelectRequest searchSelectRequest){
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        //精准查询
        BoolQueryBuilder boolQueryBuilder = ProductSearchBuilder.keyTermQuery(searchSelectRequest.getKey());
        //增加店铺条件
        if (searchSelectRequest.getStoreId() != null){
            boolQueryBuilder.filter(ProductSearchBuilder.storeIdTermQuery(searchSelectRequest.getStoreId()));
        }
        //增加供应商条件
        if (StringUtils.isNotEmpty(searchSelectRequest.getSupplierId())){
            boolQueryBuilder.filter(ProductSearchBuilder.supplierIdTermQuery(searchSelectRequest.getSupplierId()));
        }
        //添加选型条件
        boolQueryBuilder.must(ProductSearchBuilder.structMatchQuery(searchSelectRequest.getCatas(), searchSelectRequest.getBrands(), searchSelectRequest.getProps(), searchSelectRequest.getSpecs()));
        //分类展示系列 条件
        boolQueryBuilder.must(ProductSearchBuilder.isShowPropTerms());
        //添加分组条件
        sourceBuilder.aggregation(ProductSearchBuilder.brandNameAgg()).aggregation(ProductSearchBuilder.cataNameAgg()).aggregation(ProductSearchBuilder.propNameAgg()).aggregation(ProductSearchBuilder.specValsArrAgg());
        //添加高亮字段，设置超时时间
        sourceBuilder.query(boolQueryBuilder).highlighter(ProductSearchBuilder.highlight()).timeout(new TimeValue(60, TimeUnit.SECONDS));
        log.info("选型term查询-分类展示系列:" + sourceBuilder.toString());
        return sourceBuilder;
    }


    /**
     * 【选型接口】 match匹配，agg分组分类、品牌、系列、规格
     * 分类是否展示系列
     * @param searchSelectRequest
     * @return
     */
    public SearchSourceBuilder selectMatchQueryWithShowProp(SearchSelectRequest searchSelectRequest){
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        //匹配查询
        BoolQueryBuilder boolQueryBuilder = ProductSearchBuilder.keyMatchQuery(searchSelectRequest.getKey());
        //增加店铺条件
        if (searchSelectRequest.getStoreId() != null){
            boolQueryBuilder.filter(ProductSearchBuilder.storeIdTermQuery(searchSelectRequest.getStoreId()));
        }
        //增加供应商条件
        if (StringUtils.isNotEmpty(searchSelectRequest.getSupplierId())){
            boolQueryBuilder.filter(ProductSearchBuilder.supplierIdTermQuery(searchSelectRequest.getSupplierId()));
        }
        //添加选型条件
        boolQueryBuilder.must(ProductSearchBuilder.structMatchQuery(searchSelectRequest.getCatas(), searchSelectRequest.getBrands(), searchSelectRequest.getProps(), searchSelectRequest.getSpecs()));
        //分类展示系列 条件
        boolQueryBuilder.must(ProductSearchBuilder.isShowPropTerms());
        //添加分组条件
        sourceBuilder.aggregation(ProductSearchBuilder.brandNameAgg()).aggregation(ProductSearchBuilder.cataNameAgg()).aggregation(ProductSearchBuilder.propNameAgg()).aggregation(ProductSearchBuilder.specValsArrAgg());
        //添加高亮字段，设置超时时间
        sourceBuilder.query(boolQueryBuilder).highlighter(ProductSearchBuilder.highlight()).timeout(new TimeValue(60, TimeUnit.SECONDS));
        log.info("选型match查询-分类展示系列:" + sourceBuilder.toString());
        return sourceBuilder;
    }

    /**
     * 分类树获取
     * @return
     */
    public SearchSourceBuilder buildCataTree(SearchCataRequest searchCataRequest){
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder musts = ProductSearchBuilder.keyTermQuery(null);
        //增加供应商条件
        if (StringUtils.isNotEmpty(searchCataRequest.getSupplierId())){
            musts.filter(ProductSearchBuilder.supplierIdTermQuery(searchCataRequest.getSupplierId()));
        }
        sourceBuilder.aggregation(ProductSearchBuilder.cataNameAgg());
        sourceBuilder.query(musts).timeout(new TimeValue(60, TimeUnit.SECONDS));
        log.info("分类树分组查询:" + sourceBuilder.toString());
        return sourceBuilder;
    }

    /**
     * 列表精准查询
     * @param searchListRequest
     * @return
     */
    public SearchSourceBuilder listTermQuery(SearchListRequest searchListRequest){
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        //精准查询
        BoolQueryBuilder boolQueryBuilder = ProductSearchBuilder.keyTermQuery(searchListRequest.getKey());
        //增加店铺条件
        if (searchListRequest.getStoreId() != null){
            boolQueryBuilder.filter(ProductSearchBuilder.storeIdTermQuery(searchListRequest.getStoreId()));
        }
        //增加供应商条件
        if (StringUtils.isNotEmpty(searchListRequest.getSupplierId())){
            boolQueryBuilder.filter(ProductSearchBuilder.supplierIdTermQuery(searchListRequest.getSupplierId()));
        }
        //添加是否显示有货
        if (searchListRequest.isShowStock()){
            boolQueryBuilder.filter(ProductSearchBuilder.isShowStock());
        }
        //添加选型条件
        boolQueryBuilder.must(ProductSearchBuilder.structMatchQuery(searchListRequest.getCatas(), searchListRequest.getBrands(), searchListRequest.getProps(), searchListRequest.getSpecs()));
        //添加高亮字段，设置超时时间 和分页值
        int from = (searchListRequest.getPageNum()-1) * searchListRequest.getPageSize();
        SearchListRequest.SortObj sort = searchListRequest.getSortObj();
        if (sort == null || StringUtils.isEmpty(sort.getFiled())){
            sourceBuilder.sort(SortBuilders.scoreSort().order(SortOrder.DESC));
        }else{
            sourceBuilder.sort(sort.getFiled(), StringUtils.equalsIgnoreCase(SortOrder.DESC.toString(), sort.getOrder()) ? SortOrder.DESC : SortOrder.ASC);
        }
        sourceBuilder.query(boolQueryBuilder).highlighter(ProductSearchBuilder.highlight()).timeout(new TimeValue(60, TimeUnit.SECONDS)).from(from).size(searchListRequest.getPageSize());
        log.info("商品列表term查询:" + sourceBuilder.toString());
        return sourceBuilder;
    }

    /**
     * 列表match查询
     * @param searchListRequest
     * @return
     */
    public SearchSourceBuilder listMatchQuery(SearchListRequest searchListRequest){
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        //精准查询
        BoolQueryBuilder boolQueryBuilder = ProductSearchBuilder.keyMatchQuery(searchListRequest.getKey());
        //增加店铺条件
        if (searchListRequest.getStoreId() != null){
            boolQueryBuilder.filter(ProductSearchBuilder.storeIdTermQuery(searchListRequest.getStoreId()));
        }
        //增加供应商条件
        if (StringUtils.isNotEmpty(searchListRequest.getSupplierId())){
            boolQueryBuilder.filter(ProductSearchBuilder.supplierIdTermQuery(searchListRequest.getSupplierId()));
        }
        //添加是否显示有货
        if (searchListRequest.isShowStock()){
            boolQueryBuilder.filter(ProductSearchBuilder.isShowStock());
        }
        //添加选型条件
        boolQueryBuilder.must(ProductSearchBuilder.structMatchQuery(searchListRequest.getCatas(), searchListRequest.getBrands(), searchListRequest.getProps(), searchListRequest.getSpecs()));
        //添加高亮字段，设置超时时间 和分页值
        int from = (searchListRequest.getPageNum()-1) * searchListRequest.getPageSize();
        SearchListRequest.SortObj sort = searchListRequest.getSortObj();
        if (sort == null || StringUtils.isEmpty(sort.getFiled())){
            sourceBuilder.sort(SortBuilders.scoreSort().order(SortOrder.DESC));
        }else{
            sourceBuilder.sort(sort.getFiled(), StringUtils.equalsIgnoreCase(SortOrder.DESC.toString(), sort.getOrder()) ? SortOrder.DESC : SortOrder.ASC);
        }
        sourceBuilder.query(boolQueryBuilder).highlighter(ProductSearchBuilder.highlight()).timeout(new TimeValue(60, TimeUnit.SECONDS)).from(from).size(searchListRequest.getPageSize());
        log.info("商品列表term查询:" + sourceBuilder.toString());
        return sourceBuilder;
    }

}
