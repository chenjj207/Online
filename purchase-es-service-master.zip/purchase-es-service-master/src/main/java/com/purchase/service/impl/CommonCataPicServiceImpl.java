package com.purchase.service.impl;

import com.purchase.entity.CommonCataPic;
import com.purchase.mapper.CommonCataPicMapper;
import com.purchase.service.CommonCataPicService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 三级分类--产品关系表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-07-03
 */
@Service
public class CommonCataPicServiceImpl extends ServiceImpl<CommonCataPicMapper, CommonCataPic> implements CommonCataPicService {

}
