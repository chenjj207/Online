package com.purchase.service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
public class Spec {

    private String name;
    private List<SpecVal> specVals;

    @Data
    public static class SpecVal {
        private String value;
        private boolean selected;
    }

}
