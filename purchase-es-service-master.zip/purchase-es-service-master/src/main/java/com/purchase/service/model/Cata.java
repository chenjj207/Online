package com.purchase.service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;

@Data
public class Cata implements Comparable<Cata> {
    @Schema(description = "分类名")
    private String name;
    @Schema(description = "父分类名")
    private String parentName;
    @Schema(description = "等级")
    private int level;
    @Schema(description = "是否选中")
    private boolean selected = false;
    @Schema(description = "分类图片")
    private String cataPicUrl;
    @Schema(description = "分类子集")
    private List<Cata> child ;

    @Override
    public int compareTo(Cata o) {
        if (!equals(o)){
            return 1;
        }
        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Cata other = (Cata) obj;
        if (!StringUtils.equals(name, other.name)) {
            return false;
        }
        return true;
    }


}
