package com.purchase.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "oss")
@Data
public class OssConf {
    private String endpoint;
    private String accessKeySecret;
    private String accessKeyId;
    private String bucketName;
    private String ossUrl;
    private String corpOssPrex;
    private String smallPreix;
    private String tenantwatemartName;
    private String tmp;
    private String productUpload;
}
