package com.purchase.config;

import com.zyd.framework.utils.exception.BaseExceptionDesc;
import com.zyd.framework.utils.exception.BusinessExceptionDesc;

/**
 * @author jidonglin
 * @Description: 服务异常码
 * @date 2023/2/7  16:03
 */
public class ESBusinessExceptionDesc extends BusinessExceptionDesc {
    public static BaseExceptionDesc FILE_DOES_NOT_EXIST = new BaseExceptionDesc(-30001, "文件不存在");
    public static BaseExceptionDesc SEARCH_PARAMETERS_NOT_EXIST = new BaseExceptionDesc(-30002, "没有搜索参数");
    public static BaseExceptionDesc ERROR_ES_SEARCH = new BaseExceptionDesc(-30003, "es搜索异常");
    public static BaseExceptionDesc ERROR_SYNC_CORP = new BaseExceptionDesc(-30004, "数据同步到ES异常");
}
