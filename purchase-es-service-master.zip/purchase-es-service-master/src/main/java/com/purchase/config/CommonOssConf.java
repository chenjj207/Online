package com.purchase.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "commonoss")
@Data
public class CommonOssConf {
    private String endpoint;
    private String bucketName;
    private String ossUrl;
    private String accessKeySecret;
    private String accessKeyId;
}
