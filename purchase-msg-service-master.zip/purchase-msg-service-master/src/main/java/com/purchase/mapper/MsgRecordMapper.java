package com.purchase.mapper;

import com.purchase.entity.MsgRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 消息记录表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-08
 */
@Mapper
public interface MsgRecordMapper extends BaseMapper<MsgRecord> {

}
