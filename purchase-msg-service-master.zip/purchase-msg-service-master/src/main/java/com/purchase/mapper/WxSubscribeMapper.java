package com.purchase.mapper;

import com.purchase.entity.WxSubscribe;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-16
 */
@Mapper
public interface WxSubscribeMapper extends BaseMapper<WxSubscribe> {

}
