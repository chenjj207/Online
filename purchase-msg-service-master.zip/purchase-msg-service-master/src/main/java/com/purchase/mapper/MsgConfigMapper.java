package com.purchase.mapper;

import com.purchase.entity.MsgConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 租户消息配置表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-08
 */
@Mapper
public interface MsgConfigMapper extends BaseMapper<MsgConfig> {

}
