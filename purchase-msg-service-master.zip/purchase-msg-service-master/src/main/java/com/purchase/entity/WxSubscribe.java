package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 
* </p>
*
* @author jidonglin
* @since 2023-11-16
*/
@Data
@TableName("t_msg_wx_subscribe")
@Schema(title = "")
public class WxSubscribe extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "union_id")
    @TableField("union_id")
    private String unionId;

    @Schema(description = "open_id")
    @TableField("open_id")
    private String openId;

    @Schema(description = "订阅状态： 	subscribe：订阅 	unsubscribe：取消订阅")
    @TableField("event")
    private String event;




}
