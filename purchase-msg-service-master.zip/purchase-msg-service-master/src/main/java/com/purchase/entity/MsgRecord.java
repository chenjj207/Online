package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 消息记录表
* </p>
*
* @author jidonglin
* @since 2023-11-08
*/
@Data
@TableName("t_msg_record")
@Schema(title = "消息记录表")
public class MsgRecord extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "策略类型：1. send  2.receive")
    @TableField("strategy")
    private String strategy;

    @Schema(description = "消息来源：	1. businessMsg(业务消息) 	2. systemMsg(系统消息)")
    @TableField("msg_source")
    private String msgSource;

    @Schema(description = "消息内容")
    @TableField("content")
    private String content;

    @Schema(description = "业务（枚举）：如联营慧会员、惠采商城客户、 惠采供应商、订单")
    @TableField("business")
    private String business;

    @Schema(description = "场景（枚举）：会员登录、会员注册、创建订单、会员审核、留言、发布需求、发布资源等场景")
    @TableField("scene")
    private String scene;

    @Schema(description = "通知目标对象类型（枚举）：	member: 联营慧会员 	cust: 惠采商城客户 	supplier: 惠采供应商 	user: 运营用户")
    @TableField("target_type")
    private String targetType;

    @Schema(description = "通知方式（枚举）：	手机短信, 	公众号消息, 	企业微信, 	站内信")
    @TableField("notice_way")
    private String noticeWay;

    @Schema(description = "通知目标，具体人，id、工号等，多个用逗号隔开")
    @TableField("notice_target")
    private String noticeTarget;

    @Schema(description = "触发平台：如联营慧小程序、联营慧PC、惠采ODS、惠采商城")
    @TableField("trigger_plat")
    private String triggerPlat;

    @Schema(description = "触发类型")
    @TableField("trigger_type")
    private String triggerType;

    @Schema(description = "触发规则")
    @TableField("trigger_rule")
    private String triggerRule;

    @Schema(description = "相关联系方式，如邮箱，手机号具体值")
    @TableField("contact_way")
    private String contactWay;

    @Schema(description = "是否已执行	Y:已执行 	N:未执行")
    @TableField("is_exec")
    private String isExec;

    @Schema(description = "备注、原因")
    @TableField("remark")
    private String remark;




}
