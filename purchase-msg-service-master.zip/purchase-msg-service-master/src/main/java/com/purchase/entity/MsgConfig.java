package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 租户消息配置表
* </p>
*
* @author jidonglin
* @since 2023-11-08
*/
@Data
@TableName("t_msg_config")
@Schema(title = "租户消息配置表")
public class MsgConfig extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "策略类型：1. send(发送)  2.receive(接收)")
    @TableField("strategy")
    private String strategy;

    @Schema(description = "消息来源：	1. businessMsg(业务消息) 	2. systemMsg(系统消息)")
    @TableField("msg_source")
    private String msgSource;

    @Schema(description = "业务（枚举）：如联营慧会员、惠采商城客户、 惠采供应商、订单")
    @TableField("business")
    private String business;

    @Schema(description = "场景（枚举）：会员登录、会员注册、创建订单、会员审核、留言、发布需求、发布资源等场景")
    @TableField("scene")
    private String scene;

    @Schema(description = "通知目标对象类型（枚举）：	member: 联营慧会员	cust: 惠采商城客户	supplier: 惠采供应商	user: 运营用户	")
    @TableField("target_type")
    private String targetType;

    @Schema(description = "通知方式（枚举）：	手机短信, 	公众号消息, 	企业微信, 	站内信")
    @TableField("notice_way")
    private String noticeWay;

    @Schema(description = "触发平台：如联营慧小程序、联营慧PC、惠采ODS、惠采商城")
    @TableField("trigger_plat")
    private String triggerPlat;

    @Schema(description = "消息模板，模板id")
    @TableField("msg_template")
    private String msgTemplate;

    @Schema(description = "通知人：需要配置固定的通知人，英文逗号隔开")
    @TableField("notice_fixed_man")
    private String noticeFixedMan;

    @Schema(description = "短信签名配置")
    @TableField("sms_sign")
    private String smsSign;

    @Schema(description = "企业微信应用id")
    @TableField("qywx_agent_id")
    private String qywxAgentId;


    @Schema(description = "触发类型")
    @TableField("trigger_type")
    private String triggerType;

    @Schema(description = "触发规则")
    @TableField("trigger_rule")
    private String triggerRule;

    @Schema(description = "是否立刻执行	Y：是 	N：否")
    @TableField("is_exec_now")
    private String isExecNow;

    @Schema(description = "是否开启	Y：是 	N：否")
    @TableField("open")
    private String open;

    @Schema(description = "是否多人通知 Y：是 	N：否")
    @TableField("multiple_people")
    private String multiplePeople ;
}
