package com.purchase.common;

import lombok.Data;

/**
 * @author jidonglin
 * @Description: 业务枚举值
 */
@Data
public class MsgConstants {

    /**
     * 策略
     */
    public enum Strategy {
        SEND("send", "发送"),
        RECEIVE("receive", "接收"),
        ;

        public String code;
        public String message;
        Strategy(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 消息来源
     */
    public enum MsgResource {
        BUSINESS("business", "业务消息"),
        SYSTEM("system", "系统消息"),
        ;

        public String code;
        public String message;
        MsgResource(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }


    /**
     * 业务枚举
     */
    public enum Business {
        MEMBER("member", "会员"),
        REGIST("regist", "注册"),
        LOGIN("login", "登录"),
        SUPPLIER("supplier", "惠采供应商"),
        NOTIFY("notify", "消息通知"),
        ORDER("order", "订单"),
        ;

        public String code;
        public String message;
        Business(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 场景枚举
     */
    public enum Scene {
        MEMBER_LOGIN_CODE("memberLoginCode", "会员登录获取验证码"),
        MEMBER_REGIST_CODE("memberRegistCode", "会员注册验证码"),
        MEMBER_REGIST_APPLY("memberRegistApply", "提交注册会员资料"),
        MEMBER_APPLY_PASS("memberApplyPass", "会员资料审核通过"),
        MEMBER_APPLY_REJECT("memberApplyReject", "会员资料审核未通过"),
        CUST_LOGIN_CODE("custLoginCode", "客户登录验证码"),
        SUPPLIER_APPLY("supplierApply", "供应商入驻申请"),
        SUPPLIER_APPLY_PASS("supplierApplyPass", "供应商资料审核通过"),
        SUPPLIER_APPLY_REJECT("supplierApplyReject", "供应商资料审核未通过"),
        MEMBER_MESSAGE_LEAVE("memberMessageLeave", "对其他会员的留言"),
        MEMBER_REPLY_COO("memberReplyCoo", "响应需求-回复需求"),
        MEMBER_ADD_COO_RESOURCE("memberAddCooResource", "发布协作-资源消息"),
        MEMBER_ADD_COO_NEED("memberAddCooNeed", "发布协作-需求消息"),
        MEMBER_INVITE_CHAT("memberInviteChat", "会员邀约聊天"),
        MEMBER_ADD_INQUIRY_ORDER("memberAddInquiryOrder", "会员生成待报价订单"),
        USER_CONFIRM_QUOTE("userConfirmQuote", "运营端比价后确认报价"),
        SUPPLIER_SUBMIT_QUOTE("supplierSubmitQuote", "供应商提交报价"),
        ;

        public String code;
        public String message;
        Scene(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 通知目标对象类型
     */
    public enum TargetType {
        MEMBER("member", "联营慧会员"),
        CUST("cust", "惠采商城客户"),
        SUPPLIER("supplier", "惠采供应商"),
        USER("user", "运营用户"),
        ;

        public String code;
        public String message;
        TargetType(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 通知方式、渠道
     */
    public enum NoticeWay {
        SMS("sms", "短信"),
        WX_ACCOUNT_PLATFORM("wx_account_platform", "微信公众平台"),
        QY_WX("qy_wx", "企业微信"),
        PLAT_FORM("inner_platform", "站内信"),
        ;

        public String code;
        public String message;
        NoticeWay(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 触发平台
     */
    public enum TriggerPlat {
        LYH_MINI_PROGRAM("lyhMiniProgram", "联营慧小程序"),
        LYH_PC("lyhPc", "联营慧PC"),
        HUICAI_ODS("huicaiODS", "惠采ODS"),
        SUPPLIER_ODS("supplierODS", "供应商ODS"),
        HUICAI_MALL("huicaiMall", "惠采商城"),
        ;

        public String code;
        public String message;
        TriggerPlat(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 是否立即执行
     */
    public enum ExecNow {
        Y("Y", "已执行"),
        N("N", "未执行"),
        ;

        public String code;
        public String message;
        ExecNow(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 记录是否已执行
     */
    public enum RecordExec {
        Y("Y", "已执行"),
        N("N", "未执行"),
        ;

        public String code;
        public String message;
        RecordExec(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }
    /**
     * 是否开启配置
     */
    public enum ConfigOpen {
        Y("Y", "开启"),
        N("N", "关闭"),
        ;

        public String code;
        public String message;
        ConfigOpen(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }
    /**
     * 是否多人通知
     */
    public enum MultiplePeople {
        Y("Y", "是"),
        N("N", "否"),
        ;

        public String code;
        public String message;
        MultiplePeople(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }
}
