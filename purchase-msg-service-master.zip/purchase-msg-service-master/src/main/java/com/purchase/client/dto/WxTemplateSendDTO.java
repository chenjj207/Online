package com.purchase.client.dto;

import com.alibaba.fastjson.JSONObject;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description: 微信公众号模板消息
 * @date 2023/11/10  16:13
 */
@Data
public class WxTemplateSendDTO {
    @Schema(description = "接收者openid")
    private String touser;
    @Schema(description = "模板ID")
    private String template_id;
    @Schema(description = "模板跳转链接，非必填")
    private String url;
    @Schema(description = "跳小程序所需数据，不需跳小程序可不用传该数据")
    private Miniprogram miniprogram;
    @Schema(description = "模板数据 json")
    private JSONObject data;
    @Schema(description = "防重入id。 非必填")
    private String client_msg_id;

    @Data
    public static class Miniprogram{
        @Schema(description = "所需跳转到的小程序appid（该小程序appid必须与发模板消息的公众号是绑定关联关系)")
        private String appid;
        @Schema(description = "所需跳转到小程序的具体页面路径，支持带参数,（示例index?foo=bar），要求该小程序已发布，暂不支持小游戏")
        private String pagepath;
    }
}
