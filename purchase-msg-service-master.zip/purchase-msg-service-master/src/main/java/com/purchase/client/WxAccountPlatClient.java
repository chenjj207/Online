package com.purchase.client;

import com.alibaba.fastjson.JSONObject;
import com.dtflys.forest.annotation.*;
import com.purchase.client.dto.WxTemplateSendDTO;

/**
 * @author jidonglin
 * @Description: 微信公众号接口
 * @date 2023/11/10  15:02
 */
public interface WxAccountPlatClient {

    @Get("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential")
    JSONObject getToken(@Query("appid")String appid, @Query("secret")String secret);

    @Post("https://api.weixin.qq.com/cgi-bin/message/template/send")
    JSONObject templateSend(@Query("access_token")String accessToken, @JSONBody WxTemplateSendDTO wxTemplateSendDTO);

    @Get("https://api.weixin.qq.com/cgi-bin/user/info?lang=zh_CN")
    JSONObject userInfo(@Query("access_token")String accessToken, @Query("openid")String openid);

    /**
     * 一次拉取调用最多拉取10000个关注者的OpenID
     * @param accessToken
     * @return
     */
    @Get("https://api.weixin.qq.com/cgi-bin/user/get")
    JSONObject getAllUser(@Query("access_token")String accessToken);

    /**
     * 批量获取用户基本信息
     * 开发者可通过该接口来批量获取用户基本信息。最多支持一次拉取100条。
     * @param accessToken
     * @return
     */
    @Post("https://api.weixin.qq.com/cgi-bin/user/info/batchget")
    JSONObject batchGetByOpenId(@Query("access_token")String accessToken, @JSONBody JSONObject jsonObject);
}
