package com.purchase.client;

import com.alibaba.fastjson.JSONObject;
import com.dtflys.forest.annotation.*;

import java.io.InputStream;
import java.util.Map;

/**
 * @author jidonglin
 * @Description: 企业微信接口
 * @date 2023/3/20  11:13
 */
public interface QyWXClient {

    @Get("https://qyapi.weixin.qq.com/cgi-bin/gettoken")
    JSONObject getToken(@Query("corpid") String corpid, @Query("corpsecret") String corpsecret);

    @Post("https://qyapi.weixin.qq.com/cgi-bin/message/send")
    JSONObject sendNoticeMessage(@Query("access_token") String accessToken, @JSONBody Map<String, Object> info);

    //写法要按照顺序，先文件，再其他参数
    @Post(url = "https://qyapi.weixin.qq.com/cgi-bin/media/upload", contentType = "multipart/form-data")
    JSONObject mediaUpload(@DataFile(value = "file", fileName = "${1}") InputStream in, String filename, @Query("access_token") String accessToken, @Query("type") String type);
}
