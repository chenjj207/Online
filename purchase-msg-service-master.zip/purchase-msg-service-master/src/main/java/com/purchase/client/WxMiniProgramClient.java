package com.purchase.client;

import com.alibaba.fastjson.JSONObject;
import com.dtflys.forest.annotation.Get;
import com.dtflys.forest.annotation.Query;

/**
 * @author jidonglin
 * @Description: 微信小程序接口
 * @date 2023/11/10  15:02
 */
public interface WxMiniProgramClient {

    @Get("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential")
    JSONObject getToken(@Query("appid") String appid, @Query("secret") String secret);


}
