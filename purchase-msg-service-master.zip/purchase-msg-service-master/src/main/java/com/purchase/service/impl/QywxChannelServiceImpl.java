package com.purchase.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.purchase.client.QyWXClient;
import com.purchase.config.QyWXProperties;
import com.purchase.entity.MsgConfig;
import com.purchase.service.ChannelService;
import com.purchase.service.dto.TriggerMsgRequest;
import com.purchase.utils.TokenUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;
import java.util.StringJoiner;

/**
 * @author jidonglin
 * @Description: 企业微信渠道
 * @date 2023/11/13  15:06
 */
@Service("qy_wx")
@Slf4j
public class QywxChannelServiceImpl implements ChannelService {

    @Autowired
    TokenUtils tokenUtils;
    @Resource
    QyWXClient qyWXClient;
    @Resource
    QyWXProperties qyWXProperties;
    @Value("${msg.env:}")
    private String env;

    @Override
    public JSONObject send(TriggerMsgRequest triggerMsgRequest, MsgConfig msgConfig) {
        JSONObject param = triggerMsgRequest.getQywxParam();
        JSONObject resultJson = new JSONObject();
        String token = tokenUtils.getQyWXToken(msgConfig.getQywxAgentId());
            Map<String, Object> info = new HashMap<>();

            String noticeFixedMan = msgConfig.getNoticeFixedMan();
            if (StringUtils.isEmpty(noticeFixedMan) && !param.containsKey("noticeUser")){
                resultJson.put("success", false);
                resultJson.put("remark", "user not exist!");
                return resultJson;
            }
            //固定通知人
            StringJoiner joiner = new StringJoiner("|");
            if (StringUtils.isNotEmpty(noticeFixedMan)){
                String[] noticeFixedMans = noticeFixedMan.split(",");
                for (String man : noticeFixedMans) {
                    joiner.add(man);
                }
            }
            //动态通知人
            if (param.containsKey("noticeUser")){
                String noticeUser = param.getString("noticeUser");
                String[] noticeMans = noticeUser.split(",");
                for (String man : noticeMans) {
                    joiner.add(man);
                }
            }

            info.put("touser", joiner.toString());
            String msgtype = param.getString("msgtype");
            info.put("msgtype", msgtype);
            if (StringUtils.equals(msgConfig.getQywxAgentId(), qyWXProperties.getAgentid2())){
                info.put("agentid", qyWXProperties.getAgentid2());
            }else if (StringUtils.equals(msgConfig.getQywxAgentId(), qyWXProperties.getAgentid3())){
                info.put("agentid", qyWXProperties.getAgentid3());
            }else {
                info.put("agentid", qyWXProperties.getAgentid());
            }
            if (StringUtils.equals(msgtype, "textcard")){
                //文本卡片
                info.put("textcard", param.getJSONObject("textcard"));
            }else if (StringUtils.equals(msgtype, "text")){
                String envName = "";
                if (StringUtils.isNotBlank(env)) {
                    if (env.equals("test")) {
                        envName = "【测试环境】";
                    } else if (env.equals("adv")) {
                        envName = "【预上线环境】";
                    }
                }
                JSONObject text = param.getJSONObject("text");
                String content = text.getString("content");
                content = envName + content;
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("content", content);
                //纯文本
                info.put("text", jsonObject);
            }else if (StringUtils.equals(msgtype, "file")){
                try {
                    //文件
                    URL url = new URL(param.getString("fileUrl"));
                    // 打开连接
                    URLConnection connection = url.openConnection();
                    // 获取输入流
                    InputStream inputStream = connection.getInputStream();
                    String fileName = param.getString("fileName");
                    JSONObject jsonObject = qyWXClient.mediaUpload(inputStream, fileName, token, "file");
                    String mediaId = jsonObject.getString("media_id");
                    Map<String, String> contentMap = new HashMap<>();
                    contentMap.put("media_id", mediaId);
                    info.put("file", contentMap);
                }catch (Exception e){
                    log.error("上传临时素材异常" + e.getMessage());
                }
            }else if (StringUtils.equals(msgtype, "template_card")){
                //模板卡片
                String envName = "";
                if (StringUtils.isNotBlank(env)) {
                    if (env.equals("test")) {
                        envName = "【测试环境】";
                    } else if (env.equals("adv")) {
                        envName = "【预上线环境】";
                    }
                }
                JSONObject templateCard = param.getJSONObject("template_card");
                if (templateCard != null) {
                    JSONObject mainTitle = templateCard.getJSONObject("main_title");
                    if (mainTitle != null) {
                        mainTitle.put("title", mainTitle.get("title") + envName);
                        templateCard.put("main_title", mainTitle);
                    }
                }
                log.error("templateCardtemplateCard：" + templateCard);
                info.put("template_card", templateCard);
            }
            JSONObject jsonObject = qyWXClient.sendNoticeMessage(token, info);
            if(jsonObject.containsKey("errcode")){
                if(jsonObject.get("errcode").toString().equals("0")){
                    resultJson.put(SUCCESS, true);
                    log.info("发送企业微信消息成功");
                }else{
                    resultJson.put(SUCCESS, false);
                    if(jsonObject.containsKey("errmsg")){
                        resultJson.put(REMARK, "发送企业微信异常：" + jsonObject.get("errcode").toString() + " --- " + jsonObject.get("errmsg").toString());
                        log.error("发送企业微信异常：" + jsonObject.get("errcode").toString() + " --- " + jsonObject.get("errmsg").toString());
                    }else{
                        resultJson.put(REMARK, "发送企业微信异常：" + jsonObject.toJSONString());
                        log.error("发送企业微信异常：" + jsonObject.toJSONString());
                    }
                }
            }else{
                resultJson.put(SUCCESS, false);
            resultJson.put(REMARK, "调用企业微信接口--异常");
            log.error("调用企业微信接口--异常");
        }
        return resultJson;
    }
}
