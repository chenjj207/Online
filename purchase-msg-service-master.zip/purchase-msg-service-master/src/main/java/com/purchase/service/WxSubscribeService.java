package com.purchase.service;

import com.purchase.entity.WxSubscribe;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-16
 */
public interface WxSubscribeService extends IService<WxSubscribe> {
    public Boolean initSubscribe();

    public Boolean queryWxSubscribeByUnionid(String unionid);
}
