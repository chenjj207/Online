package com.purchase.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-16
 */
public interface WxCallBackService{
    public String eventPush(HttpServletRequest req, HttpServletResponse resp);
}
