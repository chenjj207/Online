package com.purchase.service.impl;

import com.purchase.entity.MsgConfig;
import com.purchase.mapper.MsgConfigMapper;
import com.purchase.service.MsgConfigService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 租户消息配置表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-08
 */
@Service
public class MsgConfigServiceImpl extends ServiceImpl<MsgConfigMapper, MsgConfig> implements MsgConfigService {

}
