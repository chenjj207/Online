package com.purchase.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.purchase.common.MsgConstants;
import com.purchase.config.AliSmsProperties;
import com.purchase.entity.MsgConfig;
import com.purchase.service.ChannelService;
import com.purchase.service.dto.TriggerMsgRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 阿里短信渠道
 * @date 2023/11/8  15:06
 */
@Service("sms")
@Slf4j
public class AliSmsChannelServiceImpl implements ChannelService {

    @Resource
    AliSmsProperties aliSmsProperties;

    @Override
    public JSONObject send(TriggerMsgRequest triggerMsgRequest, MsgConfig msgConfig) {
        JSONObject param = triggerMsgRequest.getSmsParam();
        JSONObject jsonObject = new JSONObject();
        try {
            // 设置超时时间-可自行调整
            System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
            System.setProperty("sun.net.client.defaultReadTimeout", "10000");
            // 初始化ascClient需要的几个参数
            final String product = "Dysmsapi";// 短信API产品名称（短信产品名固定，无需修改）
            final String domain = "dysmsapi.aliyuncs.com";// 短信API产品域名（接口地址固定，无需修改）
            // 替换成你的AK
            // 初始化ascClient,暂时不支持多region（请勿修改）
            IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", aliSmsProperties.getAccesskeyId(), aliSmsProperties.getAccessKeySecret());
            DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
            IAcsClient acsClient = new DefaultAcsClient(profile);
            // 组装请求对象
            SendSmsRequest request = new SendSmsRequest();
            // 使用post提交
            request.setMethod(MethodType.POST);
            // 必填:待发送手机号。支持以逗号分隔的形式进行批量调用，批量上限为1000个手机号码,批量调用相对于单条调用及时性稍有延迟,验证码类型的短信推荐使用单条调用的方式；发送国际/港澳台消息时，接收号码格式为国际区号+号码，如“85200000000”
            if (StringUtils.equals(msgConfig.getMultiplePeople(), MsgConstants.MultiplePeople.Y.code)){
                List<String> phones = (List<String>) param.get("phones");
                String phoneNum = String.join(",", phones);
                request.setPhoneNumbers(phoneNum);
            }else {
                request.setPhoneNumbers(param.getString("phone"));
            }
            // 必填:短信签名-可在短信控制台中找到
            request.setSignName(msgConfig.getSmsSign());
            // 必填:短信模板-可在短信控制台中找到，发送国际/港澳台消息时，请使用国际/港澳台短信模版
            request.setTemplateCode(msgConfig.getMsgTemplate());
            // 可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${smsCode}"时,此处的值为
            // 友情提示:如果JSON中需要带换行符,请参照标准的JSON协议对换行符的要求,比如短信内容中包含\r\n的情况在JSON中需要表示成\\r\\n,否则会导致JSON在服务端解析失败
            request.setTemplateParam(param.toString());
            // 可选-上行短信扩展码(扩展码字段控制在7位或以下，无特殊需求用户请忽略此字段)
            // request.setSmsUpExtendCode("90997");
            // 可选:outId为提供给业务方扩展字段,最终在短信回执消息中将此值带回给调用者
            request.setOutId("yourOutId");
            // 请求失败这里会抛ClientException异常
            SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);
            if ("OK".equals(sendSmsResponse.getCode())){
                jsonObject.put(SUCCESS, true);
                jsonObject.put(REMARK, sendSmsResponse.getMessage());
                return jsonObject;
            }else {
                jsonObject.put(SUCCESS, false);
                jsonObject.put(REMARK, sendSmsResponse.getMessage());
                return jsonObject;
            }
        } catch (Exception e) {
            log.info("短信发送失败");
            log.error(e.getMessage(), e);
            jsonObject.put(SUCCESS, false);
            jsonObject.put(REMARK, e.getMessage());
            return jsonObject;
        }
    }

}
