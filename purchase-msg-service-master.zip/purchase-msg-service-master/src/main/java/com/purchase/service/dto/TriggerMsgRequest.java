package com.purchase.service.dto;

import com.alibaba.fastjson.JSONObject;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


/**
 * @author jidonglin
 * @Description:
 * @date 2023/11/8  10:02
 */
@Data
@Schema(description = "消息请求")
public class TriggerMsgRequest {
    @Schema(description = "业务")
    private String business;
    @Schema(description = "场景")
    private String scene;
    @Schema(description = "短信参数")
    private JSONObject smsParam;
    @Schema(description = "微信公众号参数")
    private JSONObject wxpfParam;
    @Schema(description = "企业微信参数")
    private JSONObject qywxParam;

}
