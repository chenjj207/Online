package com.purchase.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.purchase.client.WxAccountPlatClient;
import com.purchase.config.PurchaseOrderExceptionDesc;
import com.purchase.entity.WxSubscribe;
import com.purchase.mapper.WxSubscribeMapper;
import com.purchase.service.WxSubscribeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.utils.TokenUtils;
import com.zyd.framework.utils.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-16
 */
@Service
@Slf4j
public class WxSubscribeServiceImpl extends ServiceImpl<WxSubscribeMapper, WxSubscribe> implements WxSubscribeService {

    @Resource
    WxAccountPlatClient wxAccountPlatClient;
    @Resource
    TokenUtils tokenUtils;


    @Override
    public Boolean initSubscribe() {
        String token = tokenUtils.getWXAccountPlatToken();
        JSONObject jsonObject = wxAccountPlatClient.getAllUser(token);
        if(jsonObject.containsKey("errcode")){
            log.info("error get all user : " + jsonObject.get("errcode"));
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_GET_SUBSCRIBE_USER);
        }
        JSONArray jsonArray = jsonObject.getJSONObject("data").getJSONArray("openid");
        if (jsonArray != null && jsonArray.size() > 0){
            LocalDateTime now = LocalDateTime.now();
            List<WxSubscribe> wxSubscribes = new ArrayList<>();
            HashMap<String, WxSubscribe> hashMap = new HashMap<>();
            for (int i = 0; i < jsonArray.size(); i++) {
                WxSubscribe wxSubscribe = new WxSubscribe();
                String openId = (String) jsonArray.get(i);
                wxSubscribe.setOpenId(openId);
                wxSubscribe.setEvent("subscribe");
                wxSubscribe.setCreatedAt(now);
                wxSubscribes.add(wxSubscribe);

                hashMap.put(openId, wxSubscribe);
            }
            boolean result = this.saveBatch(wxSubscribes);
            if (result){
                JSONObject jsonObject1 = new JSONObject();
                JSONArray jsonArray1 = new JSONArray();
                for (WxSubscribe w : wxSubscribes) {
                    JSONObject jsonObject2 = new JSONObject();
                    jsonObject2.put("openid", w.getOpenId());
                    jsonObject2.put("lang", "zh_CN");
                    jsonArray1.add(jsonObject2);
                }
                jsonObject1.put("user_list", jsonArray1);
                JSONObject jsonObjectResult = wxAccountPlatClient.batchGetByOpenId(token, jsonObject1);
                JSONArray jsonArrayResult = jsonObjectResult.getJSONArray("user_info_list");
                LocalDateTime now1 = LocalDateTime.now();
                List<WxSubscribe> wxSubscribes1 = new ArrayList<>();
                for (int i = 0; i < jsonArrayResult.size(); i++) {
                    JSONObject o = (JSONObject) jsonArrayResult.get(i);
                    if (o.containsKey("subscribe")){
                        int subscribe = o.getIntValue("subscribe");
                        if (subscribe == 1){
                            WxSubscribe wxSubscribe = hashMap.get(o.getString("openid"));
                            wxSubscribe.setUnionId(o.getString("unionid"));
                            wxSubscribe.setUpdatedAt(now1);
                            wxSubscribes1.add(wxSubscribe);
                        }
                    }
                }
                boolean batchById = this.updateBatchById(wxSubscribes1);
                return batchById;
            }
            return false;
        }
        return false;
    }

    @Override
    public Boolean queryWxSubscribeByUnionid(String unionid) {
        QueryWrapper<WxSubscribe> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("union_id", unionid);
        WxSubscribe wxSubscribe = this.getOne(queryWrapper);
        if (wxSubscribe != null){
            if (StringUtils.equals(wxSubscribe.getEvent(), "subscribe")){
                return true;
            }
        }
        return false;
    }
}
