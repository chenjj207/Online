package com.purchase.service;

import com.purchase.entity.MsgConfig;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 租户消息配置表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-08
 */
public interface MsgConfigService extends IService<MsgConfig> {

}
