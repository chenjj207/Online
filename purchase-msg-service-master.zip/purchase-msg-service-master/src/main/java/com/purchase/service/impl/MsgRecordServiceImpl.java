package com.purchase.service.impl;

import com.purchase.entity.MsgRecord;
import com.purchase.mapper.MsgRecordMapper;
import com.purchase.service.MsgRecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 消息记录表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-08
 */
@Service
public class MsgRecordServiceImpl extends ServiceImpl<MsgRecordMapper, MsgRecord> implements MsgRecordService {

}
