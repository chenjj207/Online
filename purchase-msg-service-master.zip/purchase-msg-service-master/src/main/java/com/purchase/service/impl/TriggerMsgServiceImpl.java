package com.purchase.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.purchase.common.MsgConstants;
import com.purchase.config.PurchaseOrderExceptionDesc;
import com.purchase.entity.MsgConfig;
import com.purchase.entity.MsgRecord;
import com.purchase.mapper.MsgConfigMapper;
import com.purchase.service.ChannelService;
import com.purchase.service.MsgRecordService;
import com.purchase.service.TriggerMsgService;
import com.purchase.service.dto.TriggerMsgRequest;
import com.zyd.framework.utils.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/11/8  15:05
 */
@Service
@Slf4j
public class TriggerMsgServiceImpl implements TriggerMsgService {

    @Resource
    MsgConfigMapper msgConfigMapper;

    @Autowired
    MsgRecordService msgRecordService;

    @Override
    public Boolean triggerMsg(TriggerMsgRequest request) {
        QueryWrapper<MsgConfig> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("msg_source", "business")
                .eq("business", request.getBusiness())
                .eq("scene", request.getScene())
                .orderByAsc("id"); // id正序，排在前面的优先发送
        List<MsgConfig> msgConfigs = msgConfigMapper.selectList(queryWrapper);
        if (CollectionUtils.isEmpty(msgConfigs)){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_CONFIG);
        }
        //同个目标类型的多条策略
        HashMap<String, List<MsgConfig>> hashMap = new HashMap<>();
        for (MsgConfig msgConfig : msgConfigs) {
            if (hashMap.containsKey(msgConfig.getTargetType())){
                List<MsgConfig> msgConfigs1 = hashMap.get(msgConfig.getTargetType());
                msgConfigs1.add(msgConfig);
                hashMap.put(msgConfig.getTargetType(), msgConfigs1);
            }else {
                List<MsgConfig> msgConfigs1 = new ArrayList<>();
                msgConfigs1.add(msgConfig);
                hashMap.put(msgConfig.getTargetType(), msgConfigs1);
            }
        }

        for (Map.Entry<String, List<MsgConfig>> entry : hashMap.entrySet()) {
            List<MsgConfig> msgConfigList = entry.getValue();
            String key = entry.getKey();
            for (MsgConfig m : msgConfigList) {
                if (!StringUtils.equals(m.getOpen(), MsgConstants.ConfigOpen.Y.code)){
                    //配置未开启
                    log.info(m.getBusiness() + "：" + m.getScene() + "：" + m.getTargetType()  + "：" + m.getNoticeWay() + " 配置未开启");
                    continue;
                }
                MsgRecord msgRecord = new MsgRecord();
                BeanUtil.copyProperties(m, msgRecord, "id", "created_at", "created_by");
                msgRecord.setNoticeTarget(m.getTargetType());
                //是否下一个渠道
                boolean nextWay = false;
                if (StringUtils.equals(m.getIsExecNow(), MsgConstants.ExecNow.Y.code)){
                    //具体发送逻辑，发送成功则break，不进行下一个渠道的发送,根据通知方法获取渠道
                    ChannelService channelService = SpringUtil.getBean(m.getNoticeWay(), ChannelService.class);
                    //调用渠道的发送方法
                    JSONObject result = channelService.send(request, m);
                    if (result.getBoolean(ChannelService.SUCCESS)){
                        msgRecord.setIsExec(MsgConstants.RecordExec.Y.code);
                        //此条消息发送成功， 则进行下一个发送目标的发送逻辑
                        nextWay = true;
                    }else {
                        msgRecord.setIsExec(MsgConstants.RecordExec.N.code);
                    }
                    msgRecord.setRemark(result.getString(ChannelService.REMARK));
                }else {
                    msgRecord.setIsExec(MsgConstants.RecordExec.N.code);
                    nextWay = true;
                }
                msgRecord.setCreatedAt(LocalDateTime.now());
                msgRecord.setCreatedBy("system");
                msgRecordService.save(msgRecord);
                if (nextWay){
                    break;
                }
            }
        }
        return true;
    }
}
