package com.purchase.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.purchase.client.WxAccountPlatClient;
import com.purchase.client.dto.WxTemplateSendDTO;
import com.purchase.config.WxMiniProgramProperties;
import com.purchase.entity.MsgConfig;
import com.purchase.entity.WxSubscribe;
import com.purchase.service.ChannelService;
import com.purchase.service.WxSubscribeService;
import com.purchase.service.dto.TriggerMsgRequest;
import com.purchase.utils.TokenUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author jidonglin
 * @Description: 微信公众号渠道
 * @date 2023/11/8  15:06
 */
@Service("wx_account_platform")
@Slf4j
public class WeChatChannelServiceImpl implements ChannelService {

    @Autowired
    TokenUtils tokenUtils;
    @Resource
    WxAccountPlatClient wxAccountPlatClient;
    @Resource
    WxMiniProgramProperties wxMiniProgramProperties;
    @Autowired
    WxSubscribeService wxSubscribeService;

    @Override
    public JSONObject send(TriggerMsgRequest triggerMsgRequest, MsgConfig msgConfig) {
        JSONObject param = triggerMsgRequest.getWxpfParam();
        String unionId = param.getString("unionid");
        QueryWrapper<WxSubscribe> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("union_id", unionId);
        WxSubscribe wxSubscribe = wxSubscribeService.getOne(queryWrapper);
        JSONObject resultJson = new JSONObject();
        if (wxSubscribe == null){
            resultJson.put(SUCCESS, false);
            resultJson.put("remark", "not exist wxSubscribe");
            return resultJson;
        }
        String token = tokenUtils.getWXAccountPlatToken();

        WxTemplateSendDTO wxTemplateSendDTO = new WxTemplateSendDTO();
        wxTemplateSendDTO.setTouser(wxSubscribe.getOpenId());
        wxTemplateSendDTO.setTemplate_id(msgConfig.getMsgTemplate());
        if (StringUtils.isNotEmpty(param.getString("appid")) && StringUtils.isNotEmpty(param.getString("pagepath"))){
            WxTemplateSendDTO.Miniprogram  miniprogram = new WxTemplateSendDTO.Miniprogram();
            miniprogram.setAppid(param.getString("appid"));
            miniprogram.setPagepath(param.getString("pagepath"));
            wxTemplateSendDTO.setMiniprogram(miniprogram);
        }
        wxTemplateSendDTO.setData(param.getJSONObject("data"));

        JSONObject jsonObject = wxAccountPlatClient.templateSend(token, wxTemplateSendDTO);
        if (jsonObject.getIntValue("errcode") != 0){
            resultJson.put("success", false);
            resultJson.put("remark", "error send wx_account_plat template msg: " + jsonObject.getString("errmsg"));
            log.error("error send wx_account_plat template msg: " + jsonObject.getString("errmsg"));
            return resultJson;
        }
        resultJson.put(SUCCESS, true);
        return resultJson;
    }
}
