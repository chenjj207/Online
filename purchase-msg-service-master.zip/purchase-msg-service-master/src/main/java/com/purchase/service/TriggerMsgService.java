package com.purchase.service;

import com.purchase.service.dto.TriggerMsgRequest;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/11/8  15:05
 */
public interface TriggerMsgService {
    Boolean triggerMsg(TriggerMsgRequest request);
}
