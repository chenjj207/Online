package com.purchase.service.dto;

import com.alibaba.fastjson.JSONObject;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


/**
 * @author jidonglin
 * @Description:
 * @date 2025/01/20  10:02
 */
@Data
@Schema(description = "消息请求")
public class QywxRequest {
    @Schema(description = "业务")
    private String url;
    @Schema(description = "业务")
    private String type = "file";
}
