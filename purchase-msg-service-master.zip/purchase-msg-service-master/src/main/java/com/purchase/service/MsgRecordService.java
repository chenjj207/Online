package com.purchase.service;

import com.purchase.entity.MsgRecord;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 消息记录表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-08
 */
public interface MsgRecordService extends IService<MsgRecord> {

}
