package com.purchase.service;

import com.alibaba.fastjson.JSONObject;
import com.purchase.entity.MsgConfig;
import com.purchase.service.dto.TriggerMsgRequest;

/**
 * @author jidonglin
 * @Description: 渠道服务
 * @date 2023/11/8  14:54
 */
public interface ChannelService {

    public static String SUCCESS = "success";
    public static String REMARK = "remark";

    public JSONObject send(TriggerMsgRequest triggerMsgRequest, MsgConfig msgConfig);
}
