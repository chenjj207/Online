package com.purchase.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.purchase.client.WxAccountPlatClient;
import com.purchase.entity.WxSubscribe;
import com.purchase.service.WxCallBackService;
import com.purchase.service.WxSubscribeService;
import com.purchase.utils.TokenUtils;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-16
 */
@Service
@Slf4j
public class WxCallBackServiceImpl implements WxCallBackService{

    @Autowired
    WxSubscribeService wxSubscribeService;
    @Resource
    WxAccountPlatClient wxAccountPlatClient;
    @Autowired
    TokenUtils tokenUtils;

    @Override
    public String eventPush(HttpServletRequest req, HttpServletResponse resp) {
        try {
            req.setCharacterEncoding("UTF-8"); // 接收请求时的编码。
            resp.setCharacterEncoding("UTF-8"); // 响应给浏览器的编码。
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        SAXReader saxReader = new SAXReader();
        Map<String, String> map = new HashMap<>();
        Document read = null;
        try {
            read = saxReader.read(req.getInputStream());
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //得到根节点
        Element rootElement = read.getRootElement();
        //获得子节点
        List<Element> elements = rootElement.elements();
        for (Element e: elements) {
            map.put(e.getName(), e.getStringValue());
        }
        if (map.containsKey("MsgType") && map.get("MsgType").equals("event")){
            //判断用户是否为关注
            if (map.containsKey("Event")) {
                if (map.get("Event").equals("subscribe") || map.get("Event").equals("unsubscribe")){
                    String openId = map.get("FromUserName");
                    QueryWrapper<WxSubscribe> queryWrapper = new QueryWrapper<>();
                    queryWrapper.eq("open_id", openId);
                    WxSubscribe wxSubscribe = wxSubscribeService.getOne(queryWrapper);
                    if (wxSubscribe == null){
                        WxSubscribe wxSubscribe1 = new WxSubscribe();
                        wxSubscribe1.setOpenId(openId);
                        JSONObject jsonObject = wxAccountPlatClient.userInfo(tokenUtils.getWXAccountPlatToken(), openId);
                        log.info(jsonObject.toJSONString());
                        String unionId = jsonObject.getString("unionid");
                        wxSubscribe1.setUnionId(unionId);
                        wxSubscribe1.setEvent(map.get("Event"));
                        LocalDateTime now =  LocalDateTime.now();
                        wxSubscribe1.setCreatedAt(now);
                        wxSubscribe1.setUpdatedAt(now);
                        wxSubscribeService.save(wxSubscribe1);
                    }else {
                        JSONObject jsonObject = wxAccountPlatClient.userInfo(tokenUtils.getWXAccountPlatToken(), openId);
                        log.info(jsonObject.toJSONString());
                        String unionId = jsonObject.getString("unionid");
                        wxSubscribe.setUnionId(unionId);
                        wxSubscribe.setEvent(map.get("Event"));
                        wxSubscribe.setUpdatedAt(LocalDateTime.now());
                        wxSubscribeService.updateById(wxSubscribe);
                    }
                }
            }
        }
        return "success";
    }
}
