package com.purchase.utils;

import com.alibaba.fastjson.JSONObject;
import com.purchase.client.QyWXClient;
import com.purchase.client.WxAccountPlatClient;
import com.purchase.client.WxMiniProgramClient;
import com.purchase.config.QyWXProperties;
import com.purchase.config.WxAccountPlatProperties;
import com.purchase.config.WxMiniProgramProperties;
import com.zyd.framework.utils.redis.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/3/20  15:58
 */
@Component
@Slf4j
public class TokenUtils {

    @Resource
    private WxAccountPlatClient wxAccountPlatClient;
    @Resource
    private WxMiniProgramClient wxMiniProgramClient;
    @Resource
    private QyWXClient qyWXClient;

    @Resource
    WxAccountPlatProperties wxAccountPlatProperties;
    @Resource
    WxMiniProgramProperties wxMiniProgramProperties;
    @Resource
    QyWXProperties qyWXProperties;

    /**
     * 微信公众号获取token
     * @return
     */
    public String getWXAccountPlatToken() {
        String accessToken = RedisUtil.StringOps.get("wx_plat_token");
        if (StringUtils.isEmpty(accessToken)){
            JSONObject jsonObject = wxAccountPlatClient.getToken(wxAccountPlatProperties.getAppid(), wxAccountPlatProperties.getSecret());
            log.info("wx_plat_token: " + jsonObject.toJSONString());
            String newAccessToken = jsonObject.getString("access_token");
            //设置为7000秒
            RedisUtil.StringOps.setEx("wx_plat_token", newAccessToken, 1000, TimeUnit.SECONDS);
            accessToken = newAccessToken;
        }
        return accessToken;
    }

    /**
     * 微信小程序获取token
     * @return
     */
    public String getWXMiniProgramToken() {
        String accessToken = RedisUtil.StringOps.get("wx_mini_program_token");
        if (StringUtils.isEmpty(accessToken)){
            JSONObject jsonObject = wxMiniProgramClient.getToken(wxMiniProgramProperties.getAppid(), wxMiniProgramProperties.getSecret());
            log.info(jsonObject.toJSONString());
            String newAccessToken = jsonObject.getString("access_token");
            //设置为7000秒
            RedisUtil.StringOps.setEx("wx_mini_program_token", newAccessToken, 1000, TimeUnit.SECONDS);
            accessToken = newAccessToken;
        }
        return accessToken;
    }

    /**
     * 企业微信获取token
     * @return
     */
    public String getQyWXToken(String agentid) {
        String accessToken = RedisUtil.StringOps.get("qywx_token");
        if (StringUtils.isEmpty(accessToken)){
            if (StringUtils.equals(agentid, qyWXProperties.getAgentid2())){
                //如果传递的是第二个配置的应用id，就是用第二个应用的密钥
                JSONObject jsonObject = qyWXClient.getToken(qyWXProperties.getCorpid(), qyWXProperties.getCorpSecret2());
                String newAccessToken = jsonObject.getString("access_token");
                //设置为7000秒
                RedisUtil.StringOps.setEx(qyWXProperties.getAgentid2() + "_qywx_token", newAccessToken, 60, TimeUnit.SECONDS);
                accessToken = newAccessToken;
            }else if (StringUtils.equals(agentid, qyWXProperties.getAgentid3())){
                //如果传递的是第三个配置的应用id，就是用第二个应用的密钥
                JSONObject jsonObject = qyWXClient.getToken(qyWXProperties.getCorpid(), qyWXProperties.getCorpSecret3());
                String newAccessToken = jsonObject.getString("access_token");
                //设置为7000秒
                RedisUtil.StringOps.setEx(qyWXProperties.getAgentid3() + "_qywx_token", newAccessToken, 60, TimeUnit.SECONDS);
                accessToken = newAccessToken;
            }else{
                //其他默认 业务协同系统应用
                JSONObject jsonObject = qyWXClient.getToken(qyWXProperties.getCorpid(), qyWXProperties.getCorpSecret());
                String newAccessToken = jsonObject.getString("access_token");
                //设置为7000秒
                RedisUtil.StringOps.setEx(qyWXProperties.getAgentid() + "_qywx_token", newAccessToken, 60, TimeUnit.SECONDS);
                accessToken = newAccessToken;
            }
        }
        return accessToken;
    }

}
