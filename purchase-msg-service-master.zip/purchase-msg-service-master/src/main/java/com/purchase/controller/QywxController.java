package com.purchase.controller;


import com.alibaba.fastjson.JSONObject;
import com.purchase.client.QyWXClient;
import com.purchase.config.QyWXProperties;
import com.purchase.service.dto.TriggerMsgRequest;
import com.purchase.utils.TokenUtils;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;


/**
 * @author jidonglin
 * @Description: 触发接口
 * @date 2025/01/20  10:00
 */
@RestController
@RequestMapping(value = "/qywx")
@Schema(description = "QywxController")
public class QywxController {

    @Autowired
    TokenUtils tokenUtils;
    @Resource
    QyWXClient qyWXClient;
    @Resource
    QyWXProperties qyWXProperties;

    @PostMapping(value = "/file/send")
    @Operation(summary = "企业微信发送文件")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean fileSend(@RequestBody TriggerMsgRequest request){
        try {
            String token = tokenUtils.getQyWXToken("1000041");
            //文件
            URL url = new URL("https://zyd-online-tenant-prod.oss-cn-shenzhen.aliyuncs.com/purchase/brandAuthApply/o1nhx5kifzAaXFtTS92VufooKC5Y/2024/%E4%BC%97%E4%B8%9A%E8%BE%BE%E5%93%81%E7%89%8C%E6%8E%88%E6%9D%83%E5%90%88%E4%BD%9C%E8%A1%A5%E5%85%85%E5%8D%8F%E8%AE%AE%EF%BC%88%E6%96%BD%E8%80%90%E5%BE%B7%EF%BC%89.pdf");

            // 打开连接
            URLConnection connection = url.openConnection();
            // 获取输入流
            InputStream inputStream = connection.getInputStream();
            String fileName = "测试.pdf";
            JSONObject jsonObject = qyWXClient.mediaUpload(inputStream, fileName, token, "file");
            System.out.println(jsonObject.toJSONString());
        }catch (Exception e){
            e.printStackTrace();
        }
        return true;
    }


}
