package com.purchase.controller;

import com.purchase.service.WxSubscribeService;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-16
 */
@RestController
@RequestMapping("/wx-subscribe")
public class WxSubscribeController {

    @Autowired
    WxSubscribeService wxSubscribeService;

    @PostMapping("/init")
    @Auth(value = AuthType.NONE)
    public Boolean initSubscribe(){
        return wxSubscribeService.initSubscribe();
    }

    @PostMapping("/query/subscribe")
    @Auth(value = AuthType.NONE)
    public Boolean queryWxSubscribeByUnionid(@RequestParam("unionid") String unionid){
        return wxSubscribeService.queryWxSubscribeByUnionid(unionid);
    }
}
