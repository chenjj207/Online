package com.purchase.controller;


import com.purchase.service.TriggerMsgService;
import com.purchase.service.dto.TriggerMsgRequest;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


/**
 * @author jidonglin
 * @Description: 触发接口
 * @date 2023/11/8  10:00
 */
@RestController
@RequestMapping(value = "/trigger")
@Schema(description = "TriggerController")
public class TriggerMsgController {

    @Autowired
    TriggerMsgService triggerMsgService;

    @PostMapping(value = "/business/msg")
    @Operation(summary = "业务消息发送")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean triggerMsg(@RequestBody TriggerMsgRequest request){
        return triggerMsgService.triggerMsg(request);
    }


}
