package com.purchase.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 租户消息配置表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-11-08
 */
@RestController
@RequestMapping("/t-msg-config")
public class MsgConfigController {


}
