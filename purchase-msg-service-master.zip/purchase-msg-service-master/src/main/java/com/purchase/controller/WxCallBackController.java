package com.purchase.controller;

import com.purchase.service.WxCallBackService;
import com.purchase.utils.CheckUtil;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;

/**
 * @author jidonglin
 * @Description: 众业达在线公众号回调
 * @date 2023/11/16  14:07
 */
@RestController
@RequestMapping("/wx")
@Slf4j
public class WxCallBackController {

    @Autowired
    WxCallBackService wxCallBackService;

    /**
     * GET 请求此接口校验 微信公众号后台 服务器配置 相关参数
     * 注意配置的域名必须以http://或https://开头，分别支持80端口和443端口
     * @param signature
     * @param timestamp
     * @param nonce
     * @param echostr
     * @param response
     */
    @GetMapping("/callback")
    @ResponseBody
    @Auth(value = AuthType.NONE)
    public void handlewxCheckSignature(@RequestParam(name = "signature", required = false) String signature,
                                         @RequestParam(name = "timestamp", required = false) String timestamp,
                                         @RequestParam(name = "nonce", required = false) String nonce,
                                         @RequestParam(name = "echostr", required = false) String echostr,
                                         HttpServletResponse response){
        log.info("\n-----------验证微信订阅号信息开始------------");
        try {
            log.info("\nsignature = "+signature);
            log.info("\ntimestamp = "+timestamp);
            log.info("\nnonce = "+nonce);
            log.info("\nechostr = "+echostr);
            if (CheckUtil.checkSignature(signature, timestamp, nonce)) {
                log.info("\n-----------验证微信订阅号信息结束------------");
                BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
                out.write(echostr.getBytes());
                out.flush();
                out.close();
            }else{
                log.info("\n-----------不是微信服务器发送过来的请求------------");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * POST 请求此接口校验
     * @param req
     * @param resp
     * @return
     */
    @PostMapping("/callback")
    @ResponseBody
    @Auth(value = AuthType.NONE)
    public String eventPush(HttpServletRequest req, HttpServletResponse resp){
         return wxCallBackService.eventPush(req, resp);
    }
}
