package com.purchase.config;

import com.zyd.framework.utils.exception.BaseExceptionDesc;
import com.zyd.framework.utils.exception.BusinessExceptionDesc;

/**
 * @author jidonglin
 * @Description: 服务异常码
 */
public class PurchaseOrderExceptionDesc extends BusinessExceptionDesc {
    public static BaseExceptionDesc ERROR_SERVICE = new BaseExceptionDesc(-60000, "服务异常");
    public static BaseExceptionDesc NOT_EXIST_CONFIG = new BaseExceptionDesc(-60001, "不存在此配置");
    public static BaseExceptionDesc ERROR_GET_SUBSCRIBE_USER = new BaseExceptionDesc(-60002, "获取公众号用户失败");
}
