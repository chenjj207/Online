package com.purchase.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/***
 * 企业微信配置参数
 * @author jidonglin
 *
 */
@Data
@Component
@RefreshScope
@ConfigurationProperties(prefix= QyWXProperties.PREFIX)
public class QyWXProperties {
    public final static String PREFIX = "zyd.qywx";
    /**
     * 企业ID
     */
    String corpid;
    /**
     * [众业达业务协同系统]应用的凭证密钥
     */
    String corpSecret;
    /**
     * [众业达业务协同系统]应用id
     */
    String agentid;

    /**
     * [公共应用]应用的凭证密钥
     */
    String corpSecret2;
    /**
     * [公共应用]应用id
     */
    String agentid2;

    /**
     * [广州测试用]应用的凭证密钥
     */
    String corpSecret3;
    /**
     * [广州测试用]应用id
     */
    String agentid3;
}
