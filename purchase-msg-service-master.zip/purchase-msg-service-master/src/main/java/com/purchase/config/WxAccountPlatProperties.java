package com.purchase.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/***
 * 微信公众号配置参数
 * @author jidonglin
 *
 */
@Data
@Component
@RefreshScope
@ConfigurationProperties(prefix= WxAccountPlatProperties.PREFIX)
public class WxAccountPlatProperties {
    public final static String PREFIX = "zyd.wx.plat";
    
    /***
     * 微信公众号appid
     */
    String appid;
    /***
     * 微信公众号 密钥
     */
    String secret;
}
