package com.purchase.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/***
 * 微信公众号配置参数
 * @author jidonglin
 *
 */
@Data
@Component
@RefreshScope
@ConfigurationProperties(prefix= WxMiniProgramProperties.PREFIX)
public class WxMiniProgramProperties {
    public final static String PREFIX = "zyd.wx.miniprogram";
    
    /***
     * 微信公众号appid
     */
    String appid;
    /***
     * 微信公众号 密钥
     */
    String secret;
}
