package com.purchase.client;

import com.purchase.client.dto.TriggerMsgRequest;
import com.zyd.framework.utils.response.CommonResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


/**
 * 搜索对外服务接口
 */
@FeignClient(value = "purchase-msg")
public interface MsgClient {

    /**
     * 业务消息发送
     * @return
     */
    @PostMapping("/trigger/business/msg")
    public CommonResponse triggerMsg(@RequestBody TriggerMsgRequest request);
}
