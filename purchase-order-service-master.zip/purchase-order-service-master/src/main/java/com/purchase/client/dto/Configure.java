package com.purchase.client.dto;

import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/10/9  14:02
 */
@Data
public class Configure {
    //图片中文字的最小高度，单位像素（此参数目前已经废弃）
    private int min_size;
    //是否输出文字框的概率
    private boolean output_prob;
    //是否输出文字框角点
    private boolean output_keypoints;
    //是否跳过文字检测步骤直接进行文字识别
    private boolean skip_detection;
    //是否关闭自动旋转
    private boolean dir_assure;
    //当skip_detection为true时，该字段才生效，做单行手写识别。
    private String language;
}
