package com.purchase.client;

import com.alibaba.fastjson.JSONObject;
import com.dtflys.forest.annotation.Header;
import com.dtflys.forest.annotation.JSONBody;
import com.dtflys.forest.annotation.Post;
import com.purchase.client.dto.AliOcrDTO;

/**
 * @author jidonglin
 * @Description: 阿里云ocr识别接口
 * @date 2023/10/9  13:36
 */
public interface AliOcrClient {
    @Post("https://tysbgpu.market.alicloudapi.com/api/predict/ocr_general")
    JSONObject ocr(@Header("Authorization")String appCode, @JSONBody AliOcrDTO aliOcrDTO);
}
