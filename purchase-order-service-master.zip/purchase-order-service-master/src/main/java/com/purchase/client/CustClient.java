package com.purchase.client;

import com.purchase.client.dto.QywxMsgDTO;
import com.zyd.framework.utils.response.CommonResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/13  15:00
 */
@FeignClient(value = "purchase-cust")
public interface CustClient {
    @PostMapping(value = "/customer/qywx/msg/send")
    public CommonResponse sendQyMsgWithFile(@RequestBody QywxMsgDTO qywxMsgDTO);
}
