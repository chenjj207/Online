package com.purchase.client;

import com.alibaba.fastjson.JSONObject;
import com.purchase.client.dto.ProductAuditDTO;
import com.purchase.client.dto.PurchaseProductApply;
import com.purchase.client.dto.TriggerMsgRequest;
import com.zyd.framework.utils.response.CommonResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashMap;
import java.util.List;

@FeignClient(value = "purchase-product")
public interface ProductClient {

    /**
     * 单商品发布
     * @return
     */
    @PostMapping("/purchaseProductApply/quote/product/publish")
    public HashMap<String, String> multiQuote(@RequestBody List<PurchaseProductApply> applyVOS);

    /**
     * 商品审核
     * @param productAuditDtos
     * @return
     */
    @PostMapping("/purchaseProductApply/audit/quote/product")
    public HashMap<String, Long> productQuoteAudit(@RequestBody List<ProductAuditDTO> productAuditDtos);
}
