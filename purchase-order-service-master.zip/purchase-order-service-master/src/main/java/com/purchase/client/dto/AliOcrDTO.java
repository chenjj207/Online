package com.purchase.client.dto;

import lombok.Data;

/**
 * @author jidonglin
 * @Description: 阿里云ocr实体
 * @date 2023/10/9  13:41
 */
@Data
public class AliOcrDTO {
    private String image;
    private Configure configure;
}