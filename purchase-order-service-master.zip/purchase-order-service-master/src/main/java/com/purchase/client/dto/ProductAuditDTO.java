package com.purchase.client.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class ProductAuditDTO {

    @Schema(description="审核id")
    private String id;

    @Schema(description="审核后产品的审核状态")
    private Integer auditStatus;

    @Schema(description="审核附加信息（未通过原因或Erp编码）")
    private String data;

    /**
     * 可编辑属性
     */
    private CompileProperties properties;


    @Data
    public static class CompileProperties {

        /**
         * 一级分类名称
         */

        @Schema(description= "一级分类名称")
        private String firstLevelCataName;

        /**
         * 二级分类名称
         */
        @Schema(description= "二级分类名称")
        private String secondLevelCataName;

        /**
         * 三级分类名称
         */
        @Schema(description= "三级分类名称")
        private String threeLevelCataName;

        /**
         * 商品品牌名称
         */
        @Schema(description="商品品牌名称")
        private String brandName;

        /**
         * 商品系列名称
         */
        @Schema(description="商品系列名称")
        private String propName;

        /**
         * 规格json数据
         */
        @Schema(description="规格json数据")
        private String specData;
    }




}
