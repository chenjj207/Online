package com.purchase.client.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @Author zhangcheng
 * @Description 商品发布审核
 * @Date 2022-08-16
 **/
@Data
public class PurchaseProductApply  {

    public static final String ID = "id";
    public static final String BATCH_NO = "batchNo";
    public static final String APPLY_NO = "applyNo";
    public static final String FIRST_LEVEL_CATA_NAME = "firstLevelCataName";
    public static final String SECOND_LEVEL_CATA_NAME = "secondLevelCataName";
    public static final String THREE_LEVEL_CATA_NAME = "threeLevelCataName";
    public static final String BRAND_NAME = "brandName";
    public static final String PROP_NAME = "propName";
    public static final String MATERIAL_NAME = "materialName";
    public static final String PRODUCT_TYPE = "productType";
    public static final String SKU_CODE = "skuCode";
    public static final String PRODUCT_CODE = "productCode";
    public static final String PRODUCT_ERP_CODE = "productErpCode";
    public static final String SUPPLY_PRICE = "supplyPrice";
    public static final String PURCHASE_PRICE = "purchasePrice";
    public static final String PRICE = "price";
    public static final String SUGGEST_PRICE = "suggestPrice";
    public static final String STOCK = "stock";
    public static final String DELIVERY_DATE = "deliveryDate";
    public static final String UNIT = "unit";
    public static final String WEIGHT = "weight";
    public static final String IS_ONSALE = "isOnsale";
    public static final String IS_SUPPLY = "isSupply";
    public static final String SUPPLIER_ID = "supplierId";
    public static final String AUDIT_TYPE = "auditType";
    public static final String AUDIT_STATUS = "auditStatus";
    public static final String AUDIT_REMARK = "auditRemark";
    public static final String PUBLIC_PRODUCT_ID = "publicProductId";
    public static final String STORE_CATA_ID = "storeCataId";

    @Schema(description = "批次编号")
    private String batchNo;
    @Schema(description = "申请编号")
    private Long applyNo;
    @Schema(description="一级分类名称")
    private String firstLevelCataName;
    @Schema(description="二级分类名称")
    private String secondLevelCataName;
    @Schema(description="三级分类名称")
    private String threeLevelCataName;
    @Schema(description="商品品牌名称")
    private String brandName;
    @Schema(description="商品系列名称")
    private String propName;
    @Schema(description="商品物料名称")
    private String materialName;
    @Schema(description="规格json数据")
    private String specData;
    @Schema(description="产品型号")
    private String productType;
    @Schema(description="订货号")
    private String skuCode;
    @Schema(description="商品编号")
    private String productCode;
    @Schema(description="erp商品编号")
    private String productErpCode;
    @Schema(description="供货价")
    private BigDecimal supplyPrice;
    @Schema(description="慧采价")
    private BigDecimal purchasePrice;
    @Schema(description="面价（元）")
    private BigDecimal price;
    @Schema(description="建议销售价")
    private BigDecimal suggestPrice;
    @Schema(description="库存")
    private Integer stock;
    @Schema(description="货期")
    private String deliveryDate;
    @Schema(description="计量单位")
    private String unit;
    @Schema(description="重量")
    private String weight;
    @Schema(description="商品图片（多个用@分隔）")
    private String productPicName;
    @Schema(description="视频详情")
    private String productVedioName;
    @Schema(description="是否上下架（Y=上架，N=下架）")
    private String isOnsale;
    @Schema(description="商品详情")
    private String productContent;
    @Schema(description="编辑字段")
    private String editColumns;
    @Schema(description="审核类型（1=新增，2=修改）")
    private Integer auditType;
    @Schema(description="审核状态（0=待审核，1=通过，2=不通过）")
    private Integer auditStatus;
    @Schema(description="审核备注")
    private String auditRemark;
    @Schema(description = "审核时间", hidden = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime;
    @Schema(description="公海产品id")
    private Long publicProductId;
    @Schema(description="供应商id")
    private String supplierId;
    @Schema(description="是否是供应链（Y：是，N：否）")
    private String isSupply;
    @Schema(description="样本（多个用@分割）")
    private String sample;

    @Schema(description="店铺分类id")
    private Integer storeCataId;
    @Schema(description="用户id")
    private String userId;
}

