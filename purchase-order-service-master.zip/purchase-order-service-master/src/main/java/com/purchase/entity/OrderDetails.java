package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 订单详情表
* </p>
*
* @author jidonglin
* @since 2023-09-12
*/
@Data
@TableName("t_od_purchase_order_details")
@Schema(title = "订单详情表")
public class OrderDetails extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Schema(description = "询价单id")
    @TableField("inquiry_order_id")
    private Integer inquiryOrderId;

    @Schema(description = "订单id")
    @TableField("order_id")
    private Integer orderId;

    @Schema(description = "客户订单编号")
    @TableField("order_code")
    private String orderCode;

    @Schema(description = "公海产品id")
    @TableField("public_product_id")
    private Long publicProductId;

    @Schema(description = "我的编码")
    @TableField("product_code")
    private String productCode;

    @Schema(description = "品牌名")
    @TableField("brand_name")
    private String brandName;

    @Schema(description = "型号")
    @TableField("product_type")
    private String productType;

    @Schema(description = "订货号")
    @TableField("sku_code")
    private String skuCode;

    @Schema(description = "产品名称")
    @TableField("product_name")
    private String productName;

    @Schema(description = "系列名")
    @TableField("prop_name")
    private String propName;

    @Schema(description = "货期")
    @TableField("delivery_time")
    private String deliveryTime;

    @Schema(description = "期望货期")
    @TableField("expect_delivery_date")
    private String expectDeliveryDate;

    @Schema(description = "单种商品的数量")
    @TableField("number")
    private Integer number;

    @Schema(description = "面价")
    @TableField("amount")
    private BigDecimal amount;

    @Schema(description = "慧采价/报价")
    @TableField("purchase_amount")
    private BigDecimal purchaseAmount;

    @Schema(description = "总价/小计")
    @TableField("total_amount")
    private BigDecimal totalAmount;

    @Schema(description = "供应商id")
    @TableField("supplier_id")
    private String supplierId;

    @Schema(description = "单位")
    @TableField("unit")
    private String unit;

    @Schema(description = "库存")
    @TableField("stock")
    private Integer stock;

    @Schema(description = "是否转采购 1=是 0=否")
    @TableField("procured")
    private Integer procured;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;

    @Schema(description = "图片备注，url地址")
    @TableField("pic_remark")
    private String picRemark;

    @Schema(description = "供应商名称")
    @TableField(exist = false)
    private String supplierName;

}
