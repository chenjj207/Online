package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
* <p>
* 采购订单表
* </p>
*
* @author jidonglin
* @since 2023-12-19
*/
@Data
@TableName("t_od_purchase_procure_orders")
@Schema(title = "采购订单表")
public class ProcureOrders extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "采购单号")
    @TableField("procure_order_code")
    private String procureOrderCode;

    @Schema(description = "销售订单id")
    @TableField("order_id")
    private Integer orderId;

    @Schema(description = "销售订单编号")
    @TableField("order_code")
    private String orderCode;

    @Schema(description = "总金额")
    @TableField("total_amount")
    private BigDecimal totalAmount;

    @Schema(description = "订单文件路径")
    @TableField("order_url")
    private String orderUrl;

    @Schema(description = "商品总数量")
    @TableField("total_num")
    private Integer totalNum;

    @Schema(description = "订单状态（1=待确认 2=已确认 3=已作废）")
    @TableField("order_status")
    private Integer orderStatus;

    @Schema(description = "支付状态（0=未支付/未入账，1=已支付/已入账）")
    @TableField("pay_status")
    private Integer payStatus;

    @Schema(description = "支付方式（1=公对公转账，2=银联，3=微信，4=支付宝，5=在线支付）")
    @TableField("pay_type")
    private Integer payType;

    @Schema(description = "所属供应商id")
    @TableField("supplier_id")
    private String supplierId;

    @Schema(description = "收货地址")
    @TableField("receiving_addr")
    private String receivingAddr;

    @Schema(description = "收件人")
    @TableField("receiving_man")
    private String receivingMan;

    @Schema(description = "收件人联系方式")
    @TableField("receiving_phone")
    private String receivingPhone;

    @Schema(description = "收件人邮编")
    @TableField("receiving_zipcode")
    private String receivingZipcode;

    @Schema(description = "确认时间")
    @TableField("confirm_time")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    private LocalDateTime confirmTime;

    @Schema(description = "作废时间")
    @TableField("cancel_time")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    private LocalDateTime cancelTime;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;

    @Schema(description = "作废原因")
    @TableField("reason")
    private String reason;

    @Schema(description = "供应商名称")
    @TableField(exist = false)
    private String supplierName;

    @Schema(description = "供应商账号")
    @TableField(exist = false)
    private String supplierLinkphone;
}
