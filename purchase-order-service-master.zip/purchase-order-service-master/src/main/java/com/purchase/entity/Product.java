package com.purchase.entity;

import com.alibaba.excel.annotation.ExcelProperty;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 惠采商品列表
* </p>
*
* @author jidonglin
* @since 2023-08-31
*/
@Data
@TableName("t_pd_purchase_product")
@Schema(title = "惠采商品列表")
public class Product extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @ExcelProperty({"* 品牌"})
    @Schema(description = "品牌名称")
    @TableField("brand_name")
    private String brandName;

    @ExcelProperty({"* 型号"})
    @Schema(description = "产品型号")
    @TableField("product_type")
    private String productType;

    @ExcelProperty({"物料号"})
    @Schema(description = "产品物料号")
    @TableField("product_sku")
    private String productSku;

    @ExcelProperty({"产品名称"})
    @Schema(description = "产品名称")
    @TableField("product_name")
    private String productName;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;




}
