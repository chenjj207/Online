package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 
* </p>
*
* @author jidonglin
* @since 2024-05-28
*/
@Data
@TableName("t_pd_purchase_delivery_date")
@Schema(title = "")
public class DeliveryDate extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "货期")
    @TableField("delivery_date")
    private String deliveryDate;




}
