package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
* <p>
* 供应商惠采商品
* </p>
*
* @author jidonglin
* @since 2023-08-31
*/
@Data
@TableName("t_pd_purchase_supplier_quote")
@Schema(title = "供应商惠采商品")
public class SupplierQuote extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "询价id")
    @TableField("inquiry_order_id")
    private Integer inquiryOrderId;

    @Schema(description = "询价详情id")
    @TableField("inquiry_order_details_id")
    private Integer inquiryOrderDetailsId;

    @Schema(description = "供应商id")
    @TableField("supplier_id")
    private String supplierId;

    @Schema(description = "状态：0: 未报价(仅保存) 1:已报价")
    @TableField("state")
    private Integer state;

    @Schema(description = "询价订单状态,只要一个产品已报价，此产品对应的所有orderState都是1：0: 未报价 1:已报价")
    @TableField("inquiry_order_state")
    private Integer inquiryOrderState;

    @Schema(description = "建议品牌")
    @TableField("suggested_brand_name")
    private String suggestedBrandName;

    @Schema(description = "建议型号")
    @TableField("suggested_product_type")
    private String suggestedProductType;

    @Schema(description = "建议物料号")
    @TableField("suggested_product_sku")
    private String suggestedProductSku;

    @Schema(description = "建议物料名称")
    @TableField("suggested_product_name")
    private String suggestedProductName;

    @Schema(description = "供应商商品申请表 id，报价后更新")
    @TableField("product_apply_id")
    private String productApplyId;

    @Schema(description = "库存")
    @TableField(value ="stock", updateStrategy = FieldStrategy.IGNORED)
    private Integer stock;

    @Schema(description = "面价")
    @TableField("price")
    private BigDecimal price;

    @Schema(description = "供货价")
    @TableField(value = "supply_price", updateStrategy = FieldStrategy.IGNORED)
    private BigDecimal supplyPrice;

    @Schema(description = "报价")
    @TableField(value = "quote_price", updateStrategy = FieldStrategy.IGNORED)
    private BigDecimal quotePrice;

    @Schema(description = "货期类型： 现货  期货")
    @TableField("delivery_type")
    private String deliveryType;

    @Schema(description = "货期")
    @TableField("delivery_date")
    private String deliveryDate;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "报价时间")
    @TableField("quote_time")
    private LocalDateTime quoteTime;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "报价有效期")
    @TableField("expire_time")
    private LocalDateTime expireTime;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;

    @Schema(description = "供应商名称")
    @TableField(exist = false)
    private String supplierName;

    @Schema(description = "是否确认")
    @TableField(exist = false)
    private boolean isConfirmed;
}
