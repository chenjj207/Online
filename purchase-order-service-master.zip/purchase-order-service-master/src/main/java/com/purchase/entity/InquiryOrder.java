package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
* <p>
* 
* </p>
*
* @author jidonglin
* @since 2023-09-19
*/
@Data
@TableName("t_od_purchase_inquiry_order")
@Schema(title = "")
public class InquiryOrder extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Schema(description = "询价单号")
    @TableField("inquiry_code")
    private String inquiryCode;

    @Schema(description = "询价单标题")
    @TableField("title")
    private String title;

    @Schema(description = "报价总金额")
    @TableField("all_quote_price")
    private BigDecimal allQuotePrice;

    @Schema(description = "总项数，即产品条数")
    @TableField("items")
    private Integer items;

    @Schema(description = "已报价项数，即运营端提交报价对应的询价详情数")
    @TableField("quote_items")
    private Integer quoteItems;

    @Schema(description = "客户id")
    @TableField("cust_id")
    private Integer custId;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "询价有效期")
    @TableField("inquiry_expire_time")
    private LocalDateTime inquiryExpireTime;

    @Schema(description = "期望货期")
    @TableField("expect_delivery_date")
    private String expectDeliveryDate;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "报价有效期")
    @TableField("quote_expire_time")
    private LocalDateTime quoteExpireTime;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "报价时间，运营端比价提交报价时间")
    @TableField("quote_time")
    private LocalDateTime quoteTime;

    @Schema(description = "交付货期")
    @TableField("delivery_date")
    private String deliveryDate;

    @Schema(description = "询价状态：0：报价中 1：已报价 2：已采纳 3：已作废")
    @TableField("state")
    private Integer state;

    @Schema(description = "已报价是否管理员确认状态：0：未确认 1：已确认 ")
    @TableField("confirm_state")
    private Integer confirmState;

    @Schema(description = "标记删除：1：标记删除 其他：未标记删除")
    @TableField("deleted")
    private Integer deleted;

    @Schema(description = "作废原因 ")
    @TableField("reason")
    private String reason;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;

    @Schema(description = "客户名称")
    @TableField(exist = false)
    private String custName;

    @Schema(description = "账号、手机号")
    @TableField(exist = false)
    private String linkphone;

    @Schema(description = "是否显示 前往报价按钮")
    @TableField(exist = false)
    private boolean isShow = false;
}
