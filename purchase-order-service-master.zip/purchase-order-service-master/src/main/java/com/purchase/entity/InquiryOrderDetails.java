package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
* <p>
* 惠采商品询价单
* </p>
*
* @author jidonglin
* @since 2023-08-31
*/
@Data
@TableName("t_od_purchase_inquiry_order_details")
@Schema(title = "惠采商品询价单")
public class InquiryOrderDetails extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Schema(description = "询价单id")
    @TableField("inquiry_order_id")
    private Integer inquiryOrderId;

    @Schema(description = "我的编码")
    @TableField("product_code")
    private String productCode;

    @Schema(description = "品牌名称")
    @TableField("brand_name")
    private String brandName;

    @Schema(description = "产品型号")
    @TableField("product_type")
    private String productType;

    @Schema(description = "产品物料号")
    @TableField("product_sku")
    private String productSku;

    @Schema(description = "产品名称")
    @TableField("product_name")
    private String productName;

    @Schema(description = "建议品牌")
    @TableField("suggested_brand_name")
    private String suggestedBrandName;

    @Schema(description = "建议型号")
    @TableField("suggested_product_type")
    private String suggestedProductType;

    @Schema(description = "建议物料号")
    @TableField("suggested_product_sku")
    private String suggestedProductSku;

    @Schema(description = "建议物料名称")
    @TableField("suggested_product_name")
    private String suggestedProductName;

    @Schema(description = "t_pd_purchase_product 惠采商品的id 临时表id")
    @TableField("product_id")
    private Long productId;

    @Schema(description = "t_pd_common_product 公海表的productId")
    @TableField("public_product_id")
    private Long publicProductId;

    @Schema(description = "询价单号")
    @TableField("inquiry_code")
    private String inquiryCode;

    @Schema(description = "询价状态：0：报价中 1：已报价 2：已采纳 3：已作废")
    @TableField("state")
    private Integer state;

    @Schema(description = "已报价是否管理员确认状态：0：未确认 1：已确认 ")
    @TableField("confirm_state")
    private Integer confirmState;

    @Schema(description = "供应商id，保存和提交都会更新")
    @TableField("supplier_id")
    private String supplierId;

    @Schema(description = "库存，保存和提交都会更新库存")
    @TableField("stock")
    private Integer stock;

    @Schema(description = "供应商报价id，运营端确认报价的供应商，confirm_state为1是不能为空")
    @TableField("supplier_quote_id")
    private Integer supplierQuoteId;

    @Schema(description = "单位")
    @TableField("unit")
    private String unit;

    @Schema(description = "需求数量")
    @TableField("num")
    private Integer num;

    @Schema(description = "面价")
    @TableField("price")
    private BigDecimal price;

    @Schema(description = "报价/慧采价")
    @TableField("quote_price")
    private BigDecimal quotePrice;

    @Schema(description = "供货价")
    @TableField("supply_price")
    private BigDecimal supplyPrice;

    @Schema(description = "小计")
    @TableField("subtotal")
    private BigDecimal subtotal;

    @Schema(description = "货期时效")
    @TableField("delivery_date")
    private String deliveryDate;

    @Schema(description = "期望货期")
    @TableField("expect_delivery_date")
    private String expectDeliveryDate;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @TableField("inquiry_expire_time")
    @Schema(description = "有效时间")
    private LocalDateTime inquiryExpireTime;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @TableField("quote_time")
    @Schema(description = "报价时间")
    private LocalDateTime quoteTime;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @TableField("quote_expire_time")
    @Schema(description = "报价有效期")
    private LocalDateTime quoteExpireTime;

    @Schema(description = "客户id")
    @TableField("cust_id")
    private Integer custId;

    @Schema(description = "文字备注")
    @TableField("remark")
    private String remark;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @TableField("confirm_time")
    @Schema(description = "确认时间")
    private LocalDateTime confirmTime;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @TableField("accept_time")
    @Schema(description = "采纳时间")
    private LocalDateTime acceptTime;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @TableField("voided_time")
    @Schema(description = "作废时间")
    private LocalDateTime voidedTime;

    @Schema(description = "图片备注，url地址")
    @TableField("pic_remark")
    private String picRemark;

    @Schema(description = "供应商名称")
    @TableField(exist = false)
    private String supplierName;

    @Schema(description = "客户名称")
    @TableField(exist = false)
    private String custName;

    @Schema(description = "客户账号")
    @TableField(exist = false)
    private String linkphone;

    @Schema(description = "联系人")
    @TableField(exist = false)
    private String linkman;

    @Schema(description = "地址")
    @TableField(exist = false)
    private String address;

    @Schema(description = "供应商数量")
    @TableField(exist = false)
    private Integer supplierCount;

    @Schema(description = "供应商商品申请表 id，报价后更新")
    @TableField(exist = false)
    private String productApplyId;

}
