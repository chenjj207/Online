package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.DeliveryDate;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.DeliveryDatePageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-28
 */
@Mapper
public interface DeliveryDateMapper extends BaseMapper<DeliveryDate> {

    Page<DeliveryDate> page (@Param("dto") DeliveryDatePageDTO dto , Page page);

}
