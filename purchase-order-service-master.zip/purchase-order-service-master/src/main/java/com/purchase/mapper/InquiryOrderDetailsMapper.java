package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.InquiryOrderDetails;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.InquiryOrderPageBackDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 惠采商品询价单 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-08-31
 */
@Mapper
public interface InquiryOrderDetailsMapper extends BaseMapper<InquiryOrderDetails> {
    /**
     * 待供应商报价
     * @param dto
     * @param page
     * @return
     */
    Page<InquiryOrderDetails> selectPending (@Param("dto") InquiryOrderPageBackDTO dto , Page page);

    /**
     * 待供应商报价 数量查询
     * @param dto
     * @return
     */
    int selectPendingCount (@Param("dto") InquiryOrderPageBackDTO dto );

    /**
     * 已报价待确认
     * 已报价已确认
     * 已采纳
     * 已作废
     * @param dto
     * @param page
     * @return
     */
    Page<InquiryOrderDetails> selectByState(@Param("dto") InquiryOrderPageBackDTO dto , Page page);

    /**
     * 已报价待确认
     * 已报价已确认
     * 已采纳
     * 已作废
     * 数量查询
     * @param dto
     * @return
     */
    int selectByStateCount(@Param("dto") InquiryOrderPageBackDTO dto);

    Page<InquiryOrderDetails> selectByStateAndSupplier(@Param("dto") InquiryOrderPageBackDTO dto , Page page);

    int selectByStateAndSupplierCount(@Param("dto") InquiryOrderPageBackDTO dto);

    List<InquiryOrderDetails> listByAdmin(@Param("inquiryOrderId") Integer inquiryOrderId);

    List<InquiryOrderDetails> listBySupplier(@Param("inquiryOrderId") Integer inquiryOrderId, @Param("supplierId") String supplierId);

    List<InquiryOrderDetails> listByNoQuote(@Param("inquiryOrderId") Integer inquiryOrderId);

    int emptyQuote(@Param("item")List<Integer> ids, @Param("userId") String userId);
}
