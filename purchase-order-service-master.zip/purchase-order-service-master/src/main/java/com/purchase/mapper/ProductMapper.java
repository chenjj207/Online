package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Product;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.CommonEsDTO;
import com.purchase.service.dto.CommonProductDTO;
import com.purchase.service.vo.ProductPageVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 惠采商品列表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-08-31
 */
@Mapper
public interface ProductMapper extends BaseMapper<Product> {

    List<CommonEsDTO> selectSkuOrProduct(@Param("skuCodeOrTypeList") List<String> skuCodeOrTypeList);

    Page<ProductPageVO> selectBySupplier(@Param("key")String key, @Param("supplierId")String supplierId , Page page);

    List<ProductPageVO> productQuote(@Param("productId")Integer productId);

    List<CommonProductDTO> selectCommonByIds(@Param("idList") List<String> idList);

    String selectSelfSupplier();
}
