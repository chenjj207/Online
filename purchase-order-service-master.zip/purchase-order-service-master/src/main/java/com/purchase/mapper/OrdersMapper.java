package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Orders;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.OrderPageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 订单表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-12
 */
@Mapper
public interface OrdersMapper extends BaseMapper<Orders> {

    /**
     * 订单分页查询
     * @param dto
     * @param page
     * @return
     */
    Page<Orders> page (@Param("dto") OrderPageDTO dto , Page page);

    int count (@Param("dto") OrderPageDTO dto);

    Orders selectOrdersById (Integer id);
}
