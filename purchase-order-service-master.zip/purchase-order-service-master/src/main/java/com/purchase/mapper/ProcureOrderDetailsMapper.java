package com.purchase.mapper;

import com.purchase.entity.ProcureOrderDetails;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 采购订单详情表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
@Mapper
public interface ProcureOrderDetailsMapper extends BaseMapper<ProcureOrderDetails> {

}
