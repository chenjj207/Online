package com.purchase.mapper;

import com.purchase.entity.OrderDetails;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 订单详情表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-12
 */
@Mapper
public interface OrderDetailsMapper extends BaseMapper<OrderDetails> {

    List<OrderDetails> selectListByOrderId(@Param("orderId") Integer orderId);

}
