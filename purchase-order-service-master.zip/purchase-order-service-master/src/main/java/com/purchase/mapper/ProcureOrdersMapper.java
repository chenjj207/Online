package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.ProcureOrders;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.ProcureOrderPageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 采购订单表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
@Mapper
public interface ProcureOrdersMapper extends BaseMapper<ProcureOrders> {

    /**
     * 采购订单分页查询
     * @param dto
     * @param page
     * @return
     */
    Page<ProcureOrders> page (@Param("dto") ProcureOrderPageDTO dto , Page page);

    int count (@Param("dto") ProcureOrderPageDTO dto);

    ProcureOrders selectById (Integer id);
}
