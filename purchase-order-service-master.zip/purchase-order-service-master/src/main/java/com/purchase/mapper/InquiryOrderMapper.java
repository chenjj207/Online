package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.InquiryOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.InquiryOrderMallPageDTO;
import com.purchase.service.dto.InquiryOrderPageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-19
 */
@Mapper
public interface InquiryOrderMapper extends BaseMapper<InquiryOrder> {
    /**
     * 商城端询价单分页查询
     * @param dto
     * @param page
     * @return
     */
    Page<InquiryOrder> page (@Param("dto") InquiryOrderPageDTO dto , Page page);

    /**
     * 运营端询价单分页查询
     * @param dto
     * @param page
     * @return
     */
    Page<InquiryOrder> pageAdmin (@Param("dto") InquiryOrderPageDTO dto , Page page);

    /**
     * 供应商端询价单分页查询
     * @param dto
     * @param page
     * @return
     */
    Page<InquiryOrder> pageSupplier (@Param("dto") InquiryOrderPageDTO dto , Page page);

    Page<InquiryOrder> pageLyh (@Param("dto") InquiryOrderMallPageDTO dto , Page page);


    int count (@Param("dto") InquiryOrderPageDTO dto);
    /**
     * 运营端询价单 统计
     * @param dto
     * @return
     */
    int countAdmin (@Param("dto") InquiryOrderPageDTO dto);

    /**
     * 供应商端询价单 统计
     * @param dto
     * @return
     */
    int countSupplier (@Param("dto") InquiryOrderPageDTO dto);

    int emptyQuote(@Param("id")Integer id, @Param("userId") String userId);

    String selectPhoneByCustId(@Param("custId")Integer custId);

    String selectUnionIdByCustId(@Param("custId")Integer custId);

    List<String> selectPhoneBySupplier();

    InquiryOrder selectByInquiryOrderId(@Param("id")Integer id);
}
