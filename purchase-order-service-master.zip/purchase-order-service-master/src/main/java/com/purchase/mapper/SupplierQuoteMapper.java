package com.purchase.mapper;

import com.purchase.entity.SupplierQuote;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 供应商惠采商品 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-08-31
 */
@Mapper
public interface SupplierQuoteMapper extends BaseMapper<SupplierQuote> {

    List<SupplierQuote> selectByInquiryOrderDetailsId(@Param("inquiryOrderDetailsId")Integer inquiryOrderDetailsId);

    List<SupplierQuote> selectByInquiryOrderId(@Param("inquiryOrderId")Integer inquiryOrderId);
}
