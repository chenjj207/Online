package com.purchase.controller;

import com.purchase.service.SupplierQuoteService;
import com.purchase.service.dto.ConfirmQuoteAddDTO;
import com.purchase.service.dto.ConfirmQuoteSaveDTO;
import com.purchase.service.dto.SupplierQuoteAddDTO;
import com.purchase.service.dto.SupplierQuoteSaveDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * <p>
 * 供应商惠采商品报价 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-08-31
 */
@RestController
@RequestMapping("/purchase-supplier-quote")
public class SupplierQuoteController {

    @Autowired
    SupplierQuoteService supplierQuoteService;

    @PostMapping("/add")
    @Operation(summary = "惠采后台 -- 供应商提交报价单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean add(@Valid @RequestBody SupplierQuoteAddDTO supplierQuoteAddDTO){
        return supplierQuoteService.add(supplierQuoteAddDTO);
    }

    @PostMapping("/save")
    @Operation(summary = "惠采后台 -- 供应商保存报价单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean save(@Valid @RequestBody SupplierQuoteSaveDTO supplierQuoteSaveDTO){
        return supplierQuoteService.save(supplierQuoteSaveDTO);
    }

    @PostMapping("/confirm/add")
    @Operation(summary = "惠采平台运营后台 -- 提交报价")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean confirmAdd(@RequestBody ConfirmQuoteAddDTO confirmQuoteAddDTO){
        return supplierQuoteService.confirmAdd(confirmQuoteAddDTO);
    }

    @PostMapping("/confirm/save")
    @Operation(summary = "惠采平台运营后台 -- 保存报价")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean save(@RequestBody ConfirmQuoteSaveDTO confirmQuoteSaveDTO){
        return supplierQuoteService.confirmSave(confirmQuoteSaveDTO);
    }

}
