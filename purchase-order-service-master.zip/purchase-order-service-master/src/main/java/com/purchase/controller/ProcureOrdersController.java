package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.ProcureOrders;
import com.purchase.service.CommonService;
import com.purchase.service.ProcureOrdersService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.ProcureOrderTabVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 采购订单表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
@RestController
@RequestMapping("/procure-orders")
public class ProcureOrdersController {

    @Autowired
    ProcureOrdersService procureOrdersService;
    @Autowired
    CommonService commonService;

    @PostMapping("/admin/page")
    @Operation(summary = "慧采平台运营端--采购订单列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<ProcureOrders> adminPage(@Valid @RequestBody ProcureOrderPageDTO procureOrderPageDTO){
        return procureOrdersService.page(procureOrderPageDTO);
    }

    @PostMapping(value = "/admin/count")
    @Operation(summary = "慧采平台运营端 -- 统计采购订单数量")
    @Auth(value = AuthType.NONE)
    public List<ProcureOrderTabVO> adminCount(@Valid @RequestBody ProcureOrderPageDTO procureOrderPageDTO){
        return procureOrdersService.countTab(procureOrderPageDTO);
    }

    @PostMapping(value = "/supplier/page")
    @Operation(summary = "慧采平台供应商--采购订单列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<ProcureOrders> supplierPage(@Valid @RequestBody ProcureOrderPageDTO procureOrderPageDTO){
        procureOrderPageDTO.setSupplierId(commonService.getSupplierId());
        return procureOrdersService.page(procureOrderPageDTO);
    }

    @PostMapping(value = "/supplier/count")
    @Operation(summary = "慧采平台供应商 -- 统计采购订单数量")
    @Auth(value = AuthType.NONE)
    public List<ProcureOrderTabVO> supplierCount(@Valid @RequestBody ProcureOrderPageDTO procureOrderPageDTO){
        procureOrderPageDTO.setSupplierId(commonService.getSupplierId());
        return procureOrdersService.countTab(procureOrderPageDTO);
    }

    @PostMapping("/cancel")
    @Operation(summary = "慧采平台运营端、供应商 -- 作废订单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean cancel(@RequestBody CancelProcureOrderDTO cancelProcureOrderDTO){
        return procureOrdersService.cancel(cancelProcureOrderDTO);
    }

    @PostMapping("/confirm")
    @Operation(summary = "慧采平台运营端、供应商 -- 确认订单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean confirm(@RequestBody ConfirmProcureOrderDTO confirmProcureOrderDTO){
        return procureOrdersService.confirm(confirmProcureOrderDTO);
    }

    @PostMapping("/query")
    @Operation(summary = "采购订单详情")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public ProcureOrders query(@RequestParam(value = "id", required = true)Integer id){
        return procureOrdersService.query(id);
    }
}
