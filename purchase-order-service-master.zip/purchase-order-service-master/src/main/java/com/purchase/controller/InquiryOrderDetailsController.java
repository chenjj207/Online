package com.purchase.controller;


import com.purchase.entity.InquiryOrderDetails;
import com.purchase.service.InquiryOrderDetailsService;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-19
 */
@RestController
@RequestMapping("/inquiry-order-details")
public class InquiryOrderDetailsController {

    @Autowired
    InquiryOrderDetailsService inquiryOrderDetailsService;

    @PostMapping("/list")
    @Operation(summary = "惠采商城--询价详情查询")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public List<InquiryOrderDetails> list(@RequestParam(value = "inquiryOrderId", required = true)Integer inquiryOrderId){
        return inquiryOrderDetailsService.list(inquiryOrderId);
    }

    @PostMapping("/admin/list")
    @Operation(summary = "惠采平台运营后台--询价详情查询")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public List<InquiryOrderDetails> listByAdmin(@RequestParam(value = "inquiryOrderId", required = true)Integer inquiryOrderId){
        return inquiryOrderDetailsService.listByAdmin(inquiryOrderId);
    }

    @PostMapping("/supplier/list")
    @Operation(summary = "惠采平台供应商后台--询价详情查询")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public List<InquiryOrderDetails> listBySupplier(@RequestParam(value = "inquiryOrderId", required = true)Integer inquiryOrderId){
        return inquiryOrderDetailsService.listBySupplier(inquiryOrderId);
    }

    @PostMapping("/lyh/mall/list")
    @Operation(summary = "惠采平台供应商后台--询价详情查询")
    @Auth(value = AuthType.NONE)
    public List<InquiryOrderDetails> listByLyh(@RequestParam(value = "inquiryOrderId", required = true)Integer inquiryOrderId){
        return inquiryOrderDetailsService.listByLyh(inquiryOrderId);
    }
}
