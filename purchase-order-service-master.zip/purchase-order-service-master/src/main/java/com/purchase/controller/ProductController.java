package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Product;
import com.purchase.service.ProductService;
import com.purchase.service.dto.InquiryOrderIdDTO;
import com.purchase.service.dto.ProductBatchDTO;
import com.purchase.service.dto.ProductPageDTO;
import com.purchase.service.dto.QuotationExportDTO;
import com.purchase.service.vo.InquiryOrderTabVO;
import com.purchase.service.vo.NeedExportVO;
import com.purchase.service.vo.ParseResultVO;
import com.purchase.service.vo.ProductPageVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * <p>
 * 惠采商品列表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-08-31
 */
@RestController
@RequestMapping("/purchase-product")
public class ProductController {

    @Autowired
    ProductService productService;

    @PostMapping(value = "/need/export")
    @Operation(summary = "惠采商城--上传需求清单")
    @Auth(value = AuthType.NONE)
    public NeedExportVO needExport(@RequestParam(value = "file") MultipartFile multipartFile){
        return productService.needExport(multipartFile);
    }


    @PostMapping(value = "/ocr/export")
    @Operation(summary = "惠采商城--上传手写单")
    @Auth(value = AuthType.NONE)
    public ParseResultVO ocrExport(@RequestParam(value = "file", required = false) MultipartFile multipartFile){
        return productService.ocrExport(multipartFile);
    }


    @PostMapping(value = "/text/parse")
    @Operation(summary = "惠采商城--搜索文本解析")
    @Auth(value = AuthType.NONE)
    public ParseResultVO textParse(@RequestBody ProductBatchDTO productBatchDTO){
        return productService.textParse(productBatchDTO);
    }


    @PostMapping(value = "/quotation/export")
    @Operation(summary = "惠采商城--导出报价单")
    @Auth(value = AuthType.NONE)
    public void export(@RequestBody QuotationExportDTO quotationExportDTO, HttpServletResponse response){
        productService.export(quotationExportDTO, response);
    }

    @PostMapping(value = "/quotation/inquiry/export")
    @Operation(summary = "惠采商城--导出订单明细")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public void exportInquriy(@RequestBody QuotationExportDTO quotationExportDTO, HttpServletResponse response){
        productService.exportInquiry(quotationExportDTO, response);
    }

    @PostMapping(value = "admin/quotation/inquiry/export")
    @Operation(summary = "慧采平台运营端--导出订单明细")
    public void adminExportInquriy(@RequestParam(value = "inquiryOrderId") Integer inquiryOrderId, HttpServletResponse response){
        productService.adminExportInquriy(inquiryOrderId, response);
    }


    @PostMapping(value = "/admin/product/page")
    @Operation(summary = "惠采后台运营端 -- 商品列表")
    @Auth(value = AuthType.NONE)
    public Page<Product> pageAdmin(@Valid @RequestBody ProductPageDTO productPageDTO){
        return productService.page(productPageDTO);
    }

    @PostMapping(value = "/supplier/product/page")
    @Operation(summary = "惠采后台供应商端 -- 商品列表")
    @Auth(value = AuthType.NONE)
    public Page<ProductPageVO> pageSupplier(@Valid @RequestBody ProductPageDTO productPageDTO){
        return productService.pageSupplier(productPageDTO);
    }

    @PostMapping(value = "/admin/product/quote")
    @Operation(summary = "惠采后台运营端 -- 查看产品供货详情")
    @Auth(value = AuthType.NONE)
    public List<ProductPageVO> productQuote(@RequestParam(value = "productId", required = true)Integer productId){
        return productService.productQuote(productId);
    }

}
