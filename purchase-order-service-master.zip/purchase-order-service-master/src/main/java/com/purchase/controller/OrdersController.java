package com.purchase.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Orders;
import com.purchase.service.CommonService;
import com.purchase.service.OrdersService;
import com.purchase.service.dto.CancelOrderDTO;
import com.purchase.service.dto.OrderAddDTO;
import com.purchase.service.dto.OrderPageDTO;
import com.purchase.service.vo.OrdersTabVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 订单表 前端控制器
 * </p>
 * @author jidonglin
 * @since 2023-09-12
 */
@RestController
@RequestMapping("/order")
public class OrdersController {

    @Autowired
    OrdersService ordersService;
    @Autowired
    CommonService commonService;

    @PostMapping("/add")
    @Operation(summary = "惠采商城--立即下单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public String add(@Valid @RequestBody OrderAddDTO orderAddDTO){
        return ordersService.orderAdd(orderAddDTO);
    }

    @PostMapping("/page")
    @Operation(summary = "惠采商城--订单列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<Orders> page(@Valid @RequestBody OrderPageDTO orderPageDTO){
        orderPageDTO.setCustId(Integer.valueOf(commonService.loginId()));
        return ordersService.page(orderPageDTO);
    }

    @PostMapping(value = "/count")
    @Operation(summary = "惠采商城 -- 统计订单数量")
    @Auth(value = AuthType.NONE)
    public List<OrdersTabVO> count(@Valid @RequestBody OrderPageDTO orderPageDTO){
        orderPageDTO.setCustId(Integer.valueOf(commonService.loginId()));
        return ordersService.count(orderPageDTO);
    }

    @PostMapping("/admin/page")
    @Operation(summary = "慧采平台运营端--订单列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<Orders> adminPage(@Valid @RequestBody OrderPageDTO orderPageDTO){
        return ordersService.page(orderPageDTO);
    }

    @PostMapping(value = "/admin/count")
    @Operation(summary = "慧采平台运营端 -- 统计订单数量")
    @Auth(value = AuthType.NONE)
    public List<OrdersTabVO> adminCount(@Valid @RequestBody OrderPageDTO orderPageDTO){
        return ordersService.count(orderPageDTO);
    }

    @PostMapping("/query")
    @Operation(summary = "惠采商城、慧采后台--订单详情")
    @Auth(value = AuthType.NONE)
    public Orders query(@RequestParam(value = "orderId", required = true)Integer orderId){
        return ordersService.getOrdersById(orderId);
    }

    @PostMapping("/cancel")
    @Operation(summary = "惠采商城 -- 作废订单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean cancel(@RequestBody CancelOrderDTO cancelOrderDTO){
        return ordersService.cancel(cancelOrderDTO);
    }

    @PostMapping("/admin/cancel")
    @Operation(summary = "惠采平台运营端 -- 作废订单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean adminCancel(@RequestBody CancelOrderDTO cancelOrderDTO){
        return ordersService.adminCancel(cancelOrderDTO);
    }

}