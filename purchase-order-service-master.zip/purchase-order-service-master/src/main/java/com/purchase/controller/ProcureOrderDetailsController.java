package com.purchase.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.purchase.entity.ProcureOrderDetails;
import com.purchase.entity.ProcureOrders;
import com.purchase.service.ProcureOrderDetailsService;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 * 采购订单详情表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
@RestController
@RequestMapping("/procure-order-details")
public class ProcureOrderDetailsController {

    @Autowired
    ProcureOrderDetailsService procureOrderDetailsService;

    @PostMapping("/list")
    @Operation(summary = "采购订单详情")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public List<ProcureOrderDetails> list(@RequestParam(value = "procureOrderId", required = true)Integer procureOrderId){
        QueryWrapper<ProcureOrderDetails> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("procure_order_id", procureOrderId);
        return procureOrderDetailsService.list(queryWrapper);
    }
}
