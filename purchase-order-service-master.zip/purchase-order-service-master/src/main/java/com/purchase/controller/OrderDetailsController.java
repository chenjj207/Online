package com.purchase.controller;


import com.purchase.entity.OrderDetails;
import com.purchase.service.OrderDetailsService;
import com.purchase.service.dto.ConfirmOrderDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 订单详情表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-12
 */
@RestController
@RequestMapping("/order-details")
public class OrderDetailsController {

    @Autowired
    OrderDetailsService orderDetailsService;

    @PostMapping("/list")
    @Operation(summary = "惠采商城、慧采后台--订单详情")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public List<OrderDetails> list(@RequestParam(value = "orderId", required = true)Integer orderId){
        return orderDetailsService.listByOrderId(orderId);
    }


    @PostMapping("/confirm")
    @Operation(summary = "慧采后台运营端 -- 确认商品订单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean confirm(@Valid @RequestBody ConfirmOrderDTO confirmOrderDTO){
        return orderDetailsService.confirm(confirmOrderDTO);
    }
}
