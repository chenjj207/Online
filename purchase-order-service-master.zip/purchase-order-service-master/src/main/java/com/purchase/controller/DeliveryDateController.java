package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.DeliveryDate;
import com.purchase.service.DeliveryDateService;
import com.purchase.service.dto.DeliveryDateAddDTO;
import com.purchase.service.dto.DeliveryDatePageDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-28
 */
@RestController
@RequestMapping("/delivery-date")
public class DeliveryDateController {

    @Autowired
    DeliveryDateService deliveryDateService;

    @PostMapping("/add")
    @Operation(summary = "货期添加")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Integer add(@Valid @RequestBody DeliveryDateAddDTO deliveryDateAddDTO){
        return deliveryDateService.add(deliveryDateAddDTO);
    }

    @PostMapping("/page")
    @Operation(summary = "惠采后台--货期分页查询")
    @Auth(value = AuthType.NONE)
    public Page<DeliveryDate> queryList(@RequestBody DeliveryDatePageDTO deliveryDatePageDTO){
        return deliveryDateService.queryList(deliveryDatePageDTO);
    }
}
