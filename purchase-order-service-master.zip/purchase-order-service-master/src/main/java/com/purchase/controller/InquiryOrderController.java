package com.purchase.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.InquiryOrder;
import com.purchase.service.InquiryOrderService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.InquiryOrderAndQuotesVO;
import com.purchase.service.vo.InquiryOrderTabVO;
import com.purchase.service.vo.ProductAnalysVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 惠采商品询价单 前端控制器
 * </p>
 * @author jidonglin
 * @since 2023-08-31
 */
@RestController
@RequestMapping("/inquiry-order")
public class InquiryOrderController {

    @Autowired
    InquiryOrderService inquiryOrderService;

    @PostMapping("/add")
    @Operation(summary = "惠采商城--立即询价")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Integer add(@Valid @RequestBody InquiryOrderAddDTO inquiryOrderAddDTO){
        return inquiryOrderService.add(inquiryOrderAddDTO);
    }

    @PostMapping("/page")
    @Operation(summary = "惠采商城--询价列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<InquiryOrder> page(@Valid @RequestBody InquiryOrderPageDTO inquiryOrderPageDTO){
        return inquiryOrderService.page(inquiryOrderPageDTO);
    }

    @PostMapping("/cancel")
    @Operation(summary = "惠采商城--取消订单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean cancel(@Valid @RequestBody InquiryOrderCancelDTO inquiryOrderCancelDTO){
        return inquiryOrderService.cancel(inquiryOrderCancelDTO);
    }

    @PostMapping("/delete")
    @Operation(summary = "惠采商城--标价删除订单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean delete(@Valid @RequestBody InquiryOrderDeleteDTO inquiryOrderDeleteDTO){
        return inquiryOrderService.delete(inquiryOrderDeleteDTO);
    }

    @PostMapping("/admin/cancel")
    @Operation(summary = "惠采平台运营后台--取消订单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean adminCancel(@Valid @RequestBody InquiryOrderCancelDTO inquiryOrderCancelDTO){
        return inquiryOrderService.adminCancel(inquiryOrderCancelDTO);
    }

    @PostMapping("/admin/delete")
    @Operation(summary = "惠采平台运营后台--标价删除订单")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean adminDelete(@Valid @RequestBody InquiryOrderDeleteDTO inquiryOrderDeleteDTO){
        return inquiryOrderService.adminDelete(inquiryOrderDeleteDTO);
    }

    @PostMapping("/admin/page")
    @Operation(summary = "惠采平台运营后台 -- 询价列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<InquiryOrder> pageByAdmin(@Valid @RequestBody InquiryOrderPageDTO inquiryOrderPageDTO){
        return inquiryOrderService.pageByAdmin(inquiryOrderPageDTO);
    }

    @PostMapping("/supplier/page")
    @Operation(summary = "惠采平台供应商 -- 询价列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<InquiryOrder> pageBySupplier(@Valid @RequestBody InquiryOrderPageDTO inquiryOrderPageDTO){
        return inquiryOrderService.pageBySupplier(inquiryOrderPageDTO);
    }

    @PostMapping("/lyh/mall/page")
    @Operation(summary = "联营慧PC端 -- 询价列表")
    @Auth(value = AuthType.NONE)
    public Page<InquiryOrder> pageByLyh(@Valid @RequestBody InquiryOrderMallPageDTO inquiryOrderPageDTO){
        return inquiryOrderService.pageByLyh(inquiryOrderPageDTO);
    }

    @PostMapping(value = "/inquiry/count")
    @Operation(summary = "惠采商城 -- 统计询价单数量")
    @Auth(value = AuthType.NONE)
    public List<InquiryOrderTabVO> count(@Valid @RequestBody InquiryOrderPageDTO inquiryOrderPageDTO){
        return inquiryOrderService.countTab(inquiryOrderPageDTO);
    }

    @PostMapping(value = "/admin/inquiry/count")
    @Operation(summary = "惠采后台运营端 -- 统计询价单数量")
    @Auth(value = AuthType.NONE)
    public List<InquiryOrderTabVO> adminCount(@Valid @RequestBody InquiryOrderPageDTO inquiryOrderPageDTO){
        return inquiryOrderService.adminCountTab(inquiryOrderPageDTO);
    }

    @PostMapping(value = "/supplier/inquiry/count")
    @Operation(summary = "惠采后台供应商端 -- 统计询价单数量")
    @Auth(value = AuthType.NONE)
    public List<InquiryOrderTabVO> supplierCount(@Valid @RequestBody InquiryOrderPageDTO inquiryOrderPageDTO){
        return inquiryOrderService.supplierCountTab(inquiryOrderPageDTO);
    }

    @PostMapping("/query")
    @Operation(summary = "惠采商城、惠采后台 -- 询价单查询")
    @Auth(value = AuthType.NONE)
    public InquiryOrder query(@RequestParam(value = "inquiryOrderId", required = true)Integer inquiryOrderId){
        return inquiryOrderService.queryById(inquiryOrderId);
    }

    @PostMapping("/mall/query")
    @Operation(summary = "联营慧PC端 -- 询价单查询")
    @Auth(value = AuthType.NONE)
    public InquiryOrder mallQuery(@RequestParam(value = "inquiryOrderId", required = true)Integer inquiryOrderId){
        return inquiryOrderService.mallQuery(inquiryOrderId);
    }


    @PostMapping("/supplier-quote/query")
    @Operation(summary = "惠采平台运营后台 -- 根据询价id 查看供应商报价")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public InquiryOrderAndQuotesVO queryQuote(@RequestParam(value = "inquiryOrderDetailsId", required = true)Integer inquiryOrderDetailsId){
        return inquiryOrderService.queryQuote(inquiryOrderDetailsId);
    }

    @PostMapping(value = "/product/analys")
    @Operation(summary = "惠采后台供应商端 -- 采购分析")
    @Auth(value = AuthType.NONE)
    public ProductAnalysVO productAnalys(@RequestParam("inquriyId")Integer inquiryId){
        return inquiryOrderService.productAnalys(inquiryId);
    }
}
