package com.purchase.config;

import com.zyd.framework.utils.exception.BaseExceptionDesc;
import com.zyd.framework.utils.exception.BusinessExceptionDesc;

/**
 * @author jidonglin
 * @Description: 服务异常码
 */
public class PurchaseOrderExceptionDesc extends BusinessExceptionDesc {
    public static BaseExceptionDesc NOT_EXIST_CUSTOMER = new BaseExceptionDesc(-40000, "该用户信息不存在");
    public static BaseExceptionDesc ERROR_EXCEL_TYPE = new BaseExceptionDesc(-50000, "上传文件有误，请重新上传");
    public static BaseExceptionDesc ERROR_IO = new BaseExceptionDesc(-50001, "读取文件IO异常");
    public static BaseExceptionDesc ERROR_EXCEL_NUM = new BaseExceptionDesc(-50002, "导入数据不超过800行");
    public static BaseExceptionDesc ERROR_EXCEL_EXPORT = new BaseExceptionDesc(-50003, "上传文件有误，请重新上传");
    public static BaseExceptionDesc ERROR_GET_EXCEL_MODULE = new BaseExceptionDesc(-50004, "无法获取模板");
    public static BaseExceptionDesc ERROR_UPLOAD_MODULE = new BaseExceptionDesc(-50005, "导入失败");
    public static BaseExceptionDesc QYT_MORE_ONE = new BaseExceptionDesc(-50006, "搜索的产品数量要大于1");
    public static BaseExceptionDesc QYT_LESS = new BaseExceptionDesc(-50007, "数量最大值为99999");
    public static BaseExceptionDesc ERROR_EXCEL_EMPTY = new BaseExceptionDesc(-50008, "导入内容为空");
    public static BaseExceptionDesc ERROR_EXCEL_SIZE = new BaseExceptionDesc(-50009, "上传模板文件大小限制为10M，请重新上传");
    public static BaseExceptionDesc NO_LOGIN = new BaseExceptionDesc(-50010, "未登录");
    public static BaseExceptionDesc NO_SUPPLIER_SET_UP = new BaseExceptionDesc(-50011, "未开通供应商");
    public static BaseExceptionDesc NOT_EXIST_INQUIRY_ORDER = new BaseExceptionDesc(-50012, "不存在询价单");
    public static BaseExceptionDesc NOT_EXIST_SUPPLIER_QUOTE = new BaseExceptionDesc(-50013, "不存在此供应商报价");
    public static BaseExceptionDesc INQUIRY_ORDER_NOT_EXIST_SUPPLIER_QUOTE = new BaseExceptionDesc(-50014, "报价单不存在此报价");
    public static BaseExceptionDesc ERROR_QUOTE = new BaseExceptionDesc(-50015, "报价失败");
    public static BaseExceptionDesc EXIST_SUPPLIER_QUOTE = new BaseExceptionDesc(-50016, "已存在供应商报价");
    public static BaseExceptionDesc HAS_CONFIRM_QUOTE = new BaseExceptionDesc(-50017, "已确认过报价");
    public static BaseExceptionDesc EMPTY_ORDER = new BaseExceptionDesc(-50018, "下单商品不能为空");
    public static BaseExceptionDesc ERROR_ADD_ORDER = new BaseExceptionDesc(-50019, "添加订单失败");
    public static BaseExceptionDesc NOT_EXIST_ORDER_TAB = new BaseExceptionDesc(-50020, "下单页面必填");
    public static BaseExceptionDesc EXPIRE_INQUIRY_ORDER = new BaseExceptionDesc(-50021, "询价单已过期");
    public static BaseExceptionDesc NOT_EMPTY_INQUIRY = new BaseExceptionDesc(-50022, "询价单不能为空");
    public static BaseExceptionDesc EXIST_QUOTE_ZERO = new BaseExceptionDesc(-50023, "请选中可下单商品！");
    public static BaseExceptionDesc NOT_EXIST_PURCHASE_PRODUCT = new BaseExceptionDesc(-50024, "不存在此惠采商品");
    public static BaseExceptionDesc ERROR_INQUIRY = new BaseExceptionDesc(-50025, "询价失败");
    public static BaseExceptionDesc ERROR_QUOTE_PRICE = new BaseExceptionDesc(-50026, "报价金额错误");
    public static BaseExceptionDesc NOT_EXIST_INQUIRY_ORDER_DETAILS = new BaseExceptionDesc(-50027, "询价详情列表不存在");
    public static BaseExceptionDesc ERROR_QUOTE_PRICE_OR_STOCK = new BaseExceptionDesc(-50028, "报价金额或库存错误");
    public static BaseExceptionDesc ERROR_SAVE_QUOTE = new BaseExceptionDesc(-50029, "报价单保存失败");
    public static BaseExceptionDesc CANNOT_QUOTE = new BaseExceptionDesc(-50030, "当前报价单不能报价");
    public static BaseExceptionDesc NOT_EXIST_INQUIRY_DETAILS_ORDER = new BaseExceptionDesc(-50031, "询价详情单不存在");
    public static BaseExceptionDesc ERROR_SUBMIT_QUOTE = new BaseExceptionDesc(-50032, "询价详情单不存在");
    public static BaseExceptionDesc CANNOT_SUBMIT_QUOTE = new BaseExceptionDesc(-50033, "当前报价单状态不能提交报价");
    public static BaseExceptionDesc CANNOT_SAVE_QUOTE = new BaseExceptionDesc(-50034, "当前报价单状态不能保存报价");
    public static BaseExceptionDesc NOT_EMPTY_SAVE_QUOTE = new BaseExceptionDesc(-50035, "要保存的报价单信息不能为空");
    public static BaseExceptionDesc NOT_EMPTY_ADD_QUOTE = new BaseExceptionDesc(-50036, "要添加的报价单信息不能为空");
    public static BaseExceptionDesc ERROR_OCR = new BaseExceptionDesc(-50037, "图片解析失败");
    public static BaseExceptionDesc NOT_EXIST_TAB = new BaseExceptionDesc(-50038, "不存在此tab");
    public static BaseExceptionDesc NOT_NULL_ORDER_ID = new BaseExceptionDesc(-50039, "询价单id不存在");
    public static BaseExceptionDesc NOT_EQUALS_ORDER_AND_DETAILS = new BaseExceptionDesc(-50040, "询价单与询价详情不一致");
    public static BaseExceptionDesc NOT_OCR_WORD = new BaseExceptionDesc(-50041, "未识别出文字");
    public static BaseExceptionDesc EXIST_ERROR_INQUIRY_DETAILS = new BaseExceptionDesc(-50042, "存在无法报价的商品");
    public static BaseExceptionDesc NOT_EXIST_INQUIRY_DETAILS_TO_QUOTE = new BaseExceptionDesc(-50043, "不存在可报价的商品");
    public static BaseExceptionDesc NOT_EXIST_SUBMIT_INQUIRY_DETAILS = new BaseExceptionDesc(-50044, "不存在可提交报价的商品");
    public static BaseExceptionDesc ERROR_EXPORT_ORDER = new BaseExceptionDesc(-50045, "清单导出异常");
    public static BaseExceptionDesc NOT_EQUALS_ORDER_AND_USER = new BaseExceptionDesc(-50046, "询价单不属于当前客户");
    public static BaseExceptionDesc NOT_VOIDED_STATE = new BaseExceptionDesc(-50047, "不是作废状态不能删除");
    public static BaseExceptionDesc NOT_EXIST_ORDER_DETAILS = new BaseExceptionDesc(-50048, "订单的商品信息不存在");
    public static BaseExceptionDesc EXIST_ORDER_DETAILS_PROCURE = new BaseExceptionDesc(-50049, "存在已转采的商品");
    public static BaseExceptionDesc EXIST_NOT_SUPPLIER_ORDERS_DETAILS = new BaseExceptionDesc(-50050, "存在供应商为空的商品");
    public static BaseExceptionDesc NOT_EXIST_ORDERS = new BaseExceptionDesc(-50051, "订单不存在");
    public static BaseExceptionDesc CAN_NOT_CANCEL_NOT_PENDING_ORDERS = new BaseExceptionDesc(-50052, "不能作废不是待确认的订单");
    public static BaseExceptionDesc CAN_NOT_CONFIRM_NOT_PENDING_ORDERS = new BaseExceptionDesc(-50053, "不能确认不是待确认的订单");
    public static BaseExceptionDesc NOT_EXIST_PROCURE_ORDERS = new BaseExceptionDesc(-50054, "采购订单不存在");
    public static BaseExceptionDesc ERROR_SUPPLY_PRICE = new BaseExceptionDesc(-50055, "商品毛利低于约定毛利率");
}
