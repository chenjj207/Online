package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.URLUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.client.MsgClient;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.common.OrderConstants;
import com.purchase.config.PurchaseOrderExceptionDesc;
import com.purchase.entity.*;
import com.purchase.mapper.*;
import com.purchase.service.CommonService;
import com.purchase.service.InquiryOrderDetailsService;
import com.purchase.service.InquiryOrderService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.InquiryOrderAndQuotesVO;
import com.purchase.service.vo.InquiryOrderTabVO;
import com.purchase.service.vo.ProductAnalysVO;
import com.zyd.framework.utils.constant.UserSession;
import com.zyd.framework.utils.exception.BaseExceptionDesc;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 惠采商品询价单 服务实现类
 * </p>
 * @author jidonglin
 * @since 2023-08-31
 */
@Service
public class InquiryOrderServiceImpl extends ServiceImpl<InquiryOrderMapper, InquiryOrder> implements InquiryOrderService {

    @Resource
    InquiryOrderMapper inquiryOrderMapper;
    @Resource
    InquiryOrderDetailsMapper inquiryOrderDetailsMapper;
    @Resource
    SupplierQuoteMapper supplierQuoteMapper;
    @Resource
    ProductMapper productMapper;
    @Resource
    OrderDetailsMapper orderDetailsMapper;

    @Autowired
    CommonService commonService;
    @Autowired
    InquiryOrderDetailsService inquiryOrderDetailsService;
    @Resource
    MsgClient msgClient;

    @Value("${odsUrl}")
    String odsUrl;
    @Override
    @Transactional
    public Integer add(InquiryOrderAddDTO inquiryOrderAddDTO) {
        if (inquiryOrderAddDTO == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EMPTY_INQUIRY);
        }
        //获取当前客户id
        Integer custId = Integer.valueOf(commonService.loginId());
        //生成询价编码
        String inquiryCode = OrderConstants.OrderNumPrefix.INQUIRY.code + System.currentTimeMillis();
        //当前时间
        LocalDateTime now = LocalDateTime.now();

        List<InquiryOrderDetails> inquiryOrderDetailsList = new ArrayList<>();
        InquiryOrder inquiryOrder = new InquiryOrder();
        inquiryOrder.setInquiryCode(inquiryCode);
        inquiryOrder.setTitle(inquiryOrderAddDTO.getTitle());
        inquiryOrder.setAllQuotePrice(null);
        inquiryOrder.setItems(inquiryOrderAddDTO.getInquiryOrderDetails().size());
        inquiryOrder.setState(OrderConstants.InquiryState.IN_QUOTATION.code);
        inquiryOrder.setConfirmState(OrderConstants.InquiryConfirmState.UN_CONFIRMED.code);
        inquiryOrder.setInquiryExpireTime(now.plusDays(inquiryOrderAddDTO.getDay()));
        inquiryOrder.setExpectDeliveryDate(inquiryOrderAddDTO.getExpectDeliveryDate());
        inquiryOrder.setCreatedAt(now);
        inquiryOrder.setCustId(custId);
        int count = inquiryOrderMapper.insert(inquiryOrder);
        if (count != 1){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_INQUIRY);
        }
        Integer inquiryOrderId = inquiryOrder.getId();

        for (int j = 0; j < inquiryOrderAddDTO.getInquiryOrderDetails().size(); j++) {
            InquiryOrderDetails i = inquiryOrderAddDTO.getInquiryOrderDetails().get(j);
            if (StringUtils.isEmpty(i.getBrandName()) && StringUtils.isEmpty(i.getProductType()) && StringUtils.isEmpty(i.getProductName())){
                BaseExceptionDesc standard = new BaseExceptionDesc();
                standard.setCode(PurchaseOrderExceptionDesc.ERROR_INQUIRY.getCode());
                standard.setDesc("请先完善第"+ (j+1)  +"行商品信息");
                throw BusinessException.newInstance(standard);
            }
            InquiryOrderDetails inquiryOrderDetails = new InquiryOrderDetails();
            BeanUtil.copyProperties(i, inquiryOrderDetails);
            //报价，货期，库存数， 小计 默认为空
            inquiryOrderDetails.setQuotePrice(null);
            inquiryOrderDetails.setDeliveryDate(null);
            inquiryOrderDetails.setStock(null);
            inquiryOrderDetails.setSubtotal(null);
            inquiryOrderDetails.setInquiryOrderId(inquiryOrderId);
            inquiryOrderDetails.setState(OrderConstants.InquiryState.IN_QUOTATION.code);
            inquiryOrderDetails.setConfirmState(OrderConstants.InquiryConfirmState.UN_CONFIRMED.code);
            inquiryOrderDetails.setCustId(custId);
            // 11+时间戳
            inquiryOrderDetails.setInquiryCode(inquiryCode);
            inquiryOrderDetails.setCreatedAt(now);
            inquiryOrderDetails.setExpectDeliveryDate(inquiryOrderAddDTO.getExpectDeliveryDate());
            inquiryOrderDetails.setInquiryExpireTime(now.plusDays(inquiryOrderAddDTO.getDay()));


            //查询是否存在惠采临时商品
            QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("brand_name", i.getBrandName());
            queryWrapper.eq("product_type", i.getProductType());
            queryWrapper.eq("product_name", i.getProductName());
            Product productQuery = productMapper.selectOne(queryWrapper);
            if (productQuery != null){
                inquiryOrderDetails.setProductId(productQuery.getId().longValue());
            }
            inquiryOrderDetailsList.add(inquiryOrderDetails);
        }

        boolean result = inquiryOrderDetailsService.saveBatch(inquiryOrderDetailsList);
        if (!result){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_INQUIRY);
        }

        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("order");
        triggerMsgRequest.setScene("memberAddInquiryOrder");

        JSONObject qywxParam = new JSONObject();
        //企业微信
        qywxParam.put("msgtype", "template_card");
        JSONObject templateCard = new JSONObject();
        templateCard.put("card_type", "text_notice");
        JSONObject mainTitle = new JSONObject();
        mainTitle.put("title", "您有新询价单待报价");
        mainTitle.put("desc", "订单报价中");
        templateCard.put("main_title", mainTitle);
        List<JSONObject> horizontalContentList = new ArrayList<>();
        JSONObject keyName1 = new JSONObject();
        keyName1.put("keyname", "客户名称");
        keyName1.put("value", commonService.getCustInfo().getString("company"));
        horizontalContentList.add(keyName1);
        JSONObject keyName2 = new JSONObject();
        keyName2.put("keyname", "商城账号");
        keyName2.put("value", commonService.getCustInfo().getString("linkphone"));
        horizontalContentList.add(keyName2);
        JSONObject keyName3 = new JSONObject();
        keyName3.put("keyname", "询价单号");
        keyName3.put("value", inquiryCode);
        horizontalContentList.add(keyName3);
        JSONObject keyName4 = new JSONObject();
        keyName4.put("keyname", "询价时间");
        keyName4.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
        horizontalContentList.add(keyName4);
        templateCard.put("horizontal_content_list", horizontalContentList);

        JSONObject emphasisContent = new JSONObject();
        emphasisContent.put("title",  inquiryOrder.getAllQuotePrice()==null ? "询价" : ("￥ " + inquiryOrder.getAllQuotePrice()));
        emphasisContent.put("desc", "商品行数:" + inquiryOrder.getItems());
        templateCard.put("emphasis_content", emphasisContent);

        List<JSONObject> jumpList = new ArrayList<>();
        JSONObject jumpList1 = new JSONObject();
        jumpList1.put("type", 1);
        jumpList1.put("title", "跳转惠采");
        jumpList1.put("url", odsUrl + "/#/supply-manager/subsidiary/customer-manage/enquiry?key=" + URLUtil.encode(inquiryCode));
        jumpList.add(jumpList1);
        templateCard.put("jump_list", jumpList);

        JSONObject cardAction = new JSONObject();
        cardAction.put("type", 1);
        cardAction.put("url",  odsUrl + "/#/supply-manager/subsidiary/customer-manage/enquiry?key=" + URLUtil.encode(inquiryCode));
        templateCard.put("card_action", cardAction);
        qywxParam.put("template_card", templateCard);
        triggerMsgRequest.setQywxParam(qywxParam);

        //短信
        JSONObject smsParam = new JSONObject();
        smsParam.put("code", inquiryCode);
        smsParam.put("phones", inquiryOrderMapper.selectPhoneBySupplier());
        triggerMsgRequest.setSmsParam(smsParam);
        msgClient.triggerMsg(triggerMsgRequest);
        return inquiryOrder.getId();
    }

    @Override
    public Page<InquiryOrder> page(InquiryOrderPageDTO inquiryOrderPageDTO) {
        inquiryOrderPageDTO.setCustId(Integer.valueOf(commonService.loginId()));
        return inquiryOrderMapper.page(inquiryOrderPageDTO, inquiryOrderPageDTO.buildPage());
    }

    @Override
    public Boolean cancel(InquiryOrderCancelDTO inquiryOrderCancelDTO) {
        InquiryOrder inquiryOrder = getById(inquiryOrderCancelDTO.getInquiryOrderId());
        if (inquiryOrder == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }
        if (inquiryOrder.getCustId().intValue() != Integer.parseInt(commonService.loginId())){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EQUALS_ORDER_AND_USER);
        }
        UpdateWrapper<InquiryOrder> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", inquiryOrder.getId())
                .set(inquiryOrderCancelDTO.getDelete(), "deleted", 1)
                .set("state", OrderConstants.InquiryState.VOIDED.code)
                .set(StringUtils.isNotEmpty(inquiryOrderCancelDTO.getReason()), "reason", inquiryOrderCancelDTO.getReason())
                .set("remark", "客户 取消订单" + (inquiryOrderCancelDTO.getDelete() ? "并标记删除订单" : ""))
                .set("updated_by", commonService.loginId())
                .set("updated_at", LocalDateTime.now());
        return this.update(updateWrapper);
    }

    @Override
    public Boolean delete(InquiryOrderDeleteDTO inquiryOrderDeleteDTO) {
        InquiryOrder inquiryOrder = getById(inquiryOrderDeleteDTO.getInquiryOrderId());
        if (inquiryOrder == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }
        if (inquiryOrder.getCustId().intValue() != Integer.parseInt(commonService.loginId())){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EQUALS_ORDER_AND_USER);
        }
        if (inquiryOrder.getState().intValue() != OrderConstants.InquiryState.VOIDED.code){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_VOIDED_STATE);
        }
        UpdateWrapper<InquiryOrder> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", inquiryOrder.getId())
                .set("deleted", 1)
                .set("remark", "客户 标记删除订单")
                .set("updated_by", commonService.loginId())
                .set("updated_at", LocalDateTime.now());
        return this.update(updateWrapper);
    }

    @Override
    public Boolean adminCancel(InquiryOrderCancelDTO inquiryOrderCancelDTO) {
        InquiryOrder inquiryOrder = getById(inquiryOrderCancelDTO.getInquiryOrderId());
        if (inquiryOrder == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }
        UpdateWrapper<InquiryOrder> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", inquiryOrder.getId())
                .set(inquiryOrderCancelDTO.getDelete(), "deleted", 1)
                .set("state", OrderConstants.InquiryState.VOIDED.code)
                .set(StringUtils.isNotEmpty(inquiryOrderCancelDTO.getReason()), "reason", inquiryOrderCancelDTO.getReason())
                .set("remark", "运营后台 取消订单" + (inquiryOrderCancelDTO.getDelete() ? "并标记删除订单" : ""))
                .set("updated_by", commonService.getUserId())
                .set("updated_at", LocalDateTime.now());
        return this.update(updateWrapper);
    }

    @Override
    public Boolean adminDelete(InquiryOrderDeleteDTO inquiryOrderDeleteDTO) {
        InquiryOrder inquiryOrder = getById(inquiryOrderDeleteDTO.getInquiryOrderId());
        if (inquiryOrder == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }
        if (inquiryOrder.getState().intValue() != OrderConstants.InquiryState.VOIDED.code){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_VOIDED_STATE);
        }
        UpdateWrapper<InquiryOrder> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", inquiryOrder.getId())
                .set("deleted", 1)
                .set("remark", "运营后台 标记删除订单")
                .set("updated_by", commonService.getUserId())
                .set("updated_at", LocalDateTime.now());
        return this.update(updateWrapper);
    }

    @Override
    public Page<InquiryOrder> pageByAdmin(InquiryOrderPageDTO inquiryOrderPageDTO) {
        return inquiryOrderMapper.pageAdmin(inquiryOrderPageDTO, inquiryOrderPageDTO.buildPage());
    }

    @Override
    public Page<InquiryOrder> pageBySupplier(InquiryOrderPageDTO inquiryOrderPageDTO) {
        inquiryOrderPageDTO.setSupplierId(commonService.getSupplierId());
        Page<InquiryOrder> inquiryOrderPage = inquiryOrderMapper.pageSupplier(inquiryOrderPageDTO, inquiryOrderPageDTO.buildPage());
        if (StringUtils.equals(inquiryOrderPageDTO.getTabState(), OrderConstants.SupplierInquiryTabState.PENDING.code)){
            List<InquiryOrder> records = inquiryOrderPage.getRecords();
            for (InquiryOrder i : records) {
                i.setQuoteItems(0);
                i.setQuoteTime(null);
            }
            return inquiryOrderPage;
        }else if (StringUtils.equals(inquiryOrderPageDTO.getTabState(), OrderConstants.SupplierInquiryTabState.QUOTED.code)){
            return inquiryOrderPage;
        }else {
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_TAB);
        }
    }

    @Override
    public Page<InquiryOrder> pageByLyh(InquiryOrderMallPageDTO inquiryOrderPageDTO) {
        if (StringUtils.equals(inquiryOrderPageDTO.getTabState(), "1")){
            //未参与
            if (StpUtil.isLogin()){
                JSONObject jsonObject = StpUtil.getSession().getModel(UserSession.INFO,JSONObject.class);
                String supplierId = jsonObject.getString("supplierId");
                inquiryOrderPageDTO.setSupplierId(supplierId);
            }
        }
        if (StringUtils.equals(inquiryOrderPageDTO.getTabState(), "2") || StringUtils.equals(inquiryOrderPageDTO.getTabState(), "3")){
            //已参与要校验登录
            if (StpUtil.isLogin()){
                JSONObject jsonObject = StpUtil.getSession().getModel(UserSession.INFO,JSONObject.class);
                String supplierId = jsonObject.getString("supplierId");
                if (StringUtils.isNotEmpty(supplierId)){
                    inquiryOrderPageDTO.setSupplierId(supplierId);
                }else {
                    return new Page<InquiryOrder>();
                }
            }else {
                return new Page<InquiryOrder>();
            }
        }
        Page<InquiryOrder> inquiryOrderPage = inquiryOrderMapper.pageLyh(inquiryOrderPageDTO, inquiryOrderPageDTO.buildPage());
        return inquiryOrderPage;
    }

    @Override
    public InquiryOrderAndQuotesVO queryQuote(Integer inquiryOrderDetailsId) {
        InquiryOrderDetails inquiryOrderDetails = inquiryOrderDetailsMapper.selectById(inquiryOrderDetailsId);
        if (inquiryOrderDetails == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_DETAILS_ORDER);
        }
        List<SupplierQuote> supplierQuotes = supplierQuoteMapper.selectByInquiryOrderDetailsId(inquiryOrderDetailsId);
        InquiryOrderAndQuotesVO inquiryOrderAndQuotesVO = new InquiryOrderAndQuotesVO();
        BeanUtil.copyProperties(inquiryOrderDetails, inquiryOrderAndQuotesVO);
        if (!CollectionUtils.isEmpty(supplierQuotes)){
            List<SupplierQuote> supplierQuoteWithSelecteds = BeanUtil.copyToList(supplierQuotes, SupplierQuote.class);
            for (SupplierQuote supplierQuote : supplierQuoteWithSelecteds) {
                if (StringUtils.equals(supplierQuote.getSupplierId(), inquiryOrderDetails.getSupplierId())){
                    supplierQuote.setConfirmed(true);
                }
            }
            inquiryOrderAndQuotesVO.setSupplierQuotes(supplierQuoteWithSelecteds);
        }
        return inquiryOrderAndQuotesVO;
    }

    @Override
    public List<InquiryOrderTabVO> countTab(InquiryOrderPageDTO inquiryOrderPageDTO) {
        List<InquiryOrderTabVO> inquiryOrderTabVOS = new ArrayList<>();
        inquiryOrderPageDTO.setCustId(Integer.valueOf(commonService.loginId()));
        inquiryOrderPageDTO.setTabState(OrderConstants.MallInquiryState.PENDING.code);
        InquiryOrderTabVO pending = new InquiryOrderTabVO();
        pending.setTab(OrderConstants.AdminInquiryTabState.PENDING.code);
        pending.setCount(inquiryOrderMapper.count(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(pending);

        inquiryOrderPageDTO.setTabState(OrderConstants.MallInquiryState.QUOTED_CONFIRMED.code);
        InquiryOrderTabVO quoted = new InquiryOrderTabVO();
        quoted.setTab(OrderConstants.MallInquiryState.QUOTED_CONFIRMED.code);
        quoted.setCount(inquiryOrderMapper.count(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(quoted);

        inquiryOrderPageDTO.setTabState(OrderConstants.MallInquiryState.ACCEPTED.code);
        InquiryOrderTabVO accepted = new InquiryOrderTabVO();
        accepted.setTab(OrderConstants.MallInquiryState.ACCEPTED.code);
        accepted.setCount(inquiryOrderMapper.count(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(accepted);

        inquiryOrderPageDTO.setTabState(OrderConstants.MallInquiryState.VOIDED.code);
        InquiryOrderTabVO voided = new InquiryOrderTabVO();
        voided.setTab(OrderConstants.MallInquiryState.VOIDED.code);
        voided.setCount(inquiryOrderMapper.count(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(voided);

        return inquiryOrderTabVOS;
    }

    @Override
    public List<InquiryOrderTabVO> adminCountTab(InquiryOrderPageDTO inquiryOrderPageDTO) {
        List<InquiryOrderTabVO> inquiryOrderTabVOS = new ArrayList<>();
        inquiryOrderPageDTO.setSupplierId(commonService.getSupplierId());
        inquiryOrderPageDTO.setTabState(OrderConstants.AdminInquiryTabState.PENDING.code);
        InquiryOrderTabVO pending = new InquiryOrderTabVO();
        pending.setTab(OrderConstants.AdminInquiryTabState.PENDING.code);
        pending.setCount(inquiryOrderMapper.countAdmin(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(pending);

        inquiryOrderPageDTO.setTabState(OrderConstants.AdminInquiryTabState.QUOTED_NO_CONFIRMED.code);
        InquiryOrderTabVO quotedNoConfirmed = new InquiryOrderTabVO();
        quotedNoConfirmed.setTab(OrderConstants.AdminInquiryTabState.QUOTED_NO_CONFIRMED.code);
        quotedNoConfirmed.setCount(inquiryOrderMapper.countAdmin(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(quotedNoConfirmed);

        inquiryOrderPageDTO.setTabState(OrderConstants.AdminInquiryTabState.QUOTED_CONFIRMED.code);
        InquiryOrderTabVO quotedConfirmed = new InquiryOrderTabVO();
        quotedConfirmed.setTab(OrderConstants.AdminInquiryTabState.QUOTED_CONFIRMED.code);
        quotedConfirmed.setCount(inquiryOrderMapper.countAdmin(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(quotedConfirmed);

        inquiryOrderPageDTO.setTabState(OrderConstants.AdminInquiryTabState.ACCEPTED.code);
        InquiryOrderTabVO accepted = new InquiryOrderTabVO();
        accepted.setTab(OrderConstants.AdminInquiryTabState.ACCEPTED.code);
        accepted.setCount(inquiryOrderMapper.countAdmin(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(accepted);

        inquiryOrderPageDTO.setTabState(OrderConstants.AdminInquiryTabState.VOIDED.code);
        InquiryOrderTabVO voided = new InquiryOrderTabVO();
        voided.setTab(OrderConstants.AdminInquiryTabState.VOIDED.code);
        voided.setCount(inquiryOrderMapper.countAdmin(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(voided);

        inquiryOrderPageDTO.setTabState(null);
        InquiryOrderTabVO all = new InquiryOrderTabVO();
        all.setTab(OrderConstants.AdminInquiryTabState.ALL.code);
        all.setCount(inquiryOrderMapper.countAdmin(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(all);


        return inquiryOrderTabVOS;
    }

    @Override
    public List<InquiryOrderTabVO> supplierCountTab(InquiryOrderPageDTO inquiryOrderPageDTO) {
        List<InquiryOrderTabVO> inquiryOrderTabVOS = new ArrayList<>();

        inquiryOrderPageDTO.setTabState(OrderConstants.SupplierInquiryTabState.PENDING.code);
        inquiryOrderPageDTO.setSupplierId(commonService.getSupplierId());
        InquiryOrderTabVO pending = new InquiryOrderTabVO();
        pending.setTab(OrderConstants.SupplierInquiryTabState.PENDING.code);
        pending.setCount(inquiryOrderMapper.countSupplier(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(pending);

        inquiryOrderPageDTO.setTabState(OrderConstants.SupplierInquiryTabState.QUOTED.code);
        InquiryOrderTabVO quoted = new InquiryOrderTabVO();
        quoted.setTab(OrderConstants.SupplierInquiryTabState.QUOTED.code);
        quoted.setCount(inquiryOrderMapper.countSupplier(inquiryOrderPageDTO));
        inquiryOrderTabVOS.add(quoted);

        return inquiryOrderTabVOS;
    }

    @Override
    public InquiryOrder queryById(Integer inquiryOrderId) {
        return inquiryOrderMapper.selectByInquiryOrderId(inquiryOrderId);
    }

    @Override
    public ProductAnalysVO productAnalys(Integer inquiryId) {

        InquiryOrderDetails inquiryOrderDetails = inquiryOrderDetailsMapper.selectById(inquiryId);
        if (inquiryOrderDetails == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }

        //查询是否存在惠采临时商品
        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("brand_name", inquiryOrderDetails.getBrandName());
        queryWrapper.eq("product_type", inquiryOrderDetails.getProductType());
        Product productQuery = productMapper.selectOne(queryWrapper);
        if (productQuery == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_PURCHASE_PRODUCT);
        }
        ProductAnalysVO productAnalysVO = new ProductAnalysVO();
        BeanUtil.copyProperties(productQuery, productAnalysVO);

        BigDecimal avgQuotePrice = new BigDecimal(0);
        BigDecimal subTotal = new BigDecimal(0);
        int allNum = 0;

        QueryWrapper<OrderDetails> orderDetailsQueryWrapper = new QueryWrapper<>();
        orderDetailsQueryWrapper.eq("brand_name", inquiryOrderDetails.getBrandName());
        orderDetailsQueryWrapper.eq("product_type", inquiryOrderDetails.getProductType());
        List<OrderDetails> orderDetails = orderDetailsMapper.selectList(orderDetailsQueryWrapper);

        if (CollectionUtils.isEmpty(orderDetails)){
            productAnalysVO.setAvgQuotePrice(avgQuotePrice);
            productAnalysVO.setSubTotal(subTotal);
            productAnalysVO.setAllNum(allNum);
        }else {
            BigDecimal quotePrice = new BigDecimal(0);
            for (OrderDetails o : orderDetails) {
                allNum += o.getNumber();
                subTotal = subTotal.add(o.getTotalAmount());
                quotePrice = quotePrice.add(o.getPurchaseAmount());
            }
            productAnalysVO.setAvgQuotePrice(quotePrice.divide(new BigDecimal(orderDetails.size()), 2, RoundingMode.DOWN));
            productAnalysVO.setSubTotal(subTotal);
            productAnalysVO.setAllNum(allNum);
            productAnalysVO.setOrderDetails(orderDetails);
        }
        return productAnalysVO;
    }

    @Override
    public InquiryOrder mallQuery(Integer inquiryId) {
        InquiryOrder inquiryOrder = this.getById(inquiryId);
        if (inquiryOrder == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }
        if (StpUtil.isLogin()){
            JSONObject jsonObject = StpUtil.getSession().getModel(UserSession.INFO,JSONObject.class);
            String supplierId = jsonObject.getString("supplierId");
            QueryWrapper<SupplierQuote> quoteQueryWrapper = new QueryWrapper<>();
            quoteQueryWrapper.eq("supplier_id", supplierId);
            quoteQueryWrapper.eq("inquiry_order_state", "1");
            quoteQueryWrapper.eq("inquiry_order_id", inquiryOrder.getId());
            List<SupplierQuote> supplierQuotes = supplierQuoteMapper.selectList(quoteQueryWrapper);
            if (CollectionUtils.isEmpty(supplierQuotes)){
                //说明没有报价
                if (inquiryOrder.getInquiryExpireTime() == null || inquiryOrder.getInquiryExpireTime().isAfter(LocalDateTime.now())){
                    if (inquiryOrder.getConfirmState().intValue() == 0){
                        inquiryOrder.setShow(true);
                    }
                }
            }
        }else {
            if (inquiryOrder.getState() != null && inquiryOrder.getConfirmState() != null &&
                    ((inquiryOrder.getState().intValue() == 0 && inquiryOrder.getConfirmState().intValue() == 0) || (inquiryOrder.getState().intValue() == 1 && inquiryOrder.getConfirmState().intValue() == 0))){
                inquiryOrder.setShow(true);
            }
        }
        return inquiryOrder;
    }

}
