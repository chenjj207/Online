package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.InquiryOrder;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.InquiryOrderAndQuotesVO;
import com.purchase.service.vo.InquiryOrderTabVO;
import com.purchase.service.vo.ProductAnalysVO;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 惠采商品询价单 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-08-31
 */
public interface InquiryOrderService extends IService<InquiryOrder> {
    public Integer add(InquiryOrderAddDTO inquiryOrderAddDTO);

    public Page<InquiryOrder> page(InquiryOrderPageDTO inquiryOrderPageDTO);

    public Boolean cancel(InquiryOrderCancelDTO inquiryOrderCancelDTO);

    public Boolean delete(InquiryOrderDeleteDTO inquiryOrderDeleteDTO);

    public Boolean adminCancel(InquiryOrderCancelDTO inquiryOrderCancelDTO);

    public Boolean adminDelete(InquiryOrderDeleteDTO inquiryOrderDeleteDTO);

    public Page<InquiryOrder> pageByAdmin(InquiryOrderPageDTO inquiryOrderPageDTO);

    public Page<InquiryOrder> pageBySupplier(InquiryOrderPageDTO inquiryOrderPageDTO);

    public Page<InquiryOrder> pageByLyh(InquiryOrderMallPageDTO inquiryOrderMallPageDTO);

    public InquiryOrderAndQuotesVO queryQuote(Integer inquiryOrderDetailsId);

    public List<InquiryOrderTabVO> countTab(InquiryOrderPageDTO inquiryOrderPageDTO);

    public List<InquiryOrderTabVO> adminCountTab(InquiryOrderPageDTO inquiryOrderPageDTO);

    public List<InquiryOrderTabVO> supplierCountTab(InquiryOrderPageDTO inquiryOrderPageDTO);

    public InquiryOrder queryById(Integer inquiryOrderId);

    public ProductAnalysVO productAnalys(Integer inquiryId);

    public InquiryOrder mallQuery(Integer inquiryId);
}
