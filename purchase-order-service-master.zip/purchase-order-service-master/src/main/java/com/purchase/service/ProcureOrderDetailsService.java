package com.purchase.service;

import com.purchase.entity.ProcureOrderDetails;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 采购订单详情表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
public interface ProcureOrderDetailsService extends IService<ProcureOrderDetails> {

}
