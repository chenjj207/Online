package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/12/19  15:29
 */
@Data
public class CancelOrderDTO {

    @Schema(description = "订单id")
    @NotNull(message = "订单id不能为空")
    private Integer id;

    @Schema(description = "作废原因")
    private String reason;

}
