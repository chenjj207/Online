package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 订单新增实体
 * @date 2023/9/6  9:47
 */
@Data
public class OrderAddDTO {
    @Schema(description = "合计 需求数量")
    @NotNull(message = "合计需求数量不能为空")
    private Integer allNum;

    @Schema(description = "合计")
    @NotNull(message = "合计不能为空")
    private BigDecimal allSubtotal;

    @Schema(description = "合计库存")
    @NotNull(message = "合计库存不能为空")
    private Integer allStock;

    @Schema(description = "询价单id")
    private Integer inquiryOrderId;

    @Schema(description = "询价详情产品id列表")
    private List<String> inquiryOrderDetailsIds;

    @Schema(description = "商品列表")
    private List<ProductInqueryDTO> productInqueryDTOS;

    @Schema(description = "下单页面  1：采购清单  2：我的询价")
    @NotEmpty(message = "下单页面必填")
    private String tab;

    @Schema(description = "订单备注")
    private String remark;

    @Schema(description = "支付方式（1=公对公转账，2=银联，3=微信，4=支付宝，5=在线支付）")
    @NotNull(message = "支付方式不能为空")
    private Integer payType;

    @Schema(description = "收货地址")
    @NotNull(message = "收货地址不能为空")
    private String receivingAddr;

    @Schema(description = "收件人")
    @NotNull(message = "收件人不能为空")
    private String receivingMan;

    @Schema(description = "收件人联系方式")
    @NotNull(message = "收件人联系方式不能为空")
    private String receivingPhone;

    @Schema(description = "收件人邮编")
    private String receivingZipcode;
}
