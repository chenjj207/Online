package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 提交比价
 * @date 2023/9/7  16:01
 */
@Data
public class ConfirmQuoteAddDTO {

    @Schema(description = "询价产品单id")
    @NotBlank(message = "询价产品单id不能为空")
    private Integer inquiryOrderId;

    @Schema(description = "货期")
    @NotEmpty(message = "货期不能为空")
    private String deliveryDate;

    @Schema(description = "报价有效期")
    @NotNull(message = "报价有效期天数不能为空")
    private Integer day;

    @Schema(description = "供应商比价产品信息")
    private List<InquiryDetailAndSupplierQuoteDTO> inquiryDetailAndSupplierQuoteDTOS;

    @Schema(description = "要清空的详情产品信息")
    private List<Integer> inquiryOrderDetails;

}
