package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;


/**
 * @author jidonglin
 * @Description: 询价单取消并删除
 * @date 2023/12/11  9:47
 */
@Data
public class InquiryOrderCancelDTO{

    @Schema(description = "询价单id")
    @NotEmpty(message = "询价单id不能为空")
    private String inquiryOrderId;

    @Schema(description = "是否删除")
    private Boolean delete;

    @Schema(description = "取消订单原因")
    private String reason;

}
