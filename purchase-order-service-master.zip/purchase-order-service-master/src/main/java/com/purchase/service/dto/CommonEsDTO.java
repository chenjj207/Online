package com.purchase.service.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
* <p>
* 公海es字段数据
* </p>
*
* @author jidonglin
* @since 2023-04-19
*/
@Data
@TableName("t_pd_common_es")
@Schema(title = "公海es字段数据")
public class CommonEsDTO {

    private static final long serialVersionUID = 1L;


    @Schema(description = "产品id")
    @TableId("product_id")
    private Long productId;

    @Schema(description = "erp产品id")
    @TableField("erp_product_id")
    private Long erpProductId;

    @Schema(description = "是否上架")
    @TableField("is_onsale")
    private String isOnsale;

    @Schema(description = "产品货号")
    @TableField("sku_code")
    private String skuCode;

    @Schema(description = "产品型号")
    @TableField("product_type")
    private String productType;

    @Schema(description = "产品来源")
    @TableField("product_src")
    private String productSrc;

    @Schema(description = "产品图名称")
    @TableField("product_pic_name")
    private String productPicName;

    @Schema(description = "系列名称")
    @TableField("prop_name")
    private String propName;

    @Schema(description = "分类名称")
    @TableField("cata_name")
    private String cataName;

    @Schema(description = "三级分类名称")
    @TableField("three_cata_name")
    private String threeCataName;

    @Schema(description = "分类排序")
    @TableField("cata_order")
    private BigDecimal cataOrder;

    @Schema(description = "品牌id")
    @TableField("brand_id")
    private Long brandId;

    @Schema(description = "品牌排序")
    @TableField("brand_order")
    private Integer brandOrder;

    @Schema(description = "品牌名称")
    @TableField("brand_name")
    private String brandName;

    @Schema(description = "搜索集")
    @TableField("searchset")
    private String searchset;

    @Schema(description = "规格参数")
    @TableField("spec_vals")
    private String specVals;

    @Schema(description = "规格值:规格参数")
    @TableField("specs")
    private String specs;

    @Schema(description = "价格")
    @TableField("price")
    private BigDecimal price;

    @Schema(description = "慧采价格")
    @TableField("purchase_price")
    private BigDecimal purchasePrice;

    @Schema(description = "库存")
    @TableField("stock")
    private Long stock;

    @Schema(description = "规格值:规格参数，三个空格")
    @TableField("specsArr")
    private String specsArr;

    @Schema(description = "规格值:规格参数，@@@@【四个@】")
    @TableField("specsArr1")
    private String specsArr1;

    @Schema(description = "默认common")
    @TableField("tenant_product_src")
    private String tenantProductSrc;

    @Schema(description = "分类是否展示系列")
    @TableField("isCataShowProp")
    private String isCataShowProp;

    @Schema(description = "主采购组")
    @TableField("ifs_main_procurement")
    private String ifsMainProcurement;

    @Schema(description = "店铺id")
    @TableField("store_id")
    private int storeId;

    @Schema(description = "店铺类型")
    @TableField("store_type")
    private int storeType;

    @Schema(description = "店铺名")
    @TableField("store_name")
    private String storeName;

    @Schema(description = "货期")
    @TableField("delivery_date")
    private String deliveryDate;

    @Schema(description = "单位")
    @TableField("unit")
    private String unit;

    @TableField("created_at")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    private LocalDateTime createdAt;
}
