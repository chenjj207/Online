package com.purchase.service.vo;

import lombok.Data;

/**
 * @author jidonglin
 * @Description: 采购订单列表统计
 * @date 2024/01/02  13:55
 */
@Data
public class ProcureOrderTabVO {
    private Integer tab;
    private int count;
}
