package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/12/19  15:29
 */
@Data
public class ConfirmOrderDTO {

    @Schema(description = "收货地址")
    @NotNull(message = "收货地址不能为空")
    private String receivingAddr;

    @Schema(description = "收件人")
    @NotNull(message = "收件人不能为空")
    private String receivingMan;

    @Schema(description = "收件人联系方式")
    @NotNull(message = "收件人联系方式不能为空")
    private String receivingPhone;

    @Schema(description = "收件人邮编")
    private String receivingZipcode;

    @Schema(description = "订单详情列表")
    @NotEmpty(message = "订单详情列表不能为空")
    private List<Integer> ids;
}
