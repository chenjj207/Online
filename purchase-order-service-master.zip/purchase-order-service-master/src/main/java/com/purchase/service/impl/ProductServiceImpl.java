package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.metadata.fill.FillConfig;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.PutObjectRequest;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.client.AliOcrClient;
import com.purchase.client.dto.AliOcrDTO;
import com.purchase.client.dto.Configure;
import com.purchase.common.OrderConstants;
import com.purchase.config.OssConf;
import com.purchase.config.PurchaseOrderExceptionDesc;
import com.purchase.entity.InquiryOrder;
import com.purchase.entity.InquiryOrderDetails;
import com.purchase.entity.Product;
import com.purchase.entity.SupplierQuote;
import com.purchase.mapper.InquiryOrderDetailsMapper;
import com.purchase.mapper.InquiryOrderMapper;
import com.purchase.mapper.ProductMapper;
import com.purchase.mapper.SupplierQuoteMapper;
import com.purchase.service.CommonService;
import com.purchase.service.ProductService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.*;
import com.purchase.service.vo.NeedExportVO;
import com.purchase.service.vo.ParseResultVO;
import com.purchase.service.vo.ProductPageVO;
import com.purchase.service.vo.ProductVO;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.collections4.map.LinkedMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Consumer;

/**
 * <p>
 * 惠采商品列表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-08-31
 */
@Service
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements ProductService {

    @Autowired
    OssConf ossConfig;
    @Autowired
    CommonService commonService;
    @Resource
    ProductMapper productMapper;
    @Resource
    InquiryOrderMapper inquiryOrderMapper;
    @Resource
    InquiryOrderDetailsMapper inquiryOrderDetailsMapper;
    @Resource
    SupplierQuoteMapper supplierQuoteMapper;
    @Resource
    AliOcrClient aliOcrClient;
    @Override
    public NeedExportVO needExport(MultipartFile multipartFile) {
        double fileSize = (double) multipartFile.getSize() / 1048576;
        if (fileSize > 10){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_EXCEL_SIZE);
        }
        String excelFileName = multipartFile.getOriginalFilename();
        if (!StrUtil.endWith(excelFileName, ".xlsx") && !StrUtil.endWith(excelFileName, ".xls")) {
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_EXCEL_TYPE);
        }
        InputStream excelInputStream = null;
        List<Map<String, Object>> readAll = null;
        try {
            excelInputStream = multipartFile.getInputStream();
            ExcelReader reader = ExcelUtil.getReader(excelInputStream);
            readAll = reader.readAll();
        } catch (IOException e) {
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_IO);
        }catch (Exception e){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_EXCEL_TYPE);
        }


        if (CollectionUtils.isEmpty(readAll)){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_EXCEL_EXPORT);
        }
        String[] header = {"我的编码","物料名称", "品牌", "规格型号", "单位", "需求数量", "备注"};
        for (String headerText : header) {
            if (!readAll.get(0).containsKey(headerText)) {
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_EXCEL_EXPORT);
            }
        }
        if (readAll.size() > 801) {
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_EXCEL_NUM);
        }
        if (readAll.size() == 0 || readAll.size() == 1) {
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_EXCEL_EMPTY);
        }
        boolean isError = false;
        List<ProductVO> productVOS = new ArrayList<>();
        for (int i = 1; i < readAll.size(); i++) {
            StringBuilder error = new StringBuilder();
            Map<String, Object> lineMap = readAll.get(i);
            String productCode =  lineMap.get("我的编码") == null ? "" : lineMap.get("我的编码").toString();
            String productName = lineMap.get("物料名称") == null ? "" : lineMap.get("物料名称").toString();
            String brandName = lineMap.get("品牌") == null ? "" : lineMap.get("品牌").toString();
            String productType = lineMap.get("规格型号") == null ? "" : lineMap.get("规格型号").toString();
            String unit = lineMap.get("单位") == null ? "" : lineMap.get("单位").toString();

            if (StringUtils.isEmpty(productName) && StringUtils.isEmpty(brandName) && StringUtils.isEmpty(productType)){
                error.append("物料名称/品牌/规格型号必填任意一项；");
            }

            int num = 0;
            try {
                Object ob = lineMap.get("需求数量");
                if (ob == null || StringUtils.isEmpty(ob.toString())){
                    num = 1;
                }else {
                    Long numExcel = (Long) lineMap.get("需求数量");
                    if (numExcel.intValue() == 0){
                        error.append("需求数量填写错误；");
                    }else {
                        num = numExcel.intValue();
                    }
                }
            }catch (Exception e){
                error.append("需求数量填写错误；");
            }

            String remark = (String) lineMap.get("备注");

            if (StringUtils.isNotEmpty(error.toString())){
                isError = true;
            }
            ProductVO productVO = new ProductVO();
            productVO.setProductCode(productCode);
            productVO.setProductName(productName);
            productVO.setBrandName(brandName);
            productVO.setProductType(productType);
            productVO.setUnit(unit);
            productVO.setNum(num);
            productVO.setRemark(remark);
            productVO.setError(error.toString());
            productVOS.add(productVO);
        }
        NeedExportVO needExportVO = new NeedExportVO();
        if (isError){
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            ClassPathResource resource = new ClassPathResource("template/needProductResult.xlsx");
            XSSFWorkbook workbook = null;
            try {
                InputStream is = resource.getInputStream();
                workbook = new XSSFWorkbook(is);
                XSSFSheet sheet = workbook.getSheetAt(0);
                for (int i = 0; i < productVOS.size(); i++) {
                    int j = 2 + i;
                    Row row = sheet.getRow(j);
                    Cell productCodeCell = row.getCell(0);
                    productCodeCell.setCellValue(productVOS.get(i).getProductCode());

                    Cell productNameCell = row.getCell(1);
                    productNameCell.setCellValue(productVOS.get(i).getProductName());

                    Cell brandNameCell = row.getCell(2);
                    brandNameCell.setCellValue(productVOS.get(i).getBrandName());

                    Cell productTypeCell = row.getCell(3);
                    productTypeCell.setCellValue(productVOS.get(i).getProductType());

                    Cell unitCell = row.getCell(4);
                    unitCell.setCellValue(productVOS.get(i).getUnit());

                    Cell remarkCell = row.getCell(5);
                    remarkCell.setCellValue(productVOS.get(i).getRemark());

                    Cell numCell = row.getCell(6);
                    numCell.setCellValue(productVOS.get(i).getNum());

                    Cell errorCell = row.getCell(7);
                    errorCell.setCellValue(productVOS.get(i).getError());
                }

                workbook.write(byteArrayOutputStream);
                ByteArrayInputStream byteArrayInput = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                //同步到oss
                String loginId = "0";
                try {
                    loginId = commonService.loginId();
                }catch (Exception e){
                    //忽略获取不到客户id的异常，未登录用户
                }
                String targetUrl = "purchase/custinquery/" + loginId + ossConfig.getTmp() + "上传需求清单导入结果.xlsx";
                OSS ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
                ossClient.putObject(new PutObjectRequest(ossConfig.getBucketName(), targetUrl, byteArrayInput));
                needExportVO.setParse(false);
                needExportVO.setErrUrl(ossConfig.getOssUrl() + targetUrl);
                return needExportVO;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        needExportVO.setParse(true);
        needExportVO.setProductVOS(productVOS);
        return needExportVO;
    }

    @Override
    public ParseResultVO ocrExport(MultipartFile multipartFile) {
        String base64EncoderImg = "";
        byte[] buffer = null;
        try {
            InputStream inputStream = multipartFile.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[1024];
            int n;
            while ((n = inputStream.read(b)) != -1)
            {
                bos.write(b, 0, n);
            }
            inputStream.close();
            bos.close();
            buffer = bos.toByteArray();
            base64EncoderImg = Base64.getEncoder().encodeToString(buffer);
            base64EncoderImg = "data:image/png;base64," + base64EncoderImg;
            AliOcrDTO aliOcrDTO = new AliOcrDTO();
            aliOcrDTO.setImage(base64EncoderImg);
            Configure configure = new Configure();
            configure.setMin_size(16);
            configure.setOutput_prob(true);
            configure.setOutput_keypoints(false);
            configure.setSkip_detection(true);
            configure.setDir_assure(false);
            configure.setLanguage("sx");
            JSONObject response = aliOcrClient.ocr("APPCODE e439d77900664e37896e0fd71f75f644", aliOcrDTO);
            boolean success = response.getBoolean("success");
            if (!success){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_OCR);
            }
            JSONArray ret = response.getJSONArray("ret");
            if (ret == null){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_OCR_WORD);
            }
            StringBuffer text = new StringBuffer();
            for (int i = 0; i < ret.size(); i++) {
                JSONObject jsonObject = (JSONObject) ret.get(i);
                text.append(jsonObject.getString("word"));
                text.append("\n");
            }
            ProductBatchDTO productBatchDTO = new ProductBatchDTO();
            productBatchDTO.setText(text.toString());
            return textParse(productBatchDTO);
        } catch (IOException e) {
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_IO);
        }
    }

    @Override
    public ParseResultVO textParse(ProductBatchDTO productBatchDTO) {
        String text = productBatchDTO.getText();
        //去掉特殊符号
        text = text.replace("'", "").replace("\"", "")
                .replace("‘", "").replace("“", "").replace("”", "");
        //去掉连续多个空格，只保留1个空格
        String[] rows = text.replaceAll(" {2,}"," ").trim().split("\\r\\n|\\n|\\r|\\\\n");
        List<String> skuCodeOrType = new ArrayList<>();
        LinkedMap<String, Long> textMap = new LinkedMap<>();

        for(int i=0; i<rows.length; i++) {
            String rowText = rows[i];
            if (org.apache.commons.lang.StringUtils.isBlank(rowText)) {
                continue;
            }
            rowText = rowText.trim();
            if (org.apache.commons.lang.StringUtils.isBlank(rowText.trim())) {
                continue;
            }
            rowText = rowText.trim().replace("\t"," ");
            int splitIndex = rowText.trim().lastIndexOf(" ");
            long qty;
            String key;
            if (splitIndex != -1){
                key = rowText.substring(0, splitIndex).trim();
                try {
                    qty = Long.valueOf(rowText.substring(splitIndex).trim());
                }catch (Exception e){
                    key = rowText;
                    qty = 1;
                }
                if (qty<1){
                    throw BusinessException.newInstance(PurchaseOrderExceptionDesc.QYT_MORE_ONE);
                }
                if (qty > 99999){
                    throw BusinessException.newInstance(PurchaseOrderExceptionDesc.QYT_LESS);
                }
            }else{
                key = rowText;
                qty = 1;
            }
            key = key.trim();
            if(org.apache.commons.lang.StringUtils.isBlank(key)){
                continue;
            }
            skuCodeOrType.add(key);
            textMap.put(key, qty);
        }
        ParseResultVO parseResultVO = new ParseResultVO();
        if (CollectionUtils.isEmpty(skuCodeOrType)){
            return parseResultVO;
        }
        HashMap<String, List<CommonEsDTO>> hashMap = new HashMap<>();
        //按照慧采价格 正序排列
        List<CommonEsDTO> commonEsDTOS = productMapper.selectSkuOrProduct(skuCodeOrType);
        if (!CollectionUtils.isEmpty(commonEsDTOS)){
            for (CommonEsDTO c: commonEsDTOS) {
                if (StringUtils.equals(c.getSkuCode(), c.getProductType())){
                    if (hashMap.containsKey(c.getSkuCode())){
//                    List<CommonEsDTO> commonEsDTOS1 = hashMap.get(c.getSkuCode());
//                    commonEsDTOS1.add(c);
//                    hashMap.put(c.getSkuCode(), commonEsDTOS1);
                        //存在就跳过
                        continue;
                    }else {
                        List<CommonEsDTO> commonEsDTOS1 = new ArrayList<>();
                        commonEsDTOS1.add(c);
                        hashMap.put(c.getSkuCode(), commonEsDTOS1);
                    }
                    continue;
                }else {
                    if (StringUtils.isNotEmpty(c.getSkuCode())){
                        if (hashMap.containsKey(c.getSkuCode())){
//                        List<CommonEsDTO> commonEsDTOS1 = hashMap.get(c.getSkuCode());
//                        commonEsDTOS1.add(c);
//                        hashMap.put(c.getSkuCode(), commonEsDTOS1);
                            //存在就跳过
                            continue;
                        }else {
                            List<CommonEsDTO> commonEsDTOS1 = new ArrayList<>();
                            commonEsDTOS1.add(c);
                            hashMap.put(c.getSkuCode(), commonEsDTOS1);
                        }
                    }
                    if (StringUtils.isNotEmpty(c.getProductType())){
                        if (hashMap.containsKey(c.getProductType())){
//                        List<CommonEsDTO> commonEsDTOS1 = hashMap.get(c.getProductType());
//                        commonEsDTOS1.add(c);
//                        hashMap.put(c.getProductType(), commonEsDTOS1);
                            //存在就跳过
                            continue;
                        }else {
                            List<CommonEsDTO> commonEsDTOS1 = new ArrayList<>();
                            commonEsDTOS1.add(c);
                            hashMap.put(c.getProductType(), commonEsDTOS1);
                        }
                    }
                }
            }
        }
        List<RepeatConfirmDTO> repeatConfirmDTOList = new ArrayList<>();

        boolean isRepeat = false;
        int serialNum = 1;
        for (String key : textMap.keySet()) {
            List<ProductInqueryDTO> productInqueryDTOS = new ArrayList<>();

            List<CommonEsDTO> commonEsDTOS1 =  hashMap.get(key);
            if (!CollectionUtils.isEmpty(commonEsDTOS1)){
                //此版本commonEsDTOS1 不可能会大于1的情况，不会重复
                if (commonEsDTOS1.size() > 1){
                    isRepeat = true;
                }
                for (CommonEsDTO c : commonEsDTOS1) {
                    ProductInqueryDTO productInqueryDTO = new ProductInqueryDTO();
                    productInqueryDTO.setBrandName(c.getBrandName());
                    productInqueryDTO.setProductSku(c.getSkuCode());
                    productInqueryDTO.setProductType(c.getProductType());
                    productInqueryDTO.setProductName(c.getThreeCataName());
                    productInqueryDTO.setNum(textMap.get(key).intValue());
                    productInqueryDTO.setPrice(c.getPrice());
                    productInqueryDTO.setPurchasePrice(c.getPurchasePrice() != null ? c.getPurchasePrice().setScale(2, BigDecimal.ROUND_HALF_UP) : null);
                    productInqueryDTO.setStock(c.getStock());
                    productInqueryDTO.setProductId(String.valueOf(c.getProductId()));
                    productInqueryDTO.setDeliveryDate(c.getDeliveryDate());
                    productInqueryDTO.setUnit(c.getUnit());
                    BigDecimal num = new BigDecimal(textMap.get(key));
                    BigDecimal purchasePrice = productInqueryDTO.getPurchasePrice();
                    productInqueryDTO.setSubtotal(num.multiply(purchasePrice));
                    productInqueryDTOS.add(productInqueryDTO);
                }
            }else {
                ProductInqueryDTO productInqueryDTO = new ProductInqueryDTO();
                productInqueryDTO.setProductType(key);
                productInqueryDTO.setNum(textMap.get(key).intValue());
                productInqueryDTOS.add(productInqueryDTO);
            }

            RepeatConfirmDTO repeatConfirmDTO = new RepeatConfirmDTO();
            repeatConfirmDTO.setProductInqueryDTOS(productInqueryDTOS);
            repeatConfirmDTO.setSerialNum(serialNum);
            repeatConfirmDTO.setText(key);
            serialNum ++;

            repeatConfirmDTOList.add(repeatConfirmDTO);
        }

        parseResultVO.setRepeat(isRepeat);
        parseResultVO.setRepeatConfirmDTOList(repeatConfirmDTOList);

        return parseResultVO;
    }

    @Override
    public void export(QuotationExportDTO quotationExportDTO, HttpServletResponse response) {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        // 设置编码格式
        response.setCharacterEncoding("utf-8");
        // 设置URLEncoder.encode 防止中文乱码
        String fileName = null;
        try {
            if (StpUtil.isLogin()){
                JSONObject custInfo = commonService.getCustInfo();
                fileName = URLEncoder.encode("采购清单-" + custInfo.getString("company") + "-" + DateUtil.format(LocalDateTime.now(), DatePattern.PURE_DATETIME_PATTERN), "UTF-8").replaceAll("\\+", "%20");
            }else {
                fileName = URLEncoder.encode("采购清单-" + DateUtil.format(LocalDateTime.now(), DatePattern.PURE_DATETIME_PATTERN), "UTF-8").replaceAll("\\+", "%20");
            }
            // 设置响应头
            response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
            List<ProductInqueryDTO> productInqueryDTOS = quotationExportDTO.getProductInqueryDTOS();
            //excel表的位置
            ClassPathResource resource = new ClassPathResource("template/quotationOrder.xlsx");
            XSSFWorkbook wb = new XSSFWorkbook(resource.getInputStream());
            XSSFSheet sheet = wb.getSheetAt(0);

            if (StpUtil.isLogin()){
                JSONObject custInfo = commonService.getCustInfo();
                Row companyRow = sheet.getRow(1);
                Cell companyCell = companyRow.getCell(6);
                companyCell.setCellValue(custInfo.getString("company"));

                Row linkmanRow = sheet.getRow(2);
                Cell linkmanCell = linkmanRow.getCell(6);
                linkmanCell.setCellValue(custInfo.getString("linkman"));

                Row linkphoneRow = sheet.getRow(3);
                Cell linkphoneCell = linkphoneRow.getCell(6);
                linkphoneCell.setCellValue(custInfo.getString("linkphone"));

                Row addressRow = sheet.getRow(4);
                Cell addressCell = addressRow.getCell(6);
                addressCell.setCellValue(custInfo.getString("address"));
            }else {
                Row companyRow = sheet.getRow(1);
                Cell companyCell = companyRow.getCell(3);
                companyCell.setCellValue("");

                Row linkmanRow = sheet.getRow(2);
                Cell linkmanCell = linkmanRow.getCell(3);
                linkmanCell.setCellValue("");

                Row linkphoneRow = sheet.getRow(3);
                Cell linkphoneCell = linkphoneRow.getCell(3);
                linkphoneCell.setCellValue("");

                Row addressRow = sheet.getRow(3);
                Cell addressCell = addressRow.getCell(3);
                addressCell.setCellValue("");
            }
            XSSFCellStyle style = wb.createCellStyle();
            style.setBorderBottom(BorderStyle.THIN);
            style.setBorderTop(BorderStyle.THIN);
            style.setBorderLeft(BorderStyle.THIN);
            style.setBorderRight(BorderStyle.THIN);
            style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
            style.setTopBorderColor(IndexedColors.BLACK.getIndex());
            style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
            style.setRightBorderColor(IndexedColors.BLACK.getIndex());

            for (int i = 0; i <= productInqueryDTOS.size(); i++) {
                int j = 6 + i;
                Row row = sheet.createRow(j);
                Cell serialNumCell = row.createCell(0);
                if (i == productInqueryDTOS.size()){
                    serialNumCell.setCellValue("");
                }else {
                    serialNumCell.setCellValue(productInqueryDTOS.get(i).getSerialNum().toString());
                }
                serialNumCell.setCellStyle(style);

                Cell productCodeCell = row.createCell(1);
                if (i == productInqueryDTOS.size()){
                    productCodeCell.setCellValue("");
                }else {
                    productCodeCell.setCellValue(productInqueryDTOS.get(i).getProductCode() == null ? "" : productInqueryDTOS.get(i).getProductCode());
                }
                productCodeCell.setCellStyle(style);

                Cell productNameCell = row.createCell(2);
                if (i == productInqueryDTOS.size()){
                    productNameCell.setCellValue("");
                }else {
                    productNameCell.setCellValue(productInqueryDTOS.get(i).getProductName() == null ? "" : productInqueryDTOS.get(i).getProductName());
                }
                productNameCell.setCellStyle(style);

                Cell brandNameCell = row.createCell(3);
                if (i == productInqueryDTOS.size()){
                    brandNameCell.setCellValue("总计");
                }else {
                    brandNameCell.setCellValue(productInqueryDTOS.get(i).getBrandName() == null ? "" : productInqueryDTOS.get(i).getBrandName());
                }
                brandNameCell.setCellStyle(style);

                Cell productTypeCell = row.createCell(4);
                if (i == productInqueryDTOS.size()){
                    productTypeCell.setCellValue("");
                }else {
                    productTypeCell.setCellValue(productInqueryDTOS.get(i).getProductType() == null ? "" : productInqueryDTOS.get(i).getProductType());
                }
                productTypeCell.setCellStyle(style);

                Cell productSkuCell = row.createCell(5);
                if (i == productInqueryDTOS.size()){
                    productSkuCell.setCellValue("");
                }else {
                    productSkuCell.setCellValue(productInqueryDTOS.get(i).getProductSku() == null ? "" : productInqueryDTOS.get(i).getProductSku());
                }
                productSkuCell.setCellStyle(style);

                Cell unitCell = row.createCell(6);
                if (i == productInqueryDTOS.size()){
                    unitCell.setCellValue("");
                }else {
                    unitCell.setCellValue(productInqueryDTOS.get(i).getUnit() == null ? "" : productInqueryDTOS.get(i).getUnit());
                }
                unitCell.setCellStyle(style);

                Cell remarkCell = row.createCell(7);
                if (i == productInqueryDTOS.size()){
                    remarkCell.setCellValue("");
                }else {
                    remarkCell.setCellValue(productInqueryDTOS.get(i).getRemark() == null ? "0" : productInqueryDTOS.get(i).getRemark());
                }
                remarkCell.setCellStyle(style);

                Cell numCell = row.createCell(8);
                if (i == productInqueryDTOS.size()){
                    numCell.setCellValue(quotationExportDTO.getAllNum() == null ? "0" : quotationExportDTO.getAllNum().toString());
                }else {
                    numCell.setCellValue(productInqueryDTOS.get(i).getNum() == null ? "0" : productInqueryDTOS.get(i).getNum().toString());
                }
                numCell.setCellStyle(style);

                Cell stockCell = row.createCell(9);
                if (i == productInqueryDTOS.size()){
                    stockCell.setCellValue(quotationExportDTO.getAllStock() == null ? "0" : quotationExportDTO.getAllStock().toString());
                }else {
                    stockCell.setCellValue(productInqueryDTOS.get(i).getStock() == null ? "0" : productInqueryDTOS.get(i).getStock().toString());
                }
                stockCell.setCellStyle(style);

                Cell purchasePriceCell = row.createCell(10);
                if (i == productInqueryDTOS.size()){
                    purchasePriceCell.setCellValue("");
                }else {
                    purchasePriceCell.setCellValue(productInqueryDTOS.get(i).getPurchasePrice() == null ? "0" : productInqueryDTOS.get(i).getPurchasePrice().toString());
                }
                purchasePriceCell.setCellStyle(style);

                Cell deliveryDateCell = row.createCell(11);
                if (i == productInqueryDTOS.size()){
                    deliveryDateCell.setCellValue("");
                }else {
                    deliveryDateCell.setCellValue(productInqueryDTOS.get(i).getDeliveryDate() == null ? "" : productInqueryDTOS.get(i).getDeliveryDate());
                }

                deliveryDateCell.setCellStyle(style);

                Cell subTotalCell = row.createCell(12);
                if (i == productInqueryDTOS.size()){
                    subTotalCell.setCellValue(quotationExportDTO.getAllSubtotal()== null ? "0" : quotationExportDTO.getAllSubtotal().toString());
                }else {
                    subTotalCell.setCellValue(productInqueryDTOS.get(i).getSubtotal() == null ? "0" : productInqueryDTOS.get(i).getSubtotal().toString());
                }
                subTotalCell.setCellStyle(style);


            }

            CellRangeAddress rangeAddress = new CellRangeAddress(8+productInqueryDTOS.size(), 8+productInqueryDTOS.size(), 0, 12);
            sheet.addMergedRegion(rangeAddress);
            Row allRemarkRow = sheet.createRow(8+productInqueryDTOS.size());
            Cell allRemarkRowCell = allRemarkRow.createCell(0);
            allRemarkRowCell.setCellValue("备注：报价单仅做参考，价格、货期、物流时效下单时均会由专属销售与您重新确认；若您对商品、货期存在疑问。可联系您的专属销售咨询；");

            //画图的顶级管理器
            XSSFDrawing patriarch = sheet.createDrawingPatriarch();

            /* anchor主要用于设置图片的属性
             * 该构造函数有8个参数
             * 前四个参数是控制图片在单元格的位置，分别是图片距离单元格left，top，right，bottom的像素距离
             * 后四个参数，前两个表示图片左上角所在的cellNum和 rowNum，后两个参数对应的表示图片右下角所在的cellNum和 rowNum，
             * excel中的cellNum和rowNum的index都是从0开始的
             * 设置二维码的属性
             */
            ClassPathResource resource1 = new ClassPathResource("template/qrCode.png");
            XSSFClientAnchor anchor = new XSSFClientAnchor(0, 0, 0, 0, 8, productInqueryDTOS.size() + 10, 9, productInqueryDTOS.size() + 10 + 5);
            patriarch.createPicture(anchor, wb.addPicture(resource1.getInputStream(), XSSFWorkbook.PICTURE_TYPE_PNG));

            Row guanzhuRemarkRow = sheet.createRow(15+productInqueryDTOS.size());
            Cell guanzhuRowCell = guanzhuRemarkRow.createCell(8);
            guanzhuRowCell.setCellValue("关注微信公众号，了解更多资讯。");

            wb.write(response.getOutputStream());

        } catch (Exception e) {
            e.printStackTrace();
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_EXPORT_ORDER);
        }
    }


    @Override
    public void exportInquiry(QuotationExportDTO quotationExportDTO, HttpServletResponse response) {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        // 设置编码格式
        response.setCharacterEncoding("utf-8");
        // 设置URLEncoder.encode 防止中文乱码
        String fileName = null;
        try {
            JSONObject custInfo = commonService.getCustInfo();
            fileName = URLEncoder.encode("订单明细-" + custInfo.getString("company") + "-" + DateUtil.format(LocalDateTime.now(), DatePattern.PURE_DATETIME_PATTERN), "UTF-8").replaceAll("\\+", "%20");

            // 设置响应头
            response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
            List<ProductInqueryDTO> productInqueryDTOS = quotationExportDTO.getProductInqueryDTOS();
            // 模板文件保存在springboot项目的resources/static下
            ClassPathResource resource = new ClassPathResource("template/quotationInquiryOrder.xlsx");
            XSSFWorkbook wb = new XSSFWorkbook(resource.getInputStream());
            XSSFSheet sheet = wb.getSheetAt(0);

            Row orderNoRow = sheet.getRow(1);
            Cell orderNoCell = orderNoRow.getCell(1);
            orderNoCell.setCellValue(quotationExportDTO.getInquiryOrderCode());

            Row orderDateRow = sheet.getRow(1);
            Cell orderDateCell = orderDateRow.getCell(6);
            orderDateCell.setCellValue(quotationExportDTO.getInquiryTime());

            Row companyRow = sheet.getRow(3);
            Cell companyCell = companyRow.getCell(6);
            companyCell.setCellValue(custInfo.getString("company"));

            Row linkmanRow = sheet.getRow(4);
            Cell linkmanCell = linkmanRow.getCell(6);
            linkmanCell.setCellValue(custInfo.getString("linkman"));

            Row linkphoneRow = sheet.getRow(5);
            Cell linkphoneCell = linkphoneRow.getCell(6);
            linkphoneCell.setCellValue(custInfo.getString("linkphone"));

            Row addressRow = sheet.getRow(6);
            Cell addressCell = addressRow.getCell(6);
            addressCell.setCellValue(custInfo.getString("address"));

            XSSFCellStyle style = wb.createCellStyle();
            style.setBorderBottom(BorderStyle.THIN);
            style.setBorderTop(BorderStyle.THIN);
            style.setBorderLeft(BorderStyle.THIN);
            style.setBorderRight(BorderStyle.THIN);
            style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
            style.setTopBorderColor(IndexedColors.BLACK.getIndex());
            style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
            style.setRightBorderColor(IndexedColors.BLACK.getIndex());

            for (int i = 0; i <= productInqueryDTOS.size(); i++) {
                int j = 8 + i;
                Row row = sheet.createRow(j);
                Cell serialNumCell = row.createCell(0);
                if (i == productInqueryDTOS.size()){
                    serialNumCell.setCellValue("");
                }else {
                    serialNumCell.setCellValue(productInqueryDTOS.get(i).getSerialNum().toString());
                }
                serialNumCell.setCellStyle(style);

                Cell productCodeCell = row.createCell(1);
                if (i == productInqueryDTOS.size()){
                    productCodeCell.setCellValue("");
                }else {
                    productCodeCell.setCellValue(productInqueryDTOS.get(i).getProductCode() == null ? "" : productInqueryDTOS.get(i).getProductCode());
                }
                productCodeCell.setCellStyle(style);

                Cell productNameCell = row.createCell(2);
                if (i == productInqueryDTOS.size()){
                    productNameCell.setCellValue("");
                }else {
                    productNameCell.setCellValue(productInqueryDTOS.get(i).getProductName() == null ? "" : productInqueryDTOS.get(i).getProductName());
                }
                productNameCell.setCellStyle(style);

                Cell brandNameCell = row.createCell(3);
                if (i == productInqueryDTOS.size()){
                    brandNameCell.setCellValue("总计");
                }else {
                    brandNameCell.setCellValue(productInqueryDTOS.get(i).getBrandName() == null ? "" : productInqueryDTOS.get(i).getBrandName());
                }
                brandNameCell.setCellStyle(style);

                Cell productTypeCell = row.createCell(4);
                if (i == productInqueryDTOS.size()){
                    productTypeCell.setCellValue("");
                }else {
                    productTypeCell.setCellValue(productInqueryDTOS.get(i).getProductType() == null ? "" : productInqueryDTOS.get(i).getProductType());
                }
                productTypeCell.setCellStyle(style);

                Cell productSkuCell = row.createCell(5);
                if (i == productInqueryDTOS.size()){
                    productSkuCell.setCellValue("");
                }else {
                    productSkuCell.setCellValue(productInqueryDTOS.get(i).getProductSku() == null ? "" : productInqueryDTOS.get(i).getProductSku());
                }
                productSkuCell.setCellStyle(style);

                Cell unitCell = row.createCell(6);
                if (i == productInqueryDTOS.size()){
                    unitCell.setCellValue("");
                }else {
                    unitCell.setCellValue(productInqueryDTOS.get(i).getUnit() == null ? "" : productInqueryDTOS.get(i).getUnit());
                }
                unitCell.setCellStyle(style);

                Cell remarkCell = row.createCell(7);
                if (i == productInqueryDTOS.size()){
                    remarkCell.setCellValue("");
                }else {
                    remarkCell.setCellValue(productInqueryDTOS.get(i).getRemark() == null ? "0" : productInqueryDTOS.get(i).getRemark());
                }
                remarkCell.setCellStyle(style);

                Cell numCell = row.createCell(8);
                if (i == productInqueryDTOS.size()){
                    numCell.setCellValue(quotationExportDTO.getAllNum() == null ? "0" : quotationExportDTO.getAllNum().toString());
                }else {
                    numCell.setCellValue(productInqueryDTOS.get(i).getNum() == null ? "0" : productInqueryDTOS.get(i).getNum().toString());
                }
                numCell.setCellStyle(style);

                Cell stockCell = row.createCell(9);
                if (i == productInqueryDTOS.size()){
                    stockCell.setCellValue(quotationExportDTO.getAllStock() == null ? "0" : quotationExportDTO.getAllStock().toString());
                }else {
                    stockCell.setCellValue(productInqueryDTOS.get(i).getStock() == null ? "0" : productInqueryDTOS.get(i).getStock().toString());
                }
                stockCell.setCellStyle(style);

                Cell purchasePriceCell = row.createCell(10);
                if (i == productInqueryDTOS.size()){
                    purchasePriceCell.setCellValue("");
                }else {
                    purchasePriceCell.setCellValue(productInqueryDTOS.get(i).getPurchasePrice() == null ? "0" : productInqueryDTOS.get(i).getPurchasePrice().toString());
                }
                purchasePriceCell.setCellStyle(style);

                Cell deliveryDateCell = row.createCell(11);
                if (i == productInqueryDTOS.size()){
                    deliveryDateCell.setCellValue("");
                }else {
                    deliveryDateCell.setCellValue(productInqueryDTOS.get(i).getDeliveryDate() == null ? "" : productInqueryDTOS.get(i).getDeliveryDate());
                }

                deliveryDateCell.setCellStyle(style);

                Cell subTotalCell = row.createCell(12);
                if (i == productInqueryDTOS.size()){
                    subTotalCell.setCellValue(quotationExportDTO.getAllSubtotal()== null ? "0" : quotationExportDTO.getAllSubtotal().toString());
                }else {
                    subTotalCell.setCellValue(productInqueryDTOS.get(i).getSubtotal() == null ? "0" : productInqueryDTOS.get(i).getSubtotal().toString());
                }
                subTotalCell.setCellStyle(style);


            }
            //合并单元格
            CellRangeAddress rangeAddress = new CellRangeAddress(10+productInqueryDTOS.size(), 10+productInqueryDTOS.size(), 0, 12);
            sheet.addMergedRegion(rangeAddress);
            Row allRemarkRow = sheet.createRow(10+productInqueryDTOS.size());
            Cell allRemarkRowCell = allRemarkRow.createCell(0);
            allRemarkRowCell.setCellValue("备注：报价单仅做参考，价格、货期、物流时效下单时均会由专属销售与您重新确认；若您对商品、货期存在疑问。可联系您的专属销售咨询；");

            //画图的顶级管理器
            XSSFDrawing patriarch = sheet.createDrawingPatriarch();

            /* anchor主要用于设置图片的属性
             * 该构造函数有8个参数
             * 前四个参数是控制图片在单元格的位置，分别是图片距离单元格left，top，right，bottom的像素距离
             * 后四个参数，前两个表示图片左上角所在的cellNum和 rowNum，后两个参数对应的表示图片右下角所在的cellNum和 rowNum，
             * excel中的cellNum和rowNum的index都是从0开始的
             * 设置二维码的属性
             */
            ClassPathResource resource1 = new ClassPathResource("template/qrCode.png");
            XSSFClientAnchor anchor = new XSSFClientAnchor(0, 0, 0, 0, 8, productInqueryDTOS.size() + 12, 9, productInqueryDTOS.size() + 12 + 5);
            patriarch.createPicture(anchor, wb.addPicture(resource1.getInputStream(), XSSFWorkbook.PICTURE_TYPE_PNG));

            Row guanzhuRemarkRow = sheet.createRow(17+productInqueryDTOS.size());
            Cell guanzhuRowCell = guanzhuRemarkRow.createCell(8);
            guanzhuRowCell.setCellValue("关注微信公众号，了解更多资讯。");

            wb.write(response.getOutputStream());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void adminExportInquriy(Integer inquiryOrderId, HttpServletResponse response) {

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        // 设置编码格式
        response.setCharacterEncoding("utf-8");
        InquiryOrder inquiryOrder = inquiryOrderMapper.selectById(inquiryOrderId);
        List<InquiryOrderDetails> inquiryOrderDetails = inquiryOrderDetailsMapper.listByAdmin(inquiryOrderId);
        if (inquiryOrder == null || CollectionUtils.isEmpty(inquiryOrderDetails)){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }
        //查询出提交报价的数据
        List<SupplierQuote> supplierQuotes = supplierQuoteMapper.selectByInquiryOrderId(inquiryOrderId);
        Map<Integer, List<SupplierQuote>> map = new HashMap<>();
        if (!CollectionUtils.isEmpty(supplierQuotes)){
            for (SupplierQuote supplierQuote : supplierQuotes){
                if (map.containsKey(supplierQuote.getInquiryOrderDetailsId())){
                    List<SupplierQuote> supplierQuotes1 = map.get(supplierQuote.getInquiryOrderDetailsId());
                    supplierQuotes1.add(supplierQuote);
                    map.put(supplierQuote.getInquiryOrderDetailsId(), supplierQuotes1);
                }else {
                    List<SupplierQuote> supplierQuotes1 = new ArrayList<>();
                    supplierQuotes1.add(supplierQuote);
                    map.put(supplierQuote.getInquiryOrderDetailsId(), supplierQuotes1);
                }
            }
        }
        try {
            // 设置URLEncoder.encode 防止中文乱码
            String fileName = URLEncoder.encode("订单明细-" + inquiryOrderDetails.get(0).getCustName() + "-" + inquiryOrder.getInquiryCode(), "UTF-8").replaceAll("\\+", "%20");
            // 设置响应头
            response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
            // 模板文件保存在springboot项目的resources/static下
            ClassPathResource resource = new ClassPathResource("template/adminInquiryQuote.xlsx");
            XSSFWorkbook wb = new XSSFWorkbook(resource.getInputStream());
            XSSFSheet sheet = wb.getSheetAt(0);

            Row orderNoRow = sheet.getRow(1);
            Cell orderNoCell = orderNoRow.getCell(1);
            orderNoCell.setCellValue(inquiryOrder.getInquiryCode());

            Row inquiryTimeRow = sheet.getRow(1);
            Cell inquiryTimeCell = inquiryTimeRow.getCell(11);
            inquiryTimeCell.setCellValue(DateUtil.format(inquiryOrder.getCreatedAt(), "yyyy/MM/dd HH:mm:ss"));

            Row inquiryExpireTimeRow = sheet.getRow(2);
            Cell inquiryExpireTimeCell = inquiryExpireTimeRow.getCell(1);
            inquiryExpireTimeCell.setCellValue(DateUtil.format(inquiryOrder.getInquiryExpireTime(), "yyyy/MM/dd HH:mm"));

            Row expectDeliveryDateRow = sheet.getRow(2);
            Cell expectDeliveryDateCell = expectDeliveryDateRow.getCell(11);
            expectDeliveryDateCell.setCellValue(inquiryOrder.getExpectDeliveryDate());

            Row companyRow = sheet.getRow(4);
            Cell companyCell = companyRow.getCell(11);
            companyCell.setCellValue(inquiryOrderDetails.get(0).getCustName());

            Row linkmanRow = sheet.getRow(5);
            Cell linkmanCell = linkmanRow.getCell(11);
            linkmanCell.setCellValue(inquiryOrderDetails.get(0).getLinkman());

            Row linkphoneRow = sheet.getRow(6);
            Cell linkphoneCell = linkphoneRow.getCell(11);
            linkphoneCell.setCellValue(inquiryOrderDetails.get(0).getLinkphone());

            Row addressRow = sheet.getRow(7);
            Cell addressCell = addressRow.getCell(11);
            addressCell.setCellValue(inquiryOrderDetails.get(0).getAddress());
            //单元格风格
            XSSFCellStyle style = wb.createCellStyle();
            style.setBorderBottom(BorderStyle.THIN);
            style.setBorderTop(BorderStyle.THIN);
            style.setBorderLeft(BorderStyle.THIN);
            style.setBorderRight(BorderStyle.THIN);
            style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
            style.setTopBorderColor(IndexedColors.BLACK.getIndex());
            style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
            style.setRightBorderColor(IndexedColors.BLACK.getIndex());
            //合并单元格风格
            XSSFCellStyle mergeStyle = wb.createCellStyle();
            mergeStyle.setBorderRight(BorderStyle.THIN);
            mergeStyle.setBorderBottom(BorderStyle.THIN);
            mergeStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
            mergeStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
            int serialNum = 1;
            int row = 11;
            for (InquiryOrderDetails i : inquiryOrderDetails) {
                List<SupplierQuote> supplierQuoteList = map.get(i.getId());
                if (CollectionUtils.isEmpty(supplierQuoteList)){
                    Row rowObj = sheet.createRow(row);
                    Cell serialNumCell = rowObj.createCell(0);
                    serialNumCell.setCellValue(serialNum);
                    serialNumCell.setCellStyle(style);

                    Cell stateRowCell = rowObj.createCell(1);
                    if (inquiryOrder.getState().intValue() == OrderConstants.InquiryState.IN_QUOTATION.code || inquiryOrder.getState().intValue() == OrderConstants.InquiryState.VOIDED.code){
                        stateRowCell.setCellValue("待报价");
                    }else {
                        stateRowCell.setCellValue("暂无代理");
                    }
                    stateRowCell.setCellStyle(style);

                    Cell productNameRowCell = rowObj.createCell(2);
                    productNameRowCell.setCellValue(i.getProductName());
                    productNameRowCell.setCellStyle(style);

                    Cell brandNameRowCell = rowObj.createCell(3);
                    brandNameRowCell.setCellValue(i.getBrandName());
                    brandNameRowCell.setCellStyle(style);

                    Cell productTypeRowCell = rowObj.createCell(4);
                    productTypeRowCell.setCellValue(i.getProductType());
                    productTypeRowCell.setCellStyle(style);

                    Cell productSkuRowCell = rowObj.createCell(5);
                    productSkuRowCell.setCellValue(i.getProductSku());
                    productSkuRowCell.setCellStyle(style);

                    Cell unitRowCell = rowObj.createCell(6);
                    unitRowCell.setCellValue(i.getUnit());
                    unitRowCell.setCellStyle(style);

                    Cell remarkRowCell = rowObj.createCell(7);
                    remarkRowCell.setCellValue(i.getRemark());
                    remarkRowCell.setCellStyle(style);;

                    Cell numRowCell = rowObj.createCell(8);
                    numRowCell.setCellValue(i.getNum());
                    numRowCell.setCellStyle(style);

                    for (int j = 9; j < 19; j++) {
                        Cell otherRowCell = rowObj.createCell(j);
                        otherRowCell.setCellStyle(style);
                    }
                    row++;
                }else {
                    int lasRow = row + supplierQuoteList.size() - 1;
                    if (supplierQuoteList.size() > 1){
                        //合并单元格
                        sheet.addMergedRegion(new CellRangeAddress(row, lasRow, 0, 0));
                        sheet.addMergedRegion(new CellRangeAddress(row, lasRow, 1, 1));
                        sheet.addMergedRegion(new CellRangeAddress(row, lasRow, 2, 2));
                        sheet.addMergedRegion(new CellRangeAddress(row, lasRow, 3, 3));
                        sheet.addMergedRegion(new CellRangeAddress(row, lasRow, 4, 4));
                        sheet.addMergedRegion(new CellRangeAddress(row, lasRow, 5, 5));
                        sheet.addMergedRegion(new CellRangeAddress(row, lasRow, 6, 6));
                        sheet.addMergedRegion(new CellRangeAddress(row, lasRow, 7, 7));
                        sheet.addMergedRegion(new CellRangeAddress(row, lasRow, 8, 8));
                        sheet.addMergedRegion(new CellRangeAddress(row, lasRow, 9, 9));
                    }
                    //创建行
                    Row rowObj = sheet.createRow(row);
                    //创建单元格
                    Cell serialNumRowCell = rowObj.createCell(0);
                    serialNumRowCell.setCellValue(serialNum);
                    serialNumRowCell.setCellStyle(style);

                    Cell stateRowCell = rowObj.createCell(1);
                    if (inquiryOrder.getState().intValue() == OrderConstants.InquiryState.QUOTED.code){
                        if (inquiryOrder.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.UN_CONFIRMED.code){
                            if (i.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.UN_CONFIRMED.code){
                                stateRowCell.setCellValue("待确认");
                            }else if (i.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.CONFIRMED.code){
                                if (StringUtils.isNotEmpty(i.getSupplierName())){
                                    stateRowCell.setCellValue("已报价");
                                }else {
                                    stateRowCell.setCellValue("暂无代理");
                                }
                            }
                        }else if (inquiryOrder.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.CONFIRMED.code){
                            if (i.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.UN_CONFIRMED.code){
                                stateRowCell.setCellValue("暂无代理");
                            }else if (i.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.CONFIRMED.code){
                                if (StringUtils.isNotEmpty(i.getSupplierName())){
                                    stateRowCell.setCellValue("已报价");
                                }else {
                                    stateRowCell.setCellValue("暂无代理");
                                }
                            }
                        }

                    }else if (inquiryOrder.getState().intValue() == OrderConstants.InquiryState.ACCEPTED.code){
                        if (i.getState().intValue() == OrderConstants.InquiryState.ACCEPTED.code && i.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.CONFIRMED.code){
                            stateRowCell.setCellValue("已成交");
                        }else if (i.getState().intValue() == OrderConstants.InquiryState.QUOTED.code && i.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.CONFIRMED.code){
                            stateRowCell.setCellValue("已报价");
                        }else if (i.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.UN_CONFIRMED.code){
                            stateRowCell.setCellValue("暂无代理");
                        }
                    }else if (inquiryOrder.getState().intValue() == OrderConstants.InquiryState.VOIDED.code){
                        if (i.getState().intValue() == OrderConstants.InquiryState.IN_QUOTATION.code && i.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.UN_CONFIRMED.code){
                            stateRowCell.setCellValue("待报价");
                        }else if (i.getState().intValue() == OrderConstants.InquiryState.QUOTED.code && i.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.UN_CONFIRMED.code){
                            stateRowCell.setCellValue("待确认");
                        }else if (i.getState().intValue() == OrderConstants.InquiryState.QUOTED.code && i.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.CONFIRMED.code){
                            stateRowCell.setCellValue("已报价");
                        }
                    }
                    stateRowCell.setCellStyle(style);

                    Cell productNameRowCell = rowObj.createCell(2);
                    productNameRowCell.setCellValue(StringUtils.isNotEmpty(i.getSuggestedProductName()) ? i.getSuggestedProductName() : i.getProductName());
                    productNameRowCell.setCellStyle(style);

                    Cell brandNameRowCell = rowObj.createCell(3);
                    brandNameRowCell.setCellValue(StringUtils.isNotEmpty(i.getSuggestedBrandName()) ? i.getSuggestedBrandName() : i.getBrandName());
                    brandNameRowCell.setCellStyle(style);

                    Cell productTypeRowCell = rowObj.createCell(4);
                    productTypeRowCell.setCellValue(StringUtils.isNotEmpty(i.getSuggestedProductType()) ? i.getSuggestedProductType() : i.getProductType());
                    productTypeRowCell.setCellStyle(style);

                    Cell productSkuRowCell = rowObj.createCell(5);
                    productSkuRowCell.setCellValue(StringUtils.isNotEmpty(i.getSuggestedProductSku()) ? i.getSuggestedProductSku() : i.getProductSku());
                    productSkuRowCell.setCellStyle(style);

                    Cell unitRowCell = rowObj.createCell(6);
                    unitRowCell.setCellValue(i.getUnit());
                    unitRowCell.setCellStyle(style);

                    Cell numRowCell = rowObj.createCell(7);
                    numRowCell.setCellValue(i.getNum());
                    numRowCell.setCellStyle(style);

                    Cell remarkRowCell = rowObj.createCell(8);
                    remarkRowCell.setCellValue(i.getRemark());
                    remarkRowCell.setCellStyle(style);;

                    Cell confirmSupplierRowCell = rowObj.createCell(9);
                    confirmSupplierRowCell.setCellValue(i.getSupplierName());
                    confirmSupplierRowCell.setCellStyle(style);

                    for (int j = 0; j < supplierQuoteList.size(); j++) {
                        SupplierQuote supplierQuote = supplierQuoteList.get(j);
                        Row rowObj1 = null;
                        if (j != 0){
                            rowObj1 = sheet.createRow(row + j);
                            rowObj1.createCell(0).setCellStyle(mergeStyle);
                            rowObj1.createCell(1).setCellStyle(mergeStyle);
                            rowObj1.createCell(2).setCellStyle(mergeStyle);
                            rowObj1.createCell(3).setCellStyle(mergeStyle);
                            rowObj1.createCell(4).setCellStyle(mergeStyle);
                            rowObj1.createCell(5).setCellStyle(mergeStyle);
                            rowObj1.createCell(6).setCellStyle(mergeStyle);
                            rowObj1.createCell(7).setCellStyle(mergeStyle);
                            rowObj1.createCell(8).setCellStyle(mergeStyle);
                            rowObj1.createCell(9).setCellStyle(mergeStyle);
                        }else {
                            rowObj1 = sheet.getRow(row + j);
                        }

                        Cell quoteSupplierRowCell = rowObj1.createCell(10);
                        quoteSupplierRowCell.setCellValue(supplierQuote.getSupplierName());
                        quoteSupplierRowCell.setCellStyle(style);

                        Cell suggestedBrandRowCell = rowObj1.createCell(11);
                        suggestedBrandRowCell.setCellValue(supplierQuote.getSuggestedBrandName());
                        suggestedBrandRowCell.setCellStyle(style);

                        Cell suggestedProductTypeRowCell = rowObj1.createCell(12);
                        suggestedProductTypeRowCell.setCellValue(supplierQuote.getSuggestedProductType());
                        suggestedProductTypeRowCell.setCellStyle(style);

                        Cell stockRowCell = rowObj1.createCell(13);
                        stockRowCell.setCellValue(supplierQuote.getStock());
                        stockRowCell.setCellStyle(style);

                        Cell supplyPriceRowCell = rowObj1.createCell(14);
                        supplyPriceRowCell.setCellValue(supplierQuote.getSupplyPrice().toString());
                        supplyPriceRowCell.setCellStyle(style);

                        Cell quotePriceRowCell = rowObj1.createCell(15);
                        quotePriceRowCell.setCellValue(supplierQuote.getQuotePrice().toString());
                        quotePriceRowCell.setCellStyle(style);

                        Cell deliveryDateRowCell = rowObj1.createCell(16);
                        deliveryDateRowCell.setCellValue(supplierQuote.getDeliveryDate());
                        deliveryDateRowCell.setCellStyle(style);

                        Cell quoteTimeRowCell = rowObj1.createCell(17);
                        quoteTimeRowCell.setCellValue(DateUtil.format(supplierQuote.getQuoteTime(), "yyyy/MM/dd HH:mm"));
                        quoteTimeRowCell.setCellStyle(style);

                        Cell expireTimeRowCell = rowObj1.createCell(18);
                        expireTimeRowCell.setCellValue(DateUtil.format(supplierQuote.getExpireTime(), "yyyy/MM/dd HH:mm"));
                        expireTimeRowCell.setCellStyle(style);
                    }

                    row = row + supplierQuoteList.size();
                }
                serialNum++;
            }
            wb.write(response.getOutputStream());
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public Page<Product> page(ProductPageDTO productPageDTO) {
        if (!StringUtils.isEmpty(productPageDTO.getSupplierId())){
            Page<ProductPageVO> productPage = productMapper.selectBySupplier(productPageDTO.getKey(), productPageDTO.getSupplierId(), productPageDTO.buildPage());
            Page<Product> productPage1 = new Page<>();
            BeanUtil.copyProperties(productPage, productPage1);
            return productPage1;
        }else {
            QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
            queryWrapper.and(StringUtils.isNotEmpty(productPageDTO.getKey()), new Consumer<QueryWrapper<Product>>() {
                @Override
                public void accept(QueryWrapper<Product> purchaseInquiryOrderQueryWrapper) {
                    purchaseInquiryOrderQueryWrapper.or().like("product_name", productPageDTO.getKey());
                    purchaseInquiryOrderQueryWrapper.or().like("brand_name", productPageDTO.getKey());
                    purchaseInquiryOrderQueryWrapper.or().like("product_type", productPageDTO.getKey());
                    purchaseInquiryOrderQueryWrapper.or().like("product_sku", productPageDTO.getKey());
                }
            });
            return productMapper.selectPage(productPageDTO.buildPage(), queryWrapper);
        }
    }

    @Override
    public Page<ProductPageVO> pageSupplier(ProductPageDTO productPageDTO) {
        String supplier = commonService.getSupplierId();
        productPageDTO.setSupplierId(supplier);
        Page<ProductPageVO> productPage = productMapper.selectBySupplier(productPageDTO.getKey(), productPageDTO.getSupplierId(), productPageDTO.buildPage());
        return productPage;
    }

    @Override
    public List<ProductPageVO> productQuote(Integer productId) {
        return productMapper.productQuote(productId);
    }

}
