package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/8  13:40
 */
@Data
public class ProductPageDTO extends PageDTO {
    @Schema(description = "品牌/型号/物料号/产品名称")
    private String key;
    @Schema(description = "供应商id")
    private String supplierId;
}
