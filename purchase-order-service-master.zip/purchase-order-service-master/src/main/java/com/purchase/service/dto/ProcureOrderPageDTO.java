package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Pattern;
import java.time.LocalDateTime;


/**
 * @author jidonglin
 * @Description: 采购订单
 * @date 2023/12/20  9:47
 */
@Data
public class ProcureOrderPageDTO extends PageDTO {
    @Schema(description = "管理端关键字")
    private String adminKey;

    @Schema(description = "供应商端关键字")
    private String supplierKey;

    @Schema(description = "供应商id")
    private String supplierId;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "下单时间： 开始时间")
    private LocalDateTime startTime;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "下单时间： 结束时间")
    private LocalDateTime endTime;

    @Schema(description = "订单状态")
    @Pattern(regexp = "1|2|3",message = "没有此状态")
    private String orderStatus;
}
