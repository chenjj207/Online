package com.purchase.service.dto;

import com.purchase.entity.InquiryOrderDetails;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 询价单
 * @date 2023/9/6  9:47
 */
@Data
public class InquiryOrderAddDTO {

    @Schema(description = "标题")
    @NotBlank(message = "标题不能为空")
    private String title;

    @Schema(description = "期望货期")
    private String expectDeliveryDate;

    @Schema(description = "有效期天数")
    @NotNull(message = "有效期天数不能为空")
    private Integer day;

    @Schema(description = "报价总金额")
    private BigDecimal allQuotePrice;

    @Schema(description = "总项数，即产品条数")
    @NotNull(message = "总项数不能为空")
    private Integer items;

    @Schema(description = "商品详情")
    @NotEmpty(message = "商品详情不能为空")
    private List<InquiryOrderDetails> inquiryOrderDetails;
}
