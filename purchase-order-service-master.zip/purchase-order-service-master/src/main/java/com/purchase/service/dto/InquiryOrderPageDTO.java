package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


/**
 * @author jidonglin
 * @Description: 询价单
 * @date 2023/9/6  9:47
 */
@Data
public class InquiryOrderPageDTO extends PageDTO {
    @Schema(description = "关键字")
    private String key;

    @Schema(description = "询价单号")
    private String inquiryCode;

    @Schema(description = "状态")
    private Integer state;

    @Schema(description = "运营端确认状态")
    private Integer confirmState;

    @Schema(description = "tab状态条件")
    private String tabState;

    @Schema(description = "供应商id")
    private String supplierId;

    @Schema(description = "客户名称")
    private String custName;

    @Schema(description = "客户id")
    private Integer custId;

    @Schema(description = "是否过期 1：未过期 2：已过期")
    private Boolean isExpire;
}
