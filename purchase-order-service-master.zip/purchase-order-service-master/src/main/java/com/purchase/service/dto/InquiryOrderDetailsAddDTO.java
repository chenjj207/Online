package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @author jidonglin
 * @Description: 询价单详情
 * @date 2023/9/6  9:47
 */
@Data
public class InquiryOrderDetailsAddDTO {
    @Schema(description = "我的编码")
    private String productCode;

    @Schema(description = "品牌名称")
    private String brandName;

    @Schema(description = "产品型号")
    private String productType;

    @Schema(description = "产品物料号")
    private String productSku;

    @Schema(description = "产品名称")
    private String productName;

    @Schema(description = "需求数量")
    @Min(value = 1, message = "需求数量至少要为1")
    private int num;

    @Schema(description = "面价")
    private BigDecimal price;

    @Schema(description = "报价")
    private BigDecimal quotePrice;

    @Schema(description = "小计")
    private BigDecimal subtotal;

    @Schema(description = "货期时效")
    private String deliveryDate;
}
