package com.purchase.service;

import com.purchase.entity.SupplierQuote;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.ConfirmQuoteAddDTO;
import com.purchase.service.dto.ConfirmQuoteSaveDTO;
import com.purchase.service.dto.SupplierQuoteAddDTO;
import com.purchase.service.dto.SupplierQuoteSaveDTO;

/**
 * <p>
 * 供应商惠采商品 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-08-31
 */
public interface SupplierQuoteService extends IService<SupplierQuote> {

    public Boolean add(SupplierQuoteAddDTO supplierQuoteAddDTO);

    public Boolean save(SupplierQuoteSaveDTO supplierQuoteSaveDTO);

    public Boolean confirmAdd(ConfirmQuoteAddDTO confirmQuoteAddDTO);

    public Boolean confirmSave(ConfirmQuoteSaveDTO confirmQuoteSaveDTO);

}
