package com.purchase.service.vo;

import lombok.Data;

/**
 * @author jidonglin
 * @Description: 订单列表统计
 * @date 2024/01/02  11:11
 */
@Data
public class OrdersTabVO {
    private Integer tab;
    private int count;
}
