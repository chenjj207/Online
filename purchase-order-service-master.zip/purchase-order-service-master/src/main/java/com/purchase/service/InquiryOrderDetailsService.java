package com.purchase.service;

import com.purchase.entity.InquiryOrder;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.entity.InquiryOrderDetails;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-19
 */
public interface InquiryOrderDetailsService extends IService<InquiryOrderDetails> {

    List<InquiryOrderDetails> list(Integer inquiryOrderId);

    List<InquiryOrderDetails> listByAdmin(Integer inquiryOrderId);

    List<InquiryOrderDetails> listBySupplier(Integer inquiryOrderId);

    List<InquiryOrderDetails> listByLyh(Integer inquiryOrderId);

}
