package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Pattern;


/**
 * @author jidonglin
 * @Description: 询价单
 * @date 2023/10/21  9:47
 */
@Data
public class InquiryOrderMallPageDTO extends PageDTO {
    @Pattern(regexp = "1|2|3",message = "没有此tag")
    @Schema(description = "tab状态条件 1、未参与 2、已参与 3、已过期")
    private String tabState;

    @Schema(description = "供应商id")
    private String supplierId;
}
