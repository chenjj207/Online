package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/20  16:35
 */
@Data
public class InquiryOrderDetailsEditDTO {

    @NotNull(message = "询价详情id不能为空")
    @Schema(description = "询价详情id")
    private Integer id;

    @Schema(description = "库存，运营端确认报价后更新库存")
    private Integer stock;

    @Schema(description = "报价/慧采价")
    private BigDecimal quotePrice;

    @Schema(description = "供货价")
    private BigDecimal supplyPrice;

    @Schema(description = "货期时效")
    private String deliveryDate;

    @Schema(description = "建议品牌")
    private String suggestedBrandName;

    @Schema(description = "建议型号")
    private String suggestedProductType;

    @Schema(description = "建议物料号")
    private String suggestedProductSku;

    @Schema(description = "建议物料名称")
    private String suggestedProductName;
}
