package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * @author jidonglin
 * @Description: 重复商品确认DTO
 * @date 2023/9/4  13:24
 */
@Data
public class RepeatConfirmDTO {
    @Schema(description = "序号")
    private int serialNum;
    @Schema(description = "搜索框文本")
    private String text;
    @Schema(description = "惠采商品列表")
    private List<ProductInqueryDTO> productInqueryDTOS;
}
