package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.purchase.config.PurchaseOrderExceptionDesc;
import com.purchase.entity.InquiryOrder;
import com.purchase.entity.InquiryOrderDetails;
import com.purchase.mapper.InquiryOrderDetailsMapper;
import com.purchase.mapper.InquiryOrderMapper;
import com.purchase.service.CommonService;
import com.purchase.service.InquiryOrderDetailsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zyd.framework.utils.constant.UserSession;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-19
 */
@Service
public class InquiryOrderDetailsServiceImpl extends ServiceImpl<InquiryOrderDetailsMapper, InquiryOrderDetails> implements InquiryOrderDetailsService {

    @Resource
    InquiryOrderDetailsMapper inquiryOrderDetailsMapper;
    @Autowired
    CommonService commonService;

    @Override
    public List<InquiryOrderDetails> list(Integer inquiryOrderId) {
        QueryWrapper<InquiryOrderDetails> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("inquiry_order_id", inquiryOrderId);
        return inquiryOrderDetailsMapper.selectList(queryWrapper);
    }

    @Override
    public List<InquiryOrderDetails> listByAdmin(Integer inquiryOrderId) {
        return inquiryOrderDetailsMapper.listByAdmin(inquiryOrderId);
    }

    @Override
    public List<InquiryOrderDetails> listBySupplier(Integer inquiryOrderId) {
        String supplierId = commonService.getSupplierId();
        return inquiryOrderDetailsMapper.listBySupplier(inquiryOrderId, supplierId);
    }

    @Override
    public List<InquiryOrderDetails> listByLyh(Integer inquiryOrderId) {
        String supplierId = null;
        if (StpUtil.isLogin()){
            JSONObject jsonObject = StpUtil.getSession().getModel(UserSession.INFO,JSONObject.class);
            supplierId = jsonObject.getString("supplierId");
        }
        if (StringUtils.isEmpty(supplierId)){
            return inquiryOrderDetailsMapper.listByNoQuote(inquiryOrderId);
        }else {
            return inquiryOrderDetailsMapper.listBySupplier(inquiryOrderId, supplierId);
        }
    }
}
