package com.purchase.service.vo;

import com.purchase.entity.SupplierQuote;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/7  15:14
 */
@Data
public class InquiryOrderAndQuotesVO {
    @Schema(description = "品牌名称")
    private String brandName;

    @Schema(description = "产品型号")
    private String productType;

    @Schema(description = "产品物料号")
    private String productSku;

    @Schema(description = "产品名称")
    private String productName;

    @Schema(description = "报价列表")
    private List<SupplierQuote> supplierQuotes;

}
