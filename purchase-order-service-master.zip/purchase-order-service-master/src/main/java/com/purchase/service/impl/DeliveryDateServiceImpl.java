package com.purchase.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.DeliveryDate;
import com.purchase.mapper.DeliveryDateMapper;
import com.purchase.service.CommonService;
import com.purchase.service.DeliveryDateService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.DeliveryDateAddDTO;
import com.purchase.service.dto.DeliveryDatePageDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-28
 */
@Service
public class DeliveryDateServiceImpl extends ServiceImpl<DeliveryDateMapper, DeliveryDate> implements DeliveryDateService {

    @Resource
    DeliveryDateMapper deliveryDateMapper;
    @Autowired
    CommonService commonService;

    @Override
    public Integer add(DeliveryDateAddDTO deliveryDateAddDTO) {
        DeliveryDate deliveryDate = new DeliveryDate();
        deliveryDate.setDeliveryDate(deliveryDateAddDTO.getDeliveryDate());
        deliveryDate.setCreatedAt(LocalDateTime.now());
        deliveryDate.setCreatedBy(commonService.getUserId());
        deliveryDateMapper.insert(deliveryDate);
        return deliveryDate.getId();
    }

    @Override
    public Page<DeliveryDate> queryList(DeliveryDatePageDTO deliveryDatePageDTO) {
        return deliveryDateMapper.page(deliveryDatePageDTO, deliveryDatePageDTO.buildPage());
    }
}
