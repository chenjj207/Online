package com.purchase.service.vo;

import com.purchase.entity.InquiryOrderDetails;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/6  16:03
 */
@Data
public class InquiryOrderDetailsPageBackVO extends InquiryOrderDetails {
    @Schema(description = "客户名称")
    private String company;
    @Schema(description = "供应商名称")
    private String supplierName;

}
