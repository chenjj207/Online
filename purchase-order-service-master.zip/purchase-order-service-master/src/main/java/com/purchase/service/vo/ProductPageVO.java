package com.purchase.service.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.purchase.entity.Product;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/1  11:09
 */
@Data
public class ProductPageVO extends Product {

    @Schema(description = "需求数量")
    private String num;
    @Schema(description = "期望货期")
    private String expectDeliveryDate;
    @Schema(description = "错误信息")
    private String error;

    private Integer stock;

    @Schema(description = "面价")
    private BigDecimal price;

    @Schema(description = "报价")
    private BigDecimal quotePrice;

    @Schema(description = "货期类型： 现货  期货")
    private String deliveryType;

    @Schema(description = "货期")
    private String deliveryDate;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "报价有效期")
    private LocalDateTime expireTime;


    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "报价时间")
    private LocalDateTime quoteTime;

    @Schema(description = "供应商名称")
    private String company;
}
