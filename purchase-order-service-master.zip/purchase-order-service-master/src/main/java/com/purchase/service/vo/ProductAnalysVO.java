package com.purchase.service.vo;

import com.purchase.entity.OrderDetails;
import com.purchase.entity.SupplierQuote;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 采购分析响应
 * @date 2023/9/14  10:56
 */
@Data
public class ProductAnalysVO {

    @Schema(description = "品牌名称")
    private String brandName;

    @Schema(description = "产品型号")
    private String productType;

    @Schema(description = "产品物料号")
    private String productSku;

    @Schema(description = "产品名称")
    private String productName;

    @Schema(description = "供应商平均报价")
    private BigDecimal avgQuotePrice;

    @Schema(description = "采购数量")
    private Integer allNum;

    @Schema(description = "总合计")
    private BigDecimal subTotal;

    @Schema(description = "下单商品详情")
    private List<OrderDetails> orderDetails;


}
