package com.purchase.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.URLUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.purchase.client.MsgClient;
import com.purchase.client.ProductClient;
import com.purchase.client.dto.ProductAuditDTO;
import com.purchase.client.dto.PurchaseProductApply;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.common.OrderConstants;
import com.purchase.config.PurchaseOrderExceptionDesc;
import com.purchase.entity.InquiryOrder;
import com.purchase.entity.InquiryOrderDetails;
import com.purchase.entity.Product;
import com.purchase.entity.SupplierQuote;
import com.purchase.mapper.InquiryOrderDetailsMapper;
import com.purchase.mapper.InquiryOrderMapper;
import com.purchase.mapper.ProductMapper;
import com.purchase.mapper.SupplierQuoteMapper;
import com.purchase.service.CommonService;
import com.purchase.service.InquiryOrderDetailsService;
import com.purchase.service.InquiryOrderService;
import com.purchase.service.SupplierQuoteService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.*;
import com.zyd.framework.utils.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 供应商惠采商品 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-08-31
 */
@Service
@Slf4j
public class SupplierQuoteServiceImpl extends ServiceImpl<SupplierQuoteMapper, SupplierQuote> implements SupplierQuoteService {

    @Resource
    SupplierQuoteMapper supplierQuoteMapper;
    @Resource
    InquiryOrderDetailsMapper inquiryOrderDetailsMapper;
    @Resource
    InquiryOrderMapper inquiryOrderMapper;
    @Resource
    ProductMapper productMapper;

    @Autowired
    CommonService commonService;
    @Autowired
    InquiryOrderDetailsService inquiryOrderDetailsService;
    @Autowired
    InquiryOrderService inquiryOrderService;
    @Resource
    MsgClient msgClient;
    @Resource
    ProductClient productClient;

    @Value("${odsUrl}")
    String odsUrl;

    /**
     * 报价
     * @param supplierQuoteAddDTO
     * @return
     */
    @Override
    @Transactional
    public Boolean add(SupplierQuoteAddDTO supplierQuoteAddDTO) {
        InquiryOrder inquiryOrder = inquiryOrderMapper.selectById(supplierQuoteAddDTO.getInquiryOrderId());
        //检查询价单是否存在
        if (inquiryOrder == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }
        if (inquiryOrder.getState().intValue() == OrderConstants.InquiryState.VOIDED.code){
            //询价单状态 为【作废】，不允许报价
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.CANNOT_QUOTE);
        }
        LocalDateTime now = LocalDateTime.now();
        if (inquiryOrder.getInquiryExpireTime().isBefore(now)){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.EXPIRE_INQUIRY_ORDER);
        }
        List<InquiryOrderDetailsEditDTO> inquiryOrderDetailsEditDTOS = supplierQuoteAddDTO.getInquiryOrderDetailsEditDTOS();
        List<Integer> ids = inquiryOrderDetailsEditDTOS.stream().map(InquiryOrderDetailsEditDTO::getId).collect(Collectors.toList());
        //判断是否存在询价单详情记录，不存在则抛出异常
        QueryWrapper<InquiryOrderDetails> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("id", ids);
        queryWrapper.eq("inquiry_order_id", inquiryOrder.getId());
        List<InquiryOrderDetails> inquiryOrderDetails = inquiryOrderDetailsMapper.selectList(queryWrapper);
        if (CollectionUtils.isEmpty(inquiryOrderDetails)){
            //询价详情单不存在
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER_DETAILS);
        }
        if (inquiryOrderDetails.size() != inquiryOrderDetailsEditDTOS.size()){
            //询价详情单的数量 不等于 入参的询价单的数量
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER_DETAILS);
        }
        Map<Integer, InquiryOrderDetails> inquiryOrderDetailsHashMap = new HashMap<>();
        for (InquiryOrderDetails i : inquiryOrderDetails) {
            if (i.getState().intValue() == OrderConstants.InquiryState.VOIDED.code){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.EXIST_ERROR_INQUIRY_DETAILS);
            }
            inquiryOrderDetailsHashMap.put(i.getId(), i);
        }
        //判断是否存在供应商 已报价
        QueryWrapper<SupplierQuote> supplierQuoteQueryWrapper = new QueryWrapper<>();
        supplierQuoteQueryWrapper.in("inquiry_order_details_id", ids);
        supplierQuoteQueryWrapper.eq("supplier_id", commonService.getSupplierId());
        List<SupplierQuote> querySupplierQuotes = supplierQuoteMapper.selectList(supplierQuoteQueryWrapper);
        //获取待报价的商品详情单
        HashMap<Integer, Integer> pendingIdMap = new HashMap<>();
        //已报价过的商品
        HashMap<Integer, SupplierQuote> quoteIdMap = new HashMap<>();
        if (!CollectionUtils.isEmpty(querySupplierQuotes)){
            for (SupplierQuote s : querySupplierQuotes) {
                if (s.getState().equals(OrderConstants.SupplierQuoteStatus.QUOTED.code)){
                    //已报价的商品
                    quoteIdMap.put(s.getInquiryOrderDetailsId(), s);
                }else {
                    //待报价（已保存）的商品
                    pendingIdMap.put(s.getInquiryOrderDetailsId(), s.getId());
                }
            }
        }

        //获取 正在报价的商品， 报价和供货价和库存都大于0, 并且商品当前供应商未报价
        List<Integer> quoteInquiryDetailsIdS = new ArrayList<>();
        for (InquiryOrderDetailsEditDTO i : inquiryOrderDetailsEditDTOS){
            if (i.getQuotePrice() != null && i.getStock() != null && i.getSupplyPrice() != null
                    && (i.getQuotePrice().compareTo(BigDecimal.ZERO) > 0)  && (i.getSupplyPrice().compareTo(BigDecimal.ZERO) > 0)){
                //报价和库存都大于0
                if (quoteIdMap.containsKey(i.getId())){
                    //如果有报价，并且存在报价, 忽略
                    continue;
                }else {
                    //如果没有报价，判断供货价和慧采价的比值，就直接添加
                    if ((i.getSupplyPrice().multiply(new BigDecimal(1.05)).compareTo(i.getQuotePrice())) > 0){
                        throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_SUPPLY_PRICE);
                    }
                    quoteInquiryDetailsIdS.add(i.getId());
                }
            }
        }
        if (CollectionUtils.isEmpty(quoteInquiryDetailsIdS)){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_DETAILS_TO_QUOTE);
        }
        String userId = commonService.getUserId();
        String supplierId = commonService.getSupplierId();
        //询价商品 和 临时产品表商品 的关联
        HashMap<Integer, Integer> productInquiryMap = new HashMap<>();
        //商品申请表
        List<PurchaseProductApply> purchaseProductApplies = new ArrayList<>();
        for (InquiryOrderDetailsEditDTO i : inquiryOrderDetailsEditDTOS) {
            // 询价商品进入临时商品表，这个逻辑暂时保留
            // https://zentao-gz.zyd.cn/index.php?m=projectstory&f=view&storyID=1756 这个版本调整为 商品进入供应商商品申请表
            if (!quoteInquiryDetailsIdS.contains(i.getId())){
                //只对正在报价的商品 添加临时商品
                continue;
            }
            String brandName = StringUtils.isEmpty(i.getSuggestedBrandName()) ? inquiryOrderDetailsHashMap.get(i.getId()).getBrandName() : i.getSuggestedBrandName();
            String productType = StringUtils.isEmpty(i.getSuggestedProductType()) ? inquiryOrderDetailsHashMap.get(i.getId()).getProductType() : i.getSuggestedProductType();
            String productSku = StringUtils.isEmpty(i.getSuggestedProductSku()) ? inquiryOrderDetailsHashMap.get(i.getId()).getProductSku() : i.getSuggestedProductSku();
            String productName = StringUtils.isEmpty(i.getSuggestedProductName()) ? inquiryOrderDetailsHashMap.get(i.getId()).getProductName() : i.getSuggestedProductName();
            //商品申请表
            PurchaseProductApply p = new PurchaseProductApply();
            p.setBrandName(brandName);
            p.setProductType(productType);
            p.setSkuCode(productSku);
            p.setMaterialName(productName);
            p.setSupplyPrice(i.getSupplyPrice());
            p.setPurchasePrice(i.getQuotePrice());
            p.setStock(i.getStock());
            p.setSupplierId(supplierId);
            p.setDeliveryDate(i.getDeliveryDate());
            p.setUserId(userId);
            p.setIsSupply("N");//不是供应链
            p.setIsOnsale("Y");//
            p.setProductCode(inquiryOrderDetailsHashMap.get(i.getId()).getProductCode());
            purchaseProductApplies.add(p);
            //查询是否存在惠采临时商品
            QueryWrapper<Product> productQueryWrapper = new QueryWrapper<>();
            productQueryWrapper.eq(StringUtils.isNotEmpty(brandName), "brand_name", brandName);
            productQueryWrapper.eq(StringUtils.isNotEmpty(productType), "product_type", productType);
            Product productQuery = productMapper.selectOne(productQueryWrapper);
            Integer productId = null;
            if (productQuery == null){
                //添加惠采临时商品
                Product product = new Product();
                product.setBrandName(brandName);
                product.setProductType(productType);
                product.setProductSku(productSku);
                product.setProductName(productName);
                product.setCreatedAt(now);
                product.setCreatedBy(userId);
                productMapper.insert(product);
                productId = product.getId();
            }else {
                productId = productQuery.getId();
            }
            productInquiryMap.put(i.getId(), productId);
        }

        HashMap<String, String> multiQuoteHashMap = new HashMap<>();
        //报价成功，增加供应商商品申请
        if (!CollectionUtils.isEmpty(purchaseProductApplies)){
            //添加商品申请的数据
            multiQuoteHashMap = productClient.multiQuote(purchaseProductApplies);
        }
        //保存报价单
        List<SupplierQuote> addSupplierQuotes = new ArrayList<>();
        List<SupplierQuote> updateSupplierQuotes = new ArrayList<>();
        //询价单详情
        List<InquiryOrderDetails> inquiryOrderDetailsList = new ArrayList<>();
        BigDecimal allQuotePrice = new BigDecimal(0);
        for (InquiryOrderDetailsEditDTO i : supplierQuoteAddDTO.getInquiryOrderDetailsEditDTOS()) {
            if (i.getQuotePrice() != null){
                allQuotePrice = allQuotePrice.add(i.getQuotePrice().multiply(new BigDecimal(inquiryOrderDetailsHashMap.get(i.getId()).getNum())));
            }
            SupplierQuote supplierQuote = new SupplierQuote();
            if (quoteIdMap.containsKey(i.getId())){
                //已报价的 修改报价时间 报价货期
                supplierQuote.setId(quoteIdMap.get(i.getId()).getId());
                supplierQuote.setDeliveryDate(i.getDeliveryDate());
                supplierQuote.setExpireTime(now.plusDays(supplierQuoteAddDTO.getDay()));
                supplierQuote.setQuoteTime(now);
                supplierQuote.setUpdatedAt(now);
                supplierQuote.setUpdatedBy(userId);
                supplierQuote.setSupplyPrice(quoteIdMap.get(i.getId()).getSupplyPrice());
                supplierQuote.setStock(quoteIdMap.get(i.getId()).getStock());
                supplierQuote.setQuotePrice(quoteIdMap.get(i.getId()).getQuotePrice());
                updateSupplierQuotes.add(supplierQuote);
                continue;
            }
            //获取商品申请表的id
            String brandName = StringUtils.isEmpty(i.getSuggestedBrandName()) ? inquiryOrderDetailsHashMap.get(i.getId()).getBrandName() : i.getSuggestedBrandName();
            String productType = StringUtils.isEmpty(i.getSuggestedProductType()) ? inquiryOrderDetailsHashMap.get(i.getId()).getProductType() : i.getSuggestedProductType();
            String key = productType + "@" + (StringUtils.isEmpty(brandName) ? "" : brandName);
            String productApplyId = multiQuoteHashMap.get(key);
            supplierQuote.setProductApplyId(productApplyId);

            supplierQuote.setInquiryOrderId(supplierQuoteAddDTO.getInquiryOrderId());
            supplierQuote.setInquiryOrderDetailsId(i.getId());
            supplierQuote.setSupplierId(supplierId);
            supplierQuote.setSuggestedBrandName(i.getSuggestedBrandName());
            supplierQuote.setSuggestedProductType(i.getSuggestedProductType());
            supplierQuote.setSuggestedProductSku(i.getSuggestedProductSku());
            supplierQuote.setSuggestedProductName(i.getSuggestedProductName());
            if (quoteInquiryDetailsIdS.contains(i.getId())){
                //库存报价都大于0时， 为“已报价”状态
                supplierQuote.setState(OrderConstants.SupplierQuoteStatus.QUOTED.code);
                supplierQuote.setDeliveryDate(i.getDeliveryDate());
                supplierQuote.setExpireTime(now.plusDays(supplierQuoteAddDTO.getDay()));
                supplierQuote.setQuoteTime(now);
            } else {
                //其他为 "未报价"
                supplierQuote.setState(OrderConstants.SupplierQuoteStatus.PENDING.code);
            }
            supplierQuote.setSupplyPrice(i.getSupplyPrice());
            supplierQuote.setQuotePrice(i.getQuotePrice());
            supplierQuote.setStock(i.getStock());
            supplierQuote.setInquiryOrderState(OrderConstants.InquiryOrderStatus.QUOTED.code);
            if (pendingIdMap.keySet().contains(i.getId())){
                supplierQuote.setUpdatedAt(now);
                supplierQuote.setUpdatedBy(userId);
                supplierQuote.setId(pendingIdMap.get(i.getId()));
                updateSupplierQuotes.add(supplierQuote);
            }else {
                supplierQuote.setCreatedAt(now);
                supplierQuote.setCreatedBy(userId);
                addSupplierQuotes.add(supplierQuote);
            }
            if (quoteInquiryDetailsIdS.contains(i.getId())){
                if (inquiryOrderDetailsHashMap.get(i.getId()).getState().intValue() !=  OrderConstants.InquiryState.ACCEPTED.code
                        && inquiryOrderDetailsHashMap.get(i.getId()).getState().intValue() !=  OrderConstants.InquiryState.VOIDED.code){
                    //处理询价单详情
                    InquiryOrderDetails inquiryOrderDetails1 = new InquiryOrderDetails();
                    inquiryOrderDetails1.setId(i.getId());
                    inquiryOrderDetails1.setState(OrderConstants.InquiryState.QUOTED.code);
                    inquiryOrderDetails1.setProductId(Long.valueOf(productInquiryMap.get(i.getId())));
                    inquiryOrderDetails1.setUpdatedAt(now);
                    inquiryOrderDetails1.setUpdatedBy(userId);
                    inquiryOrderDetailsList.add(inquiryOrderDetails1);
                }

            }
        }
        //报价单保存或更新
        if (!CollectionUtils.isEmpty(addSupplierQuotes)){
            boolean result1 = saveBatch(addSupplierQuotes);
            if (!result1){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_QUOTE);
            }
        }
        if (!CollectionUtils.isEmpty(updateSupplierQuotes)){
            boolean result2 = updateBatchById(updateSupplierQuotes);
            if (!result2){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_QUOTE);
            }
        }

        if (!CollectionUtils.isEmpty(inquiryOrderDetailsList)){
            //更新询价单详情状态
            boolean result3 = inquiryOrderDetailsService.updateBatchById(inquiryOrderDetailsList);
            if (!result3){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_QUOTE);
            }
        }
        if (inquiryOrder.getState().intValue() != OrderConstants.InquiryState.ACCEPTED.code
                && inquiryOrder.getState().intValue() != OrderConstants.InquiryState.VOIDED.code){
            //更新询价单
            inquiryOrder.setState(OrderConstants.InquiryState.QUOTED.code);
            inquiryOrder.setUpdatedAt(now);
            inquiryOrder.setUpdatedBy(userId);
            boolean result4 = inquiryOrderService.updateById(inquiryOrder);
            if (!result4){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_QUOTE);
            }
        }

        //供应商报价埋点
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("order");
        triggerMsgRequest.setScene("supplierSubmitQuote");

        JSONObject qywxParam = new JSONObject();
        //企业微信
        qywxParam.put("msgtype", "template_card");
        JSONObject templateCard = new JSONObject();
        templateCard.put("card_type", "text_notice");
        JSONObject mainTitle = new JSONObject();
        mainTitle.put("title", "供应商提交报价");
        mainTitle.put("desc", "订单已报价");
        templateCard.put("main_title", mainTitle);
        List<JSONObject> horizontalContentList = new ArrayList<>();
        JSONObject keyName1 = new JSONObject();
        keyName1.put("keyname", "供应商名称");
        keyName1.put("value", commonService.getUserInfo().get("name").toString().replaceAll("\"", ""));
        horizontalContentList.add(keyName1);
        JSONObject keyName2 = new JSONObject();
        keyName2.put("keyname", "供应商账号");
        keyName2.put("value", commonService.getUserInfo().get("mobile").toString().replaceAll("\"", ""));
        horizontalContentList.add(keyName2);
        JSONObject keyName3 = new JSONObject();
        keyName3.put("keyname", "询价单号");
        keyName3.put("value", inquiryOrder.getInquiryCode());
        horizontalContentList.add(keyName3);
        JSONObject keyName4 = new JSONObject();
        keyName4.put("keyname", "报价时间");
        keyName4.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
        horizontalContentList.add(keyName4);
        templateCard.put("horizontal_content_list", horizontalContentList);

        JSONObject emphasisContent = new JSONObject();
        emphasisContent.put("title","￥ " + allQuotePrice);
        emphasisContent.put("desc", "商品行数:" + inquiryOrder.getItems());
        templateCard.put("emphasis_content", emphasisContent);

        List<JSONObject> jumpList = new ArrayList<>();
        JSONObject jumpList1 = new JSONObject();
        jumpList1.put("type", 1);
        jumpList1.put("title", "跳转惠采");
        jumpList1.put("url", odsUrl + "/#/supply-manager/subsidiary/customer-manage/enquiry?key=" + URLUtil.encode(inquiryOrder.getInquiryCode()));
        jumpList.add(jumpList1);
        templateCard.put("jump_list", jumpList);

        JSONObject cardAction = new JSONObject();
        cardAction.put("type", 1);
        cardAction.put("url",  odsUrl + "/#/supply-manager/subsidiary/customer-manage/enquiry?key=" + URLUtil.encode(inquiryOrder.getInquiryCode()));
        templateCard.put("card_action", cardAction);
        qywxParam.put("template_card", templateCard);
        triggerMsgRequest.setQywxParam(qywxParam);

        msgClient.triggerMsg(triggerMsgRequest);
        return true;
    }

    @Override
    @Transactional
    public Boolean save(SupplierQuoteSaveDTO supplierQuoteSaveDTO) {
        InquiryOrder inquiryOrder = inquiryOrderMapper.selectById(supplierQuoteSaveDTO.getInquiryOrderId());
        //检查询价单是否存在
        if (inquiryOrder == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }
        LocalDateTime now = LocalDateTime.now();
        if (inquiryOrder.getInquiryExpireTime().isBefore(now)){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.EXPIRE_INQUIRY_ORDER);
        }
        if (!CollectionUtils.isEmpty(supplierQuoteSaveDTO.getInquiryOrderDetailsSaveDTOS())){
            List<Integer> ids = supplierQuoteSaveDTO.getInquiryOrderDetailsSaveDTOS().stream().map(InquiryOrderDetailsSaveDTO::getId).collect(Collectors.toList());
            //判断是否存在询价单详情记录，不存在则抛出异常
            QueryWrapper<InquiryOrderDetails> queryWrapper = new QueryWrapper<>();
            queryWrapper.in("id", ids);
            List<InquiryOrderDetails> inquiryOrderDetails = inquiryOrderDetailsMapper.selectList(queryWrapper);
            if (CollectionUtils.isEmpty(inquiryOrderDetails)){
                //询价详情单不存在
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER_DETAILS);
            }
            if (inquiryOrderDetails.size() != supplierQuoteSaveDTO.getInquiryOrderDetailsSaveDTOS().size()){
                //询价详情单 不等于 入参的询价单
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER_DETAILS);
            }
            //获取询价单id列表
            List<Integer> inquriyOrderIds = inquiryOrderDetails.stream().map(InquiryOrderDetails::getInquiryOrderId).collect(Collectors.toList());
            if (inquriyOrderIds.stream().anyMatch(num -> num != supplierQuoteSaveDTO.getInquiryOrderId().intValue())){
                //判断询价单详情是否与询价单匹配上
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER_DETAILS);
            }
            //判断是否存在供应商 已报价
            QueryWrapper<SupplierQuote> supplierQuoteQueryWrapper = new QueryWrapper<>();
            supplierQuoteQueryWrapper.in("inquiry_order_details_id", ids);
            supplierQuoteQueryWrapper.eq("supplier_id", commonService.getSupplierId());
            List<SupplierQuote> querySupplierQuotes = supplierQuoteMapper.selectList(supplierQuoteQueryWrapper);

            //询价单详情id 和 报价单id
            HashMap<Integer, Integer> hashMap = new HashMap<>();
            if (!CollectionUtils.isEmpty(querySupplierQuotes)){
                for (SupplierQuote s : querySupplierQuotes) {
                    if (s.getState().equals(OrderConstants.SupplierQuoteStatus.QUOTED.code)){
                        throw BusinessException.newInstance(PurchaseOrderExceptionDesc.EXIST_SUPPLIER_QUOTE);
                    }else {
                        hashMap.put(s.getInquiryOrderDetailsId(), s.getId());
                    }
                }
            }
            //保存报价单
            List<SupplierQuote> addSupplierQuotes = new ArrayList<>();
            List<SupplierQuote> updateSupplierQuotes = new ArrayList<>();
            for (InquiryOrderDetailsSaveDTO i : supplierQuoteSaveDTO.getInquiryOrderDetailsSaveDTOS()) {
                SupplierQuote supplierQuote = new SupplierQuote();
                supplierQuote.setInquiryOrderId(supplierQuoteSaveDTO.getInquiryOrderId());
                supplierQuote.setInquiryOrderDetailsId(i.getId());
                supplierQuote.setSupplierId(commonService.getSupplierId());
                supplierQuote.setDeliveryDate(i.getDeliveryDate());
                supplierQuote.setState(OrderConstants.SupplierQuoteStatus.PENDING.code);
                supplierQuote.setSupplyPrice(i.getSupplyPrice());
                supplierQuote.setQuotePrice(i.getQuotePrice());
                supplierQuote.setStock(i.getStock());
                supplierQuote.setSuggestedBrandName(i.getSuggestedBrandName());
                supplierQuote.setSuggestedProductType(i.getSuggestedProductType());
                supplierQuote.setSuggestedProductSku(i.getSuggestedProductSku());
                supplierQuote.setSuggestedProductName(i.getSuggestedProductName());
                supplierQuote.setInquiryOrderState(OrderConstants.InquiryOrderStatus.PENDING.code);
                if (hashMap.keySet().contains(i.getId())){
                    supplierQuote.setId(hashMap.get(i.getId()));
                    supplierQuote.setUpdatedBy(commonService.getUserId());
                    supplierQuote.setUpdatedAt(now);
                    updateSupplierQuotes.add(supplierQuote);
                }else {
                    supplierQuote.setCreatedAt(now);
                    supplierQuote.setCreatedBy(commonService.getUserId());
                    addSupplierQuotes.add(supplierQuote);
                }
            }
            boolean result1 = false, result2 = false;
            if (CollectionUtils.isEmpty(addSupplierQuotes)){
                result1 = true;
            }else {
                result1 = saveBatch(addSupplierQuotes);
            }
            if (CollectionUtils.isEmpty(updateSupplierQuotes)){
                result2 = true;
            }else {
                result2 = updateBatchById(updateSupplierQuotes);
            }
            if (!result1 || !result2){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_SAVE_QUOTE);
            }
        }
        return true;
    }

    @Override
    @Transactional
    public Boolean confirmAdd(ConfirmQuoteAddDTO confirmQuoteAddDTO) {
        InquiryOrder inquiryOrder = inquiryOrderService.getById(confirmQuoteAddDTO.getInquiryOrderId());
        //检查询价单是否存在
        if (inquiryOrder == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }
        //运营端确认报价不需要管询价单是否过期
        LocalDateTime now = LocalDateTime.now();
        //2023/11/07 调整逻辑 存在有【待报价】 【已报价】的商品
        if (inquiryOrder.getState().intValue() == OrderConstants.InquiryState.VOIDED.code){
            //询价单状态 为【作废】，不允许报价
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.CANNOT_QUOTE);
        }
        List<InquiryDetailAndSupplierQuoteDTO> inquiryDetailAndSupplierQuoteDTOS = confirmQuoteAddDTO.getInquiryDetailAndSupplierQuoteDTOS();
        //是否确认的商品详情
        HashMap<Integer, Integer> detailConfirmStateMap = new HashMap<>();
        if (!CollectionUtils.isEmpty(inquiryDetailAndSupplierQuoteDTOS)){
            List<Integer> inquiryOrderDetailsIdList = new ArrayList<>();
            List<Integer> supplierQuoteIdList = new ArrayList<>();
            HashMap<Integer, Integer> detailQuoteMap = new HashMap<>();
            HashMap<Integer, BigDecimal> quotePriceMap = new HashMap<>();
            for (InquiryDetailAndSupplierQuoteDTO i : inquiryDetailAndSupplierQuoteDTOS) {
                inquiryOrderDetailsIdList.add(i.getInquriyDetailsId());
                supplierQuoteIdList.add(i.getSupplierQuoteId());
                detailQuoteMap.put(i.getInquriyDetailsId(), i.getSupplierQuoteId());
                quotePriceMap.put(i.getSupplierQuoteId(), i.getQuotePrice());
            }
            List<InquiryOrderDetails> inquiryOrderDetails = inquiryOrderDetailsMapper.selectBatchIds(inquiryOrderDetailsIdList);
            List<SupplierQuote> supplierQuotes = supplierQuoteMapper.selectBatchIds(supplierQuoteIdList);
            if (CollectionUtils.isEmpty(inquiryOrderDetails)){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER_DETAILS);
            }
            if (CollectionUtils.isEmpty(supplierQuotes)){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_SUPPLIER_QUOTE);
            }
            HashMap<Integer, Integer> detailIdAndNumMap = new HashMap<>();
            //获取可以重新比较的id，只有报价中和已报价才可以
            List<Integer> canSubmitDetailList = new ArrayList<>();
            BigDecimal allQuotePrice = new BigDecimal(0);
            if (!CollectionUtils.isEmpty(inquiryOrderDetails)){
                for (InquiryOrderDetails i : inquiryOrderDetails) {
                    detailIdAndNumMap.put(i.getId(), i.getNum());
                    if (i.getState().intValue() == OrderConstants.InquiryState.IN_QUOTATION.code
                            || i.getState().intValue() == OrderConstants.InquiryState.QUOTED.code){
                        canSubmitDetailList.add(i.getId());
                    }
                    //总金额 增加已成交金额
                    if (i.getState().intValue() == OrderConstants.InquiryState.ACCEPTED.code){
                        allQuotePrice = allQuotePrice.add(i.getQuotePrice().multiply(new BigDecimal(i.getNum())));
                    }
                    detailConfirmStateMap.put(i.getId(), i.getConfirmState());
                }
            }
            //如果可报价的数据为空
//            if (CollectionUtils.isEmpty(canSubmitDetailList)){
//                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_SUBMIT_INQUIRY_DETAILS);
//            }
            String userId = commonService.getUserId();
            List<InquiryOrderDetails> inquiryOrderDetailsList = new ArrayList<>();
            List<ProductAuditDTO> productAuditDTOS = new ArrayList<>();
            for (SupplierQuote s: supplierQuotes) {
                //检查报价id 与 报价产品是否相对应
                if (s.getId().intValue() != detailQuoteMap.get(s.getInquiryOrderDetailsId()).intValue()){
                    throw BusinessException.newInstance(PurchaseOrderExceptionDesc.INQUIRY_ORDER_NOT_EXIST_SUPPLIER_QUOTE);
                }
                if (!canSubmitDetailList.contains(s.getInquiryOrderDetailsId())){
                    continue;
                }
                ProductAuditDTO productAuditDTO = new ProductAuditDTO();
                productAuditDTO.setId(s.getProductApplyId());
                productAuditDTO.setAuditStatus(1);
                productAuditDTOS.add(productAuditDTO);

                InquiryOrderDetails inquiryOrderDetails1 = new InquiryOrderDetails();
                inquiryOrderDetails1.setId(s.getInquiryOrderDetailsId());
                inquiryOrderDetails1.setProductApplyId(s.getProductApplyId());
                inquiryOrderDetails1.setStock(s.getStock());
                inquiryOrderDetails1.setSupplyPrice(s.getSupplyPrice());
                inquiryOrderDetails1.setQuotePrice(quotePriceMap.get(s.getId()));
                inquiryOrderDetails1.setDeliveryDate(s.getDeliveryDate());
                inquiryOrderDetails1.setSubtotal(inquiryOrderDetails1.getQuotePrice().multiply(new BigDecimal(detailIdAndNumMap.get(s.getInquiryOrderDetailsId()))));
                inquiryOrderDetails1.setSupplierId(s.getSupplierId());
                inquiryOrderDetails1.setSupplierQuoteId(s.getId());
                //提交报价单 字段更新
                inquiryOrderDetails1.setState(OrderConstants.InquiryState.QUOTED.code);
                inquiryOrderDetails1.setConfirmState(OrderConstants.InquiryConfirmState.CONFIRMED.code);
                inquiryOrderDetails1.setQuoteTime(now);
                inquiryOrderDetails1.setQuoteExpireTime(now.plusDays(confirmQuoteAddDTO.getDay()));
                inquiryOrderDetails1.setConfirmTime(now);
                inquiryOrderDetails1.setSuggestedBrandName(s.getSuggestedBrandName());
                inquiryOrderDetails1.setSuggestedProductSku(s.getSuggestedProductSku());
                inquiryOrderDetails1.setSuggestedProductType(s.getSuggestedProductType());
                inquiryOrderDetails1.setSuggestedProductName(s.getSuggestedProductName());

                inquiryOrderDetails1.setUpdatedAt(now);
                inquiryOrderDetails1.setUpdatedBy(userId);
                inquiryOrderDetailsList.add(inquiryOrderDetails1);

                //商品变为已确认
                detailConfirmStateMap.put(s.getInquiryOrderDetailsId(), inquiryOrderDetails1.getConfirmState());

                allQuotePrice = allQuotePrice.add(inquiryOrderDetails1.getQuotePrice().multiply(new BigDecimal(detailIdAndNumMap.get(s.getInquiryOrderDetailsId()))));
            }

            if (!CollectionUtils.isEmpty(inquiryOrderDetailsList)){
                if (!CollectionUtils.isEmpty(productAuditDTOS)){
                    //提交报价 即 审核
                    HashMap<String, Long> productIdMap = productClient.productQuoteAudit(productAuditDTOS);
                    if (productIdMap != null && productIdMap.size() > 0){
                        for (InquiryOrderDetails inquiryOrderDetails1: inquiryOrderDetailsList) {
                            inquiryOrderDetails1.setPublicProductId(productIdMap.get(inquiryOrderDetails1.getProductApplyId()));
                        }
                    }
                }
                //保存报价详情
                boolean result = inquiryOrderDetailsService.updateBatchById(inquiryOrderDetailsList);
                if (!result){
                    throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_SUBMIT_QUOTE);
                }
                if (inquiryOrder.getState().intValue() != OrderConstants.InquiryState.ACCEPTED.code){
                    inquiryOrder.setState(OrderConstants.InquiryState.QUOTED.code);
                }
                inquiryOrder.setConfirmState(OrderConstants.InquiryConfirmState.CONFIRMED.code);
            }
            inquiryOrder.setQuoteExpireTime(now.plusDays(confirmQuoteAddDTO.getDay()));
            inquiryOrder.setQuoteTime(now);
            inquiryOrder.setDeliveryDate(confirmQuoteAddDTO.getDeliveryDate());
            inquiryOrder.setQuoteItems(inquiryDetailAndSupplierQuoteDTOS.size());
            inquiryOrder.setAllQuotePrice(allQuotePrice);
            inquiryOrder.setUpdatedAt(now);
            inquiryOrder.setUpdatedBy(userId);
            boolean b = inquiryOrderService.updateById(inquiryOrder);
            if (!b){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_SUBMIT_QUOTE);
            }

        }

        if (!CollectionUtils.isEmpty(confirmQuoteAddDTO.getInquiryOrderDetails())){
            QueryWrapper<InquiryOrderDetails> queryWrapper = new QueryWrapper();
            queryWrapper.in("id", confirmQuoteAddDTO.getInquiryOrderDetails());
            queryWrapper.eq("inquiry_order_id", confirmQuoteAddDTO.getInquiryOrderId());
            List<InquiryOrderDetails> inquiryOrderDetails = inquiryOrderDetailsMapper.selectList(queryWrapper);
            if (!CollectionUtils.isEmpty(inquiryOrderDetails)){
                List<Integer> ids = inquiryOrderDetails.stream().map(InquiryOrderDetails::getId).collect(Collectors.toList());
                inquiryOrderDetailsMapper.emptyQuote(ids, commonService.getUserId());
                for(Integer id : ids){
                    detailConfirmStateMap.put(id, OrderConstants.InquiryConfirmState.UN_CONFIRMED.code);
                }
            }
        }
        boolean isExistConfirm = false;
        for (Map.Entry<Integer, Integer> entry : detailConfirmStateMap.entrySet()){
            if (entry.getValue().intValue() == OrderConstants.InquiryConfirmState.CONFIRMED.code){
                isExistConfirm = true;
                break;
            }
        }
        if (!isExistConfirm){
            //清空询价单的数据
            inquiryOrderMapper.emptyQuote(inquiryOrder.getId(), commonService.getUserId());
        }
        //运营端确认报价埋点
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        triggerMsgRequest.setBusiness("order");
        triggerMsgRequest.setScene("userConfirmQuote");
        JSONObject smsParam = new JSONObject();
        smsParam.put("phone", inquiryOrderMapper.selectPhoneByCustId(inquiryOrder.getCustId()));
        smsParam.put("code", inquiryOrder.getInquiryCode());
        triggerMsgRequest.setSmsParam(smsParam);

        //微信公众号消息
        JSONObject wxpfParam = new JSONObject();
        wxpfParam.put("unionid", inquiryOrderMapper.selectUnionIdByCustId(inquiryOrder.getCustId()));

        JSONObject k1 = new JSONObject();
        JSONObject thing12 = new JSONObject();
        thing12.put("value", inquiryOrder.getTitle());
        k1.put("thing12", thing12);
        JSONObject character_string4 = new JSONObject();
        character_string4.put("value", inquiryOrder.getInquiryCode());
        k1.put("character_string4", character_string4);
        JSONObject amount9 = new JSONObject();
        amount9.put("value", inquiryOrder.getAllQuotePrice().setScale(2, BigDecimal.ROUND_HALF_UP) + "元");
        k1.put("amount9", amount9);

        wxpfParam.put("data", k1);
        triggerMsgRequest.setWxpfParam(wxpfParam);
        msgClient.triggerMsg(triggerMsgRequest);
        return true;
    }

    @Override
    @Transactional
    public Boolean confirmSave(ConfirmQuoteSaveDTO confirmQuoteSaveDTO) {
        if (CollectionUtils.isEmpty(confirmQuoteSaveDTO.getInquiryDetailAndSupplierQuoteDTOS()) && CollectionUtils.isEmpty(confirmQuoteSaveDTO.getInquiryOrderDetails())){
            return true;
        }
        InquiryOrder inquiryOrder = inquiryOrderService.getById(confirmQuoteSaveDTO.getInquiryOrderId());
        //检查询价单是否存在
        if (inquiryOrder == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }
        LocalDateTime now = LocalDateTime.now();
        if (inquiryOrder.getInquiryExpireTime().isBefore(now)){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.EXPIRE_INQUIRY_ORDER);
        }
        if (inquiryOrder.getConfirmState().intValue() == OrderConstants.InquiryConfirmState.CONFIRMED.code
                || (inquiryOrder.getState().intValue() != OrderConstants.InquiryState.IN_QUOTATION.code
                && inquiryOrder.getState().intValue() != OrderConstants.InquiryState.QUOTED.code)){
            //00 10
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.CANNOT_SAVE_QUOTE);
        }
        List<InquiryDetailAndSupplierQuoteDTO> inquiryDetailAndSupplierQuoteDTOS = confirmQuoteSaveDTO.getInquiryDetailAndSupplierQuoteDTOS();
        if (!CollectionUtils.isEmpty(inquiryDetailAndSupplierQuoteDTOS)){
            List<Integer> inquiryOrderDetailsIdList = new ArrayList<>();
            List<Integer> supplierQuoteIdList = new ArrayList<>();
            HashMap<Integer, Integer> detailQuoteMap = new HashMap<>();
            HashMap<Integer, BigDecimal> quotePriceMap = new HashMap<>();
            for (InquiryDetailAndSupplierQuoteDTO i : inquiryDetailAndSupplierQuoteDTOS) {
                inquiryOrderDetailsIdList.add(i.getInquriyDetailsId());
                supplierQuoteIdList.add(i.getSupplierQuoteId());
                detailQuoteMap.put(i.getInquriyDetailsId(), i.getSupplierQuoteId());
                quotePriceMap.put(i.getSupplierQuoteId(), i.getQuotePrice());
            }
            List<InquiryOrderDetails> inquiryOrderDetails = inquiryOrderDetailsMapper.selectBatchIds(inquiryOrderDetailsIdList);
            List<SupplierQuote> supplierQuotes = supplierQuoteMapper.selectBatchIds(supplierQuoteIdList);
            if (CollectionUtils.isEmpty(inquiryOrderDetails)){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER_DETAILS);
            }
            if (CollectionUtils.isEmpty(supplierQuotes)){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_SUPPLIER_QUOTE);
            }
            HashMap<Integer, Integer> detailIdAndNumMap = new HashMap<>();
            if (!CollectionUtils.isEmpty(inquiryOrderDetails)){
                for (InquiryOrderDetails i : inquiryOrderDetails) {
                    detailIdAndNumMap.put(i.getId(), i.getNum());
                }
            }
            String userId = commonService.getUserId();
            List<InquiryOrderDetails> inquiryOrderDetailsList = new ArrayList<>();
            for (SupplierQuote s: supplierQuotes) {
                //检查报价id 与 报价产品是否相对应
                if (s.getId().intValue() != detailQuoteMap.get(s.getInquiryOrderDetailsId()).intValue()){
                    throw BusinessException.newInstance(PurchaseOrderExceptionDesc.INQUIRY_ORDER_NOT_EXIST_SUPPLIER_QUOTE);
                }
                InquiryOrderDetails inquiryOrderDetails1 = new InquiryOrderDetails();
                inquiryOrderDetails1.setId(s.getInquiryOrderDetailsId());
                inquiryOrderDetails1.setSupplierQuoteId(s.getId());
                inquiryOrderDetails1.setSupplierId(s.getSupplierId());
                inquiryOrderDetails1.setQuotePrice(quotePriceMap.get(s.getId()));
                inquiryOrderDetails1.setSuggestedBrandName(s.getSuggestedBrandName());
                inquiryOrderDetails1.setSuggestedProductSku(s.getSuggestedProductSku());
                inquiryOrderDetails1.setSuggestedProductType(s.getSuggestedProductType());
                inquiryOrderDetails1.setSuggestedProductName(s.getSuggestedProductName());
                inquiryOrderDetails1.setUpdatedAt(now);
                inquiryOrderDetails1.setUpdatedBy(userId);
                inquiryOrderDetailsList.add(inquiryOrderDetails1);
            }
            //保存报价单
            boolean result = inquiryOrderDetailsService.updateBatchById(inquiryOrderDetailsList);
            if (!result){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_SAVE_QUOTE);
            }
        }
        if (!CollectionUtils.isEmpty(confirmQuoteSaveDTO.getInquiryOrderDetails())){
            QueryWrapper<InquiryOrderDetails> queryWrapper = new QueryWrapper();
            queryWrapper.in("id", confirmQuoteSaveDTO.getInquiryOrderDetails());
            queryWrapper.eq("inquiry_order_id", confirmQuoteSaveDTO.getInquiryOrderId());
            List<InquiryOrderDetails> inquiryOrderDetails = inquiryOrderDetailsMapper.selectList(queryWrapper);
            if (!CollectionUtils.isEmpty(inquiryOrderDetails)){
                List<Integer> ids = inquiryOrderDetails.stream().map(InquiryOrderDetails::getId).collect(Collectors.toList());
                inquiryOrderDetailsMapper.emptyQuote(ids, commonService.getUserId());
            }
        }
        return true;
    }

}
