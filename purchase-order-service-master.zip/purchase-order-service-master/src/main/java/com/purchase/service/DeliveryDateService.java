package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.DeliveryDate;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.DeliveryDateAddDTO;
import com.purchase.service.dto.DeliveryDatePageDTO;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-05-28
 */
public interface DeliveryDateService extends IService<DeliveryDate> {

    public Integer add(DeliveryDateAddDTO deliveryDateAddDTO);

    public Page<DeliveryDate> queryList(DeliveryDatePageDTO deliveryDatePageDTO);
}
