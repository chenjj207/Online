package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 
* </p>
*
* @author jidonglin
* @since 2024-05-28
*/
@Data
public class DeliveryDateAddDTO {

    @Schema(description = "货期")
    private String deliveryDate;

}
