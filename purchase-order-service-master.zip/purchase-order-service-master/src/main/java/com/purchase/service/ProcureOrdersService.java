package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.ProcureOrders;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.CancelProcureOrderDTO;
import com.purchase.service.dto.ConfirmProcureOrderDTO;
import com.purchase.service.dto.ProcureOrderPageDTO;
import com.purchase.service.vo.ProcureOrderTabVO;
import java.util.List;

/**
 * <p>
 * 采购订单表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
public interface ProcureOrdersService extends IService<ProcureOrders> {

    public Page<ProcureOrders> page(ProcureOrderPageDTO procureOrderPageDTO);

    public List<ProcureOrderTabVO> countTab(ProcureOrderPageDTO procureOrderPageDTO);

    public Boolean cancel(CancelProcureOrderDTO cancelProcureOrderDTO);

    public Boolean confirm(ConfirmProcureOrderDTO confirmProcureOrderDTO);

    public ProcureOrders query(Integer id);
}
