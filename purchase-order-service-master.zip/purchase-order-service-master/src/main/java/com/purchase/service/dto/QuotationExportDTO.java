package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 报价单导出
 * @date 2023/9/4  15:51
 */
@Schema(title = "报价单导出")
@Data
public class QuotationExportDTO {
    @Schema(description = "合计 需求数量")
    @NotNull(message = "合计需求数量不能为空")
    private Long allNum;

    @Schema(description = "合计 小计")
    @NotNull(message = "合计小计不能为空")
    private BigDecimal allSubtotal;

    @Schema(description = "合计 库存")
    @NotNull(message = "合计库存数量不能为空")
    private Long allStock;

    @Schema(description = "订单号")
    private String inquiryOrderCode;

    @Schema(description = "询价日期")
    private String inquiryTime;

    @Schema(description = "询价列表")
    @NotEmpty(message = "未选择商品")
    private List<ProductInqueryDTO> productInqueryDTOS;
}
