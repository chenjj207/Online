package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/25  13:59
 */
@Data
public class InquiryDetailAndSupplierQuoteDTO {
    @Schema(description = "询价产品详情id")
    @NotNull(message = "询价产品详情id不能为空")
    private Integer inquriyDetailsId;

    @Schema(description = "供应商报价id")
    @NotNull(message = "供应商报价id不能为空")
    private Integer supplierQuoteId;

    @Schema(description = "报价/惠采价")
    @NotNull(message = "报价不能为空")
    private BigDecimal quotePrice;
}
