package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Product;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.InquiryOrderIdDTO;
import com.purchase.service.dto.ProductBatchDTO;
import com.purchase.service.dto.ProductPageDTO;
import com.purchase.service.dto.QuotationExportDTO;
import com.purchase.service.vo.NeedExportVO;
import com.purchase.service.vo.ParseResultVO;
import com.purchase.service.vo.ProductPageVO;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 惠采商品列表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-08-31
 */
public interface ProductService extends IService<Product> {

    public NeedExportVO needExport(MultipartFile multipartFile);

    public ParseResultVO ocrExport(MultipartFile multipartFile);

    public ParseResultVO textParse(ProductBatchDTO productBatchDTO);

    public void export(QuotationExportDTO quotationExportDTO, HttpServletResponse response);

    public void exportInquiry(QuotationExportDTO quotationExportDTO, HttpServletResponse response);

    public void adminExportInquriy(Integer inquiryOrderId, HttpServletResponse response);

    public Page<Product> page(ProductPageDTO productPageDTO);

    public Page<ProductPageVO> pageSupplier(ProductPageDTO productPageDTO);

    public List<ProductPageVO> productQuote(Integer productId);

}
