package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Orders;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.CancelOrderDTO;
import com.purchase.service.dto.OrderAddDTO;
import com.purchase.service.dto.OrderPageDTO;
import com.purchase.service.vo.OrdersTabVO;

import java.util.List;

/**
 * <p>
 * 订单表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-12
 */
public interface OrdersService extends IService<Orders> {

    public String orderAdd(OrderAddDTO orderAddDTO);

    public Page<Orders> page(OrderPageDTO orderPageDTO);

    public List<OrdersTabVO> count(OrderPageDTO orderPageDTO);

    public Boolean cancel(CancelOrderDTO cancelOrderDTO);

    public Boolean adminCancel(CancelOrderDTO cancelOrderDTO);

    public Orders getOrdersById(Integer id);
}
