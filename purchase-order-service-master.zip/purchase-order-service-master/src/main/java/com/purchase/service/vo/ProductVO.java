package com.purchase.service.vo;

import com.purchase.entity.Product;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/1  11:09
 */
@Data
public class ProductVO extends Product {

    @Schema(description = "我的编码")
    private String productCode;
    @Schema(description = "需求数量")
    private Integer num;
    @Schema(description = "期望货期")
    private String expectDeliveryDate;
    @Schema(description = "备注")
    private String remark;
    @Schema(description = "单位")
    private String unit;
    @Schema(description = "错误信息")
    private String error;
}
