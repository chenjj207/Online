package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.metadata.fill.FillConfig;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.PutObjectRequest;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.client.CustClient;
import com.purchase.client.dto.QywxMsgDTO;
import com.purchase.common.OrderConstants;
import com.purchase.config.OssConf;
import com.purchase.config.PurchaseOrderExceptionDesc;
import com.purchase.entity.InquiryOrder;
import com.purchase.entity.InquiryOrderDetails;
import com.purchase.entity.OrderDetails;
import com.purchase.entity.Orders;
import com.purchase.mapper.InquiryOrderDetailsMapper;
import com.purchase.mapper.OrdersMapper;
import com.purchase.mapper.ProductMapper;
import com.purchase.service.*;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.*;
import com.purchase.service.vo.OrdersTabVO;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 订单表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-12
 */
@Service
public class OrdersServiceImpl extends ServiceImpl<OrdersMapper, Orders> implements OrdersService {

    @Autowired
    InquiryOrderService inquiryOrderService;
    @Autowired
    InquiryOrderDetailsService inquiryOrderDetailsService;
    @Autowired
    CommonService commonService;
    @Autowired
    OrderDetailsService orderDetailsService;

    @Resource
    InquiryOrderDetailsMapper inquiryOrderDetailsMapper;
    @Resource
    OrdersMapper ordersMapper;
    @Resource
    ProductMapper productMapper;

    @Autowired
    OssConf ossConfig;

    @Autowired
    CustClient custClient;

    @Override
    @Transactional
    public String orderAdd(OrderAddDTO orderAddDTO) {
        JSONObject custInfo = commonService.getCustInfo();
        String urlPath = "purchase/custinquery/" +
                commonService.loginId() + ossConfig.getTmp() + "订单明细-" + custInfo.getString("company") + DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now())+".xlsx";
        List<ProductInqueryDTO> productInqueryDTOS = new ArrayList<>();
        String orderCode = null;
        LocalDateTime orderTime = null;
        Orders orders = null;
        if (StringUtils.equals(orderAddDTO.getTab(), "1")){
            //下单页面  1：发布单料
            if (CollectionUtils.isEmpty(orderAddDTO.getProductInqueryDTOS())){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.EMPTY_ORDER);
            }
            List<String> productIds = orderAddDTO.getProductInqueryDTOS().stream().map(ProductInqueryDTO::getProductId).collect(Collectors.toList());
            List<CommonProductDTO> commonProductDTOS = productMapper.selectCommonByIds(productIds);
            HashMap<String, String> productSupplierMap = new HashMap<>();
            for (CommonProductDTO c : commonProductDTOS) {
                if (StringUtils.isEmpty(c.getSupplierId())){
                    productSupplierMap.put(String.valueOf(c.getProductId()), productMapper.selectSelfSupplier());
                }else {
                    productSupplierMap.put(String.valueOf(c.getProductId()), c.getSupplierId());
                }
            }
            for (ProductInqueryDTO p : orderAddDTO.getProductInqueryDTOS()) {
                p.setSupplierId(productSupplierMap.get(p.getProductId()));
                ProductInqueryDTO p1 = new ProductInqueryDTO();
                BeanUtil.copyProperties(p, p1);
                productInqueryDTOS.add(p1);
            }
            orders = createOrderAndDetails(orderAddDTO, ossConfig.getOssUrl() + urlPath);
            orderCode = orders.getOrderCode();
            orderTime = orders.getCreatedAt();
        }else if (StringUtils.equals(orderAddDTO.getTab(), "2")){
            //下单页面 2：我的询价
            if (CollectionUtils.isEmpty(orderAddDTO.getInquiryOrderDetailsIds())){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.EMPTY_ORDER);
            }
            if (orderAddDTO.getInquiryOrderId() == null){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_NULL_ORDER_ID);
            }
            InquiryOrder inquiryOrder = inquiryOrderService.getById(orderAddDTO.getInquiryOrderId());
            if (inquiryOrder == null){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
            }

            List<InquiryOrderDetails> inquiryOrderDetails = inquiryOrderDetailsMapper.selectBatchIds(orderAddDTO.getInquiryOrderDetailsIds());
            if (CollectionUtils.isEmpty(inquiryOrderDetails)){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
            }
            LocalDateTime now = LocalDateTime.now();
            Integer allNum = 0;
            BigDecimal allSubtotal = new BigDecimal(0);
            int seriaNum = 1;
            for (InquiryOrderDetails i : inquiryOrderDetails) {
                if (i.getInquiryOrderId().intValue() != inquiryOrder.getId().intValue()){
                    throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EQUALS_ORDER_AND_DETAILS);
                }
                ProductInqueryDTO productInqueryDTO = new ProductInqueryDTO();
                BeanUtil.copyProperties(i, productInqueryDTO);
                productInqueryDTO.setProductId(String.valueOf(i.getPublicProductId()));
                productInqueryDTO.setPurchasePrice(i.getQuotePrice());
                productInqueryDTO.setSerialNum(seriaNum);
                seriaNum++;
                productInqueryDTOS.add(productInqueryDTO);
                if (i.getQuotePrice() == null || BigDecimal.ZERO.compareTo(i.getQuotePrice()) == 0){
                    //报价信息为空
                }
                i.setAcceptTime(now);
                i.setState(OrderConstants.InquiryState.ACCEPTED.code);
                i.setUpdatedAt(now);
                allNum += i.getNum();
                if (i.getSubtotal() != null){
                    allSubtotal.add(i.getSubtotal());
                }
            }
            orderAddDTO.setAllNum(allNum);
            orderAddDTO.setProductInqueryDTOS(productInqueryDTOS);
            //https://zyd-online-tenant-dev.oss-cn-shenzhen.aliyuncs.com/ + urlPath
            orders = createOrderAndDetails(orderAddDTO, ossConfig.getOssUrl() + urlPath);
            orderCode = orders.getOrderCode();
            orderTime = orders.getCreatedAt();
            inquiryOrder.setState(OrderConstants.InquiryState.ACCEPTED.code);
            inquiryOrderService.updateById(inquiryOrder);
            //更新询价单状态及采纳时间
            inquiryOrderDetailsService.updateBatchById(inquiryOrderDetails);
        }else {
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_ORDER_TAB);
        }

        if (CollectionUtils.isEmpty(productInqueryDTOS)){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_INQUIRY_ORDER);
        }

        //上传报价单文件到oss
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ClassPathResource resource = new ClassPathResource("template/quotationInquiryOrder.xlsx");
        try {
            XSSFWorkbook wb = new XSSFWorkbook(resource.getInputStream());
            XSSFSheet sheet = wb.getSheetAt(0);

            Row orderNoRow = sheet.getRow(1);
            Cell orderNoCell = orderNoRow.getCell(1);
            orderNoCell.setCellValue(orderCode);

            Row orderDateRow = sheet.getRow(1);
            Cell orderDateCell = orderDateRow.getCell(6);
            orderDateCell.setCellValue(DateUtil.format(orderTime, "yyyy/MM/dd HH:mm:ss"));

            Row companyRow = sheet.getRow(3);
            Cell companyCell = companyRow.getCell(6);
            companyCell.setCellValue(custInfo.getString("company"));

            Row linkmanRow = sheet.getRow(4);
            Cell linkmanCell = linkmanRow.getCell(6);
            linkmanCell.setCellValue(custInfo.getString("linkman"));

            Row linkphoneRow = sheet.getRow(5);
            Cell linkphoneCell = linkphoneRow.getCell(6);
            linkphoneCell.setCellValue(custInfo.getString("linkphone"));

            Row addressRow = sheet.getRow(6);
            Cell addressCell = addressRow.getCell(6);
            addressCell.setCellValue(custInfo.getString("address"));

            XSSFCellStyle style = wb.createCellStyle();
            style.setBorderBottom(BorderStyle.THIN);
            style.setBorderTop(BorderStyle.THIN);
            style.setBorderLeft(BorderStyle.THIN);
            style.setBorderRight(BorderStyle.THIN);
            style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
            style.setTopBorderColor(IndexedColors.BLACK.getIndex());
            style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
            style.setRightBorderColor(IndexedColors.BLACK.getIndex());

            for (int i = 0; i <= productInqueryDTOS.size(); i++) {
                int j = 8 + i;
                Row row = sheet.createRow(j);
                Cell serialNumCell = row.createCell(0);
                if (i == productInqueryDTOS.size()){
                    serialNumCell.setCellValue("");
                }else {
                    serialNumCell.setCellValue(productInqueryDTOS.get(i).getSerialNum().toString());
                }
                serialNumCell.setCellStyle(style);

                Cell productCodeCell = row.createCell(1);
                if (i == productInqueryDTOS.size()){
                    productCodeCell.setCellValue("");
                }else {
                    productCodeCell.setCellValue(productInqueryDTOS.get(i).getProductCode() == null ? "" : productInqueryDTOS.get(i).getProductCode());
                }
                productCodeCell.setCellStyle(style);

                Cell productNameCell = row.createCell(2);
                if (i == productInqueryDTOS.size()){
                    productNameCell.setCellValue("");
                }else {
                    productNameCell.setCellValue(productInqueryDTOS.get(i).getProductName() == null ? "" : productInqueryDTOS.get(i).getProductName());
                }
                productNameCell.setCellStyle(style);

                Cell brandNameCell = row.createCell(3);
                if (i == productInqueryDTOS.size()){
                    brandNameCell.setCellValue("总计");
                }else {
                    brandNameCell.setCellValue(productInqueryDTOS.get(i).getBrandName() == null ? "" : productInqueryDTOS.get(i).getBrandName());
                }
                brandNameCell.setCellStyle(style);

                Cell productTypeCell = row.createCell(4);
                if (i == productInqueryDTOS.size()){
                    productTypeCell.setCellValue("");
                }else {
                    productTypeCell.setCellValue(productInqueryDTOS.get(i).getProductType() == null ? "" : productInqueryDTOS.get(i).getProductType());
                }
                productTypeCell.setCellStyle(style);

                Cell productSkuCell = row.createCell(5);
                if (i == productInqueryDTOS.size()){
                    productSkuCell.setCellValue("");
                }else {
                    productSkuCell.setCellValue(productInqueryDTOS.get(i).getProductSku() == null ? "" : productInqueryDTOS.get(i).getProductSku());
                }
                productSkuCell.setCellStyle(style);

                Cell unitCell = row.createCell(6);
                if (i == productInqueryDTOS.size()){
                    unitCell.setCellValue("");
                }else {
                    unitCell.setCellValue(productInqueryDTOS.get(i).getUnit() == null ? "" : productInqueryDTOS.get(i).getUnit());
                }
                unitCell.setCellStyle(style);

                Cell numCell = row.createCell(7);
                if (i == productInqueryDTOS.size()){
                    numCell.setCellValue(orderAddDTO.getAllNum() == null ? "0" : orderAddDTO.getAllNum().toString());
                }else {
                    numCell.setCellValue(productInqueryDTOS.get(i).getNum() == null ? "0" : productInqueryDTOS.get(i).getNum().toString());
                }
                numCell.setCellStyle(style);

                Cell stockCell = row.createCell(8);
                if (i == productInqueryDTOS.size()){
                    stockCell.setCellValue(orderAddDTO.getAllStock() == null ? "0" : orderAddDTO.getAllStock().toString());
                }else {
                    stockCell.setCellValue(productInqueryDTOS.get(i).getStock() == null ? "0" : productInqueryDTOS.get(i).getStock().toString());
                }
                stockCell.setCellStyle(style);

                Cell purchasePriceCell = row.createCell(9);
                if (i == productInqueryDTOS.size()){
                    purchasePriceCell.setCellValue("");
                }else {
                    purchasePriceCell.setCellValue(productInqueryDTOS.get(i).getPurchasePrice() == null ? "0" : productInqueryDTOS.get(i).getPurchasePrice().toString());
                }
                purchasePriceCell.setCellStyle(style);

                Cell deliveryDateCell = row.createCell(10);
                if (i == productInqueryDTOS.size()){
                    deliveryDateCell.setCellValue("");
                }else {
                    deliveryDateCell.setCellValue(productInqueryDTOS.get(i).getDeliveryDate() == null ? "" : productInqueryDTOS.get(i).getDeliveryDate());
                }

                deliveryDateCell.setCellStyle(style);

                Cell subTotalCell = row.createCell(11);
                if (i == productInqueryDTOS.size()){
                    subTotalCell.setCellValue(orderAddDTO.getAllSubtotal()== null ? "0" : orderAddDTO.getAllSubtotal().toString());
                }else {
                    subTotalCell.setCellValue(productInqueryDTOS.get(i).getSubtotal() == null ? "0" : productInqueryDTOS.get(i).getSubtotal().toString());
                }
                subTotalCell.setCellStyle(style);

                Cell remarkCell = row.createCell(12);
                if (i == productInqueryDTOS.size()){
                    remarkCell.setCellValue("");
                }else {
                    remarkCell.setCellValue(productInqueryDTOS.get(i).getRemark() == null ? "0" : productInqueryDTOS.get(i).getRemark());
                }
                remarkCell.setCellStyle(style);
            }

            CellRangeAddress rangeAddress = new CellRangeAddress(10+productInqueryDTOS.size(), 10+productInqueryDTOS.size(), 0, 12);
            sheet.addMergedRegion(rangeAddress);
            Row allRemarkRow = sheet.createRow(10+productInqueryDTOS.size());
            Cell allRemarkRowCell = allRemarkRow.createCell(0);
            allRemarkRowCell.setCellValue("备注：报价单仅做参考，价格、货期、物流时效下单时均会由专属销售与您重新确认；若您对商品、货期存在疑问。可联系您的专属销售咨询；");

            //画图的顶级管理器
            XSSFDrawing patriarch = sheet.createDrawingPatriarch();

            /* anchor主要用于设置图片的属性
             * 该构造函数有8个参数
             * 前四个参数是控制图片在单元格的位置，分别是图片距离单元格left，top，right，bottom的像素距离
             * 后四个参数，前两个表示图片左上角所在的cellNum和 rowNum，后两个参数对应的表示图片右下角所在的cellNum和 rowNum，
             * excel中的cellNum和rowNum的index都是从0开始的
             * 设置二维码的属性
             */
            ClassPathResource resource1 = new ClassPathResource("template/qrCode.png");
            XSSFClientAnchor anchor = new XSSFClientAnchor(0, 0, 0, 0, 8, productInqueryDTOS.size() + 12, 9, productInqueryDTOS.size() + 12 + 5);
            patriarch.createPicture(anchor, wb.addPicture(resource1.getInputStream(), XSSFWorkbook.PICTURE_TYPE_PNG));

            Row guanzhuRemarkRow = sheet.createRow(17+productInqueryDTOS.size());
            Cell guanzhuRowCell = guanzhuRemarkRow.createCell(8);
            guanzhuRowCell.setCellValue("关注微信公众号，了解更多资讯。");

            wb.write(byteArrayOutputStream);

            ByteArrayInputStream byteArrayInput = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            //同步到oss
            OSS ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
            ossClient.putObject(new PutObjectRequest(ossConfig.getBucketName(), urlPath, byteArrayInput));
        } catch (IOException e) {
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_IO);
        }
        //发送企业微信消息
        QywxMsgDTO qywxMsgDTO = new QywxMsgDTO();
        qywxMsgDTO.setUrlPath(urlPath);
        qywxMsgDTO.setContent("联营慧会员【"+ StpUtil.getSession().getModel("info", JSONObject.class).getString("company")+"】提交了采购需求清单，请及时跟进处理");
        qywxMsgDTO.setFileName(FileUtil.mainName(urlPath) + "." + FileUtil.extName(urlPath));
        custClient.sendQyMsgWithFile(qywxMsgDTO);
        return orders.getId().toString();
    }

    @Override
    public Page<Orders> page(OrderPageDTO orderPageDTO) {
        return ordersMapper.page(orderPageDTO, orderPageDTO.buildPage());
    }

    @Override
    public List<OrdersTabVO> count(OrderPageDTO orderPageDTO) {
        List<OrdersTabVO> ordersTabVOS = new ArrayList<>();
        OrdersTabVO ordersTabVO1 = new OrdersTabVO();
        ordersTabVO1.setTab(OrderConstants.OrdersStatus.PENDING.code);
        orderPageDTO.setOrderStatus(OrderConstants.OrdersStatus.PENDING.code);
        ordersTabVO1.setCount(ordersMapper.count(orderPageDTO));
        ordersTabVOS.add(ordersTabVO1);

        OrdersTabVO ordersTabVO2 = new OrdersTabVO();
        ordersTabVO2.setTab(OrderConstants.OrdersStatus.CONFIRM.code);
        orderPageDTO.setOrderStatus(OrderConstants.OrdersStatus.CONFIRM.code);
        ordersTabVO2.setCount(ordersMapper.count(orderPageDTO));
        ordersTabVOS.add(ordersTabVO2);

        OrdersTabVO ordersTabVO3 = new OrdersTabVO();
        ordersTabVO3.setTab(OrderConstants.OrdersStatus.CANCEL.code);
        orderPageDTO.setOrderStatus(OrderConstants.OrdersStatus.CANCEL.code);
        ordersTabVO3.setCount(ordersMapper.count(orderPageDTO));
        ordersTabVOS.add(ordersTabVO3);

        return ordersTabVOS;
    }

    @Override
    public Boolean cancel(CancelOrderDTO cancelOrderDTO) {
        Orders orders = this.getById(cancelOrderDTO.getId());
        if (orders == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_ORDERS);
        }
        if (orders.getOrderStatus().intValue() != OrderConstants.OrdersStatus.PENDING.code){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.CAN_NOT_CANCEL_NOT_PENDING_ORDERS);
        }
        UpdateWrapper<Orders> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("order_status", OrderConstants.OrdersStatus.CANCEL.code)
                .set(StringUtils.isNotEmpty(cancelOrderDTO.getReason()), "reason", cancelOrderDTO.getReason())
                .set("cancel_time", LocalDateTime.now())
                .set("updated_by", commonService.loginId())
                .set("updated_at", LocalDateTime.now())
                .eq("id", cancelOrderDTO.getId());
        return this.update(updateWrapper);
    }

    @Override
    public Boolean adminCancel(CancelOrderDTO cancelOrderDTO) {
        Orders orders = this.getById(cancelOrderDTO.getId());
        if (orders == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_ORDERS);
        }
        if (orders.getOrderStatus().intValue() != OrderConstants.OrdersStatus.PENDING.code){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.CAN_NOT_CANCEL_NOT_PENDING_ORDERS);
        }
        UpdateWrapper<Orders> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("order_status", OrderConstants.OrdersStatus.CANCEL.code)
                .set(StringUtils.isNotEmpty(cancelOrderDTO.getReason()), "reason", cancelOrderDTO.getReason())
                .set("cancel_time", LocalDateTime.now())
                .set("updated_by", commonService.getUserId())
                .set("updated_at", LocalDateTime.now())
                .eq("id", cancelOrderDTO.getId());
        return this.update(updateWrapper);
    }

    @Override
    public Orders getOrdersById(Integer id) {
        return ordersMapper.selectOrdersById(id);
    }

    private Orders createOrderAndDetails(OrderAddDTO orderAddDTO, String url) {
        LocalDateTime now = LocalDateTime.now();
        String custId = commonService.loginId();
        Orders orders = new Orders();
        orders.setInquiryOrderId(orderAddDTO.getInquiryOrderId());
        orders.setCustId(Integer.parseInt(custId));
        orders.setOrderCode(OrderConstants.OrderNumPrefix.ORDER.code + System.currentTimeMillis());
        orders.setTotalAmount(orderAddDTO.getAllSubtotal());
        orders.setTotalNum(orderAddDTO.getAllNum());
        orders.setOrderStatus(OrderConstants.OrdersStatus.PENDING.code);
        orders.setOrderUrl(url);
        orders.setPayType(orderAddDTO.getPayType());
        orders.setPayStatus(OrderConstants.PayStatus.NOT_PAY.code);
        orders.setReceivingAddr(orderAddDTO.getReceivingAddr());
        orders.setReceivingMan(orderAddDTO.getReceivingMan());
        orders.setReceivingPhone(orderAddDTO.getReceivingPhone());
        orders.setReceivingZipcode(orderAddDTO.getReceivingZipcode());
        orders.setRemark(orderAddDTO.getRemark());
        orders.setSource(orderAddDTO.getTab().equals("1") ? OrderConstants.Source.CONTRACT.code : OrderConstants.Source.INQUIRY.code);
        orders.setCreatedAt(now);
        orders.setCreatedBy(custId);
        int count = ordersMapper.insert(orders);
        if (count != 1){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_ADD_ORDER);
        }
        List<OrderDetails> orderDetailsList = new ArrayList<>();
        for (ProductInqueryDTO i : orderAddDTO.getProductInqueryDTOS()) {
            OrderDetails orderDetails = new OrderDetails();
            BeanUtil.copyProperties(i, orderDetails, "id", "updatedAt", "updatedBy");
            orderDetails.setInquiryOrderId(orderAddDTO.getInquiryOrderId());
            orderDetails.setPublicProductId(Long.valueOf(i.getProductId()));
            orderDetails.setSkuCode(i.getProductSku());
            orderDetails.setOrderId(orders.getId());
            orderDetails.setOrderCode(orders.getOrderCode());
            orderDetails.setDeliveryTime(i.getDeliveryDate());
            orderDetails.setNumber(Integer.valueOf(i.getNum()));
            orderDetails.setAmount(i.getPrice());
            orderDetails.setPurchaseAmount(i.getPurchasePrice());
            orderDetails.setProcured(OrderConstants.Procured.N.code);
            if (i.getPurchasePrice() != null && i.getNum() != null){
                orderDetails.setTotalAmount(i.getPurchasePrice().multiply(new BigDecimal(Integer.valueOf(i.getNum()))));
            }
            orderDetails.setCreatedAt(now);
            orderDetails.setCreatedBy(custId);
            orderDetailsList.add(orderDetails);
        }
        boolean result = orderDetailsService.saveBatch(orderDetailsList);
        if (!result){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.ERROR_ADD_ORDER);
        }
        return orders;
    }


}
