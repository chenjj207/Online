package com.purchase.service;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.core.util.URLUtil;
import com.alibaba.fastjson.JSONObject;
import com.purchase.config.PurchaseOrderExceptionDesc;
import com.zyd.framework.utils.constant.UserSession;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.redis.RedisUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/1  10:31
 */
@Service
public class CommonService {

    /**
     * 上海供应链公司 的供应商id
     */
    @Value("${supplierId}")
    private String supplierId;

    //获取慧采商城端
    public String loginId(){
        String[] loginIds = StpUtil.getLoginIdAsString().split("-");
        String custId = loginIds[1];
        if (StringUtils.equalsIgnoreCase(custId, "NULL")){
            //客户不存在
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_CUSTOMER);
        }
        return custId;
    }

    /**
     * 获取登录客户 登录会员的详细信息
     * @return
     */
    public JSONObject getCustInfo(){
        JSONObject json = StpUtil.getSession().getModel(UserSession.INFO,JSONObject.class);
        return json;
    }

    public Map<Object,Object> getUserInfo()  {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String token = URLUtil.decode(request.getHeader("sessionid"), StandardCharsets.UTF_8);
        try {
            return RedisUtil.HashOps.hGetAll(token);
        }catch (IllegalArgumentException e){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NO_LOGIN);
        }

    }

    /**
     * 获取供应商id
     * @return
     */
    public String getSupplierId(){
        Map<Object,Object> jsonObject = getUserInfo();
        String supplierDataType =  String.valueOf(jsonObject.get("supplierDataType")).replace("\"", "");
        if (StringUtils.isEmpty(supplierDataType) || StringUtils.equalsIgnoreCase("null", supplierDataType)){
            //说明是运营后台的用户
            return supplierId;
        }else {
            String supplierId =  String.valueOf(jsonObject.get("supplierId")).replace("\"", "");
            if (StrUtil.isBlank(supplierId)){
                throw  BusinessException.newInstance(PurchaseOrderExceptionDesc.NO_SUPPLIER_SET_UP);
            }
            return supplierId;
        }
    }

    /**
     * 获取用户id
     * @return
     */
    public String getUserId(){
        Map<Object,Object> jsonObject = getUserInfo();
        String userId =  String.valueOf(jsonObject.get("userId")).replace("\"", "");
        return userId;
    }
}
