package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/12/20  15:29
 */
@Data
public class ConfirmProcureOrderDTO {

    @Schema(description = "采购订单id")
    @NotNull(message = "采购订单id不能为空")
    private Integer id;

}
