package com.purchase.service.dto;

import com.purchase.entity.Product;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/4  11:38
 */
@Data
public class ProductInqueryDTO extends Product {
    @Schema(description = "序号")
    private Integer serialNum;
    @Schema(description = "我的编码")
    private String productCode;
    @Schema(description = "公海产品id")
    private String productId;
    @Schema(description = "供应商id")
    private String supplierId;
    @Schema(description = "需求数量")
    private Integer num;
    @Schema(description = "期望货期")
    private String expectDeliveryDate;
    @Schema(description = "货期")
    private String deliveryDate;
    @Schema(description = "单位")
    private String unit;
    @Schema(description = "库存")
    private Long stock;
    @Schema(description = "面价")
    private BigDecimal price;
    @Schema(description = "慧采价格/报价")
    private BigDecimal purchasePrice;
    @Schema(description = "小计")
    private BigDecimal subtotal;
    @Schema(description = "备注")
    private String remark;
    @Schema(description = "图片备注，url地址")
    private String picRemark;

}
