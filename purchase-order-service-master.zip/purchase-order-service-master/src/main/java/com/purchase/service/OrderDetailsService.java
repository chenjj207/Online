package com.purchase.service;

import com.purchase.entity.OrderDetails;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.ConfirmOrderDTO;

import java.util.List;

/**
 * <p>
 * 订单详情表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-12
 */
public interface OrderDetailsService extends IService<OrderDetails> {

    public List<OrderDetails> listByOrderId(Integer orderId);

    public Boolean confirm( ConfirmOrderDTO confirmOrderDTO);
}
