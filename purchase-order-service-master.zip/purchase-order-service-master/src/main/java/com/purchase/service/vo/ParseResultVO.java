package com.purchase.service.vo;

import com.purchase.service.dto.RepeatConfirmDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/4  11:31
 */
@Data
public class ParseResultVO {
    @Schema(description = "是否存在重复")
    private boolean isRepeat;
    @Schema(description = "重复商品确认列表")
    private List<RepeatConfirmDTO> repeatConfirmDTOList;
}
