package com.purchase.service.impl;

import com.purchase.entity.ProcureOrderDetails;
import com.purchase.mapper.ProcureOrderDetailsMapper;
import com.purchase.service.ProcureOrderDetailsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 采购订单详情表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
@Service
public class ProcureOrderDetailsServiceImpl extends ServiceImpl<ProcureOrderDetailsMapper, ProcureOrderDetails> implements ProcureOrderDetailsService {

}
