package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * @author jidonglin
 * @Description: 上传清单文件 响应
 * @date 2023/9/1  14:50
 */
@Data
public class NeedExportVO {

    @Schema(description = "是否解析成功")
    private boolean isParse;

    @Schema(description = "解析的商品列表")
    private List<ProductVO> productVOS;

    @Schema(description = "错误结果链接")
    private String errUrl;

}
