package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;


/**
 * @author jidonglin
 * @Description: 删除
 * @date 2023/12/11  9:59
 */
@Data
public class InquiryOrderDeleteDTO {

    @Schema(description = "询价单id")
    @NotEmpty(message = "询价单id不能为空")
    private String inquiryOrderId;
}
