package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/12/12  9:43
 */
@Data
@Schema(title = "运营端报价单导出")
public class InquiryOrderIdDTO {
    @Schema(description = "询价单id")
    @NotEmpty(message = "询价单id不能为空")
    private Integer id;
}
