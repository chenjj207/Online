package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


/**
 * @author jidonglin
 * @Description: 询价单
 * @date 2023/9/6  9:47
 */
@Data
public class InquiryOrderPageBackDTO extends PageDTO {
    @Schema(description = "关键字  品牌/型号/物料号/产品名称/询价单号")
    private String key;

    @Schema(description = "供应商id")
    private String supplierId;

    @Schema(description = "tab状态条件")
    private String tabState;

    @Schema(description = "询价状态")
    private Integer state;

    @Schema(description = "确认状态")
    private Integer confirmState;

}
