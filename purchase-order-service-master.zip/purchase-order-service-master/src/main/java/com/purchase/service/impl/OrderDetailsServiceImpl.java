package com.purchase.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.purchase.common.OrderConstants;
import com.purchase.config.PurchaseOrderExceptionDesc;
import com.purchase.entity.OrderDetails;
import com.purchase.entity.Orders;
import com.purchase.entity.ProcureOrderDetails;
import com.purchase.entity.ProcureOrders;
import com.purchase.mapper.OrderDetailsMapper;
import com.purchase.mapper.OrdersMapper;
import com.purchase.service.CommonService;
import com.purchase.service.OrderDetailsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.ProcureOrderDetailsService;
import com.purchase.service.ProcureOrdersService;
import com.purchase.service.dto.ConfirmOrderDTO;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 订单详情表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-09-12
 */
@Service
public class OrderDetailsServiceImpl extends ServiceImpl<OrderDetailsMapper, OrderDetails> implements OrderDetailsService {

    @Autowired
    CommonService commonService;

    @Resource
    OrderDetailsMapper orderDetailsMapper;
    @Resource
    OrdersMapper ordersMapper;

    @Autowired
    ProcureOrdersService procureOrdersService;
    @Autowired
    ProcureOrderDetailsService procureOrderDetailsService;

    @Override
    public List<OrderDetails> listByOrderId(Integer orderId) {
        return orderDetailsMapper.selectListByOrderId(orderId);
    }

    @Override
    @Transactional
    public Boolean confirm(ConfirmOrderDTO confirmOrderDTO) {
        List<OrderDetails> details = orderDetailsMapper.selectBatchIds(confirmOrderDTO.getIds());
        if (CollectionUtils.isEmpty(details)){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_ORDER_DETAILS);
        }

        Orders orders = ordersMapper.selectById(details.get(0).getOrderId());
        if(orders.getOrderStatus().intValue() != OrderConstants.OrdersStatus.PENDING.code){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.CAN_NOT_CONFIRM_NOT_PENDING_ORDERS);
        }
        HashMap<String, List<OrderDetails>> supplierOrderDetailsMap = new HashMap<>();
        LocalDateTime now = LocalDateTime.now();
        for (OrderDetails o : details) {
            //判断是否存在已转采的商品
            if (o.getProcured() != null && o.getProcured().intValue() == OrderConstants.Procured.Y.code){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.EXIST_ORDER_DETAILS_PROCURE);
            }
            if (StringUtils.isEmpty(o.getSupplierId())){
                throw BusinessException.newInstance(PurchaseOrderExceptionDesc.EXIST_NOT_SUPPLIER_ORDERS_DETAILS);
            }
            if (supplierOrderDetailsMap.containsKey(o.getSupplierId())){
                List<OrderDetails> orderDetails = supplierOrderDetailsMap.get(o.getSupplierId());
                orderDetails.add(o);
                supplierOrderDetailsMap.put(o.getSupplierId(), orderDetails);
            }else {
                List<OrderDetails> orderDetails = new ArrayList<>();
                orderDetails.add(o);
                supplierOrderDetailsMap.put(o.getSupplierId(), orderDetails);
            }
            //设置订单详情 数据
            o.setProcured(OrderConstants.Procured.Y.code);
            o.setUpdatedAt(now);
            o.setUpdatedBy(commonService.getUserId());
        }

        for (Map.Entry<String, List<OrderDetails>> entry : supplierOrderDetailsMap.entrySet()) {
            String supplierId = entry.getKey();
            List<OrderDetails> orderDetails = entry.getValue();

            BigDecimal totalAmount = new BigDecimal(0);
            int totalNum = 0;
            for (OrderDetails o : orderDetails) {
                totalAmount = totalAmount.add(o.getTotalAmount());
                totalNum = totalNum + o.getNumber();
            }

            ProcureOrders procureOrders = new ProcureOrders();
            procureOrders.setProcureOrderCode(OrderConstants.OrderNumPrefix.PROCURE.code + System.currentTimeMillis());
            procureOrders.setOrderId(orders.getId());
            procureOrders.setOrderCode(orders.getOrderCode());
            procureOrders.setOrderStatus(OrderConstants.ProcureOrdersStatus.PENDING.code);
            procureOrders.setPayStatus(OrderConstants.PayStatus.NOT_PAY.code);
            procureOrders.setReceivingAddr(confirmOrderDTO.getReceivingAddr());
            procureOrders.setReceivingMan(confirmOrderDTO.getReceivingMan());
            procureOrders.setReceivingPhone(confirmOrderDTO.getReceivingPhone());
            procureOrders.setReceivingZipcode(confirmOrderDTO.getReceivingZipcode());
            procureOrders.setSupplierId(supplierId);
            procureOrders.setTotalAmount(totalAmount);
            procureOrders.setTotalNum(totalNum);
            procureOrders.setCreatedBy(commonService.getUserId());
            procureOrders.setCreatedAt(now);
            //增加采购订单
            procureOrdersService.save(procureOrders);

            List<ProcureOrderDetails> procureOrderDetailsList = new ArrayList<>();
            for (OrderDetails o : orderDetails) {
                ProcureOrderDetails procureOrderDetails = new ProcureOrderDetails();
                BeanUtil.copyProperties(o, procureOrderDetails, "id", "createdBy", "createdAt", "updatedAt", "updatedBy");
                procureOrderDetails.setOrderId(orders.getId());
                procureOrderDetails.setOrderCode(orders.getOrderCode());
                procureOrderDetails.setProcureOrderId(procureOrders.getId());
                procureOrderDetails.setProcureOrderCode(procureOrders.getProcureOrderCode());
                procureOrderDetails.setSupplierId(supplierId);
                procureOrderDetails.setCreatedBy(commonService.getUserId());
                procureOrderDetails.setCreatedAt(now);
                procureOrderDetailsList.add(procureOrderDetails);
            }
            //增加采购订单详情
            procureOrderDetailsService.saveBatch(procureOrderDetailsList);
        }
        //更新订单
        UpdateWrapper<Orders> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("order_status", OrderConstants.OrdersStatus.CONFIRM.code)
                .set("updated_at", now)
                .set("confirm_time", now)
                .set("updated_by", commonService.getUserId())
                .eq("id", orders.getId());
        ordersMapper.update(null, updateWrapper);
        //更新订单详情
        this.updateBatchById(details);
        return true;
    }
}
