package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * @author jidonglin
 * @Description:
 * @date 2021/8/31  10:30
 */
@Data
public class ProductBatchDTO {
    @NotBlank(message = "搜索内容不能为空")
    @Schema(description = "搜索框文本")
    private String text;
}
