package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 供应商报价
 * @date 2023/9/7  11:25
 */
@Data
public class SupplierQuoteSaveDTO {

    @NotNull(message = "询价订单不能为空")
    @Schema(description = "询价订单id")
    private Integer inquiryOrderId;

    @Schema(description = "询价详情列表")
    private List<InquiryOrderDetailsSaveDTO> inquiryOrderDetailsSaveDTOS;

}
