package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 
* </p>
*
* @author jidonglin
* @since 2024-05-28
*/
@Data
public class DeliveryDatePageDTO extends PageDTO {

    @Schema(description = "货期")
    private String deliveryDate;

}
