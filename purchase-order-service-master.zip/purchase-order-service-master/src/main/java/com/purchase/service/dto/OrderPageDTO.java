package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;


/**
 * @author jidonglin
 * @Description: 订单
 * @date 2023/12/19  9:47
 */
@Data
public class OrderPageDTO extends PageDTO {
    @Schema(description = "关键字")
    private String key;

    @Schema(description = "运营端关键字")
    private String adminKey;

    @Schema(description = "订单号")
    private String orderCode;

    @Schema(description = "订单状态")
    private Integer orderStatus;

    @Schema(description = "客户名称")
    private String custName;

    @Schema(description = "订单来源")
    private String source;

    @Schema(description = "客户id")
    private Integer custId;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "下单时间： 开始时间")
    private LocalDateTime startTime;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    @Schema(description = "下单时间： 结束时间")
    private LocalDateTime endTime;
}
