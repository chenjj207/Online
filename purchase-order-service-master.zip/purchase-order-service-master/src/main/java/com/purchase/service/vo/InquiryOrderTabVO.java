package com.purchase.service.vo;

import lombok.Data;

/**
 * @author jidonglin
 * @Description: 询价列表统计
 * @date 2023/9/12  11:11
 */
@Data
public class InquiryOrderTabVO {
    private String tab;
    private int count;
}
