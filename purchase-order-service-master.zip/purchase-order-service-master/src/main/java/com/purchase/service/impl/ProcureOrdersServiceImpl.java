package com.purchase.service.impl;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.common.OrderConstants;
import com.purchase.config.PurchaseOrderExceptionDesc;
import com.purchase.entity.Orders;
import com.purchase.entity.ProcureOrders;
import com.purchase.mapper.ProcureOrdersMapper;
import com.purchase.service.CommonService;
import com.purchase.service.ProcureOrdersService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.CancelProcureOrderDTO;
import com.purchase.service.dto.ConfirmProcureOrderDTO;
import com.purchase.service.dto.ProcureOrderPageDTO;
import com.purchase.service.vo.ProcureOrderTabVO;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 采购订单表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
@Service
public class ProcureOrdersServiceImpl extends ServiceImpl<ProcureOrdersMapper, ProcureOrders> implements ProcureOrdersService {

    @Resource
    ProcureOrdersMapper procureOrdersMapper;
    @Autowired
    CommonService commonService;
    @Override
    public Page<ProcureOrders> page(ProcureOrderPageDTO procureOrderPageDTO) {
        return procureOrdersMapper.page(procureOrderPageDTO, procureOrderPageDTO.buildPage());
    }

    @Override
    public List<ProcureOrderTabVO> countTab(ProcureOrderPageDTO procureOrderPageDTO) {
        List<ProcureOrderTabVO> procureOrderTabVOS = new ArrayList<>();
        ProcureOrderTabVO procureOrderTabVO1 = new ProcureOrderTabVO();
        procureOrderTabVO1.setTab(OrderConstants.OrdersStatus.PENDING.code);
        procureOrderPageDTO.setOrderStatus(OrderConstants.ProcureOrdersStatus.PENDING.code.toString());
        procureOrderTabVO1.setCount(procureOrdersMapper.count(procureOrderPageDTO));
        procureOrderTabVOS.add(procureOrderTabVO1);

        ProcureOrderTabVO procureOrderTabVO2 = new ProcureOrderTabVO();
        procureOrderTabVO2.setTab(OrderConstants.OrdersStatus.CONFIRM.code);
        procureOrderPageDTO.setOrderStatus(OrderConstants.ProcureOrdersStatus.CONFIRM.code.toString());
        procureOrderTabVO2.setCount(procureOrdersMapper.count(procureOrderPageDTO));
        procureOrderTabVOS.add(procureOrderTabVO2);

        ProcureOrderTabVO procureOrderTabVO3 = new ProcureOrderTabVO();
        procureOrderTabVO3.setTab(OrderConstants.OrdersStatus.CANCEL.code);
        procureOrderPageDTO.setOrderStatus(OrderConstants.ProcureOrdersStatus.CANCEL.code.toString());
        procureOrderTabVO3.setCount(procureOrdersMapper.count(procureOrderPageDTO));
        procureOrderTabVOS.add(procureOrderTabVO3);
        return procureOrderTabVOS;
    }

    @Override
    public Boolean cancel(CancelProcureOrderDTO cancelProcureOrderDTO) {
        ProcureOrders procureOrders = this.getById(cancelProcureOrderDTO.getId());
        if (procureOrders == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_PROCURE_ORDERS);
        }
        if (procureOrders.getOrderStatus().intValue() != OrderConstants.ProcureOrdersStatus.PENDING.code){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.CAN_NOT_CANCEL_NOT_PENDING_ORDERS);
        }
        UpdateWrapper<ProcureOrders> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("order_status", OrderConstants.ProcureOrdersStatus.CANCEL.code)
                .set(StringUtils.isNotEmpty(cancelProcureOrderDTO.getReason()), "reason", cancelProcureOrderDTO.getReason())
                .set("cancel_time", LocalDateTime.now())
                .set("updated_by", commonService.getUserId())
                .set("updated_at", LocalDateTime.now())
                .eq("id", cancelProcureOrderDTO.getId());
        return this.update(updateWrapper);
    }

    @Override
    public Boolean confirm(ConfirmProcureOrderDTO confirmProcureOrderDTO) {
        ProcureOrders procureOrders = this.getById(confirmProcureOrderDTO.getId());
        if (procureOrders == null){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.NOT_EXIST_PROCURE_ORDERS);
        }
        if (procureOrders.getOrderStatus().intValue() != OrderConstants.ProcureOrdersStatus.PENDING.code){
            throw BusinessException.newInstance(PurchaseOrderExceptionDesc.CAN_NOT_CONFIRM_NOT_PENDING_ORDERS);
        }
        UpdateWrapper<ProcureOrders> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("order_status", OrderConstants.ProcureOrdersStatus.CONFIRM.code)
                .set("confirm_time", LocalDateTime.now())
                .set("updated_by", commonService.getUserId())
                .set("updated_at", LocalDateTime.now())
                .eq("id", confirmProcureOrderDTO.getId());
        return this.update(updateWrapper);
    }

    @Override
    public ProcureOrders query(Integer id) {
        return procureOrdersMapper.selectById(id);
    }
}
