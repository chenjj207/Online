package com.purchase.common;

import lombok.Data;

/**
 * @author jidonglin
 * @Description: 业务枚举值
 */
@Data
public class OrderConstants {

    /**
     * 单号前缀
     */
    public enum OrderNumPrefix {
        INQUIRY("11", "询价单"),
        ORDER("22", "销售单"),
        PROCURE("33", "采购单"),
        ;

        public String code;
        public String message;
        OrderNumPrefix(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 询价状态
     */
    public enum InquiryState{
        IN_QUOTATION(0, "报价中"),
        QUOTED(1, "已报价"),
        ACCEPTED(2, "已采纳"),
        VOIDED(3, "已作废"),
        ;

        public int code;
        public String message;
        InquiryState(int code, String message) {
            this.code = code;
            this.message = message;
        }
        public int getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 已报价的运营人员确认状态
     */
    public enum InquiryConfirmState{
        UN_CONFIRMED(0, "未确认"),
        CONFIRMED(1, "已确认"),
        ;

        public int code;
        public String message;
        InquiryConfirmState(int code, String message) {
            this.code = code;
            this.message = message;
        }
        public int getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 商城端 询价单Tab条件
     */
    public enum MallInquiryState {
        PENDING("1", "报价中"),
        QUOTED_CONFIRMED("2", "已报价"),
        ACCEPTED("3", "已采纳"),
        VOIDED("4", "已作废"),
        ;

        public String code;
        public String message;
        MallInquiryState(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 运营端 询价单Tab条件
     */
    public enum AdminInquiryTabState {
        PENDING("1", "待报价"),
        QUOTED_NO_CONFIRMED("2", "已报价待确认"),
        QUOTED_CONFIRMED("3", "已报价已确认"),
        ACCEPTED("4", "已成交"),
        VOIDED("5", "已作废"),
        ALL("6", "全部"),
        ;

        public String code;
        public String message;
        AdminInquiryTabState(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }


    /**
     * 供应商端 询价单Tab条件
     */
    public enum SupplierInquiryTabState {
        PENDING("1", "待报价"),
        QUOTED("2", "已报价"),
        ;

        public String code;
        public String message;
        SupplierInquiryTabState(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 供应商报价状态
     */
    public enum SupplierQuoteStatus {
        PENDING(0, "未报价（仅保存）"),
        QUOTED(1, "已报价"),
        ;

        public Integer code;
        public String message;
        SupplierQuoteStatus(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 供应商报价状态
     */
    public enum InquiryOrderStatus {
        PENDING(0, "未报价"),
        QUOTED(1, "已报价"),
        ;

        public Integer code;
        public String message;
        InquiryOrderStatus(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 销售订单状态
     */
    public enum OrdersStatus {
        PENDING(1, "待确认"),
        CONFIRM(2, "已确认"),
        CANCEL(3, "已作废"),
        ;

        public Integer code;
        public String message;
        OrdersStatus(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 采购订单状态
     */
    public enum ProcureOrdersStatus {
        PENDING(1, "待确认"),
        CONFIRM(2, "已确认"),
        CANCEL(3, "已作废"),
        ;

        public Integer code;
        public String message;
        ProcureOrdersStatus(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 支付状态
     */
    public enum PayStatus {
        NOT_PAY(0, "待支付"),
        PAY(1, "已支付"),
        ;

        public Integer code;
        public String message;
        PayStatus(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }
    /**
     * 是否转采
     */
    public enum Procured {
        N(0, "未转采"),
        Y(1, "已转采"),
        ;

        public Integer code;
        public String message;
        Procured(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    /**
     * 来源
     */
    public enum Source {
        INQUIRY("INQUIRY", "询价"),
        CONTRACT("CONTRACT", "直接做合同"),
        ;

        public String code;
        public String message;
        Source(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }
}
