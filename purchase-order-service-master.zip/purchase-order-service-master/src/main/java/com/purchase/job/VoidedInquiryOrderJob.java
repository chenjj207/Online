package com.purchase.job;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.spring.boot.annotation.JobRunner4TaskTracker;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.github.ltsopensource.tasktracker.runner.JobRunner;
import com.purchase.common.OrderConstants;
import com.purchase.entity.InquiryOrder;
import com.purchase.entity.InquiryOrderDetails;
import com.purchase.service.InquiryOrderDetailsService;
import com.purchase.service.InquiryOrderService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.helpers.MessageFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;


/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/15  14:27
 */
@Slf4j
@Component
@JobRunner4TaskTracker
public class VoidedInquiryOrderJob implements JobRunner {

    @Autowired
    InquiryOrderService inquiryOrderService;
    @Autowired
    InquiryOrderDetailsService inquiryOrderDetailsService;

    /**
     * 执行任务
     * 抛出异常则消费失败, 返回null则认为是消费成功
     *
     * @param jobContext
     */
    @Override
    public Result run(JobContext jobContext) throws Throwable {
        String type = jobContext.getJob().getParam("type");
        switch (type) {
            case "VOIDED_INQUIRY_ORDER":
                LocalDateTime now = LocalDateTime.now();
//                //超过询价时间则作废询价单
//                QueryWrapper<InquiryOrderDetails> queryWrapper = new QueryWrapper();
//                queryWrapper.le("inquiry_expire_time", now);
//                queryWrapper.ne("state", OrderConstants.InquiryState.VOIDED.code);
//                List<InquiryOrderDetails> list = inquiryOrderDetailsService.list(queryWrapper);
//                if (!CollectionUtils.isEmpty(list)){
//                    list.forEach(object -> object.setState(OrderConstants.InquiryState.VOIDED.code));
//                    list.forEach(object -> object.setUpdatedAt(now));
//                    inquiryOrderDetailsService.updateBatchById(list);
//                }

                //客户生成询价单未有供应商提交报价并目超过询价有效期
                QueryWrapper<InquiryOrder> queryWrapper = new QueryWrapper<>();
                queryWrapper.le("inquiry_expire_time", now);
                queryWrapper.eq("state", OrderConstants.InquiryState.IN_QUOTATION.code);
                List<InquiryOrder> list = inquiryOrderService.list(queryWrapper);
                if (!CollectionUtils.isEmpty(list)){
                    list.forEach(object -> object.setState(OrderConstants.InquiryState.VOIDED.code));
                    list.forEach(object -> object.setUpdatedAt(now));
                    inquiryOrderService.updateBatchById(list);
                }


                //运营后台已确认的询价单并且超过运营填写的报价有效期
                QueryWrapper<InquiryOrder> queryWrapper1 = new QueryWrapper<>();
                queryWrapper1.le("quote_expire_time", now);
                queryWrapper1.eq("state", OrderConstants.InquiryState.QUOTED.code);
                queryWrapper1.eq("confirm_state", OrderConstants.InquiryConfirmState.CONFIRMED.code);
                List<InquiryOrder> list1 = inquiryOrderService.list(queryWrapper1);
                if (!CollectionUtils.isEmpty(list1)){
                    list1.forEach(object -> object.setState(OrderConstants.InquiryState.VOIDED.code));
                    list1.forEach(object -> object.setUpdatedAt(now));
                    inquiryOrderService.updateBatchById(list1);
                }

                return  new Result(Action.EXECUTE_SUCCESS, "任务执行成功");
            default:
                return new Result(Action.EXECUTE_EXCEPTION, MessageFormatter.format("非法执行命令: {}", type).getMessage());
        }
    }

}
