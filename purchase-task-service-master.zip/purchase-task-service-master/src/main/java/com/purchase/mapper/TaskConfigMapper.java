package com.purchase.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.entity.TaskConfig;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/12/13 15:55
 */
@Mapper
public interface TaskConfigMapper extends BaseMapper<TaskConfig> {
}
