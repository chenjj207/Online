package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.TaskManage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.TaskDTO;
import com.purchase.service.vo.TaskCreatedByVO;
import com.purchase.service.vo.TaskSearchVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 任务管理 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2024-12-24
 */
@Mapper
public interface TaskManageMapper extends BaseMapper<TaskManage> {

    /**
     * 搜索
     *
     * @param dto
     * @param userId
     * @param userCodes
     * @param buildPage
     * @Author: loine
     * @Date: 2024/12/26 17:03
     */
    Page<TaskSearchVO> search(@Param("dto") TaskDTO.SearchDTO dto, @Param("userId") String userId, @Param("userCodes") String userCodes, Page buildPage);

    /**
     * 获取创建人列表
     *
     * @Author loine
     * @Date 2025/8/20 10:53
     */
    List<TaskCreatedByVO> getCreatedByList();

    /**
     * 获取模块列表
     *
     * @Author loine
     * @Date 2025/12/13 09:44
     */
    List<String> moduleList();

    /**
     * 获取类型列表
     *
     * @Author loine
     * @Date 2026/4/20 14:20
     */
    List<String> typeList();
}
