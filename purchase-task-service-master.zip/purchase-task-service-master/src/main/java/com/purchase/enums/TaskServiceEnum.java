package com.purchase.enums;

import lombok.Getter;

/**
 * @Description: 任务中心-服务枚举
 * @Author: loine
 * @Date: 2025/12/16 10:59
 */
@Getter
public enum TaskServiceEnum {
    PURCHASE_PRODUCT("purchase-product", "商品服务"),
    PURCHASE_PUBLIC_PRODUCT("purchase-public-product", "公海商品服务"),
    ELVO_PRODUCT("elvo-product", "海外商品服务"),
    ELVO_PUBLIC_PRODUCT("elvo-public-product", "海外公海商品服务"),
    ;

    private final String key;
    private final String value;

    TaskServiceEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

}
