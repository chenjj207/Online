package com.purchase.enums;

import lombok.Getter;

/**
 * @Description: 任务中心-系统模块枚举
 * @Author: loine
 * @Date: 2025/12/16 10:59
 */
@Getter
public enum TaskModuleEnum {
    PRODUCT_AUDIT("product_audit", "商品审核（国内）"),
    PRODUCT("product", "商品池（国内）"),
    ZYDMALL_PRODUCT_ONSALE("zydmall_product_onsale", "zydmall商品上架（国内）"),
    ELVO_PRODUCT_AUDIT("elvo_product_audit", "商品审核（海外）"),
    ELVO_PRODUCT("elvo_product", "商品池（海外）"),
    PRODUCT_SUM("product_sum", "商品统计"),
    ;

    private final String key;
    private final String value;

    TaskModuleEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }
    public static boolean isAudit(String value) {
        return value.equals(PRODUCT_AUDIT.value) || value.equals(ELVO_PRODUCT_AUDIT.value);
    }
}
