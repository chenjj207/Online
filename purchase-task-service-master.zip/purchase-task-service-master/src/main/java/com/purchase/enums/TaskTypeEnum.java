package com.purchase.enums;

import lombok.Getter;

/**
 * @Description: 任务中心-类型枚举
 * @Author: loine
 * @Date: 2025/12/16 10:59
 */
@Getter
public enum TaskTypeEnum {
    AUDIT_APPROVE("audit_approve", "审核通过"),
    AUDIT_REJECT("audit_reject", "审核驳回"),
    SET_DISTRIBUTE_PRICE("set_distribute_price", "设置调货价"),
    SET_ERP_CODE("set_erp_code", "关联ERP编码"),
    PRODUCT_EXPORT("product_export", "商品导出"),
    PRODUCT_AUDIT_SUM("product_audit_sum", "商品审核考核分析"),
    ERP_CODE_PRODUCT_APPLY("erp_code_product_apply", "编码申请导出"),
    PRODUCT_LIST_IMPORT("product_list_import", "修改商品"),
    ;

    private final String key;
    private final String value;

    TaskTypeEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public static boolean isAudit(String value) {
        return value.equals(AUDIT_APPROVE.value) || value.equals(AUDIT_REJECT.value) || value.equals(SET_DISTRIBUTE_PRICE.value);
    }

    public static boolean isExport(String value) {
        return value.equals(PRODUCT_EXPORT.value) || value.equals(PRODUCT_AUDIT_SUM.value) || value.equals(ERP_CODE_PRODUCT_APPLY.value);
    }
}
