package com.purchase.util;

import cn.hutool.core.io.IoUtil;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.exception.BusinessExceptionDesc;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/12/13 16:49
 */
@Slf4j
public class ExcelUtil {

    /**
     * 多个excel合并成一个
     *
     * @param response
     * @param fileName
     * @param sheetName
     * @param sourceUrls
     * @Author loine
     * @Date 2025/12/13 16:59
     */
    public static void mergeExcel(HttpServletResponse response, String fileName, String sheetName, List<String> sourceUrls) {
        Workbook mainWorkbook = new XSSFWorkbook();
        mainWorkbook.createSheet(sheetName);
        for (int i = 0; i < sourceUrls.size(); i++) {
            String sourceUrl = sourceUrls.get(i);
            InputStream is = null;
            try {
                URL url = new URL(sourceUrl);
                is = url.openStream();
                Workbook workbook = new XSSFWorkbook(is);
                copySheets(workbook, mainWorkbook, i == 0);
            } catch (Exception e) {
                log.error("合成文件异常：" + e);
            } finally {
                IoUtil.close(is);
            }
        }
        try {
            response.reset();
            response.setContentType("application/octet-stream;charset=utf-8");
            fileName = URLEncoder.encode(fileName, "UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
            mainWorkbook.write(response.getOutputStream());
        } catch (Exception e) {
            log.error("导出文件异常：" + e);
        }
    }


    /**
     * 复制工作簿中的所有工作表到目标工作簿
     *
     * @param sourceWorkbook 源工作簿
     * @param targetWorkbook 目标工作簿
     * @param hasTitleRow    包含标题行
     */
    private static void copySheets(Workbook sourceWorkbook, Workbook targetWorkbook, boolean hasTitleRow) {
        Sheet sourceSheet = sourceWorkbook.getSheetAt(0);
        Sheet targetSheet = targetWorkbook.getSheetAt(0);

        // 复制行和单元格
        copySheet(sourceSheet, targetSheet, hasTitleRow);
    }

    /**
     * 复制单个工作表的内容
     *
     * @param sourceSheet 源工作表
     * @param targetSheet 目标工作表
     * @param hasTitleRow 包含标题行
     */
    private static void copySheet(Sheet sourceSheet, Sheet targetSheet, boolean hasTitleRow) {
        int lastRowNum = sourceSheet.getLastRowNum();
        int nowNum = targetSheet.getLastRowNum() + 1;
        int j = 0;
        for (int i = (hasTitleRow ? 0 : 1); i <= lastRowNum; i++) {
            Row sourceRow = sourceSheet.getRow(i);
            Row targetRow = targetSheet.createRow(nowNum + j);
            j++;
            if (sourceRow != null) {
                copyRow(sourceRow, targetRow);
            }
        }
    }

    /**
     * 复制行的内容
     *
     * @param sourceRow  源行
     * @param targetRow  目标行
     */
    private static void copyRow(Row sourceRow, Row targetRow) {
        targetRow.setHeight(sourceRow.getHeight());

        for (int i = 0; i < sourceRow.getLastCellNum(); i++) {
            Cell sourceCell = sourceRow.getCell(i);
            Cell targetCell = targetRow.createCell(i);

            if (sourceCell != null) {
                copyCell(sourceCell, targetCell);
            }
        }
    }

    /**
     * 复制单元格的内容和样式
     *
     * @param sourceCell 源单元格
     * @param targetCell 目标单元格
     */
    private static void copyCell(Cell sourceCell, Cell targetCell) {
        // 复制单元格样式
        CellStyle newCellStyle = targetCell.getSheet().getWorkbook().createCellStyle();
        newCellStyle.cloneStyleFrom(sourceCell.getCellStyle());
        targetCell.setCellStyle(newCellStyle);

        // 复制单元格值
        switch (sourceCell.getCellType()) {
            case STRING:
                targetCell.setCellValue(sourceCell.getStringCellValue());
                break;
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(sourceCell)) {
                    targetCell.setCellValue(sourceCell.getDateCellValue());
                } else {
                    targetCell.setCellValue(sourceCell.getNumericCellValue());
                }
                break;
            case BOOLEAN:
                targetCell.setCellValue(sourceCell.getBooleanCellValue());
                break;
            case FORMULA:
                targetCell.setCellFormula(sourceCell.getCellFormula());
                break;
            case BLANK:
                targetCell.setBlank();
                break;
            default:
                targetCell.setCellValue(sourceCell.getStringCellValue());
                break;
        }
    }

    /**
     * 校验两个cell值是否一样
     *
     * @param cell1
     * @param cell2
     */
    private static boolean compareCellValue(Cell cell1, Cell cell2) {
        if (cell1 == null && cell2 == null) return true;
        if (cell1 == null || cell2 == null) return false;

        if (cell1.getCellType() != cell2.getCellType()) return false;

        switch (cell1.getCellType()) {
            case STRING:
                return cell1.getStringCellValue().equals(cell2.getStringCellValue());
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell1) && DateUtil.isCellDateFormatted(cell2)) {
                    return cell1.getDateCellValue().equals(cell2.getDateCellValue());
                } else {
                    return cell1.getNumericCellValue() == cell2.getNumericCellValue();
                }
            case BOOLEAN:
                return cell1.getBooleanCellValue() == cell2.getBooleanCellValue();
            case FORMULA:
                return cell1.getCellFormula().equals(cell2.getCellFormula());
            default:
                return cell1.toString().equals(cell2.toString());
        }
    }
}
