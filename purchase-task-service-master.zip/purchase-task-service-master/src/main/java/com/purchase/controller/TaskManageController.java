package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.service.TaskManageService;
import com.purchase.service.dto.TaskCommitRequest;
import com.purchase.service.dto.TaskDTO;
import com.purchase.service.vo.TaskCreatedByVO;
import com.purchase.service.vo.TaskSearchVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 任务管理 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-12-24
 */
@RestController
@RequestMapping("/task-manage")
@Tag(name = "任务管理")
public class TaskManageController {

    @Autowired
    private TaskManageService taskManageService;

    @PostMapping(value = "/commit")
    @Operation(summary = "任务提交")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Integer commit(@RequestBody TaskCommitRequest request) {
        return taskManageService.commit(request);
    }

    @PostMapping(value = "/search")
    @Operation(summary = "搜索")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Page<TaskSearchVO> search(@Valid @RequestBody TaskDTO.SearchDTO dto) {
        return taskManageService.search(dto);
    }

    @PostMapping(value = "/download")
    @Operation(summary = "下载")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean download(HttpServletResponse response, @Valid @RequestBody TaskDTO.BaseDTO dto) {
        taskManageService.download(response, dto);
        return true;
    }

    @PostMapping(value = "/reExecute")
    @Operation(summary = "重新执行")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Integer reExecute(@Valid @RequestBody TaskDTO.BaseDTO dto) {
        return taskManageService.reExecute(dto);
    }

    @PostMapping(value = "/createdByList")
    @Operation(summary = "创建人列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public List<TaskCreatedByVO> createdByList() {
        return taskManageService.createdByList();
    }

    @PostMapping(value = "/moduleList")
    @Operation(summary = "模块列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public List<String> moduleList() {
        return taskManageService.moduleList();
    }

    @PostMapping(value = "/typeList")
    @Operation(summary = "类型列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public List<String> typeList() {
        return taskManageService.typeList();
    }

    @PostMapping(value = "/taskMergeExport")
    @Operation(summary = "多个任务合并明细导出")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public void taskMergeExport(HttpServletResponse response, @Valid @RequestBody TaskDTO.MergeExportDTO dto){
        taskManageService.taskMergeExport(response, dto);
    }
}
