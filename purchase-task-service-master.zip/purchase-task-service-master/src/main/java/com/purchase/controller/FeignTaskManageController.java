package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.TaskManage;
import com.purchase.service.TaskManageService;
import com.purchase.service.dto.TaskCommitRequest;
import com.purchase.service.dto.TaskDTO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * <p>
 * 任务管理 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2024-12-24
 */
@RestController
@RequestMapping("/feign/task-manage")
@Tag(name = "任务中心远程调用")
public class FeignTaskManageController {

    @Autowired
    private TaskManageService taskManageService;

    @PostMapping(value = "/detail")
    @Operation(summary = "任务详情")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public TaskManage detail(@Valid @RequestBody TaskDTO.BaseDTO dto){
        return taskManageService.detail(dto);
    }

    @PostMapping(value = "/update")
    @Operation(summary = "更新任务")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Integer taskUpdate(@Valid @RequestBody TaskDTO.UpdateDTO dto){
        return taskManageService.taskUpdate(dto);
    }

    @PostMapping(value = "/create")
    @Operation(summary = "创建任务")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Integer create(@RequestBody TaskManage task){
        return taskManageService.create(task);
    }

    @PostMapping(value = "/new/update")
    @Operation(summary = "更新任务")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Integer update(@RequestBody TaskManage task){
        return taskManageService.update(task);
    }
}
