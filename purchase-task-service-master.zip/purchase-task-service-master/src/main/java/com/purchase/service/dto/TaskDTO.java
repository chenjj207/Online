package com.purchase.service.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @Description: 任务实体
 * @Author: loine
 * @Date: 2024/12/26 16:54
 **/
@Data
public class TaskDTO {

    @Data
    @Schema(description = "搜索")
    public static class SearchDTO extends PageDTO {
        @Schema(description = "关键字")
        private String key;
        @Schema(description = "类型")
        private List<String> types;
        @Schema(description = "状态：0：未执行 1：执行中 2：执行成功 3：执行失败")
        private String status;
        @Schema(description = "创建者")
        private String createdBy;
        @Schema(description = "模块")
        private List<String> modules;
        @Schema(description = "创建时间开始")
        private String startDate;
        @Schema(description = "创建时间截止")
        private String endDate;
    }

    @Data
    @Schema(description = "基本")
    public static class BaseDTO {
        @Schema(description = "主键")
        @NotNull(message = "id不能为空")
        private Integer id;
    }

    @Data
    @Schema(description = "更新")
    public static class UpdateDTO {
        @Schema(description = "主键")
        @NotNull(message = "id不能为空")
        private Integer id;
        @Schema(description = "状态：0：未执行 1：执行中 2：执行成功 3：执行失败")
        private String status;
        @Schema(description = "执行结果类型：1: url  2：text")
        private String resultType;
        @Schema(description = "执行结果内容")
        private String resultContent;
        @Schema(description = "备注")
        private String remark;
    }

    @Data
    @Schema(description = "合并导出")
    public static class MergeExportDTO {
        @Schema(description = "id组")
        @NotEmpty(message = "id组不能为空")
        private List<Integer> id;
    }
}
