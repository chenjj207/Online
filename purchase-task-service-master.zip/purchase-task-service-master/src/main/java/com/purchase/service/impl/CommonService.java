package com.purchase.service.impl;

import cn.hutool.core.util.URLUtil;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.redis.RedisUtil;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * @author jidonglin
 * @Description: 公共服务
 * @date 2024/12/27  9:09
 */
@Service
public class CommonService {

    public Map<Object,Object> getUserInfo()  {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String token = URLUtil.decode(request.getHeader("sessionid"), StandardCharsets.UTF_8);
        try {
            return RedisUtil.HashOps.hGetAll(token);
        }catch (IllegalArgumentException e){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NO_LOGIN);
        }

    }
}
