package com.purchase.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.client.MsgClient;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.entity.TaskConfig;
import com.purchase.entity.TaskManage;
import com.purchase.enums.TaskModuleEnum;
import com.purchase.enums.TaskServiceEnum;
import com.purchase.enums.TaskTypeEnum;
import com.purchase.mapper.TaskConfigMapper;
import com.purchase.mapper.TaskManageMapper;
import com.purchase.service.TaskManageService;
import com.purchase.service.dto.TaskCommitRequest;
import com.purchase.service.dto.TaskDTO;
import com.purchase.service.vo.TaskCreatedByVO;
import com.purchase.service.vo.TaskSearchVO;
import com.purchase.util.ExcelUtil;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.exception.BusinessExceptionDesc;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import javax.jms.Queue;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

/**
 * <p>
 * 任务管理 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2024-12-24
 */
@Service
public class TaskManageServiceImpl extends ServiceImpl<TaskManageMapper, TaskManage> implements TaskManageService {

    @Autowired
    private JmsMessagingTemplate jmsMessagingTemplate;
    @Resource
    private Queue productApproveQueue;
    @Resource
    private Queue productExportQueue;
    @Resource
    private Queue publicProductRelevanceErpQueue;
    @Resource
    private Queue publicProductExportQueue;
    @Resource
    private Queue publicProductListImportQueue;
    @Resource
    private Queue elvoProductApproveQueue;
    @Resource
    private Queue elvoProductExportQueue;
    @Resource
    private Queue elvoPublicProductExportQueue;
    @Autowired
    private CommonService commonService;
    @Autowired
    private MsgClient msgClient;
    @Autowired
    private TaskConfigMapper taskConfigMapper;

    /**
     * 登录信息
     *
     * @param param
     */
    public JSONObject loginNameInfo(String param) {
        // 将用户信息写入到请求参数里面，后面需要用到
        String username = null;
        String name = null;
        String userId = null;
        try {
            userId = (String) commonService.getUserInfo().get("userId");
            if (StringUtils.isNotBlank(userId)) {
                userId = userId.substring(1, userId.length() - 1);
            }
            username = (String) commonService.getUserInfo().get("username");
            if (StringUtils.isNotBlank(username)) {
                username = username.substring(1, username.length() - 1);
            }
            name = (String) commonService.getUserInfo().get("name");
            if (StringUtils.isNotBlank(name)) {
                name = name.substring(1, name.length() - 1);
            }
        } catch (Exception e) {
            log.warn("发送任务未登录,获取用户信息失败");
            username = "测试用户";
            name = "测试用户";
            userId = "测试用户";
        }
        JSONObject requestParam = StringUtils.isNotBlank(param) ?
                JSONObject.parseObject(param) : new JSONObject();
        requestParam.put("createUsername", username);
        requestParam.put("createName", name);
        requestParam.put("userId", userId);
        return requestParam;
    }

    /**
     * 任务提交
     *
     * @param request
     * @Author: loine
     * @Date: 2024/12/27 9:32
     */
    @Override
    public Integer commit(TaskCommitRequest request) {
        JSONObject requestParam = loginNameInfo(request.getRequestParam());
        if (StringUtils.isBlank(request.getModule())) {
            throw BusinessException.newInstance(BusinessExceptionDesc.PARAM_ERROR, "模块不能为空");
        }
        if (StringUtils.isBlank(request.getService())) {
            throw BusinessException.newInstance(BusinessExceptionDesc.PARAM_ERROR, "服务名称不能为空");
        }
        // 新增任务
        TaskManage taskManage = new TaskManage();
        taskManage.setType(request.getType());
        taskManage.setModule(request.getModule());
        taskManage.setService(request.getService());
        taskManage.setStatus("0");
        taskManage.setRequestParam(requestParam.toJSONString());
        taskManage.setDownloadNum(0);
        taskManage.setCreatedAt(LocalDateTime.now());
        taskManage.setCreatedBy(requestParam.getString("userId"));
        int n = baseMapper.insert(taskManage);
        if (n > 0) {
            // 发送mq
            if (request.getService().equalsIgnoreCase(TaskServiceEnum.PURCHASE_PRODUCT.getKey())) {
                if (TaskTypeEnum.isAudit(request.getType())) {
                    jmsMessagingTemplate.convertAndSend(productApproveQueue, taskManage.getId());
                } else if (TaskTypeEnum.isExport(request.getType())) {
                    jmsMessagingTemplate.convertAndSend(productExportQueue, taskManage.getId());
                }
            } else if (request.getService().equalsIgnoreCase(TaskServiceEnum.ELVO_PRODUCT.getKey())) {
                if (TaskTypeEnum.isAudit(request.getType())) {
                    jmsMessagingTemplate.convertAndSend(elvoProductApproveQueue, taskManage.getId());
                } else if (taskManage.getType().equals(TaskTypeEnum.PRODUCT_EXPORT.getValue())) {
                    jmsMessagingTemplate.convertAndSend(elvoProductExportQueue, taskManage.getId());
                }
            } else if (request.getService().equalsIgnoreCase(TaskServiceEnum.PURCHASE_PUBLIC_PRODUCT.getKey())) {
                jmsMessagingTemplate.convertAndSend(publicProductExportQueue, taskManage.getId());
            } else if (request.getService().equalsIgnoreCase(TaskServiceEnum.ELVO_PUBLIC_PRODUCT.getKey())) {
                jmsMessagingTemplate.convertAndSend(elvoPublicProductExportQueue, taskManage.getId());
            }
        }
        return taskManage.getId();
    }

    /**
     * 搜索
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/12/26 17:00
     */
    @Override
    public Page<TaskSearchVO> search(TaskDTO.SearchDTO dto) {
        String userId = (String) commonService.getUserInfo().get("userId");
        String userCode = (String) commonService.getUserInfo().get("username");
        if (StringUtils.isNotBlank(userId)) {
            userId = userId.substring(1, userId.length() - 1);
        }
        if (StringUtils.isNotBlank(userCode)) {
            userCode = userCode.substring(1, userCode.length() - 1);
        }
        // 工号在配置表的，可以看所有数据，不在的只能看自己建的数据
        String userCodes = null;
        TaskConfig taskConfig = taskConfigMapper.selectById(1);
        if (taskConfig != null) {
            userCodes = taskConfig.getAllDataCode();
            if (!userCodes.contains(userCode)) {
                userCodes = null;
            }
        }
        Page<TaskSearchVO> page = baseMapper.search(dto, userId, userCodes, dto.buildPage());
        List<TaskSearchVO> vos = page.getRecords();
        for (TaskSearchVO vo : vos) {
            if (StringUtils.isBlank(vo.getRequestParam())) {
                continue;
            }
            JSONObject requestParam = JSONObject.parseObject(vo.getRequestParam());
            vo.setCreatedName(requestParam.get("createName") + "");
            // 隐藏创建用户信息
            requestParam.remove("createUsername");
            requestParam.remove("createName");
            requestParam.remove("userId");
            vo.setRequestParam(requestParam.toJSONString());
        }
        page.setRecords(vos);
        return page;
    }

    /**
     * 下载
     *
     * @param response
     * @param dto
     * @Author: loine
     * @Date: 2024/12/28 10:57
     */
    @Override
    public void download(HttpServletResponse response, TaskDTO.BaseDTO dto) {
        TaskManage taskManage = baseMapper.selectById(dto.getId());
        if (taskManage == null) {
            throw BusinessException.newInstance(BusinessExceptionDesc.PARAM_ERROR, "任务不存在");
        }
        if ("1".equals(taskManage.getResultType()) && StringUtils.isNotBlank(taskManage.getResultContent())) {
            // 更新下载次数
            taskManage.setDownloadNum(taskManage.getDownloadNum() + 1);
            taskManage.setUpdatedAt(LocalDateTime.now());
            baseMapper.updateById(taskManage);
        }
    }

    /**
     * 重新执行
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/12/26 17:51
     */
    @Override
    public Integer reExecute(TaskDTO.BaseDTO dto) {
        TaskManage taskManage = baseMapper.selectById(dto.getId());
        if (taskManage == null) {
            throw BusinessException.newInstance(BusinessExceptionDesc.PARAM_ERROR, "任务不存在");
        }
        // 重新发送mq
        if (taskManage.getStatus().equals("0") || taskManage.getStatus().equals("3")) {
            // 发送mq
            if (taskManage.getService().equalsIgnoreCase(TaskServiceEnum.PURCHASE_PRODUCT.getKey())) {
                if (TaskTypeEnum.isAudit(taskManage.getType())) {
                    jmsMessagingTemplate.convertAndSend(productApproveQueue, taskManage.getId());
                } else if (TaskTypeEnum.isExport(taskManage.getType())) {
                    jmsMessagingTemplate.convertAndSend(productExportQueue, taskManage.getId());
                }
            } else if (taskManage.getService().equalsIgnoreCase(TaskServiceEnum.ELVO_PRODUCT.getKey())) {
                if (TaskTypeEnum.isAudit(taskManage.getType())) {
                    jmsMessagingTemplate.convertAndSend(elvoProductApproveQueue, taskManage.getId());
                } else if (taskManage.getType().equals(TaskTypeEnum.PRODUCT_EXPORT.getValue())) {
                    jmsMessagingTemplate.convertAndSend(elvoProductExportQueue, taskManage.getId());
                }
            } else if (taskManage.getService().equalsIgnoreCase(TaskServiceEnum.PURCHASE_PUBLIC_PRODUCT.getKey())) {
                jmsMessagingTemplate.convertAndSend(publicProductExportQueue, taskManage.getId());
            } else if (taskManage.getService().equalsIgnoreCase(TaskServiceEnum.ELVO_PUBLIC_PRODUCT.getKey())) {
                jmsMessagingTemplate.convertAndSend(elvoPublicProductExportQueue, taskManage.getId());
            }
        }
        return taskManage.getId();
    }

    /**
     * 任务详情
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/12/27 10:16
     */
    @Override
    public TaskManage detail(TaskDTO.BaseDTO dto) {
        return baseMapper.selectById(dto.getId());
    }

    /**
     * 更新任务
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/12/27 11:07
     */
    @Override
    public Integer taskUpdate(TaskDTO.UpdateDTO dto) {
        TaskManage taskManage = baseMapper.selectById(dto.getId());
        if (taskManage == null) {
            throw BusinessException.newInstance(BusinessExceptionDesc.PARAM_ERROR, "任务不存在");
        }
        BeanUtils.copyProperties(dto, taskManage);
        if (dto.getStatus().equals("2")) {
            taskManage.setRemark("");
        }
        taskManage.setUpdatedBy(taskManage.getCreatedBy());
        taskManage.setUpdatedAt(LocalDateTime.now());
        baseMapper.updateById(taskManage);
        // 成功或者失败时发送消息
        String tag;
        if (taskManage.getType().equals(TaskTypeEnum.AUDIT_APPROVE.getValue()) || taskManage.getType().equals(TaskTypeEnum.AUDIT_REJECT.getValue())) {
            tag = "审核";
        } else if (taskManage.getType().equals(TaskTypeEnum.SET_DISTRIBUTE_PRICE.getValue())) {
            tag = "设置调货价";
        } else {
            return taskManage.getId();
        }
        String textContent;
        if (taskManage.getStatus().equals("2")) {
            textContent = "您的SCM商品批量" + tag + "任务已执行成功【任务ID:" + dto.getId() + "】，请登录运营管理后台查看";
        } else if (taskManage.getStatus().equals("3")) {
            textContent = "您的SCM商品批量" + tag + "任务已执行失败【任务ID:" + dto.getId() + "】，请登录运营管理后台查看";
        } else {
            textContent = "";
        }
        if (StringUtils.isNotBlank(textContent)) {
            try {
                String userName = JSONObject.parseObject(taskManage.getRequestParam()).getString("createUsername");
                TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
                triggerMsgRequest.setBusiness("scmProduct");
                triggerMsgRequest.setScene("productAudit");
                JSONObject qywxParam = new JSONObject();
                qywxParam.put("msgtype", "text");
                qywxParam.put("noticeUser", userName);
                qywxParam.put("text", new JSONObject() {{
                    put("content", textContent);
                }});
                triggerMsgRequest.setQywxParam(qywxParam);
                msgClient.triggerMsg(triggerMsgRequest);
            } catch (Exception e) {
                log.error("更新任务-推送消息异常：" + e);
            }
        }
        return taskManage.getId();
    }

    @Override
    public Integer create(TaskManage taskManage) {
        // 登录信息
        JSONObject jsonObject = loginNameInfo(taskManage.getRequestParam());
        // 新增任务
        taskManage.setRequestParam(jsonObject.toJSONString());
        taskManage.setCreatedBy(jsonObject.getString("userId"));
        taskManage.setCreatedAt(LocalDateTime.now());
        int n = baseMapper.insert(taskManage);
        if (n > 0) {
            // 发送mq
            if (taskManage.getType().equals(TaskTypeEnum.SET_ERP_CODE.getValue())) {
                jmsMessagingTemplate.convertAndSend(publicProductRelevanceErpQueue, taskManage.getId());
            } else if (taskManage.getType().equals(TaskTypeEnum.PRODUCT_LIST_IMPORT.getValue())) {
                jmsMessagingTemplate.convertAndSend(publicProductListImportQueue, taskManage.getId());
            }

        }
        return taskManage.getId();
    }

    @Override
    public Integer update(TaskManage taskManage) {
        taskManage.setUpdatedAt(LocalDateTime.now());
        int i = baseMapper.updateById(taskManage);
        return i;
    }

    /**
     * 创建人列表
     *
     * @Author loine
     * @Date 2025/8/20 10:52
     */
    @Override
    public List<TaskCreatedByVO> createdByList() {
        return baseMapper.getCreatedByList();
    }

    /**
     * 模块列表
     *
     * @Author loine
     * @Date 2025/12/13 09:44
     */
    @Override
    public List<String> moduleList() {
        return baseMapper.moduleList();
    }

    /**
     * 获取类型列表
     *
     * @Author loine
     * @Date 2026/4/20 14:20
     */
    @Override
    public List<String> typeList() {
        return baseMapper.typeList();
    }

    /**
     * 多个任务合并明细导出
     *
     * @param response
     * @param dto
     * @Author loine
     * @Date 2025/12/13 16:22
     */
    @Override
    public void taskMergeExport(HttpServletResponse response, TaskDTO.MergeExportDTO dto) {
        List<String> excelUrls = new LinkedList<>();
        for (Integer id : dto.getId()) {
            TaskManage taskManage = baseMapper.selectById(id);
            if (taskManage == null) {
                throw BusinessException.newInstance(BusinessExceptionDesc.PARAM_ERROR, "任务不存在");
            }
            if (!taskManage.getStatus().equals("2")) {
                throw BusinessException.newInstance(BusinessExceptionDesc.PARAM_ERROR, "任务未完成，无法导出");
            }
            if (!TaskModuleEnum.isAudit(taskManage.getModule())) {
                throw BusinessException.newInstance(BusinessExceptionDesc.PARAM_ERROR, "仅支持对商品审核的数据合并导出");
            }
            if (StringUtils.isNotBlank(taskManage.getResultContent())) {
                if (taskManage.getResultContent().contains("https://") || taskManage.getResultContent().contains("http://")) {
                    excelUrls.add(taskManage.getResultContent());
                }
            }
        }
        if (!CollectionUtils.isEmpty(excelUrls)) {
            ExcelUtil.mergeExcel(response, "商品审核.xlsx", "商品明细", excelUrls);
        }
    }

}
