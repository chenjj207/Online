package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description: 任务提交实体
 * @date 2024/12/24  14:01
 */
@Data
public class TaskCommitRequest {

    @Schema(description = "类型，指按钮操作（审核通过、审核驳回、设置调货价、批量发布商品）")
    private String type;
    @Schema(description = "请求参数，json格式")
    private String requestParam;
    @Schema(description = "模块：页面菜单名称，如商品管理")
    private String module;
    @Schema(description = "服务名称：例如purchase-product")
    private String service;
}
