package com.purchase.service.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * @Description: 任务搜索实体
 * @Author: loine
 * @Date: 2024/12/26 16:54
 **/
@Data
public class TaskSearchVO {
    @Schema(description = "主键")
    private Integer id;
    @Schema(description = "类型，指按钮操作（审核通过、审核驳回、设置调货价、批量发布商品）")
    private String type;
    @Schema(description = "模块：页面菜单名称，如商品管理")
    private String module;
    @Schema(description = "服务名称：例如purchase-product")
    private String service;
    @Schema(description = "状态：0：未执行 1：执行中 2：执行成功 3：执行失败")
    private String status;
    @Schema(description = "请求参数，用于保存用户当前执行的参数")
    private String requestParam;
    @Schema(description = "执行结果类型：1: url  2：text")
    private String resultType;
    @Schema(description = "执行结果内容")
    private String resultContent;
    @Schema(description = "下载次数")
    private Integer downloadNum;
    @Schema(description = "备注")
    private String remark;
    @Schema(description = "创建人")
    private String createdName;
    @Schema(description = "创建时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createdAt;
    @Schema(description = "更新时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime updatedAt;

}
