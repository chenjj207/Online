package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.TaskManage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.TaskCommitRequest;
import com.purchase.service.dto.TaskDTO;
import com.purchase.service.vo.TaskCreatedByVO;
import com.purchase.service.vo.TaskSearchVO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 任务管理 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2024-12-24
 */
public interface TaskManageService extends IService<TaskManage> {

    /**
     * 任务提交
     *
     * @param request
     * @Author: loine
     * @Date: 2024/12/27 9:32
     */
    Integer commit(TaskCommitRequest request);

    /**
     * 搜索
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/12/26 17:00
     */
    Page<TaskSearchVO> search(TaskDTO.SearchDTO dto);

    /**
     * 下载
     *
     * @param response
     * @param dto
     * @Author: loine
     * @Date: 2024/12/28 10:57
     */
    void download(HttpServletResponse response, TaskDTO.BaseDTO dto);

    /**
     * 重新执行
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/12/26 17:51
     */
    Integer reExecute(TaskDTO.BaseDTO dto);

    /**
     * 任务详情
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/12/27 10:16
     */
    TaskManage detail(TaskDTO.BaseDTO dto);

    /**
     * 更新任务
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/12/27 11:07
     */
    Integer taskUpdate(TaskDTO.UpdateDTO dto);

    /**
     * 创建任务
     *
     * @param task
     * @return
     */
    Integer create(TaskManage task);

    /**
     * 更新任务
     *
     * @param task
     * @return
     */
    Integer update(TaskManage task);

    /**
     * 创建人列表
     *
     * @Author loine
     * @Date 2025/8/20 10:52
     */
    List<TaskCreatedByVO> createdByList();

    /**
     * 模块列表
     *
     * @Author loine
     * @Date 2025/12/13 09:44
     */
    List<String> moduleList();

    /**
     * 获取类型列表
     *
     * @Author loine
     * @Date 2026/4/20 14:20
     */
    List<String> typeList();

    /**
     * 多个任务合并明细导出
     *
     * @param response
     * @param dto
     * @Author loine
     * @Date 2025/12/13 16:22
     */
    void taskMergeExport(HttpServletResponse response, TaskDTO.@Valid MergeExportDTO dto);
}
