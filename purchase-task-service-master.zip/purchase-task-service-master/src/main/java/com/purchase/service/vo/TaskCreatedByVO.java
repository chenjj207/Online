package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/8/20 10:46
 */
@Data
public class TaskCreatedByVO {
    @Schema(description = "创建者")
    private String createdBy;
    @Schema(description = "创建者姓名")
    private String createdName;
}
