package com.purchase;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

/**
 * 项目启动类
 * @author jidonglin
 */
@SpringCloudApplication
@ServletComponentScan(basePackages = {"com.purchase.*", "com.zyd.*"})
@ComponentScan(basePackages = {"com.purchase.**", "com.zyd.**"})
@MapperScan("com.purchase.mapper")
@EnableFeignClients
@RefreshScope
@EnableHystrix
public class TaskApplication {
    public static void main(String[] args) {
        SpringApplication.run(TaskApplication.class, args);
    }
}
