package com.purchase.config;

import com.zyd.framework.utils.exception.BaseExceptionDesc;
import com.zyd.framework.utils.exception.BusinessExceptionDesc;

/**
 * @author jidonglin
 * @Description: 服务异常码
 * @date 2024/12/27  09:12
 */
public class PurchaseBusinessExceptionDesc extends BusinessExceptionDesc {
    public static BaseExceptionDesc NO_LOGIN = new BaseExceptionDesc(-70001, "未登录");
}

