package com.purchase.config;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.core.JmsMessagingTemplate;

import javax.annotation.PostConstruct;
import javax.jms.ConnectionFactory;
import java.util.concurrent.Executors;

@EnableJms
@Configuration
public class ActiveMqConfig {

    private final Logger logger = LoggerFactory.getLogger(ActiveMqConfig.class);

    @Value("${spring.activemq.broker-url}")
    private String brokerUrl;

    @Value("${spring.activemq.user}")
    private String username;

    @Value("${spring.activemq.password}")
    private String password;

    @PostConstruct
    public void init() {
        logger.warn("【ActiveMq 连接成功】");
    }

    @Value("${spring.jms.listener.concurrency}")
    private int concurrency;


    // 在Queue模式中，对消息的监听需要对containerFactory进行配置
    @Bean("topicListener")
    public JmsListenerContainerFactory<?> topicListenerFactory(ConnectionFactory connectionFactory) {
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        factory.setPubSubDomain(true);
        factory.setConnectionFactory(connectionFactory);
        //并发消费
        factory.setTaskExecutor(Executors.newFixedThreadPool(concurrency));
        factory.setConcurrency(String.valueOf(concurrency));
        return factory;

    }


    //在Topic模式中，对消息的监听需要对containerFactory进行配置
    @Bean("queueListener")
    public JmsListenerContainerFactory<?> queueListenerFactory(ConnectionFactory connectionFactory) {
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        factory.setPubSubDomain(false);
        factory.setConnectionFactory(connectionFactory);
        //并发消费
        factory.setTaskExecutor(Executors.newFixedThreadPool(concurrency));
        factory.setConcurrency(String.valueOf(concurrency));
        return factory;

    }

//    @Bean
//    public PlatformTransactionManager jmsTransactionManager(ConnectionFactory connectionFactory){
//        return new JmsTransactionManager(connectionFactory);
//    }


    @Bean
    public ConnectionFactory connectionFactory(){
        return new ActiveMQConnectionFactory(username, password, brokerUrl);
    }

    @Bean
    public JmsMessagingTemplate jmsMessageTemplate(){
        return new JmsMessagingTemplate(connectionFactory());
    }
}
