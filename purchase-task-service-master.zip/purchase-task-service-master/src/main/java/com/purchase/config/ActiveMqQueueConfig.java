package com.purchase.config;

import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.jms.Queue;

/**
 * @author jidonglin
 * @Description: 队列配置
 * @date 2024/12/24  14:15
 */
@Configuration
public class ActiveMqQueueConfig {
    // 产品服务-审核任务队列
    @Value("${mq.queue.task.product-approve}")
    private String productApproveQueue;

    @Bean(name = "productApproveQueue")
    public Queue productApproveQueue() {
        return new ActiveMQQueue(productApproveQueue);
    }

    // 产品服务-导出任务队列
    @Value("${mq.queue.task.product-export}")
    private String productExportQueue;

    @Bean(name = "productExportQueue")
    public Queue productExportQueue() {
        return new ActiveMQQueue(productExportQueue);
    }

    // 公海产品服务-关联ERP编码任务队列
    @Value("${mq.queue.task.public-product-RelevanceErp}")
    private String publicProductRelevanceErpQueue;

    @Bean(name = "publicProductRelevanceErpQueue")
    public Queue publicProductRelevanceErpQueue() {
        return new ActiveMQQueue(publicProductRelevanceErpQueue);
    }

    // 公海产品服务-导出任务队列
    @Value("${mq.queue.task.public-product-export}")
    private String publicProductExportQueue;

    @Bean(name = "publicProductExportQueue")
    public Queue publicProductExportQueue() {
        return new ActiveMQQueue(publicProductExportQueue);
    }

    // 公海产品服务-商品清单导入任务队列
    @Value("${mq.queue.task.public-product-listImport}")
    private String publicProductListImportQueue;

    @Bean(name = "publicProductListImportQueue")
    public Queue publicProductListImportQueue() {
        return new ActiveMQQueue(publicProductListImportQueue);
    }

    // elvo产品服务任务队列
    @Value("${mq.queue.task.elvo-product-approve}")
    private String elvoProductApproveQueue;

    @Bean(name = "elvoProductApproveQueue")
    public Queue elvoProductApproveQueue() {
        return new ActiveMQQueue(elvoProductApproveQueue);
    }

    // elvo产品服务-导出任务队列
    @Value("${mq.queue.task.elvo-product-export}")
    private String elvoProductExportQueue;

    @Bean(name = "elvoProductExportQueue")
    public Queue elvoProductExportQueue() {
        return new ActiveMQQueue(elvoProductExportQueue);
    }

    // elvo公海产品服务-导出任务队列
    @Value("${mq.queue.task.elvo-public-product-export}")
    private String elvoPublicProductExportQueue;

    @Bean(name = "elvoPublicProductExportQueue")
    public Queue elvoPublicProductExportQueue() {
        return new ActiveMQQueue(elvoPublicProductExportQueue);
    }
}
