package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 任务管理
* </p>
*
* @author jidonglin
* @since 2024-12-24
*/
@Data
@TableName("t_task_manage")
@Schema(title = "任务管理")
public class TaskManage extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "类型，指按钮操作（审核通过、审核驳回、设置调货价、批量发布商品、关联ERP编码）")
    @TableField("type")
    private String type;

    @Schema(description = "模块：页面菜单名称，如商品管理")
    @TableField("module")
    private String module;

    @Schema(description = "服务名称：例如purchase-product")
    @TableField("service")
    private String service;

    @Schema(description = "状态：0：未执行 1：执行中 2：执行成功 3：执行失败")
    @TableField("status")
    private String status;

    @Schema(description = "请求参数，用于保存用户当前执行的参数")
    @TableField("request_param")
    private String requestParam;

    @Schema(description = "执行结果类型：1: url  2：text")
    @TableField("result_type")
    private String resultType;

    @Schema(description = "执行结果内容")
    @TableField("result_content")
    private String resultContent;

    @Schema(description = "下载次数")
    @TableField("download_num")
    private Integer downloadNum;

    @Schema(description = "备注")
    @TableField("remark")
    private String remark;




}
