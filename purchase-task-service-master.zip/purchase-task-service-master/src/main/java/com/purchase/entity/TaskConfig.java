package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 任务管理
* </p>
*
* @author jidonglin
* @since 2024-12-24
*/
@Data
@TableName("t_task_config")
@Schema(title = "任务配置")
public class TaskConfig extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Schema(description = "查看所有任务数据工号（多个逗号隔开）")
    @TableField("all_data_code")
    private String allDataCode;
}
