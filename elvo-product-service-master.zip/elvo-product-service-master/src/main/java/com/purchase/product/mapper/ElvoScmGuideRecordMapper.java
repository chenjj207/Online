package com.purchase.product.mapper;

import com.purchase.product.model.ElvoScmGuideRecord;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 * @Description:
 * @Author: loine
 * @Date: 2024/11/5 14:01
 **/
public interface ElvoScmGuideRecordMapper extends QguBaseMapper<ElvoScmGuideRecord> {

}
