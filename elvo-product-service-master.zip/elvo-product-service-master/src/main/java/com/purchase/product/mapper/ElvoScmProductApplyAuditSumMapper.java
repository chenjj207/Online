package com.purchase.product.mapper;

import com.purchase.product.model.ElvoScmProductApplyAuditSum;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/12/15 13:56
 */
public interface ElvoScmProductApplyAuditSumMapper extends QguBaseMapper<ElvoScmProductApplyAuditSum> {

    /**
     * 相同供应商+相同品牌维度下，获取最近一行类型=‘提报数据’的事件结果数量
     *
     * @Author loine
     * @Date 2025/12/15 15:13
     */
    Integer getLastResultNum(@Param("supplierId") String supplierId, @Param("brandName") String brandName);
}
