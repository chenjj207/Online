package com.purchase.product.activemq;

import com.purchase.product.service.ElvoScmProductApplyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


/**
 * @author jidonglin
 * @Description: 商家队列消费
 * @date 2024/12/24  14:30
 */
@Component
@Slf4j
public class QueueConsumerListener {

    @Resource
    private ElvoScmProductApplyService elvoScmProductApplyService;

    // 审核
    @JmsListener(destination = "${mq.queue.task.elvo-product-approve}", containerFactory = "queueListener", concurrency = "1")
    public void readElvoProductApproveQueue(String message) {
        elvoScmProductApplyService.readElvoProductApproveQueue(message);
    }

    // 导出
    @JmsListener(destination = "${mq.queue.task.elvo-product-export}", containerFactory = "queueListener", concurrency = "1")
    public void readProductExportQueue(String message) {
        elvoScmProductApplyService.readElvoProductExportQueue(message);
    }
}
