package com.purchase.product.mapper;

import com.purchase.product.model.PurchaseMsgCompanyUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.BaseMapper;

import java.util.List;

/**
 * @Description:
 * @Author: loine
 * @Date: 2024/11/13 9:29
 **/
@Mapper
public interface PurchaseMsgCompanyUserMapper extends BaseMapper<PurchaseMsgCompanyUser> {

    /**
     * 根据子公司id获取审核人员
     * @param companyId
     * @Author: loine
     * @Date: 2024/11/13 9:33
     */
    List<PurchaseMsgCompanyUser> selectByCompanyId(@Param("companyId") Integer companyId);
}
