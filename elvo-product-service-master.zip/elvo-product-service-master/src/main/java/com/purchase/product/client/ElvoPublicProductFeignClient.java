package com.purchase.product.client;

import com.purchase.model.PurchaseProductSync;
import com.purchase.product.dto.CommonProductTaskDto;
import com.purchase.product.vo.CommonProductVo;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import feign.hystrix.FallbackFactory;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.*;

/**
 *  elvo公海服务
 */
@FeignClient(value = "elvo-public-product", path = "/publicProductFeign", fallbackFactory = ElvoPublicProductFeignClient.PublicProductFeignClientHystrix.class)
public interface ElvoPublicProductFeignClient {

    @PostMapping(value = "/public/elvoProductSync")
    @ApiOperation(value = "产品同步至ELVO公海")
    JsonResult<Long> elvoProductSync(@RequestBody PurchaseProductSync purchaseProductSync);

    @PostMapping(value = "/public/elvoProductList")
    @ApiOperation(value = "ELVO慧采列表")
    List<CommonProductVo> elvoProductList(@RequestBody CommonProductTaskDto dto);

    @Slf4j
    @Component
    class PublicProductFeignClientHystrix implements FallbackFactory<ElvoPublicProductFeignClient> {
        @Override
        public ElvoPublicProductFeignClient create(Throwable throwable) {
            return new ElvoPublicProductFeignClient() {

                @Override
                public JsonResult<Long> elvoProductSync(PurchaseProductSync purchaseProductSync) {
                    return null;
                }

                @Override
                public List<CommonProductVo> elvoProductList(CommonProductTaskDto dto) {
                    return null;
                }

            };
        }
    }

}
