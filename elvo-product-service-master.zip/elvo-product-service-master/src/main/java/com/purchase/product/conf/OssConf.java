package com.purchase.product.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @ClassName: OssConf
 * @author zhangcheng
 * @Date: 2022-08-10
 **/
@Component
@ConfigurationProperties(prefix = "oss")
@Data
public class OssConf {
    private String endpoint;
    private String accessKeySecret;
    private String accessKeyId;
    private String bucketName;
    private String ossUrl;
    private String corpOssPrex;
    private String smallPreix;
    private String dir;
}
