package com.purchase.product.controller;

import com.purchase.product.dto.ElvoScmProductApplyDto;
import com.purchase.product.service.ElvoScmProductApplyService;
import com.purchase.product.vo.ElvoScmProductApplyVo;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * @Description: ELVO_SCM产品申请服务提供类
 * @Author: loine
 * @Date: 2025/4/14 9:47
 **/
@RestController
@RequestMapping(value = "/elvoScmProductApply")
@Api(value = "ElvoScmProductApplyController", tags = {"ELVO_SCM产品申请服务提供类"})
@Slf4j
public class ElvoScmProductApplyController {

    @Resource
    private ElvoScmProductApplyService elvoScmProductApplyService;

    @PostMapping(value = "/supplier/search")
    @ApiOperation(value = "供应商-搜索")
    public JsonResult<Page<ElvoScmProductApplyVo.SupplierSearchVo>> supplierSearch(@Valid @RequestBody ElvoScmProductApplyDto.SupplierSearchDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.supplierSearch(dto));
    }

    @PostMapping(value = "/supplier/count")
    @ApiOperation(value = "供应商-搜索角标")
    public JsonResult<ElvoScmProductApplyVo.SearchCountVo> supplierSearchCount(@Valid @RequestBody ElvoScmProductApplyDto.SupplierSearchDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.supplierSearchCount(dto));
    }

    @PostMapping(value = "/supplier/detail")
    @ApiOperation(value = "供应商-详情")
    public JsonResult<ElvoScmProductApplyVo.SupplierDetailVo> supplierDetail(@Valid @RequestBody ElvoScmProductApplyDto.BaseDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.supplierDetail(dto.getId()));
    }

    @PostMapping(value = "/supplier/randomDetail")
    @ApiOperation(value = "供应商-随机商品详情")
    public JsonResult<ElvoScmProductApplyVo.SupplierRandomDetailVo> supplierRandomDetail(@Valid @RequestBody ElvoScmProductApplyDto.SupplierRandomDetailDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.supplierRandomDetail(dto));
    }

    @PostMapping(value = "/supplier/selectDelivery")
    @ApiOperation(value = "供应商-选择货期")
    public JsonResult<ElvoScmProductApplyVo.SupplierSelectDeliveryVo> supplierSelectDelivery() {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.supplierSelectDelivery());
    }

    @PostMapping(value = "/supplier/checkIsApply")
    @ApiOperation(value = "供应商-校验是否已经申请过")
    public JsonResult supplierCheckIsApply(@Valid @RequestBody ElvoScmProductApplyDto.SupplierCheckIsApplyDto dto){
        return elvoScmProductApplyService.supplierCheckIsApply(dto);
    }

    @PostMapping(value = "/supplier/downloadImportTemplate")
    @ApiOperation(value = "供应商-下载导入模板/导出数据")
    public void supplierDownloadImportTemplate(HttpServletRequest request, HttpServletResponse response, @Valid @RequestBody ElvoScmProductApplyDto.SupplierDownloadImportTemplateDto dto){
        elvoScmProductApplyService.supplierDownloadImportTemplate(request, response, dto);
    }

    @PostMapping(value = "/supplier/readImportTemplate")
    @ApiOperation(value = "供应商-读取导入数据")
    public JsonResult<List<Map<String, String>>> supplierReadImportTemplate(@RequestParam("file") @ApiParam("上传文件") MultipartFile file, @RequestParam("type") @ApiParam("类型（1=新增，2=修改）") String type, @RequestParam("specNames") @ApiParam("规格名数组") List<String> specNames){
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.supplierReadImportTemplate(file, type, specNames));
    }

    @PostMapping(value = "/supplier/sameSearch")
    @ApiOperation(value = "供应商-相同型号搜索")
    public JsonResult<Page<ElvoScmProductApplyVo.SupplierSameSearchVo>> supplierSameSearch(@Valid @RequestBody ElvoScmProductApplyDto.SupplierSameSearchDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.supplierSameSearch(dto));
    }

    @PostMapping(value = "/supplier/sameSelector")
    @ApiOperation(value = "供应商-相同型号搜索选择器")
    public JsonResult<ElvoScmProductApplyVo.SupplierSameSelectorVo> supplierSameSelector(@Valid @RequestBody ElvoScmProductApplyDto.SupplierSameSearchDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.supplierSameSelector(dto));
    }

    @PostMapping(value = "/supplier/cancel")
    @ApiOperation(value = "供应商-批量撤销")
    public JsonResult supplierCancel(@Valid @RequestBody ElvoScmProductApplyDto.SupplierCancelDto dto){
        return elvoScmProductApplyService.supplierCancel(dto);
    }

    @PostMapping(value = "/supplier/delete")
    @ApiOperation(value = "供应商-批量删除")
    public JsonResult supplierDelete(@Valid @RequestBody ElvoScmProductApplyDto.SupplierSearchDto dto){
        return elvoScmProductApplyService.supplierDelete(dto);
    }

    @PostMapping(value = "/supplier/applyExport")
    @ApiOperation(value = "供应商-商品申请列表导出")
    public void supplierApplyExport(HttpServletRequest request, HttpServletResponse response, @Valid @RequestBody ElvoScmProductApplyDto.SupplierSearchDto dto){
        elvoScmProductApplyService.supplierApplyExport(request, response, dto);
    }

    @PostMapping(value = "/supplier/mySearch")
    @ApiOperation(value = "供应商-我的商品搜索")
    public JsonResult<Page<ElvoScmProductApplyVo.SupplierMySearchVo>> supplierMySearch(@Valid @RequestBody ElvoScmProductApplyDto.SupplierMySearchDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.supplierMySearch(dto));
    }

    @PostMapping(value = "/supplier/myCount")
    @ApiOperation(value = "供应商-我的商品搜索角标")
    public JsonResult<ElvoScmProductApplyVo.SupplierMySearchCountVo> supplierMySearchCount(@Valid @RequestBody ElvoScmProductApplyDto.SupplierMySearchDto dto) {
        return new JsonResult<>(true, null, elvoScmProductApplyService.supplierMySearchCount(dto));
    }

    @PostMapping(value = "/supplier/myOnsale")
    @ApiOperation(value = "供应商-我的商品上下架")
    public JsonResult supplierMyOnsale(@Valid @RequestBody ElvoScmProductApplyDto.SupplierMyOnsaleDto dto){
        return elvoScmProductApplyService.supplierMyOnsale(dto);
    }

    @PostMapping(value = "/supplier/myExport")
    @ApiOperation(value = "供应商-我的商品导出")
    public void supplierMyExport(HttpServletRequest request, HttpServletResponse response, @Valid @RequestBody ElvoScmProductApplyDto.SupplierMySearchDto dto){
        elvoScmProductApplyService.supplierMyExport(request, response, dto);
    }

    @PostMapping(value = "/supplier/publish")
    @ApiOperation(value = "供应商-批量发布")
    public JsonResult supplierPublish(@Valid @RequestBody ElvoScmProductApplyDto.SupplierPublishDto dto){
        return elvoScmProductApplyService.supplierPublish(dto);
    }

    @PostMapping(value = "/supplier/publishDraft")
    @ApiOperation(value = "供应商-批量发布待提交")
    public JsonResult supplierPublishDraft(@Valid @RequestBody ElvoScmProductApplyDto.SupplierPublishDraftDto dto){
        return elvoScmProductApplyService.supplierPublishDraft(dto);
    }
    
    @PostMapping(value = "/supplier/edit")
    @ApiOperation(value = "供应商-批量编辑修改")
    public JsonResult supplierEdit(@Valid @RequestBody ElvoScmProductApplyDto.SupplierPublishDto dto){
        return elvoScmProductApplyService.supplierEdit(dto);
    }
    
    @PostMapping(value = "/supplier/editDraft")
    @ApiOperation(value = "供应商-批量编辑待提交")
    public JsonResult supplierEditDraft(@Valid @RequestBody ElvoScmProductApplyDto.SupplierPublishDraftDto dto){
        return elvoScmProductApplyService.supplierEditDraft(dto);
    }
    
    @PostMapping(value = "/supplier/getGuide")
    @ApiOperation(value = "供应商-获取引导启用状态")
    public JsonResult<ElvoScmProductApplyVo.SupplierGetGuideVo> supplierGetGuide(@Valid @RequestBody ElvoScmProductApplyDto.SupplierGetGuideDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.supplierGetGuide(dto));
    }

    @PostMapping(value = "/supplier/addGuide")
    @ApiOperation(value = "供应商-添加引导记录")
    public JsonResult supplierAddGuide(@Valid @RequestBody ElvoScmProductApplyDto.SupplierGetGuideDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.addGuide(dto));
    }

    @PostMapping(value = "/admin/search")
    @ApiOperation(value = "后台-搜索")
    public JsonResult<Page<ElvoScmProductApplyVo.AdminSearchVo>> adminSearch(@Valid @RequestBody ElvoScmProductApplyDto.AdminSearchDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.adminSearch(dto));
    }

    @PostMapping(value = "/admin/count")
    @ApiOperation(value = "后台-搜索角标")
    public JsonResult<ElvoScmProductApplyVo.SearchCountVo> adminSearchCount(@Valid @RequestBody ElvoScmProductApplyDto.AdminSearchDto dto) {
        return new JsonResult<>(true, null, elvoScmProductApplyService.adminSearchCount(dto));
    }

    @PostMapping(value = "/admin/detail")
    @ApiOperation(value = "后台-详情")
    public JsonResult<ElvoScmProductApplyVo.SupplierDetailVo> adminDetail(@Valid @RequestBody ElvoScmProductApplyDto.BaseDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.adminDetail(dto.getId()));
    }

    @PostMapping(value = "/admin/sameSearch")
    @ApiOperation(value = "后台-相同型号搜索")
    public JsonResult<Page<ElvoScmProductApplyVo.SupplierSameSearchVo>> adminSameSearch(@Valid @RequestBody ElvoScmProductApplyDto.AdminSameSearchDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.adminSameSearch(dto));
    }

    @PostMapping(value = "/admin/sameSelector")
    @ApiOperation(value = "后台-相同型号搜索选择器")
    public JsonResult<ElvoScmProductApplyVo.SupplierSameSelectorVo> adminSameSelector(@Valid @RequestBody ElvoScmProductApplyDto.AdminSameSearchDto dto) {
        return new JsonResult<>(true, "查询成功", elvoScmProductApplyService.adminSameSelector(dto));
    }

}
