package com.purchase.product.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/2/20 9:59
 **/
@Data
@ApiModel("供应商_ELVO_SCM产品申请_审核记录表")
@Table(name = "t_pd_elvo_scm_product_apply_audit_record")
public class ElvoScmProductApplyAuditRecord extends BaseCorpModel {

    public static final String ID = "id";
    public static final String APPLY_NO = "applyNo";

    @ApiModelProperty("申请编号")
    private Long applyNo;
    @ApiModelProperty("审核前状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回）")
    private Integer auditStatusBefore;
    @ApiModelProperty("审核后状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回）")
    private Integer auditStatusAfter;
    @ApiModelProperty("审核时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime;
    @ApiModelProperty("审核备注")
    private String auditRemark;
}
