package com.purchase.product.mapper;

import com.purchase.product.model.ElvoScmGuideConfig;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 * @Description:
 * @Author: loine
 * @Date: 2024/11/5 14:01
 **/
public interface ElvoScmGuideConfigMapper extends QguBaseMapper<ElvoScmGuideConfig> {

}
