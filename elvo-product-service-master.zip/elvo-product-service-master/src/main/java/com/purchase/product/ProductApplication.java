package com.purchase.product;

import com.github.ltsopensource.spring.boot.annotation.EnableTaskTracker;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import tk.mybatis.spring.annotation.MapperScan;

/**
 * product 项目启动类文件
 *
 * @author auto
 * @version 1.0
 * @since 2021-06-21 11:32:34
 */
@EnableFeignClients({"com.purchase.product.**","com.qgutech.qgyun.dev.client.**"})
@SpringCloudApplication
@ComponentScan({"com.qgutech.qgyun.dev.client.**","com.purchase.**","com.purchase.product.**"})
@MapperScan({"com.purchase.product.**.mapper"})
//@EnableTaskTracker
public class ProductApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProductApplication.class, args);
    }
}
