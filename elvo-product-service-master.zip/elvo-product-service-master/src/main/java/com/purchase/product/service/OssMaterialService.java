package com.purchase.product.service;

import cn.hutool.core.io.IoUtil;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.*;
import com.purchase.product.conf.OssConf;
import com.purchase.product.dto.oss.OssResourceDto;
import com.purchase.product.util.MD5Util;
import com.purchase.utils.date.ZydDateUtils;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.*;

/**
 * OssMaterialService 服务提供类
 *
 * @author zhangcheng
 * @version 1.0
 * @since 2022-08-10
 */
@Service
@Slf4j
public class OssMaterialService {

    @Autowired
    private OssConf ossConf;

    /**
     * 检查当前目录是否达到最大数
     *
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    private void checkMax1000(OSS ossClient, String path) {
        String prefix = ContextHandler.getCorpCode() + ossConf.getCorpOssPrex() + path;
        // 分页列举，每次传入上次返回结果中的nextContinuationToken。
        ListObjectsV2Request listObjectsV2Request = new ListObjectsV2Request(ossConf.getBucketName())
                .withMaxKeys(1000)
                .withPrefix(prefix)
                .withDelimiter("/")
                .withFetchOwner(false);
        ListObjectsV2Result result = ossClient.listObjectsV2(listObjectsV2Request);
        if (result.isTruncated()) {
            ossClient.shutdown();
            log.error("========================当前目录已达最大数量：" + path + "==========================");
            throw new BaseException("-1", "当前目录已达最大数量");
        }
    }

    /**
     * scm上传接口
     *
     * @param path
     * @param fileUploads
     * @Author: loine
     * @Date: 2024/10/18 13:24
     */
    public JsonResult scmUploadResource(String path, MultipartFile[] fileUploads) {
        if (fileUploads == null || fileUploads.length == 0) {
            return new JsonResult(false, "请选择文件");
        }
        if (fileUploads.length > 20) {
            return new JsonResult(false, "单次最多上传20个文件");
        }
        File file;
        FileOutputStream os = null;
        OSS ossClient;
        // 初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        checkMax1000(ossClient, path);
        Map<String, Object> resultMap = new HashMap<>();
        StringBuilder resultPath = new StringBuilder();
        try {
            // 限制大小
            for (MultipartFile fileUpload : fileUploads) {
                String originalFilename = Objects.requireNonNull(fileUpload.getOriginalFilename()).replace("/", "");
                String suffix = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
                if (suffix.equalsIgnoreCase("jpg") || suffix.equalsIgnoreCase("png") || suffix.equalsIgnoreCase("gif")) {
                    if (fileUpload.getSize() > 10 * 1024 * 1024) {
                        return new JsonResult(false, "图片大小不超过10M");
                    }
                } else if (suffix.equalsIgnoreCase("mp4")) {
                    if (fileUpload.getSize() > 50 * 1024 * 1024) {
                        return new JsonResult(false, "视频不超过50M");
                    }
                } else if (suffix.equalsIgnoreCase("pdf")) {
                    if (fileUpload.getSize() > 100 * 1024 * 1024) {
                        return new JsonResult(false, "上传文件超过100M，请检查");
                    }
                } else {
                    return new JsonResult(false, "上传文件格式有误，请检查");
                }
            }
            String supplierCode = (String) ContextHandler.get("supplierId");
            path = (StringUtils.isEmpty(supplierCode) ? "" : supplierCode) + (StringUtils.isBlank(path) ? "" : path);
            if (StringUtils.isNotBlank(ossConf.getDir())) {
                path = ossConf.getDir() + "/" + path;
            }
            String newPath;
            for (MultipartFile fileUpload : fileUploads) {
                String originalFilename = Objects.requireNonNull(fileUpload.getOriginalFilename()).replace("/", "");
                String suffix = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
                if (!suffix.equals("pdf")) {
                    // 文件转base64，MD5之后做为新文件名称
                    String base64String = Base64.getEncoder().encodeToString(fileUpload.getBytes());
                    String newFileName = MD5Util.MD5(base64String);
                    newPath = path + newFileName + "." + suffix;
                } else {
                    newPath = path + originalFilename;
                }
                file = new File(suffix);
                os = new FileOutputStream(file);
                os.write(fileUpload.getBytes());
                fileUpload.transferTo(file);
                // 填写Bucket名称和Object完整路径。Object完整路径中不能包含Bucket名称。
                // 如果存在，则不做上传
                if (!ossClient.doesObjectExist(ossConf.getBucketName(), newPath)) {
                    // 上传文件
                    PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(), newPath, file));
                    // 设置权限(公开读)
                    ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
                    if (result == null) {
                        // 上传失败，抛出提示
                        return new JsonResult(false, "上传失败");
                    }
                }
                resultPath.append(newPath).append(",");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return new JsonResult(false, "上传异常");
        } finally {
            IoUtil.close(os);
            ossClient.shutdown();
        }
        if (resultPath.length() > 0) {
            resultPath.deleteCharAt(resultPath.length() - 1);
        }
        resultMap.put("urlPrefix", ossConf.getOssUrl());
        resultMap.put("path", resultPath.toString());
        return new JsonResult<>(true, "", resultMap);
    }

    /**
     * scm上传接口（根据全路径）
     *
     * @param path
     * @param url
     * @Author: loine
     * @Date: 2024/10/23 17:36
     */
    public String scmUploadResourceByUrl(String path, String url) {
        OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        InputStream is = null;
        String newPath = "";
        try {
            String supplierCode = (String) ContextHandler.get("supplierId");
            path = (StringUtils.isEmpty(supplierCode) ? "" : supplierCode) + (StringUtils.isBlank(path) ? "" : path);
            String suffix = url.substring(url.lastIndexOf(".") + 1);

            String newFileName = MD5Util.MD5(path);
            newPath = path + newFileName + "." + suffix;
            if (StringUtils.isNotBlank(ossConf.getDir())) {
                newPath = ossConf.getDir() + "/" + newPath;
            }
            // 如果存在，则不做上传
            if (!ossClient.doesObjectExist(ossConf.getBucketName(), newPath)) {
                // 使用java语言对这个地址进行连接并读取
                HttpURLConnection httpUrl = (HttpURLConnection) new URL(url).openConnection();
                httpUrl.connect();
                is = httpUrl.getInputStream();
                // 上传文件
                PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(), newPath, is));
                // 设置权限(公开读)
                ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(is);
            ossClient.shutdown();
        }
        return newPath;
    }

    /**
     * 上传接口（根据流）
     *
     * @param newPath
     * @param is
     * @Author: loine
     * @Date: 2024/12/27 11:38
     */
    public String uploadResourceByIs(String newPath, ByteArrayInputStream is) {
        OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        try {
            // 上传文件
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(), newPath, is));
            // 设置权限(公开读)
            ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(is);
            ossClient.shutdown();
        }
        return ossConf.getOssUrl() + newPath;
    }

    /**
     * 获取oss目录下的资源数据
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    public OssResourceDto getResource(String path, String nextContinuationToken, String prefix, int maxKeys) {
        String corpCodeOss = getOssCorpCode();
        //初始化ossclient
        OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        if(maxKeys<=0){
            maxKeys = 10;
        }
        ListObjectsV2Result result;
        prefix = corpCodeOss + (StringUtils.isBlank(path)?"":path.trim()) + (StringUtils.isBlank(prefix)?"":prefix.trim());//指定目录，到时候就是指定分配租户的文件夹
        // 分页列举，每次传入上次返回结果中的nextContinuationToken。
        ListObjectsV2Request listObjectsV2Request = new ListObjectsV2Request(ossConf.getBucketName())
                .withMaxKeys(maxKeys)
                .withPrefix(prefix)
                .withDelimiter("/")
                .withFetchOwner(false);
        listObjectsV2Request.setContinuationToken(StringUtils.isBlank(nextContinuationToken)?null:nextContinuationToken);
        result = ossClient.listObjectsV2(listObjectsV2Request);
        OssResourceDto ossResourceDto = new OssResourceDto();
        List<OssResourceDto.OssResourceSubDto> ossResourceSubDtos = new ArrayList<>();
        OssResourceDto.OssResourceSubDto ossResourceSubDto;
        //列出文件夹
        List<String> commonPrefixes = result.getCommonPrefixes();
        String fileName;
        if(commonPrefixes!=null&&commonPrefixes.size()>0){
            for(String directory:commonPrefixes){
                fileName = directory.split("[/]")[directory.split("[/]").length-1];
                if(StringUtils.isBlank(fileName)){
                    continue;
                }
                ossResourceSubDto = new OssResourceDto.OssResourceSubDto();
                ossResourceSubDto.setFileName(fileName);
                ossResourceSubDto.setFileType("directory");
                ossResourceSubDto.setPath(directory.replace(corpCodeOss,""));
                ossResourceSubDto.setFileSize(0L);
                ossResourceSubDto.setLastUpdateTime("");
                ossResourceSubDtos.add(ossResourceSubDto);
            }
        }
        //列出具体文件
        List<OSSObjectSummary> sums = result.getObjectSummaries();
        for (OSSObjectSummary s : sums) {
            if(s.getKey().equals(prefix)&&!s.getKey().split("[/]")[s.getKey().split("[/]").length-1].contains(".")){
                continue;
            }
            fileName = s.getKey().split("[/]")[s.getKey().split("[/]").length-1];
            ossResourceSubDto = new OssResourceDto.OssResourceSubDto();
            ossResourceSubDto.setFileName(fileName);
            ossResourceSubDto.setFileSize(s.getSize());
            ossResourceSubDto.setFileType("");
            if(ossResourceSubDto.getFileName().split("[.]").length==2
                    &&((ossResourceSubDto.getFileName().split("[.]")[1]).equalsIgnoreCase("jpg")
                    ||(ossResourceSubDto.getFileName().split("[.]")[1]).equalsIgnoreCase("png"))){
                ossResourceSubDto.setFileType("image");
                try {
                    ossResourceSubDto.setFileSmallImg(ossConf.getOssUrl()+prefix+ URLEncoder.encode(ossResourceSubDto.getFileName(),"UTF-8")+ossConf.getSmallPreix());
                }catch (Exception e){
                }
            }
            ossResourceSubDto.setLastUpdateTime(DateUtil.formatDate(s.getLastModified(),DateUtil.DATE_PATTERN_yyyy_MM_dd_HH_MM_ss));
            ossResourceSubDto.setPath(s.getKey().replace(corpCodeOss,""));
            String url = "";
            try {
                url = URLEncoder.encode(ossResourceSubDto.getPath(), "UTF-8");
                url = ossConf.getOssUrl()+corpCodeOss+url;
            }catch (Exception e){
                log.error(e.getMessage(),e);
            }
            ossResourceSubDto.setUrl(url);
            ossResourceSubDtos.add(ossResourceSubDto);
        }
        nextContinuationToken = result.getNextContinuationToken();
        ossResourceDto.setTruncated(result.isTruncated());
        ossResourceDto.setList(ossResourceSubDtos);
        ossResourceDto.setNextContinuationToken(nextContinuationToken);
        ossClient.shutdown();
        return ossResourceDto;
    }

    /**
     * 重命名文件/文件夹
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    public JsonResult reNameResource(String path, String newFileName) {
        if(StringUtils.isBlank(newFileName)||newFileName.length()>50){
            return new JsonResult<>(false,"请输入50个字符以内的名称");
        }
        newFileName = newFileName.replace("/","").trim();
        String hasPath;
        //判断是不是需要修改名称
        hasPath =  path.replace(path.split("[/]")[path.split("[/]").length-1],newFileName);
        if(hasPath.equals(path)){
            return new JsonResult(true,"");
        }

        String corpCodeOss = getOssCorpCode();
        //初始化ossclient
        OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        String[] newPath = path.split("/");
        String newPathStr = "";
        for(String p:newPath){
            if(!p.equals(newPath[newPath.length-1])){
                newPathStr += "/"+p;
            }
        }
        newPathStr = corpCodeOss+(StringUtils.isNotBlank(newPathStr)?(newPathStr.substring(1)+"/"):"")+newFileName;
        //这里判断新地址是不是有存在相同的文件/文件夹
        // 填写Bucket名称和Object完整路径。Object完整路径中不能包含Bucket名称。
        if(ossClient.doesObjectExist(ossConf.getBucketName(), newPathStr)){
            return new JsonResult(false,"文件或文件夹已存在，操作失败");
        }
        //判断文件夹是否存在
        if(!newPathStr.split("[/]")[newPathStr.split("[/]").length-1].contains(".")){
            ListObjectsV2Request listObjectsV2Request = new ListObjectsV2Request(ossConf.getBucketName())
                    .withMaxKeys(100)
                    .withPrefix(newPathStr)
                    .withDelimiter("/")
                    .withFetchOwner(false);
            ListObjectsV2Result result = ossClient.listObjectsV2(listObjectsV2Request);
            //列出文件夹
            List<String> commonPrefixes = result.getCommonPrefixes();
            if(commonPrefixes!=null&&commonPrefixes.size()>0){
                for(String dir:commonPrefixes){
                    if(dir.equals(newPathStr+"/")){
                        return new JsonResult(false,"文件或文件夹已存在，操作失败");
                    }
                }
            }
        }
        path = corpCodeOss+path;
        final int maxKeys = 200;
        String nextMarker = null;
        ObjectListing objectListing;
        CopyObjectResult result;
        String newKey;
        Set<String> deletDir = new HashSet<>();
        do {
            objectListing = ossClient.listObjects(new ListObjectsRequest(ossConf.getBucketName()).withMarker(nextMarker).withMaxKeys(maxKeys).withPrefix(path));
            List<OSSObjectSummary> sums = objectListing.getObjectSummaries();
            for (OSSObjectSummary s : sums) {
                String repath = path;
                if(repath.endsWith("/")){
                    repath = path.substring(0,path.length()-1);
                }
                newKey = s.getKey().replace(repath,newPathStr);
                //如果是文件夹，就不要复制
                if(!s.getKey().split("/")[s.getKey().split("/").length-1].contains(".")){
                    createDir(ossClient,newKey);
                    deletDir.add(s.getKey());
                    continue;
                }
                // 拷贝文件
                result = ossClient.copyObject(ossConf.getBucketName(), s.getKey(), ossConf.getBucketName(), newKey);
                if(StringUtils.isNotBlank(result.getETag())){
                    //删除原文件
                    ossClient.deleteObject(ossConf.getBucketName(),s.getKey());
                }
            }
            nextMarker = objectListing.getNextMarker();
        } while (objectListing.isTruncated());
        //最后删除原文件夹
        ossClient.deleteObject(ossConf.getBucketName(),path);
        deletDir.stream().forEach(e->{
            ossClient.deleteObject(ossConf.getBucketName(),e);
        });
        // 关闭OSSClient。
        ossClient.shutdown();
        return new JsonResult<>(true,"");
    }

    /**
     * 创建文件夹
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    public JsonResult createResource(String fileName) {
        if(StringUtils.isBlank(fileName)){
            return new JsonResult<>(false,"请输入文件夹名称");
        }
        String corpCodeOss = getOssCorpCode();
        //初始化ossclient
        OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        //检查当前目录是否达到最大数
        String[] pathStr = fileName.split("/");
        String path = "";
        for(String s:pathStr){
            if(s.equals(pathStr[pathStr.length-1])){
                if(s.length()>20){
                    return new JsonResult<>(false,"请输入20个字符以内的名称");
                }
                break;
            }
            path += s + "/";
        }
        checkMax1000(ossClient,path);
        try {
            //校验是否有相同名称
            String prefix = corpCodeOss+fileName+"/";//指定目录，到时候就是指定分配租户的文件夹
            // 填写Bucket名称和Object完整路径。Object完整路径中不能包含Bucket名称。
            boolean found = ossClient.doesObjectExist(ossConf.getBucketName(), prefix);
            if(found){
                return new JsonResult(false,"文件或文件夹已存在，操作失败");
            }
            //创建文件夹
            createDir(ossClient,prefix);
        }catch (Exception e){
            log.error(e.getMessage(),e);
        }finally {
            // 关闭OSSClient。
            ossClient.shutdown();
        }
        return new JsonResult<>(true,"");
    }

    /**
     * 删除文件/文件夹
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    public JsonResult deleteResource(String path) {
        if(StringUtils.isNotBlank(path)){
            path = getOssCorpCode() + path;
            //初始化ossclient
            OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
            // 列举所有包含指定前缀的文件并删除。
            String nextMarker = null;
            ObjectListing objectListing;
            do {
                ListObjectsRequest listObjectsRequest = new ListObjectsRequest(ossConf.getBucketName())
                        .withPrefix(path)
                        .withMarker(nextMarker);
                objectListing = ossClient.listObjects(listObjectsRequest);
                if (objectListing.getObjectSummaries().size() > 0) {
                    List<String> keys = new ArrayList<String>();
                    for (OSSObjectSummary s : objectListing.getObjectSummaries()) {
                        keys.add(s.getKey());
                    }
                    DeleteObjectsRequest deleteObjectsRequest = new DeleteObjectsRequest(ossConf.getBucketName()).withKeys(keys);
                    ossClient.deleteObjects(deleteObjectsRequest);
                }
                nextMarker = objectListing.getNextMarker();
            } while (objectListing.isTruncated());
            // 关闭OSSClient。
            ossClient.shutdown();
        }
        return new JsonResult<>(true,"");
    }

    /**
     * 上传文件
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    public JsonResult uploadResource(String path, MultipartFile[] fileuploads) {
        if(fileuploads==null||fileuploads.length<=0){
            return new JsonResult(false,"请选择文件");
        }
        if(fileuploads.length>10){
            return new JsonResult(false,"单次最多上传10个文件");
        }
        File file;
        FileOutputStream os = null;
        OSS ossClient;
        //初始化ossclient
        ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        checkMax1000(ossClient,path);
        try {
            path = getOssCorpCode() + (StringUtils.isBlank(path)?"":path);
            String newPath;
            for(MultipartFile fileupload:fileuploads){
                String originalFilename = fileupload.getOriginalFilename().replace("/","");
                String suffix = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
                file = new File(suffix);
                os = new FileOutputStream(file);
                os.write(fileupload.getBytes());
                fileupload.transferTo(file);
                newPath = path+originalFilename;
                // 填写Bucket名称和Object完整路径。Object完整路径中不能包含Bucket名称。
                if(ossClient.doesObjectExist(ossConf.getBucketName(), newPath)){
                    newPath = path
                            + originalFilename.split("[.]")[0]
                            + "-"
                            + ZydDateUtils.format(ZydDateUtils.ymdhmsGapless, new Date())
                            + "."+suffix;
                }
                // 上传文件
                PutObjectResult result = ossClient.putObject(new PutObjectRequest(ossConf.getBucketName(), newPath, file));
                // 设置权限(公开读)
                ossClient.setBucketAcl(ossConf.getBucketName(), CannedAccessControlList.PublicRead);
                if (result == null) {
                    //上传失败，抛出提示
                    return new JsonResult(false,"上传失败");
                }
            }
        }catch (Exception e){
            log.error(e.getMessage(),e);
            return new JsonResult(false,"上传异常");
        }finally {
            IoUtil.close(os);
            ossClient.shutdown();
        }
        return new JsonResult<>(true,"");
    }

    /**
     * 下载文件
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    public JsonResult download(String path, HttpServletResponse response) {
        if(StringUtils.isBlank(path)){
            return new JsonResult(false,"请选择文件下载");
        }
        //初始化ossclient
        OSS ossClient = new OSSClientBuilder().build(ossConf.getEndpoint(), ossConf.getAccessKeyId(), ossConf.getAccessKeySecret());
        OSSObject ossObject = null;
        BufferedInputStream in = null;
        BufferedOutputStream out = null;
        try {
            ossObject = ossClient.getObject(ossConf.getBucketName(), getOssCorpCode() + path);
            in = new  BufferedInputStream(ossObject.getObjectContent());
            out = new BufferedOutputStream(response.getOutputStream());
            response.setContentType("application/x-msdownload");
            response.setHeader("Content-Disposition","attachment;filename="
                    + URLEncoder.encode(path.split("[/]")[path.split("[/]").length-1],"UTF-8"));
            byte[] car = new byte [1024];
            int L = 0;
            while ((L=in.read(car))!=-1){
                out.write(car,0,L);
            }
        }catch (Exception e){
            log.error(e.getMessage(),e);
        }finally {
            ossClient.shutdown();
            IoUtil.close(ossObject);
            IoUtil.close(in);
            try {
                out.flush();
            }catch (Exception ex){}
            IoUtil.close(out);
        }
        return new JsonResult(true,"");
    }

    /**
     * 组合租户的oss路径
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    public String getOssCorpCode() {
        String supplierCode = (String) ContextHandler.get("supplierId");
        String path = "purchase" + (StringUtils.isEmpty(supplierCode) ? "" : "_" + supplierCode) + ossConf.getCorpOssPrex();
        if (StringUtils.isNotBlank(ossConf.getDir())) {
            return ossConf.getDir() + "/" + path;
        }
        return path;
    }

    /**
     * 创建文件夹目录
     * @author zhangcheng
     * @Date: 2022-08-10
     * @since：OssMaterialService 0.0.1
     **/
    private void createDir(OSS ossClient, String prefix) {
        ObjectMetadata objectMeta = new ObjectMetadata();
        /*
         * 这里的size为0,注意OSS本身没有文件夹的概念,这里创建的文件夹本质上是一个size为0的Object,dataStream仍然可以有数据
         * 照样可以上传下载,只是控制台会对以"/"结尾的Object以文件夹的方式展示,用户可以利用这种方式来实现文件夹模拟功能,创建形式上的文件夹
         */
        byte[] buffer = new byte[0];
        ByteArrayInputStream in = new ByteArrayInputStream(buffer);
        objectMeta.setContentLength(0);
        ossClient.putObject(ossConf.getBucketName(), prefix, in, objectMeta);
        IoUtil.close(in);
    }
}
