package com.purchase.product.mapper;

import com.purchase.product.model.ElvoScmProductApplyAuditRecord;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/2/20 9:59
 **/
public interface ElvoScmProductApplyAuditRecordMapper extends QguBaseMapper<ElvoScmProductApplyAuditRecord> {

}
