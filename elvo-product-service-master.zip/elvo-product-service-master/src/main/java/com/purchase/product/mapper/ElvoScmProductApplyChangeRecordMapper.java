package com.purchase.product.mapper;

import com.purchase.product.model.ElvoScmProductApplyChangeRecord;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

/**
 * @Description:
 * @Author: loine
 * @Date: 2025/2/10 16:51
 **/
public interface ElvoScmProductApplyChangeRecordMapper extends QguBaseMapper<ElvoScmProductApplyChangeRecord> {

    /**
     * 根据申请编号查询变更记录
     *
     * @param applyNos
     * @Author: loine
     * @Date: 2025/2/12 16:37
     */
    List<ElvoScmProductApplyChangeRecord> getByApplyNos(@Param("applyNos") Set<Long> applyNos);
}
