package com.purchase.product.mapper;

import com.purchase.product.dto.ElvoScmProductApplyDto;
import com.purchase.product.model.ElvoScmProductApply;
import com.purchase.product.vo.ElvoScmProductApplyVo;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

/**
 * @Description:
 * @Author: loine
 * @Date: 2024/10/14 15:16
 **/
public interface ElvoScmProductApplyMapper extends QguBaseMapper<ElvoScmProductApply> {

    /**
     * 供应商-搜索
     *
     * @param dto
     * @param supplierId
     * @param corpCode
     * @Author: loine
     * @Date: 2024/10/14 17:11
     */
    List<ElvoScmProductApplyVo.SupplierSearchVo> supplierApplySearch(@Param("dto") ElvoScmProductApplyDto.SupplierSearchDto dto, @Param("supplierId") String supplierId, @Param("corpCode") String corpCode);

    /**
     * 供应商-搜索角标
     *
     * @param dto
     * @param supplierId
     * @param corpCode
     * @Author: loine
     * @Date: 2024/10/15 13:12
     */
    ElvoScmProductApplyVo.SearchCountVo supplierSearchCount(@Param("dto") ElvoScmProductApplyDto.SupplierSearchDto dto, @Param("supplierId") String supplierId, @Param("corpCode") String corpCode);

    /**
     * 获取商品池随机商品详情
     *
     * @param dto
     * @Author: loine
     * @Date: 2024/10/15 9:42
     */
    ElvoScmProductApplyVo.SupplierRandomDetailVo selectRandomCommonByCataBrandProp(@Param("dto") ElvoScmProductApplyDto.SupplierRandomDetailDto dto);

    /**
     * 校验是否已经申请过
     *
     * @param supplierId
     * @param productType
     * @Author: loine
     * @Date: 2024/10/16 11:02
     */
    int supplierCheckIsApply(@Param("supplierId") String supplierId, @Param("productType") String productType);

    /**
     * 供应商-我的商品搜索
     *
     * @param dto
     * @param supplierId
     * @param corpCode
     * @Author: loine
     * @Date: 2024/10/15 16:22
     */
    List<ElvoScmProductApplyVo.SupplierMySearchVo> supplierMySearch(@Param("dto") ElvoScmProductApplyDto.SupplierMySearchDto dto, @Param("supplierId") String supplierId, @Param("corpCode") String corpCode);

    /**
     * 供应商-我的商品搜索角标
     *
     * @param dto
     * @param supplierId
     * @param corpCode
     * @Author: loine
     * @Date: 2024/10/15 16:32
     */
    ElvoScmProductApplyVo.SupplierMySearchCountVo supplierMySearchCount(@Param("dto") ElvoScmProductApplyDto.SupplierMySearchDto dto, @Param("supplierId") String supplierId, @Param("corpCode") String corpCode);

    /**
     * 后台-搜索
     *
     * @param dto
     * @param corpCode
     * @param companyShortName
     * @Author: loine
     * @Date: 2024/10/14 17:11
     */
    List<ElvoScmProductApplyVo.AdminSearchVo> adminSearch(@Param("dto") ElvoScmProductApplyDto.AdminSearchDto dto, @Param("corpCode") String corpCode, @Param("companyShortName") String companyShortName);

    /**
     * 后台-搜索角标
     *
     * @param dto
     * @param corpCode
     * @param companyShortName
     * @Author: loine
     * @Date: 2024/10/15 15:13
     */
    ElvoScmProductApplyVo.SearchCountVo adminSearchCount(@Param("dto") ElvoScmProductApplyDto.AdminSearchDto dto, @Param("corpCode") String corpCode, @Param("companyShortName") String companyShortName);

    /**
     * 供应商-查询规格
     *
     * @param dto
     * @param supplierId
     * @param corpCode
     * @Author: loine
     * @Date: 2024/10/17 14:31
     */
    List<ElvoScmProductApplyVo.SpecVo> supplierSelectSpec(@Param("dto") ElvoScmProductApplyDto.SupplierSearchDto dto, @Param("supplierId") String supplierId, @Param("corpCode") String corpCode);

    /**
     * 供应商-我的商品查询规格
     *
     * @param dto
     * @param supplierId
     * @param corpCode
     * @Author: loine
     * @Date: 2024/10/17 14:31
     */
    List<ElvoScmProductApplyVo.SpecVo> supplierMySelectSpec(@Param("dto") ElvoScmProductApplyDto.SupplierMySearchDto dto, @Param("supplierId") String supplierId, @Param("corpCode") String corpCode);

    /**
     * 后台-查询规格
     *
     * @param searchDto
     * @param corpCode
     * @param companyShortName
     * @Author: loine
     * @Date: 2024/11/11 13:05
     */
    List<ElvoScmProductApplyVo.SpecVo> adminSelectSpec(@Param("dto") ElvoScmProductApplyDto.AdminSearchDto searchDto, @Param("corpCode") String corpCode, @Param("companyShortName") String companyShortName);

    /**
     * 获取最大的申请编码
     *
     * @Author: loine
     * @Date: 2024/10/17 15:34
     */
    Long getMaxApplyNo();

    /**
     * 更新上下架状态
     *
     * @param detail
     * @Author: loine
     * @Date: 2024/10/24 9:44
     */
    void updateOnsale(@Param("o") ElvoScmProductApply detail);

    /**
     * 获取公司信息
     *
     * @param companyIds
     * @Author: loine
     * @Date: 2024/10/30 16:20
     */
    List<ElvoScmProductApplyVo.CompanyVo> getCompany(@Param("companyIds") Set<Integer> companyIds);

    /**
     * 获取供应商信息
     *
     * @Author: loine
     * @Date: 2024/11/13 13:06
     */
    ElvoScmProductApplyVo.SupplierVo getSupplierInfo(@Param("supplierId") String supplierId);

    /**
     * 获取公海分类名称
     *
     * @param cataId
     * @Author: loine
     * @Date: 2024/11/25 14:58
     */
    String getCommonCataName(@Param("cataId") Long cataId);

    /**
     * 获取公海品牌名称
     *
     * @param brandId
     * @Author: loine
     * @Date: 2024/11/25 14:58
     */
    String getCommonBrandName(@Param("brandId") Long brandId);

    /**
     * 获取公海系列名称
     *
     * @param propId
     * @Author: loine
     * @Date: 2024/11/25 14:58
     */
    String getCommonPropName(@Param("propId") Long propId);

    /**
     * 获取公海规格
     *
     * @param firstLevelCataName
     * @param secondLevelCataName
     * @param threeLevelCataName
     * @Author: loine
     * @Date: 2024/12/2 16:30
     */
    List<ElvoScmProductApplyVo.CommonSpecVo> getCommonSpec(@Param("firstLevelCataName") String firstLevelCataName, @Param("secondLevelCataName") String secondLevelCataName, @Param("threeLevelCataName") String threeLevelCataName);

    /**
     * 获取公海规格值
     *
     * @param specId
     * @Author: loine
     * @Date: 2024/12/2 16:36
     */
    List<String> getCommonSpecValue(@Param("specId") Long specId);

    /**
     * 校验公海系列名称是否存在
     *
     * @param propNames
     * @Author: loine
     * @Date: 2024/11/25 14:58
     */
    Set<String> checkIsExistCommonPropName(@Param("propNames") Set<String> propNames);

    /**
     * 获取分类是否展示系列
     *
     * @param firstLevelCataName
     * @param secondLevelCataName
     * @param threeLevelCataName
     * @Author: loine
     * @Date: 2025/4/15 16:36
     */
    String getCommonCataIsShowProp(@Param("firstLevelCataName") String firstLevelCataName, @Param("secondLevelCataName") String secondLevelCataName, @Param("threeLevelCataName") String threeLevelCataName);

    /**
     * 相同供应商+相同品牌维度下，获取当前待审核数量
     *
     * @param supplierId
     * @param brandName
     * @Author loine
     * @Date 2025/12/24 17:31
     */
    Integer getSupplierBrandAuditNum(@Param("supplierId") String supplierId, @Param("brandName") String brandName);

    /**
     * 根据品牌名称获取品牌中文名称
     *
     * @param brandNames
     * @Author loine
     * @Date 2026/1/5 14:54
     */
    List<ElvoScmProductApplyVo.BrandNameCnVo> getBrandCn(@Param("brandNames") Set<String> brandNames);
}
