package com.purchase.product.model;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.*;

/**
 * @Description:
 * @Author: loine
 * @Date: 2024/10/14 15:16
 **/
@Data
@ApiModel("供应商_ELVO_SCM产品申请表")
@Table(name = "t_pd_elvo_scm_product_apply")
public class ElvoScmProductApply extends BaseCorpModel {

    public static final String ID = "id";
    public static final String APPLY_NO = "applyNo";
    public static final String FIRST_LEVEL_CATA_NAME = "firstLevelCataName";
    public static final String SECOND_LEVEL_CATA_NAME = "secondLevelCataName";
    public static final String THREE_LEVEL_CATA_NAME = "threeLevelCataName";
    public static final String BRAND_NAME = "brandName";
    public static final String PROP_NAME = "propName";
    public static final String MATERIAL_NAME = "materialName";
    public static final String PRODUCT_TYPE = "productType";
    public static final String SKU_CODE = "skuCode";
    public static final String PRODUCT_CODE = "productCode";
    public static final String SUPPLY_PRICE = "supplyPrice";
    public static final String PRICE = "price";
    public static final String SUGGEST_PRICE = "suggestPrice";
    public static final String DISTRIBUTE_PRICE = "distributePrice";
    public static final String STOCK = "stock";
    public static final String DELIVERY_DATE = "deliveryDate";
    public static final String UNIT = "unit";
    public static final String WEIGHT = "weight";
    public static final String IS_ONSALE = "isOnsale";
    public static final String OFFSALE_TYPE = "offsaleType";
    public static final String IS_SUPPLY = "isSupply";
    public static final String SUPPLIER_ID = "supplierId";
    public static final String COMPANY_ID = "companyId";
    public static final String AUDIT_TYPE = "auditType";
    public static final String AUDIT_STATUS = "auditStatus";
    public static final String AUDIT_REMARK = "auditRemark";
    public static final String PUBLIC_PRODUCT_ID = "publicProductId";
    public static final String PRODUCT_ERP_CODE = "productErpCode";

    @ApiModelProperty("申请编号")
    private Long applyNo;
    @ApiModelProperty("一级分类名称")
    private String firstLevelCataName;
    @ApiModelProperty("二级分类名称")
    private String secondLevelCataName;
    @ApiModelProperty("三级分类名称")
    private String threeLevelCataName;
    @ApiModelProperty("品牌名称")
    private String brandName;
    @ApiModelProperty("系列名称")
    private String propName;
    @ApiModelProperty("商品物料名称")
    private String materialName;
    @ApiModelProperty("规格json数据")
    private String specData;
    @ApiModelProperty("产品型号")
    private String productType;
    @ApiModelProperty("订货号")
    private String skuCode;
    @ApiModelProperty("商品编号")
    private String productCode;
    @ApiModelProperty("供货价折扣")
    private BigDecimal supplyDiscount;
    @ApiModelProperty("供货价")
    private BigDecimal supplyPrice;
    @ApiModelProperty("面价")
    private BigDecimal price;
    @ApiModelProperty("建议销售价折扣")
    private BigDecimal suggestDiscount;
    @ApiModelProperty("建议销售价")
    private BigDecimal suggestPrice;
    @ApiModelProperty("调货价")
    private BigDecimal distributePrice;
    @ApiModelProperty("调货价折扣")
    private BigDecimal distributeDiscount;
    @ApiModelProperty("调货价折扣 计算方式（乘：*、除：/）")
    private String distributeCalcWay;
    @ApiModelProperty("库存（1=现货，0=订货）")
    private Integer stock;
    @ApiModelProperty("货期")
    private String deliveryDate;
    @ApiModelProperty("计量单位")
    private String unit;
    @ApiModelProperty("重量")
    private String weight;
    @ApiModelProperty("最小起订量")
    private Integer minimunRequire;
    @ApiModelProperty("商品图片（多个用@分隔）")
    private String productPicName;
    @ApiModelProperty("视频详情（多个用@分隔）")
    private String productVideoName;
    @ApiModelProperty("样本详情（多个用@分隔）")
    private String productSampleName;
    @ApiModelProperty("商品申请来源 来源：ELVO_PRODUCT_APPLY")
    private String applySource;
    @ApiModelProperty("是否上下架（Y=上架，N=下架）")
    private String isOnsale;
    @ApiModelProperty("下架类型（1=系统下架，2=自主下架）")
    private Integer offsaleType;
    @ApiModelProperty("下架原因")
    private String offsaleReason;
    @ApiModelProperty("产品详情图名称（多个用@分隔）")
    private String productContentPicName;
    @ApiModelProperty("编辑字段")
    private String editColumns;
    @ApiModelProperty("编辑规格")
    private String editSpecs;
    @ApiModelProperty("审核类型（1=商品新增，2=资料修改，3=价格修改，4=资料价格修改，5=图片修改）")
    private Integer auditType;
    @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回）")
    private Integer auditStatus;
    @ApiModelProperty("审核备注")
    private String auditRemark;
    @ApiModelProperty("待分部审核时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime1;
    @ApiModelProperty("待资料审核时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime2;
    @ApiModelProperty("待价格审核时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime3;
    @ApiModelProperty("公海产品id")
    private Long publicProductId;
    @ApiModelProperty("供应商id")
    private String supplierId;
    @ApiModelProperty("公司id")
    private Integer companyId;
    @ApiModelProperty("erp商品编号")
    private String productErpCode;
    @ApiModelProperty("是否是供应链（Y：是，N：否）")
    private String isSupply;
    @ApiModelProperty("取消时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime cancelTime;

    @Transient
    private List<ElvoScmProductApplyChangeRecord> changeRecords;

    /**
     * 字段代码映射列名
     */
    public static final Map<String, String> EDIT_COLUMN_MAP = new HashMap<>();
    static {
        EDIT_COLUMN_MAP.put("first_level_cata_name", "一级分类名称");
        EDIT_COLUMN_MAP.put("second_level_cata_name", "二级分类名称");
        EDIT_COLUMN_MAP.put("three_level_cata_name", "三级分类名称");
        EDIT_COLUMN_MAP.put("brand_name", "品牌名称");
        EDIT_COLUMN_MAP.put("prop_name", "系列名称");
        EDIT_COLUMN_MAP.put("material_name", "产品名称");
        EDIT_COLUMN_MAP.put("product_type", "产品型号");
        EDIT_COLUMN_MAP.put("sku_code", "订货号");
        EDIT_COLUMN_MAP.put("product_code", "商品编码");
        EDIT_COLUMN_MAP.put("supply_price", "供货价");
        EDIT_COLUMN_MAP.put("distribute_price", "调货价");
        EDIT_COLUMN_MAP.put("price", "面价");
        EDIT_COLUMN_MAP.put("suggest_price", "建议销售价");
        EDIT_COLUMN_MAP.put("stock", "库存");
        EDIT_COLUMN_MAP.put("delivery_date", "货期");
        EDIT_COLUMN_MAP.put("unit", "单位");
        EDIT_COLUMN_MAP.put("weight", "重量");
        EDIT_COLUMN_MAP.put("minimun_require", "最小起订量");
        EDIT_COLUMN_MAP.put("product_pic_name", "商品主图");
        EDIT_COLUMN_MAP.put("product_video_name", "视频详情");
        EDIT_COLUMN_MAP.put("product_sample_name", "样本详情");
        EDIT_COLUMN_MAP.put("product_content_pic_name", "产品详情图");
        EDIT_COLUMN_MAP.put("spec_data", "规格值");
    }

    /**
     * 自定义比较，返回不同项
     *
     * @param applyNew
     * @param isReadLastUpdate 是否读取上次修改的列
     * @Author loine
     * @Date 2024/10/18 10:19
     */
    public Map<String, Object> ownCompare(ElvoScmProductApply applyNew, boolean isReadLastUpdate) {
        Map<String, Object> result = new HashMap<>();
        Set<String> notEquals = new HashSet<>();
        Set<String> editSpec = new HashSet<>();
        List<ElvoScmProductApplyChangeRecord> changeRecords = new ArrayList<>();
        int editInfo = 0;
        int editPrice = 0;
        int editImage = 0;
        boolean isNewEdit = false;// 本次是否有修改
        if (applyNew != null) {
            if (!equals(firstLevelCataName, applyNew.getFirstLevelCataName())) {
                notEquals.add("first_level_cata_name");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("first_level_cata_name", null, firstLevelCataName, applyNew.getFirstLevelCataName()));
            }
            if (!equals(secondLevelCataName, applyNew.getSecondLevelCataName())) {
                notEquals.add("second_level_cata_name");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("second_level_cata_name", null, secondLevelCataName, applyNew.getSecondLevelCataName()));
            }
            if (!equals(threeLevelCataName, applyNew.getThreeLevelCataName())) {
                notEquals.add("three_level_cata_name");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("three_level_cata_name", null, threeLevelCataName, applyNew.getThreeLevelCataName()));
            }
            if (!equals(brandName, applyNew.getBrandName())) {
                notEquals.add("brand_name");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("brand_name", null, brandName, applyNew.getBrandName()));
            }
            if (!equals(propName, applyNew.getPropName())) {
                notEquals.add("prop_name");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("prop_name", null, propName, applyNew.getPropName()));
            }
            if (!equals(materialName, applyNew.getMaterialName())) {
                notEquals.add("material_name");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("material_name", null, materialName, applyNew.getMaterialName()));
            }
            if (!equals(productType, applyNew.getProductType())) {
                notEquals.add("product_type");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("product_type", null, productType, applyNew.getProductType()));
            }
            if (!equals(skuCode, applyNew.getSkuCode())) {
                notEquals.add("sku_code");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("sku_code", null, skuCode, applyNew.getSkuCode()));
            }
            if (!equals(productCode, applyNew.getProductCode())) {
                notEquals.add("product_code");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("product_code", null, productCode, applyNew.getProductCode()));
            }
            if (!equalsDecimal(supplyPrice, applyNew.getSupplyPrice())) {
                notEquals.add("supply_price");
                editPrice++;
                isNewEdit = true;
                String oldValue = "";
                String newValue = "";
                if (supplyPrice != null) {
                    oldValue = supplyPrice.setScale(2, RoundingMode.HALF_DOWN).toString();
                }
                if (applyNew.getSupplyPrice() != null) {
                    newValue = applyNew.getSupplyPrice().setScale(2, RoundingMode.HALF_DOWN).toString();
                }
                changeRecords.add(getChangeRecord("supply_price", null, oldValue, newValue));
            }
            if (!equalsDecimal(price, applyNew.getPrice())) {
                notEquals.add("price");
                editPrice++;
                isNewEdit = true;
                String oldValue = "";
                String newValue = "";
                if (price != null) {
                    oldValue = price.setScale(2, RoundingMode.HALF_DOWN).toString();
                }
                if (applyNew.getPrice() != null) {
                    newValue = applyNew.getPrice().setScale(2, RoundingMode.HALF_DOWN).toString();
                }
                changeRecords.add(getChangeRecord("price", null, oldValue, newValue));
            }
            if (!equalsDecimal(suggestPrice, applyNew.getSuggestPrice())) {
                notEquals.add("suggest_price");
                editPrice++;
                isNewEdit = true;
                String oldValue = "";
                String newValue = "";
                if (suggestPrice != null) {
                    oldValue = suggestPrice.setScale(2, RoundingMode.HALF_DOWN).toString();
                }
                if (applyNew.getSuggestPrice() != null) {
                    newValue = applyNew.getSuggestPrice().setScale(2, RoundingMode.HALF_DOWN).toString();
                }
                changeRecords.add(getChangeRecord("suggest_price", null, oldValue, newValue));
            }
            if (!Objects.equals(stock, applyNew.getStock())) {
                notEquals.add("stock");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("stock", null, stock, applyNew.getStock()));
            }
            if (!equals(deliveryDate, applyNew.getDeliveryDate())) {
                notEquals.add("delivery_date");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("delivery_date", null, deliveryDate, applyNew.getDeliveryDate()));
            }
            if (!equals(unit, applyNew.getUnit())) {
                notEquals.add("unit");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("unit", null, unit, applyNew.getUnit()));
            }
            if (!equals(weight, applyNew.getWeight())) {
                notEquals.add("weight");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("weight", null, weight, applyNew.getWeight()));
            }
            if (!Objects.equals(minimunRequire, applyNew.getMinimunRequire())) {
                notEquals.add("minimun_require");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("minimun_require", null, minimunRequire, applyNew.getMinimunRequire()));
            }
            if (!equals(productPicName, applyNew.getProductPicName())) {
                notEquals.add("product_pic_name");
                editImage++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("product_pic_name", null, productPicName, applyNew.getProductPicName()));
            }
            if (!equals(productVideoName, applyNew.getProductVideoName())) {
                notEquals.add("product_video_name");
                editImage++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("product_video_name", null, productVideoName, applyNew.getProductVideoName()));
            }
            if (!equals(productSampleName, applyNew.getProductSampleName())) {
                notEquals.add("product_sample_name");
                editInfo++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("product_sample_name", null, productSampleName, applyNew.getProductSampleName()));
            }
            if (!equals(productContentPicName, applyNew.getProductContentPicName())) {
                notEquals.add("product_content_pic_name");
                editImage++;
                isNewEdit = true;
                changeRecords.add(getChangeRecord("product_content_pic_name", null, productContentPicName, applyNew.getProductContentPicName()));
            }
            if (!equals(specData, applyNew.getSpecData())) {
                boolean flag = false;
                JSONArray oldArray = JSONArray.parseArray(specData);
                JSONArray newArray = JSONArray.parseArray(applyNew.getSpecData());
                if (oldArray == null && newArray != null) {
                    if (newArray.size() != 0) {
                        flag = true;
                        for (Object newA : newArray) {
                            JSONObject newO = (JSONObject) newA;
                            editSpec.add(newO.getString("specName"));
                            changeRecords.add(getChangeRecord("spec_data", "规格值（" + newO.getString("specName") + "）", null, newO.getString("specValue")));
                        }
                    }
                } else if (oldArray != null && newArray == null) {
                    if (oldArray.size() != 0) {
                        flag = true;
                        for (Object oldA : oldArray) {
                            JSONObject oldO = (JSONObject) oldA;
                            editSpec.add(oldO.getString("specName"));
                            changeRecords.add(getChangeRecord("spec_data", "规格值（" + oldO.getString("specName") + "）", oldO.getString("specValue"), null));
                        }
                    }
                } else {
                    if (oldArray != null && oldArray.size() != newArray.size()) {
                        flag = true;
                    }
                    if (oldArray != null) {
                        Map<String, String> oldMap = new HashMap<>();
                        Map<String, String> newMap = new HashMap<>();
                        for (Object oldA : oldArray) {
                            JSONObject oldO = (JSONObject) oldA;
                            String specName = oldO.getString("specName");
                            String specValue = oldO.getString("specValue");
                            oldMap.put(specName, specValue);
                        }
                        for (Object newA : newArray) {
                            JSONObject newO = (JSONObject) newA;
                            String specName = newO.getString("specName");
                            String specValue = newO.getString("specValue");
                            newMap.put(specName, specValue);
                        }
                        for (String newSpecName : newMap.keySet()) {
                            String oldSpecValue = oldMap.get(newSpecName);
                            String newSpecValue = newMap.get(newSpecName);
                            if (StringUtils.isBlank(oldSpecValue)) {
                                flag = true;
                                editSpec.add(newSpecName);
                                changeRecords.add(getChangeRecord("spec_data", "规格值（" + newSpecName + "）", oldSpecValue, newSpecValue));
                            } else if (!oldSpecValue.equalsIgnoreCase(newSpecValue)) {
                                flag = true;
                                editSpec.add(newSpecName);
                                changeRecords.add(getChangeRecord("spec_data", "规格值（" + newSpecName + "）", oldSpecValue, newSpecValue));
                            }
                        }
//                        for (Object oldA : oldArray) {
//                            JSONObject oldO = (JSONObject) oldA;
//                            String spec = oldO.getString("specName");
//                            String specValue = oldO.getString("specValue");
//                            boolean temp = false;
//                            for (Object newA : newArray) {
//                                JSONObject newO = (JSONObject) newA;
//                                if (spec.equals(newO.getString("specName")) && specValue.equals(newO.getString("specValue"))) {
//                                    temp = true;
//                                }
//                            }
//                            if (!temp) {
//                                flag = true;
//                            }
//                        }
                    }
                }
                if (flag) {
                    notEquals.add("spec_data");
                    editInfo++;
                    isNewEdit = true;
                }
            }
            // 读取上次修改的列
            if (isReadLastUpdate && StringUtils.isNotBlank(this.getEditColumns())) {
                List<String> editColumns = Arrays.asList(this.getEditColumns().split(","));
                if (editColumns.contains("first_level_cata_name") || editColumns.contains("second_level_cata_name") || editColumns.contains("three_level_cata_name") || editColumns.contains("brand_name") || editColumns.contains("prop_name") || editColumns.contains("material_name") || editColumns.contains("product_type") || editColumns.contains("sku_code") || editColumns.contains("product_code") || editColumns.contains("stock") || editColumns.contains("delivery_date") || editColumns.contains("unit") || editColumns.contains("weight") || editColumns.contains("minimun_require") || editColumns.contains("spec_data")) {
                    editInfo++;
                }
                if (editColumns.contains("supply_price") || editColumns.contains("price") || editColumns.contains("suggest_price")) {
                    editPrice++;
                }
                if (editColumns.contains("product_pic_name") || editColumns.contains("product_video_name") || editColumns.contains("product_content_pic_name")) {
                    editImage++;
                }
                notEquals.addAll(editColumns);
            }
            // 判断审核类型
            if (editInfo > 0 && editPrice == 0) {
                result.put("auditType", "2");
            } else if (editInfo == 0 && editPrice > 0 && editImage == 0) {
                result.put("auditType", "3");
            } else if ((editInfo > 0 && editPrice > 0) || (editPrice > 0 && editImage > 0)) {
                result.put("auditType", "4");
            } else if (editInfo == 0 && editPrice == 0 && editImage > 0) {
                result.put("auditType", "5");
            } else {
                result.put("auditType", this.getAuditType());
            }
            result.put("isNewEdit", isNewEdit);
        }
        result.put("notEquals", notEquals);
        result.put("editSpec", editSpec);
        result.put("changeRecords", changeRecords);
        return result;
    }

    /**
     * 比较两个字符串是否相等
     *
     * @param oldString
     * @param newString
     * @Author: loine
     * @Date: 2024/11/4 17:18
     */
    private static boolean equals(String oldString, String newString) {
        if (StringUtils.isBlank(oldString) && StringUtils.isBlank(newString)) {
            return true;
        }
        if (StringUtils.isBlank(oldString)) {
            oldString = "";
        }
        if (StringUtils.isBlank(newString)) {
            newString = "";
        }
        return oldString.equals(newString);
    }

    /**
     * 比较两个金额是否相等
     *
     * @param oldDecimal
     * @param newDecimal
     * @Author loine
     * @Date 2025/8/20 14:27
     */
    private static boolean equalsDecimal(BigDecimal oldDecimal, BigDecimal newDecimal) {
        if (oldDecimal == null && newDecimal == null) {
            return true;
        } else if (oldDecimal == null || newDecimal == null) {
            return false;
        } else {
            return oldDecimal.compareTo(newDecimal) == 0;
        }
    }

    /**
     * 获取比较的json对象
     *
     * @param field
     * @param fieldCn
     * @param oldValue
     * @param newValue
     * @Author: loine
     * @Date: 2025/2/10 16:08
     */
    private ElvoScmProductApplyChangeRecord getChangeRecord(String field, String fieldCn, Object oldValue, Object newValue) {
        ElvoScmProductApplyChangeRecord changeRecord = new ElvoScmProductApplyChangeRecord();
        changeRecord.setFieldCode(field);
        if (fieldCn != null) {
            changeRecord.setFieldName(fieldCn);
        } else {
            changeRecord.setFieldName(EDIT_COLUMN_MAP.get(field));
        }
        if (oldValue != null) {
            changeRecord.setOldValue(oldValue.toString());
        }
        if (newValue != null) {
            changeRecord.setNewValue(newValue.toString());
        }
        String corpCode = ContextHandler.getCorpCode();
        if (StringUtils.isBlank(corpCode)) {
            corpCode = "default";
        }
        changeRecord.setCorpCode(corpCode);
        return changeRecord;
    }
}

