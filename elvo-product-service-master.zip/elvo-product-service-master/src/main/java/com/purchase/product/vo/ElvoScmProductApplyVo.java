package com.purchase.product.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.purchase.utils.excel.export.ExcelField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@ApiModel("ELVO_SCM产品申请-出参")
public class ElvoScmProductApplyVo {

    @Data
    @ApiModel("规格-出参")
    public static class SpecVo {
        @ApiModelProperty("规格名称")
        private String specName;
        @ApiModelProperty("规格值")
        private String specValue;
    }

    @Data
    @ApiModel("供应商-搜索-出参")
    public static class SupplierSearchVo {
        @ApiModelProperty("主键id")
        private String id;
        @ApiModelProperty("申请编号")
        private Long applyNo;
        @ApiModelProperty("商品物料名称")
        private String materialName;
        @ApiModelProperty("规格json数据")
        private String specData;
        @ApiModelProperty("规格名")
        private String specName;
        @ApiModelProperty("规格值")
        private String specValue;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号/物料号")
        private String skuCode;
        @ApiModelProperty("商品编号")
        private String productCode;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("商品系列名称")
        private String propName;
        @ApiModelProperty("面价")
        private String price;
        @ApiModelProperty("供货价折扣")
        private BigDecimal supplyDiscount;
        @ApiModelProperty("供货价")
        private String supplyPrice;
        @ApiModelProperty("建议销售价折扣")
        private BigDecimal suggestDiscount;
        @ApiModelProperty("建议销售价")
        private String suggestPrice;
        @ApiModelProperty("库存（1=现货，0=订货）")
        private Integer stock;
        @ApiModelProperty("货期")
        private String deliveryDate;
        @ApiModelProperty("计量单位")
        private String unit;
        @ApiModelProperty("重量")
        private String weight;
        @ApiModelProperty("最小起订量")
        private Integer minimunRequire;
        @ApiModelProperty("商品图片（多个用@分隔）")
        private String productPicName;
        @ApiModelProperty("视频详情（多个用@分隔）")
        private String productVideoName;
        @ApiModelProperty("样本详情（多个用@分隔）")
        private String productSampleName;
        @ApiModelProperty("产品详情图名称（多个用@分隔）")
        private String productContentPicName;
        @ApiModelProperty("审核类型（1=商品新增，2=资料修改，3=价格修改，4=资料价格修改，5=图片修改）")
        private Integer auditType;
        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回）")
        private Integer auditStatus;
        @ApiModelProperty("审核备注")
        private String auditRemark;
        @ApiModelProperty("申请时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime createdAt;
        @ApiModelProperty("修改时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime updatedAt;
        @ApiModelProperty("待分部审核时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime auditTime1;
        @ApiModelProperty("待资料审核时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime auditTime2;
        @ApiModelProperty("待价格审核时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime auditTime3;
        @ApiModelProperty("审核时间（合）")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime auditTimeMerge;
    }

    @Data
    @ApiModel("搜索角标-出参")
    public static class SearchCountVo {
        @ApiModelProperty("待提交数量")
        private int auditStatus0;
        @ApiModelProperty("待分部审核数量")
        private int auditStatus1;
        @ApiModelProperty("待资料审核数量")
        private int auditStatus2;
        @ApiModelProperty("待价格审核数量")
        private int auditStatus3;
        @ApiModelProperty("通过数量")
        private int auditStatus4;
        @ApiModelProperty("驳回数量")
        private int auditStatus5;
    }

    @Data
    @ApiModel("供应商-详情-出参")
    public static class SupplierDetailVo {
        @ApiModelProperty("主键id")
        private String id;
        @ApiModelProperty("申请编号")
        private Long applyNo;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("系列名称")
        private String propName;
        @ApiModelProperty("商品物料名称")
        private String materialName;
        @ApiModelProperty("规格json数据")
        private String specData;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号")
        private String skuCode;
        @ApiModelProperty("商品编号")
        private String productCode;
        @ApiModelProperty("供货价折扣")
        private BigDecimal supplyDiscount;
        @ApiModelProperty("供货价")
        private String supplyPrice;
        @ApiModelProperty("面价")
        private String price;
        @ApiModelProperty("建议销售价折扣")
        private BigDecimal suggestDiscount;
        @ApiModelProperty("建议销售价")
        private String suggestPrice;
        @ApiModelProperty("调货价")
        private String distributePrice;
        @ApiModelProperty("库存（1=现货，0=订货）")
        private Integer stock;
        @ApiModelProperty("货期")
        private String deliveryDate;
        @ApiModelProperty("单位")
        private String unit;
        @ApiModelProperty("重量")
        private String weight;
        @ApiModelProperty("最小起订量")
        private Integer minimunRequire;
        @ApiModelProperty("商品图片（多个用@分隔）")
        private String productPicName;
        @ApiModelProperty("视频详情（多个用@分隔）")
        private String productVideoName;
        @ApiModelProperty("样本详情（多个用@分隔）")
        private String productSampleName;
        @ApiModelProperty("商品申请来源 来源： inquiry | publish")
        private String applySource;
        @ApiModelProperty("是否上下架（Y=上架，N=下架）")
        private String isOnsale;
        @ApiModelProperty("产品详情图名称（多个用@分隔）")
        private String productContentPicName;
        @ApiModelProperty("编辑字段")
        private String editColumns;
        @ApiModelProperty("审核类型（1=商品新增，2=资料修改，3=价格修改，4=资料价格修改，5=图片修改）")
        private Integer auditType;
        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回）")
        private Integer auditStatus;
        @ApiModelProperty("审核备注")
        private String auditRemark;
        @ApiModelProperty("供应商id")
        private String supplierId;
        @ApiModelProperty("资源文件地址前缀")
        private String urlPrefix;
        @ApiModelProperty("所属子公司")
        private String companyShortName;
        @ApiModelProperty("分类是否展示系列")
        private String cataIsShowProp;
    }

    @Data
    @ApiModel("供应商-随机商品详情-出参")
    public static class SupplierRandomDetailVo {
        @ApiModelProperty("产品id")
        private Long productId;
        @ApiModelProperty("商品物料名称")
        private String materialName;
        //        @ApiModelProperty("规格json数据")
//        private String specData;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号")
        private String skuCode;
        @ApiModelProperty("商品编号")
        private String productCode;
        @ApiModelProperty("供货价折扣")
        private BigDecimal supplyDiscount;
        @ApiModelProperty("供货价")
        private String supplyPrice;
        @ApiModelProperty("面价")
        private String price;
        @ApiModelProperty("建议销售价折扣")
        private BigDecimal suggestDiscount;
        @ApiModelProperty("建议销售价")
        private String suggestPrice;
        @ApiModelProperty("库存（1=现货，0=订货）")
        private Integer stock;
        @ApiModelProperty("货期")
        private String deliveryDate;
        @ApiModelProperty("重量")
        private String weight;
        @ApiModelProperty("商品图片（多个用@分隔）")
        private String productPicName;
        @ApiModelProperty("视频详情（多个用@分隔）")
        private String productVideoName;
        @ApiModelProperty("样本详情（多个用@分隔）")
        private String productSampleName;
        @ApiModelProperty("资源文件地址前缀")
        private String urlPrefix;
    }

    @Data
    @ApiModel("供应商-相同型号搜索-出参")
    public static class SupplierSameSearchVo {
        @ApiModelProperty("主键id")
        private String id;
        @ApiModelProperty("申请编号")
        private Long applyNo;
        @ApiModelProperty("产品id")
        private Long productId;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("系列名称")
        private String propName;
        @ApiModelProperty("商品物料名称")
        private String materialName;
        @ApiModelProperty("规格json数据")
        private String specData;
        @ApiModelProperty("规格值字符串")
        private String specValueString;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号")
        private String skuCode;
        @ApiModelProperty("商品编号")
        private String productCode;
        @ApiModelProperty("供货价折扣")
        private BigDecimal supplyDiscount;
        @ApiModelProperty("供货价")
        private String supplyPrice;
        @ApiModelProperty("面价")
        private String price;
        @ApiModelProperty("建议销售价折扣")
        private BigDecimal suggestDiscount;
        @ApiModelProperty("建议销售价")
        private String suggestPrice;
        @ApiModelProperty("调货价")
        private String distributePrice;
        @ApiModelProperty("库存（1=现货，0=订货）")
        private Integer stock;
        @ApiModelProperty("货期")
        private String deliveryDate;
        @ApiModelProperty("计量单位")
        private String unit;
        @ApiModelProperty("重量")
        private String weight;
        @ApiModelProperty("最小起订量")
        private Integer minimunRequire;
        @ApiModelProperty("商品图片（多个用@分隔）")
        private String productPicName;
        @ApiModelProperty("视频详情（多个用@分隔）")
        private String productVideoName;
        @ApiModelProperty("样本详情（多个用@分隔）")
        private String productSampleName;
        @ApiModelProperty("是否上下架（Y=上架，N=下架）")
        private String isOnsale;
        @ApiModelProperty("产品详情图名称（多个用@分隔）")
        private String productContentPicName;
        @ApiModelProperty("审核类型（1=商品新增，2=资料修改，3=价格修改，4=资料价格修改，5=图片修改）")
        private Integer auditType;
        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回）")
        private Integer auditStatus;
        @ApiModelProperty("审核备注")
        private String auditRemark;
        @ApiModelProperty("公海产品id")
        private Long publicProductId;
    }

    @Data
    @ApiModel("供应商-相同型号搜索选择器-出参")
    public static class SupplierSameSelectorVo {
        @ApiModelProperty("规格列表")
        private List<SupplierSameSelectorListVo> specs;
    }

    @Data
    @ApiModel("供应商-相同型号搜索选择器-列表-出参")
    public static class SupplierSameSelectorListVo {
        @ApiModelProperty("规格名称")
        private String specName;
        @ApiModelProperty("规格值列表")
        private List<SupplierSameSelectorSpecValueVo> specValues;
    }

    @Data
    @ApiModel("供应商-相同型号搜索选择器-规格值列表-入参")
    public static class SupplierSameSelectorSpecValueVo {
        @ApiModelProperty("规格值")
        private String specValue;
        @ApiModelProperty("是否选中")
        private boolean selected;
    }

    @Data
    @ApiModel("供应商-选择货期-出参")
    public static class SupplierSelectDeliveryVo {
        @ApiModelProperty("货期列表")
        private List<String> deliveryDates;
    }

    @Data
    @ApiModel("供应商-导出-出参")
    public static class SupplierExportVo {
        @ApiModelProperty("申请编号")
        private Long applyNo;
        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回）")
        private String auditStatus;
        @ApiModelProperty("审核类型（1=商品新增，2=资料修改，3=价格修改，4=资料价格修改，5=图片修改）")
        private String auditType;
        @ApiModelProperty("商品物料名称")
        private String materialName;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号/物料号")
        private String skuCode;
        @ApiModelProperty("商品编号")
        private String productCode;
        @ApiModelProperty("库存（1=现货，0=订货）")
        private String stock;
        @ApiModelProperty("货期")
        private String deliveryDate;
        @ApiModelProperty("计量单位")
        private String unit;
        @ApiModelProperty("重量")
        private String weight;
        @ApiModelProperty("最小起订量")
        private Integer minimunRequire;
        @ApiModelProperty("面价")
        private String price;
        @ApiModelProperty("供货价")
        private String supplyPrice;
        @ApiModelProperty("建议销售价")
        private String suggestPrice;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("商品系列名称")
        private String propName;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("规格json数据")
        private String specData;
        @ApiModelProperty("规格名")
        private String specName;
        @ApiModelProperty("规格值")
        private String specValue;
        @ApiModelProperty("商品图片（多个用@分隔）")
        private String productPicName;
        @ApiModelProperty("视频详情（多个用@分隔）")
        private String productVideoName;
        @ApiModelProperty("样本详情（多个用@分隔）")
        private String productSampleName;
        @ApiModelProperty("产品详情图名称（多个用@分隔）")
        private String productContentPicName;
        @ApiModelProperty("申请时间")
        private String createdAt;
        @ApiModelProperty("修改时间")
        private String updatedAt;
        @ApiModelProperty("审核时间（合）")
        private String auditTimeMerge;
    }

    @Data
    @ApiModel("供应商-我的商品搜索-出参")
    public static class SupplierMySearchVo {
        @ApiModelProperty("主键id")
        private String id;
        @ApiModelProperty("产品id")
        private Long productId;
        @ApiModelProperty("商品物料名称")
        private String materialName;
        @ApiModelProperty("规格json数据")
        private String specData;
        @ApiModelProperty("规格名")
        private String specName;
        @ApiModelProperty("规格值")
        private String specValue;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号/物料号")
        private String skuCode;
        @ApiModelProperty("商品编号")
        private String productCode;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("商品系列名称")
        private String propName;
        @ApiModelProperty("面价")
        private String price;
        @ApiModelProperty("供货价折扣")
        private BigDecimal supplyDiscount;
        @ApiModelProperty("供货价")
        private String supplyPrice;
        @ApiModelProperty("建议销售价折扣")
        private BigDecimal suggestDiscount;
        @ApiModelProperty("建议销售价")
        private String suggestPrice;
        @ApiModelProperty("库存（1=现货，0=订货）")
        private Integer stock;
        @ApiModelProperty("货期")
        private String deliveryDate;
        @ApiModelProperty("计量单位")
        private String unit;
        @ApiModelProperty("重量")
        private String weight;
        @ApiModelProperty("最小起订量")
        private Integer minimunRequire;
        @ApiModelProperty("商品图片（多个用@分隔）")
        private String productPicName;
        @ApiModelProperty("视频详情（多个用@分隔）")
        private String productVideoName;
        @ApiModelProperty("样本详情（多个用@分隔）")
        private String productSampleName;
        @ApiModelProperty("是否上下架（Y=上架，N=下架）")
        private String isOnsale;
        @ApiModelProperty("下架类型（1=系统下架，2=自主下架）")
        private Integer offsaleType;
        @ApiModelProperty("下架原因")
        private String offsaleReason;
        @ApiModelProperty("产品详情图名称（多个用@分隔）")
        private String productContentPicName;
        @ApiModelProperty("申请时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime createdAt;
        @ApiModelProperty("修改时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime updatedAt;
    }

    @Data
    @ApiModel("供应商-我的商品搜索角标-出参")
    public static class SupplierMySearchCountVo {
        @ApiModelProperty("上架数量")
        private int isOnsale1;
        @ApiModelProperty("下架数量")
        private int isOnsale2;
    }

    @Data
    @ApiModel("供应商-我的商品导出-出参")
    public static class SupplierMyExportVo {
        @ApiModelProperty("产品id")
        private Long productId;
        @ApiModelProperty("是否上下架（Y=上架，N=下架）")
        private String isOnsale;
        @ApiModelProperty("商品物料名称")
        private String materialName;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号/物料号")
        private String skuCode;
        @ApiModelProperty("商品编号")
        private String productCode;
        @ApiModelProperty("库存（1=现货，0=订货）")
        private String stock;
        @ApiModelProperty("货期")
        private String deliveryDate;
        @ApiModelProperty("计量单位")
        private String unit;
        @ApiModelProperty("重量")
        private String weight;
        @ApiModelProperty("最小起订量")
        private Integer minimunRequire;
        @ApiModelProperty("面价")
        private String price;
        @ApiModelProperty("供货价")
        private String supplyPrice;
        @ApiModelProperty("建议销售价")
        private String suggestPrice;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("商品系列名称")
        private String propName;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("规格json数据")
        private String specData;
        @ApiModelProperty("规格名")
        private String specName;
        @ApiModelProperty("规格值")
        private String specValue;
        @ApiModelProperty("商品图片（多个用@分隔）")
        private String productPicName;
        @ApiModelProperty("视频详情（多个用@分隔）")
        private String productVideoName;
        @ApiModelProperty("样本详情（多个用@分隔）")
        private String productSampleName;
        @ApiModelProperty("产品详情图名称（多个用@分隔）")
        private String productContentPicName;
        @ApiModelProperty("下架原因")
        private String offsaleReason;
        @ApiModelProperty("申请时间")
        private String createdAt;
        @ApiModelProperty("修改时间")
        private String updatedAt;
    }

    @Data
    @ApiModel("供应商-获取引导状态-出参")
    public static class SupplierGetGuideVo {
        @ApiModelProperty("是否启用（Y/N）")
        private String isEnable;
    }

    @Data
    @ApiModel("后台-搜索-出参")
    public static class AdminSearchVo {
        @ApiModelProperty("主键id")
        private String id;
        @ApiModelProperty("申请编号")
        private Long applyNo;
        @ApiModelProperty("商品物料名称")
        private String materialName;
        @ApiModelProperty("规格json数据")
        private String specData;
        @ApiModelProperty("规格名")
        private String specName;
        @ApiModelProperty("规格值")
        private String specValue;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号/物料号")
        private String skuCode;
        @ApiModelProperty("商品编号")
        private String productCode;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("品牌名称（中文）")
        private String brandNameCn;
        @ApiModelProperty("商品系列名称")
        private String propName;
        @ApiModelProperty("面价")
        private String price;
        @ApiModelProperty("供货价折扣")
        private BigDecimal supplyDiscount;
        @ApiModelProperty("供货价")
        private String supplyPrice;
        @ApiModelProperty("建议销售价")
        private String suggestPrice;
        @ApiModelProperty("调货价")
        private String distributePrice;
        @ApiModelProperty("调货价折扣")
        private BigDecimal distributeDiscount;
        @ApiModelProperty("调货价折扣 计算方式（乘：*、除：/）")
        private String distributeCalcWay;
        @ApiModelProperty("库存（1=现货，0=订货）")
        private Integer stock;
        @ApiModelProperty("货期")
        private String deliveryDate;
        @ApiModelProperty("计量单位")
        private String unit;
        @ApiModelProperty("重量")
        private String weight;
        @ApiModelProperty("最小起订量")
        private Integer minimunRequire;
        @ApiModelProperty("商品图片（多个用@分隔）")
        private String productPicName;
        @ApiModelProperty("视频详情（多个用@分隔）")
        private String productVideoName;
        @ApiModelProperty("样本详情（多个用@分隔）")
        private String productSampleName;
        @ApiModelProperty("产品详情图名称（多个用@分隔）")
        private String productContentPicName;
        @ApiModelProperty("编辑字段")
        private String editColumns;
        @ApiModelProperty("编辑规格")
        private String editSpecs;
        @ApiModelProperty("是否上下架（Y=上架，N=下架）")
        private String isOnsale;
        @ApiModelProperty("审核类型（1=商品新增，2=资料修改，3=价格修改，4=资料价格修改，5=图片修改）")
        private Integer auditType;
        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回）")
        private Integer auditStatus;
        @ApiModelProperty("审核备注")
        private String auditRemark;
        @ApiModelProperty("申请时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime createdAt;
        @ApiModelProperty("修改时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime updatedAt;
        @ApiModelProperty("待分部审核时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime auditTime1;
        @ApiModelProperty("待资料审核时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime auditTime2;
        @ApiModelProperty("待价格审核时间")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
        private LocalDateTime auditTime3;
        @ApiModelProperty("所属子公司")
        private String companyShortName;
        @ApiModelProperty("供应商名称")
        private String supplierName;
        @ApiModelProperty("公海产品id")
        private Long publicProductId;
        @ApiModelProperty("zydmall上架标识 1：上架 0或空：未上架")
        private String zydmallFlag;
        @ApiModelProperty("ERP产品编码")
        private String erpProductCode;
    }

    @Data
    @ApiModel("后台-导出-出参")
    public static class AdminExportVo {
        @ApiModelProperty("申请编号")
        private Long applyNo;
        @ApiModelProperty("审核状态（0=待提交，1=待分部审核，2=待资料审核，3=待价格审核，4=通过，5=驳回）")
        private String auditStatus;
        @ApiModelProperty("审核类型（1=商品新增，2=资料修改，3=价格修改，4=资料价格修改，5=图片修改）")
        private String auditType;
        @ApiModelProperty("所属子公司")
        private String companyShortName;
        @ApiModelProperty("供应商名称")
        private String supplierName;
        @ApiModelProperty("商品物料名称")
        private String materialName;
        @ApiModelProperty("产品型号")
        private String productType;
        @ApiModelProperty("订货号/物料号")
        private String skuCode;
        @ApiModelProperty("商品编号")
        private String productCode;
        @ApiModelProperty("库存（1=现货，0=订货）")
        private String stock;
        @ApiModelProperty("货期")
        private String deliveryDate;
        @ApiModelProperty("计量单位")
        private String unit;
        @ApiModelProperty("重量")
        private String weight;
        @ApiModelProperty("最小起订量")
        private Integer minimunRequire;
        @ApiModelProperty("面价")
        private String price;
        @ApiModelProperty("供货价折扣")
        private String supplyDiscount;
        @ApiModelProperty("供货价")
        private String supplyPrice;
        @ApiModelProperty("调货价折扣")
        private String distributeDiscount;
        @ApiModelProperty("调货价")
        private String distributePrice;
        @ApiModelProperty("建议销售价")
        private String suggestPrice;
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("商品系列名称")
        private String propName;
        @ApiModelProperty("一级分类名称")
        private String firstLevelCataName;
        @ApiModelProperty("二级分类名称")
        private String secondLevelCataName;
        @ApiModelProperty("三级分类名称")
        private String threeLevelCataName;
        @ApiModelProperty("规格json数据")
        private String specData;
        @ApiModelProperty("规格名")
        private String specName;
        @ApiModelProperty("规格值")
        private String specValue;
        @ApiModelProperty("商品图片（多个用@分隔）")
        private String productPicName;
        @ApiModelProperty("视频详情（多个用@分隔）")
        private String productVideoName;
        @ApiModelProperty("样本详情（多个用@分隔）")
        private String productSampleName;
        @ApiModelProperty("产品详情图名称（多个用@分隔）")
        private String productContentPicName;
        @ApiModelProperty("申请时间")
        private String createdAt;
        @ApiModelProperty("修改时间")
        private String updatedAt;
        @ApiModelProperty("待分部审核时间")
        private String auditTime1;
        @ApiModelProperty("待资料审核时间")
        private String auditTime2;
        @ApiModelProperty("待价格审核时间")
        private String auditTime3;
        @ApiModelProperty("变更记录")
        private String changeRecords;
    }

    @Data
    @ApiModel("公司信息-出参")
    public static class CompanyVo {
        @ApiModelProperty("公司id")
        private Integer companyId;
        @ApiModelProperty("公司简称")
        private String subCompany;
    }

    @Data
    @ApiModel("供应商信息-出参")
    public static class SupplierVo {
        @ApiModelProperty("供应商名称")
        private String name;
        @ApiModelProperty("登录账号")
        private String loginName;
    }

    @Data
    @ApiModel("公海规格-出参")
    public static class CommonSpecVo {
        @ApiModelProperty("规格id")
        private Long specId;
        @ApiModelProperty("规格名称")
        private String specName;
        @ApiModelProperty("规格值数组")
        private List<String> specValues;
    }

    @Data
    @ApiModel("后台-审核异步导出-出参")
    public static class AdminAuditExportVo {
        @ApiModelProperty("申请编号")
        @ExcelField(title = "申请编号", sort = 1)
        private Long applyNo;
        @ApiModelProperty("所属子公司")
        @ExcelField(title = "所属子公司", sort = 2)
        private String companyShortName;
        @ApiModelProperty("供应商名称")
        @ExcelField(title = "供应商", sort = 3)
        private String supplierName;
        @ApiModelProperty("商品物料名称")
        @ExcelField(title = "产品名称", sort = 4)
        private String materialName;
        @ApiModelProperty("产品型号")
        @ExcelField(title = "产品型号", sort = 5)
        private String productType;
        @ApiModelProperty("订货号/物料号")
        @ExcelField(title = "厂家物料号", sort = 6)
        private String skuCode;
        @ApiModelProperty("商品编号")
        @ExcelField(title = "商品编码", sort = 7)
        private String productCode;
    }

    @Data
    @ApiModel("后台-审核已标记上架zydmall导出-出参")
    public static class AdminAuditZydmallExportVo {
        @ApiModelProperty("所属子公司")
        @ExcelField(title = "所属子公司", sort = 1)
        private String companyShortName;
        @ApiModelProperty("供应商名称")
        @ExcelField(title = "供应商", sort = 2)
        private String supplierName;
        @ApiModelProperty("分类")
        @ExcelField(title = "分类", sort = 3)
        private String cataName;
        @ApiModelProperty("品牌")
        @ExcelField(title = "产品品牌", sort = 4)
        private String brandName;
        @ApiModelProperty("产品系列")
        @ExcelField(title = "产品系列", sort = 5)
        private String propName;
        @ApiModelProperty("商品ID")
        @ExcelField(title = "商品ID", sort = 6)
        private Long productId;
        @ApiModelProperty("产品型号")
        @ExcelField(title = "产品型号", sort = 7)
        private String productType;
        @ApiModelProperty("订货号/物料号")
        @ExcelField(title = "厂家物料号", sort = 8)
        private String skuCode;
        @ApiModelProperty("ERP产品编码")
        @ExcelField(title = "ERP产品编码", sort = 9)
        private String erpProductCode;
        @ApiModelProperty("变更详情")
        @ExcelField(title = "变更详情", sort = 10)
        private String editDetail;
    }

    @Data
    @ApiModel("品牌中文名称-出参")
    public static class BrandNameCnVo {
        @ApiModelProperty("品牌名称")
        private String brandName;
        @ApiModelProperty("品牌名称（中文）")
        private String brandNameCn;
    }
}
