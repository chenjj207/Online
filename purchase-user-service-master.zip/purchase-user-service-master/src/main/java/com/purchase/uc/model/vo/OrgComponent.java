package com.purchase.uc.model.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 用于选人控件中的组织信息
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年06月14日15:27:03
 */
@Getter
@Setter
@ToString
public class OrgComponent {
    /**
     * 主键【业务主键】
     */
    private String id;

    /**
     * 类型
     */
    private String type;

    /**
     * 名称[orgName|posName|groupName]
     */
    private String name;

    /**
     * 关联ID[orgId|posId|groupId]
     */
    private String relId;

    /**
     * type为POSITION时对应orgId
     */
    private String rangOrgId;

    /**
     * type为POSITION时对应orgName
     */
    private String relName;

    /**
     * 类型名称[部门|群组|岗位]
     */
    @ApiModelProperty(value = "组织类型")
    private String typeName;
    private String namePath;

}
