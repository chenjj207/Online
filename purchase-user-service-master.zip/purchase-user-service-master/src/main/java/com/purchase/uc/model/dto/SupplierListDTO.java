package com.purchase.uc.model.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class SupplierListDTO {

    @NotBlank(message = "数据类型不能为空")
    @ApiModelProperty("数据类型")
    private String type;
}
