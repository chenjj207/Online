package com.purchase.uc.listener;

import com.alibaba.excel.annotation.ExcelProperty;
import com.purchase.uc.model.vo.ImportExcelUser;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.model.vo.ErrorImportExcelUser;
import com.purchase.uc.model.vo.ExcelUser;
import com.purchase.uc.utils.UcRedisKeys;
import com.purchase.uc.utils.UcUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 人员导入
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class UserImportBaseExcelListener extends BaseImportExcelListener<ImportExcelUser> {
    private static final Field[] fields = ImportExcelUser.class.getDeclaredFields();
    private Map<String, Integer> repeatFiledMap = new HashMap<>();

    @Override
    protected boolean analysisFilter(ImportExcelUser user) {
        if (rowNum++ < 2 || user == null || UcUtil.checkImportExcelUserEmpty(user)) {
            return false;
        }

        List<String> errorMsg = new ArrayList<>();
        for (Field field : fields) {
            ExcelProperty property = field.getAnnotation(ExcelProperty.class);
            if (property == null) {
                continue;
            }

            int index = property.index() + 1;
            Object value;
            try {
                field.setAccessible(true);
                value = field.get(user);
                if (field.isAnnotationPresent(NotNull.class)
                        && (value == null
                        || (value instanceof String)
                        && StringUtils.isBlank(String.valueOf(value)))) {
                    addErrorData(errorMsg, index, "不可为空");
                    continue;
                }
            } catch (IllegalAccessException e) {
                log.error("数据解析失败", e);
                addErrorData(errorMsg, index, "数据解析失败");
                continue;
            }

            if (value == null) {
                continue;
            }

            String name = field.getName();
            if (ExcelUser.CODE.equals(name)
                    || ExcelUser.EMAIL.equals(name)
                    || ExcelUser.MOBILE.equals(name)
                    || ExcelUser.ID_CARD.equals(name)
                    || ExcelUser.LOGIN_NAME.equals(name)) {
                String key = name + UcConstants.SEPARATOR_CHARS + String.valueOf(value);
                if (StringUtils.isNotEmpty(userLoginFieldAndIdMap.get(key))) {
                    String[] names = property.value();
                    String nameValue = "数据";
                    if (ArrayUtils.isNotEmpty(names)) {
                        nameValue = names[0];
                    }

                    addErrorData(errorMsg, index, nameValue + "已存在");
                }

                Integer repeatRowNum = repeatFiledMap.get(key);
                if (repeatRowNum != null) {
                    String[] names = property.value();
                    String nameValue = "数据";
                    if (ArrayUtils.isNotEmpty(names)) {
                        nameValue = names[0];
                    }

                    addErrorData(errorMsg, index, nameValue + "与第" + repeatRowNum + "行重复");
                } else {
                    repeatFiledMap.put(key, rowNum + 1);
                }
                continue;
            }

            if (ExcelUser.LEADER_NAME.equals(name)) {
                user.setLeaderId(getLeaderId(errorMsg, index, user.getLeaderCode()));
                continue;
            }

            if (ExcelUser.ORG_NAME_PATH.equals(name)) {
                user.setOrgId(validateOrg(index, value, errorMsg));
                continue;
            }

            if (ExcelUser.POSITION_NAME.equals(name)) {
                String positionCode = user.getPositionCode();
                String positionId = validPosition(positionCode, user.getPositionCategory(), index, value, errorMsg);
                user.setPositionId(positionId);
            }
        }

        boolean error = errorMsg.size() > 0;
        if (error) {
            addErrorData(user, errorMsg);
        }

        return !error;
    }

    private void addErrorData(ImportExcelUser user, List<String> errorData) {
        ErrorImportExcelUser error = new ErrorImportExcelUser();
        BeanUtils.copyProperties(user, error);
        error.setMessage(errorData.toString());
        errorUsers.add(error);
    }

    @Override
    protected void saveUser(List<ImportExcelUser> dataList) {
        if (CollectionUtils.isEmpty(dataList)) {
            return;
        }

        userService.saveImport(dataList);
    }

    @Override
    protected String getCacheKey() {
        return UcRedisKeys.USER_IMPORT + handlerUserId;
    }

    @Override
    protected String getErrorTemplate() {
        return "template/emptyImportUserTemplate.xlsx";
    }

    @Override
    protected Class<? extends ExcelUser> getErrorExcelClass() {
        return ErrorImportExcelUser.class;
    }
}
