package com.purchase.uc.service;

import com.purchase.uc.mapper.CorpInfoMapper;
import com.purchase.uc.model.CorpInfo;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;


/**
 * CorpInfoService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2021-04-02 10:35:28
 */
@Service
public class CorpInfoService extends BaseServiceImpl<CorpInfo> {

    @Resource
    private CorpInfoMapper corpInfoMapper;

    /**
     * saas同步新增
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String syncAdd(CorpInfo corpInfo) {
        return insert(corpInfo);
    }

}
