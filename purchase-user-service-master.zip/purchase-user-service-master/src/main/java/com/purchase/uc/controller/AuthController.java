package com.purchase.uc.controller;

import com.purchase.uc.base.DataPermissionEnum;
import com.purchase.uc.client.SaasClient;
import com.purchase.uc.model.RoleAuthRel;
import com.purchase.uc.model.vo.AuthTreeNode;
import com.purchase.uc.service.RoleAuthRelService;
import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.model.Auth;
import com.purchase.uc.model.Role;
import com.purchase.uc.service.AuthService;
import com.purchase.uc.service.RoleService;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.TreeNode;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Auth接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/auth")
@Api(value = "Auth接口", tags = {"Auth接口"})
public class AuthController {
    private static Logger logger = LoggerFactory.getLogger(AuthController.class);
    private static final PathMatcher PATH_MATCHER = new AntPathMatcher();

    @Resource
    private AuthService authService;
    @Resource
    private RoleService roleService;
    @Resource
    private RoleAuthRelService roleAuthRelService;
    @Resource
    private SaasClient saasClient;

    @GetMapping(value = "/getMenuTree")
    @ApiOperation(value = "获取菜单")
    public JsonResult<TreeNode> getMenuTree() {
        TreeNode authTree = authService.getAuthMenuTree();
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), authTree);
    }

    @GetMapping(value = "/getAllMenuTree")
    @ApiOperation(value = "获取菜单")
    public JsonResult<TreeNode> getAllMenuTree() {
        TreeNode authTree = authService.getAuthMenuTree();
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), authTree);
    }

    @GetMapping(value = "/getMyAuthTree")
    @ApiOperation(value = "根据管理类型获取我能管理的权限树")
    @ApiImplicitParams(@ApiImplicitParam(name = "manage", paramType = "query", dataType = "String",
            value = "是否为管理员权限 true:管理员权限树，false:学员权限树，null:我能管理的所有权限树")
    )
    public JsonResult<TreeNode> getMyAuthTree(Boolean manage) {
        TreeNode authTree = authService.getMyAuthTree(manage);
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), authTree);
    }

    @GetMapping(value = "/getCanManageAuthTree/{roleId}")
    @ApiOperation(value = "根据角色Id获取我能管理的权限树")
    @ApiImplicitParams(@ApiImplicitParam(name = "roleId", paramType = "query", dataType = "String",
            value = "角色Id")
    )
    public JsonResult<TreeNode> getCanManageAuthTree(@PathVariable(value = "roleId") @Check String roleId) {
        Role role = roleService.get(roleId);
        if (role == null) {
            return new JsonResult<>(false, "角色不存在");
        }

        TreeNode authTree = authService.getAuthMenuTree();
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), authTree);
    }

    @GetMapping(value = "/getAuthTree/{userId}")
    @ApiOperation(value = "根据userId获取对应权限树")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "userId", value = "用户ID", paramType = "path", dataType = "String",
                    required = true)
    )
    public JsonResult<TreeNode> getAuthTree(@PathVariable("userId") @Check String userId) {
        TreeNode authTree = authService.getAuthTreeByUserId(userId, null, false);
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), authTree);
    }

    @GetMapping(value = "/getSelectedAuthIds/{roleId}")
    @ApiOperation(value = "根据角色Id获取已选的权限Id列表")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "roleId", value = "角色Id", paramType = "path", dataType = "String",
                    required = true)
    )
    public JsonResult<Map<String, DataPermissionEnum>> getSelectedAuthIds(@PathVariable("roleId") @Check String roleId) {
        List<RoleAuthRel> authRelList = roleAuthRelService.getAuthRelList(Collections.singletonList(roleId));
        if (CollectionUtils.isEmpty(authRelList)) {
            return new JsonResult<>(true, "查询成功");
        }

        Map<String, DataPermissionEnum> authIdAndPermissionMap = authRelList.stream()
                .collect(Collectors.toMap(RoleAuthRel::getAuthId, RoleAuthRel::getDataPermission,
                        (a, b) -> b, () -> new HashMap<>(authRelList.size())));
        return new JsonResult<>(true, null, authIdAndPermissionMap);
    }

    @GetMapping(value = "/putAuthToRedis/{corpCode}")
    @ApiOperation(value = "刷新公司权限缓存")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "corpCode", value = "corpCode", paramType = "path", required = true)
    )
    public JsonResult<String> putAuthToRedis(@PathVariable(value = "corpCode") @Check String corpCode) {
        try {
            ContextHandler.setCorpCode(corpCode);
            authService.putAuthTreeToRedis(corpCode);
            return new JsonResult<>(true, "刷新成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, "刷新失败");
        }
    }

    /**
     * 初始化权限菜单数据
     */
    @RequestMapping(value = "init", method = RequestMethod.POST)
    @ApiOperation(value = "初始化菜单数据")
    @ApiImplicitParams(@ApiImplicitParam(name = "corpCode", paramType = "query", dataType = "String",
            value = "公司corpCode")
    )
    public JsonResult<List<String>> initMenu(String jsonPath, @Check String corpCode) {
        if (StringUtils.isEmpty(corpCode)) {
            ContextHandler.setCorpCode(corpCode);
        }

        authService.init();
        return new JsonResult<>(true, "初始化数据成功");
    }

    @RequestMapping(value = "/canAccess", method = RequestMethod.POST)
    public JsonResult<Boolean> canAccess(@RequestBody String url) {
        // 公司所有权限【需要验证权限的urls】
        AuthTreeNode tree = authService.getAuthTree();
        if (tree == null) {
            return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), true);
        }

        List<String> allAuthUrls = getAuthUrls(tree);
        if (CollectionUtils.isEmpty(allAuthUrls)) {
            return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), true);
        }

        for (String authCode : allAuthUrls) {
            // 访问url不在公司需要验证权限的列表可以访问
            if (!PATH_MATCHER.match(authCode, url)) {
                return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), true);
            }
        }

        // 用户所拥有的权限【需要验证权限的urls】
        AuthTreeNode myAuthTree = authService.getAuthTreeByUserId(ContextHandler.getUserId(), null, false);
        if (myAuthTree == null) {
            return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), false);
        }

        List<String> myAuthUrls = getAuthUrls(myAuthTree);
        if (CollectionUtils.isEmpty(myAuthUrls)) {
            return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), false);
        }

        for (String authUrl : myAuthUrls) {
            // 访问url在我的权限范围可访问
            if (PATH_MATCHER.match(authUrl, url)) {
                return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), true);
            }
        }

        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), false);
    }

    private List<String> getAuthUrls(AuthTreeNode authTree) {
        if (authTree == null) {
            return new ArrayList<>(0);
        }

        List<String> authUrls = new ArrayList<>();
        getAuthUrls(authTree.getChildList(), authUrls);
        return authUrls;
    }

    private void getAuthUrls(List<AuthTreeNode> treeNodes, List<String> authUrls) {
        if (CollectionUtils.isEmpty(treeNodes)) {
            return;
        }

        for (AuthTreeNode treeNode : treeNodes) {
            authUrls.add(treeNode.getCon());
            getAuthUrls(treeNode.getChildList(), authUrls);
        }
    }

    @RequestMapping(value = "/getMyAuthUrls", method = RequestMethod.POST)
    public JsonResult<List<String>> getMyAuthUrls() {
        AuthTreeNode authTree = authService.getAuthTreeByUserId(ContextHandler.getUserId(), null, false);
        List<String> authUrls = getAuthUrls(authTree);
        return new JsonResult<>(true, "", authUrls);
    }

    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public JsonResult<String> delete(@RequestParam String id) {
        authService.delete(id);
        return new JsonResult<>();
    }

    @RequestMapping(value = "/get", method = RequestMethod.GET)
    public JsonResult<Auth> get(@RequestParam String id) {
        return new JsonResult<>(true, null, authService.getById(id));
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public JsonResult<String> save(@RequestBody Auth auth) {
        String id = authService.save(auth);
        return new JsonResult<>(true, "", id);
    }

    @RequestMapping(value = "/move", method = RequestMethod.POST)
    public JsonResult<List<String>> move(@RequestParam String id, @RequestParam String pId,
                                         String preId, String nextId) {
        authService.move(id, pId, preId, nextId);
        return new JsonResult<>();
    }

    /**
     * 初始化权限菜单数据
     */
    @GetMapping(value = "/public/initAllCorp")
    @ApiOperation(value = "初始化所有租户菜单数据")
    public JsonResult<String> initAllCorpMenu() {
        List<String> corpCodes = saasClient.listAllCorpCode();
        if (CollectionUtils.isNotEmpty(corpCodes)) {
            for (String corpCode : corpCodes) {
                ContextHandler.setCorpCode(corpCode);
                authService.init();
            }
        }
        return new JsonResult<>(true, "初始化数据成功");
    }


}
