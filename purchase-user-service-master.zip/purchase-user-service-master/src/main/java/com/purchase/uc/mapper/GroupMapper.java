package com.purchase.uc.mapper;

import com.purchase.uc.model.Group;
import com.purchase.uc.model.vo.GroupSearch;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 群组Mapper接口类
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
public interface GroupMapper extends QguBaseMapper<Group> {

    /**
     * 根据分页条件及查询条件获取分页list
     *
     * @param group    查询条件 name:群组或创建人人模糊搜索
     * @param pageInfo 分页条件
     * @param orders   排序条件
     * @return 指定大小的list
     */
    List<Group> searchGroup(@Param("group") GroupSearch group, @Param("page") Page<Group> pageInfo,
                            @Param("orders") String orders);

    /**
     * 满足分页条件的总条数
     *
     * @param group 查询条件 name:群组或创建人人模糊搜索
     * @return 总条数
     */
    int getGroupTotal(@Param("group") GroupSearch group);
}
