package com.purchase.uc.job;

import com.github.ltsopensource.core.domain.Action;
import com.github.ltsopensource.spring.boot.annotation.JobRunner4TaskTracker;
import com.github.ltsopensource.tasktracker.Result;
import com.github.ltsopensource.tasktracker.runner.JobContext;
import com.github.ltsopensource.tasktracker.runner.JobRunner;
import com.purchase.uc.mapper.RoleMapper;
import com.purchase.uc.mapper.UserRoleRelMapper;
import com.purchase.uc.model.Role;
import com.purchase.uc.service.UserRoleRelService;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.helpers.MessageFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author jidonglin
 * @Description: 初始化子公司用户角色管理
 * @date 2024/11/06  14:27
 */
@Slf4j
@Component
@JobRunner4TaskTracker
public class InitCompanyUserJob implements JobRunner {

    @Resource
    RoleMapper roleMapper;
    @Resource
    UserRoleRelMapper userRoleRelMapper;
    @Autowired
    UserRoleRelService userRoleRelService;

    /**
     * 执行任务
     * 抛出异常则消费失败, 返回null则认为是消费成功
     *
     * @param jobContext
     */
    @Override
    public Result run(JobContext jobContext) throws Throwable {
        String type = jobContext.getJob().getParam("type");
        switch (type) {
            case "INIT_COMPANY_USER":
                //增量更新
                ContextHandler.setCorpCode("default");
                Role roleQuery = new Role();
                roleQuery.setName("子公司");
                Role role = roleMapper.selectOne(roleQuery);
                if (role == null){
                    return new Result(Action.EXECUTE_SUCCESS, "当前无【子公司】角色");
                }
                List<String> userIdList = userRoleRelMapper.selectUserIdWithNoUserRole(role.getId());
                //绑定用户-角色关系
                userRoleRelService.addUserRoleRel(userIdList, role.getId());
                //增量更新
                return new Result(Action.EXECUTE_SUCCESS, "初始化子公司用户角色成功");
            default:
                return new Result(Action.EXECUTE_EXCEPTION, MessageFormatter.format("非法执行命令: {}", type).getMessage());
        }
    }
}
