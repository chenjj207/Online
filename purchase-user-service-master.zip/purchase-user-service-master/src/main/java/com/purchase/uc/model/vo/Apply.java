package com.purchase.uc.model.vo;

import lombok.Data;

/**
 * @since TangFD@HF 2020/1/15.
 */
@Data
public class Apply {
    private String id;
    private String name;
    private String phone;
    private String companyName;
    private String address;
    private String count;
    private String email;
    private String description;
}
