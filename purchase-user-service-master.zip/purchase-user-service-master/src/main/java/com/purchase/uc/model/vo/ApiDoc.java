package com.purchase.uc.model.vo;

import lombok.Data;

import java.util.List;

/**
 * api dcc 实体
 */
@Data
public class ApiDoc {
    /**
     * doc tag
     */
    private List<Tag> tags;
    /**
     * doc paths
     */
    private Object paths;
    /**
     * doc appCode
     */
    private String appCode;
    /**
     * doc code
     */
    private String code;

    /**
     * doc code
     */
    private String url;

    /**
     * doc name
     */
    private String name;

    /**
     * api tag 对象
     */
    @Data
    public class Tag {
        private  String name;
        private  String description;
        private  int order;
    }

}
