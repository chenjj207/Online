package com.purchase.uc.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.function.Supplier;

/**
 * @author zhangcheng
 */
@Slf4j
@SuppressWarnings("unchecked")
public class RedisUtil {

    public static Long genCode(String customeCode, RedisTemplate redisTemplate, Supplier<Long> task) {
        if (StringUtils.isEmpty(customeCode)) {
            customeCode = "ID";
        }

        String redisKey = customeCode + "_INCR_NO";
        Object redisNumber = redisTemplate.opsForValue().get(redisKey);
        Long num;
        if (redisNumber != null) {
            return redisTemplate.opsForValue().increment(redisKey, 1);
        }
        Long temp = task.get();
        num = (temp == null ? 0 : temp) +1;
        redisTemplate.opsForValue().set(redisKey, num);
        return num;
    }

}
