package com.purchase.uc.service;

import com.purchase.uc.model.vo.OrgComponent;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;

import java.util.List;

/**
 * 选组织组件需要实现的公共接口，使用组件必须要实现接口对应功能
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年06月15日17:05:16
 */
public interface OrgComponentService {
    /**
     * 该方法用于添加传入的组织列表，当已选组织列表已存在该组织时跳过
     *
     * @param condition 添加组织条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relIds 必须 = List<String> userIds</li>
     *                  </p>
     */
    void addOrgs(ComponentCondition condition);

    /**
     * 该方法用于全量删除查询条件下的全部组织
     *
     * @param condition 删除条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType != com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>category 必须</li>
     *                  <li>includeChild 必须</li>
     *                  </p>
     */
    void removeAllOrgs(ComponentCondition condition);

    /**
     * 该方法用于删除传入的组织列表
     *
     * @param condition 删除条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relIds 必须 = List<String> userIds</li>
     *                  </p>
     */
    void removeOrgs(ComponentCondition condition);

    /**
     * 该方法用于根据查询条件获取所有已选组织ID集合
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType != com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  </p>
     */
    List<String> listSelectedOrgId(ComponentCondition condition);

    /**
     * 该方法用于根据查询条件分页获取已选组织ID
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType != com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  <li>keywords 可选</li>
     *                  </p>
     */
    Page<String> searchSelectedOrgId(ComponentCondition condition);

    /**
     * 该方法用于根据查询条件分页获取已选组织
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType != com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  <li>keywords 可选</li>
     *                  </p>
     */
    Page<OrgComponent> searchSelectedOrg(ComponentCondition condition);
}
