package com.purchase.uc.mapper;

import com.purchase.uc.model.SysSetting;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 *
 * @author auto
 * @version 1.0
 * @since 2020-04-07 16:42:35
 */
public interface SysSettingMapper extends QguBaseMapper<SysSetting> {

}

