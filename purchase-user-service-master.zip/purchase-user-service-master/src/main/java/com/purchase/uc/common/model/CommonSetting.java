
package com.purchase.uc.common.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-23 09:41:22
 */
@Getter
@Setter
@ToString
@ApiModel(value = "CommonSetting", description = "")
@Table(name = "t_common_setting")
public class CommonSetting extends BaseCorpModel {


    /**
     * 功能编号
     */
    @ApiModelProperty(value = "功能编号")
    private String funCode;

    /**
     * 设置内容，每个功能一条json数据
     */
    @ApiModelProperty(value = "设置内容，每个功能一条json数据")
    private String content;

}
