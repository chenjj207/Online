package com.purchase.uc.controller;

import com.qgutech.qgyun.dev.common.controller.CommonRelController;
import com.purchase.uc.model.UseScope;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * UseScopeController 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2019-06-13 14:18:21
 */
@RestController
@RequestMapping(value = "/useScope")
@Api(value = "UseScopeController", tags = {"UseScopeController 服务提供类"})
public class UseScopeController extends CommonRelController<UseScope> {

}
