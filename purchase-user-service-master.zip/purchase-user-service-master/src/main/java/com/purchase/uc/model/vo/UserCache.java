package com.purchase.uc.model.vo;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.purchase.uc.base.UcConstants;
import lombok.Data;
import org.apache.commons.lang.StringUtils;

import java.time.LocalDate;

/**
 * 用户基本信息缓存
 */
@Data
public class UserCache {
    /**
     * 姓名
     */
    private String id;

    /**
     * 姓名
     */
    private String name;

    /**
     * 员工编号
     */
    private String code;

    /**
     * 登录名
     */
    private String loginName;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * 身份证号
     */
    private String idCard;

    /**
     * 用户头像
     */
    private String faceId;

    /**
     * 部门主键
     */
    private String orgId;

    /**
     * 岗位主键
     */
    private String positionId;

    /**
     * 隶属上级主键
     */
    private String leaderId;

    /**
     * 入职日期
     */
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class, as = LocalDate.class)
    private LocalDate entryAt;

    /**
     * 用户年龄
     */
    private Integer age;

    /**
     * 级别
     */
    private String level;

    /**
     * 类型
     */
    private String type;

    /**
     * 类型(国内:CN,海外:FW)
     */
//    private String category;

    /**
     * 用户头像
     */
    private String faceUrl;

    /**
     * 供应商
     */
    private String supplierId;

    /**
     * 分公司编号
     */
    private String companyId;

    /**
     * 分公司编码
     */
    private String comBm;

    /**
     * 所属公司名称
     */
    private String companyName;
    /**
     * 类型(SUPPLIER: 供应商，USER: 用户(供应链、子公司))
     */
    private String dataType;

    public String encode() {
        StringBuffer content = new StringBuffer();
        if (StringUtils.isNotEmpty(id)) {
            content.append(id);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(name)) {
            content.append(name);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(code)) {
            content.append(code);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(loginName)) {
            content.append(loginName);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(orgId)) {
            content.append(orgId);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(email)) {
            content.append(email);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(mobile)) {
            content.append(mobile);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(idCard)) {
            content.append(idCard);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(faceId)) {
            content.append(faceId);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(positionId)) {
            content.append(positionId);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(leaderId)) {
            content.append(leaderId);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (StringUtils.isNotEmpty(level)) {
            content.append(level);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (age != null) {
            content.append(age);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (entryAt != null) {
            content.append(entryAt);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (type != null) {
            content.append(type);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (faceUrl != null) {
            content.append(faceUrl);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (supplierId != null) {
            content.append(supplierId);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (companyId != null) {
            content.append(companyId);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (comBm != null) {
            content.append(comBm);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (companyName != null) {
            content.append(companyName);
        }
        content.append(UcConstants.SEPARATOR_CHARS);
        if (dataType != null) {
            content.append(dataType);
        }
//        content.append(UcConstants.SEPARATOR_CHARS);
//        if (category != null) {
//            content.append(category);
//        }
        return content.toString();
    }

    public static UserCache decode(String content) {
        if (StringUtils.isEmpty(content)) {
            return null;
        }

        String[] split = StringUtils.splitByWholeSeparatorPreserveAllTokens(content, UcConstants.SEPARATOR_CHARS);
        if (split.length != 21) {
            return null;
        }

        int index = 0;
        UserCache cache = new UserCache();
        String value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setId(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setName(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setCode(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setLoginName(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setOrgId(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setEmail(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setMobile(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setIdCard(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setFaceId(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setPositionId(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setLeaderId(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setLevel(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setAge(Integer.valueOf(value));
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setEntryAt(LocalDate.parse(value, UcConstants.formatter));
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setType(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setFaceUrl(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setSupplierId(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setCompanyId(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setComBm(value);
        }
        value = split[index++];
        if (StringUtils.isNotBlank(value)) {
            cache.setCompanyName(value);
        }
        value = split[index];
        if (StringUtils.isNotBlank(value)) {
            cache.setDataType(value);
        }
//        value = split[index];
//        if (StringUtils.isNotBlank(value)) {
//            cache.setCategory(value);
//        }
        return cache;
    }
}
