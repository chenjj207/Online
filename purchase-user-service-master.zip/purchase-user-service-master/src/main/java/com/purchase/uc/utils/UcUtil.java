package com.purchase.uc.utils;

import com.alibaba.fastjson.JSON;
import com.purchase.uc.model.GroupCondition;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.model.Auth;
import com.purchase.uc.model.User;
import com.purchase.uc.model.vo.*;
import com.qgutech.qgyun.framework.database.model.BaseCorpTreeModel;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.model.TreeNode;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import tk.mybatis.mapper.util.StringUtil;

import java.util.*;

/**
 * UC模块公共处理类
 *
 * @version 1.0
 * @since 2019年06月03日11:34:30
 */
public class UcUtil {

    /**
     * 根据传入的treeIds返回对应的新的tree
     *
     * @param treeNode 传入的tree
     * @param treeIds  传入的treeIds
     * @return 重新拼装的树
     */
    public static TreeNode getSubTree(TreeNode treeNode, List<String> treeIds) {
        TreeNode newRootTree = new TreeNode("*", "*", "*", "*");
        if (CollectionUtils.isEmpty(treeIds)) {
            return newRootTree;
        }

        dealTree(treeNode.getChild(), newRootTree, treeIds);

        return newRootTree;
    }

    private static void dealTree(List<TreeNode> nodeList, TreeNode newTreeNode, List<String> treeIds) {
        if (CollectionUtils.isEmpty(nodeList)) {
            return;
        }

        for (TreeNode node : nodeList) {
            if (!treeIds.contains(node.getId())) {
                continue;
            }

            List<TreeNode> child = newTreeNode.getChild();
            if (child == null) {
                child = new ArrayList<>();
                newTreeNode.setChild(child);
            }

            TreeNode newNode = new TreeNode();
            newNode.setId(node.getId());
            newNode.setName(node.getName());
            newNode.setCode(node.getCode());
            newNode.setPId(node.getPId());
            child.add(newNode);

            dealTree(node.getChild(), newNode, treeIds);
        }
    }

    public static List<Gcp> convertToGcp(List<GroupCondition> conditions) {
        if (CollectionUtils.isEmpty(conditions)) {
            return new ArrayList<>(0);
        }

        List<Gcp> gcpList = new ArrayList<>(conditions.size());
        for (GroupCondition condition : conditions) {
            String context = condition.getContext();
            if (StringUtils.isEmpty(context)) {
                continue;
            }

            Gcp gcp = JSON.parseObject(context, Gcp.class);
            gcp.setShowOrder(condition.getShowOrder());
            gcpList.add(gcp);
        }

        return gcpList;
    }

    public static List<GroupCondition> convertToCondition(List<Gcp> gcpList, String groupId) {
        if (CollectionUtils.isEmpty(gcpList)) {
            return new ArrayList<>(0);
        }

        List<GroupCondition> conditions = new ArrayList<>(gcpList.size());
        for (Gcp gcp : gcpList) {
            if (null == gcp) {
                continue;
            }

            GroupCondition condition = new GroupCondition();
            condition.setGroupId(groupId);

            condition.setShowOrder(gcp.getShowOrder());
            condition.setContext(JSON.toJSONString(gcp));
            conditions.add(condition);
        }

        return conditions;
    }

    public static void validatePage(Page page) {
        if (page == null) {
            throw new IllegalArgumentException("page not be null!");
        }

        if (page.getPageNum() < 0) {
            throw new IllegalArgumentException("page num invalid");
        }

        if (page.getPageSize() < 0) {
            throw new IllegalArgumentException("page size invalid");
        }
    }

    /**
     * 根据传入的trees返回对应的新 <T extends BaseCorpTreeModel> List<T> trees
     *
     * @param trees 传入的trees
     * @return 重新拼装的树
     */
    public static <T extends BaseCorpTreeModel> TreeNode getTreeFromList(List<T> trees, TreeNode... rootNodes) {
        TreeNode rootNode = new TreeNode("*", "*", "全部", null, true);
        if (rootNodes != null && rootNodes.length > 0) {
            rootNode = rootNodes[0];
        }

        if (CollectionUtils.isEmpty(trees)) {
            return rootNode;
        }

        Map<String, TreeNode> idAndNodeMap = getIdAndNodeMap(trees, rootNode);
        for (T t : trees) {
            TreeNode node = idAndNodeMap.get(t.getpId());
            if (node == null) {
                continue;
            }

            List<TreeNode> children = node.getChild();
            if (children == null) {
                children = new ArrayList<>();
                node.setChild(children);
            }

            children.add(idAndNodeMap.get(t.getId()));
        }

        return rootNode;
    }

    private static <T extends BaseCorpTreeModel> Map<String, TreeNode> getIdAndNodeMap(List<T> list,
                                                                                       TreeNode rootNode) {
        Map<String, TreeNode> idAndNodeMap = new HashMap<>(list.size() + 1);
        list.forEach(t -> {
            TreeNode node = new TreeNode(t.getId(), t.getpId(), t.getName(), t.getCode(), null, true);
            idAndNodeMap.put(t.getId(), node);
        });

        idAndNodeMap.put(rootNode.getId(), rootNode);
        return idAndNodeMap;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Collection<?>> Map<String, T> getResultMap(RedisTemplate redisTemplate,
                                                                        String userRoleKey,
                                                                        Collection<String> userIds) {
        HashOperations<String, String, Map<String, T>> operations = redisTemplate.opsForHash();
        List<Map<String, T>> maps = null;
        if (CollectionUtils.isNotEmpty(userIds)) {
            maps = operations.multiGet(userRoleKey, userIds);
        } else {
            maps = operations.values(userRoleKey);
        }

        if (CollectionUtils.isEmpty(maps)) {
            return new HashMap<>(0);
        }

        Map<String, T> existMap = new HashMap<>(maps.size());
        maps.stream().filter(Objects::nonNull).forEach(existMap::putAll);
        return existMap;
    }

    public static <K, V> Set<V> getCollection(Map<K, Set<V>> map) {
        Set<V> v = new HashSet<>();
        if (null != map) {
            for (Set<V> value : map.values()) {
                if (CollectionUtils.isEmpty(value)) {
                    continue;
                }

                v.addAll(value);
            }
        }

        return v;
    }

    public static <K> Set<K> getSet(Collection<Set<K>> collection) {
        Set<K> v = new HashSet<>();
        if (null != collection) {
            for (Set<K> value : collection) {
                if (CollectionUtils.isEmpty(value)) {
                    continue;
                }

                v.addAll(value);
            }
        }

        return v;
    }

    public static <K> List<K> getList(Collection<List<K>> collection) {
        List<K> v = new ArrayList<K>();
        if (null != collection) {
            for (List<K> value : collection) {
                if (CollectionUtils.isEmpty(value)) {
                    continue;
                }

                v.addAll(value);
            }
        }

        return v;
    }

    public static List<User> convertToUser(List<UserCache> conditions) {
        if (CollectionUtils.isEmpty(conditions)) {
            return new ArrayList<>(0);
        }

        List<User> userList = new ArrayList<>(conditions.size());
        for (UserCache condition : conditions) {
            if (condition == null) {
                continue;
            }

            User user = new User();
            BeanUtils.copyProperties(condition, user);
            userList.add(user);
        }

        return userList;
    }

    public static List<UserCache> convertToUserCache(List<User> conditions) {
        if (CollectionUtils.isEmpty(conditions)) {
            return new ArrayList<>(0);
        }

        List<UserCache> userCaches = new ArrayList<>(conditions.size());
        for (User condition : conditions) {
            if (condition == null) {
                continue;
            }

            UserCache userCache = new UserCache();
            BeanUtils.copyProperties(condition, userCache);
            userCaches.add(userCache);
        }

        return userCaches;
    }

    public static List<UserCache> toUserCache(List<String> userCacheStrings) {
        if (CollectionUtils.isEmpty(userCacheStrings)) {
            return new ArrayList<>(0);
        }

        List<UserCache> userCacheList = new ArrayList<>(userCacheStrings.size());
        userCacheStrings.forEach(user -> {
            UserCache userCache = UserCache.decode(user);
            if (userCache != null) {
                userCacheList.add(userCache);
            }
        });

        return userCacheList;
    }

    public static String getSex(String sex) {
        if ("男".equals(sex)) {
            return UcConstants.SEX_MALE;
        } else if ("女".equals(sex)) {
            return UcConstants.SEX_FEMALE;
        }

        return UcConstants.SEX_SECRET;
    }

    public static String getStatus(String value) {
        if ("冻结".equals(value)) {
            return UcConstants.STATUS_DISABLED;
        } else if ("激活".equals(value)) {
            return UcConstants.STATUS_ENABLED;
        } else if ("离职".equals(value)) {
            return UcConstants.STATUS_LEAVE;
        }

        return UcConstants.STATUS_ENABLED;
    }


    /**
     * 根据传入的trees返回对应的新 <T extends BaseCorpTreeModel> List<T> trees
     *
     * @param trees 传入的trees
     * @return 重新拼装的树
     */
    public static AuthTreeNode getAuthTreeFromList(List<Auth> trees, AuthTreeNode... rootNodes) {
        AuthTreeNode rootNode = new AuthTreeNode("*", "*", "全部");
        if (rootNodes != null && rootNodes.length > 0) {
            rootNode = rootNodes[0];
        }

        if (CollectionUtils.isEmpty(trees)) {
            return rootNode;
        }

        Map<String, AuthTreeNode> authIdAndNodeMap = getAuthIdAndNodeMap(trees, rootNode);
        for (Auth auth : trees) {
            String pId = auth.getpId();
            String id = auth.getId();
            AuthTreeNode node = authIdAndNodeMap.get(pId);
            if (node == null) {
                continue;
            }

            List<AuthTreeNode> children = node.getChildList();
            if (children == null) {
                children = new ArrayList<>();
                node.setChildList(children);
            }

            children.add(authIdAndNodeMap.get(id));
        }

        return rootNode;
    }

    private static Map<String, AuthTreeNode> getAuthIdAndNodeMap(List<Auth> list, AuthTreeNode rootNode) {
        Map<String, AuthTreeNode> idAndNodeMap = new HashMap<>(list.size() + 1);
        list.forEach(t -> idAndNodeMap.put(t.getId(), new AuthTreeNode(t)));
        idAndNodeMap.put(rootNode.getId(), rootNode);

        return idAndNodeMap;
    }

    public static boolean checkImportExcelUserEmpty(ImportExcelUser user) {
        return StringUtil.isEmpty(user.getOrgCode())
                && StringUtil.isEmpty(user.getOrgNamePath())
                && StringUtil.isEmpty(user.getPositionCategory())
                && StringUtil.isEmpty(user.getPositionCode())
                && StringUtil.isEmpty(user.getPositionName())
                && StringUtil.isEmpty(user.getCode())
                && StringUtil.isEmpty(user.getName())
                && StringUtil.isEmpty(user.getLoginName())
                && StringUtil.isEmpty(user.getLeaderCode())
                && StringUtil.isEmpty(user.getLeaderName())
                && StringUtil.isEmpty(user.getEmail())
                && StringUtil.isEmpty(user.getMobile())
                && StringUtil.isEmpty(user.getSex())
                && StringUtil.isEmpty(user.getIdCard())
                && StringUtil.isEmpty(user.getExt1())
                && StringUtil.isEmpty(user.getExt2())
                && StringUtil.isEmpty(user.getExt3());
    }

    public static boolean checkUpdateImportExcelUserEmpty(UpdateImportExcelUser user) {
        return StringUtil.isEmpty(user.getOrgCode())
                && StringUtil.isEmpty(user.getOrgNamePath())
                && StringUtil.isEmpty(user.getPositionCategory())
                && StringUtil.isEmpty(user.getPositionCode())
                && StringUtil.isEmpty(user.getPositionName())
                && StringUtil.isEmpty(user.getCode())
                && StringUtil.isEmpty(user.getName())
                && StringUtil.isEmpty(user.getLoginName())
                && StringUtil.isEmpty(user.getLeaderCode())
                && StringUtil.isEmpty(user.getLeaderName())
                && StringUtil.isEmpty(user.getEmail())
                && StringUtil.isEmpty(user.getMobile())
                && StringUtil.isEmpty(user.getSex())
                && StringUtil.isEmpty(user.getIdCard())
                && StringUtil.isEmpty(user.getStatus())
                && StringUtil.isEmpty(user.getPwd())
                && StringUtil.isEmpty(user.getExt1())
                && StringUtil.isEmpty(user.getExt2())
                && StringUtil.isEmpty(user.getExt3());
    }
}
