package com.purchase.uc.base;

import com.qgutech.qgyun.framework.common.result.JsonResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;

/**
 * 课程 Controller 层服务统一异常处理
 *
 * @since TangFD@HF 2019/7/23.
 */
@Slf4j
@RestControllerAdvice
public class UcExceptionHandler {

    @ExceptionHandler(Exception.class)
    public JsonResult<Object> exception(HttpServletRequest request, Exception exception) {
        log.error(exception.getMessage(), exception);
        return new JsonResult<>(false, "系统异常", exception.getMessage());
    }

    @ExceptionHandler(UcException.class)
    public JsonResult<Object> stuException(HttpServletRequest request, UcException exception) {
        log.error(exception.getMessage(), exception);
        UcErrorCode errorCode = exception.getErrorCode();
        return new JsonResult(false, errorCode.getText(), exception.getMessage(), (Object)null);
    }
}
