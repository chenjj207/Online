package com.purchase.uc.controller;

import com.purchase.uc.service.PositionService;
import com.purchase.uc.service.UserService;
import com.qgutech.qgyun.dev.common.model.vo.BlendTreeNode;
import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.model.Position;
import com.purchase.uc.model.User;
import com.purchase.uc.model.vo.PositionSearch;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Position接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/position")
@Api(description = "岗位管理", tags = {"/position/*", "position"})
public class PositionController {

    @Resource
    private PositionService positionService;
    @Resource
    private UserService userService;

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "根据id获取对应试题")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true)
    )
    public JsonResult<Position> get(@PathVariable(value = "id") @Check String id) {
        Position position = positionService.get(id);
        return new JsonResult<>(true, "查询成功", position);
    }

    @RequestMapping(value = "/search", method = RequestMethod.POST)
    @ApiOperation(value = "获取分页")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "岗位名称", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "code", value = "岗位编码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "categoryId", value = "岗位类别", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<Position>> search(@RequestBody PositionSearch position) {
        Page<Position> page = positionService.search(position, position.getPage());
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), page);
    }

    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    @ApiOperation(value = "新增岗位", nickname = "addPosition")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "岗位名称", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "code", value = "岗位编码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "categoryId", value = "岗位类别", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "id", dataType = "String", paramType = "query")
    })
    public JsonResult<String> addPosition(@ParamHide Position position) {
        if (StringUtils.isNotBlank(position.getCode())) {
            boolean exist = positionService.existByCode(position.getCode());
            if (exist) {
                return new JsonResult<>(false, UcI18nConstants.UC_CODE_DUPLICATE.getName());
            }
        }

        positionService.insert(position);
        return new JsonResult<>(true, UcI18nConstants.UC_ADD_SUCCESS.getName());
    }

    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    @ApiOperation(value = "编辑岗位", nickname = "updPosition")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "岗位名称", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "code", value = "岗位编码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "categoryId", value = "岗位类别", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult<String> editPosition(@ParamHide @Check(field = {"id"}) Position position) {
        if (StringUtils.isNotBlank(position.getCode()) && StringUtils.isNotBlank(position.getId())) {
            Position old = positionService.get(position.getId());
            if (!position.getCode().equals(old.getCode())) {
                boolean exist = positionService.existByCode(position.getCode());
                if (exist) {
                    return new JsonResult<>(false, UcI18nConstants.UC_CODE_DUPLICATE.getName());
                }
            }
        }

        positionService.update(position);
        return new JsonResult<>(true, UcI18nConstants.UC_EDIT_SUCCESS.getName());
    }

    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    @ApiOperation(value = "删除岗位", nickname = "delPosition")
    public JsonResult<String> batchDelete(@ApiParam(value = "数据源Id", required = true)
                                          @RequestBody List<String> ids) {
        List<User> users = userService.listByPositionIds(ids);
        // 没有关联到岗位的人时
        if (CollectionUtils.isEmpty(users)) {
            positionService.batchDelete(ids);
            return new JsonResult<>(true, UcI18nConstants.UC_DELETE_SUCCESS.getName());
        }

        Set<String> hasReferIds = new HashSet<>();
        for (User user : users) {
            hasReferIds.add(user.getPositionId());
        }

        ids.removeAll(hasReferIds);
        if (ids.size() > 0) {
            positionService.batchDelete(ids);
            return new JsonResult<>(true, UcI18nConstants.UC_DELETE_SUCCESS.getName(), "关联人员的未被删除");
        }

        return new JsonResult<>(false, UcI18nConstants.UC_HAS_POS_USER.getName(), "岗位关联人员");
    }

    @RequestMapping(value = "/getTree", method = RequestMethod.POST)
    @ApiOperation(value = "根据职位分类及职位树")
    public JsonResult<BlendTreeNode> getCategoryAndPositionTree() {
        BlendTreeNode rootNode = positionService.getCategoryAndPositionTree(ContextHandler.getUserId());
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), rootNode);
    }
}
