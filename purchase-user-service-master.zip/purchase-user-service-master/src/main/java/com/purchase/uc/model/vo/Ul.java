package com.purchase.uc.model.vo;

import lombok.Data;
import lombok.ToString;

/**
 * UserLogin -> Ul
 * 用户登录缓存
 */
@Data
@ToString
public class Ul {
    /**
     * 人员ID
     */
    private String uId;

    /**
     * 密码
     */
    private String pwd;

    /**
     * 状态
     */
    private String status;

    public boolean statusEquals(String state) {
        return this.status.equals(state);
    }

    public Ul() {
    }

    public Ul(String uId, String pwd, String status) {
        this.uId = uId;
        this.pwd = pwd;
        this.status = status;
    }
}
