package com.purchase.uc.service;

import cn.hutool.core.util.RandomUtil;
import com.alibaba.excel.EasyExcelFactory;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.metadata.Sheet;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.nacos.common.util.Md5Utils;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.purchase.model.Customer;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcException;
import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.client.CustFeignClient;
import com.purchase.uc.client.MsgClient;
import com.purchase.uc.client.dto.TriggerMsgRequest;
import com.purchase.uc.mapper.CompanyMapper;
import com.purchase.uc.mapper.SupplierMapper;
import com.purchase.uc.mapper.UserMapper;
import com.purchase.uc.model.Org;
import com.purchase.uc.model.Supplier;
import com.purchase.uc.model.User;
import com.purchase.uc.model.UserRoleRel;
import com.purchase.uc.model.dto.SupplierAuditDTO;
import com.purchase.uc.model.vo.SupplierExcelVO;
import com.purchase.uc.model.vo.SupplierList;
import com.purchase.uc.utils.CompoentUtil;
import com.qgutech.qgyun.dev.client.cs.model.LoginSetting;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import io.swagger.models.auth.In;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.purchase.uc.model.User.*;

/**
 * 供应商管理相关服务接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
public class SupplierService extends BaseServiceImpl<Supplier> {

    private Logger logger = LoggerFactory.getLogger(SupplierService.class);

    @Resource
    private SupplierMapper supplierMapper;
    @Resource
    private UserService userService;
    @Resource
    private CompanyService companyService;
    @Resource
    private RoleService roleService;
    @Resource
    private UserRoleRelService userRoleRelService;
    @Autowired
    AliSmsService aliSmsService;
    @Resource
    private UserMapper userMapper;

    @Resource
    private CompanyMapper companyMapper;

    @Value("${app.ali.sms.code.supplierOpen}")
    String supplierOpen;
    @Resource
    MsgClient msgClient;

    public List<Supplier> listAll() {
        return supplierMapper.selectAll();
    }

    @Override
    @Transactional(readOnly = true, rollbackFor = Exception.class)
    public Supplier get(String id) {
        Supplier supplier = super.get(id);
        return supplier;
    }

    /**
     * 该方法用于供应商保存
     *
     * @param supplier 供应商
     * @return 供应商ID
     */
    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public String insert(Supplier supplier) {
        if (supplier == null) {
            throw new IllegalArgumentException("supplier is null when insert!");
        }

        if (StringUtils.isBlank(supplier.getId())) {
            String id = IDUtils.getUUID19();
            supplier.setId(id);
        }

        String supplierId = super.insert(supplier);
        return supplierId;
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void update(Supplier supplier) {
        if (supplier == null) {
            throw new IllegalArgumentException("supplier is null when update!");
        }
        super.update(supplier);
    }

    /**
     * 根据供应商id，获取对象map
     *
     * @param ids 主键集合
     * @return 对象map
     */
    @Transactional(readOnly = true)
    public Map<String, Supplier> mapSupplierByIds(Collection<String> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return Maps.newHashMap();
        }
        Supplier supplierReq = new Supplier();
        supplierReq.setIds(new ArrayList<>(ids));
        List<Supplier> list = supplierMapper.search(supplierReq);
        if (CollectionUtils.isEmpty(list)) {
            return Maps.newHashMap();
        }

        return list.stream().collect(Collectors.toMap(Supplier::getId, s -> s));
    }

    /**
     * 获取所有供应商
     *
     * @param supplier 条件参数
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public List<Supplier> listByCondition(Supplier supplier) {
        CheckFlow.start(UcErrorCode.EMPTY_PARAM).isNotNull(supplier);
        return supplierMapper.search(supplier);
    }

    /**
     * 根据条件，获取分页列表
     *
     * @param supplier 条件
     * @param page     分页对象
     * @return 分页列表
     */
    @Transactional(readOnly = true)
    public Page<Supplier> search(Supplier supplier, Page<Supplier> page) {
        String companyShortName = ContextHandler.getString("companyShortName");
        if (StringUtils.isNotEmpty(companyShortName)){
            if (!StringUtils.equals(companyShortName, "上海供应链公司") && !StringUtils.equals(companyShortName, "众业达集团")){
                supplier.setShortName(companyShortName);
            }
        }
        CheckFlow.start(UcErrorCode.EMPTY_PARAM).isNotNull(supplier);
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<Supplier> list = supplierMapper.search(supplier);
        page = new Page<>(list);
        return page;
    }

    public Supplier listByMemberAndCust(Integer custId, Integer memberId) {
        Supplier query = new Supplier();
        query.setCustId(custId);
        query.setMemberId(memberId);
        List<Supplier> suppliers = supplierMapper.select(query);
        if (CollectionUtils.isEmpty(suppliers)) {
            throw new UcException(UcErrorCode.SUPPLIER_NOT_EXIST);
        }
        return suppliers.get(0);
    }


    /**
     * 添加
     *
     * @param supplier 参数
     * @return 新增对象
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Supplier add(Supplier supplier) {
        if (StringUtils.isEmpty(ContextHandler.getCorpCode())) {
            ContextHandler.setCorpCode("default");
        }
        CheckFlow.start(UcErrorCode.EMPTY_PARAM).isNotNull(supplier).isNotEmpty(supplier.getCode()).isNotEmpty(supplier.getName());
        //兼容处理
        if (StringUtils.equals(supplier.getType(), UcConstants.SCM_ADD)) {
            CheckFlow.start(UcErrorCode.EMPTY_PARAM).isNotEmpty(supplier.getComBm()).isNotEmpty(supplier.getShortName());
        }
        if (supplier.getMemberId() != null) {
            Supplier supplierReq = new Supplier();
            supplierReq.setMemberId(supplier.getMemberId());
            List<Supplier> list = supplierMapper.search(supplierReq);
            if (CollectionUtils.isNotEmpty(list)) {
                throw new UcException(UcErrorCode.SUPPLIER_EXIST);
            }
        }
        //校验手机
        Supplier supplierReq = new Supplier();
        supplierReq.setCode(supplier.getCode());
        List<Supplier> list = supplierMapper.search(supplierReq);
        if (CollectionUtils.isNotEmpty(list)) {
            throw new UcException(UcErrorCode.MOBILE_EXIST);
        }
        if (StringUtils.equals(supplier.getType(), UcConstants.SUPPLIER_TYPE_BACKGROUND_ADD)
                || StringUtils.equals(supplier.getType(), UcConstants.ASSOCIATE_PROTOCOL)
                || StringUtils.equals(supplier.getType(), UcConstants.SCM_ADD)) {
            //后台新增 或者 产线协议 或者 SCM创建
            supplier.setPassword(RandomUtil.randomString(6));
            supplier.setAccountStatus(supplier.getAccountStatus() != null ? supplier.getAccountStatus() : UcConstants.SUPPLIER_ACCOUNT_STATUS_ENABLE);
            supplier.setStatus(UcConstants.SUPPLIER_STATUS_PASS);
            supplier.setDataType(UcConstants.UNITE);
            supplier.setAuditTime(LocalDateTime.now());
            supplier.setUpdatedAt(LocalDateTime.now());
            supplier.setCorpCode("default");
            String id = super.insert(supplier);
            supplier.setId(id);
            createdUser(supplier);
            if (supplier.isSend()) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("phone", supplier.getCode());
                jsonObject.put("pwd", supplier.getPassword());
                SendSmsResponse response = aliSmsService.send(supplierOpen, jsonObject, supplier.getCode());
                if (!"OK".equals(response.getCode())) {
                    logger.error("send captcha error:  " + response.getMessage());
                    throw new UcException(UcErrorCode.ERROR_SEND_MSG);
                }
            }
        } else if (StringUtils.equals(supplier.getType(), UcConstants.SUPPLIER_TYPE_SUPPLIER_APPLY)) {
            //供应商申请
            supplier.setStatus(UcConstants.SUPPLIER_STATUS_WAIT_AUDIT);
            supplier.setDataType(UcConstants.UNITE);
            supplier.setCreatedAt(LocalDateTime.now());
            supplier.setCorpCode("default");
            String id = super.insert(supplier);
            supplier.setId(id);
        } else {
            //异常
            throw new UcException(UcErrorCode.ERROR_SUPPLIER_TYPE);
        }
        return supplier;
    }

    /**
     * 编辑
     *
     * @param supplier 参数
     * @return 编辑对象
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Supplier edit(Supplier supplier) {
        if (StringUtils.isEmpty(ContextHandler.getCorpCode())) {
            ContextHandler.setCorpCode("default");
        }
        // 检查供应商是否存在
        Supplier supplierOld = new Supplier();
        supplierOld.setId(supplier.getId());
        List<Supplier> search = supplierMapper.search(supplierOld);
        if (CollectionUtils.isEmpty(search)) {
            throw new UcException(UcErrorCode.SUPPLIER_NOT_EXIST);
        } else {
            supplierOld = search.get(0);
        }
        CheckFlow.start(UcErrorCode.EMPTY_PARAM).isNotNull(supplier).isNotEmpty(supplier.getCode()).isNotEmpty(supplier.getName()).isNotEmpty(supplier.getComBm()).isNotEmpty(supplier.getShortName());
        if (StringUtils.equals(supplier.getType(), UcConstants.SUPPLIER_TYPE_BACKGROUND_ADD) || StringUtils.equals(supplier.getType(), UcConstants.ASSOCIATE_PROTOCOL) || StringUtils.equals(supplier.getType(), UcConstants.SCM_ADD)) {
            //后台新增 或者 产线协议 或者 SCM创建
            // 获取旧手机号的用户数据
            User userWithOldCode = userMapper.searchAllByLoginName(supplierOld.getCode(), ContextHandler.getCorpCode());
            // 检查手机号是否发生变化
            if (!supplierOld.getCode().equals(supplier.getCode())) {
                // 检查新手机号是否已存在
                User UserWithNewCode = userMapper.searchAllByLoginName(supplier.getCode(), ContextHandler.getCorpCode());
                if (UserWithNewCode != null) {
                    throw new UcException(UcErrorCode.MOBILE_EXIST);
                }
                // 更新用户的手机号
                userWithOldCode.setCode(supplier.getCode());
                userWithOldCode.setLoginName(supplier.getCode());
                userWithOldCode.setMobile(supplier.getCode());
            }
            userWithOldCode.setStatus(UcConstants.SUPPLIER_ACCOUNT_STATUS_ENABLE.equals(supplier.getAccountStatus()) ? UcConstants.STATUS_ENABLED : UcConstants.STATUS_DISABLED);
//            userWithOldCode.setCategory(supplier.getCategory());
            userWithOldCode.setName(supplier.getName());
            userWithOldCode.setCompanyId(supplier.getComBm());
            userWithOldCode.setCompanyName(supplier.getShortName());
            if (StringUtils.equals(supplier.getShortName(), "上海供应链公司")){
                userWithOldCode.setDataType(UcConstants.USER_DATA_TYPE_SUPPLIER);
            }else {
                userWithOldCode.setDataType(UcConstants.BRANCH_SUPPLIER);
            }
            //设置角色,国内 海外
            String roleCode = "";
            if (supplier.getCategory().equals(UcConstants.CN)) {
                roleCode = "001";
            } else if (supplier.getCategory().equals(UcConstants.FW)) {
                roleCode = "007";
            }
            String roleId = roleService.getRoleIdByCode(roleCode);
            if (StringUtils.isNotEmpty(roleId)) {
                userWithOldCode.setRoleIds(Collections.singletonList(roleId));
            }
            userMapper.updateUser(userWithOldCode);
            userService.putUserToRedis(Arrays.asList(userWithOldCode.getId()));
//            userService.updateUserAndRole(userWithOldCode);
            supplier.setAccountStatus(supplier.getAccountStatus() != null ? supplier.getAccountStatus() : UcConstants.SUPPLIER_ACCOUNT_STATUS_ENABLE);
            supplier.setUpdatedAt(LocalDateTime.now());
            super.update(supplier);
        } else {
            //异常
            throw new UcException(UcErrorCode.ERROR_SUPPLIER_TYPE);
        }
        return supplier;
    }

    /**
     * 审核通过
     *
     * @param supplierAuditDTO
     * @return
     */
    @Transactional
    public Boolean audit(SupplierAuditDTO supplierAuditDTO) {
        CheckFlow.start(UcErrorCode.EMPTY_PARAM).isNotNull(supplierAuditDTO).isNotEmpty(supplierAuditDTO.getId());
        Supplier supplierReq = new Supplier();
        supplierReq.setId(supplierAuditDTO.getId());
        List<Supplier> suppliers = supplierMapper.search(supplierReq);
        if (CollectionUtils.isEmpty(suppliers)) {
            throw new UcException(UcErrorCode.SUPPLIER_NOT_EXIST);
        }
        Supplier supplier = suppliers.get(0);
        if (!supplier.getStatus().equalsIgnoreCase(UcConstants.SUPPLIER_STATUS_WAIT_AUDIT)) {
            throw new UcException(UcErrorCode.ERROR_SUPPLIER_STATUS);
        }
        supplier.setId(supplierReq.getId());
        supplier.setPassword(RandomUtil.randomString(6));
        supplier.setAuditTime(LocalDateTime.now());
        supplier.setUpdatedAt(LocalDateTime.now());
        supplier.setStatus(UcConstants.SUPPLIER_STATUS_PASS);
        supplier.setAccountStatus(UcConstants.SUPPLIER_ACCOUNT_STATUS_ENABLE);
        int count = supplierMapper.updateByPrimaryKey(supplier);
        if (count == 1) {
            createdUser(supplier);
        }

        if (supplierAuditDTO.isSend()) {
//            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("phone", supplier.getCode());
//            jsonObject.put("pwd", supplier.getPassword());
//            SendSmsResponse response = aliSmsService.send(supplierOpen, jsonObject, supplier.getCode());
//            if (!"OK".equals(response.getCode())) {
//                logger.error("send captcha error:  "+response.getMessage());
//                throw new UcException(UcErrorCode.ERROR_SEND_MSG);
//            }

            //供应商审核埋点
            TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
            triggerMsgRequest.setBusiness("supplier");
            triggerMsgRequest.setScene("supplierApplyPass");

            JSONObject smsParam = new JSONObject();
            smsParam.put("phone", supplier.getCode());
            smsParam.put("pwd", supplier.getPassword());

            triggerMsgRequest.setSmsParam(smsParam);
            msgClient.triggerMsg(triggerMsgRequest);
        }
        return true;
    }

    /**
     * 新增用户
     *
     * @param supplier
     */
    private void createdUser(Supplier supplier) {
        // 新增用户
        if (StringUtils.isEmpty(ContextHandler.getCorpCode())) {
            ContextHandler.setCorpCode("default");
        }
        User user = new User();
        user.setSupplierId(supplier.getId());
        user.setLoginName(supplier.getCode());
        user.setName(supplier.getName());
        String password = supplier.getPassword();
        user.setInitPassword(password);
        user.setPwd(StringUtils.isEmpty(password) ? null : Md5Utils.getMD5(password.getBytes()));
        user.setCode(supplier.getCode());
        user.setMobile(supplier.getCode());
        user.setStatus(UcConstants.SUPPLIER_ACCOUNT_STATUS_ENABLE.equals(supplier.getAccountStatus()) ? UcConstants.STATUS_ENABLED : UcConstants.STATUS_DISABLED);
//        user.setCategory(supplier.getCategory());
        if (StringUtils.equals(supplier.getType(), UcConstants.SCM_ADD)) {
            if (StringUtils.equals(supplier.getShortName(), "上海供应链公司")){
                user.setDataType(UcConstants.USER_DATA_TYPE_SUPPLIER);
            }else {
                user.setDataType(UcConstants.BRANCH_SUPPLIER);
            }
            user.setCompanyId(supplier.getComBm());
            user.setCompanyName(supplier.getShortName());
        } else if (StringUtils.equals(supplier.getType(), UcConstants.ASSOCIATE_PROTOCOL)){
            //如果是联营协议
            if (StringUtils.equals(supplier.getShortName(), "上海供应链公司")){
                user.setDataType(UcConstants.USER_DATA_TYPE_SUPPLIER);
                user.setCompanyId("0214");
                user.setCompanyName(supplier.getShortName());
            }else {
                user.setDataType(UcConstants.BRANCH_SUPPLIER);
                user.setCompanyId(companyMapper.selectComBmByShortName(supplier.getShortName()));
                user.setCompanyName(supplier.getShortName());
            }
        }else {
            user.setDataType(UcConstants.USER_DATA_TYPE_SUPPLIER);
            user.setCompanyId("0214");
            user.setCompanyName("上海供应链公司");
        }

        if (StringUtils.isEmpty(ContextHandler.getUserId())) {
            user.setCreatedBy(supplier.getCreatedBy());
            user.setUpdatedBy(supplier.getUpdatedBy());
        }

        //设置角色,国内 海外
        String roleCode = "";
        if (supplier.getCategory().equals(UcConstants.CN)) {
            roleCode = "001";
        } else if (supplier.getCategory().equals(UcConstants.FW)) {
            roleCode = "007";
        }
        String roleId = roleService.getRoleIdByCode(roleCode);
        if (StringUtils.isNotEmpty(roleId)) {
            user.setRoleIds(Collections.singletonList(roleId));
        }
        userService.saveUser(user);
    }

    /**
     * 启停用
     *
     * @param supplier 参数
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void enableOrDisable(Supplier supplier) {
        if (StringUtils.isEmpty(ContextHandler.getCorpCode())) {
            ContextHandler.setCorpCode("default");
        }
        CheckFlow.start(UcErrorCode.EMPTY_PARAM).isNotNull(supplier).isNotEmpty(supplier.getId()).isNotEmpty(supplier.getAccountStatus());
        String accountStatus = supplier.getAccountStatus();
        if (!StringUtils.equalsAny(accountStatus, UcConstants.SUPPLIER_ACCOUNT_STATUS_ENABLE, UcConstants.SUPPLIER_ACCOUNT_STATUS_DISABLE)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM);
        }
        Supplier dbSupplier = getById(supplier.getId(), Supplier.ID, Supplier.ACCOUNT_STATUS);
        if (null == dbSupplier) {
            throw new UcException(UcErrorCode.DATA_EMPTY);
        }
        if (accountStatus.equals(dbSupplier.getAccountStatus())) {
            throw new UcException(UcErrorCode.STATUS_UPDATE_ERROR);
        }
        update(dbSupplier.setAccountStatus(accountStatus));
        // 同步启停用户表
        User user = new User();
        user.setSupplierId(dbSupplier.getId());
//        user.setDataType(UcConstants.USER_DATA_TYPE_SUPPLIER);
        user = userService.getByCondition(user, User.ID);
        if (null == user) {
            throw new UcException(UcErrorCode.USER_EMPTY);
        }
        userService.updateStatus(Lists.newArrayList(user.getId()),
                UcConstants.SUPPLIER_ACCOUNT_STATUS_ENABLE.equals(accountStatus) ? UcConstants.STATUS_ENABLED : UcConstants.STATUS_DISABLED);
        String roleId = roleService.getRoleIdByCode("001");
        try {
            UserRoleRel userRoleRel = new UserRoleRel();
            userRoleRel.setRoleId(roleId);
            userRoleRel.setUserIds(Collections.singletonList(user.getId()));
            userRoleRelService.delUserRoleRel(userRoleRel);
        } catch (Exception e) {
            e.printStackTrace();
        }
        userRoleRelService.addUserRoleRel(user.getId(), Collections.singletonList(roleId));
    }

    public List<Map<String, Object>> count(Supplier supplier) {
        List<Map<String, Object>> list = new ArrayList<>(4);
        Map<String, Object> map = new HashMap<>(3);
        supplier.setStatus(null);
        map.put("status", "ALL");
        map.put("statusName", "全部");
        map.put("count", supplierMapper.countByStatus(supplier));
        list.add(map);
        map = new HashMap<>(3);
        supplier.setStatus("WAIT_AUDIT");
        map.put("status", "WAIT_AUDIT");
        map.put("statusName", "待审核");
        map.put("count", supplierMapper.countByStatus(supplier));
        list.add(map);
        map = new HashMap<>(3);
        supplier.setStatus("NO_PASS");
        map.put("status", "NO_PASS");
        map.put("statusName", "未通过");
        map.put("count", supplierMapper.countByStatus(supplier));
        list.add(map);
        map = new HashMap<>(3);
        supplier.setStatus("PASS");
        map.put("status", "PASS");
        map.put("statusName", "已通过");
        map.put("count", supplierMapper.countByStatus(supplier));
        list.add(map);
        return list;
    }

    public List<Map<String, Object>> scmCount(Supplier supplier) {
        String companyShortName = ContextHandler.getString("companyShortName");
        if (StringUtils.isNotEmpty(companyShortName)){
            if (!StringUtils.equals(companyShortName, "上海供应链公司") && !StringUtils.equals(companyShortName, "众业达集团")){
                supplier.setShortName(companyShortName);
            }
        }
        List<Map<String, Object>> list = new ArrayList<>(4);
        Map<String, Object> map = new HashMap<>(3);
        supplier.setAccountStatus("ENABLE");
        map.put("status", "ENABLE");
        map.put("statusName", "启用");
        map.put("count", supplierMapper.countByStatus(supplier));
        list.add(map);
        map = new HashMap<>(3);
        supplier.setAccountStatus("DISABLE");
        map.put("status", "DISABLE");
        map.put("statusName", "停用");
        map.put("count", supplierMapper.countByStatus(supplier));
        list.add(map);
        return list;
    }

    public List<SupplierList> supplierList(String type) {
        return supplierMapper.supplierList(type);
    }

    /**
     * 导出供应商列表 todo 单元格宽度后续优化
     *
     * @param response
     * @param supplier
     */
    public void exportExcel(HttpServletResponse response, Supplier supplier) {
        // 将list中的数据拷贝到excelList中
        List<Supplier> list = supplierMapper.search(supplier);
        List<SupplierExcelVO> excelList = list.stream()
                .map(item -> {
                    SupplierExcelVO excelItem = new SupplierExcelVO();
                    BeanUtils.copyProperties(item, excelItem);
                    excelItem.setRegion(item);
                    excelItem.setCreatedAt(item.getCreatedAt().format(UcConstants.TIME_FORMATTER));
                    excelItem.setUpdatedAt(item.getUpdatedAt().format(UcConstants.TIME_FORMATTER));
                    excelItem.setAccountStatus(UcConstants.SUPPLIER_ACCOUNT_STATUS_ENABLE.equals(item.getAccountStatus()) ? "启用" : "停用");
                    return excelItem;
                })
                .collect(Collectors.toList());
        // 导出Excel
        CompoentUtil.writeExcelResponse("供应商列表", response, servletOutputStream -> {
            ExcelWriter writer = EasyExcelFactory.getWriter(servletOutputStream);
            Sheet sheet = new Sheet(1, 0, SupplierExcelVO.class);
            sheet.setSheetName("供应商列表");
            writer.write(excelList, sheet);
            writer.finish();
        }, new RuntimeException("供应商列表导出异常"));
    }

    /**
     * 重置密码
     *
     * @param supplier
     * @return
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String resetPwd(Supplier supplier) {
        //生成密码
        String password = RandomUtil.randomString(6);
        CheckFlow.start(UcErrorCode.EMPTY_PARAM).isNotNull(supplier).isNotEmpty(supplier.getUserId()).isNotEmpty(supplier.getId());

        User user = new User();
        user.setId(supplier.getUserId());
        user.setPwd(StringUtils.isEmpty(password) ? null : Md5Utils.getMD5(password.getBytes()));
        user.setInitPassword(password);
        user.setCorpCode("default");
        userMapper.updateUser(user);
        userService.putUserToRedis(Arrays.asList(user.getId()));
        userService.resetPwdSendMessage(Arrays.asList(user.getId()), password);

        Supplier supplierNewPwd = supplierMapper.selectByPrimaryKey(supplier);
        supplierNewPwd.setPassword(password);
        super.update(supplierNewPwd);
        return password;
    }
}
