package com.purchase.uc.base;

import lombok.Data;

/**
 * @since TangFD@HF 2019-05-27
 */
@Data
public class UcException extends RuntimeException {
    private UcErrorCode errorCode;

    public UcException(UcErrorCode errorCode) {
        this(errorCode, errorCode.getText());
    }

    public UcException(UcErrorCode errorCode, String message) {
        this(errorCode, message, null);
    }

    public UcException(UcErrorCode errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    public UcException(UcErrorCode errorCode, Throwable cause) {
        this(errorCode, null, cause);
    }
}
