package com.purchase.uc.client.wx.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "企业微信消息返回基类")
public class MsgReturnVO implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty("返回码（0=成功，其他=失败）")
    private Integer errcode;

    @ApiModelProperty("对返回码的文本描述内容")
    private String errmsg;
}
