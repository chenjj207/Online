package com.purchase.uc.model;

import com.qgutech.qgyun.dev.common.model.CommonCategory;
import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;

/**
 * 公共树实体
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年05月22日10:44:14
 */
@Getter
@Setter
@ToString
@ApiModel(value = "Category", description = "公共树")
@Table(name = "t_uc_category")
public class Category extends CommonCategory {

}
