package com.purchase.uc.service;

import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.mapper.UserDetailMapper;
import com.purchase.uc.model.UserDetail;
import com.purchase.uc.base.UcException;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * todo: 请编写此处添加注释，注名此接口的作用
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
public class UserDetailService extends BaseServiceImpl<UserDetail> {

    @Resource
    private UserDetailMapper userDetailMapper;

    public List<UserDetail> listAll() {
        return userDetailMapper.selectAll();
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, UserDetail> getUserIdAndDetailMap(List<String> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        Example example = new Example(UserDetail.class);
        example.createCriteria()
                .andEqualTo(UserDetail.CORP_CODE, ContextHandler.getCorpCode())
                .andIn(UserDetail.USER_ID, userIds);
        List<UserDetail> userDetails = userDetailMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(userDetails)) {
            return new HashMap<>(0);
        }

        Map<String, UserDetail> userDetailMap = new HashMap<>(userDetails.size());
        userDetails.forEach(detail -> userDetailMap.put(detail.getUserId(), detail));
        return userDetailMap;
    }

    private Map<String, String> getUserIdAndIdMap(List<String> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        Example example = new Example(UserDetail.class);
        example.selectProperties(UserDetail.USER_ID, UserDetail.ID).createCriteria()
                .andEqualTo(UserDetail.CORP_CODE, ContextHandler.getCorpCode())
                .andIn(UserDetail.USER_ID, userIds);
        List<UserDetail> userDetails = userDetailMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(userDetails)) {
            return new HashMap<>(0);
        }

        Map<String, String> userIdAndIdMap = new HashMap<>(userDetails.size());
        userDetails.forEach(detail -> userIdAndIdMap.put(detail.getUserId(), detail.getId()));
        return userIdAndIdMap;
    }

    /**
     * 根据userId批量更新detail信息
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void batchUpdateByUserId(List<UserDetail> userDetails) {
        if (CollectionUtils.isEmpty(userDetails)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userDetails not be empty!");
        }

        List<String> userIds = new ArrayList<>(userDetails.size());
        userDetails.forEach(detail -> userIds.add(detail.getUserId()));
        Map<String, String> userIdAndIdMap = getUserIdAndIdMap(userIds);
        if (MapUtils.isEmpty(userIdAndIdMap)) {
            return;
        }

        userDetails.forEach(detail -> detail.setId(userIdAndIdMap.get(detail.getUserId())));
        batchUpdate(userDetails);
    }

    /**
     * 根据用户Id更新用户详情
     *
     * @param detail 用户详情
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void updateDetailByUserId(UserDetail detail) {
        if (detail == null || StringUtils.isEmpty(detail.getUserId())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        userDetailMapper.updateDetail(detail);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String getUserIdByOpenId(String openId, String corpCode) {
        if (StringUtils.isEmpty(openId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "openId not be empty!");
        }
        Example example = new Example(UserDetail.class);
        example.selectProperties(UserDetail.WECHAT, UserDetail.USER_ID, UserDetail.ID).createCriteria()
                .andEqualTo(UserDetail.CORP_CODE, corpCode)
                .andEqualTo(UserDetail.WECHAT, openId);
        List<UserDetail> userDetailList = userDetailMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(userDetailList) || userDetailList.size() > 1) {
            return null;
        }
        return null == userDetailList.get(0) ? "" : userDetailList.get(0).getUserId();
    }
}
