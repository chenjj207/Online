package com.purchase.uc.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Table;
import java.util.Date;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "UserDetail", description = "")
@Table(name = "t_uc_user_detail")
public class UserDetail extends BaseCorpModel {


    public static final String USER_ID = "userId";
    public static final String WECHAT = "wechat";
    /**
     * USER_ID
     */
    @ApiModelProperty(value = "USER_ID")
    private String userId;

    /**
     * 性别(MALE：男，FEMALE：女，SECRET：保密)
     */
    @ApiModelProperty(value = "性别(MALE：男，FEMALE：女，SECRET：保密)")
    private String sex;

    /**
     * 生日
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "生日")
    private Date birthday;

    /**
     * 最高学历/学位
     */
    @ApiModelProperty(value = "最高学历/学位")
    private String degree;

    /**
     * 专业
     */
    @ApiModelProperty(value = "专业")
    private String major;

    /**
     * 最后毕业学校
     */
    @ApiModelProperty(value = "最后毕业学校")
    private String school;

    /**
     * 政治面貌
     */
    @ApiModelProperty(value = "政治面貌")
    private String politics;

    /**
     * 国籍
     */
    @ApiModelProperty(value = "国籍")
    private String nationality;


    /**
     * 开始工作时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "开始工作时间")
    private Date startWorkDate;

    /**
     * 邮政编码
     */
    @ApiModelProperty(value = "邮政编码")
    private String zipCode;

    /**
     * 婚姻状况
     */
    @ApiModelProperty(value = "婚姻状况")
    private String marriage;

    /**
     * 入党时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "入党时间")
    private Date joinPartyDate;

    /**
     * 家庭电话
     */
    @ApiModelProperty(value = "家庭电话")
    private String familyTel;

    /**
     * 办公电话
     */
    @ApiModelProperty(value = "办公电话")
    private String officeTel;

    /**
     * 紧急联系信息
     */
    @ApiModelProperty(value = "紧急联系信息")
    private String emergencyContactTel;

    /**
     * QQ号码
     */
    @ApiModelProperty(value = "QQ号码")
    private String qq;

    /**
     * 微信号
     */
    @ApiModelProperty(value = "微信号")
    private String wechat;

    /**
     * 其它联系方式
     */
    @ApiModelProperty(value = "其它联系方式")
    private String otherContactInfo;

    /**
     * 出生地
     */
    @ApiModelProperty(value = "出生地")
    private String birthPlace;

    /**
     * 个人签名
     */
    @ApiModelProperty(value = "个人签名")
    private String signature;

    /**
     * 职业
     */
    @ApiModelProperty(value = "职业")
    private String profession;

    /**
     * 省
     */
    @ApiModelProperty(value = "省")
    private String province;

    /**
     * 市
     */
    @ApiModelProperty(value = "市")
    private String city;

    /**
     * 区
     */
    @ApiModelProperty(value = "区")
    private String area;

    /**
     * 详细地址
     */
    @ApiModelProperty(value = "详细地址")
    private String address;

    /**
     * 工作照片
     */
    @ApiModelProperty(value = "工作照片")
    private String workFaceId;

    /**
     * 身份证正面照片
     */
    @ApiModelProperty(value = "身份证正面照片")
    private String idCardFrontId;

    /**
     * 身份证反面照片
     */
    @ApiModelProperty(value = "身份证反面照片")
    private String idCardBackId;

    /**
     * 公司
     */
    @ApiModelProperty(value = "公司")
    private String company;

    /**
     * 公司地址
     */
    @ApiModelProperty(value = "公司地址")
    private String companyAddress;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 扩展字段1
     */
    @ApiModelProperty(value = "扩展字段1")
    private String ext1;

    /**
     * 扩展字段2
     */
    @ApiModelProperty(value = "扩展字段2")
    private String ext2;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext3;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext4;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext5;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext6;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext7;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext8;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext9;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext10;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext11;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext12;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext13;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext14;

    /**
     *
     */
    @ApiModelProperty(value = "")
    private String ext15;
}
