package com.purchase.uc.model.vo;

import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import lombok.Data;

import java.util.List;

/**
 * 人员条件参数实体类
 *
 * @since TangFD@HF 2019/7/31.
 */
@Data
public class UserParam {
    private String name;
    private String orgId;
    private String positionId;
    private String order;
    private List<String> statusList;
    private boolean includeChild;
    private int pageNum;
    private int pageSize;

    public <T> Page<T> getPage() {
        Page<T> page = new Page<>();
        page.setPageSize(pageSize);
        page.setPageNum(pageNum);
        return page;
    }
}