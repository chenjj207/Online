package com.purchase.uc.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;

/**
 * GroupCondition 动态群组条件
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "GroupCondition", description = "")
@Table(name = "t_uc_group_condition")
public class GroupCondition extends BaseCorpModel {

    public static final String GROUP_ID = "groupId";
    public static final String CONTEXT = "context";
    public static final String SHOW_ORDER = "showOrder";

    /**
     * 群组ID
     */
    @ApiModelProperty(value = "群组ID")
    private String groupId;

    /**
     * 条件对应的json值，每个条件存储一条数据
     */
    @ApiModelProperty(value = "条件对应的json值，每个条件存储一条数据")
    private String context;

    /**
     * 排序
     */
    @ApiModelProperty(value = "排序")
    private Float showOrder;

}
