package com.purchase.uc.utils;

import sun.misc.BASE64Encoder;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Random;

/**
 * 生成验证码工具类，base64字符串
 *
 * @author nm
 */
public class SecurityCodeUtils {
    private static String[] securityCodes = new String[]{"a", "b", "c", "d", "e",
            "f", "g", "h", "j", "k", "m", "n", "p", "q", "r", "s", "t", "u",
            "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H",
            "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V", "W",
            "X", "Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9"};

    private static BASE64Encoder encoder = new BASE64Encoder();

    public static String randomCode(int length) {
        StringBuilder builder = new StringBuilder();
        int size = securityCodes.length;
        for (int i = 0; i < length; i++) {
            double rdm = Math.random();
            int index = (int) (rdm * size);
            builder.append(securityCodes[index]);
        }
        return builder.toString();
    }

    /**
     * <p>生成验证码</p>
     */
    public static String securityCode(String code) throws IOException {
        int width = 60;
        int height = 26;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics g = image.getGraphics();
        g.setColor(randomColor(200, 250));
        g.fillRect(0, 0, width, height);
        Font mFont = new Font(null, Font.BOLD, 14);
        g.setFont(mFont);
        g.setColor(Color.BLACK);
        g.drawRect(0, 0, width - 1, height - 1);
        g.setColor(randomColor(160, 200));
        Random random = new Random();
        for (int i = 0; i < 155; i++) {
            int x2 = random.nextInt(width);
            int y2 = random.nextInt(height);
            int x3 = random.nextInt(12);
            int y3 = random.nextInt(12);
            g.drawLine(x2, y2, x2 + x3, y2 + y3);
        }
        g.setColor(new Color(20 + random.nextInt(110), 20 + random.nextInt(110), 20 + random.nextInt(110)));
        int lengtn = code.length();
        for (int i = 0; i < lengtn; i++) {
            String strRand = code.substring(i, i + 1);
            g.drawString(strRand, i * 13 + 5, 19);
        }
        g.dispose();
        ByteArrayOutputStream img = new ByteArrayOutputStream();
        try {
            img = new ByteArrayOutputStream();
            ImageIO.write(image, "JPEG", img);
            return "data:image/jpeg;base64," +
                    encoder.encodeBuffer(img.toByteArray()).trim();
        } catch (Exception e) {
            return null;
        } finally {
            img.close();
        }
    }

    private static Color randomColor(int fc, int bc) { // 给定范围获得随机颜色
        Random random = new Random();
        if (fc > 255) {
            fc = 255;
        }

        if (bc > 255) {
            bc = 255;
        }
        int r = fc + random.nextInt(bc - fc);
        int g = fc + random.nextInt(bc - fc);
        int b = fc + random.nextInt(bc - fc);
        return new Color(r, g, b);
    }
}
