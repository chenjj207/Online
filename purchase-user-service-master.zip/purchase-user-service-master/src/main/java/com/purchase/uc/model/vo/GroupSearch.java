package com.purchase.uc.model.vo;

import com.qgutech.qgyun.framework.common.context.ContextHandler;
import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * 群组分页查询条件
 */
@Getter
@Setter
@ToString
@ApiModel(value = "GroupSearch", description = "群组查询条件")
public class GroupSearch extends BaseCondition {

    private String userId;

    private List<String> categoryIdList;

    private String categoryId;

    private List<String> statusList;

    private List<Boolean> dynamicList;

    public String getCorpCode() {
        return ContextHandler.getCorpCode();
    }
}
