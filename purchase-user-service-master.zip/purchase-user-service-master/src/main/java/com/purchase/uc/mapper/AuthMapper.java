package com.purchase.uc.mapper;

import com.purchase.uc.model.Auth;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 * todo: 请编写此处添加注释，注名此接口的作用
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
public interface AuthMapper extends QguBaseMapper<Auth> {

}
