package com.purchase.uc.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.purchase.base.PageBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author zhangcheng
 * @since 2022-08-25
 */
@Accessors(chain = true)
@Getter
@Setter
@ToString
@ApiModel(value = "Supplier", description = "供应商")
@Table(name = "t_purchase_supplier")
@NoArgsConstructor
public class Supplier extends PageBean<Supplier> {
    public static final String MEMBER_ID = "memberId";
    public static final String CUST_ID = "custId";
    public static final String TYPE = "type";
    public static final String DATA_TYPE = "dataType";
    public static final String STATUS = "status";
    public static final String PASSWORD = "password";
    public static final String ACCOUNT_STATUS = "accountStatus";
    public static final String AUDIT_TIME = "auditTime";

    /**
     * 联营慧会员id
     */
    @ApiModelProperty(value = "联营慧会员id")
    private Integer memberId;


    /**
     * 客户id
     */
    @ApiModelProperty(value = "慧采商城客户id")
    private Integer custId;

    @ApiModelProperty(value = "联系人")
    private String contacts;

    @ApiModelProperty(value = "税号")
    private String identifyUmber;

    @ApiModelProperty(value = "省ID")
    private Integer provinceId;

    @ApiModelProperty(value = "省")
    private String provinceName;

    @ApiModelProperty(value = "市ID")
    private Integer cityId;

    @ApiModelProperty(value = "市")
    private String cityName;

    @ApiModelProperty(value = "区ID")
    private Integer countyId;

    @ApiModelProperty(value = "区")
    private String countyName;

    @ApiModelProperty(value = "街道ID")
    private Integer streetId;

    @ApiModelProperty(value = "街道")
    private String streetName;

    @ApiModelProperty(value = "详细地址")
    private String address;

    /**
     * 类型（SUPPLIER_APPLY: 供应商申请、BACKGROUND_ADD: 后台新增、 SCM_ADD：scm新增）
     */
    private String type;

    @ApiModelProperty(value = "类型(国内:CN,国外:FW)")
    private String category;

    /**
     * 供应商类型(UNITE:联营、SELF_SUPPORT:自营)
     */
    private String dataType;

    /**
     * 状态（WAIT_AUDIT: 待审核、NO_PASS: 未通过、PASS: 已通过）
     */
    private String status;

    /**
     * 初始密码
     */
    private String password;

    /**
     * 账号状态(ENABLE: 启用、DISABLE: 停用)
     */
    private String accountStatus;

    /**
     * 审核时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime;

    /**
     * 关键字
     */
    @Transient
    private String keywords;

    /**
     * 供应商名称
     */
    @Transient
    private String name;

    /**
     * ERP客户编码
     */
    @Transient
    private String erpCustBm;

    /**
     * 账号
     */
    @Transient
    private String code;

    /**
     * 是否发送短信通知
     */
    @Transient
    private boolean isSend;

    @Transient
    private List<String> ids;

    @Transient
    @ApiModelProperty(value = "创建时间-开始")
    private String createdAtBegin;

    @Transient
    @ApiModelProperty(value = "创建时间-结束")
    private String createdAtEnd;

    @Transient
    @ApiModelProperty(value = "分公司编码")
    private String comBm;

    @Transient
    @ApiModelProperty(value = "分公司简称")
    private String shortName;

    @Transient
    @ApiModelProperty(value = "用户ID")
    private String userId;

}
