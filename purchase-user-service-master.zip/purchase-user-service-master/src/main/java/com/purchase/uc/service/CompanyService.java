package com.purchase.uc.service;

import com.purchase.uc.mapper.CompanyMapper;
import com.purchase.uc.model.Company;
import com.purchase.uc.model.Org;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.qgutech.qgyun.framework.database.model.BaseCorpModel.CORP_CODE;
import static com.qgutech.qgyun.framework.database.model.BaseCorpTreeModel.P_ID;

/**
 * 分公司接口
 *
 * @author lwl
 */
@Service
public class CompanyService extends BaseServiceImpl<Company> {

    @Resource
    private CompanyMapper companyMapper;

    public List<Company> listAll() {
        return companyMapper.selectAll();
    }

    private Example genConditionExample(Company model) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        Integer companyId = model.getCompanyId();
        if (null != companyId) {
            criteria.andEqualTo(Company.COMPANY_ID, companyId);
        }

        String comBm = model.getComBm();
        if (StringUtils.isNotBlank(comBm)) {
            criteria.andEqualTo(Company.COM_BM, comBm);
        }

        String comName = model.getComName();
        if (StringUtils.isNotBlank(comName)) {
            criteria.andEqualTo(Company.COM_NAME, comName);
        }

        String shortName = model.getShortName();
        if (StringUtils.isNotBlank(shortName)) {
            criteria.andEqualTo(Company.SHORT_NAME, shortName);
        }


        return example;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> listIdsByExample(Company company) {
        Assert.notNull(company, "company can not be null");
        Example example = genConditionExample(company);
        example.selectProperties(Company.ID);
        List<Company> companyList = companyMapper.selectByExample(example);
        return CollectionUtils.isEmpty(companyList) ? new ArrayList<>(0) :
                companyList.stream().map(Company::getId).collect(Collectors.toList());
    }

    public String defaultCompanyId() {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(Company.COM_BM, "HCGYS");
        criteria.andEqualTo(Company.COM_NAME, "惠采供应商");
        List<Company> companyList = companyMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(companyList)) {
            return companyList.get(0).getComBm();
        }

        String id = IDUtils.getUUID19();
        Company company = new Company();
        company.setId(id);
        company.setComBm("HCGYS");
        company.setComName("惠采供应商");
        company.setShortName("惠采供应商");
        company.setCompanyId(99999999);
        insert(company);
        return "HCGYS";
    }
}
