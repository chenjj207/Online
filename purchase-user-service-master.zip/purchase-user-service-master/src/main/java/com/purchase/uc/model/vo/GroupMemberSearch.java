package com.purchase.uc.model.vo;

import com.qgutech.qgyun.framework.common.context.ContextHandler;
import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 群组分页查询条件
 */
@Getter
@Setter
@ToString
@ApiModel(value = "GroupMemberSearch", description = "群组成员查询条件")
public class GroupMemberSearch {

    /**
     * 群组ID
     */
    private String groupId;

    /**
     * 人员工号/姓名/用户名/手机
     */
    private String keywords;

    /**
     * 人员来源：APPOINT/DYNAMIC
     */
    private String source;

    public String getCorpCode() {
        return ContextHandler.getCorpCode();
    }

    public GroupMemberSearch() {
    }

    public GroupMemberSearch(String groupId, String keywords, String source) {
        this.groupId = groupId;
        this.keywords = keywords;
        this.source = source;
    }
}
