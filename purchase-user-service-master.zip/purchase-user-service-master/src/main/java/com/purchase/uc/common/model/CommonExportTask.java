package com.purchase.uc.common.model;

import com.purchase.uc.base.UcConstants;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import java.util.Date;

/**
 * 异步导出任务类
 *
 * @since TangFD@HF 2019-06-03
 */
@Getter
@Setter
@ToString
@ApiModel(value = "t_common_export_task", description = "异步导出任务类")
@Table(name = "t_common_export_task")
public class CommonExportTask extends BaseCorpModel {

    public static final String FILE_ID = "fileId";
    public static final String FUN_CODE = "funCode";
    public static final String EXPORT_TYPE = "exportType";
    public static final String STATUS = "status";
    public static final String FINISH_TIME = "finishTime";
    public static final String START_TIME = "startTime";

    /**
     * 功能编号
     */
    @ApiModelProperty(value = "功能编号")
    private String funCode;

    /**
     * 导出生成的文件Id
     */
    @ApiModelProperty(value = "导出生成的文件Id")
    private String fileId;

    /**
     * 导出类型
     */
    @ApiModelProperty(value = "导出类型")
    private String exportType;
    /**
     * 开始导出时间
     */
    @ApiModelProperty(value = "开始导出时间")
    private Date startTime;
    /**
     * 导出完成时间
     */
    @ApiModelProperty(value = "导出完成时间")
    private Date finishTime;
    /**
     * 状态
     */
    @ApiModelProperty(value = "状态")
    private String status;
    /**
     * 是否下载
     */
    @ApiModelProperty(value = "是否下载")
    private boolean download;

    public static CommonExportTask getInstance(String funCode, String exportType) {
        CommonExportTask exportTask = new CommonExportTask();
        exportTask.setStartTime(new Date());
        exportTask.setStatus(UcConstants.STATUS_RUNNING);
        exportTask.setExportType(exportType);
        exportTask.setFunCode(funCode);
        exportTask.setCorpCode(ContextHandler.getCorpCode());
        return exportTask;
    }
}
