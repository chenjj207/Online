package com.purchase.uc.service;

import com.purchase.uc.model.*;
import com.qgutech.qgyun.dev.common.model.vo.BlendTreeNode;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.qgutech.qgyun.dev.common.utils.CommonConstant;
import com.qgutech.qgyun.dev.common.utils.CommonUtils;
import com.qgutech.qgyun.dev.common.utils.TreeUtil;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcException;
import com.purchase.uc.mapper.GroupMapper;
import com.purchase.uc.model.vo.Gcp;
import com.purchase.uc.model.vo.GroupSearch;
import com.purchase.uc.model.vo.UserCache;
import com.purchase.uc.utils.UcRedisKeys;
import com.purchase.uc.utils.UcUtil;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.purchase.uc.model.Group.*;
import static com.qgutech.qgyun.framework.database.model.BaseCorpModel.CORP_CODE;
import static com.qgutech.qgyun.framework.database.model.BaseModel.ID;

/**
 * 群组管理相关服务接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
public class GroupService extends BaseServiceImpl<Group> {

    @Resource
    private GroupMapper groupMapper;
    @Resource
    private GroupConditionService groupConditionService;
    @Resource
    private CategoryService categoryService;
    @Resource
    private GroupMemberService groupMemberService;
    @Resource
    private RedisTemplate<String, Map<String, Group>> redisTemplate;
    @Resource
    private OrgService orgService;
    @Resource
    private PositionService positionService;
    @Resource
    private UseScopeService useScopeService;

    public List<Group> listAll() {
        return groupMapper.selectAll();
    }

    @Override
    @Transactional(readOnly = true, rollbackFor = Exception.class)
    public Group get(String id) {
        Group group = super.get(id);
        Map<String, String> namePathMap = categoryService.getNamePathMap(Collections.
                singletonList(group.getCategoryId()));
        if (null != namePathMap) {
            group.setCategoryNamePath(namePathMap.get(group.getCategoryId()));
        }

        if (group.getDynamic()) {
            List<GroupCondition> conditions = groupConditionService.listByGroupId(group.getId());
            List<Gcp> gcpList = UcUtil.convertToGcp(conditions);
            group.setGcpList(gcpList);
            List<String> orgIds = new ArrayList<>();
            List<String> posIds = new ArrayList<>();
            for (Gcp gcp : gcpList) {
                if (BooleanUtils.isTrue(gcp.getOrg())) {
                    String ids = gcp.getOrgIds();
                    String[] split = ids.split(Gcp.SPLIT_SEQ);
                    orgIds.addAll(Arrays.asList(split));
                }

                if (BooleanUtils.isTrue(gcp.getPos())) {
                    String ids = gcp.getPosIds();
                    String[] split = ids.split(Gcp.SPLIT_SEQ);
                    posIds.addAll(Arrays.asList(split));
                }
            }

            if (CollectionUtils.isNotEmpty(orgIds)) {
                Map<String, String> orgIdAndNameMap = orgService.getOrgIdAndNameMap(orgIds);
                group.setOrgIdNameMap(orgIdAndNameMap);
            }

            if (CollectionUtils.isNotEmpty(posIds)) {
                Map<String, String> positionIdAndNameMap = positionService.getPositionIdAndNameMap(posIds);
                group.setPosIdNameMap(positionIdAndNameMap);
            }
        }

        return group;
    }

    /**
     * 该方法用于根据类别ID查询类别下群组的数量
     *
     * @param categoryId 类别ID
     * @return 群组数量
     */
    public int countByCategory(String categoryId) {
        if (StringUtils.isEmpty(categoryId)) {
            return 0;
        }

        Example example = new Example(Group.class);
        Example.Criteria criteria = example.selectProperties(ID).createCriteria();
        criteria.andEqualTo(CATEGORY_ID, categoryId)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        example.setCountProperty(ID);

        return groupMapper.selectCountByExample(example);
    }

    /**
     * 该方法用于群组的分页查询
     *
     * @param condition 查询条件 <p>
     *                  <li>name:模糊查询</li>
     *                  <li>状态:多个IN查询 不传查所有</li>
     *                  <li>是否动态群组:null 查所有</li>
     *                  </p>
     * @param pageInfo  分页条件
     * @return 分页结果
     */
    @Transactional(readOnly = true)
    public Page<Group> search(GroupSearch condition, Page<Group> pageInfo) {
        if (!ContextHandler.isSuperAdmin()) {
            condition.setUserId(ContextHandler.getUserId());
        }

        String categoryId = condition.getCategoryId();
        if (StringUtils.isNotEmpty(categoryId)) {
            List<String> categoryIdList = new ArrayList<>();
            categoryIdList.add(categoryId);
            if (condition.isIncludeChild()) {
                categoryIdList.addAll(categoryService.getAllNodeIdByNodeId(categoryId));
            }

            condition.setCategoryIdList(categoryIdList);
        }

        int pageTotal = groupMapper.getGroupTotal(condition);
        if (pageTotal <= 0) {
            return pageInfo;
        }

        List<Group> list = groupMapper.searchGroup(condition, pageInfo, "updated_at DESC");
        if (CollectionUtils.isNotEmpty(list)) {
            pageInfo.setTotal(pageTotal);
            pageInfo.setList(list);
            pageInfo.setSize(list.size());
        }

        return pageInfo;
    }

    /**
     * 该方法用于群组保存
     *
     * @param group 群组
     * @return 群组ID
     */
    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public String insert(Group group) {
        if (group == null) {
            throw new IllegalArgumentException("Group is null when insert!");
        }

        if (StringUtils.isBlank(group.getId())) {
            String id = IDUtils.getUUID19();
            group.setId(id);
        }

        // addCondition(group);
        String groupId = super.insert(group);

        // 插入一条用户管辖范围权限
        ComponentCondition condition = new ComponentCondition();
        condition.setFunId(groupId);
        condition.setFunCode(UcConstants.RANG_TYPE_GROUP);
        condition.setRelType(UcConstants.RANG_TYPE_USER);
        condition.setRelIds(Collections.singletonList(ContextHandler.getUserId()));
        useScopeService.addUsers(condition);
        return groupId;
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void addCondition(Group group) {
        if (StringUtils.isEmpty(group.getId())) {
            throw new IllegalArgumentException("group.getId() is empty when addCondition");
        }

        Group param = new Group();
        param.setId(group.getId());
        groupConditionService.deleteByGroupId(group.getId());
        if (CollectionUtils.isNotEmpty(group.getGcpList())) {
            param.setDynamic(true);
            List<GroupCondition> conditions = UcUtil.convertToCondition(group.getGcpList(), group.getId());
            if (CollectionUtils.isNotEmpty(conditions)) {
                groupConditionService.batchInsert(conditions);
            }
        } else {
            param.setDynamic(false);
        }

        Example example = new Example(User.class);
        example.createCriteria().andEqualTo(User.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(Group.ID, group.getId());
        groupMapper.updateByExampleSelective(param, example);
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void update(Group group) {
        if (group == null) {
            throw new IllegalArgumentException("Group is null when update!");
        }

        /*String groupKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.GROUPS;
        redisTemplate.opsForHash().delete(groupKey, group.getId());

        groupConditionService.deleteByGroupId(group.getId());*/
        // addCondition(group);
        super.update(group);
    }

    /**
     * 该方法用于更新群组状态
     *
     * @param groupIds groupIds
     * @param status   状态
     */
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void updateStatus(List<String> groupIds, String status) {
        if (CollectionUtils.isEmpty(groupIds) || StringUtils.isEmpty(status)) {
            throw new IllegalArgumentException("GroupIds or status is empty when updateStatus!");
        }

        Example example = new Example(Group.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode()).andIn(ID, groupIds);
        Group group = new Group();
        group.setStatus(status);

        dealCache(groupIds, status);
        groupMapper.updateByExampleSelective(group, example);
    }

    private void dealCache(List<String> groupIds, String status) {
        CommonUtils.threadPoolExecutor(map -> {
            String groupKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.GROUPS;
            HashOperations<String, String, Object> opsForHash = redisTemplate.opsForHash();
            // 如果是停用群组
            if (UcConstants.STATUS_DISABLED.equals(status)) {
                opsForHash.delete(groupKey, groupIds.toArray());
                for (String groupId : groupIds) {
                    //缓存操作
                    List<String> userIds = groupMemberService.listCacheUserIds(groupId,
                            UcConstants.GROUP_MEMBER_TYPE_APPOINT);
                    groupMemberService.removeUserGroupCache(userIds, Collections.singletonList(groupId),
                            UcConstants.GROUP_MEMBER_TYPE_APPOINT);
                    userIds = groupMemberService.listCacheUserIds(groupId, UcConstants.GROUP_MEMBER_TYPE_DYNAMIC);
                    groupMemberService.removeUserGroupCache(userIds, Collections.singletonList(groupId),
                            UcConstants.GROUP_MEMBER_TYPE_DYNAMIC);
                }

                groupMemberService.removeGroupMembersCache(groupIds, null);
                return;
            }

            // 如果是启用群组，首先获取动态群组条件
            Map<String, List<GroupCondition>> conditionMap = groupConditionService.getConditionMap(groupIds);
            List<String> dynamicGroupIds = new ArrayList<>();
            for (String groupId : groupIds) {
                // 1、先处理指定人员缓存操作
                List<String> appointUserIds = groupMemberService.listDbUserIds(groupId,
                        UcConstants.GROUP_MEMBER_TYPE_APPOINT);
                groupMemberService.addUserGroupCache(appointUserIds, Collections.singletonList(groupId),
                        UcConstants.GROUP_MEMBER_TYPE_APPOINT);
                groupMemberService.addGroupMembersCache(CommonUtils.singletonList(groupId),
                        UcConstants.GROUP_MEMBER_TYPE_APPOINT, appointUserIds);

                // 2、处理动态群组缓存
                List<GroupCondition> conditions = conditionMap.get(groupId);
                if (null == conditions) {
                    continue;
                }

                dynamicGroupIds.add(groupId);
                Group group = new Group();
                group.setId(groupId);
                group.setGcpList(UcUtil.convertToGcp(conditions));
                // 2.1、动态群组本身放入缓存
                opsForHash.put(groupKey, groupId, group);
            }

            // 2.2、动态群组人员放入缓存
            if (CollectionUtils.isNotEmpty(dynamicGroupIds)) {
                putDynamicConditionToCache(dynamicGroupIds);
            }
        });
    }

    /**
     * 该方方法用于跑动态群组数据，群组启用、定时任务等调用，参数不传扫描所有动态群组
     *
     * @param groupIds 群组ID集合
     */
    public void putDynamicConditionToCache(List<String> groupIds) {
        putDynamicConditionToCache(groupIds, ContextHandler.getCorpCode());
    }

    /**
     * 该方方法用于跑动态群组数据，群组启用、定时任务等调用，参数不传扫描所有动态群组
     *
     * @param groupIds 群组ID集合，groupIds为null执行所有动态群组
     */
    public void putDynamicConditionToCache(List<String> groupIds, String corpCode) {
        ContextHandler.setCorpCode(corpCode);
        String groupKey = UcRedisKeys.UC_ + corpCode + UcRedisKeys.GROUPS;
        HashOperations<String, String, Group> opsForHash = redisTemplate.opsForHash();
        List<Group> groups;
        if (CollectionUtils.isEmpty(groupIds)) {
            groups = opsForHash.values(groupKey);
        } else {
            groups = opsForHash.multiGet(groupKey, groupIds);
        }

        if (CollectionUtils.isEmpty(groups)) {
            return;
        }

        Map<String, Map<String, Set<String>>> allNewUserGroupIdsMap = new HashMap<>();
        Map<String, Set<String>> userIdGroupIdListMap = new HashMap<>();
        Map<String, Set<String>> groupIdUserIdListMap = new HashMap<>();
        HashOperations<String, String, String> userRedis = redisTemplate.opsForHash();
        String usersKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USERS;
        List<String> userCaches = userRedis.values(usersKey);
        List<UserCache> users = UcUtil.toUserCache(userCaches);
        for (UserCache user : users) {
            for (Group group : groups) {
                if (group == null) {
                    continue;
                }

                List<Gcp> gcpList = group.getGcpList();
                if (CollectionUtils.isEmpty(gcpList)) {
                    continue;
                }

                boolean flag = false;
                for (Gcp gcp : gcpList) {
                    if (BooleanUtils.isTrue(gcp.getOrg())) {
                        String orgIds = gcp.getOrgIds();
                        if (StringUtils.isNotBlank(orgIds)) {
                            String[] orgIdsArray = orgIds.split(Gcp.SPLIT_SEQ);
                            List<String> orgList = Arrays.asList(orgIdsArray);
                            if (!orgList.contains(user.getOrgId())) {
                                continue;
                            }
                        }
                    }

                    if (BooleanUtils.isTrue(gcp.getPos())) {
                        String posIds = gcp.getPosIds();
                        if (StringUtils.isNotBlank(posIds)) {
                            String[] posIdsArray = posIds.split(Gcp.SPLIT_SEQ);
                            List<String> posList = Arrays.asList(posIdsArray);
                            if (!posList.contains(user.getPositionId())) {
                                continue;
                            }
                        }
                    }

                    if (BooleanUtils.isTrue(gcp.getLev())) {
                        String levVs = gcp.getLevVs();
                        if (StringUtils.isNotBlank(levVs)) {
                            String[] levVsArray = levVs.split(Gcp.SPLIT_SEQ);
                            List<String> levList = Arrays.asList(levVsArray);
                            if (!levList.contains(user.getLevel())) {
                                continue;
                            }
                        }
                    }

                    if (BooleanUtils.isTrue(gcp.getAge())) {
                        Integer age = user.getAge();
                        String ageCon = gcp.getAgeCon();
                        if (null == age || StringUtils.isBlank(ageCon)) {
                            continue;
                        }

                        String[] ageConArray = ageCon.split(Gcp.SPLIT_SEQ);
                        if (ageConArray.length > 1) {
                            String conType = ageConArray[0];
                            int conVale = Integer.parseInt(ageConArray[1]);
                            if (Gcp.GT.equals(conType)) {
                                if (age < conVale) {
                                    //不满足
                                    continue;
                                }
                            } else if (Gcp.LT.equals(conType)) {
                                if (age > conVale) {
                                    continue;
                                }
                            } else if (Gcp.ET.equals(conType)) {
                                if (age != conVale) {
                                    continue;
                                }
                            } else if (Gcp.BT.equals(conType)) {
                                int conVale2 = Integer.parseInt(ageConArray[2]);
                                if (age < conVale || age > conVale2) {
                                    continue;
                                }
                            }
                        }
                    }

                    if (BooleanUtils.isTrue(gcp.getEnt())) {//入职时间
                        LocalDate entryAt = user.getEntryAt();
                        String entCon = gcp.getEntCon();
                        if (null == entryAt || StringUtils.isEmpty(entCon)) {
                            continue;
                        }

                        String[] ageConArray = entCon.split(Gcp.SPLIT_SEQ);
                        if (ageConArray.length <= 2) {
                            continue;
                        }

                        String entryType = ageConArray[0];
                        String conType = ageConArray[1];
                        LocalDate dateFrom;
                        if (Gcp.ENTRY_TYPE_MONTH.equals(entryType)) {
                            // new Date() - entryAt >= 6个月 入职时间大于等于6个月的情况 ==> entryAt <= new Date() - 6个月
                            // new Date() - entryAt <= 12个月 入职时间小于等于12个月的情况 ==> entryAt >= new Date() - 16个月
                            // new Date() - entryAt == 3个月 入职时间等于3个月的情况 ==> entryAt == new Date() - 3个月
                            // 介于3-6个月 入职时间等于3个月的情况 ==> entryAt >= new Date() - 3个月 && entryAt >= new Date() - 6个月
                            int conVale = Integer.parseInt(ageConArray[2]);
                            dateFrom = LocalDate.now().minusMonths(conVale);
                            if (Gcp.GT.equals(conType)) {
                                if (entryAt.isAfter(dateFrom)) {
                                    continue;
                                }
                            } else if (Gcp.LT.equals(conType)) {
                                if (entryAt.isBefore(dateFrom)) {
                                    continue;
                                }
                            } else if (Gcp.ET.equals(conType)) {
                                if (entryAt.compareTo(dateFrom) != 0) {
                                    continue;
                                }
                            } else if (Gcp.BT.equals(conType) && ageConArray.length > 3) {
                                int conToVale = Integer.parseInt(ageConArray[3]);
                                LocalDate dateTo = LocalDate.now().minusMonths(conToVale);
                                if (entryAt.isAfter(dateFrom) || entryAt.isBefore(dateTo)) {
                                    continue;
                                }
                            }
                        } else if (Gcp.ENTRY_TYPE_DATE.equals(entryType)) {
                            dateFrom = LocalDate.parse(ageConArray[2], DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                            //晚于
                            if (Gcp.GT.equals(conType)) {
                                if (entryAt.isBefore(dateFrom)) {
                                    continue;
                                }
                            } else if (Gcp.LT.equals(conType)) {
                                if (entryAt.isAfter(dateFrom)) {
                                    continue;
                                }
                            } else if (Gcp.ET.equals(conType)) {
                                if (entryAt.compareTo(dateFrom) != 0) {
                                    continue;
                                }
                            } else if (Gcp.BT.equals(conType) && ageConArray.length > 3) {
                                LocalDate dateTo = LocalDate.parse(ageConArray[3], DateTimeFormatter.ofPattern("yyyy" +
                                        "-MM-dd"));
                                if (entryAt.isBefore(dateFrom) || entryAt.isAfter(dateTo)) {
                                    continue;
                                }
                            }
                        }
                    }

                    flag = true;
                    break;
                }

                if (flag) {
                    Set<String> groupIdSet = userIdGroupIdListMap.computeIfAbsent(user.getId(), k -> new HashSet<>());
                    groupIdSet.add(group.getId());

                    Set<String> userIdSet = groupIdUserIdListMap.computeIfAbsent(group.getId(), k -> new HashSet<>());
                    userIdSet.add(user.getId());
                }
            }
        }


        for (Map.Entry<String, Set<String>> entry : userIdGroupIdListMap.entrySet()) {
            Map<String, Set<String>> tmpMap = new HashMap<>(1);
            tmpMap.put(entry.getKey(), entry.getValue());
            allNewUserGroupIdsMap.put(entry.getKey(), tmpMap);
        }

        // 处理数据库数据
        dealDbData(groups, groupIdUserIdListMap);

        String groupDynamicMembersKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.GROUP_MEMBERS
                + UcRedisKeys.GROUP_SUF_D;
        HashOperations<String, String, Set<String>> groupMembersRedis = redisTemplate.opsForHash();
        if (CollectionUtils.isNotEmpty(groupIds)) {
            groupMembersRedis.delete(groupDynamicMembersKey, groupIds.toArray());
        } else {
            groupMembersRedis.getOperations().delete(groupDynamicMembersKey);
        }

        groupMembersRedis.putAll(groupDynamicMembersKey, groupIdUserIdListMap);

        String dynamicUserGroupKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USER_GROUP
                + UcRedisKeys.GROUP_SUF_D;
        HashOperations<String, String, Map<String, Set<String>>> userGroupKey = redisTemplate.opsForHash();

        userGroupKey.putAll(dynamicUserGroupKey, allNewUserGroupIdsMap);
    }

    /**
     * 处理数据库中存在的数据，本次操作的数据和数据库对比<p>
     * <li>参数有，数据库没有 新增到数据库 <li/>
     * <li>参数没有，数据库有 删除数据库数据 <li/>
     * <li>参数有，数据有 不做操作 <li/>
     * </p>
     */
    private void dealDbData(List<Group> groups, Map<String, Set<String>> groupIdUserIdListMap) {
        List<String> delGroupMemberIds = new ArrayList<>();
        for (Group group : groups) {
            Set<String> readyUserIds = groupIdUserIdListMap.get(group.getId());
            if (CollectionUtils.isEmpty(readyUserIds)) {
                delGroupMemberIds.add(group.getId());
                continue;
            }

            // 保留原 map 中 List 的值不变
            readyUserIds = new HashSet<>(groupIdUserIdListMap.get(group.getId()));
            List<String> dbUserIds = groupMemberService.listCacheUserIds(group.getId(),
                    UcConstants.GROUP_MEMBER_TYPE_DYNAMIC);
            if (CollectionUtils.isEmpty(dbUserIds)) {
                groupMemberService.batchInsert(group.getId(), UcConstants.GROUP_MEMBER_TYPE_DYNAMIC,
                        new ArrayList<>(readyUserIds));
                continue;
            }

            List<String> temUserIds = new ArrayList<>(readyUserIds);
            readyUserIds.removeAll(dbUserIds);
            dbUserIds.removeAll(temUserIds);

            if (CollectionUtils.isNotEmpty(readyUserIds)) {
                groupMemberService.batchInsert(group.getId(), UcConstants.GROUP_MEMBER_TYPE_DYNAMIC,
                        new ArrayList<>(readyUserIds));
            }

            if (CollectionUtils.isNotEmpty(dbUserIds)) {
                groupMemberService.batchDelete(group.getId(), UcConstants.GROUP_MEMBER_TYPE_DYNAMIC, dbUserIds);
            }
        }

        if (CollectionUtils.isNotEmpty(delGroupMemberIds)) {
            groupMemberService.batchDelete(delGroupMemberIds, UcConstants.GROUP_MEMBER_TYPE_DYNAMIC);
        }
    }

    @Transactional(readOnly = true)
    public Map<String, String> getGroupIdAndNameMap(Collection<String> groupIds) {
        if (CollectionUtils.isEmpty(groupIds)) {
            return new HashMap<>();
        }

        Example example = new Example(Group.class);
        example.selectProperties(ID, NAME);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode()).andIn(ID, groupIds);
        List<Group> groupList = groupMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(groupList)) {
            return new HashMap<>();
        }

        return groupList.stream().collect(Collectors.toMap(Group::getId, Group::getName));
    }


    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<Group> getGroupByCategoryIds(List<String> categoryIdList) {
        Example example = new Example(Position.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        criteria.andIn(CATEGORY_ID, categoryIdList);
        return groupMapper.selectByExample(example);
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public BlendTreeNode getCategoryAndGroupTree(String userId) {

        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        List<Category> commonTreeList = categoryService.list(CommonConstant.COMMON_TREE_FUN_CODE_UC_GROUP_CATEGORY);
        if (CollectionUtils.isEmpty(commonTreeList)) {
            return new BlendTreeNode();
        }

        BlendTreeNode root = getAndRemoveRoot(commonTreeList);
        List<String> categoryIdList = commonTreeList.stream().map(Category::getId).collect(Collectors.toList());
        List<Group> groupList = selectRangeGroup(categoryIdList);
        if (CollectionUtils.isEmpty(groupList)) {
            return TreeUtil.getBlendTree(commonTreeList, root);
        }

        Category commonTree;
        for (Group group : groupList) {
            commonTree = new Category();
            commonTree.setCategory(false);
            commonTree.setName(group.getName());
            commonTree.setId(group.getId());
            commonTree.setpId(group.getCategoryId());
            commonTreeList.add(commonTree);
        }

        return TreeUtil.getBlendTree(commonTreeList, root);
    }

    private BlendTreeNode getAndRemoveRoot(List<Category> categoryList) {
        if (CollectionUtils.isEmpty(categoryList)) {
            return null;
        }

        for (Iterator<Category> iterator = categoryList.iterator(); iterator.hasNext(); ) {
            Category category = iterator.next();
            if ("*".equals(category.getpId())) {
                iterator.remove();
                return new BlendTreeNode(category.getId(), category.getpId(), category.getName());
            }
        }

        return null;
    }

    /**
     * 根据群组类别Id列表，获取群组Id集合
     *
     * @param categoryIds 类别Id列表
     * @return 群组Id映射，key:群组Id，value:true
     */
    public Map<String, Boolean> getGroupIdMapByCategoryIds(List<String> categoryIds) {
        if (CollectionUtils.isEmpty(categoryIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "categoryIds not be empty!");
        }

        Example example = new Example(Group.class);
        example.selectProperties(Group.ID).createCriteria()
                .andEqualTo(Group.CORP_CODE, ContextHandler.getCorpCode())
                .andIn(Group.CATEGORY_ID, categoryIds);

        List<Group> groups = groupMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(groups)) {
            return new HashMap<>(0);
        }

        Map<String, Boolean> groupIdMap = new HashMap<>(groups.size());
        groups.forEach(group -> groupIdMap.put(group.getId(), true));
        return groupIdMap;
    }

    // TODO
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<Group> selectRangeGroup(List<String> categoryIds) {
        GroupSearch group = new GroupSearch();
        if (!ContextHandler.isSuperAdmin()) {
            group.setUserId(ContextHandler.getUserId());
        }

        if (CollectionUtils.isNotEmpty(categoryIds)) {
            group.setCategoryIdList(categoryIds);
        }

        group.setStatusList(CommonUtils.singletonList(CommonConstant.STATUS_ENABLED));
        group.setCorpCode(ContextHandler.getCorpCode());
        return groupMapper.searchGroup(group, null, null);
    }

    /**
     * 改方法用于判断群组是否启用
     *
     * @param groupId 群组ID
     * @return 是否启用
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public boolean isEnable(String groupId) {
        Group group = get(groupId);
        if (null == group) {
            return false;
        }

        return UcConstants.STATUS_ENABLED.equals(group.getStatus());
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void quickAddGroup(Group group) {
        if (StringUtils.isBlank(group.getId())) {
            String groupId = insert(group);
            ComponentCondition param = new ComponentCondition();
            param.setRelIds(CommonUtils.singletonList(ContextHandler.getUserId()));
            param.setFunId(groupId);
            param.setFunCode(UcConstants.RANG_TYPE_GROUP);
            useScopeService.addUsers(param);
            groupMemberService.batchInsert(groupId, UcConstants.GROUP_MEMBER_TYPE_APPOINT, group.getUserList());
        } else {
            groupMemberService.batchInsert(group.getId(), UcConstants.GROUP_MEMBER_TYPE_APPOINT, group.getUserList());
        }
    }

}
