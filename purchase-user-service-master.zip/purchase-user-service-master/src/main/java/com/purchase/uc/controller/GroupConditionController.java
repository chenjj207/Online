package com.purchase.uc.controller;

import com.purchase.uc.model.GroupCondition;
import com.purchase.uc.service.GroupConditionService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.*;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * GroupCondition接口
 * todo: 请编写此处添加注释，注名此接口的作用
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/groupCondition")
@Api(value = "GroupCondition接口", description = "GroupCondition Controller", tags = {"GroupCondition接口"})
public class GroupConditionController {

    @Resource
    private GroupConditionService groupConditionService;

    @GetMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "groupId", value = "群组ID", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "condition", value = "条件对应的json值，每个条件存储一条数据", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<GroupCondition>> search(@ParamHide GroupCondition groupCondition,
                                                   @ParamHide Page<GroupCondition> page) {
        page = groupConditionService.search(groupCondition, page);
        return new JsonResult<Page<GroupCondition>>(true, "查询成功", page);
    }

    @GetMapping(value = "/listAll")
    @ApiOperation(value = "获取所有数据")
    public JsonResult<List<GroupCondition>> listAll() {
        return new JsonResult<List<GroupCondition>>(true, "查询成功", groupConditionService.listAll());
    }

    @PostMapping("")
    @ApiOperation(value = "新增接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "groupId", value = "群组ID", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "condition", value = "条件对应的json值，每个条件存储一条数据", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "id", dataType = "String", paramType = "query")
    })
    public JsonResult addGroupCondition(@ParamHide GroupCondition groupCondition) {
        groupConditionService.insert(groupCondition);
        return new JsonResult(true, "添加成功");
    }

    @PutMapping("")
    @ApiOperation(value = "编辑接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "groupId", value = "群组ID", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "condition", value = "条件对应的json值，每个条件存储一条数据", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult editGroupCondition(@ParamHide @Check(field = {"id"}) GroupCondition groupCondition) {
        groupConditionService.update(groupCondition);
        return new JsonResult(true, "编辑成功");
    }

    @GetMapping(value = "/{id}")
    @ApiOperation(value = "根据id获取对应试题")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true)
    )
    public JsonResult<GroupCondition> getGroupCondition(@PathVariable(value = "id") @Check String id) {
        GroupCondition groupCondition = groupConditionService.get(id);
        return new JsonResult<>(true, "查询成功", groupCondition);
    }

    @DeleteMapping(value = "")
    @ApiOperation(value = "根据传入的Id，删除数据")
    public JsonResult<String> batchDelete(@ApiParam(value = "数据源Id", required = true)
                                          @RequestBody List<String> ids) {
        groupConditionService.batchDelete(ids);
        return new JsonResult<>(true, "删除成功");
    }
}
