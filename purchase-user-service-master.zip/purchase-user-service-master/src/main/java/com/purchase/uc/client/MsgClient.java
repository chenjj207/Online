package com.purchase.uc.client;

import com.aliyuncs.CommonResponse;
import com.purchase.uc.client.dto.TriggerMsgRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


/**
 * 搜索对外服务接口
 */
@FeignClient(value = "purchase-msg")
public interface MsgClient {

    /**
     * 业务消息发送
     * @return
     */
    @PostMapping("/trigger/business/msg")
    public CommonResponse triggerMsg(@RequestBody TriggerMsgRequest request);
}
