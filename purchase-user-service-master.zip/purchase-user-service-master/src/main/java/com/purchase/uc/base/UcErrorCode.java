package com.purchase.uc.base;


import com.qgutech.qgyun.framework.common.exception.ErrorEnum;

/**
 * <P>错误码</P>
 *
 * @author auto
 */
public enum UcErrorCode implements ErrorEnum {

    /**
     * 参数为空
     */
    EMPTY_PARAM("参数为空"),

    /**
     * 数据不存在
     */
    DATA_EMPTY("数据不存在"),

    /**
     * 参数非法
     */
    ILLEGAL_PARAM("参数非法"),

    /**
     * 名称重复
     */
    NAME_EXIST("名称重复"),

    /**
     * 编号非法
     */
    CODE_EXIST("编号重复"),

    /**
     * 系统异常
     */
    SYSTEM_ERROR("系统异常"),
    /**
     * 公司已过期或公司不存在
     */
    CORP_EXPIRED_OR_NOT_EXIST("公司已过期或公司不存在"),

    /**
     * 登录异常，密码空
     */
    LOGIN_ERROR_PASSWORD_EMPTY("登录异常，密码空"),

    /**
     * 登录异常，用户名空
     */
    LOGIN_ERROR_LOGIN_NAME_EMPTY("登录异常，用户名空"),

    /**
     * 部门异常，保存失败
     */
    ORGANIZE_ERROR_SAVE_ERROR("部门异常，保存失败"),

    /**
     * 部门异常，新增失败
     */
    ORGANIZE_ERROR_ADD_ERROR("部门异常，新增失败"),

    /**
     * 部门异常，父部门不存在
     */
    ORGANIZE_ERROR_PARENT_EMPTY("部门异常，父部门不存在"),

    /**
     * 部门异常，名称空
     */
    ORGANIZE_ERROR_NAME_EMPTY("部门异常，名称空"),

    /**
     * 权限异常，新增失败
     */
    PERMISSION_ERROR_ADD_ERROR("权限异常，新增失败"),

    /**
     * 权限异常，编码空
     */
    PERMISSION_ERROR_CODE_EMPTY("权限异常，编码空"),

    /**
     * 权限异常，名称空
     */
    PERMISSION_ERROR_NAME_EMPTY("权限异常，名称空"),

    /**
     * 角色权限关联异常，添加失败
     */
    ROLE_PERMISSION_ERROR_ADD_ERROR("角色权限关联异常，添加失败"),

    /**
     * 角色权限关联异常，删除失败
     */
    ROLE_PERMISSION_ERROR_DELETE_ERROR("角色权限关联异常，删除失败"),

    /**
     * 角色异常，变更状态失败
     */
    ROLE_ERROR_CHANGE_STATUS_ERROR("角色异常，变更状态失败"),

    /**
     * 角色异常，保存失败
     */
    ROLE_ERROR_SAVE_ERROR("角色异常，保存失败"),

    /**
     * 权限异常，保存失败
     */
    PERMISSION_ERROR_SAVE_ERROR("权限异常，保存失败"),

    /**
     * 角色异常，角色不存在
     */
    ROLE_ERROR_ROLE_EMPTY("角色异常，角色不存在"),

    /**
     * 角色异常，新增失败
     */
    ROLE_ERROR_ADD_ERROR("角色异常，新增失败"),

    /**
     * 角色异常，名称空
     */
    ROLE_ERROR_NAME_EMPTY("角色异常，名称空"),

    /**
     * 人员角色关联异常，删除失败
     */
    USER_ROLE_ERROR_DELETE_ERROR("人员角色关联异常，删除失败"),

    /**
     * 人员角色关联异常，添加失败
     */
    USER_ROLE_ERROR_ADD_ERROR("人员角色关联异常，添加失败"),

    /**
     * 日志错误，记录失败
     */
    LOG_ERROR_ADD_ERROR("日志错误，记录失败"),

    /**
     * 用户异常，状态变更失败
     */
    USER_ERROR_CHANGE_STATUS_ERROR("用户异常，状态变更失败"),

    /**
     * 状态参数异常
     */
    STATUS_ERROR("状态参数异常"),

    /**
     * 状态参数异常
     */
    STATUS_UPDATE_ERROR("信息已调整，请刷新列表"),

    /**
     * 重置密码失败
     */
    RESET_PASSWORD_ERROR("重置密码失败"),

    /**
     * 重置失败， 密码重复
     */
    RESET_PASSWORD_ERROR_REPEAT("重置失败， 密码重复"),

    /**
     * 用户异常，修改失败
     */
    USER_ERROR_UPDATE_ERROR("用户异常，修改失败"),

    /**
     * 用户异常，新增失败
     */
    USER_ERROR_ADD_ERROR("用户异常，新增失败"),

    /**
     * 用户异常，密码空
     */
    USER_ERROR_PASSWORD_EMPTY("用户异常，密码空"),

    /**
     * 用户异常，登录名空
     */
    USER_ERROR_LOGIN_NAME_EMPTY("用户异常，登录名空"),

    /**
     * 用户异常，用户不存在
     */
    USER_ERROR_USER_EMPTY("用户异常， 用户不存在"),

    /**
     * 登录失败，用户被冻结或已离职
     */
    LOGIN_ERROR_STATUS_ERROR("登录失败，用户被冻结或已离职"),

    /**
     * 登录失败，密码错误
     */
    LOGIN_ERROR_PASSWORD_ERROR("登录失败，密码错误"),

    /**
     * 登录失败，用户不存在
     */
    LOGIN_ERROR_USER_NOT_EXIST("登录失败，用户不存在"),

    /**
     * 用户不存在
     */
    USER_EMPTY("用户不存在"),

    /**
     * 未登录
     */
    NOT_LOGGED_IN("未登录"),
    INVALID_PASSWORD("密码不符合规范"),
    PASSWORD_NOT_EQUAL("两次输入的密码不一致"),
    OLD_PASSWORD_ERROR("输入的旧密码错误"),
    VERIFICATION_CODE_ERROR("验证码不正确"),
    VERIFICATION_CODE_INVALID("验证码已失效"),
    AUTH_DELETE_CHILD_ERROR("包含子类，不可删除"),
    AUTH_NOT_EXIST("权限菜单不存在"),
    AUTH_PARENT_NOT_EXIST("父级菜单不存在"),
    AUTH_CODE_EXIST("权限编号重复"),
    AUTH_CODE_EMPTY("权限编号不可为空"),
    AUTH_APP_CODE_EMPTY("菜单所属应用编号不可为空"),
    ROLE_HAVE_USERS_ERROR("角色下存在人员，不可删除"),

    /**
     * 供应商相关
     */
    SUPPLIER_EXIST("该会员已有供应商账号，请重试"),

    SUPPLIER_NOT_EXIST("供应商不存在"),

    ERROR_SUPPLIER_STATUS("非待审核的数据，请重新处理"),

    /**
     * 渠道商相关
     */
    CHANNEL_PROVIDER_EXIST("该渠道商已存在"),

    MOBILE_EXIST("手机号码已经绑定，请换一个重试"),

    ERROR_SUPPLIER_TYPE("供应商类型错误"),

    ERROR_SEND_MSG("发送短信通知失败"),

    UC_LOGIN_NAME_DUPLICATE("供应商手机号重复"),


    ;

    private final String text;

    UcErrorCode(String text) {
        this.text = text;
    }

    @Override
    public String getCode() {
        return name();
    }

    @Override
    public String getText() {
        return text;
    }
}
