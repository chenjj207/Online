package com.purchase.uc.base;

import java.time.format.DateTimeFormatter;

/**
 * @since TangFD@HF 2019-05-24
 */
public interface UcConstants {

    /**
     * 默认公司
     */
    String CORP_CODE_DEFAULT = "default";

    String DEFAULT_ORG_ROOT = "全部";

    String DEFAULT_CODE_KEY = "key";

    /**
     * 启用状态
     */
    String STATUS_ENABLED = "ENABLED";

    /**
     * 禁用状态
     */
    String STATUS_DISABLED = "DISABLED";

    /**
     * 删除状态
     */
    String STATUS_DELETED = "DELETED";

    /**
     * 离职状态
     */
    String STATUS_LEAVE = "LEAVE";

    /**
     * 管辖、授权、开放范围：部门
     */
    String RANG_TYPE_ORG = "ORG";
    String RANG_TYPE_ORG_TEXT = "[部]";

    /**
     * 管辖、授权、开放管辖范围：岗位
     */
    String RANG_TYPE_POSITION = "POSITION";
    String RANG_TYPE_POSITION_TEXT = "[岗]";

    /**
     * 管辖、授权、开放管辖范围：群组
     */
    String RANG_TYPE_GROUP = "GROUP";
    String RANG_TYPE_GROUP_TEXT = "[群]";

    /**
     * 管辖、授权、开放管辖范围：人员
     */
    String RANG_TYPE_USER = "USER";
    /**
     * 管辖、授权、开放管辖范围：角色
     */
    String RANG_TYPE_ROLE = "ROLE";


    /**
     * 管辖、授权、开放管辖范围：公司
     */
    String RANG_TYPE_COMPANY = "COMPANY";

    /**
     * 群组成员类型：指定
     */
    String GROUP_MEMBER_TYPE_APPOINT = "APPOINT";

    /**
     * 群组成员类型：动态
     */
    String GROUP_MEMBER_TYPE_DYNAMIC = "DYNAMIC";

    /**
     * 男
     */
    String SEX_MALE = "MALE";

    /**
     * 女
     */
    String SEX_FEMALE = "FEMALE";

    /**
     * 保密
     */
    String SEX_SECRET = "SECRET";

    /**
     * 进行中
     */
    String STATUS_RUNNING = "RUNNING";

    /**
     * 已完成
     */
    String STATUS_FINISHED = "FINISHED";

    /**
     * 失败
     */
    String STATUS_FAILED = "FAILED";

    /**
     * 已关闭
     */
    String STATUS_CLOSED = "CLOSED";

    /**
     * 导出类型：人员导出
     */
    String EXPORT_TYPE_USER = "EXPORT_UC_USER";

    /**
     * UC应用编号
     */
    String APP_CODE = "veln-uc";

    /**
     * admin账号，登录名
     */
    String ACCOUNT_ADMIN = "admin";

    String CONTEXT_KEY_PASSWORD = "password";
    String CONTEXT_KEY_MOBILE = "mobile";
    String CONTEXT_KEY_CODE = "code";
    String CONTEXT_KEY_OPENID = "openId";
    /**
     * 登录类型字段
     */
    String CONTEXT_KEY_LOGIN_TYPE = "LOGIN_TYPE";

    /**
     * 手机号登录
     */
    String LOGIN_TYPE_MOBILE = "MOBILE";
    String LOGIN_TYPE_MOBILE_REGISTER = "MOBILE_REGISTER";
    String LOGIN_TYPE_WECHAT = "WECHAT";
    //企微扫码登录
    String LOGIN_TYPE_WORK_WECHAT = "WORK_WECHAT";
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    String SEPARATOR_CHARS = ";;";

    /**
     * 导入校验，部门，岗位需要新增
     */
    String NEED_ADD = "NEED_ADD";

    String ENCODE_UTF8 = "UTF-8";
    String XLSX = ".xlsx";

    /**
     * 外部人员
     */
    String USER_TYPE_OUTER = "OUTER";

    /**
     * 内部人员
     */
    String USER_TYPE_INNER = "INNER";

    /**
     * 默认内部学员角色编号
     */
    String INNER_USER_ROLE = "default_user";

    /**
     * 默认外部学员角色编号
     */
    String OUTER_USER_ROLE = "outer_user";

    /**
     * 默认系统管理员角色编号
     */
    String DEFAULT_ADMIN_ROLE = "default_admin";

    /**
     * 默认销售人员角色编号
     */
    String SALE_USER_ROLE = "sale_user";

    /**
     * 默认商务人员角色编号
     */
    String BUSINESS_USER_ROLE = "business_user";

    /**
     * 默认技术人员角色编号
     */
    String TECHNOLOGY_USER_ROLE = "technology_user";

    /**
     * 供应链角色编号
     */
    String SUPPLY_CHAIN_ROLE = "SUPPLY_CHAIN";

    /**
     * 供应商角色编号
     */
    String SUPPLIER_ROLE = "supplier";

    /**
     * 子公司角色编号
     */
    String BRANCH_COMPANY_ROLE = "BRANCH_COMPANY";

    /**
     * 默认外部联系人部门编号
     */
    String OUTER_USER_ORG_CODE = "outer_org";
    //消息：新增人员
    String TEMPLATE_CODE_ACCOUNT_OPEN = "UC_ACCOUNT_OPEN";
    //重置密码
    String TEMPLATE_CODE_PASSWORD_RESET = "UC_ACCOUNT_PASSWORD_RESET";
    //冻结人员
    String TEMPLATE_CODE_ACCOUNT_FREEZE = "UC_ACCOUNT_FREEZE";
    //激活人员
    String TEMPLATE_CODE_ACCOUNT_ACTIVE = "UC_ACCOUNT_ACTIVE";
    //部门调动
    String TEMPLATE_CODE_DEPART_TRANSFER = "UC_DEPART_TRANSFER";

    /**
     * 账号状态(ENABLE: 启用、DISABLE: 停用)
     */
    String SUPPLIER_ACCOUNT_STATUS_ENABLE = "ENABLE";
    String SUPPLIER_ACCOUNT_STATUS_DISABLE = "DISABLE";
    /**
     * 类型（SUPPLIER_APPLY: 供应商申请、BACKGROUND_ADD: 后台新增、 ASSOCIATE_PROTOCOL：产线协议、SCM_ADD：scm新增）
     */
    String SUPPLIER_TYPE_SUPPLIER_APPLY = "SUPPLIER_APPLY";
    String SUPPLIER_TYPE_BACKGROUND_ADD = "BACKGROUND_ADD";
    String ASSOCIATE_PROTOCOL = "ASSOCIATE_PROTOCOL";
    String SCM_ADD = "SCM_ADD";
    /**
     * 类型(国内:CN、国外:FW)
     */
    String CN = "CN";
    String FW = "FW";
    /**
     * 状态（WAIT_AUDIT: 待审核、NO_PASS: 未通过、PASS: 已通过）
     */
    String SUPPLIER_STATUS_WAIT_AUDIT = "WAIT_AUDIT";
    String SUPPLIER_STATUS_NO_PASS = "NO_PASS";
    String SUPPLIER_STATUS_PASS = "PASS";

    /**
     * 用户：类型(SUPPLIER: 直供供应商，USER: 用户(供应链、子公司)，BRANCH_SUPPLIER：分部供应商)
     */
    String USER_DATA_TYPE_SUPPLIER = "SUPPLIER";
    String USER_DATA_TYPE_USER = "USER";
    String BRANCH_SUPPLIER = "BRANCH_SUPPLIER";

    /**
     * 签约项目(ZYDMALL: 联营商城, PRE_STOCK: 预库存, CONSIGNMENT_WAREHOUSE: 寄仓)
     */
    String CHANNEL_PROVIDER_SIGN_PROJECT_ZYDMALL = "ZYDMALL";
    String CHANNEL_PROVIDER_SIGN_PROJECT_PRE_STOCK = "PRE_STOCK";
    String CHANNEL_PROVIDER_SIGN_PROJECT_CONSIGNMENT_WAREHOUSE = "CONSIGNMENT_WAREHOUSE";

    /**
     * 供应商数据类型
     * UNITE：联营
     * SELF：自营
     */
    String UNITE = "UNITE";
    String SELF = "SELF";

}
