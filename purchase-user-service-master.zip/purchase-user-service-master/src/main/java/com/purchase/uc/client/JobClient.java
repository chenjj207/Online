package com.purchase.uc.client;

import com.purchase.uc.model.LoginLog;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Created by on 2019/6/20 0020
 *
 * @author shaohuiliang
 * @since saas 基础服务
 */
@FeignClient(value = "veln-jobclient", path = "/job/uc")
public interface JobClient {
    @RequestMapping(value = "/loginLogCache", method = RequestMethod.POST)
    public JsonResult createLoginLog(@RequestBody LoginLog loginLog);
}
