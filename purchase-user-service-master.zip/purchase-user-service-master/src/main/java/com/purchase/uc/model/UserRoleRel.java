package com.purchase.uc.model;

import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.List;

/**
 * 用户角色关联实体
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "UserRoleRel", description = "")
@Table(name = "t_uc_user_role_rel")
public class UserRoleRel extends BaseCorpModel {
    public static final String USER_ID = "userId";
    public static final String ROLE_ID = "roleId";

    /**
     * 用户id
     */
    @ApiModelProperty(value = "用户id")
    private String roleId;

    /**
     * 角色id
     */
    @ApiModelProperty(value = "角色id")
    private String userId;

    public UserRoleRel() {
    }

    public UserRoleRel(String userId, String roleId) {
        this.userId = userId;
        this.roleId = roleId;
        this.setCorpCode(ContextHandler.getCorpCode());
    }

    @Transient
    @ApiModelProperty(value = "用户名/工号/姓名/手机号")
    private String keyword;

    @Transient
    @ApiModelProperty(value = "用户Id列表")
    private List<String> userIds;

    @Transient
    @ApiModelProperty(value = "查询条件，角色Id列表")
    private List<String> roleIds;

    @Transient
    private int userCount;

    @ApiModelProperty(
            value = "页码（pageNum=0 并且 pageSize=0 查全部）",
            allowableValues = "1"
    )
    @Transient
    private Integer pageNum;
    @ApiModelProperty(
            value = "页大小（pageNum=0 并且 pageSize=0 查全部）",
            allowableValues = "10"
    )
    @Transient
    private Integer pageSize;
}
