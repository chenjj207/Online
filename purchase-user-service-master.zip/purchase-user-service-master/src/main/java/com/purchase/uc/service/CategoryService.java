package com.purchase.uc.service;

import com.purchase.uc.model.Category;
import com.qgutech.qgyun.dev.common.service.CommonCategoryService;
import com.qgutech.qgyun.dev.common.utils.CommonConstant;
import com.qgutech.qgyun.dev.common.utils.CommonI18nConstants;
import com.purchase.uc.base.UcI18nConstants;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Uc公共类别树服务
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年07月10日11:40:40
 */
@Service
public class CategoryService extends CommonCategoryService<Category> {
    @Resource
    private GroupService groupService;
    @Resource
    private PositionService positionService;

    /**
     * 根据类别ID删除类别
     *
     * @param categoryId 类别ID
     * @return 删除结果
     */
    public JsonResult<String> delCategory(String categoryId) {
        if (StringUtils.isEmpty(categoryId)) {
            throw new IllegalArgumentException("CategoryId is empty when delCategory!");
        }

        int count = countByParent(categoryId);
        if (count > 0) {
            return new JsonResult<>(false, UcI18nConstants.UC_HAS_CHILD.getName());
        }

        Category tree = get(categoryId);
        if (null == tree) {
            return new JsonResult<>(false, UcI18nConstants.UC_DELETE_ERROR.getName());
        }

        String funCode = tree.getFunCode();
        int resCount = 0;
        if (CommonConstant.COMMON_TREE_FUN_CODE_UC_GROUP_CATEGORY.equals(funCode)) {
            resCount = groupService.countByCategory(categoryId);
        } else if (CommonConstant.COMMON_TREE_FUN_CODE_UC_POSITION_CATEGORY.equals(funCode)) {
            resCount = positionService.countByCategory(categoryId);
        }

        if (resCount > 0) {
            return new JsonResult<>(false, UcI18nConstants.UC_BEEN_USED.getName());
        }

        super.delete(categoryId);
        return new JsonResult<>(true, UcI18nConstants.UC_DELETE_SUCCESS.getName());
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void init() {
        List<Category> list = listByProperty(Category.P_ID, "*", Category.ID);
        if (CollectionUtils.isNotEmpty(list)) {
            return;
        }

        List<Category> categoryList = new ArrayList<>(2);
        categoryList.add(getCategory(CommonConstant.COMMON_TREE_FUN_CODE_UC_POSITION_CATEGORY));
        categoryList.add(getCategory(CommonConstant.COMMON_TREE_FUN_CODE_UC_GROUP_CATEGORY));
        batchInsert(categoryList);
    }

    private Category getCategory(String funCode) {
        Category category = new Category();
        category.setName(CommonI18nConstants.ROOT_CATEGORY_NAME.getName());
        category.setFunCode(funCode);
        category.setpId("*");
        String id = IDUtils.getUUID19();
        category.setId(id);
        category.setIdPath(id);
        return category;
    }
}
