package com.purchase.uc;

import com.github.ltsopensource.spring.boot.annotation.EnableTaskTracker;
import com.qgutech.qgyun.dev.common.annotation.ComponentScanIgnore;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import tk.mybatis.spring.annotation.MapperScan;

/**
 * 项目启动类
 *
 * @author lidecheng
 */
@SpringCloudApplication
@ComponentScan(excludeFilters = @ComponentScan.Filter(ComponentScanIgnore.class))
@MapperScan({"com.purchase.uc.mapper", "com.purchase.uc.common.mapper"})
@EnableFeignClients
@EnableHystrix
@EnableTaskTracker
public class UcApplication {
    public static void main(String[] args) {
        System.setProperty("tomcat.util.http.parser.HttpParser.requestTargetAllow","{}|");
        SpringApplication.run(UcApplication.class, args);
    }
}
