package com.purchase.uc.controller;

import com.purchase.uc.model.Company;
import com.purchase.uc.service.CompanyService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 分公司接口
 *
 * @author lwl
 */
@Slf4j
@RestController
@RequestMapping(value = "/company")
@Api(value = "分公司接口", tags = {"分公司接口"})
public class CompanyController {
    @Resource
    private CompanyService companyService;

    /**
     * 获取公司
     */
    @PostMapping(value = "/all-list")
    public JsonResult<List<Company>> listAll() {
        return new JsonResult<>(true, null, companyService.listAll());
    }

    @ApiOperation("获取公司")
    @PostMapping(value = "/ngyl-list")
    public JsonResult<List<Company>> list() {
        List<Company> collect = companyService.listAll();
        List<Company> gylCompany = collect.stream().
                filter(c -> c.getComBm().equals("0214"))
                .collect(Collectors.toList());
        List<Company> companyList = collect.stream()
                .filter(c -> StringUtils.isNotBlank(c.getAreaBm()) && !c.getAreaBm().equals("Z"))
                .collect(Collectors.toList());
        companyList.addAll(gylCompany);
        return new JsonResult<>(true, null, companyList);
    }
}
