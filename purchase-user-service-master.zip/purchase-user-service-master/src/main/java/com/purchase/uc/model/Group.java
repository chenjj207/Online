package com.purchase.uc.model;

import com.purchase.uc.model.vo.Gcp;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang.StringUtils;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.List;
import java.util.Map;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "Group", description = "")
@Table(name = "t_uc_group")
public class Group extends BaseCorpModel {
    public static final String NAME = "name";
    public static final String CODE = "code";
    public static final String STATUS = "status";
    public static final String CATEGORY_ID = "categoryId";
    public static final String DYNAMIC = "dynamic";
    public static final String DESCRIPTION = "description";

    /**
     * 群组名称
     */
    @ApiModelProperty(value = "群组名称")
    private String name;

    /**
     * 群组编码
     */
    @ApiModelProperty(value = "群组编码")
    private String code;

    /**
     * 群组状态（DRAFT: 草稿，DISABLED：激活，DISABLED：停用）
     */
    @ApiModelProperty(value = "群组状态（DRAFT: 草稿，DISABLED：激活，DISABLED：停用）")
    private String status;

    /**
     * 群组类别
     */
    @ApiModelProperty(value = "群组类别")
    private String categoryId;

    /**
     * 是否动态群组
     */
    @ApiModelProperty(value = "是否动态群组")
    private Boolean dynamic;

    /**
     * 群组描述
     */
    @ApiModelProperty(value = "群组描述")
    private String description;

    /**
     * 类别名称全路径
     */
    @Transient
    private String categoryNamePath;

    /**
     * 群组条件
     */
    @Transient
    private List<Gcp> gcpList;

    /**
     * 用户姓名
     */
    @Transient
    private transient String userName;

    /**
     * 类别id集合
     */
    @Transient
    @ApiModelProperty(value = "岗位类别")
    private List<String> categoryIdList;

    @Transient
    private Map<String, String> orgIdNameMap;

    @Transient
    private Map<String, String> posIdNameMap;

    /**
     * 快捷创建群组选人使用
     */
    @Transient
    private List<String> userList;

    public String getCode() {
        if (StringUtils.isBlank(code)) {
            return null;
        }

        return code;
    }
}
