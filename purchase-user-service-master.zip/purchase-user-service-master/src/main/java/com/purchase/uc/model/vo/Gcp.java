package com.purchase.uc.model.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * GroupConditionParam 缩写，动态群组的条件参数
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年05月25日09:04:23
 */
@Getter
@Setter
@ToString
public class Gcp {
    /**
     * 动态群组条件类型
     */
    // greater than (>=) 晚于
    public static final String GT = "gt";
    // less than (<=) 早于
    public static final String LT = "lt";
    // equal to (=)
    public static final String ET = "et";
    //between and (v1 < & <v2)
    public static final String BT = "bt";

    /**
     * 入职时间类型
     */
    //指定日期
    public static final String ENTRY_TYPE_DATE = "DATE";
    //入职时长
    public static final String ENTRY_TYPE_MONTH = "MONTH";
    public static final String SPLIT_SEQ = ",";

    /**
     * 启用部门条件
     */
    private Boolean org;

    /**
     * 部门主键集合（orgId1,orgId2,...,orgIdn）
     */
    private String orgIds;

    /**
     * 启用岗位条件
     */
    private Boolean pos;

    /**
     * 岗位主键集合（posId1,posId2,...,posIdn）
     */
    private String posIds;

    /**
     * 启用级别条件
     */
    private Boolean lev;

    /**
     * 级别value（levV1,levV2,...,levVn）
     */
    private String levVs;

    /**
     * 启用年龄条件
     */
    private Boolean age;

    /**
     * 年龄condition（条件[>=|<=|=|],val1,val2）
     */
    private String ageCon;

    /**
     * 启用入职时间条件
     */
    private Boolean ent;

    /**
     * 入职时间condition（entType[DATE、MONTH],条件[>=|<=|=|],val1,val2）
     * 早于 ： <=
     * 晚于 : >=
     */
    private String entCon;

    /**
     * 排序
     */
    @ApiModelProperty(value = "排序")
    private Float showOrder;
}
