package com.purchase.uc.service;

import com.purchase.uc.mapper.GroupMemberMapper;
import com.purchase.uc.model.vo.GroupMemberSearch;
import com.purchase.uc.model.vo.UserComponent;
import com.purchase.uc.utils.CompoentUtil;
import com.purchase.uc.utils.UcUtil;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.qgutech.qgyun.dev.common.utils.CommonUtils;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.model.GroupMember;
import com.purchase.uc.model.User;
import com.purchase.uc.utils.UcRedisKeys;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

import static com.purchase.uc.model.GroupMember.*;
import static com.qgutech.qgyun.framework.database.model.BaseCorpModel.CORP_CODE;

/**
 * 群组成员表服务及实现类
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
public class GroupMemberService extends BaseServiceImpl<GroupMember> implements UserComponentService {

    @Resource
    private GroupMemberMapper groupMemberMapper;
    @Resource
    private UserService userService;
    @Resource
    private RedisTemplate redisTemplate;
    @Resource
    private GroupService groupService;

    public List<GroupMember> listAll() {
        return groupMemberMapper.selectAll();
    }

    /**
     * 该方法用于群组的分页查询
     *
     * @param condition 查询条件
     * @param pageInfo  分页条件
     * @return 分页结果
     */
    @Transactional(readOnly = true)
    public Page<User> search(GroupMemberSearch condition, Page<User> pageInfo) {
        int pageTotal = groupMemberMapper.getUserTotal(condition);
        if (pageTotal <= 0) {
            return pageInfo;
        }

        List<User> list = groupMemberMapper.searchUser(condition, pageInfo);
        if (CollectionUtils.isNotEmpty(list)) {
            pageInfo.setTotal(pageTotal);
            pageInfo.setList(list);
            list = userService.fillOrgAndPositName(list);
            pageInfo.setSize(list.size());
        }

        return pageInfo;
    }

    /**
     * 该方法用于根据群组ID和人员来源查询所有人员ID，选人组件使用
     *
     * @param groupId 群组ID
     * @param source  人员来源
     * @return 人员集合
     */
    @SuppressWarnings("unchecked")
    public List<String> listCacheUserIds(String groupId, String source) {
        if (StringUtils.isEmpty(groupId) || StringUtils.isEmpty(source)) {
            throw new IllegalArgumentException("groupId or source is empty!");
        }

        String groupMembersKey = getGroupKey(source, UcRedisKeys.GROUP_MEMBERS);
        HashOperations<String, String, Set<String>> opsForHash = redisTemplate.opsForHash();
        Set<String> cacheUserIds = opsForHash.get(groupMembersKey, groupId);
        if (CollectionUtils.isNotEmpty(cacheUserIds)) {
            return new ArrayList<>(cacheUserIds);
        }

        List<String> userIdList = getSourceUserIdMap(groupId).get(source);
        if (CollectionUtils.isNotEmpty(userIdList)) {
            opsForHash.put(groupMembersKey, groupId, new HashSet<>(userIdList));
        }

        return userIdList;
    }

    /**
     * 该方法用于根据群组ID、来源及用户ID保存群组成员【定时跑群组会用】
     *
     * @param groupId 群组ID
     * @param source  来源
     * @param userIds 用户ID
     */
    public void batchInsert(String groupId, String source, List<String> userIds) {
        if (StringUtils.isEmpty(groupId) || StringUtils.isEmpty(source) || CollectionUtils.isEmpty(userIds)) {
            throw new IllegalArgumentException("groupId or source or userIds is empty!");
        }

        List<String> dbUserIds = listDbUserIds(groupId, source);
        userIds.removeAll(dbUserIds);
        if (CollectionUtils.isEmpty(userIds)) {
            return;
        }

        List<GroupMember> groupMembers = new ArrayList<>(userIds.size());
        for (String userId : userIds) {
            GroupMember member = new GroupMember();
            member.setGroupId(groupId);
            member.setSource(source);
            member.setUserId(userId);
            groupMembers.add(member);
        }

        batchInsert(groupMembers);

        // 如果群组是启用状态
        if (groupService.isEnable(groupId)) {
            addUserGroupCache(userIds, CommonUtils.singletonList(groupId), source);
            addGroupMembersCache(CommonUtils.singletonList(groupId), source, userIds);
        }
    }

    /**
     * 该方法用于根据条件获取<h2>数据库<h2/>中已有的群组成员
     *
     * @param groupId 群组ID
     * @param source  人员来源
     * @return 人员ID集合
     */
    public List<String> listDbUserIds(String groupId, String source) {
        Example example = new Example(GroupMember.class);
        Example.Criteria criteria = example.selectProperties(USER_ID).createCriteria();
        criteria.andEqualTo(GROUP_ID, groupId)
                .andEqualTo(SOURCE, source)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        List<GroupMember> members = groupMemberMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(members)) {
            return new ArrayList<>();
        }

        return members.stream().map(GroupMember::getUserId)
                .filter(StringUtils::isNotBlank).collect(Collectors.toList());

    }

    /**
     * 该方法用于给指定人员添加指定群组缓存
     *
     * @param userIds  人员ID集合
     * @param groupIds 群组ID集合
     * @param source   来源
     */
    @SuppressWarnings("unchecked")
    public void addUserGroupCache(List<String> userIds, List<String> groupIds, String source) {
        CommonUtils.threadPoolExecutor(map -> {
            String userGroupKey = getGroupKey(source, UcRedisKeys.USER_GROUP);
            Map<String, Set<String>> allUserGroupIdsMap = UcUtil.getResultMap(redisTemplate, userGroupKey, userIds);
            Map<String, Map<String, Set<String>>> allNewUserGroupIdsMap = new HashMap<>(userIds.size());
            for (String userId : userIds) {
                Set<String> set = allUserGroupIdsMap.get(userId);
                if (CollectionUtils.isEmpty(set)) {
                    set = new HashSet<>();
                }

                set.addAll(new HashSet<>(groupIds));
                Map<String, Set<String>> userGroupIdsMap = new HashMap<>(set.size());
                userGroupIdsMap.put(userId, set);
                allNewUserGroupIdsMap.put(userId, userGroupIdsMap);
            }

            HashOperations<String, String, Map<String, Set<String>>> opsForHash = redisTemplate.opsForHash();
            opsForHash.putAll(userGroupKey, allNewUserGroupIdsMap);
        });
    }

    private String getGroupKey(String source, String keyType) {
        String preUserGroupKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + keyType;
        String userGroupKey = preUserGroupKey + UcRedisKeys.GROUP_SUF_S;
        if (UcConstants.GROUP_MEMBER_TYPE_DYNAMIC.equals(source)) {
            userGroupKey = preUserGroupKey + UcRedisKeys.GROUP_SUF_D;
        }

        return userGroupKey;
    }

    /**
     * 该方法用于根据群组ID、来源及用户ID删除群组成员
     *
     * @param groupId 群组ID
     * @param source  来源
     * @param userIds 用户ID
     */
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void batchDelete(String groupId, String source, List<String> userIds) {
        if (StringUtils.isEmpty(groupId) || StringUtils.isEmpty(source) || CollectionUtils.isEmpty(userIds)) {
            throw new IllegalArgumentException("groupId or source or userIds is empty!");
        }

        Example example = new Example(GroupMember.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(GROUP_ID, groupId)
                .andEqualTo(SOURCE, source)
                .andIn(USER_ID, userIds)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        groupMemberMapper.deleteByExample(example);

        // 群组是否启用
        if (groupService.isEnable(groupId)) {
            removeUserGroupCache(userIds, CommonUtils.singletonList(groupId), source);
            removeGroupMembersCache(CommonUtils.singletonList(groupId), source, userIds);
        }
    }

    /**
     * 该方法用于根据群组ID、来源群组成员
     *
     * @param groupIds 群组ID
     * @param source   来源
     */
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void batchDelete(List<String> groupIds, String source) {
        if (CollectionUtils.isEmpty(groupIds) || StringUtils.isEmpty(source)) {
            throw new IllegalArgumentException("groupId or source or userIds is empty!");
        }

        Example example = new Example(GroupMember.class);
        Example.Criteria criteria = example.selectProperties(USER_ID).createCriteria();
        criteria.andIn(GROUP_ID, groupIds)
                .andEqualTo(SOURCE, source)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        groupMemberMapper.deleteByExample(example);
    }

    /**
     * 该方法用于根据群组ID、来源及用户ID删除群组成员
     *
     * @param groupIds 群组ID
     * @param source   来源
     * @param userIds  用户ID
     */
    @SuppressWarnings("unchecked")
    public void removeUserGroupCache(List<String> userIds, List<String> groupIds, String source) {
        CommonUtils.threadPoolExecutor(map -> {
            String userGroupKey = getGroupKey(source, UcRedisKeys.USER_GROUP);
            HashOperations<String, String, Map<String, Set<String>>> opsForHash = redisTemplate.opsForHash();
            Map<String, Set<String>> allUserGroupIdsMap = UcUtil.getResultMap(redisTemplate, userGroupKey, userIds);
            Map<String, Map<String, Set<String>>> allNewUserGroupIdsMap = new HashMap<>(userIds.size());
            for (String userId : userIds) {
                Set<String> set = allUserGroupIdsMap.get(userId);
                if (CollectionUtils.isEmpty(set)) {
                    continue;
                }

                //从人员已有的groupList中移除
                set.removeAll(groupIds);
                Map<String, Set<String>> userGroupIdsMap = new HashMap<>(set.size());
                userGroupIdsMap.put(userId, set);
                allNewUserGroupIdsMap.put(userId, userGroupIdsMap);
            }

            opsForHash.putAll(userGroupKey, allNewUserGroupIdsMap);
        });
    }

    /**
     * 改方法用于群组停用时清除群组缓存
     *
     * @param groupIds 群组IDS
     */
    @SuppressWarnings("unchecked")
    public void removeGroupMembersCache(List<String> groupIds, String source, List<String> userIds) {
        CommonUtils.threadPoolExecutor(map -> {
            HashOperations<String, String, Set<String>> opsForHash = redisTemplate.opsForHash();
            String groupMembersKey = getGroupKey(source, UcRedisKeys.GROUP_MEMBERS);
            for (String groupId : groupIds) {
                List<String> cacheUserIds = listCacheUserIds(groupId, source);
                if (CollectionUtils.isEmpty(cacheUserIds)) {
                    continue;
                }

                cacheUserIds.removeAll(userIds);
                opsForHash.put(groupMembersKey, groupId, new HashSet<>(cacheUserIds));
            }
        });
    }

    /**
     * 改方法用于群组停用时清除群组缓存
     *
     * @param groupIds 群组IDS
     */
    @SuppressWarnings("unchecked")
    public void removeGroupMembersCache(List<String> groupIds, String source) {
        CommonUtils.threadPoolExecutor(map -> {
            HashOperations<String, String, Set<String>> opsForHash = redisTemplate.opsForHash();
            String dynamicMembersKey = getGroupKey(UcConstants.GROUP_MEMBER_TYPE_DYNAMIC, UcRedisKeys.GROUP_MEMBERS);
            String appointMembersKey = getGroupKey(UcConstants.GROUP_MEMBER_TYPE_APPOINT, UcRedisKeys.GROUP_MEMBERS);
            if (UcConstants.GROUP_MEMBER_TYPE_DYNAMIC.equals(source)) {
                opsForHash.delete(dynamicMembersKey, groupIds.toArray());
            } else if (UcConstants.GROUP_MEMBER_TYPE_APPOINT.equals(source)) {
                opsForHash.delete(appointMembersKey, groupIds.toArray());
            } else {
                opsForHash.delete(dynamicMembersKey, groupIds.toArray());
                opsForHash.delete(appointMembersKey, groupIds.toArray());
            }
        });
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public void addGroupMembersCache(List<String> groupIds, String source, List<String> userIds) {
        CommonUtils.threadPoolExecutor(map -> {
            HashOperations<String, String, Set<String>> opsForHash = redisTemplate.opsForHash();
            String groupMembersKey = getGroupKey(source, UcRedisKeys.GROUP_MEMBERS);
            for (String groupId : groupIds) {
                List<String> cacheUserIds = listCacheUserIds(groupId, source);
                if (CollectionUtils.isNotEmpty(cacheUserIds)) {
                    userIds.addAll(cacheUserIds);
                }

                opsForHash.put(groupMembersKey, groupId, new HashSet<>(userIds));
            }
        });
    }

    /**
     * 改方法用于群组启用时添加群组缓存
     *
     * @param groupIds 群组IDS
     */
    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public void addGroupMembersCache(List<String> groupIds) {
        CommonUtils.threadPoolExecutor(map -> {
            HashOperations<String, String, Set<String>> opsForHash = redisTemplate.opsForHash();
            String dynamicKey = getGroupKey(UcConstants.GROUP_MEMBER_TYPE_DYNAMIC, UcRedisKeys.GROUP_MEMBERS);
            String appointKey = getGroupKey(UcConstants.GROUP_MEMBER_TYPE_APPOINT, UcRedisKeys.GROUP_MEMBERS);
            for (String groupId : groupIds) {
                Map<String, List<String>> sourceUserIdMap = getSourceUserIdMap(groupId);
                if (null == sourceUserIdMap) {
                    continue;
                }

                List<String> dynamicUserIds = sourceUserIdMap.get(UcConstants.GROUP_MEMBER_TYPE_DYNAMIC);
                if (CollectionUtils.isNotEmpty(dynamicUserIds)) {
                    opsForHash.put(dynamicKey, groupId, new HashSet<>(dynamicUserIds));
                }

                List<String> appointUserIds = sourceUserIdMap.get(UcConstants.GROUP_MEMBER_TYPE_APPOINT);
                if (CollectionUtils.isNotEmpty(appointUserIds)) {
                    opsForHash.put(appointKey, groupId, new HashSet<>(appointUserIds));
                }
            }
        });
    }

    /**
     * 该方法用于根据群组ID获取来源和人员ID集合Map
     *
     * @param groupId 群组ID
     * @return 人员集合 key:来源 value:人员ID集合
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, List<String>> getSourceUserIdMap(String groupId) {
        if (StringUtils.isEmpty(groupId)) {
            throw new IllegalArgumentException("groupId or source is empty!");
        }

        Example example = new Example(GroupMember.class);
        Example.Criteria criteria = example.selectProperties(USER_ID, SOURCE).createCriteria();
        criteria.andEqualTo(GROUP_ID, groupId)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());

        List<GroupMember> groupMembers = groupMemberMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(groupMembers)) {
            return new HashMap<>(0);
        }

        List<String> sUserIds = new ArrayList<>();
        List<String> dUserIds = new ArrayList<>();
        for (GroupMember groupMember : groupMembers) {
            if (null == groupMember) {
                continue;
            }

            if (UcConstants.GROUP_MEMBER_TYPE_APPOINT.equals(groupMember.getSource())) {
                sUserIds.add(groupMember.getUserId());
            } else {
                dUserIds.add(groupMember.getUserId());
            }
        }

        Map<String, List<String>> map = new HashMap<>();
        map.put(UcConstants.GROUP_MEMBER_TYPE_APPOINT, sUserIds);
        map.put(UcConstants.GROUP_MEMBER_TYPE_DYNAMIC, dUserIds);

        return map;
    }

    /**
     * 该方法用于根据群组ID列表，查询所有人员ID列表（指定+动态人员）
     *
     * @param groupIds 群组ID列表
     * @return 人员ID列表
     */
    public Set<String> listUserIdsFromCache(Collection<String> groupIds) {
        return listUserIdsFromCache(groupIds, UcConstants.GROUP_MEMBER_TYPE_DYNAMIC,
                UcConstants.GROUP_MEMBER_TYPE_APPOINT);
    }

    /**
     * 该方法用于根据群组ID列表，查询所有人员ID列表（指定+动态人员）
     *
     * @param groupIds 群组ID列表
     * @return 人员ID列表
     */
    public Set<String> listUserIdsFromCache(Collection<String> groupIds, String... source) {
        String groupMembersKey;
        Map<String, Set<String>> resultMap;
        Set<String> dynamicSet = new HashSet<>(0);
        HashOperations<String, String, Set<String>> hashOperations = redisTemplate.opsForHash();
        if (source != null && Arrays.asList(source).contains(UcConstants.GROUP_MEMBER_TYPE_DYNAMIC)) {
            groupMembersKey = getGroupKey(UcConstants.GROUP_MEMBER_TYPE_DYNAMIC, UcRedisKeys.GROUP_MEMBERS);
            List<Set<String>> list;
            if (CollectionUtils.isEmpty(groupIds)) {
                list = hashOperations.values(groupMembersKey);
            } else {
                list = hashOperations.multiGet(groupMembersKey, groupIds);
            }
            dynamicSet = UcUtil.getSet(list);
        }

        Set<String> appointSet = new HashSet<>(0);
        if (source != null && Arrays.asList(source).contains(UcConstants.GROUP_MEMBER_TYPE_APPOINT)) {
            groupMembersKey = getGroupKey(UcConstants.GROUP_MEMBER_TYPE_APPOINT, UcRedisKeys.GROUP_MEMBERS);
            List<Set<String>> list;
            if (CollectionUtils.isEmpty(groupIds)) {
                list = hashOperations.values(groupMembersKey);
            } else {
                list = hashOperations.multiGet(groupMembersKey, groupIds);
            }
            appointSet = UcUtil.getSet(list);
        }

        Set<String> set = new HashSet<>();
        set.addAll(dynamicSet);
        set.addAll(appointSet);
        return set;
    }

    /**
     * 根据用户id获取用户对应的群组ids
     *
     * @return
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Set<String> findGroupsByuserId(String userId) {
        Set<String> resultGroupIds = new HashSet<>();
        HashOperations<String, String, Set<String>> opsForHash = redisTemplate.opsForHash();
        String dynamicKey = getGroupKey(UcConstants.GROUP_MEMBER_TYPE_DYNAMIC, UcRedisKeys.GROUP_MEMBERS);
        String appointKey = getGroupKey(UcConstants.GROUP_MEMBER_TYPE_APPOINT, UcRedisKeys.GROUP_MEMBERS);
        Map<String, Set<String>> dynamicMap = opsForHash.entries(dynamicKey);
        Map<String, Set<String>> appointMap = opsForHash.entries(appointKey);
        if (MapUtils.isNotEmpty(dynamicMap)) {
            buildGroupIds(resultGroupIds, dynamicMap, userId);
        }

        if (MapUtils.isNotEmpty(appointMap)) {
            buildGroupIds(resultGroupIds, appointMap, userId);
        }

        return resultGroupIds;
    }

    private void buildGroupIds(Set<String> resultGroupIds, Map<String, Set<String>> sourceMap, String userId) {
        for (String key : sourceMap.keySet()) {
            Set<String> userSet = sourceMap.get(key);
            if (userSet.contains(userId)) {
                resultGroupIds.add(key);
            }
        }
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void addUsers(ComponentCondition condition) {
        if (condition == null || StringUtils.isEmpty(condition.getFunId()) ||
                CollectionUtils.isEmpty(condition.getRelIds())) {
            throw new IllegalArgumentException("FunId or relIds is empty!");
        }

        batchInsert(condition.getFunId(), UcConstants.GROUP_MEMBER_TYPE_APPOINT, condition.getRelIds());
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void removeAllUsers(ComponentCondition condition) {
        if (condition == null || StringUtils.isEmpty(condition.getFunId())) {
            throw new IllegalArgumentException("FunId or relIds is empty!");
        }

        batchDelete(CommonUtils.singletonList(condition.getFunId()), UcConstants.GROUP_MEMBER_TYPE_APPOINT);
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void removeUsers(ComponentCondition condition) {
        if (condition == null || StringUtils.isEmpty(condition.getFunId()) ||
                CollectionUtils.isEmpty(condition.getRelIds())) {
            throw new IllegalArgumentException("FunId or relIds is empty!");
        }

        batchDelete(condition.getRelIds());
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<String> listSelectedUserId(ComponentCondition condition) {
        if (condition == null || StringUtils.isEmpty(condition.getFunId())) {
            throw new IllegalArgumentException("FunId is empty!");
        }

        GroupMemberSearch search = new GroupMemberSearch(condition.getFunId(), condition.getKeywords(),
                UcConstants.GROUP_MEMBER_TYPE_APPOINT);
        List<User> users = groupMemberMapper.searchUser(search, null);
        if (CollectionUtils.isEmpty(users)) {
            return new ArrayList<>();
        }

        return users.stream().map(User::getId)
                .filter(StringUtils::isNotBlank).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<String> searchSelectedUserId(ComponentCondition condition) {
        if (condition == null || StringUtils.isEmpty(condition.getFunId())) {
            throw new IllegalArgumentException("FunId is empty!");
        }

        GroupMemberSearch search = new GroupMemberSearch(condition.getFunId(), condition.getKeywords(),
                UcConstants.GROUP_MEMBER_TYPE_APPOINT);
        Page<User> userPage = search(search, condition.getPage());
        return CompoentUtil.convertToUserIdPage(userPage);
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<UserComponent> searchSelectedUser(ComponentCondition condition) {
        if (condition == null || StringUtils.isEmpty(condition.getFunId())) {
            throw new IllegalArgumentException("FunId is empty!");
        }

        GroupMemberSearch search = new GroupMemberSearch(condition.getFunId(), condition.getKeywords(),
                UcConstants.GROUP_MEMBER_TYPE_APPOINT);
        Page<User> userPage = search(search, condition.getPage());
        return CompoentUtil.convertToUserComponentPage(userPage);
    }
}
