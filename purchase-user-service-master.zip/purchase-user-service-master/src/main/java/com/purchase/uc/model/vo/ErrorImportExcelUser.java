package com.purchase.uc.model.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

/**
 * 人员导入错误提示模板
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Data
public class ErrorImportExcelUser extends ImportExcelUser {

    @ExcelProperty(value = "错误信息", index = 17)
    private String message;
}
