package com.purchase.uc.controller;

import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.service.GroupService;
import com.qgutech.qgyun.dev.common.model.vo.BlendTreeNode;
import com.qgutech.qgyun.dev.common.utils.CommonConstant;
import com.purchase.uc.model.Group;
import com.purchase.uc.model.vo.GroupSearch;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.*;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Group接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/group")
@Api(description = "群组管理", tags = {"/group/*", "group"})
public class GroupController {

    @Resource
    private GroupService groupService;

    @RequestMapping(value = "/search", method = RequestMethod.POST)
    @ApiOperation(value = "获取分页")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "keywords", value = "关键字(群名称或创建人名称)", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "statusList", value = "状态", dataType = "List", paramType = "query"),
            @ApiImplicitParam(name = "dynamicList", value = "群组类型:null true false", dataType = "List", paramType =
                    "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<Group>> search(@RequestBody GroupSearch group) {
        Page<Group> page = groupService.search(group, group.getPage());
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), page);
    }

    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    @ApiOperation(value = "新增群组", nickname = "addGroup")
    @ApiImplicitParams(@ApiImplicitParam(name = "group", value = "新增群组集合", dataType = "Group",
            paramType = "body"))
    public JsonResult<String> addGroup(@RequestBody Group group) {
        String groupId = groupService.insert(group);
        return new JsonResult<>(true, UcI18nConstants.UC_ADD_SUCCESS.getName(), groupId);
    }

    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    @ApiOperation(value = "编辑群组", nickname = "updGroup")
    @ApiImplicitParams(@ApiImplicitParam(name = "group", value = "更新群组集合", dataType = "Group",
            paramType = "body"))
    public JsonResult editGroup(@RequestBody @Check(field = {"id"}) Group group) {
        groupService.update(group);
        return new JsonResult(true, UcI18nConstants.UC_EDIT_SUCCESS.getName());
    }

    @RequestMapping(value = "/addCondition", method = RequestMethod.PUT)
    @ApiOperation(value = "设置群组条件", nickname = "addCondition")
    @ApiImplicitParams(@ApiImplicitParam(name = "group", value = "设置群组条件", dataType = "Group",
            paramType = "body"))
    public JsonResult addCondition(@RequestBody @Check(field = {"id"}) Group group) {
        groupService.addCondition(group);
        return new JsonResult(true, UcI18nConstants.UC_OPT_SUCCESS.getName());
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "根据id获取对应试题")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true)
    )
    public JsonResult<Group> getGroup(@PathVariable(value = "id") @Check String id) {
        Group group = groupService.get(id);
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), group);
    }

    @DeleteMapping(value = "/delete")
    @ApiOperation(value = "删除群组", nickname = "delGroup")
    public JsonResult<String> batchDelete(@ApiParam(value = "数据源Id", required = true)
                                          @RequestBody List<String> ids) {
        List<Group> groups = groupService.listByIds(ids, Group.ID, Group.STATUS);
        if (CollectionUtils.isEmpty(groups)) {
            return new JsonResult<>(false, UcI18nConstants.UC_GROUP_NOT_EXIST.getName());
        }

        List<String> groupIds = new ArrayList<>(groups.size());
        groups.forEach(group -> {
            if (!CommonConstant.STATUS_ENABLED.equals(group.getStatus())) {
                groupIds.add(group.getId());
            }
        });

        if (groupIds.size() == 0) {
            return new JsonResult<>(false, UcI18nConstants.UC_ENABLED_NOT_DELETED.getName());
        }

        groupService.batchDelete(groupIds);
        return new JsonResult<>(true, UcI18nConstants.UC_DELETE_SUCCESS.getName());
    }

    @PutMapping(value = "/enable")
    @ApiOperation(value = "启用群组", nickname = "enGroup")
    public JsonResult<String> enable(@ApiParam(value = "数据源Id", required = true)
                                     @RequestBody List<String> ids) {
        groupService.updateStatus(ids, UcConstants.STATUS_ENABLED);
        return new JsonResult<>(true, UcI18nConstants.UC_ENABLED_SUCCESS.getName());
    }

    @PutMapping(value = "/disable")
    @ApiOperation(value = "停用群组", nickname = "disGroup")
    public JsonResult<String> disable(@ApiParam(value = "数据源Id", required = true)
                                      @RequestBody List<String> ids) {
        groupService.updateStatus(ids, UcConstants.STATUS_DISABLED);
        return new JsonResult<>(true, UcI18nConstants.UC_DISABLED_SUCCESS.getName());
    }

    @RequestMapping(value = "/getTree", method = RequestMethod.POST)
    @ApiOperation(value = "根据职位分类及群组树")
    public JsonResult<BlendTreeNode> getCategoryAndGroupTree() {
        BlendTreeNode rootNode = groupService.getCategoryAndGroupTree(ContextHandler.getUserId());
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), rootNode);
    }

    @GetMapping(value = "/putDynamicConditionToCache/{corpCode}")
    @ApiOperation(value = "刷新动态群组人员，定时刷新调用")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "corpCode", value = "corpCode", paramType = "path", required = true)
    )
    public JsonResult<String> putDynamicConditionToCache(@PathVariable(value = "corpCode") @Check String corpCode) {
        try {
            groupService.putDynamicConditionToCache(null, corpCode);
            return new JsonResult<>(true, "刷新成功", "");
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, "刷新失败", "");
        }
    }

    @PostMapping(value = "/quickAddGroup")
    @ApiOperation(value = "快捷创建群组")
    public JsonResult quickAddGroup(@RequestBody Group group) {
        try {
            groupService.quickAddGroup(group);
            return new JsonResult<>(true, "一键生成群组成功", "");
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, "一键生成群组失败", "");
        }
    }
}
