package com.purchase.uc.base;

/**
 * 数据权限种类
 *
 * @author TangFD 2020/12/23
 */
public enum DataPermissionEnum {
    /**
     * 仅能查看自己创建的数据
     */
    SELF("仅看本人"),
    ORG("授权部门"),
    ALL("全部"),
    ;

    private final String text;

    DataPermissionEnum(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
