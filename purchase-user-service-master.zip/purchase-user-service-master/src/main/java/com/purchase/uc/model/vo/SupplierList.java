package com.purchase.uc.model.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SupplierList {

    @ApiModelProperty("供应商id")
    String id;

    @ApiModelProperty("供应商名称")
    String name;
}
