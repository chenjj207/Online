package com.purchase.uc.mapper;

import com.purchase.uc.model.CorpInfo;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 * @author auto
 * @version 1.0
 * @since 2021-04-02 10:35:29
 */
public interface CorpInfoMapper extends QguBaseMapper<CorpInfo> {

}
