package com.purchase.uc.controller.open;

import com.purchase.uc.model.CorpInfo;
import com.purchase.uc.service.CorpInfoService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 开放接口
 *
 * @author lwl
 */
@RestController
@RequestMapping(value = "/public")
public class OpenController {
    @Resource
    private CorpInfoService corpInfoService;

    /**
     * saas同步新增租户
     */
    @PostMapping(value = "/sync-add-corp-info")
    public JsonResult<String> syncAddCorpInfo(@RequestBody CorpInfo corpInfo) {
        return new JsonResult<>(true, null, corpInfoService.syncAdd(corpInfo));
    }
}