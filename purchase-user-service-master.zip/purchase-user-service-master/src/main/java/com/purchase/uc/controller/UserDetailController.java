package com.purchase.uc.controller;

import com.purchase.uc.model.UserDetail;
import com.purchase.uc.service.UserDetailService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.*;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * UserDetail接口
 * todo: 请编写此处添加注释，注名此接口的作用
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/userDetail")
@Api(value = "UserDetail接口", tags = {"UserDetail接口"})
public class UserDetailController {

    @Resource
    private UserDetailService userDetailService;

    @GetMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userId", value = "USER_ID", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "sex", value = "性别(MALE：男，FEMALE：女，SECRET：保密)", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "birthday", value = "生日", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "degree", value = "最高学历/学位", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "major", value = "专业", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "school", value = "最后毕业学校", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "politics", value = "政治面貌", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "nationality", value = "国籍", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "onBoarding", value = "入职日期", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "startWorkDate", value = "开始工作时间", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "zipCode", value = "邮政编码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "marriage", value = "婚姻状况", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "joinPartyDate", value = "入党时间", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "familyTel", value = "家庭电话", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "officeTel", value = "办公电话", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "emergencyContactTel", value = "紧急联系信息", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "qq", value = "QQ号码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "wechat", value = "微信号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "otherContactInfo", value = "其它联系方式", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "birthPlace", value = "出生地", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "signature", value = "个人签名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "profession", value = "职业", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "rank", value = "级别", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "inWorkTime", value = "入职时间", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "province", value = "省", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "workFaceId", value = "工作照片", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "idCardFrontId", value = "身份证正面照片", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "idCardBackId", value = "身份证反面照片", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext1", value = "扩展字段1", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext2", value = "扩展字段2", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext3", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext4", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext5", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext6", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext7", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext8", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext9", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext10", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext11", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext12", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext13", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext14", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext15", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<UserDetail>> search(@ParamHide UserDetail userDetail, @ParamHide Page<UserDetail> page) {
        page = userDetailService.search(userDetail, page);
        return new JsonResult<Page<UserDetail>>(true, "查询成功", page);
    }

    @GetMapping(value = "/listAll")
    @ApiOperation(value = "获取所有数据")
    public JsonResult<List<UserDetail>> listAll() {
        return new JsonResult<List<UserDetail>>(true, "查询成功", userDetailService.listAll());
    }

    @PostMapping("")
    @ApiOperation(value = "新增接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userId", value = "USER_ID", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "sex", value = "性别(MALE：男，FEMALE：女，SECRET：保密)", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "birthday", value = "生日", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "degree", value = "最高学历/学位", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "major", value = "专业", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "school", value = "最后毕业学校", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "politics", value = "政治面貌", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "nationality", value = "国籍", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "onBoarding", value = "入职日期", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "startWorkDate", value = "开始工作时间", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "zipCode", value = "邮政编码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "marriage", value = "婚姻状况", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "joinPartyDate", value = "入党时间", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "familyTel", value = "家庭电话", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "officeTel", value = "办公电话", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "emergencyContactTel", value = "紧急联系信息", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "qq", value = "QQ号码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "wechat", value = "微信号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "otherContactInfo", value = "其它联系方式", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "birthPlace", value = "出生地", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "signature", value = "个人签名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "profession", value = "职业", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "rank", value = "级别", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "inWorkTime", value = "入职时间", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "province", value = "省", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "workFaceId", value = "工作照片", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "idCardFrontId", value = "身份证正面照片", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "idCardBackId", value = "身份证反面照片", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext1", value = "扩展字段1", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext2", value = "扩展字段2", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext3", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext4", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext5", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext6", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext7", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext8", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext9", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext10", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext11", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext12", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext13", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext14", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext15", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "id", dataType = "String", paramType = "query")
    })
    public JsonResult addUserDetail(@ParamHide UserDetail userDetail) {
        userDetailService.insert(userDetail);
        return new JsonResult(true, "添加成功");
    }

    @PutMapping("")
    @ApiOperation(value = "编辑接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userId", value = "USER_ID", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "sex", value = "性别(MALE：男，FEMALE：女，SECRET：保密)", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "birthday", value = "生日", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "degree", value = "最高学历/学位", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "major", value = "专业", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "school", value = "最后毕业学校", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "politics", value = "政治面貌", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "nationality", value = "国籍", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "onBoarding", value = "入职日期", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "startWorkDate", value = "开始工作时间", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "zipCode", value = "邮政编码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "marriage", value = "婚姻状况", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "joinPartyDate", value = "入党时间", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "familyTel", value = "家庭电话", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "officeTel", value = "办公电话", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "emergencyContactTel", value = "紧急联系信息", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "qq", value = "QQ号码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "wechat", value = "微信号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "otherContactInfo", value = "其它联系方式", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "birthPlace", value = "出生地", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "signature", value = "个人签名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "profession", value = "职业", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "rank", value = "级别", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "inWorkTime", value = "入职时间", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "province", value = "省", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "workFaceId", value = "工作照片", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "idCardFrontId", value = "身份证正面照片", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "idCardBackId", value = "身份证反面照片", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext1", value = "扩展字段1", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext2", value = "扩展字段2", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext3", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext4", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext5", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext6", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext7", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext8", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext9", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext10", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext11", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext12", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext13", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext14", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "ext15", value = "", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult editUserDetail(@ParamHide @Check(field = {"id"}) UserDetail userDetail) {
        userDetailService.update(userDetail);
        return new JsonResult(true, "编辑成功");
    }

    @GetMapping(value = "/{id}")
    @ApiOperation(value = "根据id获取对应试题")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true)
    )
    public JsonResult<UserDetail> getUserDetail(@PathVariable(value = "id") @Check String id) {
        UserDetail userDetail = userDetailService.get(id);
        return new JsonResult<>(true, "查询成功", userDetail);
    }

    @DeleteMapping(value = "")
    @ApiOperation(value = "根据传入的Id，删除数据", hidden = true)
    public JsonResult<String> batchDelete(@ApiParam(value = "数据源Id", required = true)
                                          @RequestBody List<String> ids) {
        userDetailService.batchDelete(ids);
        return new JsonResult<>(true, "删除成功");
    }
}
