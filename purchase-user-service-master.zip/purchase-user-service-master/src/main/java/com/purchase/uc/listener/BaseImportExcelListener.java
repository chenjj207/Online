package com.purchase.uc.listener;

import com.alibaba.excel.EasyExcelFactory;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.metadata.BaseRowModel;
import com.alibaba.excel.metadata.Sheet;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.purchase.uc.service.*;
import com.qgutech.qgyun.dev.common.utils.CommonConstant;
import com.qgutech.qgyun.dev.common.utils.FileUtil;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.client.FileFeignClient;
import com.purchase.uc.model.Position;
import com.purchase.uc.model.User;
import com.purchase.uc.model.vo.ExcelUser;
import com.purchase.uc.model.vo.UserCache;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.common.utils.excel.BaseExcelListener;
import com.qgutech.qgyun.framework.common.utils.excel.model.ErrorData;
import com.qgutech.qgyun.framework.database.mybatis.model.TreeNode;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.*;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 人员信息导入，修改导入基础操作类
 *
 * @param <T> 转换实体
 */
@Slf4j
@Getter
@Setter
public abstract class BaseImportExcelListener<T extends BaseRowModel> extends BaseExcelListener<T> {
    @Resource
    protected UserService userService;
    @Resource
    private OrgService orgService;
    @Resource
    private PositionService positionService;
    @Resource
    private UserRangeService userRangeService;
    @Resource
    private FileFeignClient fileFeignClient;
    @Resource
    private CategoryService categoryService;
    @Resource
    private RedisTemplate redisTemplate;
    @Value("${user.export.path:}")
    private String userExportPath;
    protected Map<String, String> allOrgNamePathAndIdMap;
    protected Map<String, String> authOrgNamePathAndIdMap;
    protected Map<String, Boolean> authIdMap;
    protected Map<String, String> positCodeAndIdMap;
    protected Map<String, Map<String, String>> categoryIdAndPNameAndIdMap;
    protected Map<String, String> categoryNamePathAndIdMap;
    protected Map<String, String> userLoginFieldAndIdMap;
    protected List<T> errorUsers = new ArrayList<>();
    private static final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    private static final String UC_IMPORT_ERROR = "UC_IMPORT_ERROR";
    private String errorFileId;
    protected String handlerUserId;
    protected int rowNum = 0;

    public void init(String userId) {
        handlerUserId = userId;
        getUserRange();
        getOrgMap();
        getUserLoginFieldMap();
        getPositCodeAndIdMap();
    }

    private void getUserRange() {
        List<String> referIds = userRangeService.getReferIdsByUserId(handlerUserId, null);
        authIdMap = new HashMap<>(referIds.size());
        referIds.forEach(id -> authIdMap.put(id, true));
    }

    private void getPositCodeAndIdMap() {
        String funCode = CommonConstant.COMMON_TREE_FUN_CODE_UC_POSITION_CATEGORY;
        categoryNamePathAndIdMap = categoryService.getCategoryNamePathAndIdMap(funCode);

        positCodeAndIdMap = new HashMap<>();
        categoryIdAndPNameAndIdMap = new HashMap<>();
        List<Position> positions = positionService.listAll();
        if (CollectionUtils.isEmpty(positions)) {
            return;
        }

        positions.forEach(p -> {
            String id = p.getId();
            String code = p.getCode();
            if (StringUtils.isNotEmpty(code)) {
                positCodeAndIdMap.put(code, id);
            }

            String categoryId = p.getCategoryId();
            Map<String, String> nameAndIdMap = categoryIdAndPNameAndIdMap.computeIfAbsent(categoryId,
                    k -> new HashMap<>());
            nameAndIdMap.put(p.getName(), id);
        });
    }

    private void getUserLoginFieldMap() {
        List<UserCache> users = userService.listAllFromCache();
        users = CollectionUtils.isEmpty(users) ? new ArrayList<>(0) : users;
        List<User> disabledUsers = userService.getAllDisabledUsers();
        disabledUsers = CollectionUtils.isEmpty(disabledUsers) ? new ArrayList<>(0) : disabledUsers;
        userLoginFieldAndIdMap = new HashMap<>((users.size() + disabledUsers.size()) * 5);
        for (UserCache user : users) {
            saveUserLoginFieldAndIdMap(user.getId(), user.getCode(), user.getLoginName()
                    , user.getEmail(), user.getMobile(), user.getIdCard());
        }

        for (User user : disabledUsers) {
            saveUserLoginFieldAndIdMap(user.getId(), user.getCode(), user.getLoginName()
                    , user.getEmail(), user.getMobile(), user.getIdCard());
        }
    }

    private void saveUserLoginFieldAndIdMap(String id, String code, String loginName,
                                            String email, String mobile, String idCard) {
        if (StringUtils.isEmpty(id)) {
            return;
        }

        if (code != null) {
            userLoginFieldAndIdMap.put(ExcelUser.CODE + UcConstants.SEPARATOR_CHARS + code, id);
        }
        if (loginName != null) {
            userLoginFieldAndIdMap.put(ExcelUser.LOGIN_NAME + UcConstants.SEPARATOR_CHARS + loginName, id);
        }
        if (email != null) {
            userLoginFieldAndIdMap.put(ExcelUser.EMAIL + UcConstants.SEPARATOR_CHARS + email, id);
        }
        if (mobile != null) {
            userLoginFieldAndIdMap.put(ExcelUser.MOBILE + UcConstants.SEPARATOR_CHARS + mobile, id);
        }
        if (idCard != null) {
            userLoginFieldAndIdMap.put(ExcelUser.ID_CARD + UcConstants.SEPARATOR_CHARS + idCard, id);
        }
    }

    private void getOrgMap() {
        TreeNode orgTree = orgService.getOrgTree();
        allOrgNamePathAndIdMap = new HashMap<>();
        authOrgNamePathAndIdMap = new HashMap<>();
        allOrgNamePathAndIdMap.put(orgTree.getName(), orgTree.getId());
        authOrgNamePathAndIdMap.put(orgTree.getName(), orgTree.getId());
        authIdMap.put(orgTree.getId(), true);
        iterateOrgTree(orgTree.getChild(), orgTree.getName(), ContextHandler.isSuperAdmin());
    }

    private void iterateOrgTree(List<TreeNode> childNodes,
                                String parentNamePath, boolean hasAuth) {
        if (CollectionUtils.isEmpty(childNodes)) {
            return;
        }

        for (TreeNode childNode : childNodes) {
            String namePath = (StringUtils.isEmpty(parentNamePath) ? "" : (parentNamePath + ".")) + childNode.getName();
            String id = childNode.getId();
            allOrgNamePathAndIdMap.put(namePath, id);
            boolean childHasAuth = false;
            if (hasAuth || BooleanUtils.isTrue(authIdMap.get(id))) {
                authOrgNamePathAndIdMap.put(namePath, id);
                authIdMap.put(id, true);
                childHasAuth = true;
            }

            iterateOrgTree(childNode.getChild(), namePath, childHasAuth);
        }
    }

    @Override
    protected void rollHandle(List<T> list) {
        if (errorUsers.size() == 0) {
            saveUser(list);
            return;
        }

        saveUserToCache(list);
    }

    private void saveUserToCache(List<T> list) {
        if (CollectionUtils.isEmpty(list)) {
            return;
        }

        String key = getCacheKey();
        ListOperations<String, T> operations = redisTemplate.opsForList();
        operations.leftPushAll(key, list);
        redisTemplate.expire(key, 30, TimeUnit.MINUTES);
    }

    private void errorToFile() {
        String filePath = getErrorTemplate();
        String fileId = IDUtils.getUUID19();
        String fullPath = userExportPath + File.separator + fileId + UcConstants.XLSX;
        ClassPathResource resource = new ClassPathResource(filePath);
        try (InputStream in = resource.getInputStream(); OutputStream output = new FileOutputStream(fullPath)) {
            ExcelWriter excelWriter = EasyExcelFactory.getWriterWithTemp(in, output, ExcelTypeEnum.XLSX, false);
            Sheet sheet = new Sheet(1, 3, getErrorExcelClass(), "", null);
            sheet.setStartRow(2);
            sheet.setAutoWidth(true);
            excelWriter.write(errorUsers, sheet);
            excelWriter.finish();
            MultipartFile multipartFile = FileUtil.convertMultipartFile(fullPath);
            JsonResult result = fileFeignClient.upload(multipartFile, UcConstants.APP_CODE, UC_IMPORT_ERROR);
            if (!result.isSuccess()) {
                throw new RuntimeException("upload file failed");
            }

            Map<String, Object> data = (Map<String, Object>) result.getData();
            setErrorFileId((String) data.get("fileId"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected abstract void saveUser(List<T> list);

    protected abstract String getCacheKey();

    protected abstract String getErrorTemplate();

    protected abstract Class<? extends ExcelUser> getErrorExcelClass();

    @Override
    protected void errorHandle(List<ErrorData> list) {

    }

    @Override
    protected void doAfterAllAnalysed() {
        if (errorUsers.size() > 0) {
            errorToFile();
        }
    }

    protected void addErrorData(List<String> errorData, int columnNum, String message) {
        errorData.add(MessageFormat.format("第{0}列：{1}", columnNum, message));
    }

    protected String validateOrg(int index, Object value, List<String> errorMsg) {
        String namePath = String.valueOf(value);
        String orgId = allOrgNamePathAndIdMap.get(namePath);
        //部门是否存在
        if (StringUtils.isNotEmpty(orgId)) {
            //部门是否有权限
            if (BooleanUtils.isTrue(authIdMap.get(orgId))) {
                return orgId;
            }

            addErrorData(errorMsg, index, "部门没有权限");
            return null;
        }

        for (String authNamePath : authOrgNamePathAndIdMap.keySet()) {
            if (namePath.contains(authNamePath)) {
                //部门是否是管辖范围内的，需要新增
                return UcConstants.NEED_ADD;
            }
        }

        String[] names = namePath.split("\\.");
        if (names.length < 2) {
            addErrorData(errorMsg, index, "无效的部门");
            return null;
        }

        if (StringUtils.isEmpty(allOrgNamePathAndIdMap.get(names[0]))) {
            addErrorData(errorMsg, index, "无效的部门");
            return null;
        }

        String path = names[0] + names[1];
        //一级部门是否存在，不存在，则有权限在根部门下新增
        if (StringUtils.isEmpty(allOrgNamePathAndIdMap.get(path))) {
            return UcConstants.NEED_ADD;
        }

        addErrorData(errorMsg, index, "部门新增没有权限");
        return null;
    }

    protected String validPosition(String positionCode, String category, int index, Object value,
                                   List<String> errorMsg) {
        if (StringUtils.isNotEmpty(positionCode)) {
            String positionId = positCodeAndIdMap.get(positionCode);
            if (StringUtils.isNotEmpty(positionId)) {
                if (ContextHandler.isSuperAdmin() || BooleanUtils.isTrue(authIdMap.get(positionId))) {
                    return positionId;
                }

                addErrorData(errorMsg, index, "岗位没有权限");
                return null;
            }
        }

        if (StringUtils.isEmpty(category)) {
            addErrorData(errorMsg, index - 2, "岗位类别不可为空");
            return null;
        }

        String categoryId = categoryNamePathAndIdMap.get(category);
        if (StringUtils.isEmpty(categoryId)) {
            return UcConstants.NEED_ADD;
        }

        Map<String, String> nameAndIdMap = categoryIdAndPNameAndIdMap.get(categoryId);
        nameAndIdMap = nameAndIdMap == null ? new HashMap<>(0) : nameAndIdMap;
        String positionId = nameAndIdMap.get(String.valueOf(value));
        if (StringUtils.isEmpty(positionId)) {
            return UcConstants.NEED_ADD;
        }

        if (ContextHandler.isSuperAdmin() || BooleanUtils.isTrue(authIdMap.get(positionId))) {
            return positionId;
        }

        addErrorData(errorMsg, index, "岗位没有权限");
        return null;
    }

    protected String getLeaderId(List<String> errorMsg, int index, Object value) {
        String userId =
                userLoginFieldAndIdMap.get(ExcelUser.CODE + UcConstants.SEPARATOR_CHARS + String.valueOf(value));
        if (StringUtils.isEmpty(userId)) {
            addErrorData(errorMsg, index, "隶属上级不存在");
        }

        return userId;
    }
}
