package com.purchase.uc.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpTreeModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "Org", description = "")
@Table(name = "t_uc_org")
public class Org extends BaseCorpTreeModel {
    public static final String SHOW_ORDER = "showOrder";
    public static final String ID_PATH = "idPath";
    public static final String NAME_PATH = "namePath";
    public static final String STATUS = "status";

    /**
     * 排序
     */
    @ApiModelProperty(value = "排序")
    private Float showOrder;

    /**
     * id路径
     */
    @ApiModelProperty(value = "id路径")
    private String idPath;

    private String code;

    /**
     * 名称路径
     */
    @ApiModelProperty(value = "名称路径")
    private String namePath;

    /**
     * 部门状态（DISABLED：激活，DISABLED：冻结）
     */
    @ApiModelProperty(value = "部门状态（DISABLED：激活，DISABLED：冻结）")
    private String status;
}
