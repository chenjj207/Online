package com.purchase.uc.model;

import com.qgutech.qgyun.framework.database.model.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * 分公司model
 *
 * @author lwl
 */
@Getter
@Setter
@ToString
@ApiModel(value = "Company", description = "")
@Table(name = "t_purchase_company")
public class Company extends BaseModel {

    public static final String COMPANY_ID = "companyId";
    public static final String COM_BM = "comBm";
    public static final String COM_NAME = "comName";
    public static final String SHORT_NAME = "shortName";

    /**
     * 公司id，从zydmall同步过来
     */
    @ApiModelProperty(value = "公司id，从zydmall同步过来")
    private Integer companyId;

    /**
     * 分公司编码
     */
    @ApiModelProperty(value = "分公司编码")
    private String comBm;

    /**
     * 分公司名称
     */
    @ApiModelProperty(value = "分公司名称")
    private String comName;

    /**
     * 分公司简称
     */
    @ApiModelProperty(value = "分公司简称")
    private String shortName;

    @ApiModelProperty(value = "区域编码")
    private String areaBm;

    @ApiModelProperty(value = "区域")
    private String areaName;

    @Transient
    private String createdByName;

    @Transient
    private String updatedByName;
}
