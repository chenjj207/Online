package com.purchase.uc.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "Role", description = "")
@Table(name = "t_uc_role")
public class Role extends BaseCorpModel {
    public static final String NAME = "name";
    public static final String CODE = "code";
    public static final String STATUS = "status";
    public static final String MANAGE = "manage";

    /**
     * 角色名称
     */
    @ApiModelProperty(value = "角色名称")
    private String name;

    /**
     * 角色编号
     */
    @ApiModelProperty(value = "角色编号")
    private String code;

    /**
     * 角色状态（激活ENABLED, 冻结DISABLED）
     */
    @ApiModelProperty(value = "角色状态（激活ENABLED, 冻结DISABLED）")
    private String status;

    /**
     * 是否管理端
     */
    @ApiModelProperty(value = "是否管理端")
    private Boolean manage;

    @Transient
    private int userCount;
    @Transient
    private boolean canEdit;
}
