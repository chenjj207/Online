package com.purchase.uc.service;

import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.model.UserRange;
import com.purchase.uc.model.vo.UserComponent;
import com.purchase.uc.utils.UcUtil;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.qgutech.qgyun.dev.common.utils.CommonUtils;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcException;
import com.purchase.uc.mapper.UserRangeMapper;
import com.purchase.uc.model.Org;
import com.purchase.uc.model.User;
import com.purchase.uc.model.vo.OrgComponent;
import com.purchase.uc.utils.UcRedisKeys;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * 管辖范围服务接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
@RefreshScope
public class UserRangeService extends BaseServiceImpl<UserRange> implements OrgComponentService, UserComponentService {

    @Resource
    private UserRangeMapper userRangeMapper;
    @Resource
    private OrgService orgService;
    @Resource
    private UserService userService;
    @Resource
    private PositionService positionService;
    @Resource
    private RedisTemplate redisTemplate;
    @Value("${qgyun.auth.redis.expiration-time:3600}")
    private Integer authExpireTime;

    public List<UserRange> listAll() {
        return userRangeMapper.selectAll();
    }

    /**
     * 根据查询条件，分页查询管辖范围列表
     *
     * @param range 查询条件 <ul>
     *              <li>keyword:查询关键字</li>
     *              <li>referId:查询的部门Id,包含子部门</li>
     *              <li>referTypes:关联类型：ORG POSITION GROUP</li>
     *              </ul>
     * @param page  分页对象
     * @return 管辖范围列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<UserRange> searchUserRange(UserRange range, Page<UserRange> page) {
        UcUtil.validatePage(page);
        if (range == null) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "param range not be null!");
        }

        List<String> referTypes = range.getReferTypes();
        if (CollectionUtils.isEmpty(referTypes)) {
            referTypes = new ArrayList<>(1);
            referTypes.add(UcConstants.RANG_TYPE_ORG);
            range.setReferTypes(referTypes);
        }

        String orgId = range.getReferId();
        if (StringUtils.isNotEmpty(orgId)) {
            List<String> orgIds = orgService.getChildIds(Collections.singleton(orgId), true);
            range.setOrgIds(orgIds);
        }

        Integer total = userRangeMapper.searchUserRangeTotal(range);
        if (total == null || total == 0) {
            return page;
        }

        page.setTotal(total);
        List<UserRange> userRanges = userRangeMapper.searchUserRange(range, page);
        page.setList(userRanges);
        setRangeInfo(userRanges);
        return page;
    }

    /**
     * 设置用户部门，岗位名称，授权人姓名
     */
    private void setRangeInfo(List<UserRange> userRanges) {
        if (CollectionUtils.isEmpty(userRanges)) {
            return;
        }

        Set<String> orgIds = new HashSet<>();
        Set<String> positionIds = new HashSet<>(userRanges.size());
//        Set<String> userIds = new HashSet<>(userRanges.size());
        for (UserRange userRange : userRanges) {
            User user = userRange.getUser();
            if (user == null) {
                continue;
            }

            userRange.setUserId(user.getId());
            orgIds.add(user.getOrgId());
            String positionId = user.getPositionId();
            if (StringUtils.isNotEmpty(positionId)) {
                positionIds.add(positionId);
            }

//            userIds.add(userRange.getCreatedBy());
        }

        Map<String, Org> orgMap = orgService.getOrgMap(orgIds);
//        Map<String, String> userIdAndNameMap = userService.getUserIdAndNameMap(userIds);
        Map<String, String> positionIdAndNameMap;
        if (CollectionUtils.isEmpty(positionIds)) {
            positionIdAndNameMap = new HashMap<>(0);
        } else {
            positionIdAndNameMap = positionService.getPositionIdAndNameMap(positionIds);
        }

        for (UserRange userRange : userRanges) {
            User user = userRange.getUser();
            if (user == null) {
                continue;
            }

            Org org = orgMap.get(user.getOrgId());
            if (org != null) {
                user.setOrgName(org.getName());
                user.setOrgNamePath(org.getNamePath());
            }

            String positionId = user.getPositionId();
            if (StringUtils.isNotEmpty(positionId)) {
                user.setPositionName(positionIdAndNameMap.get(positionId));
            }

//            userRange.setCreatedBy(userIdAndNameMap.get(userRange.getCreatedBy()));
        }
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<OrgComponent> searchOrg(UserRange userRange, Page<OrgComponent> page) {
        UcUtil.validatePage(page);
        if (userRange == null || StringUtils.isEmpty(userRange.getUserId())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "param userRange invalid!");
        }

        List<String> referTypes = userRange.getReferTypes();
        if (CollectionUtils.isEmpty(referTypes)) {
            referTypes = new ArrayList<>(1);
            referTypes.add(UcConstants.RANG_TYPE_ORG);
            userRange.setReferTypes(referTypes);
        }

        Integer total = userRangeMapper.searchOrgTotal(userRange);
        if (total == null || total == 0) {
            return page;
        }

        page.setTotal(total);
        List<UserRange> userRangeList = userRangeMapper.searchOrg(userRange, page);
        if (CollectionUtils.isEmpty(userRangeList)) {
            return page;
        }

        List<OrgComponent> orgComponents = new ArrayList<>(userRangeList.size());
        for (UserRange range : userRangeList) {
            OrgComponent component = new OrgComponent();
            component.setId(range.getId());
            component.setRelId(range.getReferId());
            String referType = range.getReferType();
            component.setType(referType);
            if (UcConstants.RANG_TYPE_ORG.equals(referType)) {
                component.setName(UcConstants.RANG_TYPE_ORG_TEXT + range.getOrgName());
                component.setNamePath(range.getNamePath());
            } else if (UcConstants.RANG_TYPE_POSITION.equals(referType)) {
                component.setName(UcConstants.RANG_TYPE_POSITION_TEXT + range.getPositName());
            } else if (UcConstants.RANG_TYPE_GROUP.equals(referType)) {
                component.setName(UcConstants.RANG_TYPE_GROUP_TEXT + range.getGroupName());
            }

            orgComponents.add(component);
        }

        page.setList(orgComponents);
        return page;
    }

    private void addUserRangeCache(List<String> userIds, List<String> relIds) {
        CommonUtils.threadPoolExecutor(o -> {
            String userRoleKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.RANGE_MANAGE;
            Map<String, Set<String>> resultMap = UcUtil.getResultMap(redisTemplate, userRoleKey, userIds);
            Map<String, Map<String, Set<String>>> allNewUserRangeIdsMap = new HashMap<>(userIds.size());
            for (String userId : userIds) {
                Set<String> set = resultMap.get(userId);
                if (CollectionUtils.isEmpty(set)) {
                    set = new HashSet<>();
                }

                set.addAll(new HashSet<>(relIds));
                Map<String, Set<String>> userRangeIdsMap = new HashMap<>(1);
                userRangeIdsMap.put(userId, set);
                allNewUserRangeIdsMap.put(userId, userRangeIdsMap);
            }

            HashOperations<String, String, Map<String, Set<String>>> opsForHash = redisTemplate.opsForHash();
            opsForHash.putAll(userRoleKey, allNewUserRangeIdsMap);
        });
    }

    private void delUserRangeCache(List<String> userIds, List<String> relIds) {
        String userRangeKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.RANGE_MANAGE;
        HashOperations<String, String, Map<String, Set<String>>> opsForHash = redisTemplate.opsForHash();
        Map<String, Set<String>> allUserRelIdsMap = UcUtil.getResultMap(redisTemplate, userRangeKey, userIds);
        Map<String, Map<String, Set<String>>> allNewUserGroupIdsMap = new HashMap<>();
        for (String userId : userIds) {
            Set<String> set = allUserRelIdsMap.get(userId);
            if (CollectionUtils.isEmpty(set)) {
                continue;
            }

            set.removeAll(relIds);
            Map<String, Set<String>> userGroupIdsMap = new HashMap<>(1);
            userGroupIdsMap.put(userId, set);
            allNewUserGroupIdsMap.put(userId, userGroupIdsMap);
        }

        opsForHash.putAll(userRangeKey, allNewUserGroupIdsMap);
    }

    /**
     * 根据用户Id和关联类型查询用户的管辖范围
     *
     * @param userId    用户Id
     * @param referType 关联类型，为空时，查询所有
     * @return 管辖范围Id列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<String> getReferIdsByUserId(String userId, String referType) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        Set<String> orgIds = getAllReferIdsFromCache(userId);
        if (CollectionUtils.isNotEmpty(orgIds)) {
            return new ArrayList<>(orgIds);
        }

        Example example = new Example(UserRange.class).selectProperties(UserRange.REFER_ID);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(UserRange.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(UserRange.USER_ID, userId);
        if (StringUtils.isNotEmpty(referType)) {
            criteria.andEqualTo(UserRange.REFER_TYPE, referType);
        }

        List<UserRange> userRanges = userRangeMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(userRanges)) {
            return new ArrayList<>(0);
        }

        List<String> orgIdList = userRanges.stream().map(UserRange::getReferId).collect(Collectors.toCollection(()
                -> new ArrayList<>(userRanges.size())));
        addUserRangeCache(Collections.singletonList(userId), orgIdList);
        return orgIdList;
    }

    /**
     * 根据用户ID获取当前用户所有管辖范围
     *
     * @param userId 用户ID
     * @return 管辖范围
     */
    public Set<String> getAllReferIdsFromCache(String userId) {
        String userRoleKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.RANGE_MANAGE;
        Map<String, Set<String>> resultMap = UcUtil.getResultMap(redisTemplate, userRoleKey,
                Collections.singletonList(userId));

        return resultMap.get(userId);
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void addOrgs(ComponentCondition condition) {
        if (condition == null
                || StringUtils.isEmpty(condition.getFunId())
                || CollectionUtils.isEmpty(condition.getRelIds())
                || StringUtils.isEmpty(condition.getRelType())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user range params invalid!");
        }

        String userId = condition.getFunId();
        List<String> relIds = condition.getRelIds();
        String relType = condition.getRelType();
        List<String> dbReferIds = getReferIdsByUserId(userId, relType);
        if (CollectionUtils.isNotEmpty(dbReferIds)) {
            relIds.removeAll(dbReferIds);
        }

        if (CollectionUtils.isEmpty(relIds)) {
            return;
        }

        List<UserRange> userRanges = new ArrayList<>(relIds.size());
        relIds.forEach(id -> userRanges.add(new UserRange(userId, id, relType)));
        batchInsert(userRanges);
        addUserRangeCache(Collections.singletonList(userId), relIds);
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void removeAllOrgs(ComponentCondition condition) {

    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void removeOrgs(ComponentCondition condition) {
        if (condition == null
                || StringUtils.isEmpty(condition.getFunId())
                || CollectionUtils.isEmpty(condition.getRelIds())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user range params invalid!");
        }

        String userId = condition.getFunId();
        List<String> relIds = condition.getRelIds();
        String relType = condition.getRelType();
        Example example = new Example(UserRange.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(UserRange.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(UserRange.USER_ID, userId)
                .andIn(UserRange.REFER_ID, relIds);
        if (StringUtils.isNotBlank(relType)) {
            criteria.andEqualTo(UserRange.REFER_TYPE, relType);
        }

        userRangeMapper.deleteByExample(example);
        delUserRangeCache(Collections.singletonList(userId), relIds);
        getReferIdsByUserId(userId, null);
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<String> listSelectedOrgId(ComponentCondition condition) {
        return null;
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<String> searchSelectedOrgId(ComponentCondition condition) {
        return null;
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<OrgComponent> searchSelectedOrg(ComponentCondition condition) {
        UserRange userRange = new UserRange();
        userRange.setUserId(condition.getFunId());
        userRange.setKeyword(condition.getKeywords());
        String relType = condition.getRelType();
        userRange.setReferType(relType);
        if (!UcConstants.RANG_TYPE_ORG.equals(condition.getRelType()) &&
                !UcConstants.RANG_TYPE_GROUP.equals(condition.getRelType()) &&
                !UcConstants.RANG_TYPE_POSITION.equals(condition.getRelType())) {
            userRange.setReferType("ALL");
        }

        userRange.setCorpCode(ContextHandler.getCorpCode());
        Page<OrgComponent> page = condition.getPage();
        return searchOrg(userRange, page);
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<String> findRangeListByUserId() {
        return userRangeMapper.findRangeListByUserId(ContextHandler.getUserId());
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void addUsers(ComponentCondition condition) {
        if (condition == null
                || StringUtils.isEmpty(condition.getFunId())
                || CollectionUtils.isEmpty(condition.getRelIds())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user range params invalid!");
        }

        String orgId = condition.getFunId();
        List<String> userIds = condition.getRelIds();
        List<UserRange> userRanges = new ArrayList<>(userIds.size());
        userIds.forEach(id -> userRanges.add(new UserRange(id, orgId, UcConstants.RANG_TYPE_ORG)));
        batchInsert(userRanges);
        addUserRangeCache(userIds, Collections.singletonList(orgId));
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void removeAllUsers(ComponentCondition condition) {
        if (condition == null || StringUtils.isEmpty(condition.getFunId())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user range params invalid!");
        }

        String orgId = condition.getFunId();
        List<String> userIds = listSelectedUserId(condition);
        Example example = new Example(UserRange.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(UserRange.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(UserRange.REFER_ID, orgId);
        criteria.andEqualTo(UserRange.REFER_TYPE, UcConstants.RANG_TYPE_ORG);

        userRangeMapper.deleteByExample(example);
        delUserRangeCache(userIds, Collections.singletonList(orgId));
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void removeUsers(ComponentCondition condition) {
        if (condition == null || StringUtils.isEmpty(condition.getFunId())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user range params invalid!");
        }

        String orgId = condition.getFunId();
        List<String> userIds = condition.getRelIds();
        Example example = new Example(UserRange.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(UserRange.CORP_CODE, ContextHandler.getCorpCode())
                .andIn(UserRange.USER_ID, userIds)
                .andEqualTo(UserRange.REFER_ID, orgId);
        criteria.andEqualTo(UserRange.REFER_TYPE, UcConstants.RANG_TYPE_ORG);

        userRangeMapper.deleteByExample(example);
        delUserRangeCache(userIds, Collections.singletonList(orgId));
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<String> listSelectedUserId(ComponentCondition condition) {
        if (condition == null || StringUtils.isEmpty(condition.getFunId())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "funId not be empty!");
        }

        String orgId = condition.getFunId();
        Example example = new Example(UserRange.class).selectProperties(UserRange.USER_ID);
        example.setDistinct(true);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(UserRange.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(UserRange.REFER_ID, orgId);
        criteria.andEqualTo(UserRange.REFER_TYPE, UcConstants.RANG_TYPE_ORG);

        List<UserRange> userRanges = userRangeMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(userRanges)) {
            return new ArrayList<>(0);
        }

        List<String> userIds = new ArrayList<>(userRanges.size());
        userRanges.forEach(user -> userIds.add(user.getUserId()));
        return userIds;
    }

    @Override
    public Page<String> searchSelectedUserId(ComponentCondition condition) {
        return null;
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<UserComponent> searchSelectedUser(ComponentCondition condition) {
        if (condition == null || StringUtils.isEmpty(condition.getFunId())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "funId not be empty!");
        }

        UserRange range = new UserRange(null, condition.getFunId(), condition.getRelType());
        Page<UserComponent> page = condition.getPage();
        range.setKeyword(condition.getKeywords());
        Integer total = userRangeMapper.searchUserTotal(range);
        if (total == null || total == 0) {
            return page;
        }

        page.setTotal(total);
        List<User> users = userRangeMapper.searchUser(range, page);
        if (CollectionUtils.isEmpty(users)) {
            return page;
        }

        List<UserComponent> userComponents = new ArrayList<>(users.size());
        for (User user : users) {
            userComponents.add(new UserComponent(user.getId(), user.getName(), user.getCode()));
        }

        page.setList(userComponents);
        return page;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, Integer> getUserIdAndRefCntMap(List<String> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userIds not be empty!");
        }

        List<UserRange> ranges = userRangeMapper.getUserIdAndRefCntMap(ContextHandler.getCorpCode(), userIds);
        if (CollectionUtils.isEmpty(ranges)) {
            return new HashMap<>(0);
        }

        Map<String, Integer> userIdAndRefCntMap = new HashMap<>(ranges.size());
        ranges.forEach(range -> userIdAndRefCntMap.put(range.getUserId(), range.getOrgCnt()));
        return userIdAndRefCntMap;
    }

    /**
     * 登录成功后，设置人员管辖的部门idPath 到缓存中
     */
    public void setUserRangeInfoToCache(String userId) {
        List<String> orgIds = getReferIdsByUserId(userId, UcConstants.RANG_TYPE_ORG);
        if (CollectionUtils.isEmpty(orgIds)) {
            return;
        }

        Map<String, Org> orgMap = orgService.getOrgMap(orgIds);
        if (MapUtils.isEmpty(orgMap)) {
            return;
        }

        List<String> orgIdsPaths = orgMap.values().stream()
                .map(Org::getIdPath)
                .collect(Collectors.toCollection(() -> new ArrayList<>(orgMap.size())));
        setUserRangeInfoToCache(userId, orgIdsPaths);
    }

    private void setUserRangeInfoToCache(String userId, List<String> orgIdPaths) {
        ListOperations<String, String> operations = redisTemplate.opsForList();
        String key = UcRedisKeys.getUserRangeKey(userId);
        redisTemplate.delete(key);
        if (CollectionUtils.isNotEmpty(orgIdPaths)) {
            operations.leftPushAll(key, orgIdPaths);
            redisTemplate.expire(key, authExpireTime, TimeUnit.SECONDS);
        }
    }
}
