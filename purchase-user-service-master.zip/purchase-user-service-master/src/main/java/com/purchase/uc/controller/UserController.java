package com.purchase.uc.controller;

import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.client.wx.entity.auth.ScanLoginDTO;
import com.purchase.uc.common.service.CommonExportTaskService;
import com.purchase.uc.model.Company;
import com.purchase.uc.model.Supplier;
import com.purchase.uc.model.UserRoleRel;
import com.purchase.uc.model.dto.InnerLoginDTO;
import com.purchase.uc.model.vo.*;
import com.purchase.uc.service.*;
import com.qgutech.qgyun.dev.client.cs.CsFeignClient;
import com.qgutech.qgyun.dev.common.utils.CommonUtils;
import com.qgutech.qgyun.dev.common.utils.DownloadUtils;
import com.qgutech.qgyun.dev.common.utils.JedisUtils;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcException;
import com.purchase.uc.common.model.CommonExportTask;
import com.purchase.uc.model.User;
import com.purchase.uc.utils.CusAccessObjectUtil;
import com.purchase.uc.utils.UcRedisKeys;
import com.qgutech.qgyun.framework.common.context.ContextConstant;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.model.TreeNode;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import com.qgutech.qgyun.saas.client.common.CorpAccountType;
import com.qgutech.qgyun.saas.client.model.Corp;
import com.qgutech.qgyun.saas.client.service.SaasCorpService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * User接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@Slf4j
@RequestMapping(value = "/user")
@Api(description = "人员管理", tags = {"/user/*", "user"})
public class UserController {
    @Resource
    private UserService userService;
    @Resource
    private AuthService authService;
    @Resource
    private RedisTemplate redisTemplate;
    @Resource
    private CommonExportTaskService exportTaskService;
    @Value("${user.export.path:}")
    private String userExportPath;
    @Resource
    private UserRoleRelService userRoleRelService;
    @Resource
    private UserRangeService userRangeService;
    @Resource
    private RoleAuthRelService roleAuthRelService;
    @Resource
    private CsFeignClient csFeignClient;
    @Resource
    private SaasCorpService saasCorpService;
    @Resource
    private SupplierService supplierService;
    @Resource
    private CompanyService companyService;

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ApiOperation(value = "校验登录接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "loginInfo", paramType = "body",
                    value = "登录校验信息：[corpCode：公司编号，username：用户名，password：密码]")
    })
    public JsonResult<?> validateLogin(@RequestBody Map<String, String> loginInfo, HttpServletRequest httpServletRequest) {
        return userService.validateLogin(loginInfo, httpServletRequest);
    }


//    public JsonResult<?> validateLogin(@RequestBody Map<String, String> loginInfo, HttpServletRequest httpServletRequest) {
//        return userService.validSecurityCode(loginInfo, () -> {
//            String corpCode = loginInfo.get(ContextConstant.CONTEXT_KEY_CORP_CODE);
//            if (StringUtils.isBlank(corpCode)) {
//                corpCode = UcConstants.CORP_CODE_DEFAULT;
//            }
//
//            ContextHandler.setCorpCode(corpCode);
//            String userId;
//            JsonResult<?> loginResult = getLoginResult(loginInfo, corpCode);
//            if (loginResult.isSuccess()) {
//                userId = (String) loginResult.getData();
//            } else {
//                return loginResult;
//            }
//            String dataType = loginInfo.get("dataType");
//            UserCache userCache = userService.getUserCache(userId);
//            log.info("userCache:{}", userCache);
//            if (userCache == null) {
//                log.info("userCache为空");
//                // 缓存用户不存在
//                return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
//                        UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
//            }else {
//                if (StringUtils.equals(dataType, "SUPPLIER")){
//                    if (!StringUtils.equals(userCache.getDataType(), "SUPPLIER") && !StringUtils.equals(userCache.getDataType(), "BRANCH_SUPPLIER")){
//                        return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
//                                UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
//                    }
//                }else {
//                    //datatype不一致， 则抛出登录失败异常
//                    if (!StringUtils.equalsIgnoreCase(dataType, userCache.getDataType())){
//                        return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
//                                UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
//                    }
//                }
//
//            }
//
//            String loginName = userCache.getLoginName();
//            boolean isSuperAdmin = isAdmin(loginName, userCache.getId());
//            ContextHandler.setSuperAdmin(isSuperAdmin);
//            /*JsonResult<?> corpCheckResult = checkCorpSetting(loginName);
//            if (!corpCheckResult.isSuccess()) {
//                return corpCheckResult;
//            }*/
//
//            Map<String, Object> data = new HashMap<>();
//            data.put(ContextConstant.CONTEXT_KEY_USER_ID, userId);
//            data.put(ContextConstant.CONTEXT_KEY_USERNAME, loginName);
//            data.put(ContextConstant.CONTEXT_KEY_NAME, userCache.getName());
//            data.put(ContextConstant.CONTEXT_KEY_CORP_CODE, ContextHandler.getCorpCode());
//            CusAccessObjectUtil.logRequest(httpServletRequest, null);
//            data.put(ContextConstant.CONTEXT_KEY_SUPER_ADMIN, isSuperAdmin);
//            /*Corp corp = saasCorpService.getCorpByCode(corpCode);
//            if (corp != null) {
//                data.put("corpName", corp.getName());
//            }*/
//            data.put("mobile",userCache.getMobile());
//            if (!isSuperAdmin) {
//                CommonUtils.threadPoolExecutor(context -> setAuthInfoToCache(userId));
//            }
//
//            String supplierId = userCache.getSupplierId();
//            Supplier supplier = null;
//            if (StringUtils.isNotBlank(supplierId)) {
//                supplier = supplierService.get(supplierId);
//            }
//
//            if (null != supplier) {
//                data.put("supplierId", supplier.getId());
//                data.put("supplierCode", supplier.getCode());
//                data.put("supplierDataType", supplier.getDataType());
//                data.put("supplierType", supplier.getType());
////                data.put("category", supplier.getCategory());
//            } else {
//                data.put("supplierId", "");
//                data.put("supplierCode", "");
//            }
//
//            String companyId = userCache.getCompanyId();
//            Company company = null;
//            if (StringUtils.isNotEmpty(companyId)) {
//                company = companyService.getByProperty(Company.COM_BM, companyId);
//            }
//
//            if (null != company) {
//                data.put("companyId", company.getId());
//                data.put("comBm", company.getComBm());
//                data.put("companyName", company.getComName());
//                data.put("companyShortName", company.getShortName());
//            } else {
//                data.put("companyId", "");
//                data.put("comBm", "");
//                data.put("companyName", "");
//                data.put("companyShortName", "");
//            }
//
//            Optional.ofNullable(loginInfo.get(UcConstants.DEFAULT_CODE_KEY)).ifPresent(redisTemplate::delete);
//            return new JsonResult<>(true, "登录成功", data);
//        });
//    }


    @RequestMapping(value = "/wxScanLogin", method = RequestMethod.POST)
    @ApiOperation(value = "企业微信-扫码登录")
    public JsonResult<?> wxScanLogin(@RequestBody @Valid ScanLoginDTO dto, HttpServletRequest request, HttpServletResponse response) {
        return userService.wxScanLogin(dto, request, response);
    }


    @RequestMapping(value = "/inner/login", method = RequestMethod.POST)
    @ApiOperation(value = "内部登录")
    public JsonResult<?> innerLogin(@RequestBody InnerLoginDTO innerLoginDTO, HttpServletResponse response){
        ContextHandler.setCorpCode(UcConstants.CORP_CODE_DEFAULT);
        Supplier supplier = supplierService.listByMemberAndCust(innerLoginDTO.getCustId(), innerLoginDTO.getMemberId());

        List<User> users = userService.listByProperty("supplierId", supplier.getId());
        if (CollectionUtils.isEmpty(users)){
            throw new UcException(UcErrorCode.LOGIN_ERROR_USER_NOT_EXIST);
        }
        User user = users.get(0);
        UserCache userCache = userService.getUserCache(user.getId());
        log.info("userCache:{}", userCache);
        if (userCache == null) {
            log.info("userCache为空");
            // 缓存用户不存在
            return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
                    UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
        }else {
            //datatype不一致， 则抛出登录失败异常
            if (!StringUtils.equalsIgnoreCase("SUPPLIER", userCache.getDataType())){
                return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
                        UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
            }
        }

        String loginName = userCache.getLoginName();
        boolean isSuperAdmin = isAdmin(loginName, userCache.getId());
        ContextHandler.setSuperAdmin(isSuperAdmin);
            /*JsonResult<?> corpCheckResult = checkCorpSetting(loginName);
            if (!corpCheckResult.isSuccess()) {
                return corpCheckResult;
            }*/

        Map<String, Object> data = new HashMap<>();
        data.put(ContextConstant.CONTEXT_KEY_USER_ID, user.getId());
        data.put(ContextConstant.CONTEXT_KEY_USERNAME, loginName);
        data.put(ContextConstant.CONTEXT_KEY_NAME, userCache.getName());
        data.put(ContextConstant.CONTEXT_KEY_CORP_CODE, ContextHandler.getCorpCode());
        data.put(ContextConstant.CONTEXT_KEY_SUPER_ADMIN, isSuperAdmin);
            /*Corp corp = saasCorpService.getCorpByCode(corpCode);
            if (corp != null) {
                data.put("corpName", corp.getName());
            }*/
        data.put("mobile",userCache.getMobile());
        if (!isSuperAdmin) {
            CommonUtils.threadPoolExecutor(context -> setAuthInfoToCache(user.getId()));
        }

        if (null != supplier) {
            data.put("supplierId", supplier.getId());
            data.put("supplierCode", supplier.getCode());
            data.put("supplierDataType", supplier.getDataType());
            data.put("supplierType", supplier.getType());
        } else {
            data.put("supplierId", "");
            data.put("supplierCode", "");
        }

        String companyId = userCache.getCompanyId();
        Company company = null;
        if (StringUtils.isNotEmpty(companyId)) {
            company = companyService.getByProperty(Company.COM_BM, companyId);
        }

        if (null != company) {
            data.put("companyId", company.getId());
            data.put("comBm", company.getComBm());
            data.put("companyName", company.getComName());
            data.put("companyShortName", company.getShortName());
        } else {
            data.put("companyId", "");
            data.put("comBm", "");
            data.put("companyName", "");
            data.put("companyShortName", "");
        }
        JsonResult jsonResult = userService.generateSession(data, false, response);
        return jsonResult;
    }


    @RequestMapping(value = "/udesk/info", method = RequestMethod.POST)
    @ApiOperation(value = "udesk登录用户信息")
    public JsonResult udeskInfo(){
        return  userService.udeskInfo();
    }

    private JsonResult<?> checkCorpSetting(String loginName) {
        if (ContextConstant.DEFAULT_CORP_CODE.equals(ContextHandler.getCorpCode())
                && ContextHandler.isSuperAdmin() && "admin".equals(loginName)) {
            // 主要用于平台初始化阶段，管理员进入平台
            return JsonResult.ok();
        }

        Corp corp = saasCorpService.getCorpByCode(ContextHandler.getCorpCode());
        if (corp == null) {
            return new JsonResult<>(false, UcI18nConstants.UC_CORP_NOT_EXIST.getName());
        }

        LocalDateTime now = LocalDateTime.now();
        boolean valid = Optional.of(corp)
                .filter(c -> UcConstants.STATUS_ENABLED.equals(c.getStatus()))
                .filter(c -> c.getEnabledAt().isBefore(now)
                        && (c.getDisabledAt() == null || c.getDisabledAt().isAfter(now)))
                .isPresent();
        if (!valid) {
            return new JsonResult<>(false, UcI18nConstants.UC_CORP_EXPIRED.getName());
        }

        String accountType = corp.getAccountType();
        if (!CorpAccountType.CONCURRENT.name().equals(accountType)) {
            return JsonResult.ok();
        }

        Integer userOnlineMax = corp.getMaxConcurrent();
        if (userOnlineMax == null) {
            return JsonResult.ok();
        }

        String sessionPrefix = "dev_" + ContextHandler.getCorpCode() + "_session:" + "*";
        Set<String> keys = JedisUtils.keys(redisTemplate, sessionPrefix);
        if (CollectionUtils.isEmpty(keys) || userOnlineMax > keys.size()) {
            return JsonResult.ok();
        }

        if (ContextHandler.isSuperAdmin()) {
            // 随机剔除登录的用户
            logoutWithRandom(userOnlineMax, keys);
        }

        return new JsonResult<>(false, UcI18nConstants.UC_CORP_CONCURRENT_TO_LIMIT.getName());

    }

    /**
     * 随机剔除登录的用户
     */
    private void logoutWithRandom(Integer userOnlineMax, Set<String> keys) {
        String userPrefix = "dev_" + ContextHandler.getCorpCode() + "_user:";
        int overNum = keys.size() - userOnlineMax + 1;
        HashOperations<String, String, String> opsForHash = redisTemplate.opsForHash();
        for (String key : keys) {
            if (overNum-- <= 0) {
                break;
            }

            redisTemplate.delete(key);
            String delUserId = opsForHash.get(key, ContextConstant.CONTEXT_KEY_USER_ID);
            String userKeyPrefix = userPrefix + delUserId;
            redisTemplate.delete(userKeyPrefix);
            redisTemplate.delete(userKeyPrefix + "-" + key);
//            如果允许同时登录(包括移动端情况)，此时不能删除
//            redisTemplate.delete(UcRedisKeys.getUserRangeKey(delUserId));
        }
    }

    /**
     * 所拥有的管辖范围和菜单数据权限缓存
     * Auth 模块中 与session同步刷新失效时间，所以没有维护缓存刷新功能
     */
    private void setAuthInfoToCache(String userId) {
        userRangeService.setUserRangeInfoToCache(userId);
        roleAuthRelService.setAuthDataPermissionInfoToCache(userId);
    }

    private JsonResult<?> getLoginResult(Map<String, String> loginInfo, String corpCode) {
        String loginName = loginInfo.get(ContextConstant.CONTEXT_KEY_USERNAME);
        String loginType = loginInfo.get(UcConstants.CONTEXT_KEY_LOGIN_TYPE);
        String openId = loginInfo.get(UcConstants.CONTEXT_KEY_OPENID);
        if (StringUtils.isNotBlank(openId) && UcConstants.LOGIN_TYPE_WECHAT.equals(loginType)) {
            User user = userService.getUserByOpenId(openId, corpCode);
            if (null == user) {
                return new JsonResult<>(false, UcI18nConstants.LOGIN_ERROR_USER_NOT_EXIST.getCode(),
                        UcI18nConstants.LOGIN_ERROR_USER_NOT_EXIST.getName(), null);
            }

            String status = user.getStatus();
            if (!UcConstants.STATUS_ENABLED.equals(status)) {
                return new JsonResult<>(false, UcI18nConstants.UC_STATUS_DISABLED.getCode(),
                        UcI18nConstants.UC_STATUS_DISABLED.getName(), null);
            }

            return new JsonResult<>(true, UcI18nConstants.LOGIN_SUCCESS.getName(), user.getId());
        }

        boolean register = UcConstants.LOGIN_TYPE_MOBILE_REGISTER.equals(loginType);
        if (UcConstants.LOGIN_TYPE_MOBILE.equals(loginType) || register) {
            String name = loginInfo.get(ContextConstant.CONTEXT_KEY_NAME);
            String mobile = loginInfo.get(UcConstants.CONTEXT_KEY_MOBILE);
            String code = loginInfo.get(UcConstants.CONTEXT_KEY_CODE);
            if (StringUtils.isEmpty(code) || StringUtils.isEmpty(mobile)) {
                return new JsonResult<>(false, UcI18nConstants.LOGIN_CODE_ERROR.getCode(),
                        UcI18nConstants.LOGIN_CODE_ERROR.getName(), null);
            }

            String codeKey = UcRedisKeys.VERIFY_CODE_PREFIX + corpCode + "_" + mobile;
            ValueOperations<String, String> operations = redisTemplate.opsForValue();
            String value = operations.get(codeKey);
            if (StringUtils.isEmpty(value)) {
                return new JsonResult<>(false, UcI18nConstants.LOGIN_CODE_ERROR.getCode(),
                        UcErrorCode.VERIFICATION_CODE_INVALID.getText(), null);
            }

            if (!value.equals(code)) {
                return new JsonResult<>(false, UcI18nConstants.LOGIN_CODE_ERROR.getCode(),
                        UcI18nConstants.LOGIN_CODE_ERROR.getName(), null);
            }

            return userService.mLoginAndSaveOuterUser(mobile, name, corpCode, openId, register);
        } else {
            String password = loginInfo.get(UcConstants.CONTEXT_KEY_PASSWORD);
            return userService.login(loginName, password, corpCode, openId);
        }
    }

    private boolean isAdmin(String loginName, String userId) {
        return ("admin".equals(loginName) || userRoleRelService.hasSuperAdminRole(userId));
    }

    private List<String> getAuthCodes(TreeNode authTree) {
        if (authTree == null) {
            return new ArrayList<>(0);
        }

        List<String> authCodes = new ArrayList<>();
        getAuthCodes(authTree.getChild(), authCodes);
        return authCodes;
    }

    private void getAuthCodes(List<TreeNode> treeNodes, List<String> authCodes) {
        if (CollectionUtils.isEmpty(treeNodes)) {
            return;
        }

        for (TreeNode treeNode : treeNodes) {
            authCodes.add(treeNode.getCode());
            getAuthCodes(treeNode.getChild(), authCodes);
        }
    }

    @ApiOperation(value = "获取验证码")
    @RequestMapping(value = "/securityImg", method = RequestMethod.GET)
    public JsonResult<SecurityCode> securityImg(String key) {
        return new JsonResult<>(true, null, userService.getSecurityImg(key));
    }

    @PostMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    public JsonResult<Page<User>> search(@RequestBody User user) {
        Page<User> page = new Page<>();
        page.setPageNum(user.getPageNum());
        page.setPageSize(user.getPageSize());
        page = userService.searchUser(user, page);

        return new JsonResult<>(true, "查询成功", page);
    }

    @PostMapping(value = "/supply-chain/page")
    @ApiOperation(value = "供应链用户分页")
    public JsonResult<Page<User>> supplyChainPage(@RequestBody User user) {
        Page<User> page = new Page<>();
        page.setPageNum(user.getPageNum());
        page.setPageSize(user.getPageSize());
        page = userService.supplyChainPage(user, page);
        return new JsonResult<>(true, "查询成功", page);
    }

    @GetMapping(value = "/listAll")
    @ApiOperation(value = "获取所有数据")
    public JsonResult<List<User>> listAll() {
        return new JsonResult<>(true, "查询成功", userService.listAll());
    }

    @PostMapping("/save")
    @ApiOperation(value = "新增用户", nickname = "addUser")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "姓名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "code", value = "员工编号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "loginName", value = "登录名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pwd", value = "密码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "email", value = "邮箱", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "mobile", value = "手机号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "idCard", value = "身份证号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "faceId", value = "用户头像", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "人员状态（ENABLED：激活，DISABLED：冻结，LEAVE：离职）",
                    dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "orgId", value = "部门主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "positionId", value = "岗位主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "leaderId", value = "隶属上级主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "level", value = "用户职级", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "entryAt", value = "入职日期", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "roleIds", value = "角色Id列表", dataType = "List", paramType = "query"),
            @ApiImplicitParam(name = "age", value = "用户年龄", dataType = "int", paramType = "query")
    })
    public JsonResult<?> save(@RequestBody User user) {
        return userService.saveUser(user);
    }

    @PutMapping("/update")
    @ApiOperation(value = "编辑用户", nickname = "updUser")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "姓名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "code", value = "员工编号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "loginName", value = "登录名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "email", value = "邮箱", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "mobile", value = "手机号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "idCard", value = "身份证号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "faceId", value = "用户头像", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "orgId", value = "部门主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "positionId", value = "岗位主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "leaderId", value = "隶属上级主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "level", value = "用户职级", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "entryAt", value = "入职日期", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "age", value = "用户年龄", dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult<?> editUser(@RequestBody @ParamHide @Check(field = {"id"}) User user) {
        return userService.updateUserAndRole(user);
    }

    @PutMapping("/updateUserOnly")
    @ApiOperation(value = "编辑用户", nickname = "updUser")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "姓名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "code", value = "员工编号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "loginName", value = "登录名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "email", value = "邮箱", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "mobile", value = "手机号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "idCard", value = "身份证号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "faceId", value = "用户头像", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "orgId", value = "部门主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "positionId", value = "岗位主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "leaderId", value = "隶属上级主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "level", value = "用户职级", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "entryAt", value = "入职日期", dataType = "Date", paramType = "query"),
            @ApiImplicitParam(name = "age", value = "用户年龄", dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult<?> updateUserOnly(@RequestBody @ParamHide @Check(field = {"id"}) User user) {
        return userService.updateUserOnly(user);
    }

    @RequestMapping(value = "/getUserInfo/{userId}", method = RequestMethod.GET)
    @ApiOperation(value = "仅包含用户基本信息，detail信息")
    public JsonResult<User> getUserInfo(@PathVariable("userId") String userId) {
        List<String> userIds = Collections.singletonList(userId);
        Map<String, User> userMap = userService.getUserMap(userIds, true, false);
        if (MapUtils.isEmpty(userMap)) {
            return new JsonResult<>();
        }

        return new JsonResult<>(true, null, userMap.get(userId));
    }

    @RequestMapping(value = "/getUserAllInfo", method = RequestMethod.GET)
    @ApiOperation(value = "根据id获取用户信息，包含detail，role 信息")
    public JsonResult<User> getUserAllInfo(String userId) {
        String paramId = userId;
        if (StringUtils.isBlank(userId)) {
            paramId = ContextHandler.getUserId();
        }

        User user = userService.getUserAllInfo(paramId);
        user.setCorpCode(ContextHandler.getCorpCode());
        List<String> authCodes = new ArrayList<>();
        if ((StringUtils.isBlank(userId) || paramId.equals(userId)) && ContextHandler.isSuperAdmin()) {
            authCodes.add("*");
            user.setAuthCodes(authCodes);
            return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), user);
        }

        TreeNode authTree = authService.getAuthTreeByUserId(paramId, null, false);
        if (authTree != null) {
            authCodes = getAuthCodes(authTree);
            user.setAuthCodes(authCodes);
        }

        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), user);
    }

    @RequestMapping(value = "/getFrontUser", method = RequestMethod.GET)
    @ApiOperation(value = "根据id获取用户信息，包含detail，role 信息")
    public JsonResult<User> getFrontUser(String userId) {
        String paramId = userId;
        if (StringUtils.isBlank(userId)) {
            paramId = ContextHandler.getUserId();
        }

        User user = userService.getFrontUser(paramId);
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), user);
    }

    @RequestMapping(value = "/info", method = RequestMethod.GET)
    @ApiOperation(value = "根据id获取用户信息，包含detail，auth 信息")
    public JsonResult<User> getFrontUserForAdmin(String userId) {
        String paramId = userId;
        if (StringUtils.isBlank(userId)) {
            paramId = ContextHandler.getUserId();
        }

        User user = userService.getFrontUserForAdmin(paramId);
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), user);
    }

    @PutMapping(value = "/enable")
    @ApiOperation(value = "激活用户", nickname = "enUser")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "userIds", value = "用户Id列表", dataType = "List", required = true, paramType =
                    "query")
    )
    public JsonResult<?> enable(@RequestBody List<String> userIds) {
        try {
            userService.updateStatus(userIds, UcConstants.STATUS_ENABLED);
            return new JsonResult<>(true, "启用成功");
        } catch (Exception e) {
            log.error("error", e);
            return new JsonResult<>(false, "启用失败");
        }
    }

    @PutMapping(value = "/disabled")
    @ApiOperation(value = "冻结用户", nickname = "disUser")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "userIds", value = "用户Id列表", dataType = "List", required = true, paramType =
                    "query")
    )
    public JsonResult<?> disabled(@RequestBody List<String> userIds) {
        try {
            userService.updateStatus(userIds, UcConstants.STATUS_DISABLED);
            return new JsonResult<>(true, "停用成功");
        } catch (Exception e) {
            log.error("error", e);
            return new JsonResult<>(false, "停用失败");
        }
    }

    @PutMapping(value = "/delete")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "userIds", value = "用户Id列表", dataType = "List", required = true, paramType =
                    "query")
    )
    public JsonResult<?> delete(@RequestBody List<String> userIds) {
        try {
            userService.updateStatus(userIds, UcConstants.STATUS_DELETED);
            return new JsonResult<>(true, "删除成功");
        } catch (Exception e) {
            log.error("error", e);
            return new JsonResult<>(false, "删除失败");
        }
    }

    @PutMapping(value = "/resetPwd")
    @ApiOperation(value = "重置用户登录密码", nickname = "resetPwd")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "userIds", value = "用户Id列表", dataType = "List", required = true, paramType =
                    "query")
    )
    public JsonResult<String> resetPwd(@RequestBody List<String> userIds) {
        try {
            return new JsonResult<>(true, "密码重置成功", userService.resetPwd(userIds));
        } catch (Exception e) {
            log.error("error", e);
            return new JsonResult<>(false, "密码重置失败");
        }
    }

    @GetMapping(value = "/putUserToRedis/{corpCode}")
    @ApiOperation(value = "刷新用户基本缓存")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "corpCode", value = "corpCode", paramType = "path", required = true)
    )
    public JsonResult<String> putUserToRedis(@PathVariable(value = "corpCode") @Check String corpCode) {
        try {
            userService.putUserToRedis(null, corpCode);
            return new JsonResult<>(true, "刷新成功", "");
        } catch (Exception e) {
            log.error("error", e);
            return new JsonResult<>(false, "刷新失败", "");
        }
    }

    @PostMapping(value = "/export")
    @ApiOperation(value = "导出用户基本信息", nickname = "exportUser")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "姓名/编号/登录名/手机号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "statusList", value = "人员状态（ENABLED：激活，DISABLED：冻结，LEAVE：离职）",
                    dataType = "List", paramType = "query"),
            @ApiImplicitParam(name = "order", value = "列表排序字段（默认为修改时间倒叙：updatedAt desc）", dataType = "String",
                    paramType = "query"),
            @ApiImplicitParam(name = "orgId", value = "部门主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "positionId", value = "岗位主键", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<?> export(@ParamHide User user) {
        try {
            deleteLastExportFile();
            CommonExportTask export = userService.export(user);
            return new JsonResult<>(true, "导出成功", export);
        } catch (Exception e) {
            log.error("error", e);
            return new JsonResult<>(false, "导出失败");
        }
    }

    private void deleteLastExportFile() {
        CommonExportTask lastExport = exportTaskService.getFinalExportByOptUserId(ContextHandler.getUserId()
                , UcConstants.EXPORT_TYPE_USER);
        if (lastExport == null) {
            return;
        }

        String fileId = lastExport.getFileId();
        String filePath = userExportPath + File.separator + fileId + UcConstants.XLSX;
        FileUtils.deleteQuietly(new File(filePath));
    }

    @GetMapping(value = "/downloadExport/{id}")
    @ApiOperation(value = "导出用户基本信息")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "id", paramType = "path", required = true)
    )
    public void downloadExport(@PathVariable("id") String id, HttpServletResponse response) {
        CommonExportTask exportTask = exportTaskService.get(id);
        if (exportTask == null || !UcConstants.STATUS_FINISHED.equals(exportTask.getStatus())) {
            return;
        }

        String filePath = userExportPath + File.separator + exportTask.getFileId() + UcConstants.XLSX;
        DownloadUtils.download(filePath, "人员信息表.xlsx", response);
    }

    @GetMapping(value = "/downloadImportError/{id}")
    @ApiOperation(value = "导出错误信息")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "id", paramType = "path", required = true)
    )
    public void downloadImportError(@PathVariable("id") String id, HttpServletResponse response) {
        String filePath = userExportPath + File.separator + id + UcConstants.XLSX;
        DownloadUtils.download(filePath, "错误信息表.xlsx", response);
    }

    @GetMapping(value = "/importUser/{fileId}")
    @ApiOperation(value = "导入人员信息", nickname = "importUser")
    public JsonResult<?> importUser(@PathVariable("fileId") String fileId) {
        try {
            String errorFileId = userService.importUser(fileId);
            return new JsonResult<>(StringUtils.isEmpty(errorFileId), "", errorFileId);
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, "导入失败");
        }
    }

    @GetMapping(value = "/importUpdateUser/{fileId}")
    @ApiOperation(value = "修改导入人员信息", nickname = "importUser")
    public JsonResult<?> importUpdateUser(@PathVariable("fileId") String fileId) {
        try {
            String errorFileId = userService.importUpdateUser(fileId);
            return new JsonResult<>(StringUtils.isEmpty(errorFileId), "", errorFileId);
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, "修改导入失败");
        }
    }

    @RequestMapping(value = "/searchAllAdmin", method = RequestMethod.POST)
    @ApiOperation(value = "获取公司所有管理员")
    public JsonResult<Page<User>> searchAllAdmin(@RequestBody UserCondition condition) {
        try {
            Page<User> page = userService.searchAllAdmin(condition);
            return new JsonResult<>(true, "查询成功", page);
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, "查询失败");
        }
    }

    @RequestMapping(value = "/downloadImportTemplate", method = RequestMethod.GET)
    @ApiOperation(value = "下载人员导入模板")
    public void downloadImportTemplate(HttpServletResponse response) throws IOException {
        downloadTemplate(response, "人员导入模板.xlsx", "importUserTemplate.xlsx");
    }

    @RequestMapping(value = "/downloadUpdateTemplate", method = RequestMethod.GET)
    @ApiOperation(value = "下载人员修改导入模板")
    public void downloadUpdateTemplate(HttpServletResponse response) throws IOException {
        downloadTemplate(response, "人员修改导入模板.xlsx", "updateUserTemplate.xlsx");
    }

    private void downloadTemplate(HttpServletResponse response, String filename, String templateName) throws
            IOException {
        response.setContentType("application/force-download");
        response.setHeader("Content-Transfer-Encoding", "binary");
        response.setHeader("Content-Disposition", "attachment; filename=\"" +
                URLEncoder.encode(filename, "UTF-8") + "\"");
        String filePath = "template" + File.separator + templateName;
        ClassPathResource resource = new ClassPathResource(filePath);
        try (InputStream in = resource.getInputStream()) {
            IOUtils.copy(in, response.getOutputStream());
        } catch (IOException e) {
            log.error("error", e);
        }
    }

    @PostMapping(value = "/app/modifyPwd")
    @ApiOperation(value = "用户修改密码")
    public JsonResult<?> resetPwd(@RequestBody Map<String, String> params) {
        String oldPassword = new String(Base64.getDecoder().decode(params.get("oldPassword")), StandardCharsets.UTF_8);
        String newPassword = new String(Base64.getDecoder().decode(params.get("newPassword")), StandardCharsets.UTF_8);
        String againPassword = new String(Base64.getDecoder().decode(params.get("againPassword")),
                StandardCharsets.UTF_8);

        try {
            userService.appModifyPwd(oldPassword, newPassword, againPassword);
            return new JsonResult<>(true, "修改重置成功");
        } catch (UcException e) {
            return new JsonResult<>(false, e.getMessage(), e.getErrorCode());
        }
    }

    @GetMapping(value = "/saveImport")
    @ApiOperation(value = "导入用户保存校验成功的人员基本信息")
    public JsonResult<?> saveImport() {
        try {
            String key = UcRedisKeys.USER_IMPORT + ContextHandler.getUserId();
            ListOperations<String, ImportExcelUser> operations = redisTemplate.opsForList();
            Long size = operations.size(key);
            if (size != null && size > 0) {
                userService.saveImport(operations.range(key, 0, size));
            }

            redisTemplate.expire(key, 0, TimeUnit.SECONDS);
            return new JsonResult<>(true, "导入用户保存成功");
        } catch (Exception e) {
            log.error("error", e);
            return new JsonResult<>(false, "导入用户保存失败");
        }
    }

    @GetMapping(value = "/updateImport")
    @ApiOperation(value = "修改导入用户保存校验成功的人员基本信息")
    public JsonResult<?> updateImport() {
        try {
            String key = UcRedisKeys.USER_IMPORT_UPDATE + ContextHandler.getUserId();
            ListOperations<String, UpdateImportExcelUser> operations = redisTemplate.opsForList();
            Long size = operations.size(key);
            if (size != null && size > 0) {
                userService.updateImport(operations.range(key, 0, -1));
            }

            redisTemplate.expire(key, 0, TimeUnit.SECONDS);
            return new JsonResult<>(true, "修改导入用户保存成功");
        } catch (Exception e) {
            log.error("error", e);
            return new JsonResult<>(false, "修改导入用户保存失败");
        }
    }

    @PostMapping("/saveOuterUser")
    @ApiOperation(value = "新增外部联系人", nickname = "saveOuterUser")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "姓名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "email", value = "邮箱", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "mobile", value = "手机号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "userDetail.company", value = "公司", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "userDetail.province", value = "省", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "userDetail.city", value = "市", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "userDetail.address", value = "公司地址", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "userDetail.profession", value = "职业/岗位", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "userDetail.remark", value = "备注", dataType = "String", paramType = "query")
    })
    public JsonResult<?> saveOuterUser(@RequestBody User user) {
        try {
            return userService.saveOuterUser(user);
        } catch (Exception e) {
            log.error("error", e);
            if (e instanceof UcException) {
                UcException ucException = (UcException) e;
                return new JsonResult<>(false, ucException.getErrorCode().getText());
            }

            return new JsonResult<>(false, e.getMessage());
        }
    }

    @PostMapping("/updateOuterUser")
    @ApiOperation(value = "更新外部联系人", nickname = "updateOuterUser")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "姓名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "email", value = "邮箱", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "mobile", value = "手机号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "userDetail.company", value = "公司", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "userDetail.companyAddress", value = "公司地址", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "userDetail.profession", value = "职业/岗位", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "userDetail.remark", value = "备注", dataType = "String", paramType = "query")
    })
    public JsonResult<?> updateOuterUser(@RequestBody User user) {
        try {
            return userService.updateOuterUser(user);
        } catch (Exception e) {
            log.error("error", e);
            if (e instanceof UcException) {
                UcException ucException = (UcException) e;
                return new JsonResult<>(false, ucException.getErrorCode().getText());
            }

            return new JsonResult<>(false, e.getMessage());
        }
    }

    /*@GetMapping("/forgetPass/getVerifyCode")
    @ApiOperation(value = "找回密码时获取短信验证码")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "mobile", value = "手机号", dataType = "String", paramType = "query"),
    })
    public JsonResult<?> getVerifyCode(@RequestParam("mobile") String mobile, @RequestParam("corpCode") String corpCode) {
        userService.getVerificationCode(mobile, corpCode);
        return new JsonResult<>(true, "发送成功");
    }*/

    @GetMapping("/forgetPass/checkVerifyCode")
    @ApiOperation(value = "找回密码时验证短信验证码")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "mobile", value = "手机号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "verifyCode", value = "验证码", dataType = "String", paramType = "query")
    })
    public JsonResult<?> checkVerifyCode(@RequestParam("mobile") String mobile,
                                         @RequestParam("verifyCode") String verifyCode) {
        userService.checkVerificationCode(mobile, verifyCode);
        return new JsonResult<>(true, "验证成功");
    }

    @PostMapping("/forgetPass/resetPwd")
    @ApiOperation(value = "找回密码时设置密码")
    public JsonResult<?> resetPassWord(@RequestBody Map<String, String> params) {
        String verifyCode = params.get("verifyCode");
        String mobile = params.get("mobile");
        userService.checkVerificationCode(mobile, verifyCode);
        String newPassword = params.get("newPassword");
        String againPassword = params.get("againPassword");
        String corpCode = params.get("corpCode");
        ContextHandler.setCorpCode(corpCode);
        userService.resetPwd(mobile, newPassword, againPassword, corpCode);
        return new JsonResult<>(true, "设置成功");
    }

    @GetMapping("/check/mobile")
    @ApiOperation(value = "校验手机号是否存在")
    public JsonResult<Boolean> checkMobileForSupplier(@RequestParam("mobile") String mobile,
                                         @RequestParam("id") String id) {
        Boolean result = userService.checkMobileForSupplier(mobile, id);
        return new JsonResult<>(true, "操作成功", result);
    }
}
