package com.purchase.uc.model;

import com.purchase.uc.base.DataPermissionEnum;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.List;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "RoleAuthRel", description = "")
@Table(name = "t_uc_role_auth_rel")
public class RoleAuthRel extends BaseCorpModel {


    public static final String ROLE_ID = "roleId";
    public static final String AUTH_ID = "authId";
    public static final String AUTH_CODE = "authCode";
    public static final String DATA_PERMISSION = "dataPermission";
    /**
     * 角色id
     */
    @ApiModelProperty(value = "角色id")
    private String roleId;

    /**
     * 权限id
     */
    @ApiModelProperty(value = "权限id")
    private String authId;

    /**
     * 权限编码，冗余字段，用于数据权限
     */
    @ApiModelProperty(value = "权限编码，冗余字段")
    private String authCode;

    /**
     * 数据权限，为空表示拥有全部数据权限
     */
    private DataPermissionEnum dataPermission;

    @Transient
    private List<String> authIds;
    @Transient
    private List<RoleAuthRel> authRelList;

    public RoleAuthRel() {
    }

    public RoleAuthRel(String roleId, String authId) {
        this.roleId = roleId;
        this.authId = authId;
    }

    public DataPermissionEnum getDataPermission() {
        return dataPermission == null ? DataPermissionEnum.ALL : dataPermission;
    }
}
