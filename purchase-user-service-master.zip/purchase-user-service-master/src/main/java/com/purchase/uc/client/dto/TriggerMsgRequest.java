package com.purchase.uc.client.dto;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;
import lombok.Data;


/**
 * @author jidonglin
 * @Description:
 * @date 2023/11/8  10:02
 */
@Data
@ApiModel(description = "消息请求")
public class TriggerMsgRequest {
    private String business;
    private String scene;
    private JSONObject smsParam;
    private JSONObject wxpfParam;
    private JSONObject qywxParam;

}
