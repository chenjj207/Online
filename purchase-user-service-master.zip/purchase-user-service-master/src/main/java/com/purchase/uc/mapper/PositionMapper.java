package com.purchase.uc.mapper;

import com.purchase.uc.model.Position;
import com.purchase.uc.model.vo.PositionSearch;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * todo: 请编写此处添加注释，注名此接口的作用
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
public interface PositionMapper extends QguBaseMapper<Position> {

    List<Position> searchPosition(@Param("position") PositionSearch search, @Param("page") Page<Position> pageInfo, @Param
            ("orders") String orders);

    int getPositionTotal(@Param("position") PositionSearch position);
}
