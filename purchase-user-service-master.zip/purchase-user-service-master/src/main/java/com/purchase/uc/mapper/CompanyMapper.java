package com.purchase.uc.mapper;

import com.purchase.uc.model.Company;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 分公司Mapper
 *
 * @author lwl
 */
public interface CompanyMapper extends QguBaseMapper<Company> {

    String selectComBmByShortName(@Param("shortName")String shortName);
}
