package com.purchase.uc.model.vo;

import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * 使用范围分页查询条件
 */
@Getter
@Setter
@ToString
@ApiModel(value = "UseScopeCondition", description = "使用范围查询条件")
public class UseScopeCondition {
    /**
     * 业务主键
     */
    @ApiModelProperty(value = "业务主键")
    private String id;

    /**
     * 功能编号
     */
    @ApiModelProperty(value = "功能编号")
    private String funCode;

    /**
     * 关联类型id
     */
    @ApiModelProperty(value = "关联类型id")
    private String funId;

    /**
     * 人员工号/姓名/用户名/手机
     */
    @ApiModelProperty(value = "人员工号/姓名/用户名/手机")
    private String keywords;

    /**
     * 待授权的资源Id列表
     */
    @ApiModelProperty(value = "人员工号/姓名/用户名/手机")
    private List<String> resIds;

    /**
     * 被授权的人员Id列表
     */
    @ApiModelProperty(value = "被授权的人员Id列表")
    private List<String> userIds;

    /**
     * 角色Id列表
     */
    @ApiModelProperty(value = "角色Id列表")
    private List<String> roleIds;

    /**
     * 公司编号，区分租户
     */
    @ApiModelProperty(value = "公司编号，区分租户")
    private String corpCode;

    /**
     * 当前页
     */
    @ApiModelProperty(value = "当前页")
    private Integer pageNum;

    /**
     * 分页大小
     */
    @ApiModelProperty(value = "分页大小")
    private Integer pageSize;

    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人")
    private String createdBy;

    @ApiModelProperty(value = "分页对象", hidden = true)
    public <T> Page<T> getPage() {
        Page<T> page = new Page<>();
        if (null != pageNum) {
            page.setPageNum(pageNum);
        }

        if (null != pageSize) {
            page.setPageSize(pageSize);
        }

        return page;
    }
}
