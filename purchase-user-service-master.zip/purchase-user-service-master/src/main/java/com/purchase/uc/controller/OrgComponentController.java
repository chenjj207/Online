package com.purchase.uc.controller;

import com.purchase.uc.model.vo.OrgComponent;
import com.purchase.uc.service.OrgService;
import com.purchase.uc.service.UserService;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.util.List;

/**
 * 选择组织组件Component接口
 * http://veln-els/[path:(route)][method]?{condition}
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/orgComponent")
@Api(value = "OrgComponent接口", tags = {"OrgComponent接口"})
@SuppressWarnings("unchecked")
public class OrgComponentController {
    private static final String HTTP = "http://";
    @Resource
    private RestTemplate restTemplate;
    @Resource
    private OrgService orgService;
    @Resource
    private UserService userService;

    @RequestMapping(value = "/searchOrg", method = RequestMethod.POST)
    @ApiOperation(value = "获取选人组件待选组织")
    public JsonResult<Page<OrgComponent>> searchOrg(@RequestBody ComponentCondition condition) {
        // TODO(汤法东):查询所有待待选分页
        return new JsonResult<>(true, "查询成功", new Page<>());
    }

    @RequestMapping(value = "/addAllOrgs", method = RequestMethod.POST)
    @ApiOperation(value = "选部门组件添加组织")
    public JsonResult<Page<String>> addAllOrgs(@RequestBody ComponentCondition condition) {

        // TODO(汤法东):根据条件查询所有待添加的分批调用 addOrgs
        return new JsonResult<>(true, "查询成功", new Page<>());
    }

    @RequestMapping(value = "/addOrgs", method = RequestMethod.POST)
    public JsonResult<String> addOrgs(@RequestBody ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/addOrgs";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    @RequestMapping(value = "/removeAllOrgs", method = RequestMethod.POST)
    public JsonResult<String> removeAllOrgs(@RequestBody ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/removeAllOrgs";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    @RequestMapping(value = "/removeOrgs", method = RequestMethod.POST)
    public JsonResult<String> removeOrgs(@RequestBody ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/removeOrgs";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    @RequestMapping(value = "/listSelectedOrgId", method = RequestMethod.POST)
    public JsonResult<List<String>> listSelectedOrgId(@RequestBody ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/listSelectedOrgId";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    @RequestMapping(value = "/searchSelectedOrgId", method = RequestMethod.POST)
    public JsonResult<Page<String>> searchSelectedOrgId(@RequestBody ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/searchSelectedOrgId";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    @RequestMapping(value = "/searchSelectedOrg", method = RequestMethod.POST)
    public JsonResult<Page<OrgComponent>> searchSelectedOrg(@RequestBody ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/searchSelectedOrg";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    /**
     * 此接口为选组织组件完成后的列表接口，具体实现在commonRelController中，
     * 此处定义为了前端组件上接口统一
     */
    @RequestMapping(value = "/searchSelectedOrgPage", method = RequestMethod.POST)
    @ApiOperation(value = "获取选组织组件已选组织详细信息")
    public JsonResult<Page> searchSelectedOrgPage(@RequestBody ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/searchOrg";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }
}
