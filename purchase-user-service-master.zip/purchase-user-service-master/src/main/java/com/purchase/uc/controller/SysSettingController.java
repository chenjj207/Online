package com.purchase.uc.controller;

import com.purchase.uc.model.SysSetting;
import com.purchase.uc.service.SysSettingService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * SysSettingController 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2020-04-07 16:42:35
 */
@RestController
@RequestMapping(value = "/sysSetting")
@Api(value = "SysSettingController", tags = {"SysSettingController 服务提供类"})
public class SysSettingController {

    @Resource
    private SysSettingService sysSettingService;

    @GetMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "initPassword", value = "初始密码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<SysSetting>> search(@ParamHide SysSetting sysSetting, @ParamHide Page<SysSetting> page) {
        page = sysSettingService.search(sysSetting, page);
        return new JsonResult<>(true, "查询成功", page);
    }

    @GetMapping(value = "/listAll")
    @ApiOperation(value = "获取所有数据")
    public JsonResult<List<SysSetting>> listAll() {
        return new JsonResult<>(true, "查询成功", sysSettingService.listAll());
    }

    @PostMapping("/add")
    @ApiOperation(value = "新增接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "initPassword", value = "初始密码", dataType = "String", paramType = "query"),
    })
    public JsonResult<String> addSysSetting(@RequestBody SysSetting sysSetting) {
        String id = sysSettingService.insert(sysSetting);
        return new JsonResult<>(true, "添加成功", id);
    }

    @PutMapping("/edit")
    @ApiOperation(value = "编辑接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "initPassword", value = "初始密码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult editSysSetting(@RequestBody @Check(field = {"id"}) SysSetting sysSetting) {
        sysSettingService.update(sysSetting);
        return new JsonResult(true, "编辑成功");
    }

    @GetMapping(value = "/default")
    @ApiOperation(value = "获取默认setting")
    public JsonResult<SysSetting> getDefaultSetting() {
        SysSetting sysSetting = sysSettingService.defaultSetting();
        return new JsonResult<>(true, "查询成功", sysSetting);
    }

    @GetMapping(value = "/{id}")
    @ApiOperation(value = "根据id获取数据")
    @ApiImplicitParams(@ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true))
    public JsonResult<SysSetting> getSysSetting(@PathVariable(value = "id") String id) {
        SysSetting sysSetting = sysSettingService.get(id);
        return new JsonResult<>(true, "查询成功", sysSetting);
    }

    @DeleteMapping(value = "/delete")
    @ApiOperation(value = "根据传入的Id，删除数据")
    public JsonResult<String> batchDelete(@RequestBody List<String> ids) {
        sysSettingService.batchDelete(ids);
        return new JsonResult<>(true, "删除成功");
    }
}
