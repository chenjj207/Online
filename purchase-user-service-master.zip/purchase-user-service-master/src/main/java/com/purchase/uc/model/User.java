package com.purchase.uc.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "User", description = "")
@Table(name = "t_uc_user")
public class User extends BaseCorpModel {
    public static final String NAME = "name";
    public static final String CODE = "code";
    public static final String LOGIN_NAME = "loginName";
    public static final String PWD = "pwd";
    public static final String EMAIL = "email";
    public static final String MOBILE = "mobile";
    public static final String ID_CARD = "idCard";
    public static final String FACE_ID = "faceId";
    public static final String STATUS = "status";
    public static final String ORG_ID = "orgId";
    public static final String POSITION_ID = "positionId";
    public static final String LEADER_ID = "leaderId";
    public static final String ENTRY_AT = "entryAt";
    public static final String LEVEL = "level";
    public static final String AGE = "age";
    public static final String TYPE = "type";
    public static final String INIT_PASSWORD = "initPassword";
    public static final String SUPPLIER_ID = "supplierId";
    public static final String DATA_TYPE = "dataType";
    public static final String COMPANY_ID = "companyId";
    public static final String COMPANY_NAME = "companyName";
    public static final String POSITION = "position";

    /**
     * 姓名
     */
    @ApiModelProperty(value = "姓名")
    private String name;

    /**
     * 员工编号
     */
    @ApiModelProperty(value = "员工编号")
    private String code;

    /**
     * 登录名
     */
    @ApiModelProperty(value = "登录名")
    private String loginName;

    /**
     * 密码（MD5）
     */
    @ApiModelProperty(value = "密码（MD5）")
    private String pwd;

    /**
     * 邮箱
     */
    @ApiModelProperty(value = "邮箱")
    private String email;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号")
    private String mobile;

    /**
     * 身份证号
     */
    @ApiModelProperty(value = "身份证号")
    private String idCard;

    /**
     * 用户头像
     */
    @ApiModelProperty(value = "用户头像")
    private String faceId;

    /**
     * 人员状态（ENABLED：激活，DISABLED：冻结，LEAVE：离职）
     */
    @ApiModelProperty(value = "人员状态（ENABLED：激活，DISABLED：冻结，LEAVE：离职）")
    private String status;

    /**
     * 部门主键
     */
    @ApiModelProperty(value = "部门主键")
    private String orgId;

    /**
     * 岗位主键
     */
    @ApiModelProperty(value = "岗位主键")
    private String positionId;

    /**
     * 隶属上级主键
     */
    @ApiModelProperty(value = "隶属上级主键")
    private String leaderId;

    /**
     * 入职日期
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "入职日期")
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class, as = LocalDate.class)
    private LocalDate entryAt;

    /**
     * 用户年龄
     */
    @ApiModelProperty(value = "用户年龄")
    private Integer age;

    /**
     * 级别
     */
    @ApiModelProperty(value = "用户职级")
    private String level;

    /**
     * 用户类型
     */
    @ApiModelProperty(value = "用户类型：INNER(内部人员)/OUTER(外部人员)")
    private String type;

    /**
     * 供应商
     */
    private String supplierId;

    /**
     * 从zydmall同步过来的id
     */
    private Integer userId;

    /**
     * 职位/人员类型
     */
    private String position;

    /**
     * 所属公司名称
     */
    private String companyName;

    /**
     * 类型(SUPPLIER: 直供供应商，USER: 用户(供应链、子公司)，BRANCH_SUPPLIER：分部供应商)
     */
    private String dataType;

    /**
     * 类型(国内:CN,国外:FW)
     */
//    private String category;

    /**
     * 分公司编号
     */
    private String companyId;

    @Transient
    private String orgName;
    @Transient
    private String orgNamePath;
    @Transient
    private String positionName;
    @Transient
    private String relId;
    @Transient
    private String order;
    @Transient
    private List<String> statusList;
    @Transient
    private String leaderName;
    @Transient
    private List<Role> roles;
    @Transient
    private UserDetail userDetail;
    @Transient
    private String positionCode;
    @Transient
    private List<String> roleIds;
    @Transient
    private List<String> authCodes;
    @Transient
    private boolean includeChild;
    @Transient
    private String orgCode;
    @Transient
    private String positCategory;
    @Transient
    private String leaderCode;
    @Transient
    private int orgCnt;
    @Transient
    private List<String> labels;
    @Transient
    private Collection<String> userIds;
    /**
     * 微信号
     */
    @Transient
    private String wechat;
    /**
     * 当前人员是否有管理员角色
     */
    @Transient
    private boolean adminRole;
    /**
     * 头像
     */
    @Transient
    private String faceUrl;

    /**
     * 类型(SUPPLIER: 供应商，USER: 用户(供应链、子公司))
     */
    @Transient
    private List<String> dataTypeList;

    /**
     * 关键字
     */
    @Transient
    private String keywords;

    @ApiModelProperty(
            value = "页码（pageNum=0 并且 pageSize=0 查全部）",
            allowableValues = "1"
    )
    @Transient
    private Integer pageNum;
    @ApiModelProperty(
            value = "页大小（pageNum=0 并且 pageSize=0 查全部）",
            allowableValues = "10"
    )
    @Transient
    private Integer pageSize;
    /**
     * 初始密码
     */
    @ApiModelProperty(value = "初始密码")
    private String initPassword;

    @Transient
    @ApiModelProperty(value = "供应商数据类型 SELF, UNITE")
    private String supplierDataType;

    @Transient
    @ApiModelProperty(value = "供应商状态 状态（WAIT_AUDIT: 待审核、NO_PASS: 未通过、PASS: 已通过）")
    private String supplierStatus;

    @Transient
    @ApiModelProperty(value = "SUPPLIER_APPLY: 供应商申请、BACKGROUND_ADD: 后台新增、 SCM_ADD：scm新增")
    private String supplierType;

}
