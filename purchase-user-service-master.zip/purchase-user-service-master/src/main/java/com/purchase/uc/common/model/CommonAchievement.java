
package com.purchase.uc.common.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;

/**
 * 学时学分成就体系
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019-05-23 09:41:22
 */
@Getter
@Setter
@ToString
@ApiModel(value = "CommonAchievement", description = "学时学分成就体系")
@Table(name = "t_common_achievement")
public class CommonAchievement extends BaseCorpModel {


    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID")
    private String userId;

    /**
     * 项目类型：COURSE_SELECT(选课)/COURSE_MAP_STEP(学习地图阶段)
     */
    @ApiModelProperty(value = "项目类型：COURSE_SELECT(选课)/COURSE_MAP_STEP(学习地图阶段)")
    private String proType;

    /**
     * 项目ID
     */
    @ApiModelProperty(value = "项目ID")
    private String proId;

    /**
     * 资源类型：COURSE(课程)/EXAM(考试)
     */
    @ApiModelProperty(value = "资源类型：COURSE(课程)/EXAM(考试)")
    private String srcType;

    /**
     * 资源ID
     */
    @ApiModelProperty(value = "资源ID")
    private String srcId;

    /**
     * 课程学时
     */
    @ApiModelProperty(value = "课程学时")
    private Float period;

    /**
     * 课程学分
     */
    @ApiModelProperty(value = "课程学分")
    private Float score;

    /**
     * 获得课程学时
     */
    @ApiModelProperty(value = "获得课程学时")
    private Float gainPeriod;

    /**
     * 获得课程学分
     */
    @ApiModelProperty(value = "获得课程学分")
    private Float gainScore;

}
