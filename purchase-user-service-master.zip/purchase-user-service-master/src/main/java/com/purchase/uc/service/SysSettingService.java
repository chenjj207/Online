package com.purchase.uc.service;

import com.purchase.uc.mapper.SysSettingMapper;
import com.purchase.uc.model.SysSetting;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.List;


/**
 * SysSettingService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2020-04-07 16:42:35
 */
@Service
public class SysSettingService extends BaseServiceImpl<SysSetting> {

    @Resource
    private SysSettingMapper mapper;

    public List<SysSetting> listAll() {
        return mapper.selectAll();
    }

    public SysSetting defaultSetting() {
        String corpCode = ContextHandler.getCorpCode();
        if (StringUtils.isBlank(corpCode)) {
            List<SysSetting> sysSettings = mapper.selectAll();
            return CollectionUtils.isEmpty(sysSettings) ? null : sysSettings.get(0);
        }

        return getByProperty(SysSetting.CORP_CODE, corpCode);
    }


    public String getDefaultPwd() {
        SysSetting sysSetting = defaultSetting();
        if (sysSetting == null) {
            return "000000";
        }

        return sysSetting.getInitPassword();
    }


    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<SysSetting> search(SysSetting sysSetting, Page<SysSetting> page) {
        Assert.notNull(sysSetting, "sysSetting can not be null!");
        Example example = genConditionExample(sysSetting);
        example.orderBy(SysSetting.UPDATED_AT).desc();
        page = super.search(example, page);
        if (CollectionUtils.isEmpty(page.getList())) {
            return page;
        }

        List<SysSetting> sysSettingList = page.getList();
        packSysSettingData(sysSettingList);
        return page;
    }

    private Example genConditionExample(SysSetting sysSetting) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        String initPassword = sysSetting.getInitPassword();
        if (StringUtils.isNotBlank(initPassword)) {
            criteria.andEqualTo(SysSetting.INIT_PASSWORD, initPassword);
        }


        return example;
    }

    /**
     * 分页数据处理
     */
    private void packSysSettingData(List<SysSetting> sysSettingList) {
        if (CollectionUtils.isEmpty(sysSettingList)) {
            return;
        }
    }
}
