package com.purchase.uc.controller;

import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.model.Role;
import com.purchase.uc.service.RoleService;
import com.purchase.uc.service.UserRoleRelService;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Role接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/role")
@Api(description = "角色管理", tags = {"/role/*", "role"})
public class RoleController {

    @Resource
    private RoleService roleService;
    @Resource
    private UserRoleRelService userRoleRelService;

    @GetMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "角色名称", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "角色状态（激活ENABLED, 冻结DISABLED）", dataType = "String", paramType
                    = "query"),
            @ApiImplicitParam(name = "manage", value = "是否管理端", dataType = "Boolean", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<Role>> search(@ParamHide Role role, @ParamHide Page<Role> page) {
        page = roleService.search(role, page);
        return new JsonResult<Page<Role>>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), page);
    }

    @GetMapping(value = "/listAll")
    @ApiOperation(value = "获取用户拥有的角色列表[有权限的，自己创建的，所有学员角色]")
    public JsonResult<List<Role>> listAll() {
        String userId = ContextHandler.getUserId();
        List<Role> roles = roleService.listAuthByUserId(userId);
        if (CollectionUtils.isEmpty(roles)) {
            return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName());
        }

        List<String> roleIds = new ArrayList<>(roles.size());
        roles.forEach(role -> {
            roleIds.add(role.getId());
            role.setCanEdit(ContextHandler.isSuperAdmin() || userId.equals(role.getCreatedBy()));
        });
        Map<String, Integer> roleIdAndUserCntMap = userRoleRelService.getRoleIdAndUserCntMap(roleIds);
        if (MapUtils.isEmpty(roleIdAndUserCntMap)) {
            return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), roles);
        }

        for (Role role : roles) {
            Integer count = roleIdAndUserCntMap.get(role.getId());
            role.setUserCount(count == null ? 0 : count);
        }

        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), roles);
    }

    @GetMapping(value = "/listAllUserRole")
    @ApiOperation(value = "获取所有启用的学员角色,不包含外部学员角色")
    public JsonResult<List<Role>> listAllUserRole() {
        List<Role> roles = roleService.listAllUserRole();
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), roles);
    }

    @PostMapping("/save")
    @ApiOperation(value = "新增角色", nickname = "addRole")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "角色名称", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "角色状态（激活ENABLED, 冻结DISABLED）", dataType = "String", paramType
                    = "query"),
            @ApiImplicitParam(name = "manage", value = "是否管理端", dataType = "Boolean", paramType = "query"),
            @ApiImplicitParam(name = "id", dataType = "String", paramType = "query")
    })
    public JsonResult addRole(@ParamHide Role role) {
        if (StringUtils.isEmpty(role.getStatus())) {
            role.setStatus(UcConstants.STATUS_ENABLED);
        }

        return roleService.insertRole(role);
    }

    @PutMapping("/update")
    @ApiOperation(value = "编辑角色", nickname = "updRole")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "角色名称", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "角色状态（激活ENABLED, 冻结DISABLED）", dataType = "String", paramType
                    = "query"),
            @ApiImplicitParam(name = "manage", value = "是否管理端", dataType = "Boolean", paramType = "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult editRole(@ParamHide @Check(field = {"id"}) Role role) {
        return roleService.updRole(role);
    }

    @GetMapping(value = "/{id}")
    @ApiOperation(value = "根据id获取对应试题")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true)
    )
    public JsonResult<Role> getRole(@PathVariable(value = "id") @Check String id) {
        Role role = roleService.get(id);
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), role);
    }

    @DeleteMapping(value = "/disabled")
    @ApiOperation(value = "禁用角色", nickname = "disRole")
    public JsonResult<String> disabled(@ApiParam(value = "角色Id列表", required = true)
                                       @RequestBody List<String> ids) {
        try {
            roleService.disabled(ids);
            return new JsonResult<>(true, UcI18nConstants.UC_DISABLED_SUCCESS.getName());
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, UcI18nConstants.UC_DISABLED_ERROR.getName());
        }
    }

    @DeleteMapping(value = "/enabled")
    @ApiOperation(value = "启用角色", nickname = "enRole")
    public JsonResult<String> enabled(@ApiParam(value = "角色Id列表", required = true)
                                      @RequestBody List<String> ids) {
        try {
            roleService.enabled(ids);
            return new JsonResult<>(true, UcI18nConstants.UC_ENABLED_SUCCESS.getName());
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, UcI18nConstants.UC_ENABLED_ERROR.getName());
        }
    }

    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ApiOperation(value = "删除角色", nickname = "delRoles")
    public JsonResult<String> delete(@ApiParam(value = "角色Id列表", required = true)
                                     @RequestBody List<String> ids) {
        try {
            roleService.delete(ids);
            return new JsonResult<>(true, UcI18nConstants.UC_DELETE_SUCCESS.getName());
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, UcI18nConstants.UC_DELETE_ERROR.getName());
        }
    }
}
