package com.purchase.uc.service;

import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.model.Category;
import com.qgutech.qgyun.dev.common.model.vo.BlendTreeNode;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.qgutech.qgyun.dev.common.utils.CommonConstant;
import com.qgutech.qgyun.dev.common.utils.TreeUtil;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcException;
import com.purchase.uc.mapper.PositionMapper;
import com.purchase.uc.model.Position;
import com.purchase.uc.model.vo.PositionSearch;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

import static com.purchase.uc.model.Position.*;
import static com.qgutech.qgyun.framework.database.model.BaseCorpModel.CORP_CODE;
import static com.qgutech.qgyun.framework.database.model.BaseModel.ID;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
public class PositionService extends BaseServiceImpl<Position> {

    @Resource
    private PositionMapper positionMapper;
    @Resource
    private CategoryService categoryService;
    @Resource
    private UserRangeService userRangeService;

    public List<Position> listAll() {
        Example example = new Example(Position.class);
        example.createCriteria().andEqualTo(CORP_CODE, ContextHandler.getCorpCode());

        return positionMapper.selectByExample(example);
    }

    /**
     * 该方法用于保存岗位实体
     *
     * @param position 岗位信息
     * @return 主键
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String insert(Position position) {
        if (null == position) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "岗位为空");
        }

        String name = position.getName();
        if (StringUtils.isEmpty(name)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "岗位名称为空");
        }

        name = name.replace("，", ",");
        if (!name.contains(",")) {
            // 插入一条用户管辖范围权限
            String id = super.insert(position);
            ComponentCondition condition = new ComponentCondition();
            condition.setFunId(ContextHandler.getUserId());
            condition.setRelType(UcConstants.RANG_TYPE_POSITION);
            condition.setRelIds(Collections.singletonList(id));
            userRangeService.addOrgs(condition);

            return id;
        }

        String[] splitNames = name.split(",");
        if (splitNames.length <= 0) {
            return null;
        }

        String[] splitCode = new String[0];
        String code = position.getCode();
        if (StringUtils.isNotBlank(code)) {
            code = code.replace("，", ",");
            splitCode = code.split(",");
        }

        List<Position> positions = new ArrayList<>(splitNames.length);
        for (int i = 0; i < splitNames.length; i++) {
            String splitName = splitNames[i];
            Position pos = new Position();
            pos.setName(splitName);
            if (splitCode.length > i) {
                pos.setCode(splitCode[i]);
            }

            pos.setCategoryId(position.getCategoryId());
            positions.add(pos);
        }

        List<String> idList = super.batchInsert(positions);

        // 插入一条用户管辖范围权限
        ComponentCondition condition = new ComponentCondition();
        condition.setFunId(ContextHandler.getUserId());
        condition.setRelType(UcConstants.RANG_TYPE_POSITION);
        condition.setRelIds(idList);
        userRangeService.addOrgs(condition);
        return "";
    }

    /**
     * 该方法用于根据类别ID查询类别下群组的数量
     *
     * @param categoryId 类别ID
     * @return 群组数量
     */
    public int countByCategory(String categoryId) {
        if (StringUtils.isEmpty(categoryId)) {
            return 0;
        }

        return getCountByProperty(categoryId, CATEGORY_ID);
    }

    private int getCountByProperty(String propertyValue, String property) {
        Example example = new Example(Position.class);
        Example.Criteria criteria = example.selectProperties(ID).createCriteria();
        criteria.andEqualTo(property, propertyValue)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        example.setCountProperty(ID);

        return positionMapper.selectCountByExample(example);
    }

    private int getCountByProperty(List<String> propertyValue, String property) {
        Example example = new Example(Position.class);
        Example.Criteria criteria = example.selectProperties(ID).createCriteria();
        criteria.andIn(property, propertyValue)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        example.setCountProperty(ID);

        return positionMapper.selectCountByExample(example);
    }

    /**
     * 该方法用于岗位的分页查询
     *
     * @param condition 查询条件 name:模糊查询 类别:精确查询 编码:模糊查询
     * @param pageInfo  分页条件
     * @return 分页结果
     */
    @Transactional(readOnly = true)
    public Page<Position> search(PositionSearch condition, Page<Position> pageInfo) {
        if (!ContextHandler.isSuperAdmin()) {
            condition.setUserId(ContextHandler.getUserId());
        }

        String categoryId = condition.getCategoryId();
        if (StringUtils.isNotEmpty(categoryId)) {
            List<String> categoryIdList = new ArrayList<>();
            categoryIdList.add(categoryId);
            if (condition.isIncludeChild()) {
                categoryIdList = categoryService.getAllNodeIdByNodeId(categoryId);
            }

            if (CollectionUtils.isEmpty(categoryIdList)) {
                return new Page<>();
            }

            condition.setCategoryIdList(categoryIdList);
        }

        int pageTotal = positionMapper.getPositionTotal(condition);
        if (pageTotal <= 0) {
            return pageInfo;
        }

        List<Position> positions = positionMapper.searchPosition(condition, pageInfo, "updated_at DESC");
        if (CollectionUtils.isNotEmpty(positions)) {
            pageInfo.setTotal(pageTotal);
            pageInfo.setList(positions);
            pageInfo.setSize(positions.size());
        }

        List<String> categoryIds = new ArrayList<>();
        for (Position position : positions) {
            if (position == null) {
                continue;
            }

            categoryIds.add(position.getCategoryId());
        }

        Map<String, String> namePathMap = categoryService.getNamePathMap(categoryIds);
        for (Position position : positions) {
            position.setCategoryNamePath(namePathMap.get(position.getCategoryId()));
        }

        return pageInfo;
    }

    /**
     * 该方法用于判断公司岗位编码是否存在
     *
     * @param code 岗位编码
     * @return 是否存在
     */
    public boolean existByCode(String code) {
        if (StringUtils.isEmpty(code)) {
            throw new IllegalArgumentException("Code is empty when existByCode!");
        }
        List<String> codeList = Arrays.asList(StringUtils.split(code, ","));
        int count = getCountByProperty(codeList, CODE);
        return count > 0;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, String> getPositionIdAndNameMap(Collection<String> positIds) {
        if (CollectionUtils.isEmpty(positIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "positIds not be empty!");
        }

        List<Position> positions = listByIds(new ArrayList<>(positIds), ID, NAME);
        if (CollectionUtils.isEmpty(positions)) {
            return new HashMap<>(0);
        }

        Map<String, String> positionIdAndNameMap = new HashMap<>(positions.size());
        for (Position position : positions) {
            positionIdAndNameMap.put(position.getId(), position.getName());
        }

        return positionIdAndNameMap;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, String> getPositCodeAndIdMap() {
        List<Position> positions = listAll();
        if (CollectionUtils.isEmpty(positions)) {
            return new HashMap<>(0);
        }

        Map<String, String> positionCodeAndIdMap = new HashMap<>(positions.size());
        positions.forEach(position -> positionCodeAndIdMap.put(position.getCode(), position.getId()));
        return positionCodeAndIdMap;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, Position> getPositionMap(Set<String> positIds) {
        if (CollectionUtils.isEmpty(positIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "positIds not be empty!");
        }

        List<Position> positions = listByIds(new ArrayList<>(positIds));
        if (CollectionUtils.isEmpty(positions)) {
            return new HashMap<>(0);
        }

        Map<String, Position> positionMap = new HashMap<>(positions.size());
        positions.forEach(position -> positionMap.put(position.getId(), position));

        return positionMap;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<Position> getPositionByCategoryIds(List<String> categoryIdList) {
        Example example = new Example(Position.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        criteria.andIn(CATEGORY_ID, categoryIdList);
        return positionMapper.selectByExample(example);
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public BlendTreeNode getCategoryAndPositionTree(String userId) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        List<Category> commonTreeList = categoryService.list(CommonConstant
                .COMMON_TREE_FUN_CODE_UC_POSITION_CATEGORY);
        if (CollectionUtils.isEmpty(commonTreeList)) {
            return new BlendTreeNode();
        }

        BlendTreeNode root = getAndRemoveRoot(commonTreeList);
        List<String> categoryIdList = commonTreeList.stream().map(Category::getId).collect(Collectors.toList());
        List<Position> positionList = selectRangePosition(categoryIdList);
        if (CollectionUtils.isEmpty(positionList)) {
            return TreeUtil.getBlendTree(commonTreeList, root);
        }

        Category commonTree;
        for (Position position : positionList) {
            commonTree = new Category();
            commonTree.setCategory(false);
            commonTree.setName(position.getName());
            commonTree.setId(position.getId());
            commonTree.setpId(position.getCategoryId());
            commonTreeList.add(commonTree);
        }

        return TreeUtil.getBlendTree(commonTreeList, root);
    }

    private BlendTreeNode getAndRemoveRoot(List<Category> categoryList) {
        if (CollectionUtils.isEmpty(categoryList)) {
            return null;
        }

        for (Iterator<Category> iterator = categoryList.iterator(); iterator.hasNext(); ) {
            Category category = iterator.next();
            if ("*".equals(category.getpId())) {
                iterator.remove();
                return new BlendTreeNode(category.getId(), category.getpId(), category.getName());
            }
        }

        return null;
    }

    /**
     * 根据岗位类别Id列表，获取岗位Id集合
     *
     * @param categoryIds 类别Id列表
     * @return 岗位Id映射，key:岗位Id，value:true
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, Boolean> getPositionIdMapByCategoryIds(List<String> categoryIds) {
        if (CollectionUtils.isEmpty(categoryIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "categoryIds not be empty!");
        }

        List<Position> positions = selectRangePosition(categoryIds);

        if (CollectionUtils.isEmpty(positions)) {
            return new HashMap<>(0);
        }

        Map<String, Boolean> positionIdMap = new HashMap<>(positions.size());
        positions.forEach(position -> positionIdMap.put(position.getId(), true));
        return positionIdMap;
    }

    /**
     * @param categoryIds
     * @return
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<Position> selectRangePosition(List<String> categoryIds) {
        PositionSearch position = new PositionSearch();
        if (!ContextHandler.isSuperAdmin()) {
            position.setUserId(ContextHandler.getUserId());
        }

        if (CollectionUtils.isNotEmpty(categoryIds)) {
            position.setCategoryIdList(categoryIds);
        }

        position.setCorpCode(ContextHandler.getCorpCode());
        return positionMapper.searchPosition(position, null, null);
    }

    /**
     * 新增岗位类别及岗位
     *
     * @param categoryPath 岗位类别全路径
     * @param code         岗位编号
     * @param name         岗位名称
     * @return 岗位Id
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String addPosition(String categoryPath, String code, String name) {
        if (StringUtils.isEmpty(categoryPath) || StringUtils.isEmpty(name)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "categoryPath and name not be empty!");
        }

        String funCode = CommonConstant.COMMON_TREE_FUN_CODE_UC_POSITION_CATEGORY;
        Map<String, String> categoryNamePathAndIdMap = categoryService.getCategoryNamePathAndIdMap(funCode);
        String[] categorys = categoryPath.split("\\.");
        String categoryName = "", parentId = null;
        String corpCode = ContextHandler.getCorpCode();
        for (String category : categorys) {
            categoryName += StringUtils.isEmpty(categoryName) ? category : ("." + category);
            String pId = categoryNamePathAndIdMap.get(categoryName);
            if (StringUtils.isNotEmpty(pId)) {
                parentId = pId;
                continue;
            }

            Category tree = new Category();
            tree.setCorpCode(corpCode);
            tree.setpId(parentId);
            tree.setName(category);
            tree.setFunCode(funCode);
            parentId = categoryService.insert(tree);
        }

        Position position = new Position();
        position.setCategoryId(parentId);
        position.setCorpCode(corpCode);
        position.setCode(code);
        position.setName(name);
        return insert(position);
    }
}
