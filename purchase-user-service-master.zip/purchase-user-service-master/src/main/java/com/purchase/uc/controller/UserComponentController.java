package com.purchase.uc.controller;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.model.Org;
import com.purchase.uc.service.*;
import com.purchase.uc.utils.UcUtil;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.qgutech.qgyun.dev.common.model.vo.MultiUserComponent;
import com.qgutech.qgyun.dev.common.model.vo.UserComponent;
import com.qgutech.qgyun.dev.common.utils.CommonUtils;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcException;
import com.purchase.uc.model.Role;
import com.purchase.uc.model.User;
import com.purchase.uc.model.UserRoleRel;
import com.purchase.uc.model.vo.UserCache;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * 选择人员组件Component接口
 * http://veln-els/[path:(route)][method]?{condition}
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/userComponent")
@Api(value = "UserComponent接口", tags = {"UserComponent接口"})
@SuppressWarnings("unchecked")
public class UserComponentController {
    private static final String HTTP = "http://";
    @Resource
    private RestTemplate restTemplate;
    @Resource
    private OrgService orgService;
    @Resource
    private UserService userService;
    @Resource
    private PositionService positionService;
    @Resource
    private CategoryService commonTreeService;
    @Resource
    private GroupService groupService;
    @Resource
    private UserRangeService userRangeService;
    @Resource
    private UserRoleRelService userRoleRelService;
    @Resource
    private RoleService roleService;
    @Resource
    private RedisTemplate redisTemplate;

    private static final int PAGE_SIZE = 5000;

    @RequestMapping(value = "/searchUser", method = RequestMethod.POST)
    @ApiOperation(value = "获取选人组件待选人员")
    public JsonResult<Page<UserComponent>> searchUser(@RequestBody ComponentCondition condition) {
        if (condition == null) {
            return new JsonResult<>(false, "relId not be empty");
        }

        List<User> waitingUser = getWaitingUserTwo(condition);
        Page<UserComponent> page = condition.getPage();
        if (CollectionUtils.isEmpty(waitingUser)) {
            return new JsonResult<>(true, "查询成功", page);
        }

        int total = waitingUser.size();
        page.setTotal(total);
        int startRow = page.getStartRow();
        if (total < startRow) {
            return new JsonResult<>(true, "查询成功", page);
        }

        int endRow = page.getEndRow();
        List<User> userCacheList = waitingUser.subList(startRow, Math.min(total, endRow));
        List<UserComponent> userComponents;
        if (condition.isMultiColumnSelector()) {
            userComponents = userCacheList.stream()
                    .map(cache -> new MultiUserComponent(cache.getId(), cache.getName(), cache.getCode(),
                            cache.getLoginName(), cache.getEmail(), cache.getMobile()))
                    .collect(Collectors.toCollection(() -> new ArrayList<>(userCacheList.size())));
        } else {
            userComponents = userCacheList.stream()
                    .map(cache -> new UserComponent(cache.getId(), cache.getName(), cache.getCode()))
                    .collect(Collectors.toCollection(() -> new ArrayList<>(userCacheList.size())));
        }

        page.setList(userComponents);
        return new JsonResult<>(true, "查询成功", page);
    }

    /**
     * 调用业务系统，获取所有已选的人员Id列表
     *
     * @return 人员Id映射：key:Id,value:true
     */
    private Map<String, Boolean> getSelectedUserIdMap(ComponentCondition condition) {
        JsonResult<List<String>> result = listSelectedUserId(condition);
        List<String> selectedUserIds = null;
        if (result != null && result.getData() != null) {
            selectedUserIds = result.getData();
        }

        if (CollectionUtils.isEmpty(selectedUserIds)) {
            return new HashMap<>(0);
        }

        Map<String, Boolean> userIdMap = new HashMap<>(selectedUserIds.size());
        selectedUserIds.forEach(id -> userIdMap.put(id, true));
        return userIdMap;
    }

    /**
     * 从缓存中获取所有满足查询条件的待选人员
     */
    private List<UserCache> getWaitingUser(ComponentCondition condition) {
        List<UserCache> cacheList = getUserCachesByCondition(condition);
//        List<UserCache> cacheList = getUserCachesByConditionByCache(condition);
        if (CollectionUtils.isEmpty(cacheList)) {
            return new ArrayList<>(0);
        }

        Map<String, Boolean> selectedUserIdMap = getSelectedUserIdMap(condition);
        if (MapUtils.isEmpty(selectedUserIdMap)) {
            return cacheList;
        }

        cacheList.removeIf(cache -> checkSelectedAndKeywords(cache, selectedUserIdMap, null));
        return cacheList;
    }

    /**
     * 从缓存中获取所有满足查询条件的待选人员
     */
    private List<User> getWaitingUserTwo(ComponentCondition condition) {
        List<User> cacheList = filterWaitingUserByCompany(condition);
        if (CollectionUtils.isEmpty(cacheList)) {
            return new ArrayList<>(0);
        }

        Map<String, Boolean> selectedUserIdMap = getSelectedUserIdMap(condition);
        if (MapUtils.isEmpty(selectedUserIdMap)) {
            return cacheList;
        }

        cacheList.removeIf(cache -> checkSelectedAndKeywordsTwo(cache, selectedUserIdMap, null));
        return cacheList;
    }

    // 返回true需要排除的数据
    private boolean checkSelectedAndKeywordsTwo(User cache, Map<String, Boolean> selectedUserIdMap, String keywords) {
        if (selectedUserIdMap != null && BooleanUtils.isTrue(selectedUserIdMap.get(cache.getId()))) {
            return true;
        }

        if (StringUtils.isEmpty(keywords)) {
            return false;
        }

        String name = cache.getName();
        String code = cache.getCode();
        String loginName = cache.getLoginName();
        if (StringUtils.isNoneBlank(name) && name.contains(keywords)) {
            return false;
        }

        if (StringUtils.isNoneBlank(code) && code.contains(keywords)) {
            return false;
        }

        if (StringUtils.isNoneBlank(loginName) && loginName.contains(keywords)) {
            return false;
        }

        return true;
    }

    private List<UserCache> getUserCachesByConditionByCache(ComponentCondition condition) {
        List<UserCache> cacheList;
        String cacheKey = condition.getCacheKey();
        if (BooleanUtils.isNotTrue(redisTemplate.hasKey(cacheKey))) {
            cacheList = getUserCachesByCondition(condition);
            if (CollectionUtils.isNotEmpty(cacheList)) {
                saveResultToRedisByAsync(cacheKey, cacheList);
            }
        } else {
            ListOperations<String, UserCache> opsForList = redisTemplate.opsForList();
            cacheList = opsForList.range(cacheKey, 0, -1);
            redisTemplate.expire(cacheKey, 120, TimeUnit.SECONDS);
        }

        return cacheList;
    }

    private void saveResultToRedisByAsync(String cacheKey, List<UserCache> cacheList) {
        CommonUtils.threadPoolExecutor(o -> {
            ListOperations<String, UserCache> opsForList = redisTemplate.opsForList();
            opsForList.leftPushAll(cacheKey, cacheList);
            redisTemplate.expire(cacheKey, 120, TimeUnit.SECONDS);
        });
    }

    private List<UserCache> getUserCachesByCondition(ComponentCondition condition) {
        String relType = condition.getRelType();
        if (StringUtils.isEmpty(relType)) {
            relType = UcConstants.RANG_TYPE_ORG;
        }

        List<UserCache> userCacheList;
        if (UcConstants.RANG_TYPE_ORG.equals(relType)) {
            userCacheList = filterWaitingUserByOrg(condition);
        } else if (UcConstants.RANG_TYPE_POSITION.equals(relType)) {
            userCacheList = filterWaitingUserByPosit(condition);
        } else if (UcConstants.RANG_TYPE_GROUP.equals(relType)) {
            userCacheList = filterWaitingUserByGroup(condition);
        } else if (UcConstants.RANG_TYPE_ROLE.equals(relType)) {
            userCacheList = filterWaitingUserByRole(condition);
        } else {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM);
        }

        return userCacheList.parallelStream().sorted(Comparator.comparing(UserCache::getId)).collect(Collectors.toList());
    }

    private List<User> filterWaitingUserByCompany(ComponentCondition condition) {
        String relId = condition.getRelId();
        List<User> userList = userService.listByCompanyId(relId, condition.getKeywords());
        return userList.parallelStream().sorted(Comparator.comparing(User::getId)).collect(Collectors.toList());
    }

    private List<UserCache> filterWaitingUserByRole(ComponentCondition condition) {
        UserRoleRel roleRel = new UserRoleRel();
        String roleId = condition.getRelId();
        if (StringUtils.isEmpty(roleId)) {
            List<Role> roles = roleService.listAll(true);
            if (CollectionUtils.isEmpty(roles)) {
                return new ArrayList<>(0);
            }

            List<String> roleIds = new ArrayList<>(roles.size());
            roles.forEach(role -> roleIds.add(role.getId()));
            roleRel.setRoleIds(roleIds);
        } else {
            roleRel.setRoleIds(Collections.singletonList(roleId));
        }

        roleRel.setKeyword(condition.getKeywords());
        roleRel.setCorpCode(ContextHandler.getCorpCode());
        Page<UserRoleRel> relPage = new Page<>();
        relPage.setPageNum(1);
        relPage.setPageSize(10000);
        Page<User> page = userRoleRelService.searchUser(roleRel, relPage);
        List<User> list = page.getList();
        if (CollectionUtils.isEmpty(list)) {
            return new ArrayList<>(0);
        }

        List<UserCache> userCacheList = UcUtil.convertToUserCache(list);
        String keywords = condition.getKeywords();
        userCacheList.removeIf(cache -> checkSelectedAndKeywords(cache, null, keywords));
        return userCacheList;
    }

    private List<UserCache> filterWaitingUserByGroup(ComponentCondition condition) {
        Map<String, Boolean> groupIdMap = getGroupIdMapNoAuth(condition);
        if (MapUtils.isEmpty(groupIdMap)) {
            return new ArrayList<>(0);
        }

        List<UserCache> userCacheList = userService.listUserByGroupIdsFromCache(groupIdMap.keySet());
        if (CollectionUtils.isEmpty(userCacheList)) {
            return userCacheList;
        }

        String keywords = condition.getKeywords();
        userCacheList.removeIf(cache -> checkSelectedAndKeywords(cache, null, keywords));
        return userCacheList;
    }

    private Map<String, Boolean> getGroupIdMap(ComponentCondition condition) {
        Map<String, Boolean> referIdMap = getReferIdMap();
        boolean superAdmin = ContextHandler.isSuperAdmin();
        if (!superAdmin && MapUtils.isEmpty(referIdMap)) {
            return new HashMap<>(0);
        }

        String relId = condition.getRelId();
        if (!condition.isCategory()) {
            if (superAdmin || BooleanUtils.isTrue(referIdMap.get(relId))) {
                return Collections.singletonMap(relId, true);
            }

            return new HashMap<>(0);
        }

        List<String> categoryIds = getChildIds(relId, condition.isIncludeChild());
        if (CollectionUtils.isEmpty(categoryIds)) {
            return new HashMap<>(0);
        }

        Map<String, Boolean> groupIdMap = groupService.getGroupIdMapByCategoryIds(categoryIds);
        if (MapUtils.isEmpty(groupIdMap)) {
            return new HashMap<>(0);
        }

        groupIdMap.entrySet().removeIf(next -> !superAdmin && BooleanUtils.isNotTrue(referIdMap.get(next.getKey())));
        return groupIdMap;
    }

    private Map<String, Boolean> getGroupIdMapNoAuth(ComponentCondition condition) {
        // TODO(TangFD): 2019/7/11 未添加群组的使用授权校验
        String relId = condition.getRelId();
        if (!condition.isCategory()) {
            return Collections.singletonMap(relId, true);
        }

        List<String> categoryIds = getChildIds(relId, condition.isIncludeChild());
        if (CollectionUtils.isEmpty(categoryIds)) {
            return new HashMap<>(0);
        }

        return groupService.getGroupIdMapByCategoryIds(categoryIds);
    }

    private List<String> getChildIds(String parentId, boolean includeChild) {
        if (!includeChild) {
            return Collections.singletonList(parentId);
        }

        List<String> categoryIds = commonTreeService.getAllNodeIdByNodeId(parentId);
        if (CollectionUtils.isEmpty(categoryIds)) {
            return new ArrayList<>(0);
        }

        return categoryIds;
    }

    private List<UserCache> filterWaitingUserByPosit(ComponentCondition condition) {
        Map<String, Boolean> positionIdMap = getPositionIdMapNoAuth(condition);
        if (MapUtils.isEmpty(positionIdMap)) {
            return new ArrayList<>(0);
        }

        List<UserCache> userCacheList = userService.listAllFromCache();
        if (CollectionUtils.isEmpty(userCacheList)) {
            return userCacheList;
        }

        String keywords = condition.getKeywords();
        for (Iterator<UserCache> iterator = userCacheList.iterator(); iterator.hasNext(); ) {
            UserCache cache = iterator.next();
            String positionId = cache.getPositionId();
            if (StringUtils.isEmpty(positionId)) {
                iterator.remove();
                continue;
            }

            if (BooleanUtils.isNotTrue(positionIdMap.get(positionId))) {
                iterator.remove();
                continue;
            }

            if (checkSelectedAndKeywords(cache, null, keywords)) {
                iterator.remove();
            }
        }

        return userCacheList;
    }

    // 返回true需要排除的数据
    private boolean checkSelectedAndKeywords(UserCache cache, Map<String, Boolean> selectedUserIdMap, String keywords) {
        if (selectedUserIdMap != null && BooleanUtils.isTrue(selectedUserIdMap.get(cache.getId()))) {
            return true;
        }

        if (StringUtils.isEmpty(keywords)) {
            return false;
        }

        String name = cache.getName();
        String code = cache.getCode();
        String loginName = cache.getLoginName();
        /*return StringUtils.isEmpty(name) || !name.contains(keywords)
                && StringUtils.isEmpty(code) || !code.contains(keywords)
                && StringUtils.isEmpty(loginName) || !loginName.contains(keywords);*/
        if (StringUtils.isNoneBlank(name) && name.contains(keywords)) {
            return false;
        }

        if (StringUtils.isNoneBlank(code) && code.contains(keywords)) {
            return false;
        }

        if (StringUtils.isNoneBlank(loginName) && loginName.contains(keywords)) {
            return false;
        }

        return true;
    }

    private Map<String, Boolean> getPositionIdMap(ComponentCondition condition) {
        Map<String, Boolean> referIdMap = getReferIdMap();
        boolean superAdmin = ContextHandler.isSuperAdmin();
        if (!superAdmin && MapUtils.isEmpty(referIdMap)) {
            return new HashMap<>(0);
        }

        String relId = condition.getRelId();
        if (!condition.isCategory()) {
            if (superAdmin || BooleanUtils.isTrue(referIdMap.get(relId))) {
                return Collections.singletonMap(relId, true);
            }

            return new HashMap<>(0);
        }

        List<String> categoryIds = getChildIds(relId, condition.isIncludeChild());
        if (CollectionUtils.isEmpty(categoryIds)) {
            return new HashMap<>(0);
        }

        Map<String, Boolean> positionIdMap = positionService.getPositionIdMapByCategoryIds(categoryIds);
        if (MapUtils.isEmpty(positionIdMap)) {
            return new HashMap<>(0);
        }

        positionIdMap.entrySet().removeIf(next -> !superAdmin && BooleanUtils.isNotTrue(referIdMap.get(next.getKey())));
        return positionIdMap;
    }

    private Map<String, Boolean> getPositionIdMapNoAuth(ComponentCondition condition) {
        String relId = condition.getRelId();
        if (!condition.isCategory()) {
            return Collections.singletonMap(relId, true);
        }

        List<String> categoryIds = getChildIds(relId, condition.isIncludeChild());
        if (CollectionUtils.isEmpty(categoryIds)) {
            return new HashMap<>(0);
        }

        return positionService.getPositionIdMapByCategoryIds(categoryIds);
    }

    private Map<String, Boolean> getReferIdMap() {
        List<String> referIds = userRangeService.getReferIdsByUserId(ContextHandler.getUserId(), null);
        if (CollectionUtils.isEmpty(referIds)) {
            return new HashMap<>(0);
        }

        Map<String, Boolean> referIdMap = new HashMap<>(referIds.size());
        referIds.forEach(id -> referIdMap.put(id, true));
        return referIdMap;
    }

    private List<UserCache> filterWaitingUserByOrg(ComponentCondition condition) {
        String relId = condition.getRelId();
        Org org = orgService.getRootOrg();
        Boolean isRootOrg = false;
        if (null != org && relId.equals(org.getId())) {
            isRootOrg = true;
        }
        boolean includeChild = condition.isIncludeChild();
        List<String> childIds = Collections.singletonList(relId);
        if (includeChild) {
            childIds = orgService.getAuthChildIds(Collections.singleton(relId), true);
        }

        Map<String, Boolean> orgIdMap = new HashMap<>(childIds.size());
        childIds.forEach(childId -> orgIdMap.put(childId, true));
        List<UserCache> userCacheList = userService.listAllFromCache();
        String keywords = condition.getKeywords();
        for (Iterator<UserCache> iterator = userCacheList.iterator(); iterator.hasNext(); ) {
            UserCache cache = iterator.next();
            String orgId = cache.getOrgId();
            if ((StringUtils.isEmpty(orgId) && BooleanUtils.isNotTrue(isRootOrg)) ||
                    (StringUtils.isNotEmpty(orgId) && BooleanUtils.isNotTrue(orgIdMap.get(orgId)))) {
                iterator.remove();
                continue;
            }

            if (checkSelectedAndKeywords(cache, null, keywords)) {
                iterator.remove();
            }
        }

        return userCacheList;
    }

    @RequestMapping(value = "/searchSelectedUser", method = RequestMethod.POST)
    @ApiOperation(value = "获取选人组件已选人员")
    public JsonResult<Page<UserComponent>> searchSelectedUser(@RequestBody ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/searchSelectedUser";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    @RequestMapping(value = "/addAllUsers", method = RequestMethod.POST)
    @ApiOperation(value = "添加全部人员")
    public JsonResult<Page<UserComponent>> addAllUsers(@RequestBody ComponentCondition condition) {
        if (condition == null) {
            return new JsonResult<>(false, "relId not be empty");
        }

        List<User> waitingUser = getWaitingUserTwo(condition);
        if (CollectionUtils.isEmpty(waitingUser)) {
            return new JsonResult<>(false, "待添加人员列表为空");
        }

        List<String> userIds = new ArrayList<>(waitingUser.size());
        waitingUser.forEach(userCache -> userIds.add(userCache.getId()));
        condition.setRelIds(userIds);

        return addUsersForBusiness(condition, "/addUsers");
    }

    @RequestMapping(value = "/addUsers", method = RequestMethod.POST)
    @ApiOperation(value = "添加选择的人员")
    public JsonResult addUsers(@RequestBody ComponentCondition condition) {
        List<String> relIds = condition.getRelIds();
        if (CollectionUtils.isEmpty(relIds)) {
            return new JsonResult(false, "待添加人员列表为空");
        }

        return addUsersForBusiness(condition, "/addUsers");
    }

    /**
     * 调用业务系统保存人员
     *
     * @param condition 调用业务系统参数
     * @param method    业务系统方法
     * @return 保存结果
     */
    private JsonResult addUsersForBusiness(ComponentCondition condition, String method) {
        List<String> relIds = condition.getRelIds();
        int size = relIds.size();
        int pageNum = size / PAGE_SIZE;
        pageNum += (size % PAGE_SIZE) == 0 ? 0 : 1;
        JsonResult result = null;
        for (int i = 0; i < pageNum; i++) {
            int start = i * PAGE_SIZE;
            int end = start + PAGE_SIZE;
            end = end > size ? size : end;
            condition.setRelIds(relIds.subList(start, end));
            try {
                result = callBusiness(condition, method);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return result;
    }

    private JsonResult callBusiness(ComponentCondition condition, String method) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + method;
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    @RequestMapping(value = "/removeAllUsers", method = RequestMethod.POST)
    @ApiOperation(value = "移除全部已选人员")
    public JsonResult removeAllUsers(@RequestBody ComponentCondition condition) {
        condition.setRelIds(null);
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/removeAllUsers";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    @RequestMapping(value = "/listSelectedUserId", method = RequestMethod.POST)
    @HystrixCommand(fallbackMethod = "listSelectedUserIdError")
    public JsonResult<List<String>> listSelectedUserId(ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/listSelectedUserId";
        JsonResult result;
        try {
            result = restTemplate.postForObject(url, condition, JsonResult.class);
        } catch (Exception e) {
            e.printStackTrace();
            result = new JsonResult(false, "");
        }
        return result;
    }

    public JsonResult listSelectedUserIdError() {
        return new JsonResult(false, "http error");
    }

    @RequestMapping(value = "/searchSelectedUserId", method = RequestMethod.POST)
    public JsonResult<Page<String>> searchSelectedUserId(ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/searchSelectedUserId";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    @RequestMapping(value = "/removeUsers", method = RequestMethod.POST)
    @ApiOperation(value = "移除选择的人员")
    public JsonResult removeUsers(@RequestBody ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/removeUsers";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }

    @RequestMapping(value = "/listRangOrg", method = RequestMethod.POST)
    @ApiOperation(value = "获取当前用户有管辖范围的类型")
    public JsonResult<List<String>> listRangOrg() {
//        if (ContextHandler.isSuperAdmin()) {
            List<String> list = new ArrayList<>(3);
            list.add(UcConstants.RANG_TYPE_ORG);
//            list.add(UcConstants.RANG_TYPE_GROUP);
//            list.add(UcConstants.RANG_TYPE_POSITION);
            return new JsonResult<>(true, "查询成功", list);
//        }
//
//        return new JsonResult<>(true, "查询成功", userRangeService.findRangeListByUserId());
    }

    /**
     * 此接口为选人组件完成后的列表接口，具体实现在commonRelController中，
     * 此处定义为了前端组件上接口统一
     */
    @RequestMapping(value = "/searchSelectedUserPage", method = RequestMethod.POST)
    @ApiOperation(value = "获取选人组件已选人员详细信息")
    public JsonResult<Page<User>> searchSelectedUserPage(@RequestBody ComponentCondition condition) {
        String appCode = condition.getAppCode();
        String route = condition.getRoute();
        String url = HTTP + appCode + "/" + route + "/searchUser";
        return restTemplate.postForObject(url, condition, JsonResult.class);
    }
}
