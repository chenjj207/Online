package com.purchase.uc.listener;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.nacos.common.util.Md5Utils;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.model.vo.ErrorUpdateImportExcelUser;
import com.purchase.uc.model.vo.ExcelUser;
import com.purchase.uc.model.vo.UpdateImportExcelUser;
import com.purchase.uc.utils.UcRedisKeys;
import com.purchase.uc.utils.UcUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * 人员修改导入
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class UserUpdateImportBaseExcelListener extends BaseImportExcelListener<UpdateImportExcelUser> {
    private static final Field[] fields = UpdateImportExcelUser.class.getDeclaredFields();
    private static final String NULL = "null";

    @Override
    protected boolean analysisFilter(UpdateImportExcelUser user) {
        if (rowNum++ < 2 || user == null || UcUtil.checkUpdateImportExcelUserEmpty(user)) {
            return false;
        }

        String currentUserId = null;
        List<String> errorMsg = new ArrayList<>();
        for (Field field : fields) {
            ExcelProperty property = field.getAnnotation(ExcelProperty.class);
            if (property == null) {
                continue;
            }

            int index = property.index() + 1;
            Object value;
            try {
                field.setAccessible(true);
                value = field.get(user);
            } catch (IllegalAccessException e) {
                log.error("数据解析失败", e);
                addErrorData(errorMsg, index, "数据解析失败");
                continue;
            }

            String name = field.getName();
            if (ExcelUser.CODE.equals(name)) {
                if (value == null || NULL.equals(value)) {
                    addErrorData(errorMsg, index, "工号不可为空");
                    continue;
                }

                currentUserId = userLoginFieldAndIdMap.get(name + ";;" + String.valueOf(value));
                user.setId(currentUserId);
                if (StringUtils.isEmpty(currentUserId)) {
                    addErrorData(errorMsg, index, "工号不存在");
                }
                continue;
            }

            if (value == null) {
                continue;
            }

            if (StringUtils.isNotEmpty(currentUserId)
                    && (ExcelUser.EMAIL.equals(name)
                    || ExcelUser.MOBILE.equals(name)
                    || ExcelUser.ID_CARD.equals(name)
                    || ExcelUser.LOGIN_NAME.equals(name))) {
                if (NULL.equals(value) && ExcelUser.LOGIN_NAME.equals(name)) {
                    addErrorData(errorMsg, index, "用户名不可为空");
                    continue;
                }

                String userId = userLoginFieldAndIdMap.get(name + ";;" + String.valueOf(value));
                if (StringUtils.isNotEmpty(userId) && !currentUserId.equals(userId)) {
                    String[] names = property.value();
                    String nameValue = "数据";
                    if (ArrayUtils.isNotEmpty(names)) {
                        nameValue = names[0];
                    }
                    addErrorData(errorMsg, index, nameValue + "已存在");
                }

                continue;
            }

            if (ExcelUser.LEADER_NAME.equals(name)) {
                if (NULL.equals(value)) {
                    user.setLeaderId(NULL);
                } else {
                    user.setLeaderId(getLeaderId(errorMsg, index, user.getLeaderCode()));
                }
                continue;
            }

            if (ExcelUser.ORG_NAME_PATH.equals(name)) {
                if (NULL.equals(value)) {
                    addErrorData(errorMsg, index, "部门不可为空");
                    continue;
                }

                user.setOrgId(validateOrg(index, value, errorMsg));
                continue;
            }

            if (ExcelUser.POSITION_NAME.equals(name)) {
                if (NULL.equals(value)) {
                    user.setPositionId(NULL);
                    continue;
                }

                String positionCode = user.getPositionCode();
                String category = user.getPositionCategory();
                String positionId = validPosition(positionCode, category, index, value, errorMsg);
                user.setPositionId(positionId);
                continue;
            }

            if (ExcelUser.PASSWORD.equals(name)) {
                String pwd = String.valueOf(value);
                if ("null".equals(pwd)) {
                    continue;
                }

                user.setPwd(Md5Utils.getMD5(pwd, UcConstants.ENCODE_UTF8));
            }
        }

        boolean error = errorMsg.size() > 0;
        if (error) {
            addErrorData(user, errorMsg);
        }

        return !error;
    }

    private void addErrorData(UpdateImportExcelUser user, List<String> errorData) {
        ErrorUpdateImportExcelUser error = new ErrorUpdateImportExcelUser();
        BeanUtils.copyProperties(user, error);
        error.setMessage(errorData.toString());
        errorUsers.add(error);
    }

    @Override
    protected void saveUser(List<UpdateImportExcelUser> dataList) {
        if (CollectionUtils.isEmpty(dataList)) {
            return;
        }

        userService.updateImport(dataList);
    }

    @Override
    protected String getCacheKey() {
        return UcRedisKeys.USER_IMPORT_UPDATE + handlerUserId;
    }

    @Override
    protected String getErrorTemplate() {
        return "template/emptyUpdateUserTemplate.xlsx";
    }

    @Override
    protected Class<? extends ExcelUser> getErrorExcelClass() {
        return ErrorUpdateImportExcelUser.class;
    }
}
