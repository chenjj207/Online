package com.purchase.uc.client.wx.entity.auth;

import com.purchase.uc.client.wx.entity.MsgReturnVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ScanLoginVO extends MsgReturnVO {

    @ApiModelProperty("授权的系统编码")
    private String bm;

    @ApiModelProperty("企业微信用户ID（工号）")
    private String userId;

    @ApiModelProperty("应用ID")
    private String deviceId;

}
