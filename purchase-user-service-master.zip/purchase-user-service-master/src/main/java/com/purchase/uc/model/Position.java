package com.purchase.uc.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang.StringUtils;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.List;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "Position", description = "")
@Table(name = "t_uc_position")
public class Position extends BaseCorpModel {
    public static final String NAME = "name";
    public static final String CODE = "code";
    public static final String CATEGORY_ID = "categoryId";

    /**
     * 岗位名称
     */
    @ApiModelProperty(value = "岗位名称")
    private String name;

    /**
     * 岗位编码
     */
    @ApiModelProperty(value = "岗位编码")
    private String code;

    /**
     * 岗位类别
     */
    @ApiModelProperty(value = "岗位类别")
    private String categoryId;

    /**
     * 岗位类别名称全路径
     */
    @Transient
    private String categoryNamePath;

    /**
     * 岗位类别id集合
     */
    @Transient
    @ApiModelProperty(value = "岗位类别")
    private List<String> categoryIdList;

    public String getCode() {
        if (StringUtils.isBlank(code)) {
            return null;
        }

        return code;
    }
}
