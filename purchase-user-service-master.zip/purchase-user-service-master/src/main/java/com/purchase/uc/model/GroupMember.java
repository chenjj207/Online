package com.purchase.uc.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.List;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "GroupMember", description = "")
@Table(name = "t_uc_group_member")
public class GroupMember extends BaseCorpModel {
    public static final String GROUP_ID = "groupId";
    public static final String USER_ID = "userId";
    public static final String SOURCE = "source";

    /**
     * 群组ID
     */
    @ApiModelProperty(value = "群组ID")
    private String groupId;

    /**
     * 人员ID
     */
    @ApiModelProperty(value = "人员ID")
    private String userId;

    /**
     * 人员来源 APPOINT(指定)/DYNAMIC(动态群组)
     */
    @ApiModelProperty(value = "人员来源")
    private String source;

    @Transient
    private List<String> userIds;
}
