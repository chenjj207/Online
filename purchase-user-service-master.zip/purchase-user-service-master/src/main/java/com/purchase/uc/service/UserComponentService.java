package com.purchase.uc.service;

import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.purchase.uc.model.vo.UserComponent;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;

import java.util.List;

/**
 * 选人组件需要实现的公共接口，使用组件必须要实现接口对应功能
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年06月14日14:26:43
 */
public interface UserComponentService {
    /**
     * 该方法用于添加传入的人员列表，当已选人员列表已存在该人员时跳过
     *
     * @param condition 添加人员条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relIds 必须 = List<String> userIds</li>
     *                  </p>
     */
    void addUsers(ComponentCondition condition);

    /**
     * 该方法用于全量删除查询条件下的全部人员
     *
     * @param condition 删除条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType = com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>category 必须</li>
     *                  <li>includeChild 必须</li>
     *                  </p>
     */
    void removeAllUsers(ComponentCondition condition);

    /**
     * 该方法用于删除传入的人员列表
     *
     * @param condition 删除条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relIds 必须 = List<String> userIds</li>
     *                  </p>
     */
    void removeUsers(ComponentCondition condition);

    /**
     * 该方法用于根据查询条件获取所有已选人员ID集合
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType = com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  </p>
     */
    List<String> listSelectedUserId(ComponentCondition condition);

    /**
     * 该方法用于根据查询条件分页获取已选人员ID
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType = com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  <li>keywords 可选</li>
     *                  </p>
     */
    Page<String> searchSelectedUserId(ComponentCondition condition);

    /**
     * 该方法用于根据查询条件分页获取已选人员
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType = com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  <li>keywords 可选</li>
     *                  </p>
     */
    Page<UserComponent> searchSelectedUser(ComponentCondition condition);
}
