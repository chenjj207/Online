package com.purchase.uc.model.dto;

import com.qgutech.qgyun.framework.database.model.BaseModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/25  14:35
 */
@Data
public class SupplierAuditDTO{
    @ApiModelProperty(value = "供应商id")
    private String id;

    @ApiModelProperty(value = "是否发送短信通知，默认发送")
    private boolean isSend = true;
}
