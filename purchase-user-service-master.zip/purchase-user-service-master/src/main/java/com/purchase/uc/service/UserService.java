package com.purchase.uc.service;

import cn.hutool.core.util.URLUtil;
import com.alibaba.nacos.common.util.Md5Utils;
import com.google.common.collect.Lists;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcException;
import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.client.FileFeignClient;
import com.purchase.uc.client.wx.WxClusterFeign;
import com.purchase.uc.client.wx.entity.WxClusterResultInfo;
import com.purchase.uc.client.wx.entity.auth.ScanLoginDTO;
import com.purchase.uc.client.wx.entity.auth.ScanLoginVO;
import com.purchase.uc.common.model.CommonExportTask;
import com.purchase.uc.common.service.CommonExportTaskService;
import com.purchase.uc.listener.UserImportBaseExcelListener;
import com.purchase.uc.listener.UserUpdateImportBaseExcelListener;
import com.purchase.uc.mapper.UserMapper;
import com.purchase.uc.model.*;
import com.purchase.uc.model.vo.*;
import com.purchase.uc.utils.*;
import com.qgutech.qgyun.dev.client.cs.CsFeignClient;
import com.qgutech.qgyun.dev.client.cs.model.LoginSetting;
import com.qgutech.qgyun.dev.common.model.CommonRel;
import com.qgutech.qgyun.dev.common.utils.CommonConstant;
import com.qgutech.qgyun.dev.common.utils.CommonUtils;
import com.qgutech.qgyun.dev.common.utils.JedisUtils;
import com.qgutech.qgyun.framework.common.config.ContextProperties;
import com.qgutech.qgyun.framework.common.context.ContextConstant;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.BaseException;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.common.utils.SqlUtil;
import com.qgutech.qgyun.framework.common.utils.excel.ExcelUtil;
import com.qgutech.qgyun.framework.common.utils.excel.ExcelWriterFactory;
import com.qgutech.qgyun.framework.common.utils.excel.ExportExcelUtil;
import com.qgutech.qgyun.framework.database.model.BaseModel;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import com.qgutech.qgyun.fs.api.model.QgFile;
import com.qgutech.qgyun.fs.client.service.FileService;
import com.qgutech.qgyun.saas.client.service.SaasCorpService;
import feign.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.weekend.Weekend;
import tk.mybatis.mapper.weekend.WeekendSqls;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static cn.hutool.crypto.SecureUtil.sha1;
import static com.purchase.uc.model.User.*;
import static com.qgutech.qgyun.framework.database.model.BaseCorpModel.CORP_CODE;
import static com.qgutech.qgyun.framework.database.model.BaseModel.ID;


/**
 * 用户管理相关Service及实现
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Slf4j
@Service
@SuppressWarnings("unchecked")
public class UserService extends BaseServiceImpl<User> implements ApplicationContextAware {

    private static final String SECURITY_FLAG = "qgy:uc:security:flag:";
    private static final String SECURITY_CODE = "qgy:uc:security:code:";
    private static final String EMPTY_VALUE = "EMPTY";
    @Resource
    private UserMapper userMapper;
    @Resource
    private SaasCorpService saasCorpService;
    @Resource
    private OrgService orgService;
    @Resource
    private PositionService positionService;
    @Resource
    public UserDetailService userDetailService;
    @Resource
    private FileFeignClient fileFeignClient;
    @Resource
    public RedisTemplate redisTemplate;
    @Resource
    private CommonExportTaskService exportTaskService;
    @Resource
    private UserRoleRelService userRoleRelService;
    @Resource
    private GroupMemberService groupMemberService;
    @Resource
    private UserRangeService userRangeService;
    @Resource
    private CategoryService categoryService;
    @Resource
    private RoleService roleService;
    @Value("${user.export.path:}")
    private String userExportPath;
    @Resource
    private SysSettingService settingService;
    @Resource
    private FileService fileService;
    @Resource
    private CsFeignClient csFeignClient;
    private ApplicationContext applicationContext;
    @Resource
    private CompanyService companyService;
    @Resource
    private RoleAuthRelService roleAuthRelService;
    @Resource
    private WxClusterFeign wxClusterFeign;

    /*@Resource
    private AliSmsService aliSmsService;*/
    private final String KEY_TEMP = "ZYD_ONLINE_CAPTCHA_%s_%s";
    @Value("${app.ali.sms.code.resetPwd}")
    private String resetPwd;

    @Value("${udesk.im_user_key}")
    private String udeskImUserKey;

    @Resource
    private SupplierService supplierService;


    public List<User> listAll() {
        Example example = new Example(User.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        return userMapper.selectByExample(example);
    }

    /**
     * 该方法用于根据岗位ID集合回去用户集合
     *
     * @param positionIds 岗位ID集合
     * @return 用户集合
     */
    public List<User> listByPositionIds(List<String> positionIds) {
        if (CollectionUtils.isEmpty(positionIds)) {
            throw new IllegalArgumentException("PositionIds is empty when listByPositionIds");
        }

        return listByReferId(positionIds, POSITION_ID);
    }

    public SecurityCode getSecurityImg(String checkKey) {
        checkKey = StringUtils.isEmpty(checkKey) ? IDUtils.getUUID() : checkKey;
        Integer flag = (Integer) redisTemplate.opsForValue().get(SECURITY_FLAG + checkKey);
        if (flag == null || flag < 3) {
            return SecurityCode.builder().key(checkKey).hide(true).build();
        }

        try {
            String code = SecurityCodeUtils.randomCode(4);
            String img = SecurityCodeUtils.securityCode(code);
            ValueOperations<String, String> opsForValue = redisTemplate.opsForValue();
            String key = SECURITY_CODE + checkKey;
            opsForValue.set(key, code.toLowerCase(), 3, TimeUnit.MINUTES);
            SecurityCode securityCode = new SecurityCode();
            securityCode.setImg(img);
            securityCode.setKey(checkKey);
            return securityCode;
        } catch (IOException e) {
            throw new RuntimeException("LOGIN_ERROR_CREATE_CODE_ERROR");
        }
    }

    @SuppressWarnings("unchecked")
    public JsonResult<?> validSecurityCode(Map<String, String> loginInfo, Supplier<JsonResult<?>> login) {
        /*String checkKey = loginInfo.get(UcConstants.DEFAULT_CODE_KEY);
        if (StringUtils.isEmpty(checkKey)) {
            return new JsonResult<>(false, UcI18nConstants.UC_CODE_NOT_MUCH.getCode(), UcI18nConstants.UC_CODE_NOT_MUCH.getName(), null);
        }*/

        /*String flagKey = SECURITY_FLAG + checkKey;
        Integer flag = (Integer) redisTemplate.opsForValue().get(flagKey);
        if (flag == null || flag < 3) {
            JsonResult<?> result = login.get();
            //if (!result.isSuccess()) {
            //    redisTemplate.opsForValue().increment(flagKey, 1);
            //    redisTemplate.expire(flagKey, 10, TimeUnit.MINUTES);
            //}

            return result;
        }

        String key = SECURITY_CODE + checkKey;
        ValueOperations<String, String> opsForValue = redisTemplate.opsForValue();
        String securityCode = opsForValue.get(key);
        redisTemplate.delete(key);
        String code = loginInfo.get("code");
        if (StringUtils.isEmpty(securityCode) || StringUtils.isEmpty(code) || !code.toLowerCase().equals(securityCode)) {
            return new JsonResult<>(false, UcI18nConstants.UC_CODE_NOT_MUCH.getCode(), UcI18nConstants.UC_CODE_NOT_MUCH.getName(), null);
        } else {*/
            return login.get();
        //}
    }

    private List<User> listByReferId(List<String> orgIds, String orgId) {
        Example example = new Example(User.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andIn(orgId, orgIds)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());

        return userMapper.selectByExample(example);
    }

    public JsonResult<UdeskInfoVO> udeskInfo(){
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String token = URLUtil.decode(request.getHeader("sessionid"), StandardCharsets.UTF_8);
        try {
            Map<Object,Object> map = redisTemplate.opsForHash().entries(token);
            String userId = (String) map.get("userId");
            String username = (String) map.get("username");
            String mobile = (String) map.get("mobile");
            String snonce = java.util.UUID.randomUUID().toString().replace("-", "");
            String stimestamp = String.valueOf(new Date().getTime());
            String signature = getUdeskSignature(snonce, stimestamp, userId);

            UdeskInfoVO udeskInfoVO = new UdeskInfoVO();
            udeskInfoVO.setUserId(userId);
            udeskInfoVO.setUserName(username);
            udeskInfoVO.setMobile(mobile);
            udeskInfoVO.setNonce(snonce);
            udeskInfoVO.setTimestamp(stimestamp);
            udeskInfoVO.setTimestamp(stimestamp);
            udeskInfoVO.setWeb_token(userId);
            udeskInfoVO.setSignature(signature);
            return JsonResult.ok("成功", udeskInfoVO);
        }catch (IllegalArgumentException e){
            throw new UcException(UcErrorCode.NOT_LOGGED_IN);
        }
    }

    public String getUdeskSignature(String snonce, String stimestamp, String swebToken) {
        String str = "nonce=" + snonce + "&timestamp=" + stimestamp + "&web_token=" + swebToken + "&" + udeskImUserKey;
        str = sha1(str);
        str = str.toUpperCase();
        return str;
    }
    /**
     * 该方法用于根据人员集合封装人员部门和岗位名称信息
     *
     * @param users 人员集合
     * @return 封装好的集合
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<User> fillOrgAndPositName(List<User> users) {
        if (CollectionUtils.isEmpty(users)) {
            return users;
        }

        Set<String> orgIds = users.stream().map(User::getOrgId)
                .filter(StringUtils::isNotBlank).collect(Collectors.toSet());
        Set<String> positIds = users.stream().map(User::getPositionId)
                .filter(StringUtils::isNotBlank).collect(Collectors.toSet());

        Map<String, String> positionIdAndNameMap;
        if (CollectionUtils.isEmpty(positIds)) {
            positionIdAndNameMap = new HashMap<>(0);
        } else {
            positionIdAndNameMap = positionService.getPositionIdAndNameMap(positIds);
        }

        Map<String, Org> orgMap = orgService.getOrgMap(orgIds);
        users.forEach(user -> {
            String orgId = user.getOrgId();
            if (StringUtils.isNotEmpty(orgId) && MapUtils.isNotEmpty(orgMap)) {
                Org org = orgMap.get(orgId);
                if (org != null) {
                    user.setOrgName(org.getName());
                    user.setOrgNamePath(org.getNamePath());
                }
            }

            String positionId = user.getPositionId();
            if (StringUtils.isNotEmpty(positionId) && MapUtils.isNotEmpty(positionIdAndNameMap)) {
                user.setPositionName(positionIdAndNameMap.get(positionId));
            }
        });

        return users;
    }

    /**
     * 根据用户Id列表，查询用户Id与姓名的映射
     *
     * @param userIds 用户Id列表
     * @return 用户Id与姓名的映射
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Map<String, String> getUserIdAndNameMap(Collection<String> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userIds not be empty!");
        }

        Set<String> userIdSet = new HashSet<>();
        for (String userId : userIds) {
            //去除null值，否则取值时会出错
            if (StringUtils.isNotBlank(userId)) {
                userIdSet.add(userId);
            }
        }

        if (CollectionUtils.isEmpty(userIdSet)){
            return new HashMap<>();
        }

        HashOperations<String, String, String> operations = redisTemplate.opsForHash();
        String usersKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USERS;
        List<String> users = operations.multiGet(usersKey, userIdSet);
        List<UserCache> userCacheList = UcUtil.toUserCache(users);
        Map<String, String> userIdAndNameMap;
        if (CollectionUtils.isNotEmpty(userCacheList)) {
            userIdAndNameMap = new HashMap<>(userCacheList.size());
            userCacheList.forEach(user -> userIdAndNameMap.put(user.getId(), user.getName()));
            return userIdAndNameMap;
        }

        Example example = new Example(User.class);
        example.selectProperties(User.ID, User.NAME).createCriteria()
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andIn(User.ID, userIdSet);

        List<User> userList = userMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(userList)) {
            return new HashMap<>(0);
        }

        userIdAndNameMap = new HashMap<>(userList.size());
        userList.forEach(user -> userIdAndNameMap.put(user.getId(), user.getName()));
        return userIdAndNameMap;
    }

    @Resource
    protected ContextProperties contextProperties;

    public JsonResult<String> generateSession(Map<String, Object> userMap, boolean forceDelete,
                                               HttpServletResponse response) {

        JsonResult<String> jsonResult = new JsonResult<>();
        Set<String> keys = contextProperties.getAllKeys();
        for (String key : keys) {
            userMap.put(key, userMap.get(key));
        }

        //存储用户的前缀 userId - sessionId
        String userPrefix = "dev_default_user:";
        //存储 sessionId 信息前缀 sessionId -> userMap
        String sessionPrefix = "dev_default_session:";

        //强制剔除
        String userId = (String) userMap.get(ContextConstant.CONTEXT_KEY_USER_ID);
        String dbSessionId;
        if (forceDelete) {
            dbSessionId = (String)redisTemplate.opsForValue().get(userPrefix + userId);
            if (StringUtils.isNotBlank(dbSessionId)) {
                redisTemplate.delete(dbSessionId);
            }

            redisTemplate.delete(userPrefix + userId);
        }

        String sessionId = IDUtils.getUUID19();
        Integer expirationTime = (Integer) redisTemplate.opsForValue().get("CS_LOGIN_SESSION_TIMEOUT_" + userMap.get(ContextConstant.CONTEXT_KEY_CORP_CODE));
        if (expirationTime == null) {
            expirationTime = 9999999;
        }else {
            expirationTime = expirationTime * 60;
        }

        String redisSession = sessionPrefix + sessionId;
        userMap.put("sessionId", redisSession);
        CookieUtil.setCookie(response, "sessionId", redisSession);
        //是否限制单列登陆
        String redisUserKey = userPrefix + userId + "-" + redisSession;
        redisTemplate.opsForValue().set(redisUserKey, redisSession, expirationTime, TimeUnit.SECONDS);


        redisTemplate.opsForHash().putAll(redisSession, userMap);
        redisTemplate.expire(redisSession, expirationTime, TimeUnit.SECONDS);
        jsonResult.setSuccess(true);
        jsonResult.setData(redisSession);
        return jsonResult;
    }

    /**
     * 根据用户Id列表，查询用户缓存信息
     *
     * @param userIds 用户Id列表
     * @return 用户缓存信息
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Map<String, UserCache> getUserMapFromCache(Collection<String> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userIds not be empty!");
        }

        HashOperations<String, String, String> operations = redisTemplate.opsForHash();
        String usersKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USERS;
        List<String> users = operations.multiGet(usersKey, userIds);
        List<UserCache> userCacheList = UcUtil.toUserCache(users);
        if (CollectionUtils.isEmpty(userCacheList)) {
            return new HashMap<>(0);
        }

        Map<String, UserCache> userMap = new HashMap<>(userCacheList.size());
        userCacheList.forEach(user -> userMap.put(user.getId(), user));
        return userMap;
    }

    /**
     * 该方法用于刷新用户缓存
     */
    public void putUserToRedis(List<String> userIds, String... corpCodes) {
        if (corpCodes != null && corpCodes.length > 0) {
            ContextHandler.setCorpCode(corpCodes[0]);
        }

        HashOperations<String, String, Object> opsForHash = redisTemplate.opsForHash();
        String usersKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USERS;
        String userLoginKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USER_LOGIN;
        String loginNamesKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.LOGIN_NAMES;
        // 删除公司所有人员缓存
        List<User> users;
        // 公司刷缓存
        if (CollectionUtils.isEmpty(userIds)) {
            opsForHash.getOperations().delete(usersKey);
            opsForHash.getOperations().delete(userLoginKey);
            opsForHash.getOperations().delete(loginNamesKey);
            users = listAll();
        } else {
            users = listByIds(userIds);
        }

        if (CollectionUtils.isEmpty(users)) {
            return;
        }

        setFaceUrl(users);
        userIds = users.stream().map(User::getId)
                .filter(StringUtils::isNotBlank).collect(Collectors.toList());
        HashOperations<String, String, Set<String>> operations = redisTemplate.opsForHash();
        List<Set<String>> sets = operations.multiGet(loginNamesKey, userIds);
        Set<String> allCacheUserLoginNamesSet = UcUtil.getSet(sets);
        Map<String, String> usersMap = new HashMap<>(users.size());
        Map<String, Ul> userLoginMap = new HashMap<>(users.size());
        Map<String, Set<String>> loginNamesMap = new HashMap<>(users.size());
        Set<String> newUserLoginNamesSet = new HashSet<>();
        List<String> disabledUserIds = new ArrayList<>();
        for (User user : users) {
            if (null == user) {
                continue;
            }

            UserCache userCache = new UserCache();
            if (UcConstants.STATUS_ENABLED.equals(user.getStatus())) {
                BeanUtils.copyProperties(user, userCache);
                usersMap.put(user.getId(), userCache.encode());
            } else {
                disabledUserIds.add(user.getId());
            }

            Ul ul = new Ul(user.getId(), user.getPwd(), user.getStatus());
            String loginName = user.getLoginName();
            Set<String> loginNamesSet = new HashSet<>();
            if (StringUtils.isNotBlank(loginName)) {
                userLoginMap.put(loginName, ul);
                loginNamesSet.add(loginName);
            }

            if (StringUtils.isNotBlank(user.getEmail())) {
                userLoginMap.put(user.getEmail(), ul);
                loginNamesSet.add(user.getEmail());
            }

            if (StringUtils.isNotBlank(user.getMobile())) {
                userLoginMap.put(user.getMobile(), ul);
                loginNamesSet.add(user.getMobile());
            }

            if (StringUtils.isNotBlank(user.getIdCard())) {
                userLoginMap.put(user.getIdCard(), ul);
                loginNamesSet.add(user.getIdCard());
            }

            loginNamesMap.put(user.getId(), loginNamesSet);
            newUserLoginNamesSet.addAll(loginNamesSet);
        }

        allCacheUserLoginNamesSet.removeAll(newUserLoginNamesSet);
        if (CollectionUtils.isNotEmpty(allCacheUserLoginNamesSet)) {
            opsForHash.delete(userLoginKey, allCacheUserLoginNamesSet.toArray());
        }

        opsForHash.putAll(usersKey, usersMap);
        opsForHash.putAll(userLoginKey, userLoginMap);
        opsForHash.putAll(loginNamesKey, loginNamesMap);

        if (CollectionUtils.isNotEmpty(disabledUserIds)) {
            opsForHash.delete(usersKey, disabledUserIds.toArray());
        }
    }

    /**
     * 该方法用于根据属性判断人员是否存在
     *
     * @param property 属性名
     * @param value    属性值
     * @return 是否存在
     */
    public boolean existByProperty(String property, String value) {
        if (StringUtils.isEmpty(property) || StringUtils.isEmpty(value)) {
            throw new IllegalArgumentException("Property or value is empty when existByProperty!");
        }

        Example example = new Example(User.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(property, value)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());

        return userMapper.selectCountByExample(example) > 0;
    }

    /**
     * 根据查询条件分页获取人员列表
     *
     * @param user 查询条件 <ul>
     *             <li>name: 用户名，工号，姓名，手机号 模糊匹配</li>
     *             <li>order：列表排序字段（默认为修改时间倒叙：updatedAt desc）</li>
     *             <li>orgId：部门Id</li>
     *             <li>positionId：岗位Id</li>
     *             <li>statusList：人员状态</li>
     *             </ul>
     * @param page 分页对象
     * @return 人员列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<User> searchUser(User user, Page<User> page) {
        UcUtil.validatePage(page);
        if (user == null) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user not be null!");
        }

        // 不是系统管理员且没有管辖范围
        String orgId = user.getOrgId();
        Set<String> ids = null;
        if (!ContextHandler.isSuperAdmin()) {
            ids = userRangeService.getAllReferIdsFromCache(ContextHandler.getUserId());
            if (CollectionUtils.isEmpty(ids) || (StringUtils.isNotEmpty(orgId) && !ids.contains(user.getOrgId()))) {
                return new Page<>();
            }
        }

        Example example = new Example(User.class);
        example.selectProperties(User.ID, User.NAME, User.CODE, User.LOGIN_NAME, User.MOBILE, User.TYPE, EMAIL,
                POSITION_ID, ORG_ID, User.STATUS, User.LEADER_ID, User.CREATED_AT, User.UPDATED_AT, INIT_PASSWORD);
        setUserConditions(user, example, ids);
        String order = user.getOrder();
        if (StringUtils.isEmpty(order)) {
            order = "updatedAt desc";
        }

        page = search(example, page, order, User.ID);
        fillOrgAndPositName(page.getList());

        return page;
    }

    private void setUserConditions(User user, Example example, Set<String> ids) {
        Example.Criteria criteria = example.createCriteria();
        // 状态查询条件
        List<String> statusList = user.getStatusList();
        if (CollectionUtils.isNotEmpty(statusList)) {
            criteria.andIn(User.STATUS, statusList);
        }

        String status = user.getStatus();
        if (StringUtils.isNotBlank(status)) {
            criteria.andEqualTo(User.STATUS, status);
        }

        // 岗位查询条件
        String positionId = user.getPositionId();
        if (StringUtils.isNotBlank(positionId)) {
            criteria.andEqualTo(POSITION_ID, positionId);
        }

        // 部门查询条件
        String orgId = user.getOrgId();
        if (StringUtils.isNotBlank(orgId)) {
            Org org = orgService.getRootOrg();
            if (!(null != org && orgId.equals(org.getId()))) {
                if (user.isIncludeChild()) {
                    List<String> childIds = orgService.getAuthChildIds(Collections.singleton(orgId), true);
                    if (CollectionUtils.isNotEmpty(childIds)) {
                        criteria.andIn(ORG_ID, childIds);
                    }
                } else {
                    criteria.andEqualTo(ORG_ID, orgId);
                }
            }

        } else if (!ContextHandler.isSuperAdmin() && CollectionUtils.isNotEmpty(ids)) {
            List<String> childIds = orgService.getChildIds(ids, true);
            if (CollectionUtils.isNotEmpty(childIds)) {
                criteria.andIn(ORG_ID, childIds);
            }
        }

        String dataType = user.getDataType();
        if (StringUtils.isNotEmpty(dataType)) {
            if (UcConstants.USER_DATA_TYPE_USER.equals(dataType)) {
                Example.Criteria criteria1 = example.createCriteria();
                criteria1.andEqualTo(DATA_TYPE, dataType)
                        .orIsNull(DATA_TYPE);
                example.and(criteria1);
            } else {
                criteria.andEqualTo(DATA_TYPE, dataType);
            }
        }

        List<String> dataTypeList = user.getDataTypeList();
        if (CollectionUtils.isNotEmpty(dataTypeList)) {
            criteria.andIn(DATA_TYPE, dataTypeList);
        }

        String companyId = user.getCompanyId();
        if (StringUtils.isNotEmpty(companyId)) {
            criteria.andEqualTo(COMPANY_ID, companyId);
        }

        String keywords = user.getKeywords();
        if (StringUtils.isNotEmpty(keywords)) {
            //example.and(criteria.andLike(NAME, SqlUtil.asLike(keywords)).orLike(MOBILE, SqlUtil.asLike(keywords)));
            Example.Criteria weekendCriteria = example.createCriteria();
            weekendCriteria.orLike(User.NAME, SqlUtil.asLike(keywords))
                    .orLike(User.CODE, SqlUtil.asLike(keywords))
                    .orLike(User.MOBILE, SqlUtil.asLike(keywords));
            example.and(weekendCriteria);
        }

        String name = user.getName();
        if (StringUtils.isNotBlank(name)) {
            name = SqlUtil.asLike(name);
            Weekend<User> weekend = new Weekend<>(User.class);
            Example.Criteria weekendCriteria = weekend.createCriteria();
            weekendCriteria.orLike(User.NAME, name)
                    .orLike(User.CODE, name)
                    .orLike(User.MOBILE, name)
                    .orLike(User.LOGIN_NAME, name);
            example.and(weekendCriteria);
        }

        Weekend<User> conWeekend = new Weekend<>(User.class);
        Example.Criteria conWeekendCriteria = conWeekend.createCriteria();
        example.and(conWeekendCriteria);
    }

    /**
     * 根据用户Id批量修改用户状态
     *
     * @param userIds 用户Id列表
     * @param status  用户状态
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void updateStatus(List<String> userIds, String status) {
        if (CollectionUtils.isEmpty(userIds) || StringUtils.isEmpty(status)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userIds or status not be empty!");
        }

        User superAdmin = getSuperAdmin();
        if (superAdmin != null){
            userIds.remove(superAdmin.getId());
            if (CollectionUtils.isEmpty(userIds)) {
                return;
            }
        }

        User user = new User();
        user.setStatus(status);
        userMapper.updateByExampleSelective(user, getExampleByUserIds(userIds));
        putUserToRedis(userIds);
        updateStatusSendMessage(userIds, status);
        // 同步启停用供应商账号
        dealSupplier(userIds, status);
    }

    private void dealSupplier(List<String> userIds, String status) {
        if (!StringUtils.equalsAny(status, UcConstants.STATUS_ENABLED, UcConstants.STATUS_DISABLED)) {
            return;
        }

        User user = new User();
        user.setUserIds(userIds);
//        user.setDataType(UcConstants.USER_DATA_TYPE_SUPPLIER);
        List<User> userList = listByCondition(user, ID, SUPPLIER_ID);
        if (CollectionUtils.isEmpty(userList)) {
            return;
        }

        List<com.purchase.uc.model.Supplier> supplierList = new ArrayList<>(userList.size());
        com.purchase.uc.model.Supplier supplier;
        for (User u : userList) {
            supplier = new com.purchase.uc.model.Supplier();
            supplier.setId(u.getSupplierId());
            supplier.setAccountStatus(UcConstants.STATUS_ENABLED.equals(status) ?
                    UcConstants.SUPPLIER_ACCOUNT_STATUS_ENABLE : UcConstants.SUPPLIER_ACCOUNT_STATUS_DISABLE);
            supplierList.add(supplier);
        }

        supplierService.batchUpdate(supplierList);
    }

    /**
     * 人员状态，冻结，激活 发送消息
     *
     * @param userIds 待发送人员Id
     * @param status  人员状态，冻结，激活
     */
    private void updateStatusSendMessage(List<String> userIds, String status) {
        if (CollectionUtils.isEmpty(userIds)
                || (!UcConstants.STATUS_ENABLED.equals(status)
                && !UcConstants.STATUS_DISABLED.equals(status))) {
            return;
        }

        String templateCode = UcConstants.STATUS_ENABLED.equals(status) ?
                UcConstants.TEMPLATE_CODE_ACCOUNT_ACTIVE : UcConstants.TEMPLATE_CODE_ACCOUNT_FREEZE;
        String remind = "MAIL,NOTICE,SMS";
        sendMessage(userIds, remind, templateCode, new HashMap<>(0));
    }

    private User getSuperAdmin() {
        Example example = new Example(User.class);
        example.createCriteria().andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(LOGIN_NAME, "admin");
        return userMapper.selectOneByExample(example);
    }

    /**
     * 根据用户Id批量重置用户登录密码
     *
     * @param userIds 用户Id列表
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String resetPwd(List<String> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userIds not be empty!");
        }

        LoginSetting loginSetting = csFeignClient.getLoginSetting(false);
        CheckFlow.start(UcErrorCode.RESET_PASSWORD_ERROR).isNotNull(loginSetting);
        String defaultPwd = loginSetting.getDefaultPwd();
        User user = new User();
        user.setPwd(Md5Utils.getMD5(defaultPwd.getBytes()));
        user.setInitPassword(defaultPwd);
        userMapper.updateByExampleSelective(user, getExampleByUserIds(userIds));
        putUserToRedis(userIds);
        resetPwdSendMessage(userIds, defaultPwd);
        return defaultPwd;
    }

    /**
     * 重置密码发送消息
     *
     * @param userIds    待发送人员Id
     * @param defaultPwd 默认密码
     */
    public void resetPwdSendMessage(List<String> userIds, String defaultPwd) {
        if (CollectionUtils.isEmpty(userIds)) {
            return;
        }

        Map<String, Object> params = new HashMap<>(1);
        params.put("PASSWORD", defaultPwd);
        String remind = "MAIL,NOTICE,SMS";
        sendMessage(userIds, remind, UcConstants.TEMPLATE_CODE_PASSWORD_RESET, params);
    }

    /**
     * 发送消息
     *
     * @param userIds      待发送的人员Id
     * @param remind       发送方式：邮件，短信，站内信
     * @param templateCode 发送信息模板
     * @param params       信息内容参数
     */
    private void sendMessage(List<String> userIds, String remind, String templateCode,
                             Map<String, Object> params) {
        CommonUtils.threadPoolExecutor(o -> {});
    }

    private Example getExampleByUserIds(List<String> userIds) {
        Example example = new Example(User.class);
        example.createCriteria().andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andIn(User.ID, userIds);
        return example;
    }

    private Example getExampleByUserId(String userId) {
        Example example = new Example(User.class);
        example.createCriteria().andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(User.ID, userId);
        return example;
    }

    /**
     * 根据用户Id获取用户信息
     *
     * @param userId        用户Id
     * @param includeDetail 是否包含用户detail信息
     * @return 用户信息
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public User loadFromCache(String userId, boolean includeDetail) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        List<User> users = userMapper.listByUserIdFromCache(Collections.singletonList(userId), includeDetail, this);
        if (CollectionUtils.isNotEmpty(users)) {
            return users.get(0);
        }

        return null;
    }

    public void setFaceUrl(List<User> users) {
        if (CollectionUtils.isEmpty(users)) {
            return;
        }

        List<String> faceIds = new ArrayList<>(users.size());
        users.forEach(u -> {
            String faceId = u.getFaceId();
            if (StringUtils.isNotEmpty(faceId)) {
                faceIds.add(faceId);
            }
        });

        if (faceIds.size() == 0) {
            return;
        }

        Map<String, QgFile> fileMap = fileService.getNginxUrl(faceIds);
        if (MapUtils.isEmpty(fileMap)) {
            return;
        }

        users.forEach(u -> {
            QgFile qgFile = fileMap.get(u.getFaceId());
            if (qgFile == null || StringUtils.isEmpty(qgFile.getViewUrl())) {
                return;
            }

            u.setFaceUrl(qgFile.getViewUrl());
        });
    }

    /**
     * 根据用户Id，只从缓存中获取用户基本信息
     *
     * @param userId 用户Id列表
     * @return 用户基本信息
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public UserCache getUserCache(String userId) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        List<UserCache> userCacheList = listByUserIdFromCache(Collections.singletonList(userId));
        if (CollectionUtils.isEmpty(userCacheList)) {
            return null;
        }

        return userCacheList.get(0);
    }

    /**
     * 只从缓存中获取当前公司下所有用户信息列表
     *
     * @return 用户信息列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<UserCache> listAllFromCache() {
        String usersKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USERS;
        Long size = redisTemplate.opsForHash().size(usersKey);
        if (size == 0) {
            return new ArrayList<>(0);
        }

        List<String> users = new ArrayList<>(size.intValue());
        try {
            JedisUtils.hScan(redisTemplate, usersKey, cursor -> {
                Map.Entry<String, String> entry = (Map.Entry<String, String>) cursor.next();
                String value = entry.getValue();
                if (StringUtils.isNotEmpty(value)) {
                    users.add(value);
                }
            });
        } catch (IOException e) {
            log.error("scan all users from cache error", e);
        }

        return UcUtil.toUserCache(users);
    }

    /**
     * 新增保存人员基本信息，并加入缓存
     *
     * @param user 人员信息
     * @return 用户Id
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public JsonResult<?> saveUser(User user) {
        if (StringUtils.isEmpty(ContextHandler.getCorpCode())){
            ContextHandler.setCorpCode("default");
        }
        if (user == null) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user not be null!");
        }

        JsonResult<?> validResult = validUserBaseInfo(user, new User());
        if (validResult != null) {
            throw new UcException(UcErrorCode.UC_LOGIN_NAME_DUPLICATE);
        }

        if (StringUtils.isBlank(user.getPwd())) {
            String defaultPwd = "000000";
            LoginSetting loginSetting = csFeignClient.getLoginSetting(false);
            if (loginSetting != null && StringUtils.isNotBlank(loginSetting.getDefaultPwd())) {
                defaultPwd = loginSetting.getDefaultPwd();
            }
            user.setInitPassword(defaultPwd);

            user.setPwd(Md5Utils.getMD5(defaultPwd.getBytes()));
        }
        user.setType(UcConstants.USER_TYPE_INNER);
        String id = null;
        try {
            id = insert(user);
        }catch (Exception e){
            throw new UcException(UcErrorCode.USER_ERROR_ADD_ERROR);
        }

        UserDetail detail = new UserDetail();
        detail.setUserId(id);
        if (StringUtils.isEmpty(ContextHandler.getUserId())){
            detail.setCreatedBy(user.getCreatedBy());
            detail.setUpdatedBy(user.getUpdatedBy());
        }
        userDetailService.insert(detail);
        List<String> userIds = Collections.singletonList(id);
        putUserToRedis(userIds);
        newUserSendMessage(userIds);
        List<String> roleIds = user.getRoleIds();
        if (CollectionUtils.isEmpty(roleIds)) {
            return new JsonResult<>(true, UcI18nConstants.UC_ADD_SUCCESS.getName());
        }

        userRoleRelService.addUserRoleRel(id, roleIds);
        return new JsonResult<>(true, UcI18nConstants.UC_ADD_SUCCESS.getName());
    }

    /**
     * 新增人员 发送消息
     *
     * @param userIds 待发送人员id
     */
    private void newUserSendMessage(List<String> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            return;
        }

        CommonUtils.threadPoolExecutor(o -> {
            Map<String, Object> params = new HashMap<>(1);
            String remind = "MAIL,NOTICE,SMS";
            sendMessage(userIds, remind, UcConstants.TEMPLATE_CODE_ACCOUNT_OPEN, params);
        });
    }

    /**
     * 更新保存人员基本信息和角色信息，并更新缓存
     *
     * @param user 人员信息
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public JsonResult<?> updateUserAndRole(User user) {
        if (user == null || StringUtils.isEmpty(user.getId())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user not be null!");
        }

        User superAdmin = getSuperAdmin();
        String userId = user.getId();
        if (userId.equals(superAdmin.getId())) {
            return new JsonResult<>(true, UcI18nConstants.UC_CAN_NOT_EDIT_ADMIN.getName());
        }

        User dbUser = get(userId);
        JsonResult<?> validResult = validUserBaseInfo(user, dbUser);
        if (validResult != null) {
            return validResult;
        }

        genUpdateUser(user, dbUser);
        userMapper.updateByExample(dbUser, getExampleByUserId(userId));
        UserDetail detail = user.getUserDetail();
        detail = detail == null ? new UserDetail() : detail;
        detail.setUserId(userId);
        userDetailService.batchUpdateByUserId(Collections.singletonList(detail));
        List<String> delRoleIds = userRoleRelService.getRoleIdsByUserId(userId, null);
        if (CollectionUtils.isNotEmpty(delRoleIds)) {
            userRoleRelService.delUserRoleRel(userId, delRoleIds);
        }
        List<String> roleIds = user.getRoleIds();
        if (CollectionUtils.isNotEmpty(roleIds)) {
            userRoleRelService.addUserRoleRel(userId, roleIds);
        }

        List<String> userIds = Collections.singletonList(userId);
        putUserToRedis(userIds);
        if (dbUser.getOrgId() != null && user.getOrgId() != null) {
            boolean departTransfer = dbUser.getOrgId().equals(user.getOrgId());
            if (!departTransfer) {
                departTransferSendMessage(userIds);
            }
        }

        return new JsonResult<>(true, UcI18nConstants.UC_EDIT_SUCCESS.getName());
    }

    private void genUpdateUser(User user, User dbUser) {
        String code = user.getCode();
        if (code != null) {
            if (StringUtils.isBlank(code)) {
                code = null;
            }

            dbUser.setCode(code);
        }

        String email = user.getEmail();
        if (email != null) {
            if (StringUtils.isBlank(email)) {
                email = null;
            }

            dbUser.setEmail(email);
        }

        String mobile = user.getMobile();
        if (mobile != null) {
            if (StringUtils.isBlank(mobile)) {
                mobile = null;
            }

            dbUser.setMobile(mobile);
        }

        String idCard = user.getIdCard();
        if (idCard != null) {
            if (StringUtils.isBlank(idCard)) {
                idCard = null;
            }

            dbUser.setIdCard(idCard);
        }

        String name = user.getName();
        if (StringUtils.isNotBlank(name)) {
            dbUser.setName(name);
        }

        String loginName = user.getLoginName();
        if (StringUtils.isNotBlank(loginName)) {
            dbUser.setLoginName(loginName);
        }

        String leaderId = user.getLeaderId();
        if (StringUtils.isNotBlank(leaderId)) {
            dbUser.setLeaderId(leaderId);
        }

        String orgId = user.getOrgId();
        if (StringUtils.isNotBlank(orgId)) {
            dbUser.setOrgId(orgId);
        }

        String faceId = user.getFaceId();
        if (StringUtils.isNotBlank(faceId)) {
            dbUser.setFaceId(faceId);
        }

        String positionId = user.getPositionId();
        if (StringUtils.isNotBlank(positionId)) {
            dbUser.setPositionId(positionId);
        }

        Integer age = user.getAge();
        if (age != null) {
            dbUser.setAge(age);
        }

        LocalDate entryAt = user.getEntryAt();
        if (entryAt != null) {
            dbUser.setEntryAt(entryAt);
        }

        if (StringUtils.isNotBlank(user.getPwd())) {
            dbUser.setPwd(Md5Utils.getMD5(user.getPwd().getBytes()));
        }

//        if (user.getCategory() != null) {
//            dbUser.setCategory(user.getCategory());
//        }
    }

    /**
     * 更新保存人员基本信息和角色信息，并更新缓存
     *
     * @param user 人员信息
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public JsonResult<?> updateUserOnly(User user) {
        if (user == null || StringUtils.isEmpty(user.getId())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user not be null!");
        }

        String userId = user.getId();
        User dbUser = get(userId);
        JsonResult<?> validResult = validUserBaseInfo(user, dbUser);
        if (validResult != null) {
            return validResult;
        }

        genUpdateUser(user, dbUser);
        userMapper.updateByExample(dbUser, getExampleByUserId(userId));
        UserDetail detail = user.getUserDetail();
        detail = detail == null ? new UserDetail() : detail;
        detail.setUserId(userId);
        userDetailService.batchUpdateByUserId(Collections.singletonList(detail));
        List<String> userIds = Collections.singletonList(userId);
        putUserToRedis(userIds);
        return new JsonResult<>(true, UcI18nConstants.UC_EDIT_SUCCESS.getName());
    }

    /**
     * 部门调动，发送消息
     *
     * @param userIds 待发送人员Ids
     */
    private void departTransferSendMessage(List<String> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            return;
        }

        String remind = "MAIL,NOTICE,SMS";
        sendMessage(userIds, remind, UcConstants.TEMPLATE_CODE_DEPART_TRANSFER, new HashMap<>(0));
    }

    private JsonResult<?> validUserBaseInfo(User user, User dbUser) {
        String code = user.getCode();
        if (StringUtils.isNotBlank(code) && !code.equals(dbUser.getCode())) {
            if (existByProperty(CODE, code)) {
                return new JsonResult<>(false, UcI18nConstants.UC_USER_CODE_DUPLICATE.getName());
            }
        }

        String loginName = user.getLoginName();
        if (StringUtils.isNotBlank(loginName) && !loginName.equals(dbUser.getLoginName())) {
            if (existByProperty(LOGIN_NAME, loginName)) {
                return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_NAME_DUPLICATE.getName());
            }
        }

        String email = user.getEmail();
        if (StringUtils.isNotBlank(email) && !email.equals(dbUser.getEmail())) {
            if (existByProperty(EMAIL, email)) {
                return new JsonResult<>(false, UcI18nConstants.UC_EMAIL_DUPLICATE.getName());
            }
        }

//        String mobile = user.getMobile();
//        if (StringUtils.isNotBlank(mobile) && !mobile.equals(dbUser.getMobile())) {
//            if (existByProperty(MOBILE, mobile)) {
//                return new JsonResult<>(false, UcI18nConstants.UC_MOBILE_DUPLICATE.getName());
//            }
//        }

        String idCard = user.getIdCard();
        if (StringUtils.isNotBlank(idCard) && !idCard.equals(dbUser.getIdCard())) {
            if (existByProperty(ID_CARD, idCard)) {
                return new JsonResult<>(false, UcI18nConstants.UC_ID_CARD_DUPLICATE.getName());
            }
        }

        return null;
    }

    /**
     * 人员信息列表导出
     */
    public CommonExportTask export(User user) {
        if (user == null) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user not be null!");
        }

        String exportType = UcConstants.EXPORT_TYPE_USER;
        CommonExportTask exportTask = CommonExportTask.getInstance(exportType, exportType);
        exportTaskService.save(exportTask);
        String status = UcConstants.STATUS_FINISHED;
        String fileId = null;
        try {
            String filePath = executeExport(user);
            File file = new File(filePath);
            if (!file.exists()) {
                status = UcConstants.STATUS_FAILED;
            }

            String name = file.getName();
            fileId = name.substring(0, name.lastIndexOf("."));
        } catch (Exception e) {
            log.error("export user failed", e);
            status = UcConstants.STATUS_FAILED;
        }

        exportTask.setFileId(fileId);
        exportTask.setStatus(status);
        exportTask.setFinishTime(new Date());
        exportTaskService.update(exportTask);
        return exportTask;
    }

    /**
     * 执行人员信息列表导出业务
     */
    private String executeExport(User user) {
        Page<User> page = new Page<>();
        int pageSize = 5000;
        page.setPageSize(pageSize);
        int pageNum = 1, count = 1, sheetNum = 1;
        boolean hasNextPage = true;
        ExcelWriterFactory excelWriterFactory = ExportExcelUtil.start(userExportPath);
        String sheetName = "人员信息表-" + sheetNum++;
        ExcelWriterFactory.WriterRowModels writer = excelWriterFactory.newSheet(sheetName, ExportExcelUser.class);
        while (hasNextPage) {
            page.setPageNum(pageNum++);
            Page<User> userPage = searchUser(user, page);
            List<User> users = userPage.getList();
            if (users == null || users.size() == 0) {
                break;
            }

            if (count++ > 10) {
                count = 2;
                writer = excelWriterFactory.newSheet("人员信息表-" + sheetNum++, ExportExcelUser.class);
            }

            hasNextPage = users.size() == pageSize;
            List<ExportExcelUser> excelUsers = getExcelUsers(users);
            writer.write(excelUsers);
        }

        excelWriterFactory.finish();
        return excelWriterFactory.getPath();
    }

    private List<ExportExcelUser> getExcelUsers(List<User> users) {
        int size = users.size();
        Set<String> orgIds = new HashSet<>(size);
        Set<String> positIds = new HashSet<>(size);
        Set<String> leaderIds = new HashSet<>(size);
        List<String> userIds = new ArrayList<>(size);
        users.forEach(u -> {
            userIds.add(u.getId());
            orgIds.add(u.getOrgId());
            String positionId = u.getPositionId();
            if (StringUtils.isNotEmpty(positionId)) {
                positIds.add(positionId);
            }

            String leaderId = u.getLeaderId();
            if (StringUtils.isNotEmpty(leaderId)) {
                leaderIds.add(leaderId);
            }
        });

        Map<String, Position> positionMap;
        if (CollectionUtils.isEmpty(positIds)) {
            positionMap = new HashMap<>(0);
        } else {
            positionMap = positionService.getPositionMap(positIds);
        }

        Map<String, UserCache> userCacheMap;
        if (CollectionUtils.isEmpty(leaderIds)) {
            userCacheMap = new HashMap<>(0);
        } else {
            userCacheMap = getUserMapFromCache(leaderIds);
        }

        Map<String, String> categoryIdAndNamePathMap = categoryService.
                getCategoryIdAndNamePathMap(CommonConstant.COMMON_TREE_FUN_CODE_UC_POSITION_CATEGORY);
        Map<String, Org> orgMap = orgService.getOrgMap(orgIds);
        Map<String, UserDetail> userDetailMap = userDetailService.getUserIdAndDetailMap(userIds);
        List<ExportExcelUser> excelUsers = new ArrayList<>(users.size());
        users.forEach(u -> {
            String orgId = u.getOrgId();
            if (StringUtils.isNotEmpty(orgId) && MapUtils.isNotEmpty(orgMap)) {
                Org org = orgMap.get(orgId);
                if (org != null) {
                    u.setOrgCode(org.getCode());
                    u.setOrgName(org.getName());
                    u.setOrgNamePath(org.getNamePath());
                }
            }

            String positionId = u.getPositionId();
            if (StringUtils.isNotEmpty(positionId)) {
                Position position = positionMap.get(positionId);
                if (position != null) {
                    u.setPositionName(position.getName());
                    u.setPositionCode(position.getCode());
                    String categoryName = categoryIdAndNamePathMap.get(position.getCategoryId());
                    u.setPositCategory(categoryName);
                }
            }

            String leaderId = u.getLeaderId();
            if (StringUtils.isNotEmpty(leaderId)) {
                UserCache cache = userCacheMap.get(leaderId);
                if (cache != null) {
                    String name = cache.getName();
                    u.setLeaderName(name);
                    u.setLeaderCode(cache.getCode());
                }
            }

            String status = u.getStatus();
            if (UcConstants.STATUS_ENABLED.equals(status)) {
                status = "启用";
            } else if (UcConstants.STATUS_DISABLED.equals(status)) {
                status = "禁用";
            } else if (UcConstants.STATUS_DELETED.equals(status)) {
                status = "删除";
            } else if (UcConstants.STATUS_LEAVE.equals(status)) {
                status = "离职";
            } else {
                status = "无效";
            }

            u.setStatus(status);
            ExportExcelUser excelUser = new ExportExcelUser();
            BeanUtils.copyProperties(u, excelUser);
            excelUser.setCreatedAt(u.getCreatedAt().toLocalDate());
            excelUser.setUpdatedAt(u.getUpdatedAt().format(UcConstants.TIME_FORMATTER));
            excelUsers.add(excelUser);
            UserDetail detail = userDetailMap.get(u.getId());
            if (detail == null) {
                return;
            }

            String sex = detail.getSex();
            if (UcConstants.SEX_MALE.equals(sex)) {
                sex = "男";
            } else if (UcConstants.SEX_FEMALE.equals(sex)) {
                sex = "女";
            } else {
                sex = "保密";
            }
            detail.setSex(sex);
            BeanUtils.copyProperties(detail, excelUser);
        });

        return excelUsers;
    }

    /**
     * 导入人员信息
     *
     * @param fileId 上传文件Id
     */
    public String importUser(String fileId) {
        if (StringUtils.isEmpty(fileId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "fileId not be empty!");
        }

        Response response = fileFeignClient.download(fileId);
        try (InputStream inputStream = response.body().asInputStream()) {
            UserImportBaseExcelListener bean = applicationContext.getBean(UserImportBaseExcelListener.class);
            bean.init(ContextHandler.getUserId());
            ExcelUtil.readExcel(inputStream, bean, ImportExcelUser.class);
            return bean.getErrorFileId();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public String importUpdateUser(String fileId) {
        if (StringUtils.isEmpty(fileId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "fileId not be empty!");
        }

        Response response = fileFeignClient.download(fileId);
        try (InputStream inputStream = response.body().asInputStream()) {
            UserUpdateImportBaseExcelListener bean =
                    applicationContext.getBean(UserUpdateImportBaseExcelListener.class);
            bean.init(ContextHandler.getUserId());
            ExcelUtil.readExcel(inputStream, bean, UpdateImportExcelUser.class);
            return bean.getErrorFileId();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * 登录接口
     *
     * @param loginName 登录名
     * @param password  密码
     * @param corpCode  公司编号
     * @param openId
     * @return 用户ID结果集
     */
    public JsonResult<?> login(String loginName, String password, String corpCode, String openId) {
        if (StringUtils.isEmpty(loginName) || StringUtils.isEmpty(password) || StringUtils.isEmpty(corpCode)) {
            return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
                    UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
        }

        /*String userLoginKey = UcRedisKeys.UC_ + corpCode + UcRedisKeys.USER_LOGIN;
        HashOperations<String, String, Ul> operations = redisTemplate.opsForHash();
        Ul ul = operations.get(userLoginKey, loginName);
        if (ul == null) {*/
            User user = getUserByField(LOGIN_NAME, loginName);
            if (user == null) {
                return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
                        UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
            }

            Ul ul = new Ul();
            ul.setPwd(user.getPwd());
            ul.setUId(user.getId());
            ul.setStatus(user.getStatus());
        //}

        String status = ul.getStatus();
        if (!UcConstants.STATUS_ENABLED.equals(status)) {
            return new JsonResult<>(false, UcI18nConstants.UC_STATUS_DISABLED.getCode(),
                    UcI18nConstants.UC_USER_STATUS_ERROR.getName(), null);
        }

        if (StringUtils.isEmpty(ul.getPwd()) || !ul.getPwd().equals(Md5Utils.getMD5(password, "UTF-8"))) {
            return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
                    UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
        }

        // 更新openId
        if (StringUtils.isNotBlank(openId)) {
            UserDetail userDetail = new UserDetail();
            userDetail.setUserId(ul.getUId());
            userDetail.setWechat(openId);
            userDetail.setCorpCode(corpCode);
            userDetail.setUpdatedBy(ul.getUId());
            userDetail.setUpdatedAt(LocalDateTime.now());
            userDetailService.updateDetailByUserId(userDetail);
        }

        return new JsonResult<>(true, null, ul.getUId());
    }

    /**
     * 根据用户Id判断是否为admin账号
     *
     * @param userId 用户Id
     * @return 是否为admin账号
     */
    public boolean isAdminAccount(String userId) {
        UserCache user = getUserCache(userId);
        return user != null && UcConstants.ACCOUNT_ADMIN.equals(user.getLoginName());
    }

    /**
     * 根据群组Id列表，缓存中获取群组下所有的人员信息列表
     *
     * @param groupIds 群组Id列表
     * @return 人员信息列表
     */
    public List<UserCache> listUserByGroupIdsFromCache(Collection<String> groupIds) {
        if (CollectionUtils.isEmpty(groupIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "groupIds not be empty!");
        }

        Set<String> userIds = groupMemberService.listUserIdsFromCache(groupIds);
        if (CollectionUtils.isEmpty(userIds)) {
            return new ArrayList<>(0);
        }

        return listByUserIdFromCache(userIds);
    }

    /**
     * 根据用户Id列表，从缓存中批量获取用户信息列表
     *
     * @param userIds 用户Id列表
     * @return 用户信息列表
     */
    public List<UserCache> listByUserIdFromCache(Collection<String> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userIds not be empty!");
        }

        String usersKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USERS;
        HashOperations<String, String, String> operations = redisTemplate.opsForHash();
        List<String> users = operations.multiGet(usersKey, userIds);
        return UcUtil.toUserCache(users);
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<User> searchAllAdmin(UserCondition condition) {
        Page<User> pageInfo = new Page<>();
        condition.setCorpCode(ContextHandler.getCorpCode());
        int pageTotal = userMapper.getUserTotal(condition);
        if (pageTotal <= 0) {
            return pageInfo;
        }

        List<User> list = userMapper.searchUser(condition, condition.getPage());
        if (CollectionUtils.isNotEmpty(list)) {
            pageInfo.setTotal(pageTotal);
            pageInfo.setList(list);
            list = fillOrgAndPositName(list);
            pageInfo.setSize(list.size());
        }

        return pageInfo;
    }

    /**
     * 查询当前人员
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Set<String> findAllRelIdsByUserId(String userId) {
        Set<String> allRelIds = new HashSet<>();
        List<UserCache> useCacheList = listByUserIdFromCache(Collections.singletonList(userId));
        if (CollectionUtils.isEmpty(useCacheList)) {
            return allRelIds;
        }

        UserCache userCache = useCacheList.get(0);
        // 用户id
        allRelIds.add(userCache.getId());

        // 岗位id
        if (StringUtils.isNotBlank(userCache.getPositionId())) {
            allRelIds.add(userCache.getPositionId());
        }

        // 部门ids
        List<String> orgList = orgService.getChildIds(Collections.singletonList(userCache.getOrgId()), true);
        if (CollectionUtils.isNotEmpty(orgList)) {
            allRelIds.addAll(orgList);
        }

        // 群组ids
        Set<String> groupIds = groupMemberService.findGroupsByuserId(userId);
        if (CollectionUtils.isNotEmpty(groupIds)) {
            allRelIds.addAll(groupIds);
        }

        return allRelIds;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Set<String> getAllRelIdsByUserId(String userId) {
        Set<String> allRelIds = new HashSet<>();
        List<UserCache> useCacheList = listByUserIdFromCache(Collections.singletonList(userId));
        if (CollectionUtils.isEmpty(useCacheList)) {
            return allRelIds;
        }

        UserCache userCache = useCacheList.get(0);
        // 用户id
        allRelIds.add(userCache.getId());
        String orgId = userCache.getOrgId();
        allRelIds.add(orgId);
        // 岗位id
        if (StringUtils.isNotBlank(userCache.getPositionId())) {
            allRelIds.add(userCache.getPositionId() + "_" + orgId);
        }

        // 部门ids
        List<String> orgList = orgService.getParentIds(orgId, true);
        if (CollectionUtils.isNotEmpty(orgList)) {
            allRelIds.addAll(orgList);
        }

        // 群组ids
        Set<String> groupIds = groupMemberService.findGroupsByuserId(userId);
        if (CollectionUtils.isNotEmpty(groupIds)) {
            allRelIds.addAll(groupIds);
        }

        return allRelIds;
    }

    /**
     * 手机端（学员端） 修改密码
     *
     * @param oldPassword   旧密码
     * @param newPassword   新密码
     * @param againPassword 确认密码
     */
    public void appModifyPwd(String oldPassword, String newPassword, String againPassword) {
        CheckFlow.start().isNotEmpty(oldPassword).isNotEmpty(newPassword).isNotEmpty(againPassword);
        if (!newPassword.equals(againPassword)) {
            throw new UcException(UcErrorCode.PASSWORD_NOT_EQUAL);
        }

        User user = get(ContextHandler.getUserId());
        if (!Md5Utils.getMD5(oldPassword.getBytes()).equals(user.getPwd())) {
            throw new UcException(UcErrorCode.OLD_PASSWORD_ERROR);
        }

        /*JsonResult<Boolean> result = csFeignClient.validatePassword(newPassword);
        if (result == null || !result.isSuccess() || !result.getData()) {
            String msg = result != null ? result.getMsg() : null;
            throw new UcException(UcErrorCode.INVALID_PASSWORD, msg);
        }*/

        User newUser = new User();
        newUser.setPwd(Md5Utils.getMD5(newPassword.getBytes()));
        Example example = new Example(User.class);
        example.createCriteria().andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(User.ID, ContextHandler.getUserId());
        userMapper.updateByExampleSelective(newUser, example);
        putUserToRedis(Collections.singletonList(ContextHandler.getUserId()));
    }

    /**
     * 导入人员，保存已经校验成功的人员信息
     *
     * @param list 人员信息列表
     */
    public void saveImport(List<ImportExcelUser> list) {
        if (CollectionUtils.isEmpty(list)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "param not be empty!");
        }

        String defaultPwd = settingService.getDefaultPwd();
        defaultPwd = Md5Utils.getMD5(defaultPwd.getBytes());
        String corpCode = ContextHandler.getCorpCode();
        List<String> userIds = new ArrayList<>(list.size());
        for (ImportExcelUser excelUser : list) {
            try {
                excelUser.setSex(UcUtil.getSex(excelUser.getSex()));
                excelUser.setStatus(UcConstants.STATUS_ENABLED);
                String orgId = excelUser.getOrgId();
                if (UcConstants.NEED_ADD.equals(orgId)) {
                    orgId = orgService.addOrg(excelUser.getOrgNamePath(), excelUser.getOrgCode());
                    excelUser.setOrgId(orgId);
                }

                String positionId = excelUser.getPositionId();
                if (UcConstants.NEED_ADD.equals(positionId)) {
                    String category = excelUser.getPositionCategory();
                    String code = excelUser.getPositionCode();
                    positionId = positionService.addPosition(category, code, excelUser.getPositionName());
                    excelUser.setPositionId(positionId);
                }

                User user = new User();
                BeanUtils.copyProperties(excelUser, user);
                user.setPwd(defaultPwd);
                user.setCorpCode(corpCode);
                String userId = insert(user);
                userIds.add(userId);
                UserDetail detail = new UserDetail();
                BeanUtils.copyProperties(excelUser, detail);
                detail.setCorpCode(corpCode);
                detail.setUserId(userId);
                userDetailService.insert(detail);
            } catch (Exception e) {
                log.error("saveUser import user error!", e);
            }
        }

        putUserToRedis(userIds, corpCode);
        newUserSendMessage(userIds);
    }

    /**
     * 修改导入人员，保存已经校验成功的人员信息
     *
     * @param dataList 人员信息列表
     */
    public void updateImport(List<UpdateImportExcelUser> dataList) {
        if (CollectionUtils.isEmpty(dataList)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "param not be empty!");
        }

        List<String> userIds = new ArrayList<>(dataList.size());
        List<String> departTransferUserIds = new ArrayList<>(dataList.size());
        dataList.forEach(user -> userIds.add(user.getId()));
        Map<String, String> userIdAndOrgIdMap = getUserIdAndOrgIdMap(userIds);
        String corpCode = ContextHandler.getCorpCode();
        for (UpdateImportExcelUser excelUser : dataList) {
            excelUser.setSex(UcUtil.getSex(excelUser.getSex()));
            excelUser.setStatus(UcUtil.getStatus(excelUser.getStatus()));
            String userId = excelUser.getId();
            String orgId = excelUser.getOrgId();
            if (UcConstants.NEED_ADD.equals(orgId)) {
                orgId = orgService.addOrg(excelUser.getOrgNamePath(), excelUser.getOrgCode());
                excelUser.setOrgId(orgId);
            }

            String oldOrgId = userIdAndOrgIdMap.get(userId);
            boolean departTransfer = oldOrgId.equals(excelUser.getOrgId());
            String positionId = excelUser.getPositionId();
            if (UcConstants.NEED_ADD.equals(positionId)) {
                String category = excelUser.getPositionCategory();
                String code = excelUser.getPositionCode();
                String positionName = excelUser.getPositionName();
                positionId = positionService.addPosition(category, code, positionName);
                excelUser.setPositionId(positionId);
            }

            User user = new User();
            BeanUtils.copyProperties(excelUser, user);
            user.setCorpCode(corpCode);
            user.setUpdatedAt(LocalDateTime.now());
            user.setUpdatedBy(ContextHandler.getUserId());
            UserDetail detail = new UserDetail();
            BeanUtils.copyProperties(excelUser, detail);
            detail.setId(null);
            detail.setUserId(userId);
            detail.setCorpCode(corpCode);
            detail.setUpdatedAt(LocalDateTime.now());
            detail.setUpdatedBy(ContextHandler.getUserId());
            userMapper.updateUser(user);
            userDetailService.updateDetailByUserId(detail);
            if (!departTransfer) {
                departTransferUserIds.add(userId);
            }
        }

        putUserToRedis(userIds, corpCode);
        departTransferSendMessage(departTransferUserIds);
    }

    private Map<String, String> getUserIdAndOrgIdMap(List<String> userIds) {
        List<User> users = listByIds(userIds, User.ID, ORG_ID);
        if (CollectionUtils.isEmpty(users)) {
            return Collections.emptyMap();
        }

        Map<String, String> userIdAndOrgIdMap = new HashMap<>(users.size());
        users.forEach(user -> userIdAndOrgIdMap.put(user.getId(), user.getOrgId()));
        return userIdAndOrgIdMap;
    }

    /**
     * 根据id获取用户信息，包含detail，role 信息
     *
     * @param userId 用户Id
     * @return 用户详细信息
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public User getUserAllInfo(String userId) {
        User user = loadFromCache(userId, true);
        if (user == null) {
            return null;
        }

        String leaderId = user.getLeaderId();
        if (StringUtils.isNotEmpty(leaderId)) {
            User leader = loadFromCache(leaderId, false);
            if (leader != null) {
                user.setLeaderName(leader.getName());
            }
        }

        fillOrgAndPositName(Collections.singletonList(user));
        // 获取用户所有角色
        List<Role> roles = roleService.listByUserId(userId, null);
        if (CollectionUtils.isNotEmpty(roles)) {
            user.setRoleIds(roles.stream().map(Role::getId).collect(Collectors.toList()));
            user.setRoles(roles);
        }

        return user;
    }

    /**
     * 根据id获取用户信息，包含detail，role 信息
     *
     * @param userId 用户Id
     * @return 用户详细信息
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public User getFrontUserForAdmin(String userId) {
        User user = loadFromCache(userId, true);
        if (user == null) {
            return null;
        }

        user.setCorpCode(ContextHandler.getCorpCode());
        if (StringUtils.isNotEmpty(user.getSupplierId())){
            com.purchase.uc.model.Supplier supplier = supplierService.get(user.getSupplierId());
            user.setSupplierDataType(supplier.getDataType());
            user.setSupplierStatus(supplier.getStatus());
            user.setSupplierType(supplier.getType());
        }
//        TreeNode authTree = authService.getAuthTreeByUserId(userId, null);
//        if (authTree != null) {
//            List<String> authCodes = getAuthCodes(authTree);
//            user.setAuthCodes(authCodes);
//        }

        boolean hasAdminRole = roleService.checkUserHasAdminRole(userId);
        user.setAdminRole(hasAdminRole);
        return user;
    }


    /**
     * 根据id获取用户信息，包含detail，role 信息
     *
     * @param userId 用户Id
     * @return 用户详细信息
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public User getFrontUser(String userId) {
        User user = loadFromCache(userId, true);
        if (user == null) {
            return null;
        }

        String orgName = orgService.getOrgNameFromCache(user.getOrgId());
        user.setOrgName(orgName);
        String positionId = user.getPositionId();
        if (StringUtils.isNotEmpty(positionId)) {
            String name = positionService.getPropertyValById(positionId, Position.NAME, String.class);
            user.setPositionName(name);
        }

        user.setCorpCode(ContextHandler.getCorpCode());
        Set<String> appCodes = saasCorpService.getAssignAppCode(ContextHandler.getCorpCode());
        if (CollectionUtils.isEmpty(appCodes)) {
            appCodes = new HashSet<>(1);
        }

        boolean outerUser = userRoleRelService.isOuterUser();
        if (outerUser) {
            appCodes.add(UcConstants.OUTER_USER_ROLE);
        }

        user.setAuthCodes(new ArrayList<>(appCodes));
        return user;
    }

    /**
     * 获取当前公司所有已冻结的人员
     *
     * @return 所有已冻结的人员
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<User> getAllDisabledUsers() {
        Example example = new Example(User.class);
        example.selectProperties(User.ID, User.CODE, User.LOGIN_NAME, User.MOBILE, User.EMAIL, User.ID_CARD);
        example.createCriteria()
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(User.STATUS, UcConstants.STATUS_DISABLED);

        return userMapper.selectByExample(example);
    }

    /**
     * 根据姓名/用户名/工号/手机号 模糊查询匹配的userId列表
     *
     * @param keyword 姓名/用户名/工号/手机号
     * @return userId列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<String> getUserIdsByKeyword(String keyword) {
        if (StringUtils.isEmpty(keyword)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "keyword not be empty!");
        }

        Example example = new Example(User.class);
        example.selectProperties(User.ID)
                .createCriteria().andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        Weekend<User> weekend = new Weekend<>(User.class);
        Example.Criteria weekendCriteria = weekend.createCriteria();
        keyword = SqlUtil.asLike(keyword);
        weekendCriteria.orLike(User.NAME, keyword)
                .orLike(User.CODE, keyword)
                .orLike(User.MOBILE, keyword)
                .orLike(User.LOGIN_NAME, keyword);
        example.and(weekendCriteria);
        example.setDistinct(true);
        List<User> users = userMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(users)) {
            return new ArrayList<>(0);
        }

        List<String> userIds = new ArrayList<>(users.size());
        users.forEach(user -> userIds.add(user.getId()));
        return userIds;
    }

    /**
     * 根据用户名/工号/手机号 查询的用户信息
     *
     * @param field 用户名/工号/手机号
     * @return 用户信息
     */
    public User getUserByFieldWithoutCache(String field, String value) {
        if (StringUtils.isEmpty(field) || StringUtils.isEmpty(value)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "field and value not be empty!");
        }

        return getByProperty(field, value, ID);
    }

    /**
     * 新增/更新外部人员基本信息，通过手机号区分唯一，并加入缓存
     *
     * @param users 外部人员信息
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> saveOrUpdateOuterUser(List<User> users) {
        if (CollectionUtils.isEmpty(users)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user not be empty!");
        }

        Map<String, String> mobileAndIdMap = getMobileAndIdMap(users);
        if (MapUtils.isEmpty(mobileAndIdMap)) {
            setOuterUserCommonInfo(users);
            return batchInsert(users);
        }

        List<String> userIds = new ArrayList<>(users.size());
        List<User> updateUsers = new ArrayList<>(users);
        for (Iterator<User> iterator = users.iterator(); iterator.hasNext(); ) {
            User user = iterator.next();
            String mobile = user.getMobile();
            String userId = mobileAndIdMap.get(mobile);
            if (StringUtils.isNotEmpty(userId)) {
                user.setId(userId);
                updateUsers.add(user);
                userIds.add(userId);
                iterator.remove();
            }
        }

        if (users.size() > 0) {
            setOuterUserCommonInfo(users);
            userIds.addAll(batchInsert(users));
        }

        if (updateUsers.size() > 0) {
            batchUpdate(updateUsers);
        }

        putUserToRedis(userIds);
        return userIds;
    }

    private void setOuterUserCommonInfo(List<User> users) {
        String orgId = orgService.getOuterOrgId();
        String roleId = roleService.getRoleIdByCode(UcConstants.OUTER_USER_ROLE);
        List<String> roleIds = CommonUtils.singletonList(roleId);
        String defaultPwd = settingService.getDefaultPwd();
        String pwd = Md5Utils.getMD5(defaultPwd.getBytes());
        for (User user : users) {
            String mobile = user.getMobile();
            user.setCode(mobile);
            user.setLoginName(mobile);
            user.setRoleIds(roleIds);
            user.setOrgId(orgId);
            user.setType(UcConstants.USER_TYPE_OUTER);
            user.setStatus(CommonConstant.STATUS_ENABLED);
            user.setPwd(pwd);
        }
    }

    private Map<String, String> getMobileAndIdMap(List<User> users) {
        List<String> mobiles = users.stream().map(User::getMobile).
                collect(Collectors.toCollection(() -> new ArrayList<>(users.size())));
        List<User> userList = getUsersByMobile(mobiles, ID, MOBILE);
        if (CollectionUtils.isEmpty(userList)) {
            return new HashMap<>(0);
        }

        return userList.stream().collect(Collectors.toMap(User::getMobile, BaseModel::getId,
                (a, b) -> b, () -> new HashMap<>(userList.size())));
    }

    public List<User> getUsersByMobile(Collection<String> mobiles, String... properties) {
        Example example = new Example(entityClass);
        if (ArrayUtils.isNotEmpty(properties)) {
            example.selectProperties(properties);
        }

        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andIn(MOBILE, mobiles);
        return userMapper.selectByExample(example);
    }

    /**
     * 新增保存外部人员基本信息，并加入缓存
     *
     * @param user 外部人员信息
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public JsonResult<String> saveOuterUser(User user) {
        if (user == null) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user not be null!");
        }

        String email = user.getEmail();
        if (StringUtils.isNotBlank(email) && existByProperty(EMAIL, email)) {
            return new JsonResult<>(false, UcI18nConstants.UC_EMAIL_DUPLICATE.getName());
        }

        String mobile = user.getMobile();
        if (StringUtils.isBlank(mobile)) {
            return new JsonResult<>(false, UcI18nConstants.UC_MOBILE_EMPTY.getName());
        }

        if (existByProperty(MOBILE, mobile)) {
            return new JsonResult<>(false, UcI18nConstants.UC_MOBILE_DUPLICATE.getName());
        }

        user.setCode(mobile);
        user.setLoginName(mobile);
        String roleId = roleService.getRoleIdByCode(UcConstants.OUTER_USER_ROLE);
        if (StringUtils.isEmpty(roleId)) {
            return new JsonResult<>(false, UcErrorCode.ROLE_ERROR_ROLE_EMPTY.getText());
        }

        user.setRoleIds(Collections.singletonList(roleId));
        String orgId = orgService.getOuterOrgId();
        if (StringUtils.isEmpty(orgId)) {
            return new JsonResult<>(false, UcErrorCode.ORGANIZE_ERROR_ADD_ERROR.getText());
        }

        user.setOrgId(orgId);
        user.setType(UcConstants.USER_TYPE_OUTER);
        String defaultPwd = settingService.getDefaultPwd();
        user.setPwd(Md5Utils.getMD5(defaultPwd.getBytes()));
        String id = insert(user);
        UserDetail detail = user.getUserDetail();
        detail = detail == null ? new UserDetail() : detail;
        detail.setUserId(id);
        userDetailService.insert(detail);
        List<String> userIds = Collections.singletonList(id);
        putUserToRedis(userIds);
        newUserSendMessage(userIds);
        List<String> roleIds = user.getRoleIds();
        userRoleRelService.addUserRoleRel(id, roleIds);
        return new JsonResult<>(true, UcI18nConstants.UC_ADD_SUCCESS.getName());
    }

    /**
     * 更新外部人员基本信息，并加入缓存
     *
     * @param user 外部人员信息
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public JsonResult<?> updateOuterUser(User user) {
        if (user == null) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user not be null!");
        }

        String userId = user.getId();
        User dbUser = get(userId);
        String email = user.getEmail();
        if (StringUtils.isNotBlank(email) && !email.equals(dbUser.getEmail())) {
            if (existByProperty(EMAIL, email)) {
                return new JsonResult<>(false, UcI18nConstants.UC_EMAIL_DUPLICATE.getName());
            }
        } else if (StringUtils.isBlank(email)) {
            user.setEmail("null");
        }


        String mobile = user.getMobile();
        if (StringUtils.isBlank(mobile)) {
            return new JsonResult<>(false, UcI18nConstants.UC_MOBILE_EMPTY.getName());
        }

        if (!mobile.equals(dbUser.getMobile())) {
            if (existByProperty(MOBILE, mobile)) {
                return new JsonResult<>(false, UcI18nConstants.UC_MOBILE_DUPLICATE.getName());
            }
        }

        user.setCode(mobile);
        user.setLoginName(mobile);
        user.setUpdatedBy(ContextHandler.getUserId());
        user.setCorpCode(ContextHandler.getCorpCode());
        userMapper.updateUser(user);
        UserDetail detail = user.getUserDetail();
        detail.setUserId(userId);
        userDetailService.batchUpdateByUserId(Collections.singletonList(detail));
        putUserToRedis(Collections.singletonList(userId));
        return new JsonResult<>(true, UcI18nConstants.UC_ADD_SUCCESS.getName());
    }


    /**
     * 根据开放、下发范围，从缓存中查询用户Id与用户类型的映射
     * <br/>
     * <b>注：如果开放范围是USER,当此时获取人员时已被冻结，此接口依然返回了已选的userId，type默认为INNER</b>
     *
     * @param commonRelList 开放、下发范围
     * @return 用户Id与用户类型(内部 / 外部)的映射
     */
    public Map<String, String> getUserIdByScope(List<? extends CommonRel> commonRelList) throws IOException {
        if (CollectionUtils.isEmpty(commonRelList)) {
            return new HashMap<>(0);
        }

        Map<String, String> userIdAndTypeMap = new HashMap<>();
        Map<String, Boolean> orgIdMap = new HashMap<>();
        Map<String, Map<String, Boolean>> positIdAndOrgIdMap = new HashMap<>();
        dealCommonRel(commonRelList, userIdAndTypeMap, orgIdMap, positIdAndOrgIdMap);
        if (userIdAndTypeMap.size() == 0 && orgIdMap.size() == 0 && positIdAndOrgIdMap.size() == 0) {
            return new HashMap<>(0);
        }

        // 从缓存中获取所有的人员信息进行匹配
        HashOperations<String, String, String> opsForHash = redisTemplate.opsForHash();
        String usersKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USERS;
        Long size = opsForHash.size(usersKey);
        if (size == 0) {
            return new HashMap<>(0);
        }

        JedisUtils.hScan(redisTemplate, usersKey, 5000, cursor -> {
            Map.Entry<String, String> entry = (Map.Entry<String, String>) cursor.next();
            String value = entry.getValue();
            if (StringUtils.isEmpty(value)) {
                return;
            }

            try {
                UserCache cache = UserCache.decode(value);
                if (cache == null) {
                    return;
                }

                String userId = cache.getId();
                String userType = cache.getType();
                String type = userIdAndTypeMap.get(userId);
                if (EMPTY_VALUE.equals(type)) {
                    userIdAndTypeMap.put(userId, userType);
                    return;
                }

                String orgId = cache.getOrgId();
                if (BooleanUtils.isTrue(orgIdMap.get(orgId))) {
                    userIdAndTypeMap.put(userId, userType);
                    return;
                }

                String positionId = cache.getPositionId();
                Map<String, Boolean> positOrgIdMap = positIdAndOrgIdMap.get(positionId);
                if (positOrgIdMap != null && BooleanUtils.isTrue(positOrgIdMap.get(orgId))) {
                    userIdAndTypeMap.put(userId, userType);
                }
            } catch (Exception e) {
                log.error("parse user cache error", e);
            }
        });

        return userIdAndTypeMap;
    }

    /**
     * 将传入的 commonRel(开放，下发范围) 解析为对应的人员(包含群组的人员)，部门(包含子部门)，岗位
     */
    private void dealCommonRel(List<? extends CommonRel> commonRelList,
                               Map<String, String> userIdAndTypeMap,
                               Map<String, Boolean> orgIdMap,
                               Map<String, Map<String, Boolean>> positIdAndOrgIdMap) {
        Set<String> groupIds = new HashSet<>();
        for (CommonRel commonRel : commonRelList) {
            String relType = commonRel.getRelType();
            String relId = commonRel.getRelId();
            if (UcConstants.RANG_TYPE_USER.equals(relType)) {
                userIdAndTypeMap.put(relId, EMPTY_VALUE);
            } else if (UcConstants.RANG_TYPE_ORG.equals(relType)) {
                orgIdMap.put(relId, true);
            } else if (UcConstants.RANG_TYPE_GROUP.equals(relType)) {
                groupIds.add(relId);
            } else if (UcConstants.RANG_TYPE_POSITION.equals(relType)) {
                Map<String, Boolean> positOrgIdMap = positIdAndOrgIdMap.computeIfAbsent(relId, k -> new HashMap<>());
                positOrgIdMap.put(commonRel.getRelOrgId(), true);
            }
        }

        if (orgIdMap.size() > 0) {
            List<String> childIds = orgService.getChildIds(orgIdMap.keySet(), true);
            childIds.forEach(id -> orgIdMap.put(id, true));
        }

        if (groupIds.size() > 0) {
            Set<String> userIdList = groupMemberService.listUserIdsFromCache(groupIds);
            userIdList.forEach(id -> userIdAndTypeMap.put(id, EMPTY_VALUE));
        }

        if (positIdAndOrgIdMap.size() > 0) {
            for (Map.Entry<String, Map<String, Boolean>> entry : positIdAndOrgIdMap.entrySet()) {
                Map<String, Boolean> positOrgIdMap = entry.getValue();
                List<String> childIds = orgService.getChildIds(positOrgIdMap.keySet(), true);
                childIds.forEach(id -> positOrgIdMap.put(id, true));
                positIdAndOrgIdMap.put(entry.getKey(), positOrgIdMap);
            }
        }
    }

    /**
     * 根据手机号登录，并保存新增的外部人员
     *
     * @param mobile 手机号
     * @param name   姓名
     * @return 登录结果
     */
    public JsonResult<?> mLoginAndSaveOuterUser(String mobile, String name, String corpCode, String openId,
                                                boolean register) {
        if (StringUtils.isEmpty(mobile) || StringUtils.isEmpty(corpCode)) {
            return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
                    UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
        }

        String userLoginKey = UcRedisKeys.UC_ + corpCode + UcRedisKeys.USER_LOGIN;
        HashOperations<String, String, Ul> operations = redisTemplate.opsForHash();
        Ul ul = operations.get(userLoginKey, mobile);
        if (ul == null) {
            if (!register) {
                return new JsonResult<>(false, UcI18nConstants.UC_STATUS_DISABLED.getCode(),
                        UcI18nConstants.UC_STATUS_DISABLED.getName(), null);
            }

            User user = new User();
            user.setMobile(mobile);
            user.setName(name);
            if (StringUtils.isNotBlank(openId)) {
                UserDetail userDetail = new UserDetail();
                userDetail.setWechat(openId);
                user.setUserDetail(userDetail);
            }

            try {
                saveOuterUser(user);
            } catch (Exception e) {
                log.error("save outer user error", e);
                return new JsonResult<>(false, UcI18nConstants.UC_ADD_ERROR.getCode(),
                        UcI18nConstants.UC_ADD_ERROR.getName(), null);
            }

            String userId = user.getId();
            return new JsonResult<>(true, UcI18nConstants.LOGIN_SUCCESS.getName(), userId);
        }

        String status = ul.getStatus();
        if (!UcConstants.STATUS_ENABLED.equals(status)) {
            return new JsonResult<>(false, UcI18nConstants.UC_STATUS_DISABLED.getCode(),
                    UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
        }

        // 更新openId
        if (StringUtils.isNotBlank(openId)) {
            UserDetail userDetail = new UserDetail();
            userDetail.setUserId(ul.getUId());
            userDetail.setWechat(openId);
            userDetail.setCorpCode(corpCode);
            userDetail.setUpdatedBy(ul.getUId());
            userDetail.setUpdatedAt(LocalDateTime.now());
            userDetailService.updateDetailByUserId(userDetail);
        }

        return new JsonResult<>(true, null, ul.getUId());
    }

    /**
     * 用户ID获取用户基本信息【不查缓存】
     *
     * @param userIds        用户Id列表
     * @param includeDetail  是否包含用户详情信息，部门，岗位名称信息
     * @param includeOrgName 是否包含部门，岗位名称信息
     * @return key:用户主键 value:用户对象
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Map<String, User> getUserMap(Collection<String> userIds, boolean includeDetail, boolean includeOrgName) {
        if (CollectionUtils.isEmpty(userIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userIds not be empty!");
        }

        List<String> ids = new ArrayList<>(userIds);
        List<User> users = listByIds(ids, ID, NAME, CODE, LOGIN_NAME, EMAIL, MOBILE, ID_CARD,
                FACE_ID, STATUS, ORG_ID, POSITION_ID, LEADER_ID, ENTRY_AT, LEVEL, AGE, TYPE);
        if (CollectionUtils.isEmpty(users)) {
            return new HashMap<>();
        }

        if (includeOrgName) {
            fillOrgAndPositName(users);
        }

        /*if (!includeDetail) {
            return users.stream().collect(Collectors.toMap(User::getId, user -> user, (a, b) -> b,
                    () -> new HashMap<>(users.size())));
        }*/

        Map<String, UserDetail> userIdAndDetailMap = userDetailService.getUserIdAndDetailMap(ids);
        Map<String, User> userMap = new HashMap<>(users.size());
        for (User user : users) {
            String id = user.getId();
            UserDetail detail = userIdAndDetailMap.get(id);
            if (detail == null) {
                continue;
            }

            if (includeDetail) {
                user.setUserDetail(detail);
            }

            user.setWechat(detail.getWechat());
            userMap.put(id, user);
        }

        return userMap;
    }

    public User getUserByOpenId(String openId, String corpCode) {
        if (StringUtils.isEmpty(openId)) {
            return null;
        }
        String userId = userDetailService.getUserIdByOpenId(openId, corpCode);
        if (StringUtils.isBlank(userId)) {
            return null;
        }
        return get(userId);
    }

    /**
     * 获取当前公司用户总数（TOTAL）和已使用人数(USED)
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, Integer> getUserCountMap() {
        String usersKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USERS;
        HashOperations<String, String, String> opsForHash = redisTemplate.opsForHash();
        Long usedCount = opsForHash.size(usersKey);
        Map<String, Integer> userCountMap = new HashMap<>(2);
        userCountMap.put("USED", usedCount.intValue());
        int userTotal = getUserTotal();
        userCountMap.put("TOTAL", userTotal);
        return userCountMap;
    }

    private int getUserTotal() {
        Example example = new Example(User.class);
        example.createCriteria()
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        return userMapper.selectCountByExample(example);
    }

    /**
     * 判断admin账号是否已经存在
     *
     * @param rootOrgId 公司跟部门Id
     * @return true：已存在，false：不存在
     */
    public boolean hasAdminAccount(String rootOrgId) {
        if (StringUtils.isEmpty(rootOrgId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "rootOrgId not be empty!");
        }

        Org rootOrg = orgService.getRootOrg();
        if (rootOrg == null || !rootOrgId.equals(rootOrg.getId())) {
            throw new UcException(UcErrorCode.SYSTEM_ERROR);
        }

        Example example = new Example(User.class);
        example.createCriteria()
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(User.LOGIN_NAME, "admin")
                .andEqualTo(User.CODE, "admin")
                .andEqualTo(ORG_ID, rootOrgId);
        int count = userMapper.selectCountByExample(example);
        return count > 0;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Set<String> listAllUserId() {
        Example example = new Example(User.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(STATUS, UcConstants.STATUS_ENABLED);
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        example.selectProperties(ID);
        List<User> users = userMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(users)) {
            return new HashSet<>();
        }

        return users.stream().map(User::getId).collect(Collectors.toSet());
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public User getUserByField(String filedName, String fieldValue) {
        User user = getByProperty(filedName, fieldValue);
        if (user == null) {
            return null;
        }

        List<String> userIds = Collections.singletonList(user.getId());
        putUserToRedis(userIds);
        return user;
    }

    /**
     * 根据部门Id，获取部门(包含子部门)下的所有人员Id列表
     *
     * @param orgIds 部门Id
     * @return 人员Id列表
     */
    public List<String> findUserIdsByOrgIds(Collection<String> orgIds) {
        if (CollectionUtils.isEmpty(orgIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM);
        }

        List<String> childIds = orgService.getChildIds(orgIds, true);
        Example example = new Example(User.class);
        example.selectProperties(ID);
        example.createCriteria().andEqualTo(STATUS, UcConstants.STATUS_ENABLED)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andIn(ORG_ID, childIds);

        List<User> users = userMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(users)) {
            return Collections.emptyList();
        }

        return users.stream().map(User::getId).collect(Collectors.toList());
    }

    public List<String> listUserIdInKeywords(Set<String> keywords) {
        List<User> users = userMapper.selectByExample(Example.builder(User.class)
                .select(User.ID, User.NAME)
                .where(WeekendSqls.<User>custom().andIn(User::getName, keywords))
                .build());
        if (CollectionUtils.isEmpty(users)) {
            return Collections.emptyList();
        }

        Set<String> check = new HashSet<>();
        return users.stream().filter(user -> check.add(user.getName())).map(User::getId).collect(Collectors.toList());
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void initAdmin(String orgId) {
        if (hasAdminAccount(orgId)) {
            putUserToRedis(null, ContextHandler.getCorpCode());
            return;
        }

        String userId = IDUtils.getUUID19();
        ContextHandler.setUserId(userId);
        User user = new User();
        user.setId(userId);
        user.setCode("admin");
        user.setOrgId(orgId);
        user.setLoginName("admin");
        user.setName("系统管理员");
        LocalDateTime now = LocalDateTime.now();
        user.setCreatedAt(now);
        user.setCreatedBy(userId);
        user.setUpdatedAt(now);
        user.setUpdatedBy(userId);
        saveUser(user);
        putUserToRedis(null, ContextHandler.getCorpCode());

    }

    /**
     * 根据手机号发送验证码(找回密码时)
     *
     * @param mobile
     */
    /*public void getVerificationCode(String mobile, String corpCode) {
        if (StringUtils.isBlank(mobile)) {
            throw new BaseException(UcI18nConstants.UC_MOBILE_EMPTY.getCode(), "手机号不可为空");
        }

        Example example = new Example(User.class);
        example.selectProperties().createCriteria()
                .andEqualTo(MOBILE, mobile)
                .andEqualTo(CORP_CODE, corpCode);
        ContextHandler.setCorpCode(corpCode);
        int count = userMapper.selectCountByExample(example);
        if (count == 0) {
            throw new BaseException(UcI18nConstants.FORGET_PASSWORD_ERROR.getCode(), "手机号不存在");
        }

        SendSmsResponse response = aliSmsService.sendCaptcha(resetPwd, new JSONObject(), mobile);
        if (!"OK".equals(response.getCode())) {
            log.error("sendSmsCode error: {}({}), {}", response.getCode(), response.getMessage(), JSONObject.toJSONString(response));
            throw new BaseException(UcI18nConstants.FORGET_PASSWORD_ERROR.getCode(), "验证码发送失败");
        }

    }*/

    /**
     * 验证手机号验证码
     *
     * @param mobile     手机号
     * @param verifyCode 验证码
     */
    public void checkVerificationCode(String mobile, String verifyCode) {

        if (StringUtils.isBlank(mobile)) {
            throw new BaseException(UcI18nConstants.FORGET_PASSWORD_ERROR.getCode(), "手机号不可为空");
        }

        if (StringUtils.isBlank(verifyCode)) {
            throw new BaseException(UcI18nConstants.FORGET_PASSWORD_ERROR.getCode(), "验证码不可为空");
        }

        String key = String.format(KEY_TEMP, resetPwd, mobile);
        ValueOperations<String, String> opsForValue = redisTemplate.opsForValue();
        String value = opsForValue.get(key);
        if (StringUtils.isEmpty(value) || !verifyCode.equals(value)) {
            throw new BaseException(UcI18nConstants.FORGET_PASSWORD_ERROR.getCode(), "验证码不正确");
        }
    }

    /**
     * 忘记密码时重置密码
     *
     * @param mobile        手机号
     * @param newPassword   新密码
     * @param againPassword 确认密码
     */
    public void resetPwd(String mobile, String newPassword, String againPassword, String corpCode) {
        CheckFlow.start().isNotEmpty(newPassword).isNotEmpty(againPassword);
        if (!newPassword.equals(againPassword)) {
            throw new UcException(UcErrorCode.PASSWORD_NOT_EQUAL);
        }

        JsonResult<Boolean> result = csFeignClient.validatePassword(newPassword);
        if (result == null || !result.isSuccess() || !result.getData()) {
            String msg = result != null ? result.getMsg() : null;
            throw new UcException(UcErrorCode.INVALID_PASSWORD, msg);
        }
        User newUser = new User();
        newUser.setPwd(Md5Utils.getMD5(newPassword.getBytes()));
        Example example = new Example(User.class);
        example.createCriteria().andEqualTo(MOBILE, mobile).andEqualTo(CORP_CODE, corpCode);
        userMapper.updateByExampleSelective(newUser, example);
        //刷新redis
        List<User> users = userMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(users)) {
            String id = users.get(0).getId();
            putUserToRedis(Collections.singletonList(id));
        }
    }

    /**
     * 通过code获取用户信息
     * @param code
     * @return
     */
    public User getUserByCode(String code) {
        Example example = new Example(User.class);
        example.createCriteria().andEqualTo(User.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(CODE, code);
        List<User> userList = userMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(userList)) {
            return null;
        }
        return userList.get(0);
    }

    /**
     * 根据条件，获取对象集合
     *
     * @param user       条件
     * @param properties 返回字段
     * @return 对象集合
     */
    @Transactional(readOnly = true)
    public List<User> listByCondition(User user, String... properties) {
        CheckFlow.start(UcErrorCode.EMPTY_PARAM).isNotNull(user);
        Example example = genConditionExample(user);
        example.selectProperties(properties);
        return userMapper.selectByExample(example);
    }

    private Example genConditionExample(User user) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        String corpCode = user.getCorpCode();
        if (StringUtils.isNotEmpty(corpCode)) {
            criteria.andEqualTo(CORP_CODE, corpCode);
        }

        String supplierId = user.getSupplierId();
        if (StringUtils.isNotEmpty(supplierId)) {
            criteria.andEqualTo(SUPPLIER_ID, supplierId);
        }

        String dataType = user.getDataType();
        if (StringUtils.isNotEmpty(dataType)) {
            criteria.andEqualTo(DATA_TYPE, dataType);
        }

        Collection<String> userIds = user.getUserIds();
        if (CollectionUtils.isNotEmpty(userIds)) {
            criteria.andIn(ID, userIds);
        }

        return example;
    }

    /**
     * 根据条件，获取对象
     *
     * @param user       条件
     * @param properties 返回字段
     * @return 对象
     */
    @Transactional(readOnly = true)
    public User getByCondition(User user, String... properties) {
        List<User> list = listByCondition(user, properties);
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }

        return list.get(0);
    }

    /**
     * 供应链用户分页
     *
     * @param user 条件
     * @param page 分页对象
     * @return 分页列表
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public Page<User> supplyChainPage(User user, Page<User> page) {
        UcUtil.validatePage(page);
        if (user == null) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "user not be null!");
        }
        if (StringUtils.equals(UcConstants.USER_DATA_TYPE_SUPPLIER, user.getDataType())){
            //用户数据类型传递了供应商，则指定supplier
            user.setDataType("");
            user.setDataTypeList(Lists.newArrayList(UcConstants.USER_DATA_TYPE_SUPPLIER, UcConstants.BRANCH_SUPPLIER));
        }
        Example example = new Example(User.class);
        example.selectProperties(User.ID, DATA_TYPE, NAME, CODE, LOGIN_NAME, MOBILE, COMPANY_ID, COMPANY_NAME, POSITION, STATUS, INIT_PASSWORD, UPDATED_AT);
        setUserConditions(user, example, null);
        String order = user.getOrder();
        if (StringUtils.isEmpty(order)) {
            order = "updatedAt desc";
        }

        page = search(example, page, order, User.ID);
        return page;
    }

    public Boolean checkMobileForSupplier(String mobile, String id) {
        if (StringUtils.isNotEmpty(mobile)) {
            Example example = new Example(User.class);
            Example.Criteria criteria = example.createCriteria();
                criteria.andEqualTo(User.CORP_CODE, ContextHandler.getCorpCode())
                    .andEqualTo(MOBILE, mobile);
            if (StringUtils.isNotEmpty(id)) {
                Example.Criteria criteria1 = example.createCriteria();
                criteria1.andNotEqualTo(SUPPLIER_ID, id);
                criteria1.orIsNull(SUPPLIER_ID);
                example.and(criteria1);
            }
            List<User> userList = userMapper.selectByExample(example);
            return CollectionUtils.isEmpty(userList);
        }
        return true;
    }

    public List<User> listByCompanyId(String companyId, String keywords) {
        if (StringUtils.isNotEmpty(companyId)) {
            Example example = new Example(User.class);
            Example.Criteria criteria = example.createCriteria();
            criteria.andEqualTo(User.CORP_CODE, ContextHandler.getCorpCode())
                    .andEqualTo(COMPANY_ID, companyId);

            if (StringUtils.isNotEmpty(keywords)) {
                Example.Criteria criteria1 = example.createCriteria();
                criteria1.andLike(CODE, SqlUtil.asLike(keywords))
                        .orLike(NAME, SqlUtil.asLike(keywords))
                        .orLike(LOGIN_NAME, SqlUtil.asLike(keywords));
                example.and(criteria1);
            }

            return userMapper.selectByExample(example);
        }
        return Collections.emptyList();
    }


    /**
     * 校验登录接口
     *
     * @param loginInfo
     * @param httpServletRequest
     * @return
     */
    public JsonResult<?> validateLogin(Map<String, String> loginInfo, HttpServletRequest httpServletRequest) {
        return validSecurityCode(loginInfo, () -> {
            String corpCode = loginInfo.get(ContextConstant.CONTEXT_KEY_CORP_CODE);
            if (StringUtils.isBlank(corpCode)) {
                corpCode = UcConstants.CORP_CODE_DEFAULT;
            }

            ContextHandler.setCorpCode(corpCode);
            String userId;
            JsonResult<?> loginResult = getLoginResult(loginInfo, corpCode);
            if (loginResult.isSuccess()) {
                userId = (String) loginResult.getData();
            } else {
                return loginResult;
            }
            String dataType = loginInfo.get("dataType");
            UserCache userCache = getUserCache(userId);
            log.info("userCache:{}", userCache);
            if (userCache == null) {
                log.info("userCache为空");
                // 缓存用户不存在
                return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
                        UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
            }else {
                if (StringUtils.equals(dataType, "SUPPLIER")){
                    if (!StringUtils.equals(userCache.getDataType(), "SUPPLIER") && !StringUtils.equals(userCache.getDataType(), "BRANCH_SUPPLIER")){
                        return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
                                UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
                    }
                }else {
                    //datatype不一致， 则抛出登录失败异常
                    if (!StringUtils.equalsIgnoreCase(dataType, userCache.getDataType())){
                        return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_PWD_ERROR.getCode(),
                                UcI18nConstants.UC_LOGIN_PWD_ERROR.getName(), null);
                    }
                }

            }

            String loginName = userCache.getLoginName();
            boolean isSuperAdmin = isAdmin(loginName, userCache.getId());
            ContextHandler.setSuperAdmin(isSuperAdmin);
            /*JsonResult<?> corpCheckResult = checkCorpSetting(loginName);
            if (!corpCheckResult.isSuccess()) {
                return corpCheckResult;
            }*/

            Map<String, Object> data = new HashMap<>();
            data.put(ContextConstant.CONTEXT_KEY_USER_ID, userId);
            data.put(ContextConstant.CONTEXT_KEY_USERNAME, loginName);
            data.put(ContextConstant.CONTEXT_KEY_NAME, userCache.getName());
            data.put(ContextConstant.CONTEXT_KEY_CORP_CODE, ContextHandler.getCorpCode());
            CusAccessObjectUtil.logRequest(httpServletRequest, null);
            data.put(ContextConstant.CONTEXT_KEY_SUPER_ADMIN, isSuperAdmin);
            /*Corp corp = saasCorpService.getCorpByCode(corpCode);
            if (corp != null) {
                data.put("corpName", corp.getName());
            }*/
            data.put("mobile",userCache.getMobile());
            if (!isSuperAdmin) {
                CommonUtils.threadPoolExecutor(context -> setAuthInfoToCache(userId));
            }

            String supplierId = userCache.getSupplierId();
            com.purchase.uc.model.Supplier supplier = null;
            if (StringUtils.isNotBlank(supplierId)) {
                supplier = supplierService.get(supplierId);
            }

            if (null != supplier) {
                data.put("supplierId", supplier.getId());
                data.put("supplierCode", supplier.getCode());
                data.put("supplierDataType", supplier.getDataType());
                data.put("supplierType", supplier.getType());
//                data.put("category", supplier.getCategory());
            } else {
                data.put("supplierId", "");
                data.put("supplierCode", "");
            }

            String companyId = userCache.getCompanyId();
            Company company = null;
            if (StringUtils.isNotEmpty(companyId)) {
                company = companyService.getByProperty(Company.COM_BM, companyId);
            }

            if (null != company) {
                data.put("companyId", company.getId());
                data.put("comBm", company.getComBm());
                data.put("companyName", company.getComName());
                data.put("companyShortName", company.getShortName());
            } else {
                data.put("companyId", "");
                data.put("comBm", "");
                data.put("companyName", "");
                data.put("companyShortName", "");
            }

            Optional.ofNullable(loginInfo.get(UcConstants.DEFAULT_CODE_KEY)).ifPresent(redisTemplate::delete);
            return new JsonResult<>(true, "登录成功", data);
        });
    }

    /**
     * 所拥有的管辖范围和菜单数据权限缓存
     * Auth 模块中 与session同步刷新失效时间，所以没有维护缓存刷新功能
     */
    private void setAuthInfoToCache(String userId) {
        userRangeService.setUserRangeInfoToCache(userId);
        roleAuthRelService.setAuthDataPermissionInfoToCache(userId);
    }

    //从controller搬到这
    private JsonResult<?> getLoginResult(Map<String, String> loginInfo, String corpCode) {
        String loginName = loginInfo.get(ContextConstant.CONTEXT_KEY_USERNAME);
        String loginType = loginInfo.get(UcConstants.CONTEXT_KEY_LOGIN_TYPE);
        String openId = loginInfo.get(UcConstants.CONTEXT_KEY_OPENID);
        if (StringUtils.isNotBlank(openId) && UcConstants.LOGIN_TYPE_WECHAT.equals(loginType)) {
            User user = getUserByOpenId(openId, corpCode);
            if (null == user) {
                return new JsonResult<>(false, UcI18nConstants.LOGIN_ERROR_USER_NOT_EXIST.getCode(),
                        UcI18nConstants.LOGIN_ERROR_USER_NOT_EXIST.getName(), null);
            }

            String status = user.getStatus();
            if (!UcConstants.STATUS_ENABLED.equals(status)) {
                return new JsonResult<>(false, UcI18nConstants.UC_STATUS_DISABLED.getCode(),
                        UcI18nConstants.UC_STATUS_DISABLED.getName(), null);
            }

            return new JsonResult<>(true, UcI18nConstants.LOGIN_SUCCESS.getName(), user.getId());
        }

        boolean register = UcConstants.LOGIN_TYPE_MOBILE_REGISTER.equals(loginType);
        if (UcConstants.LOGIN_TYPE_MOBILE.equals(loginType) || register) {
            String name = loginInfo.get(ContextConstant.CONTEXT_KEY_NAME);
            String mobile = loginInfo.get(UcConstants.CONTEXT_KEY_MOBILE);
            String code = loginInfo.get(UcConstants.CONTEXT_KEY_CODE);
            if (StringUtils.isEmpty(code) || StringUtils.isEmpty(mobile)) {
                return new JsonResult<>(false, UcI18nConstants.LOGIN_CODE_ERROR.getCode(),
                        UcI18nConstants.LOGIN_CODE_ERROR.getName(), null);
            }

            String codeKey = UcRedisKeys.VERIFY_CODE_PREFIX + corpCode + "_" + mobile;
            ValueOperations<String, String> operations = redisTemplate.opsForValue();
            String value = operations.get(codeKey);
            if (StringUtils.isEmpty(value)) {
                return new JsonResult<>(false, UcI18nConstants.LOGIN_CODE_ERROR.getCode(),
                        UcErrorCode.VERIFICATION_CODE_INVALID.getText(), null);
            }

            if (!value.equals(code)) {
                return new JsonResult<>(false, UcI18nConstants.LOGIN_CODE_ERROR.getCode(),
                        UcI18nConstants.LOGIN_CODE_ERROR.getName(), null);
            }

            return mLoginAndSaveOuterUser(mobile, name, corpCode, openId, register);
        } else {
            String password = loginInfo.get(UcConstants.CONTEXT_KEY_PASSWORD);
            return login(loginName, password, corpCode, openId);
        }
    }

    //从controller搬到这
    private boolean isAdmin(String loginName, String userId) {
        return ("admin".equals(loginName) || userRoleRelService.hasSuperAdminRole(userId));
    }


    /**
     * 企业微信扫码登录
     *
     * @param dto
     * @param httpServletRequest 请求对象
     * @return 登录结果
     */
    public JsonResult<?> wxScanLogin(ScanLoginDTO dto,
                                     HttpServletRequest httpServletRequest,
                                     HttpServletResponse response) {
        String corpCode = dto.getCorpCode();
        if (StringUtils.isBlank(corpCode)) {
            corpCode = UcConstants.CORP_CODE_DEFAULT;
        }
        ContextHandler.setCorpCode(corpCode);

        // 调用企业微信接口获取用户信息
        WxClusterResultInfo<ScanLoginVO> result = null;
        try {
            result = wxClusterFeign.oauth2AccessInfo(dto.getBm(), dto.getAccessToken());
        } catch (Exception e) {
            log.error("企业微信扫码登录失败，获取用户信息失败：{}", result);
            return new JsonResult<>(false, "企业微信授权失败", result);
        }
        if (result == null || !result.isSuccess() || result.getData() == null) {
            log.error("企业微信扫码登录失败，获取用户信息失败：{}", result);
            return new JsonResult<>(false, "企业微信授权失败", result);
        }

        ScanLoginVO scanLoginVO = result.getData();
        String userId = scanLoginVO.getUserId();
        if (StringUtils.isBlank(userId)) {
            log.error("企业微信扫码登录失败，用户 ID 为空");
            return new JsonResult<>(false, "获取用户信息失败", null);
        }

        // 根据企业微信用户 ID 查找系统用户
        User user = userMapper.searchAllByLoginName(userId, corpCode);
        if (user == null) {
            log.error("企业微信扫码登录失败，用户不存在：userId={}", userId);
            throw new UcException(UcErrorCode.DATA_EMPTY, "用户工号不存在!");
        }

        // 检查用户状态
        String status = user.getStatus();
        if (!UcConstants.STATUS_ENABLED.equals(status)) {
            return new JsonResult<>(false, UcI18nConstants.UC_STATUS_DISABLED.getCode(),
                    UcI18nConstants.UC_STATUS_DISABLED.getName(), null);
        }

        User user1 = getUserByField(LOGIN_NAME, user.getLoginName());
        if (user1 == null) {
            return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_WX_SCAN_ERROR.getCode(),
                    UcI18nConstants.UC_LOGIN_WX_SCAN_ERROR.getName(), null);
        }

        String systemUserId = user.getId();
        UserCache userCache = getUserCache(systemUserId);
        if (userCache == null) {
            log.info("用户缓存不存在：userId={}", systemUserId);
            return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_WX_SCAN_ERROR.getCode(),
                    UcI18nConstants.UC_LOGIN_WX_SCAN_ERROR.getName(), null);
        } else {
            if (StringUtils.equals(dto.getDataType(), "SUPPLIER")) {
                if (!StringUtils.equals(userCache.getDataType(), "SUPPLIER")
                        && !StringUtils.equals(userCache.getDataType(), "BRANCH_SUPPLIER")) {
                    return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_WX_SCAN_ERROR.getCode(),
                            UcI18nConstants.UC_LOGIN_WX_SCAN_ERROR.getName(), null);
                }
            } else {
                //datatype不一致， 则抛出登录失败异常
                if (!StringUtils.equalsIgnoreCase(dto.getDataType(), userCache.getDataType())) {
                    return new JsonResult<>(false, UcI18nConstants.UC_LOGIN_WX_SCAN_ERROR.getCode(),
                            UcI18nConstants.UC_LOGIN_WX_SCAN_ERROR.getName(), null);
                }
            }
        }

        String loginName = userCache.getLoginName();
        boolean isSuperAdmin = isAdmin(loginName, systemUserId);
        ContextHandler.setSuperAdmin(isSuperAdmin);

        Map<String, Object> data = new HashMap<>();
        data.put(ContextConstant.CONTEXT_KEY_USER_ID, systemUserId);
        data.put(ContextConstant.CONTEXT_KEY_USERNAME, loginName);
        data.put(ContextConstant.CONTEXT_KEY_NAME, userCache.getName());
        data.put(ContextConstant.CONTEXT_KEY_CORP_CODE, ContextHandler.getCorpCode());
        CusAccessObjectUtil.logRequest(httpServletRequest, null);
        data.put(ContextConstant.CONTEXT_KEY_SUPER_ADMIN, isSuperAdmin);
        data.put("mobile", userCache.getMobile());
        data.put("loginType", "WECHAT_SCAN");
        data.put("wechatUserId", userId);

        if (!isSuperAdmin) {
            CommonUtils.threadPoolExecutor(context -> setAuthInfoToCache(systemUserId));
        }

        // 处理供应商信息
        String supplierId = userCache.getSupplierId();
        com.purchase.uc.model.Supplier supplier = null;
        if (StringUtils.isNotBlank(supplierId)) {
            supplier = supplierService.get(supplierId);
        }

        if (null != supplier) {
            data.put("supplierId", supplier.getId());
            data.put("supplierCode", supplier.getCode());
            data.put("supplierDataType", supplier.getDataType());
            data.put("supplierType", supplier.getType());
        } else {
            data.put("supplierId", "");
            data.put("supplierCode", "");
        }

        // 处理公司信息
        String companyId = userCache.getCompanyId();
        Company company = null;
        if (StringUtils.isNotEmpty(companyId)) {
            company = companyService.getByProperty(Company.COM_BM, companyId);
        }

        if (null != company) {
            data.put("companyId", company.getId());
            data.put("comBm", company.getComBm());
            data.put("companyName", company.getComName());
            data.put("companyShortName", company.getShortName());
        } else {
            data.put("companyId", "");
            data.put("comBm", "");
            data.put("companyName", "");
            data.put("companyShortName", "");
        }

//        log.info("企业微信扫码登录成功：userId={}, loginName={}", systemUserId, loginName);
        Optional.ofNullable(dto.getKey()).ifPresent(redisTemplate::delete);
        JsonResult jsonResult = generateSession(data, false, response);
        return jsonResult;
    }


}
