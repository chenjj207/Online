package com.purchase.uc.model.vo;

import com.purchase.uc.model.Auth;
import com.qgutech.qgyun.framework.database.mybatis.model.TreeNode;
import lombok.Data;
import lombok.ToString;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.BeanUtils;

import java.util.List;

/**
 * 权限树节点
 *
 * @since TangFD 2020-04-13
 */
@Data
@ToString
public class AuthTreeNode extends TreeNode {

    /**
     * 权限URL
     */
    private String url;

    /**
     * 应用编号
     */
    private String appCode;

    /**
     * routeUrl
     */
    private String routeUrl;

    /**
     * 打开方式（默认：default, 新窗口：window）
     */
    private String openWay;

    /**
     * 图标
     */
    private String icon;

    /**
     * 链接类型(inner:内部，outer:外部)
     */
    private String linkType;

    /**
     * 是否为菜单
     */
    private Boolean menu;

    /**
     * 是否隐藏
     */
    private Boolean hide;

    /**
     * 是否隐藏
     */
    private Boolean sys;

    List<AuthTreeNode> buttonList;

    private List<AuthTreeNode> childList;

    public AuthTreeNode(String id, String pId, String name, String code, boolean manage) {
        this(id, pId, name, code, null, manage);
    }

    public AuthTreeNode(String id, String pId, String name, String code) {
        this(id, pId, name, code, null, false);
    }

    public AuthTreeNode(String id, String pId, String name) {
        this(id, pId, name, null, null, false);
    }

    public AuthTreeNode(String id, String pId, String name, String code, String con) {
        this(id, pId, name, code, con, false);
    }

    public AuthTreeNode(String id, String pId, String name, String code, String con, boolean manage) {
        super(id, pId, name, code, con, manage);
    }

    public AuthTreeNode(Auth auth) {
        BeanUtils.copyProperties(auth, this);
        setCon(auth.getUrl());
        setSys(auth.getSys());
        setManage(BooleanUtils.isTrue(auth.getManage()));
    }

    public AuthTreeNode() {
    }
}
