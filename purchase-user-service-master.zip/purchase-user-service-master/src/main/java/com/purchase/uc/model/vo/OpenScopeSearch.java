package com.purchase.uc.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 开放范围分页查询条件
 */
@Getter
@Setter
@ToString
@ApiModel(value = "OpenScopeSearch", description = "开放范围查询条件")
public class OpenScopeSearch {

    /**
     * scopeType
     */
    @ApiModelProperty(value = "开放范围类型：USER|ORG")
    private String scopeType;

    /**
     * 人员工号/姓名/用户名/手机/组织名称
     */
    @ApiModelProperty(value = "人员工号/姓名/用户名/手机/组织名称,scopeType为ORG时：ALL ORG POSITION GROUP")
    private String keywords;

    /**
     * scopeType为USER时：orgId
     * scopeType为ORG时：ALL ORG POSITION GROUP
     */
    @ApiModelProperty(value = "开放范围具体值")
    private String value;

    /**
     * 当前页
     */
    @ApiModelProperty(value = "当前页")
    private Integer pageNum;

    /**
     * 分页大小
     */
    @ApiModelProperty(value = "分页大小")
    private Integer pageSize;
}
