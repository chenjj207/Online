package com.purchase.uc.model.dto;

import lombok.Data;


@Data
public class CorpCodeDTO {

    private String corpCode;

}
