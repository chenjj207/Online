package com.purchase.uc.model.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * 人员信息修改导入模板
 *
 * @since TangFD@HF 2019-05-14
 */
@Data
public class UpdateImportExcelUser extends ExcelUser {

    @NotNull
    @ExcelProperty(value = "工号", index = 0)
    private String code;

    @ExcelProperty(value = "姓名", index = 1)
    private String name;

    @ExcelProperty(value = "用户名", index = 2)
    private String loginName;

    @ExcelProperty(value = "部门编号", index = 3)
    private String orgCode;

    @ExcelProperty(value = "部门名称", index = 4)
    private String orgNamePath;

    @ExcelProperty(value = "岗位类别", index = 5)
    private String positionCategory;

    @ExcelProperty(value = "岗位编号", index = 6)
    private String positionCode;

    @ExcelProperty(value = "岗位名称", index = 7)
    private String positionName;

    @ExcelProperty(value = "隶属上级工号", index = 8)
    private String leaderCode;

    @ExcelProperty(value = "隶属上级姓名", index = 9)
    private String leaderName;

    @ExcelProperty(value = "邮箱", index = 10)
    private String email;

    @ExcelProperty(value = "手机", index = 11)
    private String mobile;

    @ExcelProperty(value = "性别", index = 12)
    private String sex;

    @ExcelProperty(value = "身份证号", index = 13)
    private String idCard;

    @ExcelProperty(value = "状态", index = 14)
    private String status;

    @ExcelProperty(value = "登录密码", index = 15)
    private String pwd;

    @ExcelProperty(value = "扩展字段1", index = 16)
    private String ext1;

    @ExcelProperty(value = "扩展字段2", index = 17)
    private String ext2;

    @ExcelProperty(value = "扩展字段3", index = 18)
    private String ext3;

    private String positionId;
    private String orgId;
    private String leaderId;
    private String id;

}
