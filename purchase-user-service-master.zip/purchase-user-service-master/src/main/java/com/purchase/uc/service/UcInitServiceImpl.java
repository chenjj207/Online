package com.purchase.uc.service;

import com.qgutech.qgyun.dev.common.service.CommonInitService;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.saas.client.model.Corp;
import com.qgutech.qgyun.saas.client.service.SaasCorpService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Map;

/**
 * @author TangFD 2021/1/7
 */
@Service
public class UcInitServiceImpl implements CommonInitService {
    @Resource
    private OrgService orgService;
    @Resource
    private UserService userService;
    @Resource
    private AuthService authService;
    @Resource
    private RoleService roleService;
    @Resource
    private CategoryService categoryService;
    @Resource
    private SaasCorpService saasCorpService;

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void init(Map<String, String> params) {
        Corp corp = saasCorpService.getCorpByCode(ContextHandler.getCorpCode());
        ContextHandler.setUserId("systemAdmin");
        String orgId = orgService.init(corp.getName());
        categoryService.init();
        userService.initAdmin(orgId);
        roleService.initRole();
        authService.initAuth();
    }
}
