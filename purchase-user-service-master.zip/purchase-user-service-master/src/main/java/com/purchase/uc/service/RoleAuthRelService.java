package com.purchase.uc.service;

import com.qgutech.qgyun.dev.common.utils.CommonUtils;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcException;
import com.purchase.uc.mapper.RoleAuthRelMapper;
import com.purchase.uc.model.Auth;
import com.purchase.uc.model.RoleAuthRel;
import com.purchase.uc.utils.UcRedisKeys;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.model.BaseCorpTreeModel;
import com.qgutech.qgyun.framework.database.model.BaseModel;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Sqls;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * 角色权限关联接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
@RefreshScope
public class RoleAuthRelService extends BaseServiceImpl<RoleAuthRel> {

    @Resource
    private RoleAuthRelMapper roleAuthRelMapper;
    @Resource
    private UserRoleRelService userRoleRelService;
    @Resource
    private RedisTemplate redisTemplate;
    @Resource
    private AuthService authService;
    @Value("${qgyun.auth.redis.expiration-time:3600}")
    private Integer authExpireTime;

    public List<RoleAuthRel> listAll() {
        return roleAuthRelMapper.selectAll();
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void save(RoleAuthRel roleAuthRel) {
        if (roleAuthRel == null || StringUtils.isEmpty(roleAuthRel.getRoleId())
                || CollectionUtils.isEmpty(roleAuthRel.getAuthRelList())) {
            throw new IllegalArgumentException("RoleAuthRel or roleId or authIds is empty!");
        }

        String roleId = roleAuthRel.getRoleId();
        deleteByRoleId(roleId);
        List<RoleAuthRel> authRelList = roleAuthRel.getAuthRelList();
        if (CollectionUtils.isEmpty(authRelList)) {
            return;
        }

        List<String> authIds = new ArrayList<>(authRelList.size());
        for (Iterator<RoleAuthRel> iterator = authRelList.iterator(); iterator.hasNext(); ) {
            RoleAuthRel authRel = iterator.next();
            String authId = authRel.getAuthId();
            if (StringUtils.isEmpty(authId)) {
                iterator.remove();
                continue;
            }

            authIds.add(authId);
            authRel.setRoleId(roleId);
        }

        setAuthCode(authRelList, authIds);
        batchInsert(authRelList);
        addRoleAuthCache(roleId, authIds);
    }

    private void setAuthCode(List<RoleAuthRel> authRelList, List<String> authIds) {
        List<Auth> auths = authService.listByIds(authIds, Auth.ID, Auth.CODE);
        if (CollectionUtils.isEmpty(auths)) {
            return;
        }

        Map<String, String> authIdAndCodeMap = auths.stream()
                .filter(auth -> StringUtils.isNotEmpty(auth.getCode()))
                .collect(Collectors.toMap(BaseModel::getId, BaseCorpTreeModel::getCode,
                        (a1, b) -> b, () -> new HashMap<>(auths.size())));
        authRelList.forEach(authRel -> authRel.setAuthCode(authIdAndCodeMap.get(authRel.getAuthId())));
    }

    /**
     * 添加角色与权限的缓存信息
     *
     * @param roleId  有权限的角色Id
     * @param authIds 待添加的权限Id列表
     */
    private void addRoleAuthCache(String roleId, List<String> authIds) {
        addRoleAuthCache(CommonUtils.singletonMap(roleId, authIds));
    }

    private void addRoleAuthCache(Map<String, List<String>> roleIdAndAuthIdsMap) {
        CommonUtils.threadPoolExecutor(o -> {
            delRoleAuthCache(roleIdAndAuthIdsMap.keySet());
            String roleAuthKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.ROLE_AUTH;
            HashOperations<String, String, List<String>> operations = redisTemplate.opsForHash();
            operations.putAll(roleAuthKey, roleIdAndAuthIdsMap);
        });
    }

    private int deleteByRoleId(String roleId) {
        Example example = new Example(RoleAuthRel.class);
        example.createCriteria().andEqualTo(RoleAuthRel.ROLE_ID, roleId)
                .andEqualTo(RoleAuthRel.CORP_CODE, ContextHandler.getCorpCode());

        return roleAuthRelMapper.deleteByExample(example);
    }

    /**
     * 根据用户Id 获取所拥有的权限Id列表
     *
     * @param userId 用户Id
     * @param manage 是否是管理员权限 true:管理员权限，false:学员权限，null:所有权限
     * @return 权限Id列表
     */
    public Set<String> geAuthIdsByUserId(String userId, Boolean manage) {
        if (manage == null) {
            Set<String> authIds = getAllAuthIdsFromCache(userId);
            if (CollectionUtils.isNotEmpty(authIds)) {
                return authIds;
            }
        }

        List<String> roleIds = userRoleRelService.getRoleIdsByUserId(userId, manage);
        if (CollectionUtils.isEmpty(roleIds)) {
            return new HashSet<>(0);
        }

        return getAuthIds(roleIds);
    }

    private Set<String> getAllAuthIdsFromCache(String userId) {
        List<String> roleIds = userRoleRelService.getRoleIdsByUserId(userId, null);
        if (CollectionUtils.isEmpty(roleIds)) {
            return new HashSet<>(0);
        }

        return getAuthIdsFromCacheByRoleIds(roleIds);
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Set<String> getAuthIds(Collection<String> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "roleIds not be empty!");
        }

        Set<String> authIds = getAuthIdsFromCacheByRoleIds(roleIds);
        if (CollectionUtils.isNotEmpty(authIds)) {
            return authIds;
        }

        //todo add lock 防止缓存击穿
        Example example = new Example(RoleAuthRel.class);
        example.selectProperties(RoleAuthRel.ROLE_ID, RoleAuthRel.AUTH_ID).createCriteria()
                .andEqualTo(RoleAuthRel.CORP_CODE, ContextHandler.getCorpCode())
                .andIn(RoleAuthRel.ROLE_ID, roleIds);
        List<RoleAuthRel> authRelList = roleAuthRelMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(authRelList)) {
            return new HashSet<>(0);
        }

        authIds = new HashSet<>(authRelList.size());
        Map<String, List<String>> roleIdAndAuthIdsMap = new HashMap<>(roleIds.size());
        for (RoleAuthRel rel : authRelList) {
            List<String> authIdList = roleIdAndAuthIdsMap.computeIfAbsent(rel.getRoleId(), k -> new ArrayList<>());
            String authId = rel.getAuthId();
            authIdList.add(authId);
            authIds.add(authId);
        }

        addRoleAuthCache(roleIdAndAuthIdsMap);
        return authIds;
    }

    /**
     * 刷新角色权限缓存
     */
    public void refreshRoleAuthCache() {
        Example example = new Example(RoleAuthRel.class);
        example.selectProperties(RoleAuthRel.ROLE_ID, RoleAuthRel.AUTH_ID).createCriteria()
                .andEqualTo(RoleAuthRel.CORP_CODE, ContextHandler.getCorpCode());
        List<RoleAuthRel> authRelList = roleAuthRelMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(authRelList)) {
            return;
        }

        Map<String, List<String>> roleIdAndAuthIdsMap = new HashMap<>();
        for (RoleAuthRel rel : authRelList) {
            List<String> authIdList = roleIdAndAuthIdsMap.computeIfAbsent(rel.getRoleId(), k -> new ArrayList<>());
            authIdList.add(rel.getAuthId());
        }

        addRoleAuthCache(roleIdAndAuthIdsMap);
    }

    private Set<String> getAuthIdsFromCacheByRoleIds(Collection<String> roleIds) {
        String roleAuthKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.ROLE_AUTH;
        HashOperations<String, String, List<String>> operations = redisTemplate.opsForHash();
        List<List<String>> lists = operations.multiGet(roleAuthKey, roleIds);
        if (CollectionUtils.isEmpty(lists)) {
            return new HashSet<>(0);
        }

        Set<String> authIds = new HashSet<>();
        for (List<String> list : lists) {
            if (CollectionUtils.isNotEmpty(list)) {
                authIds.addAll(list);
            }
        }

        return authIds;
    }

    /**
     * 根据角色Id列表，批量删除角色权限关联信息
     *
     * @param roleIds 角色Id列表
     * @return 删除记录数
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public int deleteByRoleIds(List<String> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "roleIds not be empty!");
        }

        Example example = new Example(RoleAuthRel.class);
        example.createCriteria()
                .andEqualTo(RoleAuthRel.CORP_CODE, ContextHandler.getCorpCode())
                .andIn(RoleAuthRel.ROLE_ID, roleIds);
        int count = roleAuthRelMapper.deleteByExample(example);
        delRoleAuthCache(roleIds);
        return count;

    }

    /**
     * 删除角色与权限的缓存信息
     *
     * @param roleIds 角色Id
     */
    private void delRoleAuthCache(Collection<String> roleIds) {
        String roleAuthKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.ROLE_AUTH;
        HashOperations<String, String, List<String>> opsForHash = redisTemplate.opsForHash();
        opsForHash.delete(roleAuthKey, roleIds.toArray());
    }

    /**
     * 登录成功后，设置人员拥有的菜单权限对应的数据权限到缓存
     */
    public void setAuthDataPermissionInfoToCache(String userId) {
        List<String> roleIds = userRoleRelService.getAdminRoleIdsFromCache(userId);
        if (CollectionUtils.isEmpty(roleIds)) {
            return;
        }

        List<RoleAuthRel> authRelList = getAuthRelList(roleIds);
        if (CollectionUtils.isEmpty(authRelList)) {
            return;
        }

        Map<String, Map<String, String>> roleIdAndAuthIdWithDPMap = new HashMap<>(authRelList.size());
        for (RoleAuthRel authRel : authRelList) {
            if (StringUtils.isEmpty(authRel.getAuthCode())) {
                continue;
            }

            Map<String, String> codeAndDPMap = roleIdAndAuthIdWithDPMap.computeIfAbsent(authRel.getRoleId(), k -> new HashMap<>());
            codeAndDPMap.put(authRel.getAuthCode(), authRel.getDataPermission().name());
        }

        String key = UcRedisKeys.getAuthDataPermissionKey(ContextHandler.getCorpCode());
        HashOperations<String, String, Map<String, String>> operations = redisTemplate.opsForHash();
        operations.putAll(key, roleIdAndAuthIdWithDPMap);
        redisTemplate.expire(key, authExpireTime, TimeUnit.SECONDS);
    }

    public List<RoleAuthRel> getAuthRelList(List<String> roleIds) {
        Example example = Example.builder(RoleAuthRel.class)
                .select(RoleAuthRel.ROLE_ID, RoleAuthRel.AUTH_ID, RoleAuthRel.AUTH_CODE, RoleAuthRel.DATA_PERMISSION)
                .where(Sqls.custom()
                        .andEqualTo(RoleAuthRel.CORP_CODE, ContextHandler.getCorpCode())
                        .andIn(RoleAuthRel.ROLE_ID, roleIds))
                .build();
        return roleAuthRelMapper.selectByExample(example);
    }
}
