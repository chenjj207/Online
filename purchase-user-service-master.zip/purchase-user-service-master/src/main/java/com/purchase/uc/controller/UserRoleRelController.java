package com.purchase.uc.controller;

import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.purchase.uc.model.User;
import com.purchase.uc.model.UserRoleRel;
import com.purchase.uc.model.vo.UserComponent;
import com.purchase.uc.service.UserRoleRelService;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.*;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * UserRoleRel接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/userRoleRel")
@Api(description = "人员角色管理", tags = {"/userRoleRel/*", "userRoleRel"})
public class UserRoleRelController extends SelectComponentBaseController {

    @Resource
    private UserRoleRelService userRoleRelService;

    @PostMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    public JsonResult<Page<User>> search(@RequestBody UserRoleRel userRoleRel) {
        userRoleRel.setCorpCode(ContextHandler.getCorpCode());
        Page<UserRoleRel> page = new Page<>();
        page.setPageNum(userRoleRel.getPageNum());
        page.setPageSize(userRoleRel.getPageSize());
        Page<User> userPage = userRoleRelService.searchUser(userRoleRel, page);
        return new JsonResult<>(true, "查询成功", userPage);
    }

    @GetMapping(value = "/listAll")
    @ApiOperation(value = "获取所有数据")
    public JsonResult<List<UserRoleRel>> listAll() {
        return new JsonResult<>(true, "查询成功", userRoleRelService.listAll());
    }

    @PostMapping("/addUserRoleRel")
    @ApiOperation(value = "新增用户角色关联", nickname = "addUserRoleRel")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userIds", value = "用户id列表", dataType = "List", paramType = "query"),
            @ApiImplicitParam(name = "roleId", value = "角色id", dataType = "String", paramType = "query")
    })
    public JsonResult addUserRoleRel(@RequestBody @ParamHide UserRoleRel userRoleRel) {
        CheckFlow.start()
                .isNotNull(userRoleRel)
                .isNotEmpty(userRoleRel.getRoleId())
                .isNotEmpty(userRoleRel.getUserIds());
        try {
            userRoleRelService.addUserRoleRel(userRoleRel);
            return new JsonResult(true, "添加成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult(false, "添加失败");
        }
    }

    @PostMapping("/delUserRoleRel")
    @ApiOperation(value = "删除用户角色关联", nickname = "delUserRoleRel")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userIds", value = "用户id列表", dataType = "List", paramType = "query"),
            @ApiImplicitParam(name = "roleId", value = "角色id", dataType = "String", paramType = "query")
    })
    public JsonResult delUserRoleRel(@RequestBody @ParamHide UserRoleRel userRoleRel) {
        CheckFlow.start()
                .isNotNull(userRoleRel)
                .isNotEmpty(userRoleRel.getRoleId())
                .isNotEmpty(userRoleRel.getUserIds());
        try {
            userRoleRelService.delUserRoleRel(userRoleRel);
            return new JsonResult(true, "删除成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult(false, "删除失败");
        }
    }

    @PutMapping("")
    @ApiOperation(value = "编辑接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userId", value = "用户id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "roleId", value = "角色id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult editUserRoleRel(@ParamHide @Check(field = {"id"}) UserRoleRel userRoleRel) {
        userRoleRelService.update(userRoleRel);
        return new JsonResult(true, "编辑成功");
    }

    @GetMapping(value = "/{id}")
    @ApiOperation(value = "根据id获取对应试题")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true)
    )
    public JsonResult<UserRoleRel> getUserRoleRel(@PathVariable(value = "id") @Check String id) {
        UserRoleRel userRoleRel = userRoleRelService.get(id);
        return new JsonResult<>(true, "查询成功", userRoleRel);
    }

    @GetMapping(value = "/refreshUserRoleCache/{corpCode}")
    @ApiOperation(value = "刷新人员角色缓存")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "corpCode", value = "公司编号", paramType = "path", required = true)
    )
    public JsonResult<UserRoleRel> refreshUserRoleCache(@PathVariable(value = "corpCode") @Check String corpCode) {
        ContextHandler.setCorpCode(corpCode);
        userRoleRelService.refreshUserRoleCache();
        return new JsonResult<>(true, "刷新成功");
    }

    @DeleteMapping(value = "/delete")
    @ApiOperation(value = "根据传入的Id，删除数据", hidden = true)
    public JsonResult<String> batchDelete(@ApiParam(value = "数据源Id", required = true)
                                          @RequestBody List<String> ids) {
        try {
            userRoleRelService.delete(ids);
            return new JsonResult<>(true, "删除成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, "删除失败");
        }
    }

    //**实现选择组件controller开始***//
    @Override
    public JsonResult<List<String>> listSelectedUserId(@RequestBody ComponentCondition condition) {
        List<String> userIds = userRoleRelService.listSelectedUserId(condition);
        return new JsonResult<>(true, "操作成功", userIds);
    }

    @Override
    public JsonResult<Page<UserComponent>> searchSelectedUser(@RequestBody ComponentCondition condition) {
        Page<UserComponent> page = userRoleRelService.searchSelectedUser(condition);
        return new JsonResult<>(true, "操作成功", page);
    }

    @Override
    public JsonResult<Page<String>> searchSelectedUserId(ComponentCondition condition) {
        Page<String> page = userRoleRelService.searchSelectedUserId(condition);
        return new JsonResult<>(true, "操作成功", page);
    }

    @Override
    public JsonResult<String> addUsers(@RequestBody ComponentCondition condition) {
        userRoleRelService.addUsers(condition);
        return new JsonResult<>(true, "操作成功");
    }

    @Override
    public JsonResult<String> removeAllUsers(@RequestBody ComponentCondition condition) {
        userRoleRelService.removeAllUsers(condition);
        return new JsonResult<>(true, "操作成功");
    }

    @Override
    public JsonResult<String> removeUsers(@RequestBody ComponentCondition condition) {
        userRoleRelService.removeUsers(condition);
        return new JsonResult<>(true, "操作成功");
    }
}
