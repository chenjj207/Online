package com.purchase.uc.service;

import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.mapper.RoleMapper;
import com.purchase.uc.model.Role;
import com.purchase.uc.base.UcException;
import com.purchase.uc.utils.RedisUtil;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.weekend.Weekend;

import javax.annotation.Resource;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.qgutech.qgyun.framework.database.model.BaseCorpModel.CORP_CODE;

/**
 * 角色相关服务接口及实现
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
@Slf4j
public class RoleService extends BaseServiceImpl<Role> {

    @Resource
    private RoleMapper roleMapper;
    @Resource
    private UserRoleRelService userRoleRelService;
    @Resource
    private RoleAuthRelService roleAuthRelService;
    @Resource
    private RedisTemplate redisTemplate;

    public List<Role> listAll() {
        return roleMapper.selectAll();
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public JsonResult<String> insertRole(Role role) {
        if (role == null) {
            throw new IllegalArgumentException("Role is null when insertRole");
        }

        boolean exist = existByProperty(Role.NAME, role.getName());
        if (exist) {
            return new JsonResult<>(false, UcI18nConstants.UC_NAME_DUPLICATE.getName(), null);
        }

        if (StringUtils.isBlank(role.getId())) {
            role.setId(IDUtils.getUUID19());
        }
        String code = genRoleCode();
        log.info("gencode:{}", code);
        role.setCode(code);
        roleMapper.insert(role);
        return new JsonResult<>(true, UcI18nConstants.UC_ADD_SUCCESS.getName(), role.getId());
    }

    private String genRoleCode() {
        Long num = RedisUtil.genCode("ROLE_CODE", redisTemplate, () -> {
            return roleMapper.getCode();
        });
        String numTemp = num+"";
        try{
            DecimalFormat df = new DecimalFormat("000");
            numTemp = df.format(num);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return numTemp;
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public JsonResult updRole(Role role) {
        if (role == null || StringUtils.isEmpty(role.getId())) {
            throw new IllegalArgumentException("Role or role.id is null when updRole");
        }

        Role dbRole = get(role.getId());
        if (!role.getName().equals(dbRole.getName())) {
            boolean exist = existByProperty(Role.NAME, role.getName());
            if (exist) {
                return new JsonResult(false, UcI18nConstants.UC_NAME_DUPLICATE.getName());
            }
        }

        roleMapper.updateByPrimaryKeySelective(role);
        return new JsonResult(true, UcI18nConstants.UC_EDIT_SUCCESS.getName());
    }

    /**
     * 获取所有启用的管理员角色或者学员角色
     *
     * @param manage 是否为管理员角色
     * @return 启用的角色列表
     */
    public List<Role> listAll(Boolean manage) {
        Role role = new Role();
        if (manage != null) {
            role.setManage(manage);
        }

        role.setStatus(UcConstants.STATUS_ENABLED);
        role.setCorpCode(ContextHandler.getCorpCode());
        return roleMapper.select(role);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public JsonResult delete(List<String> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "RoleIds is empty when delete!");
        }

        batchDelete(roleIds);
        userRoleRelService.deleteByRoleIds(roleIds);
        roleAuthRelService.deleteByRoleIds(roleIds);

        return new JsonResult(true, UcI18nConstants.UC_DELETE_SUCCESS.getName());
    }

    /**
     * 禁用角色
     *
     * @param roleIds 角色Id列表
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void disabled(List<String> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "roleIds not be empty!");
        }

        updateStatus(roleIds, UcConstants.STATUS_DISABLED);
        userRoleRelService.delUserRoleCache(roleIds);
    }

    private void updateStatus(List<String> roleIds, String status) {
        Example example = new Example(Role.class);
        example.createCriteria().andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andIn(Role.ID, roleIds);
        Role role = new Role();
        role.setStatus(status);
        roleMapper.updateByExampleSelective(role, example);
    }

    /**
     * 启用角色
     *
     * @param roleIds 角色Id列表
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void enabled(List<String> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "roleIds not be empty!");
        }

        updateStatus(roleIds, UcConstants.STATUS_ENABLED);
        Map<String, List<String>> roleIdAndUserIdsMap = userRoleRelService.getRoleIdAndUserIdsMap(roleIds);
        if (MapUtils.isEmpty(roleIdAndUserIdsMap)) {
            return;
        }

        for (String roleId : roleIdAndUserIdsMap.keySet()) {
            List<String> userIds = roleIdAndUserIdsMap.get(roleId);
            if (CollectionUtils.isEmpty(userIds)) {
                continue;
            }

            userRoleRelService.addUserRoleCache(roleId, userIds);
        }
    }

    /**
     * 根据用户Id，获取用户拥有的角色列表
     *
     * @param userId 用户Id
     * @return 角色列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<Role> listByUserId(String userId) {
        return listByUserId(userId, null);
    }

    /**
     * 根据用户Id，获取用户拥有的角色列表[有权限的，自己创建的，所有学员角色]
     *
     * @param userId 用户Id
     * @param manage 是否管理角色，null 所有角色
     * @return 角色列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<Role> listByUserId(String userId, Boolean manage) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        List<String> roleIds = userRoleRelService.getRoleIdsByUserId(userId, manage);
        Example example = new Example(Role.class);
        example.selectProperties(Role.ID, Role.CODE, Role.NAME, Role.MANAGE, Role.CREATED_BY);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(Role.STATUS, UcConstants.STATUS_ENABLED);
        Example.Criteria roleIdCriteria = new Weekend<>(Role.class).createCriteria();
        if (CollectionUtils.isNotEmpty(roleIds)) {
            roleIdCriteria.orIn(Role.ID, roleIds);
        }

        roleIdCriteria.orEqualTo(Role.CREATED_BY, userId)
                .orEqualTo(Role.MANAGE, false);
        example.and(roleIdCriteria);
        if (manage != null) {
            criteria.andEqualTo(Role.MANAGE, manage);
        }

        example.setOrderByClause("created_at");

        return roleMapper.selectByExample(example);
    }

    /**
     * 根据用户Id，获取用户可管辖的角色
     *
     * @param userId 用户Id
     * @return 角色列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<Role> listAuthByUserId(String userId) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        //if (ContextHandler.isSuperAdmin()) {
            return listAll(null);
        /*}

        List<String> roleIds = userRoleRelService.getRoleIds(userId);
        if (CollectionUtils.isEmpty(roleIds)) {
            return new ArrayList<>(0);
        }

        String id = ContextHandler.getCorpCode() + "_" + UcConstants.DEFAULT_ADMIN_ROLE;
        if (roleIds.contains(id)) {
            return listAll(null);
        }

        Example example = new Example(Role.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(Role.STATUS, UcConstants.STATUS_ENABLED);
        Example.Criteria roleIdCriteria = new Weekend<>(Role.class).createCriteria();
        if (CollectionUtils.isNotEmpty(roleIds)) {
            roleIdCriteria.orIn(Role.ID, roleIds);
        }

        roleIdCriteria.orEqualTo(Role.CREATED_BY, userId).orEqualTo(Role.MANAGE, false);
        example.and(roleIdCriteria);
        example.setOrderByClause("created_at");
        return roleMapper.selectByExample(example);*/
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public boolean checkUserHasAdminRole(String userId) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        List<String> roleIds = userRoleRelService.getRoleIdsByUserId(userId, true);
        return CollectionUtils.isNotEmpty(roleIds);
    }

    /**
     * 该方法用于根据属性判断记录是否存在
     *
     * @param property 属性名
     * @param value    属性值
     * @return 是否存在
     */
    public boolean existByProperty(String property, String value) {
        if (StringUtils.isEmpty(property) || StringUtils.isEmpty(value)) {
            throw new IllegalArgumentException("Property or value is empty when existByProperty!");
        }

        Example example = new Example(Role.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(property, value)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());

        return roleMapper.selectCountByExample(example) > 0;
    }

    /**
     * 根据角色编号获取角色Id
     *
     * @param roleCode 角色编号
     * @return 角色Id
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public String getRoleIdByCode(String roleCode) {
        if (StringUtils.isEmpty(roleCode)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "roleCode not be empty!");
        }

        Example example = new Example(Role.class);
        example.selectProperties(Role.ID)
                .createCriteria()
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(Role.CODE, roleCode);

        Role role = roleMapper.selectOneByExample(example);
        return role == null ? null : role.getId();
    }

    /**
     * 获取所有启用的学员角色,不包含外部学员角色
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<Role> listAllUserRole() {
        Example example = new Example(Role.class);
        example.selectProperties(Role.ID, Role.NAME);
        example.createCriteria()
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(Role.MANAGE, false);
        Example.Criteria weekendCriteria = new Weekend<>(Role.class).createCriteria();
        weekendCriteria.orNotEqualTo(Role.CODE, UcConstants.OUTER_USER_ROLE)
                .orIsNull(Role.CODE);
        example.and(weekendCriteria);
        example.setOrderByClause("created_at");
        return roleMapper.selectByExample(example);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void initRole() {
        initRole(UcConstants.DEFAULT_ADMIN_ROLE, "系统管理员", true);
        initRole(UcConstants.SALE_USER_ROLE, "销售人员", false);
        initRole(UcConstants.TECHNOLOGY_USER_ROLE, "技术人员", false);
        initRole(UcConstants.BUSINESS_USER_ROLE, "商务人员", false);
        userRoleRelService.refreshUserRoleCache();
    }

    private void initRole(String code, String name, boolean manage) {
        if (existByProperty(Role.CODE, code)) {
            return;
        }

        Role role = new Role();
        if (UcConstants.DEFAULT_ADMIN_ROLE.equals(code)
                || UcConstants.OUTER_USER_ROLE.equals(code)) {
            role.setId(ContextHandler.getCorpCode() + "_" + code);
        }

        role.setStatus(UcConstants.STATUS_ENABLED);
        role.setManage(manage);
        role.setCode(code);
        role.setName(name);
        insertRole(role);
    }
}
