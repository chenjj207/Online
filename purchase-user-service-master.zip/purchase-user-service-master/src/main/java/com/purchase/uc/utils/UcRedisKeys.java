package com.purchase.uc.utils;

/**
 * Uc模块redisKey集合
 *
 * @version 1.0
 * @since 2019年06月03日11:46:08
 */
public interface UcRedisKeys {
    /**
     * 所有UC应用redisKey前缀
     */
    String UC_ = "uc_";

    /**
     * 用户基本信息缓存
     */
    String USERS = "_users";

    /**
     * 用户登录信息缓存
     */
    String USER_LOGIN = "_userLogin";

    /**
     * 用户登录名缓存loginNames(loginName、mobile、email、idCard)
     */
    String LOGIN_NAMES = "_loginNames";

    /**
     * 权限树缓存
     */
    String AUTH_TREE = "_authTree";

    /**
     * 用户角色
     */
    String USER_ROLE = "_userRole";

    /**
     * 管理员角色
     */
    String ADMIN_ROLE = "_adminRole";

    /**
     * 角色权限
     */
    String ROLE_AUTH = "_roleAuth";

    /**
     * 动态群组
     */
    String GROUPS = "_groups";

    /**
     * 部门树缓存
     */
    String ORG_TREE = "_orgTree";

    /**
     * 人员群组缓存
     */
    String USER_GROUP = "_userGroup";

    /**
     * 群组人员缓存
     */
    String GROUP_MEMBERS = "_groupMembers";

    /**
     * 用户管辖范围缓存
     */
    String RANGE_MANAGE = "_rangeManage";

    /**
     * 群组相关后缀：静态群组
     */
    String GROUP_SUF_S = "_s";

    /**
     * 群组相关后缀：动态群组
     */
    String GROUP_SUF_D = "_d";

    /**
     * 人员开放范围缓存
     */
    String OPEN_SCOPE = "_openScope";

    /**
     * 人员管理群组管辖范围查询开关
     */
    String GROUP_RANGE_SWITCH = "_group_range_switch";

    /**
     * 人员导入暂存
     */
    String USER_IMPORT = "user_import_";

    /**
     * 人员修改导入暂存
     */
    String USER_IMPORT_UPDATE = "user_import_update_";

    /**
     * 使用范围
     */
    String USE_SCOPE = "_ucUseScope";

    /**
     * 短信验证码
     */
    String VERIFY_CODE_PREFIX = "verify_code_";
    String VERIFY_MOBILE_PREFIX = "verify_mobile_";
    String USER_RANGE = "user_range_";
    String AUTH_CODE_ROLE_DATA_PERMISSION = "_auth_code_role_dp";

    /**
     * 学员角色key
     */
    static String getUserRoleKey(String corpCode) {
        return UcRedisKeys.UC_ + corpCode + UcRedisKeys.USER_ROLE;
    }

    /**
     * 管理员角色key
     */
    static String getAdminRoleKey(String corpCode) {
        return UcRedisKeys.UC_ + corpCode + UcRedisKeys.ADMIN_ROLE;
    }

    /**
     * 角色对应的数据权限缓存key
     */
    static String getAuthDataPermissionKey(String corpCode) {
        return UcRedisKeys.UC_ + corpCode + UcRedisKeys.AUTH_CODE_ROLE_DATA_PERMISSION;
    }

    /**
     * 人员管辖范围key
     */
    static String getUserRangeKey(String userId) {
        return UcRedisKeys.USER_RANGE + userId;
    }
}
