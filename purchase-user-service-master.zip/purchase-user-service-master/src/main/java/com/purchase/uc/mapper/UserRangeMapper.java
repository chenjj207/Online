package com.purchase.uc.mapper;

import com.purchase.uc.model.UserRange;
import com.purchase.uc.model.vo.UserComponent;
import com.purchase.uc.model.User;
import com.purchase.uc.model.vo.OrgComponent;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * todo: 请编写此处添加注释，注名此接口的作用
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
public interface UserRangeMapper extends QguBaseMapper<UserRange> {
    List<UserRange> searchUserRange(@Param("range") UserRange range, @Param("page") Page<UserRange> page);

    Integer searchUserRangeTotal(@Param("range") UserRange range);

    List<UserRange> searchOrg(@Param("range") UserRange userRange, @Param("page") Page<OrgComponent> page);

    Integer searchOrgTotal(@Param("range") UserRange userRange);

    List<String> findRangeListByUserId(@Param("userId") String userId);

    List<User> searchUser(@Param("range") UserRange range, @Param("page") Page<UserComponent> page);

    Integer searchUserTotal(@Param("range") UserRange userRange);

    List<UserRange> getUserIdAndRefCntMap(@Param("corpCode") String corpCode, @Param("userIds") List<String> userIds);
}
