package com.purchase.uc.controller;

import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.purchase.uc.model.UserRange;
import com.purchase.uc.model.vo.OrgComponent;
import com.purchase.uc.model.vo.UserComponent;
import com.purchase.uc.service.UserRangeService;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * UserRange接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/userRange")
@Api(value = "管辖范围管理", description = "管辖范围管理", tags = {"/userRange/*", "userRange"})
public class UserRangeController extends SelectComponentBaseController {

    @Resource
    private UserRangeService userRangeService;

    @RequestMapping(value = "/page", method = RequestMethod.GET)
    @ApiOperation(value = "分页获取有管辖范围的管理员列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "keyword", value = "姓名/用户名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "referId", value = "查询部门Id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<UserRange>> search(@ParamHide UserRange userRange, @ParamHide Page<UserRange> page) {
        userRange.setCorpCode(ContextHandler.getCorpCode());
        page = userRangeService.searchUserRange(userRange, page);
        return new JsonResult<>(true, "查询成功", page);
    }

    @RequestMapping(value = "/orgPage", method = RequestMethod.GET)
    @ApiOperation(value = "分页人员管辖的部门列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userId", value = "管理员用户Id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "keyword", value = "部门名称", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<OrgComponent>> orgPage(@ParamHide UserRange userRange, @ParamHide Page<OrgComponent> page) {
        userRange.setCorpCode(ContextHandler.getCorpCode());
        page = userRangeService.searchOrg(userRange, page);
        return new JsonResult<>(true, "查询成功", page);
    }

    @RequestMapping(value = "/editUserRange", method = RequestMethod.PUT)
    @ApiOperation(value = "编辑用户管辖范围", nickname = "updUserRange")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userId", value = "用户id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "orgIds", value = "管辖部门id列表", dataType = "String", paramType = "query")
    })
    public JsonResult editUserRange(@ParamHide @Check(field = {"id"}) UserRange userRange) {
        try {
            userRangeService.update(userRange);
            return new JsonResult(true, "编辑成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult(false, "编辑失败");
        }
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "根据id获取对应试题")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true)
    )
    public JsonResult<UserRange> getUserRange(@PathVariable(value = "id") @Check String id) {
        UserRange userRange = userRangeService.get(id);
        return new JsonResult<>(true, "查询成功", userRange);
    }

    @Override
    public JsonResult<String> addOrgs(@RequestBody ComponentCondition condition) {
        userRangeService.addOrgs(condition);
        return new JsonResult<>(true, "操作成功");
    }

    @Override
    public JsonResult<String> removeOrgs(@RequestBody ComponentCondition condition) {
        userRangeService.removeOrgs(condition);
        return new JsonResult<>(true, "操作成功");
    }

    @ApiImplicitParams({
            @ApiImplicitParam(name = "funId", value = "管理员用户Id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "keywords", value = "部门名称", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    @Override
    public JsonResult<Page<OrgComponent>> searchSelectedOrg(@RequestBody ComponentCondition condition) {
        return new JsonResult<>(true, "查询成功", userRangeService.searchSelectedOrg(condition));
    }

    @Override
    public JsonResult<List<String>> listSelectedUserId(@RequestBody ComponentCondition condition) {
        List<String> userIds = userRangeService.listSelectedUserId(condition);
        return new JsonResult<>(true, "查询成功", userIds);
    }

    @Override
    public JsonResult<Page<UserComponent>> searchSelectedUser(@RequestBody ComponentCondition condition) {
        Page<UserComponent> page = userRangeService.searchSelectedUser(condition);
        return new JsonResult<>(true, "查询成功", page);
    }

    @Override
    public JsonResult<String> addUsers(@RequestBody ComponentCondition condition) {
        userRangeService.addUsers(condition);
        return new JsonResult<>();
    }

    @Override
    public JsonResult<String> removeAllUsers(@RequestBody ComponentCondition condition) {
        userRangeService.removeAllUsers(condition);
        return new JsonResult<>();
    }

    @Override
    public JsonResult<String> removeUsers(@RequestBody ComponentCondition condition) {
        userRangeService.removeUsers(condition);
        return new JsonResult<>();
    }
}
