package com.purchase.uc.controller;

import com.purchase.uc.service.OrgService;
import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.model.Org;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.LogUtil;
import com.qgutech.qgyun.framework.database.mybatis.model.TreeNode;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * Org接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/org")
@Api(value = "部门管理", description = "部门管理", tags = {"/org/*", "org"})
public class OrgController {
    private Logger LOG = LogUtil.getLogger(GroupMemberController.class);

    @Resource
    private OrgService orgService;

    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    @ApiOperation(value = "新增部门", nickname = "addOrg")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "组织名称", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "code", value = "组织编号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pId", value = "父id", dataType = "String", paramType = "query"),
    })
    public JsonResult insert(@RequestBody Org org) {
        return orgService.saveOrg(org);
    }

    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    @ApiOperation(value = "编辑部门", nickname = "updOrg")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "组织名称", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "code", value = "组织编号", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pId", value = "父id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "部门状态（DISABLED：激活，DISABLED：冻结）", dataType = "String",
                    paramType = "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult editOrg(@RequestBody @Check(field = {"id"}) Org org) {
        return orgService.updateOrg(org);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "获取部门信息")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true)
    )
    public JsonResult<Org> getOrg(@PathVariable(value = "id") @Check String id) {
        Org org = orgService.get(id);
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), org);
    }

    @ApiOperation(value = "上移下移部门")
    @RequestMapping(value = "/move", method = RequestMethod.POST)
    public JsonResult<String> move(@RequestParam String nodeId, @RequestParam String moveType) {
        orgService.move(nodeId, moveType);
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName());
    }

    @RequestMapping(value = "/getOrgTree", method = RequestMethod.GET)
    @ApiOperation(value = "获取当前登录用户管辖范围的部门树")
    public JsonResult<TreeNode> getOrgTree() {
        TreeNode rootNode = orgService.getAuthTreeByUserId(ContextHandler.getUserId());
        return new JsonResult<>(true, UcI18nConstants.UC_OPT_SUCCESS.getName(), rootNode);
    }

    @ApiOperation(value = "删除部门", nickname = "delOrg")
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public JsonResult delete(@RequestParam String orgId) {
        return orgService.delOrg(orgId);
    }
}
