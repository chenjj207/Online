package com.purchase.uc.mapper;

import com.purchase.uc.model.UserDetail;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 用户详情Mapper
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
public interface UserDetailMapper extends QguBaseMapper<UserDetail> {

    /**
     * 人员修改导入，更新detail字段（仅更新了修改导入时的几个字段）
     *
     * @param detail 用户详情
     */
    void updateDetail(@Param("detail") UserDetail detail);
}
