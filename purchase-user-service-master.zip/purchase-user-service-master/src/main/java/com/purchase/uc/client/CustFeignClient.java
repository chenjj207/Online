package com.purchase.uc.client;

import com.purchase.model.Customer;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 客户接口服务
 *
 * @author lwl
 */
@FeignClient(value = "purchase-cust", path = "/custFeign")
public interface CustFeignClient {

    /**
     * 根据id，获取对象
     *
     * @param id 主键
     * @return 客户对象
     */
    @GetMapping("/getById")
    Customer getById(@RequestParam("id") String id);

}
