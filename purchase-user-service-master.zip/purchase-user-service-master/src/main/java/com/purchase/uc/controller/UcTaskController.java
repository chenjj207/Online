package com.purchase.uc.controller;

import com.purchase.uc.service.GroupService;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * UcTaskController 定时器入口
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年06月27日18:14:49
 */
@RestController
@RequestMapping(value = "/task")
@Api(value = "UcTaskController接口", tags = {"UcTaskController接口"})
public class UcTaskController {
    private static final Logger logger = LoggerFactory.getLogger(UcTaskController.class);

    @Resource
    private GroupService groupService;

    @RequestMapping(value = "/refreshDynamicGroup", method = RequestMethod.POST)
    @ApiOperation(value = "刷新动态群组人员，定时刷新调用")
    public JsonResult<String> refreshDynamicGroup() {
        long startMillis = System.currentTimeMillis();
        logger.info("开始刷新动态群组数据，开始时间：" + startMillis);
        try {
            String corpCode = StringUtils.defaultString(ContextHandler.getCorpCode(), "default");
            groupService.putDynamicConditionToCache(null, corpCode);
            logger.info("完成刷新动态群组数据，耗时：" + (System.currentTimeMillis() - startMillis));
            return new JsonResult<>(true, "刷新成功", "");
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, "刷新失败", "");
        }
    }
}
