package com.purchase.uc.client.wx;

import com.purchase.uc.client.wx.entity.WxClusterResultInfo;
import com.purchase.uc.client.wx.entity.auth.ScanLoginVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

@Component
@FeignClient(name = "WxCluster", url = "${zyd.wx-cluster.host}")
public interface WxClusterFeign {

    /**
     * 获取用户信息
     * 用于企业微信扫码登录
     */
    @GetMapping("/platform-access/oauth2/access/info")
    WxClusterResultInfo<ScanLoginVO> oauth2AccessInfo(@RequestParam("bm") String bm,
                                                      @RequestParam("accessToken") String accessToken);

}
