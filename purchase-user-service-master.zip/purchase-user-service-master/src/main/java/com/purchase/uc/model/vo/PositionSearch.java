package com.purchase.uc.model.vo;

import com.qgutech.qgyun.framework.common.context.ContextHandler;
import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * 岗位分页查询条件
 */
@Getter
@Setter
@ToString
@ApiModel(value = "PositionSearch", description = "岗位查询条件")
public class PositionSearch extends BaseCondition {
    private String userId;

    private List<String> categoryIdList;

    private String categoryId;

    public String getCorpCode() {
        return ContextHandler.getCorpCode();
    }
}
