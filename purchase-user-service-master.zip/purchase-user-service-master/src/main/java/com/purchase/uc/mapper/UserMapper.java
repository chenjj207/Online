package com.purchase.uc.mapper;

import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcException;
import com.purchase.uc.model.User;
import com.purchase.uc.model.UserDetail;
import com.purchase.uc.model.vo.UserCache;
import com.purchase.uc.model.vo.UserCondition;
import com.purchase.uc.service.UserService;
import com.purchase.uc.utils.UcRedisKeys;
import com.purchase.uc.utils.UcUtil;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 人员UserMapper接口
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年06月19日14:51:50
 */
public interface UserMapper extends QguBaseMapper<User> {
    /**
     * 根据分页条件及查询条件获取分页list
     *
     * @param user     查询条件
     * @param pageInfo 分页条件
     * @return 指定大小的list
     */
    List<User> searchUser(@Param("user") UserCondition user, @Param("page") Page<User> pageInfo);

    /**
     * 满足分页条件的总条数
     *
     * @param user 查询条件
     * @return 总条数
     */
    int getUserTotal(@Param("user") UserCondition user);

    /**
     * 更新人员信息，如果字段为'null'，设置为null
     *
     * @param user 人员信息对象
     */
    void updateUser(@Param("user") User user);

    /**
     * 跟进手机号登录账号查询用户数据
     * @param code
     * @return
     */
    @Select("SELECT * FROM t_uc_user WHERE login_name =#{code} and corp_code =#{corpCode}")
    User searchAllByLoginName(@Param("code") String code, @Param("corpCode") String corpCode);

    /**
     * 根据用户Id，批量获取用户信息列表
     *
     * @param userIds       用户Id列表
     * @param includeDetail 是否包含用户detail信息
     * @param userService
     * @return 用户信息列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    default List<User> listByUserIdFromCache(List<String> userIds, boolean includeDetail, UserService userService) {
        if (CollectionUtils.isEmpty(userIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userIds not be empty!");
        }

        String usersKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.USERS;
        HashOperations<String, String, String> operations = userService.redisTemplate.opsForHash();
        List<String> userCaches = operations.multiGet(usersKey, userIds);
        List<UserCache> userCacheList = UcUtil.toUserCache(userCaches);
        List<User> users;
        if (CollectionUtils.isEmpty(userCacheList)) {
            users = userService.listByIds(userIds);
            userService.setFaceUrl(users);
            userCacheList = UcUtil.convertToUserCache(users);
            if (CollectionUtils.isNotEmpty(userCacheList)) {
                Map<String, String> userMap = new HashMap<>(userCacheList.size());
                userCacheList.forEach(userCache -> userMap.put(userCache.getId(), userCache.encode()));
                userService.redisTemplate.opsForHash().putAll(usersKey, userMap);
            }
        } else {
            users = UcUtil.convertToUser(userCacheList);
        }

        if (!includeDetail) {
            return users;
        }

        Map<String, UserDetail> userDetailMap = userService.userDetailService.getUserIdAndDetailMap(userIds);
        if (MapUtils.isEmpty(userDetailMap)) {
            return users;
        }

        for (User user : users) {
            UserDetail detail = userDetailMap.get(user.getId());
            user.setUserDetail(detail);
        }

        return users;
    }
}
