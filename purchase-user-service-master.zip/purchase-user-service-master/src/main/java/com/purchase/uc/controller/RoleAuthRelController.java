package com.purchase.uc.controller;

import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.model.RoleAuthRel;
import com.purchase.uc.service.AuthService;
import com.purchase.uc.service.RoleAuthRelService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import com.qgutech.qgyun.framework.starter.web.validator.annotations.Check;
import io.swagger.annotations.*;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * RoleAuthRel接口
 * todo: 请编写此处添加注释，注名此接口的作用
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/roleAuthRel")
@Api(value = "RoleAuthRel接口", tags = {"RoleAuthRel接口"})
public class RoleAuthRelController {

    @Resource
    private RoleAuthRelService roleAuthRelService;
    @Resource
    private AuthService authService;

    @GetMapping(value = "/page")
    @ApiOperation(value = "获取分页")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "authId", value = "权限id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<RoleAuthRel>> search(@ParamHide RoleAuthRel roleAuthRel, @ParamHide Page<RoleAuthRel> page) {
        page = roleAuthRelService.search(roleAuthRel, page);
        return new JsonResult<Page<RoleAuthRel>>(true, "查询成功", page);
    }

    @GetMapping(value = "/listAll")
    @ApiOperation(value = "获取所有数据")
    public JsonResult<List<RoleAuthRel>> listAll() {
        return new JsonResult<>(true, "查询成功", roleAuthRelService.listAll());
    }

    @RequestMapping(value = "/addRoleAuthRel", method = RequestMethod.POST)
    @ApiOperation(value = "为角色批量添加权限")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "authId", value = "权限id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "authIds", value = "权限id列表", dataType = "List", paramType = "query"),
    })
    public JsonResult addRoleAuthRel(@RequestBody RoleAuthRel roleAuthRel) {
        try {
            roleAuthRelService.save(roleAuthRel);
            return new JsonResult(true, UcI18nConstants.UC_ADD_SUCCESS.getName());
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult(false, UcI18nConstants.UC_ADD_ERROR.getName());
        }
    }

    @PutMapping("")
    @ApiOperation(value = "编辑接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "authId", value = "权限id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "id", value = "主键id", required = true, paramType = "query")
    })
    public JsonResult editRoleAuthRel(@ParamHide @Check(field = {"id"}) RoleAuthRel roleAuthRel) {
        roleAuthRelService.update(roleAuthRel);
        return new JsonResult(true, "编辑成功");
    }

    @GetMapping(value = "/{id}")
    @ApiOperation(value = "根据id获取对应试题")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "id", value = "主键id", paramType = "path", required = true)
    )
    public JsonResult<RoleAuthRel> getRoleAuthRel(@PathVariable(value = "id") @Check String id) {
        RoleAuthRel roleAuthRel = roleAuthRelService.get(id);
        return new JsonResult<>(true, "查询成功", roleAuthRel);
    }

    @DeleteMapping(value = "")
    @ApiOperation(value = "根据传入的Id，删除数据", hidden = true)
    public JsonResult<String> batchDelete(@ApiParam(value = "数据源Id", required = true)
                                          @RequestBody List<String> ids) {
        roleAuthRelService.batchDelete(ids);
        return new JsonResult<>(true, "删除成功");
    }
}
