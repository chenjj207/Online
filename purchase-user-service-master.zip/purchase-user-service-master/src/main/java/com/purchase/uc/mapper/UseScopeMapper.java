package com.purchase.uc.mapper;

import com.qgutech.qgyun.dev.common.mapper.CommonRelMapper;
import com.purchase.uc.model.UseScope;
import org.apache.ibatis.annotations.Mapper;

/**
 * 使用范围(授权)Mapper
 *
 * @version 1.0
 * @since 2019年06月13日14:21:59
 */
@Mapper
public interface UseScopeMapper extends CommonRelMapper<UseScope> {

}
