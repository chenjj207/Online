package com.purchase.uc.service;

import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcException;
import com.purchase.uc.config.AliSmsProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/***
 * 阿里短信业务处理类
 */
@Slf4j
@Service
public class AliSmsService {


    @Resource
    AliSmsProperties aliSmsProperties;

    @Resource
    public StringRedisTemplate stringRedisTemplate;

    private final String KEY_TEMP = "ZYD_ONLINE_CAPTCHA_%s_%s";



    public SendSmsResponse send(String tempCode, JSONObject tempParam, String phone)  {
        try {
            // 设置超时时间-可自行调整
            System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
            System.setProperty("sun.net.client.defaultReadTimeout", "10000");
            // 初始化ascClient需要的几个参数
            final String product = "Dysmsapi";// 短信API产品名称（短信产品名固定，无需修改）
            final String domain = "dysmsapi.aliyuncs.com";// 短信API产品域名（接口地址固定，无需修改）
            // 替换成你的AK
            // 初始化ascClient,暂时不支持多region（请勿修改）
            IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", aliSmsProperties.getAccesskeyId(),
                    aliSmsProperties.getAccessKeySecret());
            DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
            IAcsClient acsClient = new DefaultAcsClient(profile);
            // 组装请求对象
            SendSmsRequest request = new SendSmsRequest();
            // 使用post提交
            request.setMethod(MethodType.POST);
            // 必填:待发送手机号。支持以逗号分隔的形式进行批量调用，批量上限为1000个手机号码,批量调用相对于单条调用及时性稍有延迟,验证码类型的短信推荐使用单条调用的方式；发送国际/港澳台消息时，接收号码格式为国际区号+号码，如“85200000000”
            request.setPhoneNumbers(phone);
            // 必填:短信签名-可在短信控制台中找到
            request.setSignName(aliSmsProperties.getSignName());
            // 必填:短信模板-可在短信控制台中找到，发送国际/港澳台消息时，请使用国际/港澳台短信模版
            request.setTemplateCode(tempCode);
            // 可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${smsCode}"时,此处的值为
            // 友情提示:如果JSON中需要带换行符,请参照标准的JSON协议对换行符的要求,比如短信内容中包含\r\n的情况在JSON中需要表示成\\r\\n,否则会导致JSON在服务端解析失败
            request.setTemplateParam(tempParam.toString());
            // 可选-上行短信扩展码(扩展码字段控制在7位或以下，无特殊需求用户请忽略此字段)
            // request.setSmsUpExtendCode("90997");
            // 可选:outId为提供给业务方扩展字段,最终在短信回执消息中将此值带回给调用者
            request.setOutId("yourOutId");

            // 请求失败这里会抛ClientException异常
            SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);
            return sendSmsResponse;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            new Exception("短信发送失败");
            return null;
        }
    }

    /***
     * 发送短信验证码
     * @author CGR
     * @param tempCode 模板编码
     * @param tempParam 模板参数
     * @param phone 手机号码
     * @return
     */
    public SendSmsResponse sendCaptcha(String tempCode, JSONObject tempParam, String phone) {
        return sendCaptcha(tempCode, tempParam, phone, "code");
    }

    /***
     * 发送短信验证码
     * @author CGR
     * @param tempCode 模板编码
     * @param tempParam 模板参数
     * @param phone 手机号码
     * @param minutes 验证码过期时间（分钟）
     * @return
     */
    public SendSmsResponse sendCaptcha(String tempCode, JSONObject tempParam, String phone, int minutes) {
        return sendCaptcha(tempCode, tempParam, phone, "code",minutes);
    }

    /***
     * 发送短信验证码
     * @param tempCode 模板编码
     * @param tempParam 模板参数
     * @param phone 手机号码
     * @param code 验证码key
     * @return
     */
    public SendSmsResponse sendCaptcha(String tempCode, JSONObject tempParam, String phone, String code)  {
        String value = getRandomCode();
        tempParam.put(code, value);
        String key = String.format(KEY_TEMP, tempCode, phone);

        SendSmsResponse smsResponse = send(tempCode, tempParam, phone);
        if("OK".equalsIgnoreCase(smsResponse.getCode())){
            //缓存验证码10分钟有效期
            stringRedisTemplate.opsForValue().set(key, value, 10, TimeUnit.MINUTES);
        }
        return smsResponse;
    }

    /***
     * 发送短信验证码
     * @param tempCode 模板编码
     * @param tempParam 模板参数
     * @param phone 手机号码
     * @param code 验证码key
     * @param minutes 验证码过期时间（分钟）
     * @return
     */
    public SendSmsResponse sendCaptcha(String tempCode, JSONObject tempParam, String phone, String code, int minutes)  {
        String value = getRandomCode();
        tempParam.put(code, value);
        String key = String.format(KEY_TEMP, tempCode, phone);

        SendSmsResponse smsResponse = send(tempCode, tempParam, phone);
        if("OK".equalsIgnoreCase(smsResponse.getCode())){
            //缓存验证码10分钟有效期
            if(minutes<=0) minutes = 10;
            stringRedisTemplate.opsForValue().set(key, value, minutes, TimeUnit.MINUTES);
        }
        return smsResponse;
    }

    /**
     * 验证码校验
     * @param tempCode
     * @param phone
     * @param code
     * @throws Exception
     */
    public void valid(String tempCode, String phone, String code){
        String key = String.format(KEY_TEMP, tempCode, phone);
        String value = stringRedisTemplate.opsForValue().get(key);//获取验证码
        if(value == null || code ==null || !code.equals(value)){
            throw new UcException(UcErrorCode.VERIFICATION_CODE_ERROR);
        }
    }

    /**
     * 生成短信随机码
     * @return
     */
    private String getRandomCode(){
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        int i = 0;
        while (i<6){
            sb.append(random.nextInt(10));
            i++;
        }
        return sb.toString();
    }


    /***
     * 根据合同模板和手机号获取短信验证码
     * @param tempCode 模板编码
     * @param phone 手机号码
     * @return
     */
    public String getSmsCode(String tempCode,String phone) {
        String key = String.format(KEY_TEMP, tempCode, phone);
        return stringRedisTemplate.opsForValue().get(key);
    }

}
