package com.purchase.uc.common.controller;

import com.purchase.uc.common.service.CommonExportTaskService;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.common.model.CommonExportTask;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.io.File;
import java.util.Calendar;
import java.util.Date;

/**
 * CommonExportTask接口
 *
 * @author TangFD@HF
 * @since 2019-06-03
 */
@Slf4j
@RestController
@RequestMapping(value = "/exportTask")
@Api(value = "CommonExportTask接口", description = "CommonExportTask接口", tags = {"CommonExportTask接口"})
public class CommonExportTaskController {

    @Resource
    private CommonExportTaskService commonExportTaskService;
    @Value("${user.export.path:}")
    private String userExportPath;

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    @ApiOperation(value = "新增接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "condition", value = "业务查询条件", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "exportType", value = "导出类型", dataType = "String", paramType = "query")
    })
    public JsonResult save(@ParamHide CommonExportTask exportTask) {
        commonExportTaskService.save(exportTask);
        return new JsonResult(true, "添加成功");
    }

    @RequestMapping(value = "/getFinalExport", method = RequestMethod.GET)
    @ApiOperation(value = "得到最后一次导出的任务信息，当没有时，返回null")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "condition", value = "业务查询条件", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "exportType", value = "导出类型", dataType = "String", paramType = "query")
    })
    public JsonResult<CommonExportTask> getFinalExportTask(String exportType) {
        JsonResult<CommonExportTask> result = new JsonResult<>();
        CommonExportTask exportTask = commonExportTaskService.getFinalExportByOptUserId(ContextHandler.getUserId(), exportType);
        if (exportTask == null) {
            return result;
        }

        if (UcConstants.STATUS_FINISHED.equals(exportTask.getStatus())) {
            result.setData(exportTask);
            return result;
        }

        //如果超过一天未成功则标记为失败
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(exportTask.getStartTime());
        calendar.add(Calendar.HOUR_OF_DAY, 24);
        if (calendar.getTime().before(new Date())) {
            commonExportTaskService.updateStatusAndFileId(exportTask.getId(), UcConstants.STATUS_FAILED, null);
        }

        return result;
    }

    /**
     * 关闭导出提示
     *
     * @author yeWanQing
     * @since 2015年6月8日
     */
    @RequestMapping(value = "/closeExport/{id}", method = RequestMethod.DELETE)
    @ApiOperation(value = "关闭导出提示")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "id", paramType = "path", required = true)
    })
    public JsonResult closeExportTip(@PathVariable("id") String id) {
        JsonResult jsonResult = new JsonResult();
        try {
            CommonExportTask exportTask = commonExportTaskService.get(id);
            if (exportTask == null) {
                return jsonResult;
            }

            String filePath = userExportPath + File.separator + exportTask.getFileId() + UcConstants.XLSX;
            FileUtils.deleteQuietly(new File(filePath));
            commonExportTaskService.updateStatusAndFileId(id, UcConstants.STATUS_CLOSED, null);
            jsonResult.setSuccess(true);
        } catch (Exception e) {
            jsonResult.setSuccess(false);
            log.error("Close export task error!", e);
        }

        return jsonResult;
    }
}
