package com.purchase.uc.config;

import com.qgutech.qgyun.saas.client.component.RedisComponent;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;

import javax.annotation.Resource;

/**
 * @author niming
 * @since 2021/6/23 0023
 */
@Configuration
public class SaasConfig {

    @Resource
    private RedisTemplate<String, String> redisTemplate;

    @Bean
    public RedisComponent<String> redisComponent() {
        return new RedisComponent<>(redisTemplate);
    }
}
