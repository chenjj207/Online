package com.purchase.uc.model.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author jidonglin
 * @Description: udesk 信息
 * @date 2024/7/10  10:30
 */
@Data
public class UdeskInfoVO {
    @ApiModelProperty("用户id")
    private String userId;
    @ApiModelProperty("用户名")
    private String userName;
    @ApiModelProperty("手机号")
    private String mobile;

    @ApiModelProperty("随机数")
    String nonce;
    @ApiModelProperty("时间搓")
    String timestamp;
    @ApiModelProperty("客户ID")
    String web_token;
    @ApiModelProperty("加密签名")
    String signature;

}
