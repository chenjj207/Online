package com.purchase.uc.model.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 登录实体
 *
 * @since TangFD@HF 2019-06-04
 */
@Getter
@Setter
@ToString
public class Login {

    private String loginName;
    private String pwd;
    private String corpCode;
    private String securityCode;
    private boolean continueLogin;

}
