package com.purchase.uc.base;

/**
 * UC模块国际化
 */
public enum UcI18nConstants {
    /**
     * 登录相关
     */
    UC_CODE_NOT_MUCH("uc.login.code.error", "验证码错误"),
    UC_CORP_NOT_EXIST("uc.corp.not.exist", "公司不存在"),
    UC_CORP_EXPIRED("uc.corp.expired", "公司已过期"),
    UC_CORP_LIMIT_LOGIN_TIME("uc.corp.login.limitlogintime", "公司当前时间段不允许登录"),
    UC_CORP_CONCURRENT_TO_LIMIT("uc.corp.concurrent.toLimit", "公司当前并发数已达到上限"),
    UC_LOGIN_PWD_ERROR("uc.login.pwd.error", "登录名或密码错误"),
    UC_LOGIN_WX_SCAN_ERROR("uc.login.wx.scan.error", "企微扫码登录异常"),
    UC_USER_STATUS_ERROR("uc.login.status.error", "用户已被冻结，请联系管理员"),
    UC_LOGIN_SUCCESS("uc.login.success", "登录成功"),
    UC_OPT_SUCCESS("uc.opt.success", "操作成功"),
    UC_ADD_SUCCESS("uc.add.success", "新增成功"),
    UC_ADD_ERROR("uc.add.error", "新增错误"),
    UC_EDIT_SUCCESS("uc.edit.success", "编辑成功"),
    UC_CAN_NOT_EDIT_ADMIN("uc.can.not.edit.admin", "管理员不可编辑"),
    UC_DELETE_SUCCESS("uc.delete.error", "删除成功"),
    UC_DELETE_ERROR("uc.delete.success", "删除错误"),
    UC_NAME_DUPLICATE("uc.name.duplicate", "名称重复"),
    UC_USER_CODE_DUPLICATE("uc.user.code.duplicate", "工号重复"),
    UC_CODE_DUPLICATE("uc.code.duplicate", "编号重复"),
    UC_EMAIL_DUPLICATE("uc.email.duplicate", "邮箱重复"),
    UC_MOBILE_DUPLICATE("uc.mobile.duplicate", "手机号重复"),
    UC_LOGIN_NAME_DUPLICATE("uc.loginName.duplicate", "供应商手机号重复"),
    UC_MOBILE_EMPTY("uc.mobile.empty", "手机号不可为空"),
    UC_ID_CARD_DUPLICATE("uc.idCard.duplicate", "身份证号重复"),
    UC_HAS_ORG_CHIRD("uc.has.org.chird", "有子部门"),
    UC_HAS_ORG_USER("uc.has.org.user", "删除部门请先移除部门人员"),
    UC_CAN_NOT_DEL_SYS_ORG("uc.can.not.del.sys.org", "系统部门不可删除"),
    UC_STATUS_DISABLED("uc.status.disabled", "已冻结"),
    UC_ENABLED_SUCCESS("uc.enabled.success", "启用成功"),
    UC_DISABLED_SUCCESS("uc.disabled.success", "停用成功"),
    UC_ENABLED_ERROR("uc.enabled.error", "启用失败"),
    UC_DISABLED_ERROR("uc.disabled.error", "停用失败"),
    UC_HAS_POS_USER("uc.has.pos.user", "岗位有人员"),
    UC_HAS_ROLE_USER("uc.has.role.user", "角色有人员"),
    UC_HAS_CHILD("uc.has.pos.user", "包含子类"),
    UC_SHORT_TIME_SMS("uc.short.time.sms", "短时间内不允许重复发送"),
    UC_ENABLED_NOT_DELETED("uc.enabled.not.deleted", "启用状态不可删除"),
    UC_GROUP_NOT_EXIST("UC.GROUP.NOT.EXIST", "群组不存在"),
    LOGIN_ERROR_USER_NOT_EXIST("LOGIN.ERROR_USER_NOT_EXIST", "用户不存在"),
    LOGIN_SUCCESS("LOGIN.SUCCESS", "登录成功"),
    LOGIN_CODE_ERROR("LOGIN.CODE.ERROR", "验证码错误"),
    FORGET_PASSWORD_ERROR("forget.password.error", "忘记密码错误"),
    UC_BEEN_USED("uc.been.used", "类别被引用");

    private String name;
    private String code;

    UcI18nConstants(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }
}
