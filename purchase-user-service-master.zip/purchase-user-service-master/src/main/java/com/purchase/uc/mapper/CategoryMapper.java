package com.purchase.uc.mapper;

import com.qgutech.qgyun.dev.common.mapper.CommonCategoryMapper;
import com.purchase.uc.model.Category;
import org.apache.ibatis.annotations.Mapper;

/**
 * UC通用类别管理 Mapper
 *
 * @version 1.0
 * @since 2019年06月13日14:21:59
 */
@Mapper
public interface CategoryMapper extends CommonCategoryMapper<Category> {

}
