package com.purchase.uc.service;

import com.purchase.uc.model.UseScope;
import com.qgutech.qgyun.dev.common.service.CommonRelService;
import org.springframework.stereotype.Service;

/**
 * OpenScopeService 服务提供类
 *
 * @author auto
 * @version 1.0
 * @since 2019-06-13 14:18:21
 */
@Service
public class UseScopeService extends CommonRelService<UseScope> {

}
