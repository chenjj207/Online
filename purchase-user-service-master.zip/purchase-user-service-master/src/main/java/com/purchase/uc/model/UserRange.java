package com.purchase.uc.model;

import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.List;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "UserRange", description = "")
@Table(name = "t_uc_user_range")
public class UserRange extends BaseCorpModel {

    public static final String USER_ID = "userId";
    public static final String REFER_ID = "referId";
    public static final String REFER_TYPE = "referType";

    /**
     * 用户id
     */
    @ApiModelProperty(value = "用户id")
    private String userId;

    /**
     * 关联类型：ORG POSITION GROUP
     */
    @ApiModelProperty(value = "关联类型：ORG POSITION GROUP")
    private String referType;

    /**
     * 关联类型id
     */
    @ApiModelProperty(value = "关联类型id")
    private String referId;

    /**
     * 关联类型为POSITION时存放对应orgId，其他类型为NULL
     */
    @ApiModelProperty(value = "关联类型为POSITION时存放对应orgId，其他类型为NULL")
    private String rangeOrgId;

    @Transient
    @ApiModelProperty(value = "查询条件，关联类型")
    private List<String> referTypes;

    @Transient
    @ApiModelProperty(value = "查询的部门Id列表")
    private List<String> orgIds;

    @Transient
    @ApiModelProperty(value = "批量保存时，用户Id列表")
    private List<String> userIds;

    @Transient
    @ApiModelProperty(value = "查询关键字")
    private String keyword;

    @Transient
    @ApiModelProperty(value = "查询结果人员信息字段")
    private User user;

    @Transient
    @ApiModelProperty(value = "管辖范围名称")
    private String referName;

    @Transient
    @ApiModelProperty(value = "管辖部门数量")
    private int orgCnt;

    public UserRange() {
    }

    public UserRange(String userId, String referId, String referType) {
        this.userId = userId;
        this.referId = referId;
        this.referType = referType;
        this.setCorpCode(ContextHandler.getCorpCode());
    }

    @Transient
    private String orgName;
    @Transient
    private String namePath;
    @Transient
    private String positName;
    @Transient
    private String groupName;
}
