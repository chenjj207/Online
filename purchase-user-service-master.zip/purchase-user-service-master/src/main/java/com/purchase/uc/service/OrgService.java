package com.purchase.uc.service;

import com.alibaba.fastjson.JSON;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.qgutech.qgyun.dev.common.utils.CommonUtils;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcException;
import com.purchase.uc.base.UcI18nConstants;
import com.purchase.uc.mapper.OrgMapper;
import com.purchase.uc.model.Org;
import com.purchase.uc.model.User;
import com.purchase.uc.utils.UcRedisKeys;
import com.purchase.uc.utils.UcUtil;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.database.mybatis.model.BaseTreeNode;
import com.qgutech.qgyun.framework.database.mybatis.model.TreeNode;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.weekend.WeekendSqls;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.purchase.uc.model.Org.*;
import static com.purchase.uc.model.Org.SHOW_ORDER;
import static com.qgutech.qgyun.framework.database.model.BaseCorpModel.CORP_CODE;
import static com.qgutech.qgyun.framework.database.model.BaseModel.ID;

/**
 * 部门相关服务接口
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
public class OrgService extends BaseServiceImpl<Org> {

    @Resource
    private OrgMapper orgMapper;
    @Resource
    private RedisTemplate<String, String> redisTemplate;
    @Resource
    private UserRangeService userRangeService;
    @Resource
    private UserService userService;

    /**
     * 该方法用于获取公司下
     *
     * @return 公司所有组织
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<Org> listAll() {
        Example example = new Example(Org.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        example.orderBy(SHOW_ORDER);
        return orgMapper.selectByExample(example);
    }

    /**
     * 该方法用于根据部门ID获取对应对象的map
     *
     * @param orgIds 部门ID集合
     * @return key:orgId  value:org对象
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, Org> getOrgMap(Collection<String> orgIds) {
        if (CollectionUtils.isEmpty(orgIds)) {
            return new HashMap<>(0);
        }

        List<Org> orgList = listByIds(new ArrayList<>(orgIds));
        if (CollectionUtils.isEmpty(orgList)) {
            return new HashMap<>(0);
        }

        return orgList.stream().collect(Collectors.toMap(Org::getId, v -> v));
    }

    /**
     * 该方法用于根据部门ID获取对应名称map
     *
     * @param orgIds 部门ID集合
     * @return key:orgId  value:org名称
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, String> getOrgIdAndNameMap(Collection<String> orgIds) {
        Map<String, Org> orgMap = getOrgMap(orgIds);
        if (null == orgMap) {
            return new HashMap<>();
        }

        Map<String, String> orgIdAndNameMap = new HashMap<>(orgMap.size());
        for (Org value : orgMap.values()) {
            orgIdAndNameMap.put(value.getId(), value.getName());
        }

        return orgIdAndNameMap;
    }

    /**
     * 新增部门
     *
     * @param org 树对象
     * @return 新增成功的主键
     */
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public JsonResult<String> saveOrg(Org org) {
        JsonResult<String> vaildResult = validOrg(org);
        if (vaildResult != null) {
            return vaildResult;
        }

        if (StringUtils.isBlank(org.getId())) {
            String id = IDUtils.getUUID19();
            org.setId(id);
        }

        fillOrg(org, true);
        String orgId = super.insert(org);
        putOrgTreeToRedis();

        // 插入一条用户管辖范围权限
        ComponentCondition condition = new ComponentCondition();
        condition.setFunId(ContextHandler.getUserId());
        condition.setRelType(UcConstants.RANG_TYPE_ORG);
        condition.setRelIds(Collections.singletonList(orgId));
        userRangeService.addOrgs(condition);
        return new JsonResult<>(true, UcI18nConstants.UC_ADD_SUCCESS.getName(), orgId);
    }

    private JsonResult validOrg(Org org) {
        if (org == null || StringUtils.isEmpty(org.getName()) || StringUtils.isEmpty(org.getpId())) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "Org or name or pId is null when insert!");
        }

        if (existByProperty(NAME, org.getName(), org.getpId(), org.getId())) {
            return new JsonResult(false, UcI18nConstants.UC_NAME_DUPLICATE.getName());
        }

        if (StringUtils.isNotBlank(org.getCode()) && existByPropertyOverParent(CODE, org.getCode(), org.getId())) {
            return new JsonResult(false, UcI18nConstants.UC_CODE_DUPLICATE.getName());
        }

        return null;
    }

    /**
     * 该方法用于根据属性判断属性是否存在
     *
     * @param property 属性名
     * @param value    属性值
     * @return 是否存在
     */
    private boolean existByPropertyOverParent(String property, String value, String orgId) {
        Example example = new Example(entityClass);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(property, value)
                .andNotEqualTo(ID, orgId)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());

        return orgMapper.selectCountByExample(example) > 0;
    }

    /**
     * 该方法用于根据属性判断属性是否存在
     *
     * @param property 属性名
     * @param value    属性值
     * @return 是否存在
     */
    private boolean existByProperty(String property, String value, String pId) {
        Example example = new Example(Org.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(property, value)
                .andEqualTo(P_ID, pId)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());

        return orgMapper.selectCountByExample(example) > 0;
    }

    /**
     * 该方法用于根据属性判断属性是否存在
     *
     * @param property 属性名
     * @param value    属性值
     * @return 是否存在
     */
    private boolean existByProperty(String property, String value, String pId, String orgId) {
        Example example = new Example(Org.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(property, value)
                .andEqualTo(P_ID, pId)
                .andNotEqualTo(ID, orgId)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());

        return orgMapper.selectCountByExample(example) > 0;
    }

    /**
     * 编辑树
     *
     * @param org 树对象
     */
    public JsonResult updateOrg(Org org) {
        JsonResult jsonResult = validOrg(org);
        if (null != jsonResult) {
            return jsonResult;
        }

        if (StringUtils.isBlank(org.getId())) {
            throw new IllegalArgumentException("OrgId is null when update!");
        }

        Org dbOrg = get(org.getId());
        if (dbOrg == null) {
            throw new IllegalArgumentException("Org [id=" + org.getId() + "] is null when update!");
        }

        boolean changeShowOrder = true;
        if (dbOrg.getpId().equals(org.getpId())) {
            changeShowOrder = false;
        }

        fillOrg(org, changeShowOrder);
        dbOrg.setCode(org.getCode());
        dbOrg.setName(org.getName());
        if (!dbOrg.getpId().equals(org.getpId())) {
            dbOrg.setpId(org.getpId());
            dbOrg.setShowOrder(org.getShowOrder());
            dbOrg.setIdPath(org.getIdPath());
            dbOrg.setNamePath(org.getNamePath());
        }

        orgMapper.updateByPrimaryKey(dbOrg);
        putOrgTreeToRedis();
        return new JsonResult<>(true, UcI18nConstants.UC_EDIT_SUCCESS.getName());
    }

    private void fillOrg(Org org, boolean changeShowOrder) {
        String parentId = org.getpId();
        String POINT = ".";
        if ("*".equals(parentId) || null == parentId) {
            org.setpId("*");
            org.setIdPath(org.getId());
            org.setNamePath(org.getName());
        } else {
            Org parentOrg = get(parentId);
            if (parentOrg != null) {
                org.setIdPath(parentOrg.getIdPath() + POINT + org.getId());
                org.setNamePath(parentOrg.getNamePath() + POINT + org.getName());
            }
        }

        if (!changeShowOrder) {
            return;
        }

        Example example = new Example(Org.class);
        Example.Criteria criteria = example.selectProperties(SHOW_ORDER).createCriteria();
        criteria.andEqualTo(P_ID, parentId)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        example.setOrderByClause("show_order DESC LIMIT 1");
        Org dbOrg = orgMapper.selectOneByExample(example);
        float needShowOrder = 1;
        if (null == dbOrg) {
            org.setShowOrder(needShowOrder);
            return;
        }

        Float showOrder = dbOrg.getShowOrder();
        if (null != showOrder) {
            needShowOrder = showOrder + 1;
        }

        org.setShowOrder(needShowOrder);
    }

    /**
     * 部门上下移动
     *
     * @param orgId    树ID
     * @param moveType UP 上移 DOWN 下移
     */
    public void move(String orgId, String moveType) {
        if (StringUtils.isEmpty(orgId) || StringUtils.isEmpty(moveType)) {
            throw new IllegalArgumentException("OrgId or moveType is empty when move!");
        }

        Org org = get(orgId);
        if (org == null) {
            return;
        }

        String parentId = org.getpId();
        Float tempShowOrder = org.getShowOrder();
        Example example = new Example(Org.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(P_ID, parentId)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        if ("UP".equals(moveType)) {
            criteria.andLessThan(SHOW_ORDER, tempShowOrder);
            example.setOrderByClause("show_order DESC LIMIT 1");
        } else {
            criteria.andGreaterThan(SHOW_ORDER, tempShowOrder);
            example.setOrderByClause("show_order ASC LIMIT 1");
        }

        Org dbOrg = orgMapper.selectOneByExample(example);
        if (dbOrg == null) {
            return;
        }

        org.setShowOrder(dbOrg.getShowOrder());
        dbOrg.setShowOrder(tempShowOrder);

        List<Org> orgList = new ArrayList<>();
        orgList.add(org);
        orgList.add(dbOrg);
        batchUpdate(orgList);
        putOrgTreeToRedis();
    }

    /**
     * 该方法用于查询所有父节点为@param 的节点数量
     *
     * @param orgId 树节点ID
     * @return 数量
     */
    public int countByParentId(String orgId) {
        if (StringUtils.isBlank(orgId)) {
            return 0;
        }

        Example example = new Example(Org.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(P_ID, orgId)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        example.setCountProperty(ID);

        return orgMapper.selectCountByExample(example);
    }

    /**
     * 根据父部门Id列表，获取所有的子部门Id列表
     *
     * @param orgIds      父部门Id列表
     * @param includeSelf 是否包含父部门本身
     * @return 子部门Id列表
     */
    public List<String> getChildIds(Collection<String> orgIds, boolean includeSelf) {
        if (CollectionUtils.isEmpty(orgIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "orgIds not be empty!");
        }

        Map<String, Boolean> orgIdMap = new HashMap<>(orgIds.size());
        orgIds.forEach(id -> orgIdMap.put(id, true));
        TreeNode orgTree = getOrgTree();
        List<String> childIds = new ArrayList<>();
        boolean isChildNode = BooleanUtils.isTrue(orgIdMap.get(orgTree.getId()));
        if (isChildNode && includeSelf) {
            childIds.add(orgTree.getId());
        }

        getChildIds(orgTree.getChild(), includeSelf, isChildNode, orgIdMap, childIds);
        return childIds;
    }

    /**
     * 根据父部门Id列表，获取所有的子部门IdMAP
     *
     * @param orgIds      父部门Id列表
     * @param includeSelf 是否包含父部门本身
     * @return MAP key:部门ID value:子部门ID
     */
    public Map<String, List<String>> getChildIdsMap(Collection<String> orgIds, boolean includeSelf) {
        if (CollectionUtils.isEmpty(orgIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "orgIds not be empty!");
        }

        Map<String, List<String>> map = new HashMap<>(orgIds.size());
        for (String orgId : orgIds) {
            map.put(orgId, getChildIds(CommonUtils.singletonList(orgId), true));
        }

        return map;
    }

    private void getChildIds(List<TreeNode> childNode, boolean includeSelf, boolean isChildNode,
                             Map<String, Boolean> orgIdMap, List<String> childIds) {
        if (CollectionUtils.isEmpty(childNode)) {
            return;
        }

        for (TreeNode node : childNode) {
            if (isChildNode) {
                childIds.add(node.getId());
                getChildIds(node.getChild(), includeSelf, true, null, childIds);
                continue;
            }

            boolean childFlag = false;
            if (BooleanUtils.isTrue(orgIdMap.get(node.getId()))) {
                childFlag = true;
                if (includeSelf) {
                    childIds.add(node.getId());
                }
            }

            getChildIds(node.getChild(), includeSelf, childFlag, orgIdMap, childIds);
        }
    }


    /**
     * 根据条件获取所有权限集合
     *
     * @return 所有符合条件的权限
     */
    public TreeNode getOrgTreeFromCache() {
        ValueOperations<String, String> forValue = redisTemplate.opsForValue();
        String orgKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.ORG_TREE;
        String value = forValue.get(orgKey);
        if (StringUtils.isBlank(value)) {
            return null;
        }

        return JSON.parseObject(value, TreeNode.class);
    }

    /**
     * 根据条件获取所有权限集合
     *
     * @return 所有符合条件的权限
     */
    public TreeNode getOrgTree() {
        TreeNode orgTree = getOrgTreeFromCache();
        if (orgTree != null) {
            return orgTree;
        }

        List<Org> orgList = listAll();
        TreeNode rootNode = UcUtil.getTreeFromList(orgList, getRootNode());
        ValueOperations<String, String> forValue = redisTemplate.opsForValue();
        String orgKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.ORG_TREE;
        forValue.set(orgKey, JSON.toJSONString(rootNode));
        return rootNode;
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Org getRootOrg() {
        Example example = new Example(Org.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        criteria.andEqualTo(P_ID, "*");

        return orgMapper.selectOneByExample(example);
    }

    private TreeNode getRootNode() {
        Org org = getRootOrg();
        if (null == org) {
            return null;
        }

        return new TreeNode(org.getId(), org.getpId(), org.getName(), null, true);
    }

    /**
     * 根据用户Id获取其有权限的部门树
     *
     * @param userId 用户Id
     * @return 有权限的部门树
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public TreeNode getAuthTreeByUserId(String userId) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        TreeNode orgTree = getOrgTree();
        if (ContextHandler.isSuperAdmin()) {
            return orgTree;
        }

        List<String> orgIds = userRangeService.getReferIdsByUserId(userId, UcConstants.RANG_TYPE_ORG);
        if (CollectionUtils.isEmpty(orgIds)) {
            orgTree.setChild(null);
            orgTree.setManage(false);
            orgTree.setId("");
            return orgTree;
        }

        Map<String, Boolean> orgIdMap = new HashMap<>(orgIds.size());
        orgIds.forEach(id -> orgIdMap.put(id, true));
        if (BooleanUtils.isTrue(orgIdMap.get(orgTree.getId()))) {
            return orgTree;
        }

        return reBuildOrgTree(orgTree, orgIdMap);
    }

    /**
     * 根据有权限的部门Id,重建部门树，如果有权限的是子部门，父部门没有权限，则把子部门直接放在根部门下
     *
     * @param rootTree 完整部门树
     * @param orgIdMap 有权限的部门Id映射
     * @return 有权限的部门树
     */
    private TreeNode reBuildOrgTree(TreeNode rootTree, Map<String, Boolean> orgIdMap) {
        List<TreeNode> authNodes = new ArrayList<>();
        dealAuthNodes(rootTree.getChild(), orgIdMap, authNodes);
        TreeNode newTree = new TreeNode(rootTree.getId(), rootTree.getPId(), rootTree.getName());
        if (authNodes.size() == 0) {
            return newTree;
        }

        Map<String, TreeNode> idAndNodeMap = getOrgIdAndNodeMap(authNodes, newTree);
        for (TreeNode node : authNodes) {
            TreeNode parentNode = idAndNodeMap.get(node.getPId());
            if (parentNode == null) {
                node.setPId(newTree.getPId());
                parentNode = newTree;
            } else if (!parentNode.getId().equals(newTree.getId())) {
                continue;
            }

            List<TreeNode> children = parentNode.getChild();
            if (children == null) {
                children = new ArrayList<>();
                parentNode.setChild(children);
            }

            children.add(node);
        }

        return newTree;
    }

    private Map<String, TreeNode> getOrgIdAndNodeMap(List<TreeNode> nodes, TreeNode rootNode) {
        Map<String, TreeNode> orgAndNodeMap = new HashMap<>(nodes.size() + 1);
        orgAndNodeMap.put(rootNode.getId(), rootNode);
        nodes.forEach(node -> orgAndNodeMap.put(node.getId(), node));

        return orgAndNodeMap;
    }

    /**
     * 根据有权限的部门Id列表，获取所有有权限的部门树节点，包含子节点
     */
    private void dealAuthNodes(List<TreeNode> nodes, Map<String, Boolean> orgIdMap, List<TreeNode> authNodes) {
        if (CollectionUtils.isEmpty(nodes)) {
            return;
        }

        for (TreeNode child : nodes) {
            if (BooleanUtils.isTrue(orgIdMap.get(child.getId()))) {
                authNodes.add(child);
                continue;
            }

            dealAuthNodes(child.getChild(), orgIdMap, authNodes);
        }
    }

    /**
     * 根据部门Id列表，判断是否包含根部门
     *
     * @param orgIds 部门Id列表
     * @param rootId 根部门
     * @return 是否包含根部门
     */
    private boolean hasRootOrg(List<String> orgIds, String rootId) {
        return orgIds.stream().anyMatch(rootId::equals);
    }

    @Transactional(rollbackFor = Exception.class)
    public JsonResult delOrg(String orgId) {
        int count = countByParentId(orgId);
        if (count > 0) {
            return new JsonResult<>(false, UcI18nConstants.UC_HAS_ORG_CHIRD.getName());
        }

        boolean exist = userService.existByProperty(User.ORG_ID, orgId);
        if (exist) {
            return new JsonResult<>(false, UcI18nConstants.UC_HAS_ORG_USER.getName());
        }

        String orgCode = getPropertyValById(orgId, CODE, String.class);
        if (UcConstants.OUTER_USER_ORG_CODE.equals(orgCode)) {
            return new JsonResult<>(false, UcI18nConstants.UC_CAN_NOT_DEL_SYS_ORG.getName());
        }

        super.delete(orgId);
        putOrgTreeToRedis();
        return new JsonResult<>(true, UcI18nConstants.UC_DELETE_SUCCESS.getName());
    }

    /**
     * 该方法用于刷新部门树缓存
     */
    public void putOrgTreeToRedis() {
        ValueOperations<String, String> forValue = redisTemplate.opsForValue();
        String orgKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.ORG_TREE;
        forValue.getOperations().delete(orgKey);
        getOrgTree();
    }

    /**
     * 根据部门Id，判断当前人是否有管理权限
     *
     * @param orgId 部门Id
     * @return 是否有管理权限，true：是，false：否
     */
    public boolean checkOrgHasAuth(String orgId) {
        if (StringUtils.isEmpty(orgId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "orgId not be empty!");
        }

        String userId = ContextHandler.getUserId();
        if (ContextHandler.isSuperAdmin()) {
            return true;
        }

        TreeNode treeNode = getAuthTreeByUserId(userId);
        return orgId.equals(treeNode.getId()) || checkOrgHasAuth(treeNode.getChild(), orgId);

    }

    private boolean checkOrgHasAuth(List<TreeNode> child, String orgId) {
        if (CollectionUtils.isEmpty(child)) {
            return false;
        }

        for (TreeNode node : child) {
            if (orgId.equals(node.getId()) || checkOrgHasAuth(node.getChild(), orgId)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 根据父部门Id列表，获取所有有权限的子部门Id列表
     *
     * @param orgIds      父部门Id列表
     * @param includeSelf 是否包含父部门本身
     * @return 有权限的子部门Id列表
     */
    public List<String> getAuthChildIds(Collection<String> orgIds, boolean includeSelf) {
        if (CollectionUtils.isEmpty(orgIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "orgIds not be empty!");
        }

        if (ContextHandler.isSuperAdmin()) {
            return getChildIds(orgIds, includeSelf);
        }

        Map<String, Boolean> orgIdMap = new HashMap<>(orgIds.size());
        orgIds.forEach(id -> orgIdMap.put(id, true));
        TreeNode orgTree = getAuthTreeByUserId(ContextHandler.getUserId());
        List<String> childIds = new ArrayList<>();
        boolean isChildNode = BooleanUtils.isTrue(orgIdMap.get(orgTree.getId()));
        if (isChildNode && includeSelf) {
            childIds.add(orgTree.getId());
        }

        getChildIds(orgTree.getChild(), includeSelf, isChildNode, orgIdMap, childIds);
        return childIds;
    }

    /**
     * 根据部门路径全称，新增部门
     *
     * @param orgNamePath 部门路径全称
     * @param orgCode     部门编号
     * @return 最后一级部门Id
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String addOrg(String orgNamePath, String orgCode) {
        if (StringUtils.isEmpty(orgNamePath)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "org name path not be empty!");
        }

        Map<String, String> namePathAndIdMap = getNamePathAndIdMap();
        if (MapUtils.isEmpty(namePathAndIdMap)) {
            throw new UcException(UcErrorCode.ORGANIZE_ERROR_ADD_ERROR);
        }

        String[] names = orgNamePath.split("\\.");
        int length = names.length;
        String orgName = "", parentId = null;
        String corpCode = ContextHandler.getCorpCode();
        for (int i = 0; i < length; i++) {
            String name = names[i];
            orgName += StringUtils.isEmpty(orgName) ? name : ("." + name);
            String pId = namePathAndIdMap.get(orgName);
            if (StringUtils.isNotEmpty(pId)) {
                parentId = pId;
                continue;
            }

            Org org = new Org();
            org.setCorpCode(corpCode);
            org.setpId(parentId);
            org.setName(name);
            if (i == length - 1) {
                org.setCode(orgCode);
            }

            JsonResult<String> result = saveOrg(org);
            parentId = result.getData();
        }

        return parentId;
    }

    private Map<String, String> getNamePathAndIdMap() {
        TreeNode orgTree = getOrgTree();
        Map<String, String> namePathAndIdMap = new HashMap<>();
        namePathAndIdMap.put(orgTree.getName(), orgTree.getId());
        iterateOrgTree(orgTree.getChild(), orgTree.getName(), namePathAndIdMap);
        return namePathAndIdMap;
    }

    private void iterateOrgTree(List<TreeNode> childNodes, String parentNamePath,
                                Map<String, String> namePathAndIdMap) {
        if (CollectionUtils.isEmpty(childNodes)) {
            return;
        }

        for (TreeNode childNode : childNodes) {
            String namePath = (StringUtils.isEmpty(parentNamePath) ? "" : (parentNamePath + ".")) + childNode.getName();
            String id = childNode.getId();
            namePathAndIdMap.put(namePath, id);
            iterateOrgTree(childNode.getChild(), namePath, namePathAndIdMap);
        }
    }

    /**
     * 判断部门是否是根部门
     *
     * @param orgId 部门ID
     * @return 是否根部门
     */
    public boolean isRootOrg(String orgId) {
        if (StringUtils.isEmpty(orgId)) {
            throw new IllegalArgumentException("OrgId is empty when isRootOrg!");
        }

        Org org = get(orgId);
        if (org == null) {
            return false;
        }

        return "*".equals(org.getpId());
    }

    /**
     * 获取当前公司的外部联系人部门Id
     *
     * @return 外部联系人部门Id
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public String getOuterOrgId() {
        Example example = new Example(Org.class);
        example.selectProperties(Org.ID)
                .createCriteria()
                .andEqualTo(Org.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(Org.CODE, UcConstants.OUTER_USER_ORG_CODE);

        Org org = orgMapper.selectOneByExample(example);
        return org == null ? null : org.getId();
    }

    /**
     * 根据子部门Id，获取所有的父部门Id列表
     *
     * @param orgId       子部门Id列表
     * @param includeSelf 是否包含子部门本身
     * @return 父部门Id列表
     */
    public List<String> getParentIds(String orgId, boolean includeSelf) {
        TreeNode orgTree = getOrgTreeFromCache();
        if (orgTree == null) {
            return new ArrayList<>(0);
        }

        List<String> parentOrgIds = new ArrayList<>();
        filterParentIds(CommonUtils.singletonList(orgTree), orgId, parentOrgIds, includeSelf);
        return parentOrgIds;
    }

    private boolean filterParentIds(List<TreeNode> treeNodes, String orgId,
                                    List<String> parentOrgIds, boolean includeSelf) {
        if (CollectionUtils.isEmpty(treeNodes)) {
            return false;
        }

        for (TreeNode treeNode : treeNodes) {
            if (!orgId.equals(treeNode.getId())) {
                boolean invalid = filterParentIds(treeNode.getChild(), orgId, parentOrgIds, includeSelf);
                if (invalid) {
                    parentOrgIds.add(treeNode.getId());
                    return true;
                }
                continue;
            }

            if (includeSelf) {
                parentOrgIds.add(orgId);
            }
            return true;
        }

        return false;
    }

    /**
     * 根据部门Id，从缓存中获取部门名称
     *
     * @param orgId 部门Id
     * @return 部门名称
     */
    public String getOrgNameFromCache(String orgId) {
        if (StringUtils.isEmpty(orgId)) {
            return null;
        }

        TreeNode treeNode = getOrgTreeFromCache();
        return getPropertyFromTree(CommonUtils.singletonList(treeNode), orgId, BaseTreeNode::getName);
    }

    /**
     * 从部门树中获取每一个节点的相关属性
     *
     * @param child    部门树
     * @param orgId    指定的节点Id
     * @param function 相关属性
     * @return 属性
     */
    private String getPropertyFromTree(List<TreeNode> child, String orgId, Function<TreeNode, String> function) {
        if (CollectionUtils.isEmpty(child)) {
            return null;
        }

        for (TreeNode treeNode : child) {
            if (orgId.equals(treeNode.getId())) {
                return function.apply(treeNode);
            }

            String property = getPropertyFromTree(treeNode.getChild(), orgId, function);
            if (property != null) {
                return property;
            }
        }

        return null;
    }

    /**
     * 根据部门Code查询所有一级子部门
     *
     * @param code
     * @return
     */
    public List<Org> listOneLevelChild(String code) {
        Example example = new Example(Org.class);
        example.selectProperties(Org.ID)
                .createCriteria()
                .andEqualTo(Org.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(Org.CODE, code);
        Org org = orgMapper.selectOneByExample(example);

        Example exampleChild = new Example(Org.class);
        exampleChild.selectProperties(Org.ID, Org.NAME)
                .createCriteria()
                .andEqualTo(Org.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(Org.P_ID, org.getId());

        List<Org> orgs = orgMapper.selectByExample(exampleChild);
        return orgs;
    }

    public List<String> listOrgIdInKeywords(Set<String> keywords) {
        List<Org> orgs = orgMapper.selectByExample(Example.builder(Org.class)
                .select(Org.ID, Org.NAME)
                .where(WeekendSqls.<Org>custom().andIn(Org::getName, keywords))
                .build());
        if (CollectionUtils.isEmpty(orgs)) {
            return Collections.emptyList();
        }

        Set<String> check = new HashSet<>();
        return orgs.stream().filter(org -> check.add(org.getName())).map(Org::getId).collect(Collectors.toList());
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String init(String corpName) {
        String id = initRootOrg(corpName);
        initOuterOrg(corpName, id);
        putOrgTreeToRedis();
        return id;
    }

    private void initOuterOrg(String corpName, String id) {
        String outerOrgId = getOuterOrgId();
        if (StringUtils.isNotEmpty(outerOrgId)) {
            return;
        }

        String orgName = "会员";
        String namePath = corpName + "." + orgName;
        String outId = IDUtils.getUUID19();
        String idPath = id + "." + outId;
        insertOrg(outId, orgName, namePath, id, idPath, UcConstants.OUTER_USER_ORG_CODE);
    }

    private String initRootOrg(String corpName) {
        Org org = getRootOrg();
        if (org != null) {
            return org.getId();
        }

        String id = IDUtils.getUUID19();
        insertOrg(id, corpName, corpName, "*", null, ContextHandler.getCorpCode());
        return id;
    }

    private void insertOrg(String id, String name, String namePath, String parentId, String idPath, String code) {
        Org org = new Org();
        org.setId(id);
        org.setpId(parentId);
        org.setName(name);
        org.setNamePath(namePath);
        org.setShowOrder(1F);
        org.setIdPath(StringUtils.isEmpty(idPath) ? id : idPath);
        org.setStatus("ENABLED");
        org.setCorpCode(ContextHandler.getCorpCode());
        org.setCode(code);
        LocalDateTime now = LocalDateTime.now();
        org.setCreatedAt(now);
        String userId = ContextHandler.getUserId();
        org.setCreatedBy(userId);
        org.setUpdatedAt(now);
        org.setUpdatedBy(userId);
        insert(org);
    }
}
