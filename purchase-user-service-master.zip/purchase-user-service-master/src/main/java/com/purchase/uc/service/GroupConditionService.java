package com.purchase.uc.service;

import com.purchase.uc.model.GroupCondition;
import com.purchase.uc.mapper.GroupConditionMapper;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.*;

import static com.qgutech.qgyun.framework.database.model.BaseCorpModel.CORP_CODE;
import static com.qgutech.qgyun.framework.database.model.BaseModel.ID;

/**
 * 群组条件服务接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
public class GroupConditionService extends BaseServiceImpl<GroupCondition> {

    @Resource
    private GroupConditionMapper groupConditionMapper;

    public List<GroupCondition> listAll() {
        return groupConditionMapper.selectAll();
    }

    /**
     * 该方法用于根据群组ID获取群组对应条件集合
     *
     * @param groupId 群组ID
     * @return 条件集合
     */
    public List<GroupCondition> listByGroupId(String groupId) {
        if (StringUtils.isBlank(groupId)) {
            throw new IllegalArgumentException("GroupId is blank when listByGroupId!");
        }

        Map<String, List<GroupCondition>> conditionMap = getConditionMap(Collections.singletonList(groupId));

        return conditionMap.get(groupId);
    }

    /**
     * 该方法用于根据群组ID集合获取群组对应条件集合Map
     *
     * @param groupIds 群组ID
     * @return 条件集合 key:群组ID value:条件集合
     */
    public Map<String, List<GroupCondition>> getConditionMap(List<String> groupIds) {
        if (CollectionUtils.isEmpty(groupIds)) {
            throw new IllegalArgumentException("GroupIds is empty when getConditionMap!");
        }

        Example example = new Example(GroupCondition.class);
        Example.Criteria criteria = example.selectProperties(ID, GroupCondition.GROUP_ID, GroupCondition.CONTEXT, GroupCondition.SHOW_ORDER).createCriteria();
        criteria.andIn(GroupCondition.GROUP_ID, groupIds)
                .andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        //example.setCountProperty(ID);
        example.setOrderByClause("show_order ASC");

        List<GroupCondition> conditions = groupConditionMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(conditions)) {
            return new HashMap<>(0);
        }

        Map<String, List<GroupCondition>> conditionMap = new HashMap<>(groupIds.size());
        for (GroupCondition condition : conditions) {
            List<GroupCondition> list = conditionMap.get(condition.getGroupId());
            if (CollectionUtils.isEmpty(list)) {
                list = new ArrayList<>();
            }

            list.add(condition);
            conditionMap.put(condition.getGroupId(), list);
        }

        return conditionMap;
    }

    /**
     * 该方法用于根据群组ID删除对应条件
     *
     * @param groupId 群组ID
     */
    public void deleteByGroupId(String groupId) {
        if (StringUtils.isEmpty(groupId)) {
            throw new IllegalArgumentException("GroupId is empty when deleteByGroupId");
        }

        Example example = new Example(GroupCondition.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(GroupCondition.GROUP_ID, groupId);
        groupConditionMapper.deleteByExample(example);
    }
}
