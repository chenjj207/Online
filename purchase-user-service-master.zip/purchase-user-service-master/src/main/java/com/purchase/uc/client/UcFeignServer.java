package com.purchase.uc.client;

import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcException;
import com.purchase.uc.model.*;
import com.purchase.uc.model.vo.UserCache;
import com.purchase.uc.model.vo.UserParam;
import com.purchase.uc.service.*;
import com.qgutech.qgyun.dev.client.cs.CsFeignClient;
import com.qgutech.qgyun.dev.client.cs.model.CorpAppModel;
import com.qgutech.qgyun.dev.common.model.CommonRel;
import com.qgutech.qgyun.dev.common.service.CommonInitService;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * UC对外提供服务接口
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年06月06日10:34:03
 */
@RestController
@RequestMapping(value = "/ucFeign")
@Api(value = "UC对外提供服务接口", tags = {"UC对外提供服务接口"}, hidden = true)
public class UcFeignServer {

    @Resource
    private UserService userService;
    @Resource
    private OrgService orgService;
    @Resource
    private GroupService groupService;
    @Resource
    private PositionService positionService;
    @Resource
    private AuthService authService;
    @Resource
    private UserRoleRelService userRoleRelService;
    @Resource
    private RoleService roleService;
    @Resource
    private CommonInitService initService;
    @Resource
    private CsFeignClient csFeignClient;
    @Resource
    private SupplierService supplierService;

    @GetMapping("/isAdminAccount/{userId}")
    @ApiOperation(value = "根据用户Id检查是否有admin账号")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userId", value = "用户Id", required = true, dataType = "String", paramType =
                    "query")
    })
    public JsonResult<Boolean> isAdminAccount(@PathVariable("userId") String userId) {
        return new JsonResult<>(true, null, userService.isAdminAccount(userId));
    }

    @GetMapping("/hasSuperAdminRole/{userId}")
    @ApiOperation(value = "根据用户Id检查是否有系统管理员角色")
    public JsonResult<Boolean> hasSuperAdminRole(@PathVariable("userId") String userId) {
        if (userService.isAdminAccount(userId)) {
            return new JsonResult<>(true, null, true);
        }

        return new JsonResult<>(true, null, userRoleRelService.hasSuperAdminRole(userId));
    }

    @RequestMapping(value = "/org/getOrgMap", method = RequestMethod.POST)
    @ApiOperation(value = "部门ID集合获取对应map")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "orgIds", value = "orgIds", required = true, paramType = "body")
    })
    public Map<String, Org> getOrgMap(@RequestBody List<String> orgIds) {
        return orgService.getOrgMap(orgIds);
    }

    @RequestMapping(value = "/position/getPositionIdAndNameMap", method = RequestMethod.POST)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "posIds", value = "posIds", required = true, paramType = "body")
    })
    public Map<String, String> getPositionIdAndNameMap(@RequestBody List<String> posIds) {
        return positionService.getPositionIdAndNameMap(posIds);
    }

    @RequestMapping(value = "/group/getGroupIdAndNameMap", method = RequestMethod.POST)
    public Map<String, String> getGroupIdAndNameMap(@RequestBody List<String> groupIds) {
        return groupService.getGroupIdAndNameMap(groupIds);
    }

    @RequestMapping(value = "/user/fillOrgAndPositName", method = RequestMethod.POST)
    @ApiOperation(value = "该方法用于根据人员集合封装人员部门和岗位名称信息")
    public List<User> fillOrgAndPositName(@RequestBody List<User> users) {
        return userService.fillOrgAndPositName(users);
    }

    @RequestMapping(value = "/user/findAllRelIdsByUserId", method = RequestMethod.POST)
    @ApiOperation(value = "该方法用于根据人员id获取人员的id、部门级联id、岗位id、群组id")
    public Set<String> findAllRelIdsByUserId(String userId) {
        return userService.findAllRelIdsByUserId(userId);
    }

    @RequestMapping(value = "/initUser", method = RequestMethod.POST)
    @ApiOperation(value = "新增接口")
    public JsonResult save(@RequestBody User user) {
        return userService.saveUser(user);
    }

    @RequestMapping(value = "/initOrg", method = RequestMethod.POST)
    @ApiOperation(value = "新增接口")
    public JsonResult insert(@RequestBody Org org) {
        try {
            orgService.insert(org);
            return new JsonResult(true, "添加成功");
        } catch (UcException e) {
            return new JsonResult(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/init", method = RequestMethod.POST)
    @ApiOperation(value = "公司初始化数据: 部门，人员，角色，菜单，消息")
    public JsonResult<List<String>> init(@RequestBody Map<String, String> map) {
        if (StringUtils.isEmpty(ContextHandler.getCorpCode())) {
            String corpCode = map.get("corpCode");
            if (StringUtils.isEmpty(corpCode)) {
                throw new UcException(UcErrorCode.SYSTEM_ERROR, "corpCode not be empty!");
            }

            ContextHandler.setCorpCode(corpCode);
        }

        initService.init(map);
        return new JsonResult<>(true, "初始化数据成功");
    }

    @RequestMapping(value = "/getUserIdsByKeyword", method = RequestMethod.GET)
    @ApiOperation(value = "根据姓名/用户名/工号/手机号 模糊查询匹配的userId列表")
    public JsonResult<List<String>> getUserIdsByKeyword(@RequestParam String keyword) {
        List<String> userIds = userService.getUserIdsByKeyword(keyword);
        return new JsonResult<>(true, "查询成功", userIds);
    }

    @RequestMapping(value = "/listUserIdInKeywords", method = RequestMethod.POST)
    @ApiOperation(value = "根据人员名称 查询匹配的userId")
    public JsonResult<List<String>> listUserIdInKeywords(@RequestBody Set<String> keywords) {
        return new JsonResult<>(true, "查询成功", userService.listUserIdInKeywords(keywords));
    }

    @RequestMapping(value = "/org/listOrgIdInKeywords", method = RequestMethod.POST)
    @ApiOperation(value = "根据部门名称 查询匹配的orgId")
    public JsonResult<List<String>> listOrgIdInKeywords(@RequestBody Set<String> keywords) {
        return new JsonResult<>(true, "查询成功", orgService.listOrgIdInKeywords(keywords));
    }

    @RequestMapping(value = "/getAuthChildIds", method = RequestMethod.GET)
    @ApiOperation(value = "根据姓名/用户名/工号/手机号 模糊查询匹配的userId列表")
    public List<String> getAuthChildIds(@RequestParam String orgId) {
        return orgService.getAuthChildIds(Collections.singleton(orgId), true);
    }


    /**
     * 根据开放、下发范围，查询用户Id与用户类型的映射
     *
     * @param commonRelList 各个业务系统的开放范围和下发范围
     * @return key:userId,value:type(INNER/OUTER)
     */
    @RequestMapping(value = "/getUserIdByScope", method = RequestMethod.POST)
    @ApiOperation(value = "根据开放、下发范围，查询用户Id与用户类型的映射")
    public Map<String, String> getUserIdByScope(@RequestBody List<? extends CommonRel> commonRelList) {
        try {
            return userService.getUserIdByScope(commonRelList);
        } catch (IOException e) {
            e.printStackTrace();
            return new HashMap<>(0);
        }
    }

    @RequestMapping(value = "/getUserInfo/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "根据id获取用户信息，包含detail，role 信息")
    public User getUserInfo(@PathVariable("id") String userId) {
        return userService.getUserAllInfo(userId);
    }

    @RequestMapping(value = "/getUserBasicFromCache/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "根据id获取用户基本信息")
    public User getUserBasicFromCache(@PathVariable("id") String userId) {
        Map<String, UserCache> userMap = userService.getUserMapFromCache(Collections.singletonList(userId));
        if (MapUtils.isEmpty(userMap)) {
            return null;
        }

        User user = new User();
        BeanUtils.copyProperties(userMap.get(userId), user);
        return user;
    }

    @RequestMapping(value = "/getUserBasicMapFromCache", method = RequestMethod.POST)
    @ApiOperation(value = "根据id获取用户基本信息")
    public Map<String, UserCache> getUserBasicMapFromCache(@RequestBody Collection<String> userIds) {
        Map<String, UserCache> userCacheMap = userService.getUserMapFromCache(userIds);
        if (MapUtils.isEmpty(userCacheMap)) {
            return new HashMap<>(0);
        }

        return userCacheMap;
    }

    @RequestMapping(value = "/updateUser", method = RequestMethod.POST)
    @ApiOperation(value = "只修改用户信息")
    public JsonResult update(@RequestBody User user) {
        return userService.updateUserOnly(user);
    }

    @RequestMapping(value = "/getUserMap", method = RequestMethod.POST)
    @ApiOperation(value = "根据用户ID获取用户基本信息")
    public Map<String, User> getUserMap(@RequestBody Collection<String> userIds) {
        return userService.getUserMap(userIds, false, false);
    }

    @RequestMapping(value = "/getUserDetailMap", method = RequestMethod.POST)
    @ApiOperation(value = "根据用户ID获取用户基本信息,detail信息，部门，岗位名称")
    public Map<String, User> getUserDetailMap(@RequestBody Collection<String> userIds) {
        return userService.getUserMap(userIds, true, true);
    }

    @PostMapping(value = "/searchUser")
    @ApiOperation(value = "人员列表接口")
    public Page<User> searchUser(@RequestBody UserParam userParam) {
        User user = new User();
        BeanUtils.copyProperties(userParam, user);
        return userService.searchUser(user, userParam.getPage());
    }

    @PostMapping(value = "/saveOuterUser")
    @ApiOperation(value = "新增外部人员接口")
    public JsonResult<?> saveOuterUser(@RequestBody User user) {
        JsonResult<String> jsonResult = userService.saveOuterUser(user);
        jsonResult.setData(user.getId());
        return jsonResult;
    }

    @PostMapping(value = "/getUserCount")
    @ApiOperation(value = "获取用户总数和已使用人数")
    public Map<String, Integer> getUserCount(String corpCode) {
        ContextHandler.setCorpCode(corpCode);
        return userService.getUserCountMap();
    }

    @RequestMapping(value = "/user/getAllRelIdsByUserId", method = RequestMethod.POST)
    @ApiOperation(value = "该方法用于根据人员id获取人员的id、部门级联id(父部门)、岗位id(部门Id_岗位id)、群组ids")
    public Set<String> getAllRelIdsByUserId(@RequestParam("userId") String userId) {
        return userService.getAllRelIdsByUserId(userId);
    }

    @RequestMapping(value = "/user/listAllUserId", method = RequestMethod.POST)
    @ApiOperation(value = "获取公司所有人员ID")
    public Set<String> listAllUserId(@RequestParam("corpCode") String corpCode) {
        ContextHandler.setCorpCode(corpCode);
        return userService.listAllUserId();
    }

    @RequestMapping(value = "/refreshUsers", method = RequestMethod.GET)
    @ApiOperation(value = "刷新公司人员缓存")
    public JsonResult refreshUsers(@RequestParam String corpCode) {
        ContextHandler.setCorpCode(corpCode);
        try {
            userService.putUserToRedis(null, corpCode);
            return new JsonResult<>(true, "刷新【" + corpCode + "】人员成功", "");
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, "刷新【" + corpCode + "】人员失败", "");
        }
    }

    @PostMapping({"/getUserIdAndNameMap"})
    public Map<String, String> getUserIdAndNameMap(@RequestBody Collection<String> userIds) {
        return userService.getUserIdAndNameMap(userIds);
    }

    @RequestMapping(value = "/refreshAuths", method = RequestMethod.GET)
    @ApiOperation(value = "刷新公司权限缓存")
    public JsonResult refreshAuths(@RequestParam String corpCode) {
        ContextHandler.setCorpCode(corpCode);
        try {
            authService.putAuthTreeToRedis(corpCode);
            return new JsonResult<>(true, "刷新【" + corpCode + "】权限缓存成功", "");
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(false, "刷新【" + corpCode + "】权限缓存失败", "");
        }
    }

    @GetMapping(value = "/org/searchOutOrg")
    @ApiOperation(value = "查询外包组织接口")
    public List<Org> searchOutOrg() {
        return orgService.listOneLevelChild("out_team");
    }

    @GetMapping(value = "/role/listAllRoleByCurrentId")
    @ApiOperation(value = "获取当前人所有权限集合")
    public List<Role> listAllRoleByCurrentId() {
        String userId = ContextHandler.getUserId();
        List<String> roleIds = userRoleRelService.getRoleIdsByUserId(userId, null);
        if (CollectionUtils.isEmpty(roleIds)) {
            return new ArrayList<>(0);
        }

        return roleService.listByIds(roleIds, Role.ID, Role.CODE, Role.NAME);
    }

    @PostMapping(value = "/listUserIdsByRoleIdList")
    @ApiOperation(value = "根据角色Id获取对应人员集合")
    public List<String> listUserIdsByRoleIdList(@RequestBody List<String> roleIdList) {
        return userRoleRelService.getUserIdsByRoleIdList(roleIdList);
    }

    @RequestMapping(value = "/getUserByMobile/{mobile}", method = RequestMethod.GET)
    @ApiOperation(value = "根据手机号获取用户信息")
    public UserCache getUserByMobile(@PathVariable("mobile") String mobile) {
        User user = userService.getUserByFieldWithoutCache(User.MOBILE, mobile);
        if (user == null) {
            return null;
        }

        return userService.getUserCache(user.getId());
    }

    @RequestMapping(value = "/getUserByLoginName/{loginName}", method = RequestMethod.GET)
    @ApiOperation(value = "根据登录名获取用户信息")
    public UserCache getUserByLoginName(@PathVariable("loginName") String loginName) {
        User user = userService.getUserByFieldWithoutCache(User.LOGIN_NAME, loginName);
        if (user == null) {
            return null;
        }

        return userService.getUserCache(user.getId());
    }

    /**
     * 根据部门Id，获取部门(包含子部门)下的所有人员Id列表
     *
     * @param orgIds 部门Id
     * @return 人员Id列表
     */
    @PostMapping("/findUserIdsByOrgIds")
    List<String> findUserIdsByOrgIds(@RequestBody Collection<String> orgIds) {
        return userService.findUserIdsByOrgIds(orgIds);
    }

    @PostMapping("/saveOrUpdateOuterUser")
    @ApiOperation(value = "新增/更新外部人员基本信息,通过手机号区分唯一")
    public List<String> saveOrUpdateOuterUser(@RequestBody List<User> users) {
        if (CollectionUtils.isEmpty(users)) {
            return new ArrayList<>(0);
        }

        return userService.saveOrUpdateOuterUser(users);
    }

    @PostMapping(value = "/checkUserByMobile")
    @ApiOperation(value = "根据手机号，检查人员信息是否存在（是否有注册）")
    public Map<String, Boolean> checkUserByMobile(@RequestBody Collection<String> mobileList) {
        if (CollectionUtils.isEmpty(mobileList)) {
            return new HashMap<>(0);
        }

        List<User> userList = userService.getUsersByMobile(mobileList, User.MOBILE);
        if (CollectionUtils.isEmpty(userList)) {
            return new HashMap<>(0);
        }

        return userList.stream().collect(Collectors.toMap(User::getMobile, user -> true,
                (a, b) -> b, () -> new HashMap<>(userList.size())));
    }

    @RequestMapping(value = "/saveOrUpdateForOnline", method = RequestMethod.POST)
    public JsonResult<String> saveOrUpdateForOnline(@RequestBody Auth auth) {
        List<String> appCodeList = Collections.singletonList(auth.getAppCode());
        csFeignClient.register(new CorpAppModel(ContextHandler.getCorpCode(), appCodeList));
        authService.saveOrUpdateForOnline(auth);
        return new JsonResult<>(true, null);
    }

    /**
     * 禁用权限菜单
     */
    @RequestMapping(value = "/disabledMenu", method = RequestMethod.POST)
    public JsonResult<String> disabledMenu(@RequestBody List<String> authCodes) {
        List<String> appCodes = authService.disabledMenu(authCodes);
        if (CollectionUtils.isEmpty(appCodes)) {
            return new JsonResult<>(true, null);
        }

        csFeignClient.unRegister(new CorpAppModel(ContextHandler.getCorpCode(), appCodes));
        return new JsonResult<>(true, null);
    }

    @ApiOperation(value = "查询用户")
    @RequestMapping(value = "/public/getUserByCode", method = RequestMethod.GET)
    @ApiImplicitParam(name = "code", value = "用户code", dataType = "String", paramType = "path")
    public JsonResult<User> getUserByCode(@RequestParam("code") String code) {
        return new JsonResult<>(true, null, userService.getUserByCode(code));
    }

    @ApiOperation(value = "根据供应商id，获取对象map")
    @PostMapping(value = "/mapSupplierByIds")
    public Map<String, Supplier> mapSupplierByIds(@RequestBody Collection<String> ids) {
        return supplierService.mapSupplierByIds(ids);
    }
}
