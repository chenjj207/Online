package com.purchase.uc.model.vo;

import com.alibaba.excel.metadata.BaseRowModel;
import lombok.Data;

/**
 * 人员信息模板
 *
 * @since TangFD@HF 2019-05-14
 */
@Data
public class ExcelUser extends BaseRowModel {

    public static final String CODE = "code";
    public static final String LOGIN_NAME = "loginName";
    public static final String EMAIL = "email";
    public static final String MOBILE = "mobile";
    public static final String ID_CARD = "idCard";
    public static final String ORG_CODE = "orgCode";
    public static final String ORG_NAME_PATH = "orgNamePath";
    public static final String POSITION_CATEGORY = "positionCategory";
    public static final String POSITION_NAME = "positionName";
    public static final String POSITION_CODE = "positionCode";
    public static final String LEADER_CODE = "leaderCode";
    public static final String LEADER_NAME = "leaderName";
    public static final String SEX = "sex";
    public static final String STATUS = "status";
    public static final String PASSWORD = "pwd";

}
