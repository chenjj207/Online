package com.purchase.uc.client;

import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 * @author zhangcheng
 */
@FeignClient(value = "dev-saas", path = "/saasFeign", fallbackFactory = SaasClient.SaasClientHystrix.class)
public interface SaasClient {

    @GetMapping("/public/listAllCorpCode")
    List<String> listAllCorpCode();
    /**
     * SaasFeignClientHystrix
     */
    @Slf4j
    @Component
    class SaasClientHystrix implements FallbackFactory<SaasClient> {

        @Override
        public SaasClient create(Throwable cause) {
            return new SaasClient() {
                @Override
                public List<String> listAllCorpCode() {
                    return null;
                }
            };
        }
    }
}
