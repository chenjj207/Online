package com.purchase.uc.controller;

import com.purchase.uc.model.vo.UserComponent;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.purchase.uc.model.vo.OrgComponent;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * UC管理相关选择组件ComponentBaseController接口
 * 由业务系统实现，供UC进行反调
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RequestMapping(value = "/")
public abstract class SelectComponentBaseController {

    /**
     * 该方法用于添加传入的人员列表，当已选人员列表已存在该人员时跳过
     *
     * @param condition 添加人员条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relIds 必须 = List<String> userIds</li>
     *                  </p>
     */
    @RequestMapping(value = "/addUsers", method = RequestMethod.POST)
    @ApiOperation(value = "添加传入的人员列表")
    public JsonResult<String> addUsers(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于全量删除查询条件下的全部人员
     *
     * @param condition 删除条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType = com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>category 必须</li>
     *                  <li>includeChild 必须</li>
     *                  </p>
     */
    @RequestMapping(value = "/removeAllUsers", method = RequestMethod.POST)
    @ApiOperation(value = "全量删除查询条件下的全部人员")
    public JsonResult<String> removeAllUsers(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于删除传入的人员列表
     *
     * @param condition 删除条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relIds 必须 = List<String> userIds</li>
     *                  </p>
     */
    @RequestMapping(value = "/removeUsers", method = RequestMethod.POST)
    @ApiOperation(value = "删除传入的人员列表")
    public JsonResult<String> removeUsers(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于根据查询条件获取所有已选人员ID集合
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType = com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  </p>
     * @return 已选人员ID集合
     */
    @RequestMapping(value = "/listSelectedUserId", method = RequestMethod.POST)
    @ApiOperation(value = "获取所有已选人员ID集合")
    public JsonResult<List<String>> listSelectedUserId(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于根据查询条件分页获取已选人员ID
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType = com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  <li>keywords 可选</li>
     *                  </p>
     * @return 已选人员分页对象
     */
    @RequestMapping(value = "/searchSelectedUser", method = RequestMethod.POST)
    @ApiOperation(value = "获取选人组件已选人员分页对象")
    public JsonResult<Page<UserComponent>> searchSelectedUser(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于根据查询条件分页获取已选人员ID
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType = com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  <li>keywords 可选</li>
     *                  </p>
     */
    @RequestMapping(value = "/searchSelectedUserId", method = RequestMethod.POST)
    @ApiOperation(value = "根据查询条件分页获取已选人员ID")
    public JsonResult<Page<String>> searchSelectedUserId(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于添加传入的组织列表，当已选组织列表已存在该组织时跳过
     *
     * @param condition 添加组织条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relIds 必须 = List<String> userIds</li>
     *                  </p>
     */
    @RequestMapping(value = "/addOrgs", method = RequestMethod.POST)
    @ApiOperation(value = "添加传入的组织列表")
    public JsonResult<String> addOrgs(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于全量删除查询条件下的全部组织
     *
     * @param condition 删除条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType != com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>category 必须</li>
     *                  <li>includeChild 必须</li>
     *                  </p>
     */
    @RequestMapping(value = "/removeAllOrgs", method = RequestMethod.POST)
    @ApiOperation(value = "删除查询条件下的全部组织")
    public JsonResult<String> removeAllOrgs(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于删除传入的组织列表
     *
     * @param condition 删除条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relIds 必须 = List<String> userIds</li>
     *                  </p>
     */
    @RequestMapping(value = "/removeOrgs", method = RequestMethod.POST)
    @ApiOperation(value = "删除传入的组织列表")
    public JsonResult<String> removeOrgs(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于根据查询条件获取所有已选组织ID集合
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType != com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  </p>
     */
    @RequestMapping(value = "/listSelectedOrgId", method = RequestMethod.POST)
    @ApiOperation(value = "根据查询条件获取所有已选组织ID集合")
    public JsonResult<List<String>> listSelectedOrgId(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于根据查询条件分页获取已选组织ID
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType != com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  <li>keywords 可选</li>
     *                  </p>
     */
    @RequestMapping(value = "/searchSelectedOrgId", method = RequestMethod.POST)
    @ApiOperation(value = "根据查询条件分页获取已选组织ID")
    public JsonResult<Page<String>> searchSelectedOrgId(@RequestBody ComponentCondition condition) {
        return null;
    }

    /**
     * 该方法用于根据查询条件分页获取已选组织
     *
     * @param condition 查询条件<p>
     *                  <li>funCode 必须</li>
     *                  <li>funId 必须</li>
     *                  <li>relType != com.qgutech.qgyun.saas.app.uc.base.UcConstants#RANG_TYPE_USER</li>
     *                  <li>relId 必须</li>
     *                  <li>pageNum 当前页 必须</li>
     *                  <li>pageSize 分页大小 必须</li>
     *                  <li>keywords 可选</li>
     *                  </p>
     */
    @RequestMapping(value = "/searchSelectedOrg", method = RequestMethod.POST)
    @ApiOperation(value = "根据查询条件分页获取已选组织")
    public JsonResult<Page<OrgComponent>> searchSelectedOrg(@RequestBody ComponentCondition condition) {
        return null;
    }

}
