package com.purchase.uc.mapper;

import com.purchase.uc.model.Supplier;
import com.purchase.uc.model.vo.SupplierList;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 供应商Mapper接口类
 *
 * @author zhangcheng
 * @since 2022-08-25
 */
public interface SupplierMapper extends QguBaseMapper<Supplier> {


    /**
     * 根据条件，获取对象集合
     *
     * @param supplier 条件
     * @return 对象集合
     */
    List<Supplier> search(@Param("con") Supplier supplier);

    Long countByStatus(@Param("con") Supplier supplier);

    List<SupplierList> supplierList(@Param("type")String type);


}
