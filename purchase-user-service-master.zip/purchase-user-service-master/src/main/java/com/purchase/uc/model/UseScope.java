package com.purchase.uc.model;


import com.qgutech.qgyun.dev.common.annotation.RedisKeyCode;
import com.qgutech.qgyun.dev.common.model.CommonRel;
import com.purchase.uc.utils.UcRedisKeys;
import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;

/**
 * 使用范围实体
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年07月10日13:28:01
 */
@Getter
@Setter
@ToString
@ApiModel(value = "userScope", description = "使用范围")
@Table(name = "t_uc_use_scope")
@RedisKeyCode(name = UcRedisKeys.USE_SCOPE)
public class UseScope extends CommonRel {
}
