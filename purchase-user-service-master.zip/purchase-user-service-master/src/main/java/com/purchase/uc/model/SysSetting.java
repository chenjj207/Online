package com.purchase.uc.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;

/**
 *  model
 *
 * @author auto
 * @version 1.0
 * @since 2020-04-07 16:42:35
 */
@Getter
@Setter
@ToString
@ApiModel(value = "SysSetting", description = "")
@Table(name = "t_uc_sys_setting")
public class SysSetting extends BaseCorpModel {

    public static final String INIT_PASSWORD = "initPassword";

    /**
     * 初始密码
     */
    @ApiModelProperty(value = "初始密码")
    private String initPassword;

}