package com.purchase.uc.model.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author lidecheng
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SecurityCode {

    private String img;
    private String key;
    private boolean hide;
}
