package com.purchase.uc.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/***
 * 阿里云短信配置参数
 * @author CGR
 *
 */
@Data
@Component
@RefreshScope
@ConfigurationProperties(prefix= AliSmsProperties.PREFIX)
public class AliSmsProperties {
    public final static String PREFIX = "zyd.ali";

    /***
     * 阿里云短信服务AccessKeyId
     */
    String accesskeyId;
    /***
     * 阿里云短信服务AccessKeySecret
     */
    String accessKeySecret;
    /***
     * 阿里云短信服务短信签名
     */
    String signName;
}
