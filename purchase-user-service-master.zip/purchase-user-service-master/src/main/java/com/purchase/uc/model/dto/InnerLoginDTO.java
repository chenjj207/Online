package com.purchase.uc.model.dto;

import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/11/1  16:48
 */
@Data
public class InnerLoginDTO {

    private Integer memberId;

    private Integer custId;
}
