package com.purchase.uc.controller;

import com.purchase.uc.model.Supplier;
import com.purchase.uc.model.dto.SupplierAuditDTO;
import com.purchase.uc.model.dto.SupplierListDTO;
import com.purchase.uc.model.vo.SupplierList;
import com.purchase.uc.service.SupplierService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * 供应商接口
 *
 * @author lwl
 */
@Slf4j
@RestController
@RequestMapping(value = "/supplier")
@Api(value = "供应商接口", tags = {"供应商接口"})
public class SupplierController {
    @Resource
    private SupplierService supplierService;

    /**
     * 获取所有供应商
     */
    @PostMapping(value = "/all-list")
    public JsonResult<List<Supplier>> listAll(@RequestBody Supplier supplier) {
        return new JsonResult<>(true, null, supplierService.listByCondition(supplier));
    }

    /**
     * 获取分页数据
     */
    @PostMapping(value = "/page")
    public JsonResult<Page<Supplier>> search(@RequestBody Supplier supplier) {
        Page<Supplier> page = supplier.getPage();
        page = null == page ? new Page<>() : page;
        return new JsonResult<>(true, null, supplierService.search(supplier, page));
    }

    /**
     * 后台新增供应商
     * 慧采客户申请供应商
     *
     * @param supplier
     * @return
     */
    @PostMapping(value = "/add")
    public JsonResult<Supplier> add(@RequestBody Supplier supplier) {
        return new JsonResult<>(true, null, supplierService.add(supplier));
    }

    /**
     * 后台编辑供应商
     * SCM
     *
     * @param supplier
     * @return
     */
    @ApiOperation("SCM后台编辑供应商")
    @PostMapping(value = "/scm/edit")
    public JsonResult<Supplier> edit(@RequestBody Supplier supplier) {
        return new JsonResult<>(true, null, supplierService.edit(supplier));
    }

    /**
     * 审核接口
     *
     * @param supplierAuditDTO
     * @return
     */
    @PostMapping(value = "/audit")
    public JsonResult audit(@RequestBody SupplierAuditDTO supplierAuditDTO) {
        return new JsonResult<>(true, null, supplierService.audit(supplierAuditDTO));
    }

    /**
     * 启停用
     */
    @PostMapping(value = "/enable-or-disable")
    public JsonResult<?> enableOrDisable(@RequestBody Supplier supplier) {
        supplierService.enableOrDisable(supplier);
        return new JsonResult<>(true, null);
    }

    /**
     * 交表数据
     */
    @PostMapping(value = "/public/count")
    public JsonResult<List<Map<String, Object>>> count(@RequestBody Supplier supplier) {
        return new JsonResult<>(true, null, supplierService.count(supplier));
    }

    @ApiOperation("交表数据_SCM_启用、停用角标数")
    @PostMapping(value = "/scm/count")
    public JsonResult<List<Map<String, Object>>> scmCount(@RequestBody Supplier supplier) {
        return new JsonResult<>(true, null, supplierService.scmCount(supplier));
    }

    @PostMapping("/store-supplier-list")
    public JsonResult<List<SupplierList>> supplierList(@RequestBody @Validated SupplierListDTO supplierListDTO) {
        return new JsonResult<>(true, null, supplierService.supplierList(supplierListDTO.getType()));
    }

    @ApiOperation("导出excel")
    @PostMapping("/export/excel")
    public void exportExcel(HttpServletResponse response, @RequestBody Supplier supplier) {
        supplierService.exportExcel(response, supplier);
    }

    @ApiOperation("重置密码")
    @PostMapping("/resetPwd")
    public JsonResult<String> exportExcel(@RequestBody Supplier supplier) {
        try {
            return new JsonResult<>(true, "密码重置成功", supplierService.resetPwd(supplier));
        } catch (Exception e) {
            log.error("error", e);
            return new JsonResult<>(false, "密码重置失败");
        }
    }
}
