package com.purchase.uc.service;

import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.mapper.UserRoleRelMapper;
import com.purchase.uc.model.Role;
import com.purchase.uc.model.User;
import com.purchase.uc.model.vo.UserComponent;
import com.purchase.uc.utils.CompoentUtil;
import com.purchase.uc.utils.UcRedisKeys;
import com.purchase.uc.utils.UcUtil;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.qgutech.qgyun.dev.common.utils.CommonUtils;
import com.purchase.uc.base.UcException;
import com.purchase.uc.model.UserRoleRel;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Assert;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 用户角色关联接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
public class UserRoleRelService extends BaseServiceImpl<UserRoleRel> implements UserComponentService {

    @Resource
    private UserRoleRelMapper userRoleRelMapper;
    @Resource
    private RoleService roleService;
    @Resource
    private UserService userService;
    @Resource
    private UserRangeService userRangeService;
    @Resource
    private RedisTemplate<String, Map<String, List<String>>> redisTemplate;

    private static final int PAGE_SIZE = 1000;

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<UserRoleRel> listAll() {
        return userRoleRelMapper.selectAll();
    }

    /**
     * 根据用户Id获取角色Id列表，当查询所有角色时，只从缓存中查询
     *
     * @param manage 是否是管理员角色 true:管理员角色，false:学员角色，null:所有角色
     * @return 角色Id列表
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<String> getRoleIdsByUserId(String userId, Boolean manage) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        return getRoleIdsByUserId(userId);
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> getRoleIdsByUserId(String userId) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        List<UserRoleRel> userRoleRelList = listByProperty(UserRoleRel.USER_ID, userId);
        return CollectionUtils.isEmpty(userRoleRelList) ? new ArrayList<>(0) :
                userRoleRelList.stream().map(UserRoleRel::getRoleId).collect(Collectors.toList());
    }

    private void addUserRoleCache(Collection<String> roleIds, Collection<String> userIds) {
        if (CollectionUtils.isEmpty(roleIds) || CollectionUtils.isEmpty(userIds)) {
            return;
        }

        CommonUtils.threadPoolExecutor(o -> {
            Map<String, Boolean> roleIdAndManageMap = getRoleIdAndManageMap(new ArrayList<>(roleIds));
            if (MapUtils.isEmpty(roleIdAndManageMap)) {
                return;
            }

            String corpCode = ContextHandler.getCorpCode();
            String userRoleKey = UcRedisKeys.getUserRoleKey(corpCode);
            addUserRoleCache(userIds, roleIdAndManageMap, userRoleKey, BooleanUtils::isNotTrue);
            String adminRoleKey = UcRedisKeys.getAdminRoleKey(corpCode);
            addUserRoleCache(userIds, roleIdAndManageMap, adminRoleKey, BooleanUtils::isTrue);
        });
    }

    private void addUserRoleCache(Collection<String> userIds, Map<String, Boolean> roleIdAndManageMap,
                                  String userRoleKey, Function<Boolean, Boolean> function) {
        Map<String, List<String>> resultMap = UcUtil.getResultMap(redisTemplate, userRoleKey, userIds);
        Map<String, Map<String, List<String>>> userIdAndRoleIdsMap = new HashMap<>(userIds.size());
        for (String userId : userIds) {
            List<String> roleIdList = resultMap.get(userId);
            if (roleIdList == null) {
                roleIdList = new ArrayList<>(roleIdAndManageMap.size());
            }

            Set<String> roleIdSet = new HashSet<>(roleIdList);
            for (Map.Entry<String, Boolean> entry : roleIdAndManageMap.entrySet()) {
                if (function.apply(entry.getValue())) {
                    roleIdSet.add(entry.getKey());
                }
            }

            Map<String, List<String>> userMap = CommonUtils.singletonMap(userId, new ArrayList<>(roleIdSet));
            userIdAndRoleIdsMap.putAll(CommonUtils.singletonMap(userId, userMap));
        }

        redisTemplate.opsForHash().putAll(userRoleKey, userIdAndRoleIdsMap);
    }

    private Map<String, Boolean> getRoleIdAndManageMap(List<String> roleIds) {
        List<Role> roles = roleService.listByIds(roleIds, Role.ID, Role.MANAGE);
        if (CollectionUtils.isEmpty(roles)) {
            return Collections.emptyMap();
        }

        Map<String, Boolean> roleIdAndManageMap = new HashMap<>(roles.size());
        roles.forEach(role -> roleIdAndManageMap.put(role.getId(), BooleanUtils.isTrue(role.getManage())));
        return roleIdAndManageMap;
    }

    /**
     * 根据人员Id获取所有的学员角色Id列表
     *
     * @param userId 人员Id
     * @return 学员角色Id列表
     */
    public List<String> getUserRoleIdsFromCache(String userId) {
        String userRoleKey = UcRedisKeys.getUserRoleKey(ContextHandler.getCorpCode());
        return getRoleIdsFromCache(userId, userRoleKey);
    }

    /**
     * 根据人员Id获取所有的管理员角色Id列表
     *
     * @param userId 人员Id
     * @return 管理员角色Id列表
     */
    public List<String> getAdminRoleIdsFromCache(String userId) {
        String adminRoleKey = UcRedisKeys.getAdminRoleKey(ContextHandler.getCorpCode());
        return getRoleIdsFromCache(userId, adminRoleKey);
    }

    /**
     * 根据人员Id获取所有的管理员角色Id列表
     *
     * @param userId 人员Id
     * @return 管理员角色Id列表
     */
    public List<String> getRoleIds(String userId) {
        return getRoleIdsByUserId(userId, null);
    }

    private List<String> getRoleIdsFromCache(String userId, String roleKey) {
        Set<String> userIds = CommonUtils.singleton(userId);
        Map<String, List<String>> resultMap = UcUtil.getResultMap(redisTemplate, roleKey, userIds);
        if (MapUtils.isEmpty(resultMap)) {
            return new ArrayList<>(0);
        }

        return resultMap.get(userId);
    }

    /**
     * 从缓存中获取指定人员所有的角色Id列表
     */
    private List<String> getAllRoleIdsFromCache(String userId) {
        List<String> userRoleIds = getUserRoleIdsFromCache(userId);
        userRoleIds = userRoleIds == null ? new ArrayList<>(0) : userRoleIds;
        List<String> adminRoleIds = getAdminRoleIdsFromCache(userId);
        adminRoleIds = adminRoleIds == null ? new ArrayList<>(0) : adminRoleIds;
        adminRoleIds.addAll(userRoleIds);
        return adminRoleIds;
    }

    /**
     * 分页获取角色下的人员信息
     *
     * @param roleRel 查询条件对象
     * @param page    分页对象
     * @return 角色下的人员信息
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<User> searchUser(UserRoleRel roleRel, Page<UserRoleRel> page) {
        CheckFlow.start().isNotNull(roleRel).isNotNull(page);
        Page<User> userPage = new Page<>();
        userPage.setPageSize(page.getPageSize());
        userPage.setPageNum(page.getPageNum());
        List<String> roleIds = roleRel.getRoleIds();
        if (CollectionUtils.isEmpty(roleIds)) {
            List<Role> roles = roleService.listAll();
            if (CollectionUtils.isEmpty(roles)) {
                return userPage;
            }

            roleRel.setRoleIds(roles.stream().map(Role::getId).collect(Collectors.toList()));
        }

        Integer total = userRoleRelMapper.getUserTotal(roleRel);
        if (total == null || total == 0) {
            return userPage;
        }

        userPage.setTotal(total);
        List<User> users = userRoleRelMapper.searchUser(roleRel, page);
        if (CollectionUtils.isEmpty(users)) {
            return userPage;
        }

        userService.fillOrgAndPositName(users);
        List<String> userIds = new ArrayList<>(users.size());
        users.forEach(user -> userIds.add(user.getId()));
        Map<String, Integer> userIdAndRefCntMap = userRangeService.getUserIdAndRefCntMap(userIds);
        for (User user : users) {
            Integer count = userIdAndRefCntMap.get(user.getId());
            user.setOrgCnt(count == null ? 0 : count);
        }

        userPage.setList(users);
        return userPage;
    }

    /**
     * 根据用户Id列表和角色Id，批量添加人员角色关联
     *
     * @param userRoleRel 人员角色关联对象 <ul>
     *                    <li>roleId:角色Id</li>
     *                    <li>userIds:人员Id列表</li>
     *                    </ul>
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void addUserRoleRel(UserRoleRel userRoleRel) {
        CheckFlow.start()
                .isNotNull(userRoleRel)
                .isNotEmpty(userRoleRel.getRoleId())
                .isNotEmpty(userRoleRel.getUserIds());
        String roleId = userRoleRel.getRoleId();
        List<String> userIds = userRoleRel.getUserIds();
        List<UserRoleRel> roleRelList = new ArrayList<>(userIds.size());
        for (String userId : userIds) {
            roleRelList.add(new UserRoleRel(userId, roleId));
        }

        batchInsert(roleRelList);
        addUserRoleCache(roleId, userIds);
    }

    /**
     * 根据用户Id和角色Id列表，批量添加人员角色关联
     *
     * @param userId  人员Id
     * @param roleIds 角色Id列表
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void addUserRoleRel(String userId, List<String> roleIds) {
        if (StringUtils.isEmpty(userId) || CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId and roleIds not be empty!");
        }

        List<UserRoleRel> roleRelList = new ArrayList<>(roleIds.size());
        for (String roleId : roleIds) {
            roleRelList.add(new UserRoleRel(userId, roleId));
        }

        batchInsert(roleRelList);
        addUserRoleCache(roleIds, CommonUtils.singletonList(userId));
    }

    /**
     * 根据用户Id和角色Id列表，批量添加人员角色关联
     *
     * @param userId  人员Id
     * @param roleIds 角色Id列表
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void delUserRoleRel(String userId, List<String> roleIds) {
        if (StringUtils.isEmpty(userId) || CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId and roleIds not be empty!");
        }

        Example example = new Example(UserRoleRel.class);
        example.createCriteria()
                .andEqualTo(UserRoleRel.USER_ID, userId)
                .andIn(UserRoleRel.ROLE_ID, roleIds);
        userRoleRelMapper.deleteByExample(example);
        delUserRoleCache(roleIds, CommonUtils.singletonList(userId));
    }

    /**
     * 根据用户Id列表和角色Id，批量添加人员角色关联
     *
     * @param userIds 人员Id列表
     * @param roleId  角色Id
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void addUserRoleRel(List<String> userIds, String roleId) {
        if (StringUtils.isEmpty(roleId) || CollectionUtils.isEmpty(userIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userIds and roleId not be empty!");
        }

        List<UserRoleRel> roleRelList = new ArrayList<>(userIds.size());
        for (String userId : userIds) {
            roleRelList.add(new UserRoleRel(userId, roleId));
        }

        batchInsert(roleRelList);
        addUserRoleCache(roleId, userIds);
    }

    /**
     * 增加用户角色缓存信息
     *
     * @param roleId  待增加的角色Id
     * @param userIds 拥有该角色的用户Id列表
     */
    public void addUserRoleCache(String roleId, List<String> userIds) {
        addUserRoleCache(CommonUtils.singletonList(roleId), userIds);
    }

    /**
     * 根据用户Id列表和角色Id，批量删除人员角色关联
     *
     * @param userRoleRel 人员角色关联对象 <ul>
     *                    <li>roleId:角色Id</li>
     *                    <li>userIds:人员Id列表</li>
     *                    </ul>
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void delUserRoleRel(UserRoleRel userRoleRel) {
        CheckFlow.start()
                .isNotNull(userRoleRel)
                .isNotEmpty(userRoleRel.getRoleId())
                .isNotEmpty(userRoleRel.getUserIds());
        String roleId = userRoleRel.getRoleId();
        List<String> userIds = userRoleRel.getUserIds();
        Example example = new Example(UserRoleRel.class);
        example.createCriteria()
                .andEqualTo(UserRoleRel.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(UserRoleRel.ROLE_ID, roleId)
                .andIn(UserRoleRel.USER_ID, userIds);
        userRoleRelMapper.deleteByExample(example);
        delUserRoleCache(CommonUtils.singleton(roleId), userIds);
    }

    /**
     * 删除用户角色缓存信息
     *
     * @param roleIds 待删除的角色Id列表
     * @param userIds 拥有该角色的用户Id列表
     */
    private void delUserRoleCache(Collection<String> roleIds, Collection<String> userIds) {
        if (CollectionUtils.isEmpty(roleIds) || CollectionUtils.isEmpty(userIds)) {
            return;
        }

        CommonUtils.threadPoolExecutor(o -> {
            String corpCode = ContextHandler.getCorpCode();
            String userRoleKey = UcRedisKeys.getUserRoleKey(corpCode);
            delUserRoleCache(roleIds, userIds, userRoleKey);
            String adminRoleKey = UcRedisKeys.getAdminRoleKey(corpCode);
            delUserRoleCache(roleIds, userIds, adminRoleKey);
        });
    }

    private void delUserRoleCache(Collection<String> roleIds, Collection<String> userIds, String userRoleKey) {
        Map<String, List<String>> resultMap = UcUtil.getResultMap(redisTemplate, userRoleKey, userIds);
        Map<String, Map<String, List<String>>> userIdAndRoleIdsMap = new HashMap<>(userIds.size());
        for (String userId : userIds) {
            List<String> roleIdList = resultMap.get(userId);
            if (roleIdList == null) {
                continue;
            }

            roleIdList.removeAll(roleIds);
            Map<String, List<String>> userMap = CommonUtils.singletonMap(userId, roleIdList);
            userIdAndRoleIdsMap.putAll(CommonUtils.singletonMap(userId, userMap));
        }

        if (userIdAndRoleIdsMap.size() > 0) {
            redisTemplate.opsForHash().putAll(userRoleKey, userIdAndRoleIdsMap);
        }
    }

    /**
     * 删除用户角色缓存信息
     *
     * @param roleIds 待删除缓存的角色Id列表
     */
    public void delUserRoleCache(Collection<String> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "roleIds not be empty!");
        }

        Set<String> userIds = listUserIdsByRoleIds(roleIds);
        if (CollectionUtils.isEmpty(userIds)) {
            return;
        }

        delUserRoleCache(roleIds, userIds);
    }

    /**
     * 根据角色Id列表删除用户角色关联信息
     *
     * @param roleIds 角色Id列表
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void deleteByRoleIds(List<String> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "roleIds not be empty!");
        }

        Set<String> userIds = listUserIdsByRoleIds(roleIds);
        if (CollectionUtils.isEmpty(userIds)) {
            return;
        }

        deleteDbByRoleIds(roleIds);
        delUserRoleCache(roleIds, userIds);
    }

    /**
     * 该方法用于根据角色ID集合获取角色下所有人员ID集合
     *
     * @param roleIds 角色ID集合
     * @return 人员ID集合
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Set<String> listUserIdsByRoleIds(Collection<String> roleIds) {
        Example example = getExampleByRoleIds(roleIds, UserRoleRel.USER_ID);

        List<UserRoleRel> roleRelList = userRoleRelMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(roleRelList)) {
            return new HashSet<>(0);
        }

        return roleRelList.stream().map(UserRoleRel::getUserId).collect(Collectors.toCollection(()
                -> new HashSet<>(roleRelList.size())));
    }

    private int deleteDbByRoleIds(List<String> roleIds) {
        return userRoleRelMapper.deleteByExample(getExampleByRoleIds(roleIds));
    }

    private Example getExampleByRoleIds(Collection<String> roleIds, String... properties) {
        Example example = new Example(UserRoleRel.class);
        if (ArrayUtils.isNotEmpty(properties)) {
            example = example.selectProperties(properties);
        }

        example.createCriteria()
                .andEqualTo(UserRoleRel.CORP_CODE, ContextHandler.getCorpCode())
                .andIn(UserRoleRel.ROLE_ID, roleIds);
        return example;
    }

    /**
     * 根据角色Id获取角色与人员Id列表的映射
     *
     * @param roleIds 角色Id列表
     */
    public Map<String, List<String>> getRoleIdAndUserIdsMap(Collection<String> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "roleIds not be empty!");
        }

        Example example = getExampleByRoleIds(roleIds, UserRoleRel.USER_ID, UserRoleRel.ROLE_ID);

        List<UserRoleRel> roleRelList = userRoleRelMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(roleRelList)) {
            return new HashMap<>(0);
        }

        Map<String, List<String>> roleIdAndUserIdsMap = new HashMap<>(roleIds.size());
        roleRelList.forEach(roleRel -> {
            String roleId = roleRel.getRoleId();
            List<String> userIds = roleIdAndUserIdsMap.computeIfAbsent(roleId, k -> new ArrayList<>());
            userIds.add(roleRel.getUserId());
        });

        return roleIdAndUserIdsMap;
    }

    /**
     * 根据人员角色关联主键列表删除数据
     *
     * @param relIds 关联主键Id列表
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void delete(List<String> relIds) {
        if (CollectionUtils.isEmpty(relIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "relIds not be empty!");
        }

        List<UserRoleRel> roleRelList = listByIds(relIds);
        if (CollectionUtils.isEmpty(roleRelList)) {
            return;
        }

        batchDelete(relIds);
        Map<String, List<String>> roleIdAndUserIdsMap = new HashMap<>(relIds.size());
        for (UserRoleRel roleRel : roleRelList) {
            List<String> userIds = roleIdAndUserIdsMap.computeIfAbsent(roleRel.getRoleId(), k -> new ArrayList<>());
            userIds.add(roleRel.getUserId());
        }

        for (String roleId : roleIdAndUserIdsMap.keySet()) {
            delUserRoleCache(CommonUtils.singleton(roleId), roleIdAndUserIdsMap.get(roleId));
        }
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void addUsers(ComponentCondition condition) {
        addUserRoleRel(condition.getRelIds(), condition.getFunId());
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void removeAllUsers(ComponentCondition condition) {
        deleteByRoleIds(CommonUtils.singletonList(condition.getFunId()));
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void removeUsers(ComponentCondition condition) {
        List<String> relIds = condition.getRelIds();
        if (CollectionUtils.isEmpty(relIds)) {
            return;
        }

        List<UserRoleRel> userRoleRels = super.listByIds(relIds);
        if (CollectionUtils.isEmpty(userRoleRels)) {
            return;
        }

        for (UserRoleRel userRoleRel : userRoleRels) {
            delUserRoleRel(userRoleRel.getUserId(), CommonUtils.singletonList(userRoleRel.getRoleId()));
        }
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public List<String> listSelectedUserId(ComponentCondition condition) {
        Set<String> userIdSet = listUserIdsByRoleIds(CommonUtils.singletonList(condition.getFunId()));
        return new ArrayList<>(userIdSet);
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<String> searchSelectedUserId(ComponentCondition condition) {
        UserRoleRel roleRel = new UserRoleRel();
        String funId = condition.getFunId();
        if (StringUtils.isNotEmpty(funId)) {
            roleRel.setRoleIds(CommonUtils.singletonList(funId));
        }

        roleRel.setKeyword(condition.getKeywords());
        roleRel.setCorpCode(ContextHandler.getCorpCode());
        Page<User> userPage = searchUser(roleRel, condition.getPage());
        return CompoentUtil.convertToUserIdPage(userPage);
    }

    @Override
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Page<UserComponent> searchSelectedUser(ComponentCondition condition) {
        UserRoleRel roleRel = new UserRoleRel();
        String funId = condition.getFunId();
        if (StringUtils.isNotEmpty(funId)) {
            roleRel.setRoleIds(CommonUtils.singletonList(funId));
        }

        roleRel.setKeyword(condition.getKeywords());
        roleRel.setCorpCode(ContextHandler.getCorpCode());
        Page<User> userPage = searchUser(roleRel, condition.getPage());
        return CompoentUtil.convertToUserComponentPage(userPage);
    }

    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Set<String> listHasUserRoleIds(Collection<String> roleIds) {
        Example example = getExampleByRoleIds(roleIds, UserRoleRel.ROLE_ID);

        List<UserRoleRel> roleRelList = userRoleRelMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(roleRelList)) {
            return new HashSet<>(0);
        }

        return roleRelList.stream().map(UserRoleRel::getRoleId).collect(Collectors.toSet());
    }

    /**
     * 根据角色Id列表获取角色下的人数
     *
     * @param roleIds 角色Id列表
     * @return 角色Id与角色下的人数映射
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public Map<String, Integer> getRoleIdAndUserCntMap(List<String> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "roleIds not be empty!");
        }

        List<UserRoleRel> roles = userRoleRelMapper.getRoleIdAndUserCntMap(ContextHandler.getCorpCode(), roleIds);
        if (CollectionUtils.isEmpty(roles)) {
            return new HashMap<>(0);
        }

        Map<String, Integer> roleIdAndUserCntMap = new HashMap<>(roles.size());
        roles.forEach(role -> roleIdAndUserCntMap.put(role.getRoleId(), role.getUserCount()));
        return roleIdAndUserCntMap;
    }

    /**
     * 根据人员Id判断是否有系统管理员角色
     *
     * @param userId 人员Id
     * @return true:有，false:无
     */
    public boolean hasSuperAdminRole(String userId) {
        List<String> roleIds = getRoleIds(userId);
        if (CollectionUtils.isEmpty(roleIds)) {
            return false;
        }

        String id = ContextHandler.getCorpCode() + "_" + UcConstants.DEFAULT_ADMIN_ROLE;
        return roleIds.contains(id);
    }

    /**
     * 当前人员是否只有外部人员角色
     *
     * @return true:只有外部人员角色,false:有多个角色
     */
    public boolean isOuterUser() {
        List<String> roleIds = getUserRoleIdsFromCache(ContextHandler.getUserId());
        if (CollectionUtils.isEmpty(roleIds) || roleIds.size() > 1) {
            return false;
        }

        String id = ContextHandler.getCorpCode() + "_" + UcConstants.OUTER_USER_ROLE;
        return roleIds.contains(id);
    }

    /**
     * 刷新人员角色缓存
     */
    public void refreshUserRoleCache() {
        delUserRoleCache();
        Example example = new Example(UserRoleRel.class);
        example.selectProperties(UserRoleRel.ROLE_ID, UserRoleRel.USER_ID);
        example.setOrderByClause(UserRoleRel.ID);
        example.createCriteria().andEqualTo(UserRoleRel.CORP_CODE, ContextHandler.getCorpCode());
        Page<UserRoleRel> page = new Page<>();
        page.setPageSize(PAGE_SIZE);
        int count, num = 0;
        do {
            page.setPageNum(++num);
            Page<UserRoleRel> search = search(example, page);
            List<UserRoleRel> list = search.getList();
            if (CollectionUtils.isEmpty(list)) {
                return;
            }

            count = list.size();
            Map<String, Set<String>> userIdAndRoleIdsMap = new HashMap<>(count);
            list.forEach(rel -> {
                String userId = rel.getUserId();
                Set<String> roleIds = userIdAndRoleIdsMap.computeIfAbsent(userId, k -> new HashSet<>());
                roleIds.add(rel.getRoleId());
            });

            for (String userId : userIdAndRoleIdsMap.keySet()) {
                addUserRoleCache(userIdAndRoleIdsMap.get(userId), CommonUtils.singleton(userId));
            }
        } while (count >= PAGE_SIZE);
    }

    /**
     * 删除当前公司所有用户，角色缓存信息
     */
    private void delUserRoleCache() {
        String corpCode = ContextHandler.getCorpCode();
        redisTemplate.delete(UcRedisKeys.getUserRoleKey(corpCode));
        redisTemplate.delete(UcRedisKeys.getAdminRoleKey(corpCode));
    }

    public List<String> getUserIdsByRoleIdList(List<String> roleIdList) {
        Assert.notEmpty(roleIdList, "roleIdList can not be empty!");
        Example example = new Example(entityClass);
        example.createCriteria()
                .andIn(UserRoleRel.ROLE_ID, roleIdList);
        List<UserRoleRel> userRoleRelList = userRoleRelMapper.selectByExample(example);
        Set<String> userIds = userRoleRelList.stream().map(UserRoleRel::getUserId).collect(Collectors.toSet());
        return CollectionUtils.isNotEmpty(userRoleRelList) ?
                new ArrayList<>(userIds) : new ArrayList<>(0);
    }

    public List<String> listAllRoleIdListByUserId(String userId) {
        Assert.notEmpty(userId, "userId can not be empty!");
        Example example = new Example(entityClass);
        example.selectProperties(UserRoleRel.ROLE_ID);
        example.createCriteria()
                .andEqualTo(UserRoleRel.USER_ID, userId);
        List<UserRoleRel> userRoleRelList = userRoleRelMapper.selectByExample(example);
        return CollectionUtils.isEmpty(userRoleRelList) ? new ArrayList<>(0) :
                userRoleRelList.stream().map(UserRoleRel::getRoleId).collect(Collectors.toList());
    }
}
