package com.purchase.uc.mapper;

import com.purchase.uc.model.User;
import com.purchase.uc.model.UserRoleRel;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * UserRoleRelMapper mapper接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
public interface UserRoleRelMapper extends QguBaseMapper<UserRoleRel> {
    /**
     * 根据查询条件，分页查询角色下的人员信息列表
     *
     * @param roleRel 查询条件对象
     * @param page    分页查询对象
     * @return 人员信息列表
     */
    List<User> searchUser(@Param("roleRel") UserRoleRel roleRel, @Param("page") Page<UserRoleRel> page);

    /**
     * 根据查询条件查询角色下的人员总数
     *
     * @param roleRel 查询条件对象
     * @return 人员总数
     */
    Integer getUserTotal(@Param("roleRel") UserRoleRel roleRel);

    /**
     * 根据角色Id列表获取角色下的人数
     *
     * @param corpCode 公司编号
     * @param roleIds  角色Id列表
     * @return 角色Id与角色下的人数映射
     */
    List<UserRoleRel> getRoleIdAndUserCntMap(@Param("corpCode") String corpCode, @Param("roleIds") List<String> roleIds);

    List<String> selectUserIdWithNoUserRole(@Param("roleId")String roleId);
}
