package com.purchase.uc.utils;

import com.purchase.uc.base.UcConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.function.Predicate;

/**
 * Created by on 2019/6/20 0020
 * <p>
 * 自定义访问对象工具类
 * <p>
 * 获取对象的IP地址等信息
 *
 * @author X-rapido
 * @author shaohuiliang
 * @since saas 基础服务
 */
public class CusAccessObjectUtil {
    private static Logger logger = LoggerFactory.getLogger(CusAccessObjectUtil.class);

    /**
     * 获取用户真实IP地址，不使用request.getRemoteAddr();的原因是有可能用户使用了代理软件方式避免真实IP地址,
     * <p>
     * 可是，如果通过了多级反向代理的话，X-Forwarded-For的值并不止一个，而是一串IP值，究竟哪个才是真正的用户端的真实IP呢？
     * 答案是取X-Forwarded-For中第一个非unknown的有效IP字符串。
     * <p>
     * 如：X-Forwarded-For：192.168.1.110, 192.168.1.120, 192.168.1.130,
     * 192.168.1.100
     * <p>
     * 用户真实IP为： 192.168.1.110
     */
    public static String getIpAddress(HttpServletRequest request) {
        Predicate<String> isEmpty = str -> str == null || str.length() == 0 || "unknown".equalsIgnoreCase(str);
        for (String headerParam : new String[]{"x-forwarded-for", "Proxy-Client-IP", "WL-Proxy-Client-IP", "HTTP_CLIENT_IP",
                "HTTP_X_FORWARDED_FOR"}) {
            String ip = request.getHeader(headerParam);
            if (!isEmpty.test(ip)) {
                return ip;
            }
        }

        return request.getRemoteAddr();
    }

    public static void logRequest(HttpServletRequest request, HttpServletResponse response) {
        //返回请求行中的资源名称
        String uri = request.getRequestURI();
        //获得客户端发送请求的完整url
        String url = request.getRequestURL().toString();
        //返回发出请求的IP地址
        String ip = request.getRemoteAddr();
        //返回请求行中的参数部分
        String params = request.getQueryString();
        //返回发出请求的客户机的主机名
        String host = request.getRemoteHost();
        //返回发出请求的客户机的端口号。
        int port = request.getRemotePort();
        if (params != null && params.contains(UcConstants.CONTEXT_KEY_PASSWORD)) {
            params = params.replaceAll("(?<=password=)\\w+", "******");
        }

        logger.info("request msg[ip:{},url:{},uri:{},params:{},host:{},post:{}]", ip, url, uri, params, host, port);
    }
}
