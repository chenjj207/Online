package com.purchase.uc.service;

import com.alibaba.fastjson.JSON;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.model.vo.AuthTreeNode;
import com.purchase.uc.utils.UcUtil;
import com.qgutech.qgyun.dev.common.utils.CommonUtils;
import com.purchase.uc.base.UcException;
import com.purchase.uc.mapper.AuthMapper;
import com.purchase.uc.model.Auth;
import com.purchase.uc.utils.UcRedisKeys;
import com.qgutech.qgyun.framework.common.context.ContextConstant;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.exception.CheckFlow;
import com.qgutech.qgyun.framework.common.utils.IDUtils;
import com.qgutech.qgyun.framework.common.utils.SqlUtil;
import com.qgutech.qgyun.framework.database.model.BaseCorpTreeModel;
import com.qgutech.qgyun.framework.database.mybatis.model.TreeNode;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import com.qgutech.qgyun.saas.client.service.SaasCorpService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.Sqls;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.purchase.uc.model.Auth.*;
import static com.qgutech.qgyun.framework.database.model.BaseCorpModel.CORP_CODE;
import static com.qgutech.qgyun.framework.database.model.BaseCorpTreeModel.P_ID;
import static com.qgutech.qgyun.framework.database.model.BaseModel.ID;

/**
 * 权限相关接口实现
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Service
@Slf4j
public class AuthService extends BaseServiceImpl<Auth> {

    @Resource
    private AuthMapper authMapper;
    @Resource
    private SaasCorpService saasCorpService;
    @Resource
    private RedisTemplate<String, String> redisTemplate;
    @Resource
    private RoleAuthRelService roleAuthRelService;

    public List<Auth> listAll(Boolean isSysAuth) {
        Example example = new Example(Auth.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        if (isSysAuth != null) {
            criteria.andEqualTo(SYS, isSysAuth);
        }

        return authMapper.selectByExample(example);
    }

    /**
     * 根据条件获取所有权限集合
     *
     * @param manage true 所有管理员权限 | false 所有学员权限
     * @return 所有符合条件的权限
     */
    public List<Auth> listAuth(Boolean manage) {
        Set<String> appCodes = saasCorpService.getAssignAppCode(ContextHandler.getCorpCode());
        if (CollectionUtils.isEmpty(appCodes) && !isDefaultSysAdmin()) {
            return new ArrayList<>(0);
        }

        Example example = new Example(Auth.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(CORP_CODE, ContextHandler.getCorpCode());
        if (CollectionUtils.isNotEmpty(appCodes)) {
            criteria.andIn(APP_CODE, appCodes);
        }

        if (manage != null) {
            criteria.andEqualTo(MANAGE, manage);
        }

        example.orderBy(SHOW_ORDER);
        return authMapper.selectByExample(example);
    }

    private boolean isDefaultSysAdmin() {
        return ContextHandler.isSuperAdmin() && ContextConstant.DEFAULT_CORP_CODE.equals(ContextHandler.getCorpCode());
    }

    /**
     * 根据条件获取所有权限集合
     *
     * @return 所有符合条件的权限
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public AuthTreeNode getAuthTree() {
        ValueOperations<String, String> forValue = redisTemplate.opsForValue();
        String authKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.AUTH_TREE;
        String value = forValue.get(authKey);
        if (StringUtils.isNoneBlank(value)) {
            return JSON.parseObject(value, AuthTreeNode.class);
        }

        AuthTreeNode rootNode = getTreeNodeFromDB();
        forValue.set(authKey, JSON.toJSONString(rootNode));
        return rootNode;
    }

    /**
     * 根据条件获取所有权限集合
     *
     * @return 所有符合条件的权限
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public void initAuthTree() {
        ValueOperations<String, String> forValue = redisTemplate.opsForValue();
        String authKey = UcRedisKeys.UC_ + ContextHandler.getCorpCode() + UcRedisKeys.AUTH_TREE;
        redisTemplate.delete(authKey);
        AuthTreeNode rootNode = getTreeNodeFromDB();
        forValue.set(authKey, JSON.toJSONString(rootNode));
    }

    private TreeNode convertNode(Auth auth) {
        TreeNode node = new TreeNode();
        node.setId(auth.getId());
        node.setCode(auth.getCode());
        node.setName(auth.getName());
        node.setPId(auth.getpId());
        return node;
    }

    /**
     * 根据管理类型获取我能管理的权限树
     *
     * @param manage 是否为管理员权限 true:管理员权限树，false:学员权限树，null:我能管理的所有权限树
     * @return 我能管理的权限树
     */
    public TreeNode getMyAuthTree(Boolean manage) {
        return getAuthTreeByUserId(ContextHandler.getUserId(), manage, false);
    }

    /**
     * 获取可见菜单
     */
    public TreeNode getAuthMenuTree() {
        return getAuthTreeByUserId(ContextHandler.getUserId(), null, true);
    }

    /**
     * 获取可见菜单
     */
    public TreeNode getAllMenuTree() {
        AuthTreeNode authTree = getAuthTree();
        dealAuthTree(authTree, true);
        return authTree;
    }

    /**
     * 根据用户Id和管理类型获取用户能管理的权限树
     *
     * @param userId 用户Id
     * @param manage 是否为管理员权限 true:管理员权限树，false:学员权限树，null:能管理的所有权限树
     * @return 用户能管理的权限树
     */
    public AuthTreeNode getAuthTreeByUserId(String userId, Boolean manage, Boolean isMenu) {
        if (StringUtils.isEmpty(userId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId not be empty!");
        }

        AuthTreeNode authTree = getAuthTree();
        if (manage != null) {
            List<AuthTreeNode> child = authTree.getChildList();
            if (CollectionUtils.isEmpty(child)) {
                return authTree;
            }

            child.removeIf(node -> !manage.equals(node.isManage()));
        }

        if (!ContextHandler.isSuperAdmin()) {
            Set<String> authIds = roleAuthRelService.geAuthIdsByUserId(userId, manage);
            if (CollectionUtils.isEmpty(authIds)) {
                return new AuthTreeNode();
            }

            Map<String, Boolean> authIdMap = authIds.stream().collect(Collectors.toMap(authId -> authId,
                    authId -> true, (a, b) -> b, () -> new HashMap<>(authIds.size())));
            setSelfCreatedAuth(authIdMap, userId);
            removeNoAuthNode(authTree.getChildList(), authIdMap);
        }

        dealAuthTree(authTree, isMenu);
        return authTree;
    }

    private void setSelfCreatedAuth(Map<String, Boolean> authIdMap, String userId) {
        List<Auth> auths = listByProperty(Auth.CREATED_BY, userId, Auth.ID);
        if (CollectionUtils.isNotEmpty(auths)) {
            auths.forEach(a -> authIdMap.put(a.getId(), true));
        }
    }

    private void dealAuthTree(AuthTreeNode authTreeNode, Boolean isMenu) {
        List<AuthTreeNode> childList = authTreeNode.getChildList();
        if (CollectionUtils.isEmpty(childList)) {
            return;
        }

        List<AuthTreeNode> buttonList = new ArrayList<>(childList.size());
        authTreeNode.setButtonList(buttonList);
        Iterator<AuthTreeNode> iterator = childList.iterator();
        while (iterator.hasNext()) {
            AuthTreeNode node = iterator.next();
            if (BooleanUtils.isTrue(node.getHide()) && isMenu) {
                iterator.remove();
            } else if (!node.getMenu()) {
                buttonList.add(node);
                iterator.remove();
            }

            dealAuthTree(node, isMenu);
        }
    }

    private void removeNoAuthNode(List<AuthTreeNode> child, Map<String, Boolean> authIdMap) {
        if (CollectionUtils.isEmpty(child)) {
            return;
        }

        for (Iterator<AuthTreeNode> iterator = child.iterator(); iterator.hasNext(); ) {
            AuthTreeNode node = iterator.next();
            if (BooleanUtils.isNotTrue(authIdMap.get(node.getId()))) {
                iterator.remove();
                continue;
            }

            removeNoAuthNode(node.getChildList(), authIdMap);
        }
    }

    public List<Auth> getAuthList(Collection<String> authIds, String... properties) {
        CheckFlow.start().isNotEmpty(authIds);
        Example example = new Example(Auth.class);
        example.selectProperties(properties).createCriteria()
                .andEqualTo(Auth.CORP_CODE, ContextHandler.getCorpCode())
                .andIn(Auth.ID, authIds);
        return authMapper.selectByExample(example);
    }

    /**
     * 该方法用于刷新权限树缓存
     */
    public void putAuthTreeToRedis(String corpCode) {
        AuthTreeNode rootNode = getTreeNodeFromDB();
        ValueOperations<String, String> forValue = redisTemplate.opsForValue();
        String authKey = UcRedisKeys.UC_ + corpCode + UcRedisKeys.AUTH_TREE;
        forValue.set(authKey, JSON.toJSONString(rootNode));
    }

    private AuthTreeNode getTreeNodeFromDB() {
        List<Auth> authList = listAuth(null);
        return UcUtil.getAuthTreeFromList(authList);
    }

    /**
     * 初始化公司菜单权限，已分配的菜单权限不会删除，通过分配的应用来控制是否拥有菜单权限
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void init() {
        String corpCode = ContextHandler.getCorpCode();
        if (StringUtils.isBlank(corpCode)) {
            throw new UcException(UcErrorCode.SYSTEM_ERROR, "init auth data is error!");
        }

        if (ContextConstant.DEFAULT_CORP_CODE.equals(corpCode)) {
            return;
        }

        //initAuthTree();
        List<Auth> defaultAuths = getDefaultAuth(corpCode);
        CheckFlow.start(UcErrorCode.AUTH_NOT_EXIST).isNotEmpty(defaultAuths);
        Map<String, Auth> existAuthCodeMap = getExistAuthCodeMap();
        dealAuthIdAndSave(defaultAuths, existAuthCodeMap);
        putAuthTreeToRedis(corpCode);
    }

    private void dealAuthIdAndSave(List<Auth> defaultAuths, Map<String, Auth> existAuthCodeMap) {
        int size = defaultAuths.size();
        List<Auth> newAuths = new ArrayList<>(size);
        List<Auth> updateAuths = new ArrayList<>(size);
        List<Auth> existAuthList = listAll(null);
        List<String> deleteAuthIds = new ArrayList<>(size);
        Map<String, Auth> defaultIdAndNewAuthMap = new HashMap<>(size);
        for (Auth defaultAuth : defaultAuths) {
            String code = defaultAuth.getCode();
            if (StringUtils.isEmpty(code)) {
                continue;
            }

            Auth dbAuth = existAuthCodeMap.get(code);
            if (dbAuth != null) {
                defaultIdAndNewAuthMap.put(defaultAuth.getId(), dbAuth);
                dbAuth.setShowOrder(defaultAuth.getShowOrder());
                dbAuth.setLinkType(defaultAuth.getLinkType());
                dbAuth.setMenu(defaultAuth.getMenu());
                dbAuth.setRouteUrl(defaultAuth.getRouteUrl());
                dbAuth.setHide(defaultAuth.getHide());
                dbAuth.setIcon(defaultAuth.getIcon());
                dbAuth.setManage(defaultAuth.getManage());
                dbAuth.setUrl(defaultAuth.getUrl());
                dbAuth.setOpenWay(defaultAuth.getOpenWay());
                dbAuth.setName(defaultAuth.getName());
                dbAuth.setAppCode(defaultAuth.getAppCode());
                updateAuths.add(dbAuth);
                continue;
            }

            newAuths.add(defaultAuth);
            defaultIdAndNewAuthMap.put(defaultAuth.getId(), defaultAuth);
            defaultAuth.setId(IDUtils.getUUID19());
        }

        List<String> defaultAuthCodes = defaultAuths.stream().map(Auth::getCode).collect(Collectors.toList());
        List<String> deleteExistAuthIds = existAuthCodeMap.values().stream()
                .filter(existAuth -> !defaultAuthCodes.contains(existAuth.getCode()))
                .map(Auth::getId).collect(Collectors.toList());
        log.info("need delete authIds:{}", deleteAuthIds);
        log.info("need delete auth size:{}", deleteAuthIds.size());
        if (CollectionUtils.isNotEmpty(deleteExistAuthIds)) {
            log.info("need delete auth is not empty");
            batchDelete(deleteExistAuthIds);
        }

        if (CollectionUtils.isNotEmpty(updateAuths)){
            batchUpdate(updateAuths);
        }

        if (CollectionUtils.isEmpty(newAuths)) {
            // 没有新增的权限，无需处理
            return;
        }

        log.info("有新增的权限，需处理");

        existAuthCodeMap.values().forEach(a -> defaultIdAndNewAuthMap.put(a.getId(), a));
        dealParentIdAndIdPath(newAuths, defaultIdAndNewAuthMap);
        if (CollectionUtils.isEmpty(newAuths)) {
            // 没有新增的权限，无需处理
            return;
        }

        batchInsert(newAuths);
    }

    private void dealParentIdAndIdPath(List<Auth> newAuths, Map<String, Auth> defaultIdAndNewAuthMap) {
        newAuths.sort(Comparator.comparingInt(o -> o.getIdPath().length()));
        for (Iterator<Auth> iterator = newAuths.iterator(); iterator.hasNext(); ) {
            Auth newAuth = iterator.next();
            String parentId = newAuth.getpId();
            if ("*".equals(parentId)) {
                newAuth.setIdPath(newAuth.getId());
                continue;
            }

            Auth parentAuth = defaultIdAndNewAuthMap.get(parentId);
            if (parentAuth == null) {
                iterator.remove();
                continue;
            }

            newAuth.setpId(parentAuth.getId());
            String parentIdPath = parentAuth.getIdPath();
            newAuth.setIdPath(parentIdPath + "." + newAuth.getId());
        }
    }

    private Map<String, Auth> getExistAuthCodeMap() {
        List<Auth> authList = listAll(null);
        if (CollectionUtils.isEmpty(authList)) {
            return Collections.emptyMap();
        }

        return authList.stream().filter(auth -> StringUtils.isNotEmpty(auth.getCode()))
                .collect(Collectors.toMap(BaseCorpTreeModel::getCode, auth -> auth,
                        (a, b) -> b, () -> new HashMap<>(authList.size())));
    }

    private List<Auth> getDefaultAuth(String corpCode) {
        return CommonUtils.syncExecuteWithNewThread(ContextConstant.DEFAULT_CORP_CODE, s -> {
            List<Auth> authList = listAll(true);
            if (CollectionUtils.isEmpty(authList)) {
                return Collections.emptyList();
            }

            LocalDateTime now = LocalDateTime.now();
            for (Auth auth : authList) {
                auth.setCorpCode(corpCode);
                auth.setCreatedAt(now);
                auth.setUpdatedAt(now);
            }

            return authList;
        });
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String save(Auth auth) {
        checkAuth(auth);
        String pId = auth.getpId();
        if (StringUtils.isNotEmpty(pId) && !"*".equals(pId)) {
            Auth parentAuth = getById(pId);
            auth.setIdPath(parentAuth.getIdPath());
        } else {
            auth.setpId("*");
        }

        boolean isNew = false;
        String authId = auth.getId();
        if (StringUtils.isEmpty(authId)) {
            isNew = true;
            authId = IDUtils.getUUID19();
            auth.setId(authId);
            auth.setShowOrder(getMaxShowOrder(pId) + 1.0f);
        }

        String idPath = auth.getIdPath();
        idPath = StringUtils.isEmpty(idPath) ? authId : (idPath + "." + authId);
        auth.setIdPath(idPath);
        if (isNew) {
            insert(auth);
        } else {
            update(auth);
        }

        putAuthTreeToRedis(ContextHandler.getCorpCode());
        return authId;
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void saveOrUpdateForOnline(Auth auth) {
        CheckFlow.start().isNotNull(auth)
                .isNotEmpty(auth.getCode())
                .isNotEmpty(auth.getAppCode());
        AuthTreeNode authTree = getAuthTree();
        List<AuthTreeNode> childList = authTree.getChildList();
        float maxShowOrder = getMaxShowOrder("*");
        auth.setShowOrder(maxShowOrder + 10);
        Map<String, String> dbCodeAndIdMap = new HashMap<>();
        getAllDBCodeAndIdMap(childList, dbCodeAndIdMap);
        List<Auth> newAuthList = new ArrayList<>();
        List<Auth> updateAuthList = new ArrayList<>();
        setAuthId(auth, newAuthList, updateAuthList, "*", null, dbCodeAndIdMap);
        auth.setIdPath(auth.getId());
        filterAuthAndSetIdAndOrder(auth, newAuthList, updateAuthList, dbCodeAndIdMap);
        if (CollectionUtils.isNotEmpty(updateAuthList)) {
            batchUpdate(updateAuthList);
        }

        if (CollectionUtils.isNotEmpty(newAuthList)) {
            batchInsert(newAuthList);
        }

        putAuthTreeToRedis(ContextHandler.getCorpCode());
    }

    private void setAuthId(Auth auth, List<Auth> newAuthList, List<Auth> updateAuthList,
                           String parentId, String parentIdPath, Map<String, String> dbCodeAndIdMap) {
        String dbAuthId = dbCodeAndIdMap.get(auth.getCode());
        if (StringUtils.isEmpty(dbAuthId)) {
            auth.setId(IDUtils.getUUID19());
            newAuthList.add(auth);
        } else {
            auth.setId(dbAuthId);
            updateAuthList.add(auth);
        }

        auth.setpId(parentId);
        auth.setIdPath(parentIdPath + "." + auth.getId());
    }

    private void filterAuthAndSetIdAndOrder(Auth auth, List<Auth> newAuthList,
                                            List<Auth> updateAuthList,
                                            Map<String, String> dbCodeAndIdMap) {
        List<Auth> childList = auth.getChildList();
        if (CollectionUtils.isEmpty(childList)) {
            return;
        }

        float showOrder = 0F;
        for (Auth childAuth : childList) {
            childAuth.setShowOrder(showOrder++);
            setAuthId(childAuth, newAuthList, updateAuthList, auth.getId(), auth.getIdPath(), dbCodeAndIdMap);
            filterAuthAndSetIdAndOrder(childAuth, newAuthList, updateAuthList, dbCodeAndIdMap);
        }
    }

    private void getAllDBCodeAndIdMap(List<AuthTreeNode> childList, Map<String, String> codeAndIdMap) {
        if (CollectionUtils.isEmpty(childList)) {
            return;
        }

        for (AuthTreeNode treeNode : childList) {
            codeAndIdMap.put(treeNode.getCode(), treeNode.getId());
            getAllDBCodeAndIdMap(treeNode.getChildList(), codeAndIdMap);
        }
    }

    private void findChildTreeNode(AuthTreeNode treeNode, Map<String, AuthTreeNode> codeAndNodeMap) {
        List<AuthTreeNode> childList = treeNode.getChildList();
        if (CollectionUtils.isEmpty(childList)) {
            return;
        }

        for (AuthTreeNode node : childList) {
            codeAndNodeMap.put(node.getCode(), node);
            findChildTreeNode(node, codeAndNodeMap);
        }
    }

    private void setChildAuthIdAndOrder(Auth auth, List<Auth> insertAuths) {
        List<Auth> authChildList = auth.getChildList();
        if (CollectionUtils.isEmpty(authChildList)) {
            return;
        }

        float showOrder = 0F;
        String parentId = auth.getId();
        String idPath = auth.getIdPath();
        for (Auth childAuth : authChildList) {
            childAuth.setId(IDUtils.getUUID19());
            childAuth.setpId(parentId);
            childAuth.setIdPath(idPath + "." + childAuth.getId());
            childAuth.setShowOrder(showOrder++);
            insertAuths.add(childAuth);
            setChildAuthIdAndOrder(childAuth, insertAuths);
        }
    }

    private void checkAuth(Auth auth) {
        if (auth == null) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM);
        }

        String code = auth.getCode();
        if (StringUtils.isEmpty(code)) {
            throw new UcException(UcErrorCode.AUTH_CODE_EMPTY);
        }

        if (StringUtils.isEmpty(auth.getAppCode())) {
            throw new UcException(UcErrorCode.AUTH_APP_CODE_EMPTY);
        }

        Auth dbAuth = getByProperty(Auth.CODE, code, Auth.ID);
        if (dbAuth != null && !dbAuth.getId().equals(auth.getId())) {
            throw new UcException(UcErrorCode.CODE_EXIST);
        }
    }

    private float getMaxShowOrder(String id) {
        Example example = new Example(Auth.class);
        example.setOrderByClause(" show_order desc limit 1");
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(Auth.CORP_CODE, ContextHandler.getCorpCode());
        criteria.andEqualTo(Auth.P_ID, id);
        Auth auth = authMapper.selectOneByExample(example);
        return auth == null ? 0f : auth.getShowOrder();
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void delete(String id) {
        if (StringUtils.isEmpty(id)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM);
        }

        if (checkHasChild(id)) {
            throw new UcException(UcErrorCode.AUTH_DELETE_CHILD_ERROR);
        }

        super.delete(id);
        putAuthTreeToRedis(ContextHandler.getCorpCode());
    }

    private boolean checkHasChild(String pId) {
        Example example = new Example(Auth.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo(Auth.CORP_CODE, ContextHandler.getCorpCode());
        criteria.andEqualTo(Auth.P_ID, pId);
        return authMapper.selectCountByExample(example) > 0;
    }

    /**
     * 权限树，节点移动
     *
     * @param id     移动的节点
     * @param pId    移动的目标父节点
     * @param preId  移动的目标前一个节点
     * @param nextId 移动的目标后一个节点
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void move(String id, String pId, String preId, String nextId) {
        if (StringUtils.isEmpty(id) || StringUtils.isEmpty(pId)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM);
        }

        Auth auth = getById(id, Auth.ID, Auth.ID_PATH);
        if (auth == null) {
            throw new UcException(UcErrorCode.AUTH_NOT_EXIST);
        }

        String idPath = auth.getIdPath();
        if (StringUtils.isEmpty(pId) || "*".equals(pId)) {
            auth.setpId("*");
            auth.setIdPath(id);
        } else {
            Auth parentAuth = getById(pId);
            if (parentAuth == null) {
                throw new UcException(UcErrorCode.AUTH_PARENT_NOT_EXIST);
            }

            auth.setpId(pId);
            auth.setIdPath(parentAuth.getIdPath() + "." + id);
        }

        float order = 1;
        float curOrder = 0;
        Auth next = null;
        if (StringUtils.isNotEmpty(preId)) {
            Auth pre = getById(preId, Auth.SHOW_ORDER);
            if (pre != null) {
                curOrder = pre.getShowOrder();
                order = curOrder + 1;
            }
        }

        if (StringUtils.isNotEmpty(nextId)) {
            next = getById(nextId, Auth.SHOW_ORDER, ID);
            if (next != null) {
                curOrder = next.getShowOrder();
                order = curOrder;
            }
        }

        if (curOrder != 0) {
            List<Auth> updateAuthList = getGenThenAuthList(pId, curOrder);
            if (CollectionUtils.isNotEmpty(updateAuthList)) {
                if (next != null) {
                    updateAuthList.add(next);
                }

                updateAuthList.forEach(v -> v.setShowOrder(v.getShowOrder() + 1));
                batchUpdate(updateAuthList);
            }
        }

        auth.setShowOrder(order);
        update(auth);
        updateChildAuth(id, idPath, auth.getIdPath());
        putAuthTreeToRedis(ContextHandler.getCorpCode());
    }

    private List<Auth> getGenThenAuthList(String pId, Float showOrder) {
        Example example = new Example(entityClass);
        example.selectProperties(ID, SHOW_ORDER);
        example.createCriteria()
                .andGreaterThan(SHOW_ORDER, showOrder)
                .andEqualTo(P_ID, pId);
        return authMapper.selectByExample(example);
    }

    /**
     * 更新子节点的idPath
     *
     * @param pId       父节点
     * @param oldIdPath 父节点未更新前的idPath
     * @param newIdPath 父节点更新后的idPath
     */
    private void updateChildAuth(String pId, String oldIdPath, String newIdPath) {
        List<Auth> childAuth = getChildAuth(pId);
        if (CollectionUtils.isEmpty(childAuth)) {
            return;
        }

        childAuth.forEach(a -> {
            String idPath = a.getIdPath();
            idPath = idPath.replace(oldIdPath, newIdPath);
            a.setIdPath(idPath);
        });

        batchUpdate(childAuth);
    }

    private List<Auth> getChildAuth(String pId) {
        Example example = new Example(Auth.class);
        Example.Criteria criteria = example.selectProperties(Auth.ID, Auth.ID_PATH).createCriteria();
        criteria.andEqualTo(Auth.CORP_CODE, ContextHandler.getCorpCode());
        criteria.andNotEqualTo(Auth.ID, pId);
        criteria.andLike(Auth.ID_PATH, SqlUtil.asLike(pId));
        return authMapper.selectByExample(example);
    }

    /**
     * 根据权限编号，禁用权限菜单
     *
     * @return 菜单对应的appCode
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public List<String> disabledMenu(List<String> authCodes) {
        CheckFlow.start().isNotEmpty(authCodes);
        List<Auth> auths = listByCode(authCodes);
        if (CollectionUtils.isEmpty(auths)) {
            return Collections.emptyList();
        }

        auths.forEach(a -> a.setHide(true));
        batchUpdate(auths);
        putAuthTreeToRedis(ContextHandler.getCorpCode());
        return auths.stream().map(Auth::getAppCode).collect(Collectors.toList());
    }

    private List<Auth> listByCode(List<String> authCodes) {
        Example example = Example.builder(Auth.class)
                .select(Auth.ID, Auth.HIDE, APP_CODE)
                .where(Sqls.custom()
                        .andEqualTo(Auth.CORP_CODE, ContextHandler.getCorpCode())
                        .andIn(Auth.CODE, authCodes))
                .build();
        return authMapper.selectByExample(example);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public void initAuth() {
        init();
        roleAuthRelService.refreshRoleAuthCache();
    }
}
