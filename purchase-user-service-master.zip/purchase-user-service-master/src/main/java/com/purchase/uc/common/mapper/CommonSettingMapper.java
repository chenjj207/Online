package com.purchase.uc.common.mapper;

import com.purchase.uc.common.model.CommonSetting;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 * 公共设置Mapper接口
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年05月23日10:09:19
 */
public interface CommonSettingMapper extends QguBaseMapper<CommonSetting> {

}
