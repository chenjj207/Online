package com.purchase.uc.model.vo;

import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * 人员相关查询条件
 */
@Getter
@Setter
@ToString
@ApiModel(value = "UserCondition", description = "人员相关查询条件")
public class UserCondition {
    /**
     * 人员工号/姓名/用户名/手机/组织名称
     */
    @ApiModelProperty(value = "人员工号/姓名/用户名/手机/组织名称,scopeType为ORG时：ALL ORG POSITION GROUP")
    private String keywords;

    /**
     * 角色Id列表
     */
    @ApiModelProperty(value = "角色Id列表")
    private List<String> roleIds;

    /**
     * 公司编号，区分租户
     */
    @ApiModelProperty(value = "公司编号，区分租户", hidden = true)
    private String corpCode;

    /**
     * 当前页
     */
    @ApiModelProperty(value = "当前页")
    private Integer pageNum;

    /**
     * 分页大小
     */
    @ApiModelProperty(value = "分页大小")
    private Integer pageSize;

    /**
     * 分页大小
     */
    @ApiModelProperty(value = "分页对象", hidden = true)
    public <T> Page<T> getPage() {
        Page<T> page = new Page<>();
        if (null != pageNum) {
            page.setPageNum(pageNum);
        }

        if (null != pageSize) {
            page.setPageSize(pageSize);
        }

        return page;
    }
}
