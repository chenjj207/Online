package com.purchase.uc.client.wx.entity;

import com.alibaba.fastjson.JSONObject;
import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcException;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(description = "[微信集群]统一返回的结果集")
public class WxClusterResultInfo<T> {

    @ApiModelProperty("结果编码,200为成功,其它失败")
    private int code;

    private boolean success;

    @ApiModelProperty("访问结果描述")
    private String msg;

    @ApiModelProperty("返回的结果")
    private T data;

    public boolean isSucc() {
        return code == 200 ? true : false;
    }

    public T getData() {
        return data;
    }

    public T getData(boolean valid) {
        if (!isSucc() && valid) {
            JSONObject jsonObject = new JSONObject(true) {{
                put("code", code);
                put("msg", msg);
            }};
//            ZydException.re(!isSucc() && valid, "[微信集群] " + jsonObject.toJSONString());
            throw new UcException(UcErrorCode.SYSTEM_ERROR, "[微信集群] " + jsonObject.toJSONString());
        }
        return getData();
    }

    @Override
    public String toString() {
        return "返回编码：" + code + ", 返回描述：" + msg;
    }

}
