package com.purchase.uc.model.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.metadata.BaseRowModel;
import com.purchase.uc.model.Supplier;
import lombok.Data;

/**
 * @author czh
 * @since 2024-10-12
 */
@Data
public class SupplierExcelVO extends BaseRowModel {

    @ExcelProperty(value = "供应商名称")
    private String name;
    @ExcelProperty(value = "类型")
    private String category;
    @ExcelProperty(value = "联系人")
    private String contacts;
    @ExcelProperty(value = "登录手机")
    private String code;
    @ExcelProperty(value = "初始密码")
    private String password;
    @ExcelProperty(value = "税号")
    private String identifyUmber;
    @ExcelProperty(value = "所在地区")
    private String region;
    @ExcelProperty(value = "详细地址")
    private String address;
    @ExcelProperty(value = "所属子公司")
    private String shortName;
    @ExcelProperty(value = "账号启停用")
    private String accountStatus;
    @ExcelProperty(value = "创建时间")
    private String createdAt;
    @ExcelProperty(value = "最后修改时间")
    private String updatedAt;

    public void setRegion(Supplier supplier) {
        String province = supplier.getProvinceName() != null ? supplier.getProvinceName() : "";
        String city = supplier.getCityName() != null ? supplier.getCityName() : "";
        String county = supplier.getCountyName() != null ? supplier.getCountyName() : "";
        String street = supplier.getStreetName() != null ? supplier.getStreetName() : "";
        String region = String.join(" ", province, city, county, street).trim();
        this.region = region;
    }

}
