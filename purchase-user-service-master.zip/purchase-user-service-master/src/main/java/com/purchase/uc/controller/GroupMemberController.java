package com.purchase.uc.controller;

import com.purchase.uc.model.vo.GroupMemberSearch;
import com.purchase.uc.model.vo.UserComponent;
import com.qgutech.qgyun.dev.common.model.vo.ComponentCondition;
import com.purchase.uc.model.GroupMember;
import com.purchase.uc.model.User;
import com.purchase.uc.service.GroupMemberService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.framework.common.utils.LogUtil;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.starter.web.swagger.annotations.ParamHide;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * GroupMember Controller 接口
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@RestController
@RequestMapping(value = "/groupMember")
@Api(value = "GroupMember接口", tags = {"GroupMember接口"})
public class GroupMemberController extends SelectComponentBaseController {
    private Logger LOG = LogUtil.getLogger(GroupMemberController.class);

    @Resource
    private GroupMemberService groupMemberService;

    @RequestMapping(value = "/search", method = RequestMethod.GET)
    @ApiOperation(value = "获取分页，已选选人组件通用")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "keywords", value = "人员工号/姓名/用户名/手机", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "groupId", value = "群组ID", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "source", value = "人员来源：APPOINT/DYNAMIC", dataType = "String", paramType =
                    "query"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页大小", dataType = "Integer", paramType = "query")
    })
    public JsonResult<Page<User>> search(@ParamHide GroupMemberSearch memberSearch, @ParamHide Page<User> page) {
        page = groupMemberService.search(memberSearch, page);
        return new JsonResult<>(true, "查询成功", page);
    }

    @RequestMapping(value = "/batchInsert", method = RequestMethod.POST)
    @ApiOperation(value = "批量新增")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "groupId", value = "群组ID", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "source", value = "人员来源 APPOINT(指定)/DYNAMIC(动态群组)", dataType = "String",
                    paramType = "query"),
    })
    public JsonResult batchInsert(String groupId, String source, @RequestBody List<String> userIds) {
        try {
            groupMemberService.batchInsert(groupId, source, userIds);
            return new JsonResult(true, "添加成功");
        } catch (Exception e) {
            LOG.error("保存群组人员失败！", e);
            return new JsonResult(false, "添加失败");
        }
    }

    @RequestMapping(value = "/delByGroupId", method = RequestMethod.POST)
    @ApiOperation(value = "根据传入群组ID删除对应指定群组的人员")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "groupId", value = "群组ID", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "source", value = "人员来源 APPOINT(指定)/DYNAMIC(动态群组)", dataType = "String",
                    paramType = "query"),
    })
    public JsonResult<String> batchDelete(String groupId, String source, @RequestBody List<String> userIds) {
        groupMemberService.batchDelete(groupId, source, userIds);
        return new JsonResult<>(true, "删除成功");
    }

    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ApiOperation(value = "根据传入群组ID删除对应指定群组的人员")
    public JsonResult<String> delete(@RequestBody GroupMember member) {
        groupMemberService.batchDelete(member.getGroupId(), member.getSource(), member.getUserIds());
        return new JsonResult<>(true, "删除成功");
    }

    @Override
    public JsonResult<String> addUsers(@RequestBody ComponentCondition condition) {
        groupMemberService.addUsers(condition);
        return new JsonResult<>(true, "操作成功");
    }

    @Override
    public JsonResult<String> removeAllUsers(@RequestBody ComponentCondition condition) {
        groupMemberService.removeAllUsers(condition);
        return new JsonResult<>(true, "操作成功");
    }

    @Override
    public JsonResult<String> removeUsers(@RequestBody ComponentCondition condition) {
        groupMemberService.removeUsers(condition);
        return new JsonResult<>(true, "操作成功");
    }

    @Override
    public JsonResult<List<String>> listSelectedUserId(@RequestBody ComponentCondition condition) {
        List<String> list = groupMemberService.listSelectedUserId(condition);
        return new JsonResult<>(true, "操作成功", list);
    }

    @Override
    public JsonResult<Page<UserComponent>> searchSelectedUser(@RequestBody ComponentCondition condition) {
        Page<UserComponent> page = groupMemberService.searchSelectedUser(condition);
        return new JsonResult<>(true, "操作成功", page);
    }

    @Override
    public JsonResult<Page<String>> searchSelectedUserId(@RequestBody ComponentCondition condition) {
        Page<String> page = groupMemberService.searchSelectedUserId(condition);
        return new JsonResult<>(true, "操作成功", page);
    }
}
