package com.purchase.uc.saas;


import com.purchase.uc.service.AuthService;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.common.utils.LogUtil;
import com.qgutech.qgyun.saas.client.event.BaseSaasEventProcess;
import com.qgutech.qgyun.saas.client.model.SaasEvent;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author niming
 * @since 2020/10/15 0015
 */
@Component
public class RegisterAppProcess extends BaseSaasEventProcess {

    private final Logger log = LogUtil.getLogger(this.getClass());
    @Resource
    private AuthService authService;

    @Override
    protected String type() {
        return "REGISTER_APP";
    }

    @Override
    protected void process(SaasEvent saasEvent) {
        log.info("接收公司【{}】注册应用事件", saasEvent.getCorpCode());
        ContextHandler.setCorpCode(saasEvent.getCorpCode());
        try {
            authService.init();
            authService.putAuthTreeToRedis(saasEvent.getCorpCode());
        } catch (Exception e) {
            log.error("公司【{}】应用注册事件执行失败", saasEvent.getCorpCode());
            log.error("失败异常", e);
        }
    }
}
