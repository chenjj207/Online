package com.purchase.uc.model.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * 人员导入模板
 *
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Data
public class ImportExcelUser extends ExcelUser {

    @NotNull
    @ExcelProperty(value = "部门编号", index = 0)
    private String orgCode;

    @NotNull
    @ExcelProperty(value = "部门名称", index = 1)
    private String orgNamePath;

    @ExcelProperty(value = "岗位类别", index = 2)
    private String positionCategory;

    @ExcelProperty(value = "岗位编号", index = 3)
    private String positionCode;

    @ExcelProperty(value = "岗位名称", index = 4)
    private String positionName;

    @NotNull
    @ExcelProperty(value = "工号", index = 5)
    private String code;

    @NotNull
    @ExcelProperty(value = "姓名", index = 6)
    private String name;

    @NotNull
    @ExcelProperty(value = "用户名", index = 7)
    private String loginName;

    @ExcelProperty(value = "隶属上级工号", index = 8)
    private String leaderCode;

    @ExcelProperty(value = "隶属上级姓名", index = 9)
    private String leaderName;

    @ExcelProperty(value = "邮箱", index = 10)
    private String email;

    @ExcelProperty(value = "手机", index = 11)
    private String mobile;

    /**
     * 性别(MALE：男，FEMALE：女，SECRET：保密)
     */
    @ExcelProperty(value = "性别", index = 12)
    private String sex;

    @ExcelProperty(value = "身份证号", index = 13)
    private String idCard;

    @ExcelProperty(value = "扩展信息1", index = 14)
    private String ext1;

    @ExcelProperty(value = "扩展信息2", index = 15)
    private String ext2;

    @ExcelProperty(value = "扩展信息3", index = 16)
    private String ext3;

    private String positionId;
    private String orgId;
    private String leaderId;
    private String id;
    private String status;

}
