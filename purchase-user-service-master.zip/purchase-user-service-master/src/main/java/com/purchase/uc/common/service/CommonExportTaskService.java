package com.purchase.uc.common.service;

import com.purchase.uc.base.UcErrorCode;
import com.purchase.uc.base.UcConstants;
import com.purchase.uc.base.UcException;
import com.purchase.uc.common.mapper.CommonExportTaskMapper;
import com.purchase.uc.common.model.CommonExportTask;
import com.qgutech.qgyun.framework.common.context.ContextHandler;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.service.BaseServiceImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * 公共异步导出任务Service服务类
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年05月22日10:52:06
 */
@Service
public class CommonExportTaskService extends BaseServiceImpl<CommonExportTask> {

    @Resource
    private CommonExportTaskMapper commonExportTaskMapper;

    /**
     * 根据创建人和导出类型得到最近生成的可见的一个任务
     *
     * @param userId     创建人
     * @param exportType 导出类型
     * @return 导出任务
     * @throws UcException 当userId或者exportType为空时
     */
    @Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
    public CommonExportTask getFinalExportByOptUserId(String userId, String exportType) {
        if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(exportType)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "userId and exportType not be empty!");
        }

        Example example = new Example(CommonExportTask.class);
        example.createCriteria()
                .andEqualTo(CommonExportTask.CORP_CODE, ContextHandler.getCorpCode())
                .andEqualTo(CommonExportTask.EXPORT_TYPE, exportType)
                .andEqualTo(CommonExportTask.CREATED_BY, userId);
        example.orderBy(CommonExportTask.START_TIME).desc();
        Page<CommonExportTask> pageInfo = new Page<>();
        pageInfo.setPageSize(1);
        Page<CommonExportTask> page = search(example, pageInfo);
        List<CommonExportTask> list = page.getList();
        return CollectionUtils.isEmpty(list) ? null : list.get(0);
    }


    /**
     * 根据导出任务的主键id更新对应任务的状态和生成的文件Id
     *
     * @param id     任务id
     * @param status 要更新的状态
     * @param fileId 要更新的文件Id，可为空
     * @throws UcException 当id或者status为空时
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public int updateStatusAndFileId(String id, String status, String fileId) {
        if (StringUtils.isEmpty(id) || StringUtils.isEmpty(status)) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "id and status not be empty!");
        }

        CommonExportTask exportTask = new CommonExportTask();
        exportTask.setId(id);
        exportTask.setStatus(status);
        exportTask.setFileId(fileId);
        exportTask.setFinishTime(new Date());
        return commonExportTaskMapper.updateByPrimaryKeySelective(exportTask);
    }

    /**
     * 保存异步任务信息
     *
     * @param exportTask 异步任务
     * @return 主键Id
     * @throws UcException 当exportTask为null时
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
    public String save(CommonExportTask exportTask) {
        if (exportTask == null) {
            throw new UcException(UcErrorCode.ILLEGAL_PARAM, "id and status not be empty!");
        }

        exportTask.setStatus(UcConstants.STATUS_RUNNING);
        exportTask.setStartTime(new Date());
        return insert(exportTask);
    }

}
