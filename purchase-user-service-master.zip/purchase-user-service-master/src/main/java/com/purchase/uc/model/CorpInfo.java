package com.purchase.uc.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpModel;
import com.qgutech.qgyun.framework.database.mybatis.handler.JsonTypeHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.ibatis.type.JdbcType;
import tk.mybatis.mapper.annotation.ColumnType;

import javax.persistence.Table;
import java.util.Map;

/**
 * 公司信息 model
 *
 * @author auto
 * @version 1.0
 * @since 2021-04-02 10:35:26
 */
@Getter
@Setter
@ToString
@ApiModel(value = "CorpInfo", description = "公司信息")
@Table(name = "t_saas_corp_info")
public class CorpInfo extends BaseCorpModel {

    public static final String CORP_ID = "corpId";
    public static final String CODE = "code";
    public static final String NAME = "name";
    public static final String STATUS = "status";
    public static final String ADDRESS = "address";
    public static final String CORP_PROVINCE = "corpProvince";
    public static final String CORP_CITY = "corpCity";
    public static final String AREA_CODE = "areaCode";
    public static final String EXPECT_NUM = "expectNum";
    public static final String INDUSTRY_ID = "industryId";
    public static final String CONTACT = "contact";
    public static final String CONTACT_MOBILE = "contactMobile";
    public static final String CONTACT_EMAIL = "contactEmail";
    public static final String ENTERPRISE_NATURE = "enterpriseNature";
    public static final String ENTERPRISE_SCALE = "enterpriseScale";
    public static final String SOURCE = "source";
    public static final String DOMAIN_NAME = "domainName";
    public static final String CORP_TYPE = "corpType";
    public static final String PLATFORM_TYPE = "platformType";
    public static final String INSTITUTION_NAME = "institutionName";
    public static final String AREA = "area";
    public static final String INSTITUTION_TYPE = "institutionType";
    public static final String EXT_CONFIG = "extConfig";

    /**
     * 公司编码
     */
    @ApiModelProperty(value = "公司编码")
    private String code;
    /**
     * 公司编码
     */
    @ApiModelProperty(value = "公司编码")
    private String corpId;

    /**
     * 公司名称
     */
    @ApiModelProperty(value = "公司名称")
    private String name;

    /**
     * 状态
     */
    @ApiModelProperty(value = "状态")
    private String status;

    /**
     * 详细地址
     */
    @ApiModelProperty(value = "详细地址")
    private String address;

    /**
     * 所在地-省
     */
    @ApiModelProperty(value = "所在地-省")
    private String corpProvince;

    /**
     * 所在地-市
     */
    @ApiModelProperty(value = "所在地-市")
    private String corpCity;

    /**
     * 赠送代码
     */
    @ApiModelProperty(value = "赠送代码")
    private String areaCode;

    /**
     * 预计规模人数
     */
    @ApiModelProperty(value = "预计规模人数")
    private Integer expectNum;

    /**
     * 所属行业
     */
    @ApiModelProperty(value = "所属行业")
    private String industryId;

    /**
     * 联系人
     */
    @ApiModelProperty(value = "联系人")
    private String contact;

    /**
     * 联系人手机
     */
    @ApiModelProperty(value = "联系人手机")
    private String contactMobile;

    /**
     * 联系人邮箱
     */
    @ApiModelProperty(value = "联系人邮箱")
    private String contactEmail;

    /**
     * 企业性质
     */
    @ApiModelProperty(value = "企业性质")
    private String enterpriseNature;

    /**
     * 企业规模
     */
    @ApiModelProperty(value = "企业规模")
    private String enterpriseScale;

    /**
     * 来源
     */
    @ApiModelProperty(value = "来源")
    private String source;

    /**
     * 公司域名
     */
    @ApiModelProperty(value = "公司域名")
    private String domainName;

    /**
     * 企业类型
     */
    @ApiModelProperty(value = "企业类型")
    private String corpType;

    /**
     * 平台类型
     */
    @ApiModelProperty(value = "平台类型")
    private String platformType;

    /**
     * 所属机构名称
     */
    @ApiModelProperty(value = "所属机构名称")
    private String institutionName;

    /**
     * 所属区域
     */
    @ApiModelProperty(value = "所属区域")
    private String area;

    /**
     * 所属机构类型
     */
    @ApiModelProperty(value = "所属机构类型")
    private String institutionType;

    /**
     * 可扩展公司属性配置
     */
    @ApiModelProperty(value = "可扩展公司属性配置")
    @ColumnType(jdbcType = JdbcType.VARCHAR, typeHandler = JsonTypeHandler.class)
    private Map<String, Object> extConfig;

    /**
     * 签署项目
     */
    @ApiModelProperty(value = "签署项目")
    private String signedProject;
}
