package com.purchase.uc.utils;

import com.purchase.uc.model.User;
import com.purchase.uc.model.vo.UserComponent;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import lombok.SneakyThrows;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpHeaders;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * 组件相关公用处理类
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年06月14日18:08:58
 */
public class CompoentUtil {

    /**
     * User 转换成 UserComponent
     *
     * @param users Users
     * @return UserComponents
     */
    public static List<UserComponent> convertToUserComponent(List<User> users) {
        if (CollectionUtils.isEmpty(users)) {
            return new ArrayList<>(0);
        }

        List<UserComponent> components = new ArrayList<>(users.size());
        for (User condition : users) {
            if (condition == null) {
                continue;
            }

            UserComponent component = new UserComponent();
            BeanUtils.copyProperties(condition, component);
            // 当存在业务主键时，设置ID为业务关系表主键
            if (StringUtils.isNotBlank(condition.getRelId())) {
                component.setId(condition.getRelId());
            }

            // 设置人员ID
            component.setUserId(condition.getId());
            components.add(component);
        }

        return components;
    }

    /**
     * User分页 转换成 UserComponent分页
     *
     * @param userPage User分页对象
     * @return UserComponent分页对象
     */
    public static Page<UserComponent> convertToUserComponentPage(Page<User> userPage) {
        if (null == userPage) {
            return new Page<>();
        }

        if (CollectionUtils.isEmpty(userPage.getList())) {
            return new Page<>();
        }

        List<User> users = userPage.getList();
        List<UserComponent> userComponents = convertToUserComponent(users);
        Page<UserComponent> page = new Page<>();
        BeanUtils.copyProperties(userPage, page);
        page.setList(userComponents);

        return page;
    }

    /**
     * User分页 转换成 UserId分页
     *
     * @param userPage User分页对象
     * @return UserId分页对象
     */
    public static Page<String> convertToUserIdPage(Page<User> userPage) {
        if (null == userPage) {
            return new Page<>();
        }

        if (CollectionUtils.isEmpty(userPage.getList())) {
            return new Page<>();
        }

        List<User> users = userPage.getList();
        List<String> userIds =
                users.stream().map(User::getId).filter(StringUtils::isNotBlank).collect(Collectors.toList());
        Page<String> page = new Page<>();
        BeanUtils.copyProperties(userPage, page);
        page.setList(userIds);

        return page;
    }

    /**
     * 将excel文件写出到响应
     *
     * @param name
     * @param response
     * @param consumer
     * @param throwable
     */
    @SneakyThrows
    public static void writeExcelResponse(String name, HttpServletResponse response, Consumer<ServletOutputStream> consumer, Exception throwable) {
        try {
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
            // 这里URLEncoder.encode可以防止中文乱码
            String fileName = URLEncoder.encode(name, StandardCharsets.UTF_8.name()).replaceAll("\\+", "%20");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fileName + ".xlsx");
            consumer.accept(response.getOutputStream());
        } catch (Exception e) {
            // 重置response
            response.reset();
            throw throwable;
        }
    }
}
