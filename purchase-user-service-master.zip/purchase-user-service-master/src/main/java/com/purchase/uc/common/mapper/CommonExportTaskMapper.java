package com.purchase.uc.common.mapper;

import com.purchase.uc.common.model.CommonExportTask;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;

/**
 * 公共异步导出任务Mapper接口
 *
 * @author TangFD@HF
 * @since 2019-06-03
 */
public interface CommonExportTaskMapper extends QguBaseMapper<CommonExportTask> {

}
