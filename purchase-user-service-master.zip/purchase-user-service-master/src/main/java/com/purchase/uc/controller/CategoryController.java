package com.purchase.uc.controller;

import com.qgutech.qgyun.dev.common.controller.CommonCategoryController;
import com.purchase.uc.model.Category;
import com.purchase.uc.service.CategoryService;
import com.qgutech.qgyun.framework.common.result.JsonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * CommonTree接口
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年05月22日10:54:41
 */
@RestController
@RequestMapping(value = "/category")
@Api(value = "UcCategory接口", tags = {"UcCategory接口"})
public class CategoryController extends CommonCategoryController<Category> {
    @Resource
    private CategoryService categoryService;

    @Override
    @ApiOperation(value = "根据传入的Id，删除数据")
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public JsonResult<String> delete(@ApiParam(value = "数据源Id", required = true) @RequestParam String nodeId) {
        return categoryService.delCategory(nodeId);
    }
}
