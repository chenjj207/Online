package com.purchase.uc.model.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 用于选人控件中的人员信息
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019年06月14日15:27:03
 */
@Getter
@Setter
@ToString
public class UserComponent {
    /**
     * 主键【待选为人员主键，已选为业务主键】
     */
    private String id;

    /**
     * 人员主键【待选为空，已选为人员主键】
     */
    private String userId;

    /**
     * 姓名
     */
    private String name;

    /**
     * 员工编号
     */
    private String code;

    /**
     * 选人组件中标示该人员是否已被选中
     */
    private Boolean selected;

    public UserComponent() {
    }

    public UserComponent(String id, String name, String code) {
        this.id = id;
        this.name = name;
        this.code = code;
    }
}
