package com.purchase.uc.client.wx.entity.auth;

import com.purchase.uc.model.dto.CorpCodeDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class ScanLoginDTO extends CorpCodeDTO {

    @ApiModelProperty("授权的系统编码bm")
    @NotBlank
    private String bm;

    @ApiModelProperty("accessToken")
    @NotBlank
    private String accessToken;

    private String key;

    private String dataType;

}
