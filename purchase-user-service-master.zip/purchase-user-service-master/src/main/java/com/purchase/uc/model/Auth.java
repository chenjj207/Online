package com.purchase.uc.model;

import com.qgutech.qgyun.framework.database.model.BaseCorpTreeModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.List;

/**
 * @author auto
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
@Getter
@Setter
@ToString
@ApiModel(value = "Auth", description = "")
@Table(name = "t_uc_auth")
public class Auth extends BaseCorpTreeModel {
    public static final String APP_CODE = "appCode";
    public static final String MANAGE = "manage";
    public static final String ID_PATH = "idPath";
    public static final String SHOW_ORDER = "showOrder";
    public static final String URL = "url";
    public static final String HIDE = "hide";
    public static final String SYS = "sys";

    /**
     * 应用编号
     */
    @ApiModelProperty(value = "应用编号")
    private String appCode;

    /**
     * 是否管理端
     */
    @ApiModelProperty(value = "是否管理端")
    private Boolean manage;

    /**
     * id路径
     */
    @ApiModelProperty(value = "id路径")
    private String idPath;

    /**
     * 排序
     */
    @ApiModelProperty(value = "排序")
    private Float showOrder;

    /**
     * 权限URL
     */
    @ApiModelProperty(value = "权限URL")
    private String url;

    /**
     * routeUrl
     */
    @ApiModelProperty(value = "前端路由URL")
    private String routeUrl;

    /**
     * 打开方式（默认：default, 新窗口：window）
     */
    @ApiModelProperty(value = "打开方式（默认：default, 新窗口：window）")
    private String openWay;

    /**
     * 图标
     */
    @ApiModelProperty(value = "图标")
    private String icon;

    /**
     * 链接类型(inner:内部，outer:外部)
     */
    @ApiModelProperty(value = "链接类型(inner:内部，outer:外部)")
    private String linkType;

    /**
     * 是否为菜单
     */
    @ApiModelProperty(value = "是否为菜单")
    private Boolean menu;

    /**
     * 是否隐藏
     */
    @ApiModelProperty(value = "是否隐藏")
    private Boolean hide;

    /**
     * 是否为系统菜单
     */
    @ApiModelProperty(value = "是否为系统菜单")
    private Boolean sys;

    /**
     * funUrl -> 为生成json用
     */
    @Transient
    private String funUrl;

    /**
     * 子集
     */
    @Transient
    private List<Auth> childList;

}
