package com.purchase.uc.client;

import com.qgutech.qgyun.framework.common.result.JsonResult;
import com.qgutech.qgyun.fs.client.config.MultipartSupportConfig;
import feign.Response;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

/**
 * 文件系统接口实现类
 *
 * @since TangFD@HF 2019-06-13
 */
@FeignClient(name = "qgyun-service-fs-manager", path = "/file", configuration = MultipartSupportConfig.class)
public interface FileFeignClient {

    /**
     * 提交文件到文件服务器`qgyun-service-fs-manager`
     *
     * @param file
     * @param appCode
     * @param funCode
     * @return
     */
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    JsonResult upload(@RequestPart MultipartFile file,
                      @RequestParam("appCode") String appCode,
                      @RequestParam("funCode") String funCode);

    /**
     * 文件下载
     *
     * @param fileId
     * @return
     */
    @GetMapping(value = "/d/{fileId}", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    Response download(@PathVariable("fileId") String fileId);

    /**
     * 文件上传自定义接口, 文件上传后，会删除filePath指定的文件
     *
     * @param filePath 文件路径
     * @param appCode  应用编号
     * @param funCode  功能编号
     * @param fileName 文件名
     * @return 上传完成，文件信息
     */
    default Map<String, Object> uploadFile(String filePath, String appCode, String funCode, String fileName) {
        File file = new File(filePath);
        DiskFileItem fileItem = (DiskFileItem) new DiskFileItemFactory()
                .createItem("file", MediaType.TEXT_PLAIN_VALUE, true, fileName);
        try (InputStream input = new FileInputStream(file); OutputStream os = fileItem.getOutputStream()) {
            IOUtils.copy(input, os);
        } catch (Exception e) {
            throw new RuntimeException("Invalid file: " + e, e);
        }

        FileUtils.deleteQuietly(file);
        MultipartFile multi = new CommonsMultipartFile(fileItem);
        JsonResult result = upload(multi, appCode, funCode);
        if (!result.isSuccess()) {
            throw new RuntimeException("upload file failed");
        }

        return (Map<String, Object>) result.getData();
    }
}
