package com.purchase.uc.mapper;

import com.purchase.uc.model.GroupMember;
import com.purchase.uc.model.User;
import com.purchase.uc.model.vo.GroupMemberSearch;
import com.qgutech.qgyun.framework.database.mybatis.model.Page;
import com.qgutech.qgyun.framework.database.mybatis.registermapper.QguBaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 群组成员Mapper接口类
 *
 * @author TaoFadeng
 * @version 1.0
 * @since 2019-05-14 09:14:13
 */
public interface GroupMemberMapper extends QguBaseMapper<GroupMember> {
    /**
     * 根据分页条件及查询条件获取分页list
     *
     * @param member   查询条件
     * @param pageInfo 分页条件
     * @return 指定大小的list
     */
    List<User> searchUser(@Param("member") GroupMemberSearch member, @Param("page") Page<User> pageInfo);

    /**
     * 满足分页条件的总条数
     *
     * @param member 查询条件
     * @return 总条数
     */
    int getUserTotal(@Param("member") GroupMemberSearch member);
}
