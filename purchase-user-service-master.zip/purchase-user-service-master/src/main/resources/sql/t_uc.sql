/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.0.69-3306
 Source Server Type    : MySQL
 Source Server Version : 50725
 Source Host           : 192.168.0.69
 Source Database       : saas-platform

 Target Server Type    : MySQL
 Target Server Version : 50725
 File Encoding         : utf-8

 Date: 09/22/2020 13:55:43 PM
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `t_uc_auth`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_auth`;
CREATE TABLE `t_uc_auth`
(
    `id`         varchar(32)  NOT NULL COMMENT 'ID',
    `name`       varchar(50)  NOT NULL COMMENT '名字',
    `app_code`   varchar(50)  NULL COMMENT '应用编号',
    `manage`     tinyint(1)   DEFAULT NULL COMMENT '是否管理端',
    `code`       varchar(100) NULL COMMENT '权限编码',
    `url`        varchar(200) NULL COMMENT '权限URL',
    `p_id`       varchar(32)  NOT NULL COMMENT '父id',
    `id_path`    varchar(400) NOT NULL COMMENT 'id路径',
    `show_order` float        DEFAULT NULL COMMENT '排序',
    `created_by` varchar(32)  NOT NULL COMMENT '创建人ID',
    `created_at` datetime     NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32)  NOT NULL COMMENT '更新人ID',
    `updated_at` datetime     NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50)  NOT NULL COMMENT '公司编号',
    `route_url`  varchar(400) DEFAULT NULL COMMENT '前端路由URL',
    `open_way`   varchar(20)  DEFAULT NULL COMMENT '打开方式（默认：default, 新窗口：window）',
    `icon`       varchar(100) DEFAULT NULL COMMENT '图标',
    `link_type`  varchar(20)  DEFAULT NULL COMMENT '链接类型(inner:内部，outer:外部)',
    `menu`       tinyint(1)   DEFAULT NULL COMMENT '是否为菜单',
    `hide`       tinyint(1)   DEFAULT NULL COMMENT '是否隐藏',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_uc_auth_code` (`corp_code`, `code`, `manage`) USING BTREE,
    KEY `i_uc_auth_p_id` (`corp_code`, `p_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='权限表';

-- ----------------------------
--  Table structure for `t_uc_category`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_category`;
CREATE TABLE `t_uc_category`
(
    `id`         varchar(32)   NOT NULL COMMENT 'ID',
    `name`       varchar(50)   NOT NULL COMMENT '类别名称',
    `code`       varchar(50) DEFAULT NULL COMMENT '类别编码',
    `fun_code`   varchar(50)   NOT NULL COMMENT '所属应用',
    `show_order` float       DEFAULT NULL COMMENT '排序',
    `p_id`       varchar(32)   NOT NULL COMMENT '父id，根类别为*',
    `id_path`    varchar(1000) NOT NULL COMMENT 'id路径',
    `name_path`  varchar(1000) NOT NULL COMMENT '名称路径',
    `created_by` varchar(32)   NOT NULL COMMENT '创建人ID',
    `created_at` datetime      NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32)   NOT NULL COMMENT '更新人ID',
    `updated_at` datetime      NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50)   NOT NULL COMMENT '公司编号',
    `sys`        tinyint(1)  DEFAULT '0',
    PRIMARY KEY (`id`) USING BTREE,
    KEY `i_category_p_id` (`corp_code`, `p_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='通用类别表';

-- ----------------------------
--  Table structure for `t_uc_group`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_group`;
CREATE TABLE `t_uc_group`
(
    `id`          varchar(32) NOT NULL COMMENT 'ID',
    `name`        varchar(50) NOT NULL COMMENT '群组名称',
    `code`        varchar(50)          DEFAULT NULL COMMENT '群组编码',
    `status`      varchar(10) NOT NULL DEFAULT 'DRAFT' COMMENT '群组状态（DRAFT: 草稿，DISABLED：激活，DISABLED：停用）',
    `category_id` varchar(32) NOT NULL COMMENT '群组类别',
    `dynamic`     tinyint(1)           DEFAULT '0' COMMENT '是否动态群组',
    `description` varchar(200)         DEFAULT NULL COMMENT '群组描述',
    `created_by`  varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at`  datetime    NOT NULL COMMENT '创建时间',
    `updated_by`  varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at`  datetime    NOT NULL COMMENT '更新时间',
    `corp_code`   varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_uc_group_code` (`corp_code`, `code`) USING BTREE,
    KEY `u_uc_group_category_id` (`corp_code`, `category_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='人员群组';

-- ----------------------------
--  Table structure for `t_uc_group_condition`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_group_condition`;
CREATE TABLE `t_uc_group_condition`
(
    `id`         varchar(32)   NOT NULL COMMENT 'ID',
    `group_id`   varchar(32)   NOT NULL COMMENT '群组ID',
    `context`    varchar(1300) NOT NULL COMMENT '条件对应的json值，每个条件存储一条数据',
    `created_by` varchar(32)   NOT NULL COMMENT '创建人ID',
    `created_at` datetime      NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32)   NOT NULL COMMENT '更新人ID',
    `updated_at` datetime      NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50)   NOT NULL COMMENT '公司编号',
    `show_order` float DEFAULT NULL COMMENT '排序',
    PRIMARY KEY (`id`) USING BTREE,
    KEY `u_uc_group_condition_group_id` (`corp_code`, `group_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='群组条件表';

-- ----------------------------
--  Table structure for `t_uc_group_member`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_group_member`;
CREATE TABLE `t_uc_group_member`
(
    `id`         varchar(32) NOT NULL COMMENT 'ID',
    `group_id`   varchar(32) NOT NULL COMMENT '群组ID',
    `user_id`    varchar(32) NOT NULL COMMENT '人员ID',
    `source`     varchar(20) NOT NULL DEFAULT 'APPOINT' COMMENT '来源：APPOINT(指定)/DYNAMIC(动态群组)',
    `created_by` varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at` datetime    NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at` datetime    NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`),
    UNIQUE KEY `u_uc_group_member_user_id_group_id` (`corp_code`, `user_id`, `group_id`, `source`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='指定群组成员表';

-- ----------------------------
--  Table structure for `t_uc_login_log`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_login_log`;
CREATE TABLE `t_uc_login_log`
(
    `id`          varchar(32)   NOT NULL COMMENT 'ID',
    `user_id`     varchar(32)   NOT NULL COMMENT '用户id',
    `login_name`  varchar(50)   NOT NULL COMMENT '用户登录名',
    `name`        varchar(50)   NOT NULL COMMENT '用户姓名',
    `session_id`  varchar(3000) NOT NULL COMMENT 'session_id',
    `login_ip`    varchar(50)  DEFAULT NULL COMMENT '登录IP',
    `login_time`  datetime      NOT NULL COMMENT '登录时间',
    `logout_time` datetime     DEFAULT NULL COMMENT '登出时间',
    `machine`     varchar(100) DEFAULT NULL COMMENT '机型',
    `browser`     varchar(500) DEFAULT NULL COMMENT '浏览器及版本信息',
    `login_type`  varchar(20)  DEFAULT NULL COMMENT '登录类型，PC平台端，WECHAT微信端，APP云端',
    `created_by`  varchar(32)   NOT NULL COMMENT '创建人ID',
    `created_at`  datetime      NOT NULL COMMENT '创建时间',
    `updated_by`  varchar(32)   NOT NULL COMMENT '更新人ID',
    `updated_at`  datetime      NOT NULL COMMENT '更新时间',
    `corp_code`   varchar(50)   NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    KEY `i_uc_login_log_user_id` (`corp_code`, `user_id`, `login_type`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='登录日志表';

-- ----------------------------
--  Table structure for `t_uc_open_scope`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_open_scope`;
CREATE TABLE `t_uc_open_scope`
(
    `id`           varchar(32) NOT NULL COMMENT 'ID',
    `refer_id`     varchar(32) NOT NULL COMMENT '资源id',
    `refer_type`   varchar(20) NOT NULL COMMENT '资源类型：COURSE EXAM KNOWLEDGE等',
    `scope_type`   varchar(20) NOT NULL COMMENT '关联类型：ORG POSITION GROUP USER ROLE',
    `scope_id`     varchar(32) NOT NULL COMMENT '关联类型id',
    `scope_org_id` varchar(32) DEFAULT NULL COMMENT '关联类型为POSITION时存放对应orgId，其他类型为NULL',
    `created_by`   varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at`   datetime    NOT NULL COMMENT '创建时间',
    `updated_by`   varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at`   datetime    NOT NULL COMMENT '更新时间',
    `corp_code`    varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_uc_open_scope` (`corp_code`, `refer_id`, `refer_type`, `scope_type`, `scope_id`,
                                  `scope_org_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='功能开放范围';

-- ----------------------------
--  Table structure for `t_uc_org`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_org`;
CREATE TABLE `t_uc_org`
(
    `id`         varchar(32)   NOT NULL COMMENT '组织主键',
    `name`       varchar(50)   NOT NULL COMMENT '组织名称',
    `code`       varchar(50)            DEFAULT NULL COMMENT '组织编号',
    `show_order` float                  DEFAULT NULL COMMENT '排序',
    `p_id`       varchar(32)   NOT NULL COMMENT '父id',
    `id_path`    varchar(1000) NOT NULL COMMENT 'id路径',
    `name_path`  varchar(1000) NOT NULL COMMENT '名称路径',
    `status`     varchar(10)   NOT NULL DEFAULT 'ENABLED' COMMENT '部门状态（DISABLED：激活，DISABLED：冻结）',
    `created_by` varchar(32)   NOT NULL COMMENT '创建人ID',
    `created_at` datetime      NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32)   NOT NULL COMMENT '更新人ID',
    `updated_at` datetime      NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50)   NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_uc_org_code` (`corp_code`, `code`) USING BTREE,
    KEY `i_uc_org_p_id` (`p_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='组织/部门表';

-- ----------------------------
--  Table structure for `t_uc_position`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_position`;
CREATE TABLE `t_uc_position`
(
    `id`          varchar(32) NOT NULL COMMENT 'ID',
    `name`        varchar(50) NOT NULL COMMENT '岗位名称',
    `code`        varchar(50) DEFAULT NULL COMMENT '岗位编码',
    `category_id` varchar(32) NOT NULL COMMENT '岗位类别',
    `created_by`  varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at`  datetime    NOT NULL COMMENT '创建时间',
    `updated_by`  varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at`  datetime    NOT NULL COMMENT '更新时间',
    `corp_code`   varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_uc_position_role_code` (`corp_code`, `code`, `category_id`) USING BTREE,
    KEY `u_uc_position_category_id` (`corp_code`, `category_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='人员岗位';

-- ----------------------------
--  Table structure for `t_uc_role`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_role`;
CREATE TABLE `t_uc_role`
(
    `id`         varchar(32) NOT NULL COMMENT 'ID',
    `code`       varchar(20)          DEFAULT NULL COMMENT '角色编号',
    `name`       varchar(50) NOT NULL COMMENT '角色名称',
    `status`     varchar(20) NOT NULL DEFAULT 'ENABLED' COMMENT '角色状态（激活ENABLED, 冻结DISABLED）',
    `manage`     tinyint(1)           DEFAULT NULL COMMENT '是否管理端',
    `created_by` varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at` datetime    NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at` datetime    NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='角色';

-- ----------------------------
--  Table structure for `t_uc_role_auth_rel`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_role_auth_rel`;
CREATE TABLE `t_uc_role_auth_rel`
(
    `id`         varchar(32) NOT NULL COMMENT 'ID',
    `role_id`    varchar(32) NOT NULL COMMENT '角色id',
    `auth_id`    varchar(32) NOT NULL COMMENT '权限id',
    `created_by` varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at` datetime    NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at` datetime    NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_uc_role_auth_role_id_auth_id` (`corp_code`, `role_id`, `auth_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='角色权限关联表';

-- ----------------------------
--  Table structure for `t_uc_sys_setting`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_sys_setting`;
CREATE TABLE `t_uc_sys_setting`
(
    `id`            varchar(32) NOT NULL COMMENT 'ID',
    `init_password` varchar(255) DEFAULT NULL COMMENT '初始密码',
    `created_by`    varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at`    datetime    NOT NULL COMMENT '创建时间',
    `updated_by`    varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at`    datetime    NOT NULL COMMENT '更新时间',
    `corp_code`     varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='用户系统设置表';

-- ----------------------------
--  Table structure for `t_uc_use_scope`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_use_scope`;
CREATE TABLE `t_uc_use_scope`
(
    `id`         varchar(32) NOT NULL COMMENT 'ID',
    `fun_code`   varchar(20) NOT NULL COMMENT '功能类型：GROUP COURSE_CATEGORY等',
    `fun_id`     varchar(32) NOT NULL COMMENT '功能id',
    `rel_type`   varchar(20) NOT NULL COMMENT '关联类型：USER ROLE',
    `rel_id`     varchar(32) NOT NULL COMMENT '关联类型id',
    `rel_org_id` varchar(32) DEFAULT NULL COMMENT '关联类型为POSITION时存放对应orgId，其他类型为NULL',
    `created_by` varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at` datetime    NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at` datetime    NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_uc_use_scope` (`corp_code`, `fun_code`, `fun_id`, `rel_type`, `rel_id`, `rel_org_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='使用范围(授权表)';

-- ----------------------------
--  Table structure for `t_uc_use_scope_res_rel`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_use_scope_res_rel`;
CREATE TABLE `t_uc_use_scope_res_rel`
(
    `id`         varchar(32) NOT NULL COMMENT 'ID',
    `fun_code`   varchar(50) DEFAULT NULL COMMENT '功能编号',
    `scope_id`   varchar(32) NOT NULL COMMENT '项目ID',
    `res_id`     varchar(32) NOT NULL COMMENT '资源ID',
    `created_by` varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at` datetime    NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at` datetime    NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_res_rel` (`corp_code`, `scope_id`, `res_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='使用授权资源关联表';

-- ----------------------------
--  Table structure for `t_uc_use_scope_user_rel`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_use_scope_user_rel`;
CREATE TABLE `t_uc_use_scope_user_rel`
(
    `id`         varchar(32) NOT NULL COMMENT 'ID',
    `scope_id`   varchar(32) NOT NULL COMMENT '项目ID',
    `user_id`    varchar(32) NOT NULL COMMENT '人员ID',
    `created_by` varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at` datetime    NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at` datetime    NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_user_rel` (`corp_code`, `scope_id`, `user_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='使用授权人员关联表';

-- ----------------------------
--  Table structure for `t_uc_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_user`;
CREATE TABLE `t_uc_user`
(
    `id`          varchar(32)  NOT NULL COMMENT 'ID',
    `name`        varchar(50)  NOT NULL COMMENT '姓名',
    `code`        varchar(50)  NOT NULL COMMENT '员工编号',
    `login_name`  varchar(50)  NOT NULL COMMENT '登录名',
    `pwd`         varchar(100) NOT NULL COMMENT '密码（MD5）',
    `email`       varchar(50)           DEFAULT NULL COMMENT '邮箱',
    `mobile`      varchar(20)           DEFAULT NULL COMMENT '手机号',
    `id_card`     varchar(20)           DEFAULT NULL COMMENT '身份证号',
    `face_id`     varchar(32)           DEFAULT NULL COMMENT '用户头像',
    `status`      varchar(10)  NOT NULL DEFAULT 'ENABLED' COMMENT '人员状态（DISABLED：激活，DISABLED：冻结，LEAVE：离职）',
    `org_id`      varchar(32)  NOT NULL COMMENT '部门主键',
    `position_id` varchar(32)           DEFAULT NULL COMMENT '岗位主键',
    `leader_id`   varchar(32)           DEFAULT NULL COMMENT '隶属上级主键',
    `entry_at`    datetime              DEFAULT NULL COMMENT '入职日期',
    `age`         int(11)               DEFAULT NULL COMMENT '用户年龄',
    `level`       varchar(20)           DEFAULT NULL COMMENT '用户职级',
    `type`        varchar(10)           DEFAULT 'INNER' COMMENT '用户类型：INNER(内部人员)/OUTER(外部人员)',
    `created_by`  varchar(32)  NOT NULL COMMENT '创建人ID',
    `created_at`  datetime     NOT NULL COMMENT '创建时间',
    `updated_by`  varchar(32)  NOT NULL COMMENT '更新人ID',
    `updated_at`  datetime     NOT NULL COMMENT '更新时间',
    `corp_code`   varchar(50)  NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_uc_user_login_name` (`corp_code`, `login_name`) USING BTREE,
    UNIQUE KEY `u_uc_user_code` (`corp_code`, `code`) USING BTREE,
    UNIQUE KEY `u_uc_user_email` (`corp_code`, `email`) USING BTREE,
    UNIQUE KEY `u_uc_user_mobile` (`corp_code`, `mobile`) USING BTREE,
    UNIQUE KEY `u_uc_user_id_card` (`corp_code`, `id_card`) USING BTREE,
    KEY `i_uc_user_organize_id` (`corp_code`, `org_id`) USING BTREE,
    KEY `i_uc_user_position_id` (`corp_code`, `position_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='用户表';

-- ----------------------------
--  Table structure for `t_uc_user_detail`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_user_detail`;
CREATE TABLE `t_uc_user_detail`
(
    `id`                    varchar(32) NOT NULL COMMENT 'ID',
    `user_id`               varchar(32) NOT NULL COMMENT 'USER_ID',
    `sex`                   varchar(10)  DEFAULT NULL COMMENT '性别(MALE：男，FEMALE：女，SECRET：保密)',
    `birthday`              datetime     DEFAULT NULL COMMENT '生日',
    `degree`                varchar(50)  DEFAULT NULL COMMENT '最高学历/学位',
    `major`                 varchar(50)  DEFAULT NULL COMMENT '专业',
    `school`                varchar(50)  DEFAULT NULL COMMENT '最后毕业学校',
    `politics`              varchar(50)  DEFAULT NULL COMMENT '政治面貌',
    `nationality`           varchar(50)  DEFAULT NULL COMMENT '国籍',
    `start_work_date`       datetime     DEFAULT NULL COMMENT '开始工作时间',
    `zip_code`              varchar(10)  DEFAULT NULL COMMENT '邮政编码',
    `marriage`              varchar(10)  DEFAULT NULL COMMENT '婚姻状况',
    `join_party_date`       datetime     DEFAULT NULL COMMENT '入党时间',
    `family_tel`            varchar(20)  DEFAULT NULL COMMENT '家庭电话',
    `office_tel`            varchar(20)  DEFAULT NULL COMMENT '办公电话',
    `emergency_contact_tel` varchar(200) DEFAULT NULL COMMENT '紧急联系信息',
    `qq`                    varchar(20)  DEFAULT NULL COMMENT 'QQ号码',
    `wechat`                varchar(50)  DEFAULT NULL COMMENT '微信号',
    `other_contact_info`    varchar(20)  DEFAULT NULL COMMENT '其它联系方式',
    `birth_place`           varchar(200) DEFAULT NULL COMMENT '出生地',
    `signature`             varchar(200) DEFAULT NULL COMMENT '个人签名',
    `profession`            varchar(50)  DEFAULT NULL COMMENT '职业',
    `city`                  varchar(100) DEFAULT NULL COMMENT '市',
    `address`               varchar(100) DEFAULT NULL COMMENT '详细地址',
    `area`                  varchar(100) DEFAULT NULL COMMENT '区',
    `province`              varchar(100) DEFAULT NULL COMMENT '省',
    `work_face_id`          varchar(32)  DEFAULT NULL COMMENT '工作照片',
    `id_card_front_id`      varchar(32)  DEFAULT NULL COMMENT '身份证正面照片',
    `id_card_back_id`       varchar(32)  DEFAULT NULL COMMENT '身份证反面照片',
    `company`               varchar(100) DEFAULT NULL COMMENT '公司',
    `company_address`       varchar(200) DEFAULT NULL COMMENT '公司地址',
    `remark`                varchar(400) DEFAULT NULL COMMENT '备注',
    `ext1`                  varchar(400) DEFAULT NULL COMMENT '扩展字段1',
    `ext2`                  varchar(400) DEFAULT NULL COMMENT '扩展字段2',
    `ext3`                  varchar(400) DEFAULT NULL,
    `ext4`                  varchar(400) DEFAULT NULL,
    `ext5`                  varchar(400) DEFAULT NULL,
    `ext6`                  varchar(400) DEFAULT NULL,
    `ext7`                  varchar(400) DEFAULT NULL,
    `ext8`                  varchar(400) DEFAULT NULL,
    `ext9`                  varchar(400) DEFAULT NULL,
    `ext10`                 varchar(400) DEFAULT NULL,
    `ext11`                 varchar(400) DEFAULT NULL,
    `ext12`                 varchar(400) DEFAULT NULL,
    `ext13`                 varchar(400) DEFAULT NULL,
    `ext14`                 varchar(400) DEFAULT NULL,
    `ext15`                 varchar(400) DEFAULT NULL,
    `created_by`            varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at`            datetime    NOT NULL COMMENT '创建时间',
    `updated_at`            datetime    NOT NULL COMMENT '更新时间',
    `updated_by`            varchar(32) NOT NULL COMMENT '更新人ID',
    `corp_code`             varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_uc_user_detail_user_id` (`corp_code`, `user_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='用户详细信息表';

-- ----------------------------
--  Table structure for `t_uc_user_range`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_user_range`;
CREATE TABLE `t_uc_user_range`
(
    `id`           varchar(32) NOT NULL COMMENT 'ID',
    `user_id`      varchar(32) NOT NULL COMMENT '用户id',
    `refer_type`   varchar(20) NOT NULL COMMENT '关联类型：ORG(部门)/POSITION(岗位)/GROUP(群组)',
    `refer_id`     varchar(32) NOT NULL COMMENT '关联类型id',
    `range_org_id` varchar(32) DEFAULT NULL COMMENT '关联类型为POSITION时存放对应orgId，其他类型为NULL',
    `created_by`   varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at`   datetime    NOT NULL COMMENT '创建时间',
    `updated_by`   varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at`   datetime    NOT NULL COMMENT '更新时间',
    `corp_code`    varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    KEY `u_uc_user_range_user_id_refer_id` (`corp_code`, `user_id`, `refer_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='用户管辖范围';

-- ----------------------------
--  Table structure for `t_uc_user_role_rel`
-- ----------------------------
DROP TABLE IF EXISTS `t_uc_user_role_rel`;
CREATE TABLE `t_uc_user_role_rel`
(
    `id`         varchar(32) NOT NULL COMMENT 'ID',
    `user_id`    varchar(32) NOT NULL COMMENT '用户id',
    `role_id`    varchar(32) NOT NULL COMMENT '角色id',
    `created_by` varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at` datetime    NOT NULL COMMENT '创建时间',
    `updated_by` varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at` datetime    NOT NULL COMMENT '更新时间',
    `corp_code`  varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `u_uc_user_role_user_id_role_id` (`corp_code`, `user_id`, `role_id`) USING BTREE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  ROW_FORMAT = DYNAMIC COMMENT ='用户角色关联表';

SET FOREIGN_KEY_CHECKS = 1;

# default公司 初始化部门和admin账户
INSERT INTO `t_uc_org`(`id`, `name`, `code`, `show_order`, `p_id`, `id_path`, `name_path`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`, `corp_code`) VALUES ('rr83bY1v58r8BQIIRbG', '全部', 'default', 1, '*', 'rr83bY1v58r8BQIIRbG', '全部', 'ENABLED', 'H68TU7wmWrC0xISkzMO', '2020-03-02 15:31:22', 'H68TU7wmWrC0xISkzMO', '2020-03-02 15:31:22', 'default');
INSERT INTO `t_uc_user`(`id`, `name`, `code`, `login_name`, `pwd`, `email`, `mobile`, `id_card`, `face_id`, `status`, `org_id`, `position_id`, `leader_id`, `entry_at`, `age`, `level`, `type`, `created_by`, `created_at`, `updated_by`, `updated_at`, `corp_code`) VALUES ('H68TU7wmWrC0xISkzMO', '系统管理员', 'admin', 'admin', '670b14728ad9902aecba32e22fa4f6bd', 'admin@qixiao.com', NULL, NULL, '5211304551155712', 'ENABLED', 'rr83bY1v58r8BQIIRbG', NULL, NULL, NULL, NULL, NULL, 'INNER', 'H68TU7wmWrC0xISkzMO', '2020-03-02 15:31:23', 'H68TU7wmWrC0xISkzMO', '2020-09-28 11:15:34', 'default');
INSERT INTO `t_uc_user_detail`(`id`, `user_id`, `sex`, `birthday`, `degree`, `major`, `school`, `politics`, `nationality`, `start_work_date`, `zip_code`, `marriage`, `join_party_date`, `family_tel`, `office_tel`, `emergency_contact_tel`, `qq`, `wechat`, `other_contact_info`, `birth_place`, `signature`, `profession`, `city`, `address`, `area`, `province`, `work_face_id`, `id_card_front_id`, `id_card_back_id`, `company`, `company_address`, `remark`, `ext1`, `ext2`, `ext3`, `ext4`, `ext5`, `ext6`, `ext7`, `ext8`, `ext9`, `ext10`, `ext11`, `ext12`, `ext13`, `ext14`, `ext15`, `created_by`, `created_at`, `updated_at`, `updated_by`, `corp_code`) VALUES ('tlcR8kOMjsax3n1h8j6', 'H68TU7wmWrC0xISkzMO', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'H68TU7wmWrC0xISkzMO', '2020-03-02 15:31:23', '2020-12-25 10:49:44', 'H68TU7wmWrC0xISkzMO', 'default');

create table t_saas_corp_info
(
    id                varchar(32)                     not null comment 'ID' primary key,
    corp_id           varchar(32)                     null comment '公司id',
    code              varchar(50)                     not null comment '公司编码',
    name              varchar(100)                    not null comment '公司名称',
    status            varchar(20) default 'APPROVING' not null comment '状态',
    address           varchar(400)                    null comment '详细地址',
    corp_province     varchar(20)                     null comment '所在地-省',
    corp_city         varchar(20)                     null comment '所在地-市',
    area_code         varchar(20)                     null comment '赠送代码',
    expect_num        int                             null comment '预计规模人数',
    industry_id       varchar(32)                     null comment '所属行业',
    contact           varchar(20)                     null comment '联系人',
    contact_mobile    varchar(20)                     null comment '联系人手机',
    contact_email     varchar(50)                     null comment '联系人邮箱',
    enterprise_nature varchar(20)                     null comment '企业性质',
    enterprise_scale  varchar(20)                     null comment '企业规模',
    source            varchar(20)                     null comment '来源',
    domain_name       varchar(50)                     null comment '公司域名',
    corp_type         varchar(20)                     null comment '企业类型',
    platform_type     varchar(20)                     null comment '平台类型',
    institution_name  varchar(100)                    null comment '所属机构名称',
    area              varchar(100)                    null comment '所属区域',
    institution_type  varchar(100)                    null comment '所属机构类型',
    created_by        varchar(32)                     not null comment '创建人ID',
    created_at        datetime                        not null comment '创建时间',
    updated_by        varchar(32)                     not null comment '更新人ID',
    updated_at        datetime                        not null comment '更新时间',
    corp_code         varchar(50)                     not null comment '公司编号',
    ext_config        json                            null comment '可扩展公司属性配置',
    signed_project    varchar(255)                    null comment '签署项目'
) comment '公司信息表' collate = utf8mb4_general_ci;

CREATE TABLE `t_pd_purchase_customer`
(
    `id`             int                                                     NOT NULL AUTO_INCREMENT COMMENT '主键',
    `cust_id`        int                                                          DEFAULT NULL COMMENT '从zydmall同步过来的id',
    `cust_type`      varchar(50)                                             NOT NULL COMMENT '用户类型;(B：ERP客户，C：C端客户，T：推广员_业务员，b：商城注册客户，p：非企业认证客户)',
    `cust_name`      varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客户名称',
    `erp_cust_bm`    varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci      DEFAULT NULL COMMENT 'erp客户编码',
    `account`        varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci      DEFAULT NULL COMMENT '商城账号',
    `password`       varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci      DEFAULT NULL COMMENT '默认登陆密码',
    `company_bm`     varchar(255)                                                 DEFAULT NULL COMMENT '分公司编码',
    `company_name`   varchar(100)                                                 DEFAULT NULL COMMENT '分公司名称',
    `phone`          varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci      DEFAULT NULL COMMENT '绑定手机号',
    `sw_man_name`    varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci      DEFAULT NULL COMMENT '关联商务名称',
    `sale_man_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci      DEFAULT NULL COMMENT '关联业务名称',
    `real_name`      varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci      DEFAULT NULL COMMENT '真实姓名',
    `cust_linkman`   varchar(100)                                                 DEFAULT NULL COMMENT '客户联系人',
    `cust_link_tel`  varchar(100)                                                 DEFAULT NULL COMMENT '客户联系方式',
    `cust_address`   varchar(255)                                                 DEFAULT NULL COMMENT '客户地址',
    `regist_status`  varchar(10)                                                  DEFAULT NULL COMMENT '客户注册状态',
    `status`         varchar(10)                                                  DEFAULT NULL COMMENT '客户启停用',
    `account_status` varchar(10)                                                  DEFAULT NULL COMMENT '账号启停用',
    `registed_at`    datetime                                                     DEFAULT NULL COMMENT '注册时间',
    `created_by`     varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人ID',
    `created_at`     datetime                                                     DEFAULT NULL COMMENT '创建/开通时间',
    `updated_by`     varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人ID',
    `updated_at`     datetime                                                     DEFAULT NULL COMMENT '更新时间',
    `corp_code`      varchar(50)                                                  DEFAULT 'default' COMMENT '公司编号',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16702939 DEFAULT CHARSET=utf8 COMMENT='客户信息表';

CREATE TABLE `t_purchase_supplier`
(
    `id`             varchar(32) NOT NULL COMMENT 'ID',
    `code`           varchar(50) NOT NULL COMMENT '供应商编码',
    `name`           varchar(50) NOT NULL COMMENT '供应商名称',
    `cust_id`        varchar(32)                                                  DEFAULT NULL COMMENT '客户id',
    `type`           varchar(20)                                                  DEFAULT NULL COMMENT '类型（SUPPLIER_APPLY: 供应商申请、BACKGROUND_ADD: 后台新增）',
    `status`         varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '状态（WAIT_AUDIT: 待审核、NO_PASS: 未通过、PASS: 已通过）',
    `erp_cust_bm`    varchar(100)                                                 DEFAULT NULL COMMENT 'ERP客户编码',
    `password`       varchar(255)                                                 DEFAULT NULL COMMENT '初始密码',
    `account_status` varchar(20)                                                  DEFAULT NULL COMMENT '账号状态(ENABLE: 启用、DISABLE: 停用)',
    `audit_time`     datetime                                                     DEFAULT NULL COMMENT '审核时间',
    `created_by`     varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at`     datetime    NOT NULL COMMENT '创建时间',
    `updated_by`     varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at`     datetime    NOT NULL COMMENT '更新时间',
    `corp_code`      varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='惠采供应商表';

ALTER TABLE t_uc_user ADD data_type VARCHAR(20) COMMENT '类型(SUPPLIER: 供应商，USER: 用户(供应链、子公司))';
ALTER TABLE t_uc_user ADD company_id VARCHAR(32) COMMENT '分公司id';

CREATE TABLE `t_purchase_channel_provider`
(
    `id`             varchar(32) NOT NULL COMMENT 'ID',
    `code`           varchar(50) NOT NULL COMMENT '商城账号',
    `name`           varchar(50) NOT NULL COMMENT '渠道商名称',
    `cust_id`        varchar(32)  DEFAULT NULL COMMENT '客户id',
    `cust_type`      varchar(50) NOT NULL COMMENT '用户类型;(B：ERP客户，b：商城注册客户)',
    `erp_cust_bm`    varchar(100) DEFAULT NULL COMMENT 'ERP客户编码',
    `password`       varchar(255) DEFAULT NULL COMMENT '初始密码',
    `sign_project`   varchar(100) DEFAULT NULL COMMENT '签约项目(ZYDMALL: 联营商城, PRE_STOCK: 预库存, CONSIGNMENT_WAREHOUSE: 寄仓)',
    `un_mall_code`   varchar(100) DEFAULT NULL COMMENT '联营商城编码',
    `company_bm`     varchar(32)  DEFAULT NULL COMMENT '分公司编码',
    `company_name`   varchar(100) DEFAULT NULL COMMENT '分公司名称',
    `phone`          varchar(100) DEFAULT NULL COMMENT '绑定手机号',
    `account_status` varchar(20)  DEFAULT NULL COMMENT '账号启用停用(ENABLE: 启用、DISABLE: 停用)',
    `created_by`     varchar(32) NOT NULL COMMENT '创建人ID',
    `created_at`     datetime    NOT NULL COMMENT '创建时间',
    `updated_by`     varchar(32) NOT NULL COMMENT '更新人ID',
    `updated_at`     datetime    NOT NULL COMMENT '更新时间',
    `corp_code`      varchar(50) NOT NULL COMMENT '公司编号',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='渠道联营商表';

CREATE TABLE `t_purchase_company`
(
    `id`         int NOT NULL AUTO_INCREMENT COMMENT '主键',
    `company_id` int                                                          DEFAULT NULL COMMENT '公司id，从zydmall同步过来',
    `com_bm`     varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci      DEFAULT NULL COMMENT '分公司编码',
    `com_name`   varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci      DEFAULT NULL COMMENT '分公司名称',
    `short_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci       DEFAULT NULL COMMENT '分公司简称',
    `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人ID',
    `created_at` datetime                                                     DEFAULT NULL COMMENT '创建时间',
    `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人ID',
    `updated_at` datetime                                                     DEFAULT NULL COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `com_bm` (`com_bm`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8;

-- 大小定不敏感问题
ALTER TABLE t_purchase_channel_provider MODIFY cust_type varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '用户类型;(B：ERP客户，b：商城注册客户)';
ALTER TABLE t_pd_purchase_customer MODIFY cust_type varchar (50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '用户类型;(B：ERP客户，C：C端客户，T：推广员_业务员，b：商城注册客户，p：非企业认证客户)';;

-- 配置角色codo为以下三种，或者执行下同sql初始化
INSERT INTO `purchase`.`t_uc_role`(`id`, `code`, `name`, `status`, `manage`, `created_by`, `created_at`, `updated_by`, `updated_at`, `corp_code`) VALUES ('CB5HFKu3DjQtYvJTzOk', 'SUPPLY_CHAIN', '供应链', 'ENABLED', 1, 'TAHhFBrjOkWYI9KDNtJ', '2022-09-14 10:38:19', 'TAHhFBrjOkWYI9KDNtJ', '2022-09-14 10:38:19', 'default');
INSERT INTO `purchase`.`t_uc_role`(`id`, `code`, `name`, `status`, `manage`, `created_by`, `created_at`, `updated_by`, `updated_at`, `corp_code`) VALUES ('Vp81ePhkfAZIzdDtHXw', 'supplier', '供应商', 'ENABLED', 1, 'TAHhFBrjOkWYI9KDNtJ', '2022-08-25 14:24:04', 'TAHhFBrjOkWYI9KDNtJ', '2022-08-25 14:24:04', 'default');
INSERT INTO `purchase`.`t_uc_role`(`id`, `code`, `name`, `status`, `manage`, `created_by`, `created_at`, `updated_by`, `updated_at`, `corp_code`) VALUES ('yumOteSSQJbsN2XQ0gK', 'BRANCH_COMPANY', '子公司', 'ENABLED', 1, 'TAHhFBrjOkWYI9KDNtJ', '2022-09-28 14:46:49', 'TAHhFBrjOkWYI9KDNtJ', '2022-09-28 14:46:49', 'default');
