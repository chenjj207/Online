package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 客户地址表
* </p>
*
* @author jidonglin
* @since 2023-12-19
*/
@Data
@TableName("t_pd_purchase_customer_address")
@Schema(title = "客户地址表")
public class CustomerAddress extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "客户id")
    @TableField("cust_id")
    private Integer custId;

    @Schema(description = "国家")
    @TableField("country")
    private String country;

    @Schema(description = "省")
    @TableField("province")
    private String province;

    @Schema(description = "市")
    @TableField("city")
    private String city;

    @Schema(description = "区")
    @TableField("area")
    private String area;

    @Schema(description = "街道")
    @TableField("street")
    private String street;

    @Schema(description = "详细地址")
    @TableField("detail_address")
    private String detailAddress;

    @Schema(description = "邮编")
    @TableField("zipcode")
    private String zipcode;

    @Schema(description = "是否默认地址")
    @TableField("is_default")
    private Integer isDefault;

    @Schema(description = "收货人")
    @TableField("contact")
    private String contact;

    @Schema(description = "手机号")
    @TableField("phone")
    private String phone;

    @Schema(description = "省id")
    @TableField("province_id")
    private Integer provinceId;

    @Schema(description = "市id")
    @TableField("city_id")
    private Integer cityId;

    @Schema(description = "区id")
    @TableField("area_id")
    private Integer areaId;

    @Schema(description = "街道id")
    @TableField("street_id")
    private String streetId;




}
