package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 
* </p>
*
* @author jidonglin
* @since 2023-04-24
*/
@Data
@TableName("t_pd_purchase_customer")
@Schema(title = "慧采客户表")
public class Customer extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Schema(description = "会员id")
    @TableField("member_id")
    private Integer memberId;

    @Schema(description = "erp客户编码")
    @TableField("erp_cust_bm")
    private String erpCustBm;

}
