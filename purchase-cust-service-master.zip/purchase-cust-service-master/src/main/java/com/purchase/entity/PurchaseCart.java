package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
* <p>
* 购物车
* </p>
*
* @author jidonglin
* @since 2023-04-24
*/
@Data
@TableName("t_cu_purchase_cart")
@Schema(title = "购物车")
public class PurchaseCart extends BaseEntity {

    private static final long serialVersionUID = 1L;


    @Schema(description = "客户id")
    @TableField("cust_id")
    private Integer custId;

    @Schema(description = "产品id")
    @TableField("product_id")
    private Long productId;

    @Schema(description = "型号")
    @TableField("product_type")
    private String productType;

    @Schema(description = "订货号")
    @TableField("sku_code")
    private String skuCode;

    @Schema(description = "数量")
    @TableField("number")
    private Integer number;

    @Schema(description = "是否为选中（0为不选中，1为选中）")
    @TableField("is_select")
    private Integer isSelect;

    @Schema(description = "购物车序号索引（从1开始，连续）")
    @TableField("cart_index")
    private Integer cartIndex;

    @Schema(description = "品牌id")
    @TableField("brand_id")
    private Integer brandId;

    @Schema(description = "品牌名")
    @TableField("brand_name")
    private String brandName;

    @Schema(description = "系列id")
    @TableField("prop_id")
    private Integer propId;

    @Schema(description = "系列名")
    @TableField("prop_name")
    private String propName;




}
