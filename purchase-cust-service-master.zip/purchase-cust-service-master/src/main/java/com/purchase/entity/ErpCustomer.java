package com.purchase.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
* <p>
* 
* </p>
*
* @author jidonglin
* @since 2023-04-26
*/
@Data
@TableName("t_pd_purchase_erp_customer")
@Schema(title = "erp客户表")
public class ErpCustomer{

    private static final long serialVersionUID = 1L;
    @Schema(description = "主键id")
    @TableField("id")
    private int id;

    @Schema(description = "客户名称")
    @TableField("cust_name")
    private String custName;

    @Schema(description = "姓名")
    @TableField("nick_name")
    private String nickName;

    @Schema(description = "ERP客户编码")
    @TableField("erp_cust_bm")
    private String erpCustBm;

    @Schema(description = "商城账号")
    @TableField("sec_cust_account")
    private String secCustAccount;

    @Schema(description = "初始密码")
    @TableField("sec_init_pwd")
    private String secInitPwd;

    @Schema(description = "会员类型")
    @TableField("auth_type")
    private String authType;

    @Schema(description = "绑定手机号")
    @TableField("login_phone")
    private String loginPhone;

    @Schema(description = "关联业务")
    @TableField("saleman_name")
    private String salemanName;

    @Schema(description = "关联商务")
    @TableField("svr_sw_man_name")
    private String svrSwManName;

    @Schema(description = "分公司名称")
    @TableField("short_name")
    private String shortName;

    @Schema(description = "客户联系人")
    @TableField("cust_link_man")
    private String custLinkMan;

    @Schema(description = "客户联系方式")
    @TableField("cust_link_tel")
    private String custLinkTel;

    @Schema(description = "客户地址")
    @TableField("cust_address")
    private String custAddress;

    @Schema(description = "注册状态")
    @TableField("audit_status")
    private String auditStatus;

    @Schema(description = "客户启停用")
    @TableField("sec_disabled")
    private String secDisabled;

    @Schema(description = "账号启停用")
    @TableField("disabled")
    private String disabled;

    @Schema(description = "注册时间")
    @TableField("dreg_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime dregDate;

    @Schema(description = "开通时间")
    @TableField("dcreate_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime dcreateTime;

    @Schema(description = "最后修改时间")
    @TableField("dlast_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime dlastDate;




}
