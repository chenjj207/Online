package com.purchase.common;

import lombok.Data;

/**
 * @author jidonglin
 * @Description: 业务枚举值
 */
@Data
public class CustConstants {

    /**
     * satoken 登录授权
     */
    public static String LOGIN_AUTH = "auth";

    /**
     * satoken 登录前缀
     */
    public static String PRE_LOGIN = "mall-";

    public enum SupplierSourceType{
        BACKGROUND_ADD("BACKGROUND_ADD", "后台新增"),
        SUPPLIER_APPLY("SUPPLIER_APPLY", "供应商申请"),
        ;

        public String code;
        public String message;
        SupplierSourceType(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum SupplierAccountStatus {
        ENABLE("ENABLE", "启用"),
        DISABLE("DISABLE", "禁用"),
        ;

        public String code;
        public String message;
        SupplierAccountStatus(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum SupplierStatus {
        WAIT_AUDIT("WAIT_AUDIT", "待审核"),
        NO_PASS("NO_PASS", "未通过"),
        PASS("PASS", "已通过"),
        ;

        public String code;
        public String message;
        SupplierStatus(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum SupplierDataType{
        UNITE("UNITE", "联营"),
        SELF("SELF", "自营"),
        ;

        public String code;
        public String message;
        SupplierDataType(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum CustCartSelect{
        YES(1,"选中"),
        NO(0,"不选中");

        public Integer code;
        public String message;
        CustCartSelect(Integer code, String message) {
            this.code = code;
            this.message = message;
        }
        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum SmsCodeType{
        LOGIN(1, "登录类型"),
        REGIST(2, "注册类型"),
        ;

        public int code;
        public String message;
        SmsCodeType(int code, String message) {
            this.code = code;
            this.message = message;
        }
        public int getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum MemberState{
        CHECK(0,"待审核"),
        PASS(1,"通过"),
        REFER(2,"未通过");

        public Integer code;
        public String message;
        MemberState(Integer code, String message) {
            this.code = code;
            this.message = message;
        }

        public static String getValue(Integer code) {
            for (MemberState e : MemberState.values()) {
                if (e.code.equals(code)) {
                    return e.message;
                }
            }
            return null;
        }

        public Integer getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }
    public enum OrderStatus{
        PENDING("1","待处理");

        public String code;
        public String message;
        OrderStatus(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }

    public enum CodeState{
        NOT_REG("0","客户未注册"),
        PASS("1","客户已通过"),
        REFER("2","客户已注册，未通过");

        public String code;
        public String message;
        CodeState(String code, String message) {
            this.code = code;
            this.message = message;
        }
        public String getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
    }
}
