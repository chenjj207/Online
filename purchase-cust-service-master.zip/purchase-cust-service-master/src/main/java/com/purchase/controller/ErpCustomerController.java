package com.purchase.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.ErpCustomer;
import com.purchase.service.ErpCustomerService;
import com.purchase.service.dto.CustomerDTO;
import com.purchase.service.dto.CustomerPageDTO;
import com.purchase.service.dto.ErpCustomerPageDTO;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-26
 */
@RestController
@RequestMapping("/erp-customer")
public class ErpCustomerController {

    @Autowired
    ErpCustomerService erpCustomerService;

    @PostMapping(value = "/erp-customer-page")
    @Operation(summary = "慧采平台--分页搜索")
    public Page<ErpCustomer> queryMessage(@RequestBody ErpCustomerPageDTO erpCustomerPageDTO) {
        return erpCustomerService.selectPage(erpCustomerPageDTO);
    }
}
