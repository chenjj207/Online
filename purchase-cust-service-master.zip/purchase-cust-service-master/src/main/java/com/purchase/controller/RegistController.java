package com.purchase.controller;

import com.purchase.service.RegistService;
import com.purchase.service.dto.RelateKeyDTO;
import com.purchase.service.vo.RegistCodeVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author jidonglin
 * @Description: 注册控制器
 * @date 2023/5/16  13:43
 */
@RestController
@RequestMapping("/regist")
public class RegistController {

    @Autowired
    RegistService registService;

    @PostMapping(value = "/code")
    @Operation(summary = "慧采商城--注册码接口")
    @Auth(value = AuthType.NONE)
    public RegistCodeVO registCode(){
        return registService.registCode();
    }

    @PostMapping(value = "/relate-key")
    @Operation(summary = "慧采小程序--关联openId 和 unionId")
    @Auth(value = AuthType.NONE)
    public boolean relateKey(@RequestBody RelateKeyDTO relateKeyDTO) {
        return registService.relateKey(relateKeyDTO);
    }
}
