package com.purchase.controller;

import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.service.CustomerService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CustomerInfoVO;
import com.purchase.utils.NoticeUtils;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import com.zyd.framework.utils.response.CommonResponse;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


/**
 * 客户管理控制器
 * @author jidonglin
 * @since 2023-04-24
 */
@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    CustomerService customerService;
    @Autowired
    NoticeUtils noticeUtils;

    @PostMapping("/customer-add")
    @Operation(summary = "慧采平台--会员审核通过添加客户")
    public Boolean add(@Valid @RequestBody CustomerAddDTO customerAddDTO){
        return customerService.add(customerAddDTO);
    }

    @PostMapping(value = "/customer-page")
    @Operation(summary = "慧采平台--分页搜索")
    public Page<CustomerDTO> queryMessage(@RequestBody CustomerPageDTO customerPageDTO) {
        return customerService.selectPage(customerPageDTO);
    }

    @PostMapping(value = "/erp/bind")
    @Operation(summary = "慧采平台--绑定erp客户编码")
    public boolean bindErpBm(@Valid @RequestBody BindErpBmDTO bindErpBmDTO){
        return customerService.bindErpBm(bindErpBmDTO);
    }

    @PostMapping(value = "/suppiler/apply")
    @Operation(summary = "慧采商城--供应商申请")
    @Auth(value = AuthType.AUTH)
    public boolean suppilerOpen(){
        return customerService.suppilerApply();
    }

    @PostMapping(value = "/sms/code/send")
    @Operation(summary = "【验证】 发送短信验证码")
    @Auth(value = AuthType.NONE)
    public Boolean sendSmsCode(@Valid @RequestBody SendSmsCodeDTO sendSmsCodeDTO){
        return customerService.sendSmsCode(sendSmsCodeDTO);
    }

    @PostMapping(value = "/query")
    @Operation(summary = "根据token查询单个客户详情")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public CustomerInfoVO query(){
        return customerService.queryInfo();
    }

    @PostMapping(value = "/qywx/msg/send")
    @Operation(summary = "发送企业微信")
    @Auth(value = AuthType.NONE)
    public boolean sendQyMsgWithFile(@RequestBody QywxMsgDTO qywxMsgDTO){
        return customerService.sendQyMsgWithFile(qywxMsgDTO);
    }
}
