package com.purchase.controller;


import com.purchase.entity.CustomerAddress;
import com.purchase.service.CustomerAddressService;
import com.purchase.service.dto.AddressResolveDTO;
import com.purchase.service.dto.CustomerAddressAddDTO;
import com.purchase.service.dto.CustomerAddressEditDTO;
import com.purchase.service.vo.AddressResolveVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 客户地址表 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
@RestController
@RequestMapping("/customer-address")
public class CustomerAddressController {

    @Autowired
    CustomerAddressService customerAddressService;

    @PostMapping("/add")
    @Operation(summary = "客户添加收货地址")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Integer add(@Valid@RequestBody CustomerAddressAddDTO customerAddressAddDTO){
        return customerAddressService.add(customerAddressAddDTO);
    }

    @PostMapping("/delete")
    @Operation(summary = "客户删除收货地址")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean add(@RequestBody List<Integer> ids){
        return customerAddressService.removeBatchByIds(ids);
    }

    @PostMapping("/edit")
    @Operation(summary = "客户编辑收货地址")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean edit(@Valid @RequestBody CustomerAddressEditDTO customerAddressEditDTO){
        return customerAddressService.edit(customerAddressEditDTO);
    }

    @PostMapping("/list")
    @Operation(summary = "客户查询收货地址列表")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public List<CustomerAddress> list(){
        return customerAddressService.listByCustId();
    }

    @Operation(summary = "客户收获地址解析")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @PostMapping("/resolve")
    public AddressResolveVO addressResolve(@RequestBody AddressResolveDTO addressResolveDTO) {
        return customerAddressService.addressResolve(addressResolveDTO);
    }
}
