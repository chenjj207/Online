package com.purchase.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.purchase.client.param.JsonResult;
import com.purchase.service.LoginService;
import com.purchase.service.dto.CheckCodeDTO;
import com.purchase.service.dto.SMSLoginDTO;
import com.purchase.service.dto.WXLoginDTO;
import com.purchase.service.vo.CheckCodeVO;
import com.purchase.service.vo.UdeskInfoVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author jidonglin
 * @Description: 惠采商城、联营慧PC 登录控制器
 * @date 2023/5/16  13:43
 */
@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    LoginService loginService;

    @PostMapping(value = "/sms/login")
    @Operation(summary = "慧采商城--短信登录接口")
    @Auth(value = AuthType.NONE)
    public String smsLogin(@Valid @RequestBody SMSLoginDTO smsLoginDTO){
        return loginService.smslogin(smsLoginDTO);
    }

    @PostMapping(value = "/wx/login")
    @Operation(summary = "慧采商城--微信扫码登录接口")
    @Auth(value = AuthType.NONE)
    public String wxlogin(@Valid @RequestBody WXLoginDTO wxLoginDTO){
        String token = loginService.wxlogin(wxLoginDTO);
        return token;
    }

    @PostMapping(value = "/code/check")
    @Operation(summary = "慧采商城--轮询接口，检查微信客户注册状态及登录")
    @Auth(value = AuthType.NONE)
    public CheckCodeVO checkCode(@Valid @RequestBody CheckCodeDTO checkCodeDTO) {
        return loginService.checkCode(checkCodeDTO.getKey());
    }

    @PostMapping(value = "/token/login")
    @Operation(summary = "联营慧PC token登录 供应商后台")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public JsonResult<?> tokenLogin(){
        return loginService.tokenLogin();
    }

    @RequestMapping(value = "/udesk/info", method = RequestMethod.POST)
    @Operation(summary = "udesk登录用户信息")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public UdeskInfoVO udeskInfo(){
        return  loginService.udeskInfo();
    }

    @PostMapping(value = "/loginout")
    @Operation(summary = "联营慧PC、惠采商城退出登录")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    public Boolean loginOut(){
        StpUtil.logout();
        return true;
    }
}
