package com.purchase.controller;


import com.purchase.service.PurchaseCartService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CartCountVO;
import com.purchase.service.vo.CartListVO;
import com.purchase.service.vo.CartPriceVO;
import com.zyd.framework.utils.annotation.Auth;
import com.zyd.framework.utils.enums.AuthType;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

/**
 * <p>
 * 购物车 前端控制器
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-24
 */
@RestController
@RequestMapping("/purchase-cart")
public class PurchaseCartController {

    @Autowired
    PurchaseCartService purchaseCartService;

    @PostMapping("/cart-product-add")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "慧采商城端——客户添加购物车")
    public Boolean addCartProduct(@RequestBody @Validated List<AddCartProductDTO> addCartProductDTOList){
        return purchaseCartService.addCartProduct(addCartProductDTOList);
    }

    @PostMapping("/cart-num-edit")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "慧采商城端——购物车数量编辑")
    public Boolean editNum(@RequestBody @Validated EditNumDTO editNumDTO){
        return purchaseCartService.editNum(editNumDTO);
    }

    @PostMapping("/cart-list")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "慧采商城端——购物车列表")
    public List<CartListVO> cartList(){
        return purchaseCartService.cartList();
    }


    @PostMapping("/cart-edit-select")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "慧采商城端——购物车编辑选中")
    public Boolean cartEditSelect(@RequestBody @Validated CartEditSelectDTO cartEditSelectDTO){
        return purchaseCartService.cartEditSelect(cartEditSelectDTO);
    }

    @PostMapping("/cart-deleted")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "慧采商城端——购物车删除")
    public Boolean cartDeleted(@RequestBody @Validated  List<Integer> idList){
        return purchaseCartService.cartDeleted(idList);
    }

    @PostMapping("/cart-price")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "慧采商城端——计算总价")
    public CartPriceVO cartPrice(){
        return purchaseCartService.cartPrice();
    }

    @PostMapping("/cart-export")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "慧采商城端——购物车导出")
    public void cartExport(HttpServletResponse response,@RequestBody @Validated List<CartExportRequestDTO> cartExportRequestDTOList) {
        purchaseCartService.cartExport(response,cartExportRequestDTOList);
    }

    @PostMapping("/cart-order")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "慧采商城端——购物车转订单")
    public Boolean cartOrder(@RequestBody @Validated List<CartExportRequestDTO> cartExportRequestDTOList){
        return purchaseCartService.cartOrder(cartExportRequestDTOList);
    }

    @PostMapping("/cart-count")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "慧采商城端——购物车数量统计")
    public CartCountVO cartCount(){
        return purchaseCartService.cartCount();
    }


    @PostMapping("/edit/cart-index")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "慧采商城端——排序拖动")
    public boolean editCartIndex(@RequestBody @Validated List<EditCartIndexDTO> editCartIndexDTOS){
        return purchaseCartService.editCartIndex(editCartIndexDTOS);
    }

    @PostMapping(value = "/prompt/index")
    @Auth(value = AuthType.AUTH, roles = {"ALL"}, permissions = {"ALL"})
    @Operation(summary = "提示拖动排序顺序:true-继续提示，false-不再提示")
    public Boolean isPromptIndex(@RequestBody PromptIndexDTO promptIndexDTO) {
        Boolean isPrompt = purchaseCartService.isPromptIndex(promptIndexDTO.getPromptCode());
        return isPrompt;
    }
}
