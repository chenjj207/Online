package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Customer;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.CustomerDTO;
import com.purchase.service.dto.CustomerPageDTO;
import com.purchase.service.vo.CustomerInfoVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-24
 */
@Mapper
public interface CustomerMapper extends BaseMapper<Customer> {

    Page<CustomerDTO> search (@Param("dto") CustomerPageDTO dto, Page page);

    List<CustomerDTO> search(@Param("dto") CustomerPageDTO dto);

    CustomerInfoVO searchSuppiler(@Param("id")Integer memberId);

    CustomerDTO selectMember(@Param("openId")String openId, @Param("unionId")String unionId, @Param("linkphone")String linkphone);
}
