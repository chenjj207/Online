package com.purchase.mapper;

import com.purchase.entity.CustomerAddress;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 * 客户地址表 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
@Mapper
public interface CustomerAddressMapper extends BaseMapper<CustomerAddress> {

}
