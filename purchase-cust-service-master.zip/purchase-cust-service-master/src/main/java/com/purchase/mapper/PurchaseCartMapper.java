package com.purchase.mapper;

import com.purchase.entity.PurchaseCart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.vo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 购物车 Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-24
 */
@Mapper
public interface PurchaseCartMapper extends BaseMapper<PurchaseCart> {

    List<PurchaseCart> selectProductList(@Param("list") List<Long> addIds);

    List<CartListVO> cartList(@Param("id")String id);

    CartPriceVO cartPrice(@Param("id")String id);

    List<CartListExcelVO> cartExport(@Param("id")String id, @Param("list")List<Integer> ids);

    List<OrderInfoVO> orderInfoVos(@Param("id")String id, @Param("list")List<Integer> list);

    void insertOrder(@Param("cartOrderVo") CartOrderVO cartOrderVo);

    void insertOrderDetail(@Param("orderInfoVos") List<OrderInfoVO> orderInfoVOS);

    void updateOrder(@Param("id")Integer id, @Param("path")String path);

    CartCountVO selectCountAndSum(@Param("custId") String custId);
}
