package com.purchase.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.ErpCustomer;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.purchase.service.dto.ErpCustomerPageDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-26
 */
@Mapper
public interface ErpCustomerMapper extends BaseMapper<ErpCustomer> {

}
