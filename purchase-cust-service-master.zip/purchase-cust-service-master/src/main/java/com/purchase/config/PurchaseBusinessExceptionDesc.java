package com.purchase.config;

import com.zyd.framework.utils.exception.BaseExceptionDesc;
import com.zyd.framework.utils.exception.BusinessExceptionDesc;

/**
 * @author jidonglin
 * @Description: 服务异常码
 */
public class PurchaseBusinessExceptionDesc extends BusinessExceptionDesc {
    public static BaseExceptionDesc NOT_EXIST_CUSTOMER = new BaseExceptionDesc(-40000, "该用户信息不存在");
    public static BaseExceptionDesc MEMBER_BIND_CUSTOMER = new BaseExceptionDesc(-40001, "会员已绑定客户");
    public static BaseExceptionDesc PRODUCT_DOES_NOT_EXIST_IN_CART = new BaseExceptionDesc(-40002, "购物车不存在此产品");
    public static BaseExceptionDesc NOT_EXIST_ERP_BM = new BaseExceptionDesc(-40003, "该编码在IFS系统没有维护对应的客户信息");
    public static BaseExceptionDesc ERROR_BIND_ERP_BM = new BaseExceptionDesc(-40004, "绑定erp客户编码失败");
    public static BaseExceptionDesc ERROT_APPLY_SUPPLIER = new BaseExceptionDesc(-40005, "供应商申请失败");
    public static BaseExceptionDesc ALI_SMS_ERROR = new BaseExceptionDesc(-40006, "手机号码或验证码不正确");
    public static BaseExceptionDesc NOT_EXIST_SMS_TYPE = new BaseExceptionDesc(-40007, "不存在此验证码类型");
    public static BaseExceptionDesc NOT_EXIST_CUSTOMER_INFO = new BaseExceptionDesc(-40008, "该用户信息不存在");
    public static BaseExceptionDesc SEND_SMS_ERROR = new BaseExceptionDesc(-40009, "短信发送异常");
    public static BaseExceptionDesc ERROR_MEMBER_STATE = new BaseExceptionDesc(-40010, "用户会员认证中，请验证通过后再登录");
    public static BaseExceptionDesc FORWARDING_ORDER_GENERATION_FAILED = new BaseExceptionDesc(-40011, "转发订单生成失败");
    public static BaseExceptionDesc CODE_NOT_EXIST = new BaseExceptionDesc(-40012, "注册码已失效");
    public static BaseExceptionDesc RELATE_OPENID_UNIONID = new BaseExceptionDesc(-40013, "注册码已被扫描");
    public static BaseExceptionDesc NO_RELATE_OPENID_UNIONID = new BaseExceptionDesc(-40014, "注册码未扫码");
    public static BaseExceptionDesc WX_LOGIN_ERROR = new BaseExceptionDesc(-40015, "微信登录异常");
    public static BaseExceptionDesc NOT_PASS_MEMBER = new BaseExceptionDesc(-40016, "用户会员认证中，请联系您的销售经理");
    public static BaseExceptionDesc ERROR_EXPORT_CART = new BaseExceptionDesc(-40017, "购物车导出异常");
    public static BaseExceptionDesc ERROR_READ_TEMPLATE = new BaseExceptionDesc(-40018, "购物车模板读取异常");
    public static BaseExceptionDesc ERROR_OSS_EXPORT_CART = new BaseExceptionDesc(-40019, "购物车清单上传oss异常");
    public static BaseExceptionDesc ERROR_TEMP_FILE_QYWX = new BaseExceptionDesc(-40020, "企业微信文件上传异常");
    public static BaseExceptionDesc FULL_CART = new BaseExceptionDesc(-40021, "购物车已满");
    public static BaseExceptionDesc MAX_NUM_CART = new BaseExceptionDesc(-40022, "数量最大值为99999");
    public static BaseExceptionDesc ERRPR_UPLOAD_FILE_QY = new BaseExceptionDesc(-40023, "企业微信上传临时素材异常");
    public static BaseExceptionDesc ERROR_PARSE_ADDRESS = new BaseExceptionDesc(-40024, "地址解析异常");
    public static BaseExceptionDesc ERROR_EDIT_ADDRESS = new BaseExceptionDesc(-40025, "地址修改失败");
    public static BaseExceptionDesc ERROR_PARSE_ADDRESS_NULL = new BaseExceptionDesc(-40026, "地址解析异常NULL");
}
