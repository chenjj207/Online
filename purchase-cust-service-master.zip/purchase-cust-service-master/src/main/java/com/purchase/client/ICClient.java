package com.purchase.client;

import com.alibaba.fastjson.JSONObject;
import com.dtflys.forest.annotation.Get;
import com.dtflys.forest.annotation.Header;
import com.dtflys.forest.annotation.Query;

/**
 * @author jidonglin
 * @Description: ZYD-IC接口
 * @date 2023/2/13  11:12
 */
public interface ICClient {
    /**
     * 地址解析
     *
     * @param text
     * @return
     */
    @Get("http://10.10.31.48:88/tencent/address/resolve/zydonline")
    JSONObject addressResolve(@Header("token")String token, @Query("text") String text);

}
