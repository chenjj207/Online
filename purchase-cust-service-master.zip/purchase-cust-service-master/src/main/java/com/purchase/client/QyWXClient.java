package com.purchase.client;

import com.alibaba.fastjson.JSONObject;
import com.dtflys.forest.annotation.*;

import java.io.File;
import java.util.Map;

/**
 * @author jidonglin
 * @Description: 企业微信接口
 */
public interface QyWXClient {

    @Get("https://qyapi.weixin.qq.com/cgi-bin/gettoken")
    JSONObject getToken(@Query("corpid")String corpid, @Query("corpsecret")String corpsecret);

    @Post(value = "https://qyapi.weixin.qq.com/cgi-bin/media/upload", contentType = "multipart/form-data")
    JSONObject mediaUpload(@Query("access_token")String accessToken, @Query("type")String type,  @DataFile("file") File file);

    @Post("https://qyapi.weixin.qq.com/cgi-bin/message/send")
    JSONObject sendNoticeMessage(@Query("access_token")String accessToken, @JSONBody Map<String, Object> info);
}
