package com.purchase.client.param;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Data
public class SupplierDTO {

    private String name;

    private String code;

    /**
     * 客户id
     */
    private Integer memberId;

    /**
     * 客户id
     */
    private Integer custId;

    /**
     * 类型（SUPPLIER_APPLY: 供应商申请、BACKGROUND_ADD: 后台新增）
     */
    private String type;

    /**
     * 状态（WAIT_AUDIT: 待审核、NO_PASS: 未通过、PASS: 已通过）
     */
    private String status;

    /**
     * ERP客户编码
     */
    private String erpCustBm;

    /**
     * 初始密码
     */
    private String password;

    /**
     * 账号状态(ENABLE: 启用、DISABLE: 停用)
     */
    private String accountStatus;

    /**
     * 数据类型(UNITE: 联营、SELF: 自营)
     */
    private String dataType;
    /**
     * 审核时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime auditTime;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    private LocalDateTime createdAt;
}
