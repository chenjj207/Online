package com.purchase.client;

import com.purchase.client.param.InnerLoginDTO;
import com.purchase.client.param.JsonResult;
import com.purchase.client.param.SupplierDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/24  15:42
 */
@FeignClient(value = "purchase-user")
public interface UserClient {

    @PostMapping(value = "/supplier/add")
    public JsonResult<SupplierDTO> add(@RequestBody SupplierDTO supplier);

    @PostMapping(value = "/user/inner/login")
    public JsonResult<?> innerLogin(@RequestBody InnerLoginDTO innerLoginDTO);
}
