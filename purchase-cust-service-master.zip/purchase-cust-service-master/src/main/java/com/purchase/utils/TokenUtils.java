package com.purchase.utils;

import com.alibaba.fastjson.JSONObject;
import com.purchase.client.QyWXClient;
import com.purchase.client.WXClient;
import com.zyd.framework.utils.redis.RedisUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/3/20  15:58
 */
@Component
public class TokenUtils {

    @Resource
    private QyWXClient qyWXClient;

    @Resource
    private WXClient wxClient;

    @Value("${wx.minigram.appid}")
    String minigramAppid;
    @Value("${wx.minigram.secret}")
    String minigramSecret;
    @Value("${qywx.corpid}")
    String corpid;
    @Value("${qywx.corpSecret}")
    String corpSecret;
    @Value("${qywx.agentId}")
    String agentId;

    public String getWXMinigramToken() {
        String accessToken = RedisUtil.StringOps.get("WX_AccessToken");
        if (StringUtils.isEmpty(accessToken)){
            JSONObject jsonObject = wxClient.getToken(minigramAppid, minigramSecret);
            String newAccessToken = jsonObject.getString("access_token");
            //设置为280秒
            RedisUtil.StringOps.setEx("WX_AccessToken", newAccessToken, 280, TimeUnit.SECONDS);
            accessToken = newAccessToken;
        }
        return accessToken;
    }

    public String getQyWXToken() {
        String accessToken = RedisUtil.StringOps.get("QYWX_AccessToken_" + agentId);
        if (StringUtils.isEmpty(accessToken)){
            JSONObject jsonObject = qyWXClient.getToken(corpid, corpSecret);
            String newAccessToken = jsonObject.getString("access_token");
            //设置为7000秒
            RedisUtil.StringOps.setEx("QYWX_AccessToken_" + agentId, newAccessToken, 7000, TimeUnit.SECONDS);
            accessToken = newAccessToken;
        }
        return accessToken;
    }

}
