package com.purchase.service.vo;

import com.zyd.framework.boot.config.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class CartOrderVO extends BaseEntity {

    private Integer custId;

    private String orderCode;

    private Double totalAmount;

    private Double totalProductPrice;

    private Integer orderStatus;
}
