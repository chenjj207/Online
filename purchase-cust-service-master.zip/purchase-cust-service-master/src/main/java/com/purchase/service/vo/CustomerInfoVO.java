package com.purchase.service.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Data
public class CustomerInfoVO {

    @Schema(description = "客户id")
    private Integer Id;

    @Schema(description = "会员id")
    private Integer memberId;

    @Schema(description = "会员公司")
    private String company;

    @Schema(description = "对应服务行业")
    private String industry;

    @Schema(description = "核心能力")
    private String competence;

    @Schema(description = "核心能力描述")
    private String competenceInfo;

    @Schema(description = "联系人")
    private String linkman;

    @Schema(description = "联系方式")
    private String linkphone;

    @Schema(description = "推广人")
    private String promoter;

    @Schema(description = "省")
    private String province;

    @Schema(description = "市")
    private String city;

    @Schema(description = "区")
    private String area;

    @Schema(description = "详细地址")
    private String address;

    @Schema(description = "会员头像地址")
    private String iconUrl;

    @Schema(description = "微信union_id")
    private String unionId;

    @Schema(description = "微信用户在当前小程序的唯一标识")
    private String openId;

    @Schema(description = "状态（0=待审核，1=通过，2=未通过）")
    private Integer state;

    @Schema(description = "图片地址")
    private String memberUrl;

    @Schema(description = "推广人所属公司")
    private String companyName;

    @Schema(description = "是否开通供应商账号")
    private Boolean isSupplier;

    @Schema(description = "erp客户编码")
    private String erpCustBm;

    @Schema(description = "来源类型")
    private String type;

    @Schema(description = "状态")
    private String status;

    @Schema(description = "初始密码")
    private String password;

    @Schema(description = "账号状态(ENABLE: 启用、DISABLE: 停用)")
    private String accountStatus;

    @Schema(description = "供应商类型(UNITE:联营、SELF:自营)")
    private String dataType;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    @Schema(description = "审核时间")
    private LocalDateTime auditTime;

    @Schema(description = "是否关注")
    @TableField(exist = false)
    private boolean subscribe;
}
