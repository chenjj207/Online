package com.purchase.service;

import com.purchase.entity.PurchaseCart;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CartCountVO;
import com.purchase.service.vo.CartListVO;
import com.purchase.service.vo.CartPriceVO;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

/**
 * <p>
 * 购物车 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-24
 */
public interface PurchaseCartService extends IService<PurchaseCart> {


    Boolean addCartProduct(List<AddCartProductDTO> addCartProductDTOList);

    Boolean editNum(EditNumDTO editNumDTO);

    List<CartListVO> cartList();

    Boolean cartEditSelect(CartEditSelectDTO cartEditSelectDTO);

    Boolean cartDeleted(List<Integer> idList);

    CartPriceVO cartPrice();

    void cartExport(HttpServletResponse response,List<CartExportRequestDTO> cartExportRequestDTOList);

    Boolean cartOrder(List<CartExportRequestDTO> cartExportRequestDTOList);

    CartCountVO cartCount();

    boolean editCartIndex(List<EditCartIndexDTO> editCartIndexDTOS);

    Boolean isPromptIndex(Integer promptCode);
}
