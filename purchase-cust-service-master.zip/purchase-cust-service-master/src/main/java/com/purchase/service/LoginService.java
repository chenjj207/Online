package com.purchase.service;

import com.purchase.client.param.JsonResult;
import com.purchase.service.dto.SMSLoginDTO;
import com.purchase.service.dto.WXLoginDTO;
import com.purchase.service.vo.CheckCodeVO;
import com.purchase.service.vo.UdeskInfoVO;

/**
 * @author jidonglin
 * @Description: 登录服务层
 * @date 2023/5/16  13:45
 */
public interface LoginService {
    String smslogin(SMSLoginDTO smsLoginDTO);

    String wxlogin(WXLoginDTO wxLoginDTO);

    public CheckCodeVO checkCode(String key);

    public JsonResult<?> tokenLogin();

    public UdeskInfoVO udeskInfo();
}
