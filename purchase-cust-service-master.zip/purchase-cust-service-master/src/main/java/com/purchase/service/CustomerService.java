package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.Customer;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CustomerInfoVO;
import com.zyd.framework.utils.response.CommonResponse;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-24
 */
public interface CustomerService extends IService<Customer> {

    Page<CustomerDTO> selectPage(CustomerPageDTO customerPageDTO);

    boolean bindErpBm(BindErpBmDTO bindErpBmDTO);

    boolean suppilerApply();

    boolean add(CustomerAddDTO customerAddDTO);

    Boolean sendSmsCode(SendSmsCodeDTO dto);

    CustomerInfoVO queryInfo();

    public boolean sendQyMsgWithFile( QywxMsgDTO qywxMsgDTO);

}
