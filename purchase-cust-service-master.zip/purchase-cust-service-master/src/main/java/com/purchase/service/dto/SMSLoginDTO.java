package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/5/5  11:56
 */
@Data
public class SMSLoginDTO extends LoginAuthDTO{
    @NotEmpty(message = "手机号有误")
    @Pattern(regexp = "^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\\d{8}$",message = "手机号有误")
    @Schema(description = "联系方式")
    private String linkphone;

    @NotEmpty(message = "短信验证码不能为空")
    @Schema(description = "短信验证码")
    private String smsCode;
}
