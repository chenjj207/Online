package com.purchase.service.dto;

import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class CartEditSelectDTO {

    @NotEmpty(message = "主键ids不能为空")
    private List<Integer> ids;

    @NotNull(message = "是否选中必填")
    @Max(value = 1,message = "状态错误，请重新选择")
    @Min(value = 0,message = "状态错误,请重新选择")
    private Integer selected;
}
