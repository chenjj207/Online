package com.purchase.service;

import com.purchase.entity.CustomerAddress;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.AddressResolveDTO;
import com.purchase.service.dto.CustomerAddressAddDTO;
import com.purchase.service.dto.CustomerAddressEditDTO;
import com.purchase.service.vo.AddressResolveVO;

import java.util.List;

/**
 * <p>
 * 客户地址表 服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
public interface CustomerAddressService extends IService<CustomerAddress> {

    public Integer add(CustomerAddressAddDTO customerAddressAddDTO);

    public Boolean edit(CustomerAddressEditDTO customerAddressEditDTO);

    public List<CustomerAddress> listByCustId();

    public AddressResolveVO addressResolve(AddressResolveDTO addressResolveDTO);

}
