package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.NumberUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.metadata.fill.FillConfig;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.purchase.client.QyWXClient;
import com.purchase.common.CustConstants;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.PurchaseCart;
import com.purchase.mapper.PurchaseCartMapper;
import com.purchase.service.PurchaseCartService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.*;
import com.purchase.service.vo.*;
import com.purchase.utils.NoticeUtils;
import com.purchase.utils.TokenUtils;
import com.zyd.framework.oss.service.impl.AliyunOssService;
import com.zyd.framework.oss.utils.AliyunOssUtils;
import com.zyd.framework.utils.constant.UserSession;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.redis.RedisUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * <p>
 * 购物车 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-24
 */
@Service
public class PurchaseCartServiceImpl extends ServiceImpl<PurchaseCartMapper, PurchaseCart> implements PurchaseCartService {

    @Resource
    PurchaseCartMapper purchaseCartMapper;

    @Autowired
    NoticeUtils noticeUtils;

    @Autowired
    TokenUtils tokenUtil;

    @Resource
    QyWXClient qyWXClient;

    @Resource
    AliyunOssService aliyunOssService;

    //获取慧采商城端
    public String loginCustId(){
        String[] loginIds = StpUtil.getLoginIdAsString().split("-");
        String custId = loginIds[1];
        if (StringUtils.equalsIgnoreCase(custId, "NULL")){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_CUSTOMER_INFO);
        }
        return custId;
    }

    @Override
    public Boolean addCartProduct(List<AddCartProductDTO> addCartProductDTOList) {
        Map<Long,AddCartProductDTO> addCartProductDTOMap = addCartProductDTOList.stream().collect(Collectors.toMap(AddCartProductDTO::getProductId,e->e));
        List<Long> ids = new ArrayList<>(addCartProductDTOMap.keySet());
        QueryWrapper<PurchaseCart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("cust_id", loginCustId());
        List<PurchaseCart> purchaseCarts = purchaseCartMapper.selectList(queryWrapper);
        Integer currentSize = purchaseCarts.size();
        if(currentSize + addCartProductDTOList.size() > 500){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.FULL_CART);
        }
        List<PurchaseCart> editPurchaseCart = new ArrayList<>() ;
        //对新增的产品进行分组
        //购物车已存在需要，更新数据
        if(BeanUtil.isNotEmpty(purchaseCarts)){
            purchaseCarts.forEach(e->{
                if(CollUtil.contains(ids,e.getProductId())){
                    int num = e.getNumber() + addCartProductDTOMap.get(e.getProductId()).getNumber();
                    if (num > 99999){
                        throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.MAX_NUM_CART);
                    }
                    e.setNumber(num);
                    e.setUpdatedAt(LocalDateTime.now());
                    e.setIsSelect(CustConstants.CustCartSelect.YES.code);
                    editPurchaseCart.add(e);
                    addCartProductDTOMap.remove(e.getProductId());
                }
            });
        }
        //购物车中不存在，需要插入数据
        List<PurchaseCart> addProductList = new ArrayList<>();
        if (!addCartProductDTOMap.isEmpty()){
            List<Long> addIds = new ArrayList<>(addCartProductDTOMap.keySet());
            addProductList = purchaseCartMapper.selectProductList(addIds);
            AtomicInteger sort = new AtomicInteger(currentSize);
            addProductList.forEach((e)->{
                BeanUtil.copyProperties(addCartProductDTOMap.get(e.getProductId()),e,new CopyOptions().ignoreNullValue());
                e.setCreatedAt(LocalDateTime.now());
                e.setCustId(Integer.valueOf(loginCustId()));
                sort.getAndIncrement();
                e.setCartIndex(sort.get());
                e.setIsSelect(CustConstants.CustCartSelect.YES.code);
                if (e.getNumber().intValue() > 99999){
                    throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.MAX_NUM_CART);
                }
            });
        }

        //校验分组数据是否不为空
        if(BeanUtil.isNotEmpty(editPurchaseCart)){
            updateBatchById(editPurchaseCart);
        }
        if(BeanUtil.isNotEmpty(addProductList)){
            saveBatch(addProductList);
        }
        return true;
    }

    @Override
    public Boolean editNum(EditNumDTO editNumDTO) {
        QueryWrapper<PurchaseCart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("product_id",editNumDTO.getProductId())
                .eq("cust_id", loginCustId());
        if(BeanUtil.isEmpty(purchaseCartMapper.selectOne(queryWrapper))){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.PRODUCT_DOES_NOT_EXIST_IN_CART);
        }
        UpdateWrapper<PurchaseCart> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("cust_id", loginCustId())
                .eq("product_id",editNumDTO.getProductId())
                .set("number",editNumDTO.getNum())
                .set("updated_at",LocalDateTime.now());
        return update(updateWrapper);
    }

    @Override
    public List<CartListVO> cartList() {
        String id = loginCustId();
        return purchaseCartMapper.cartList(id);
    }

    @Override
    public Boolean cartEditSelect(CartEditSelectDTO cartEditSelectDTO) {
        QueryWrapper<PurchaseCart> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("id", cartEditSelectDTO.getIds())
                .eq("cust_id", loginCustId());
        List<PurchaseCart> purchaseCarts = purchaseCartMapper.selectList(queryWrapper);
        //校验客户购物车是否存在相应产品
        if(CollectionUtils.isEmpty(purchaseCarts) || purchaseCarts.size() != cartEditSelectDTO.getIds().size()){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.PRODUCT_DOES_NOT_EXIST_IN_CART);
        }
        for (PurchaseCart pur : purchaseCarts) {
            pur.setIsSelect(cartEditSelectDTO.getSelected());
        }
        return updateBatchById(purchaseCarts);
    }

    @Override
    public Boolean cartDeleted(List<Integer> idList) {
        QueryWrapper<PurchaseCart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("cust_id", loginCustId())
                .in("id",idList);
        purchaseCartMapper.delete(queryWrapper);

        QueryWrapper<PurchaseCart> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("cust_id", loginCustId()).orderByAsc("cart_index");
        List<PurchaseCart> purchaseCarts = purchaseCartMapper.selectList(queryWrapper1);
        if (CollectionUtils.isNotEmpty(purchaseCarts)){
            int i = 1;
            for (PurchaseCart purchaseCart : purchaseCarts) {
                purchaseCart.setCartIndex(i);
                i++;
            }
            this.updateBatchById(purchaseCarts);
        }
        return true;
    }

    @Override
    public CartPriceVO cartPrice() {
        String id = loginCustId();
        return purchaseCartMapper.cartPrice(id);
    }

    @Override
    public void cartExport(HttpServletResponse response,List<CartExportRequestDTO> cartExportRequestDTOList) {
        //设置excel导出请求头
        String fileName = URLEncoder.encode("购物清单-"+ DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now()));
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
        response.setCharacterEncoding("utf-8");
        //获取数据
        String id = loginCustId();
        Map<Integer,CartExportRequestDTO> map = cartExportRequestDTOList.stream().collect(Collectors.toMap(CartExportRequestDTO::getId,e->e));
        List<Integer> ids = new ArrayList<>(map.keySet());
        List<CartListExcelVO> cartExport = purchaseCartMapper.cartExport(id,ids);
        AtomicInteger index = new AtomicInteger(0);
        CartPriceVO cartPriceVo = new CartPriceVO();
        cartPriceVo.setNumber(0);
        cartPriceVo.setTotalPrice(0.00);
        cartExport.forEach(e->{
            e.setDeliveryDate(map.get(e.id).getDeliveryTime());
            index.getAndIncrement();
            e.purchasePrice = NumberUtil.decimalFormat("0.00",Double.valueOf(e.purchasePrice));
            e.price = NumberUtil.decimalFormat("0.00",Double.valueOf(e.price));
            e.setIndex(index.intValue());
            cartPriceVo.setNumber(cartPriceVo.getNumber()+e.getNumber());
            //去除SubTotal千分号
            try {
                cartPriceVo.setTotalPrice(cartPriceVo.getTotalPrice()+ new DecimalFormat().parse(e.getSubTotal()).doubleValue());
            } catch (ParseException ex) {
                ex.printStackTrace();
            }
            e.setProductName((e.getPropName() == null ? "" : e.getPropName()) + e.getThreeCataName());
        });
        JSONObject jsonObject = StpUtil.getSession().getModel(UserSession.INFO, JSONObject.class);
        Map<String,Object> cartMap = new HashMap<>();
        cartMap.put("company",jsonObject.get("company"));
        cartMap.put("linkman",jsonObject.get("linkman"));
        cartMap.put("linkphone",jsonObject.get("linkphone"));
        cartMap.put("address",jsonObject.get("province")+" "+jsonObject.get("city")+" "+jsonObject.get("area") + jsonObject.get("address"));
        cartMap.put("number",cartPriceVo.getNumber());
        cartMap.put("price",String.valueOf(cartPriceVo.getTotalPrice()));
        try {
            ServletOutputStream out= response.getOutputStream();
            //设置导出模板
            InputStream inputStream = new ClassPathResource("template/cartList.xlsx").getInputStream();
            ExcelWriter writer = EasyExcel.write(out).withTemplate(inputStream).excelType(ExcelTypeEnum.XLSX).build();

            WriteSheet sheet = EasyExcel.writerSheet(0).build();
            //将数据写入模板
            FillConfig fillConfig = FillConfig.builder().forceNewRow(true).build();
            writer.fill(cartMap,fillConfig,sheet);
            writer.fill(cartExport,fillConfig,sheet);

            writer.finish();
            out.flush();
        }catch (Exception e){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_EXPORT_CART);
        }
    }



    @Override
    public Boolean cartOrder(List<CartExportRequestDTO> cartExportRequestDTOList){
        //创建
        List<Integer> list = cartExportRequestDTOList.stream().map(CartExportRequestDTO::getId).collect(Collectors.toList());
        String id = loginCustId();
        List<OrderInfoVO> orderInfoVOS = purchaseCartMapper.orderInfoVos(id,list);
        //校验购物车是否存在相关产品
        if(orderInfoVOS.size()==0){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.PRODUCT_DOES_NOT_EXIST_IN_CART);
        }
        //存在则创建相应订单
        CartOrderVO cartOrderVo = new CartOrderVO();
        cartOrderVo.setCustId(Integer.valueOf(loginCustId()));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        cartOrderVo.setOrderCode(LocalDateTime.now().format(formatter)+String.valueOf(System.currentTimeMillis()));
        cartOrderVo.setCreatedBy(loginCustId());
        cartOrderVo.setCreatedAt(LocalDateTime.now());
        //获取订单慧采商品总价
        orderInfoVOS.forEach(e->{
            if(BeanUtil.isNotEmpty(e.getPurchasePrice())){
                try {
                    if(BeanUtil.isEmpty( cartOrderVo.getTotalProductPrice())){
                        cartOrderVo.setTotalProductPrice(new DecimalFormat().parse(e.getPurchasePrice()).doubleValue());
                    }else{
                        cartOrderVo.setTotalProductPrice(cartOrderVo.getTotalProductPrice()+new DecimalFormat().parse(e.getPurchasePrice()).doubleValue());
                    }
                } catch (ParseException ex) {
                    ex.printStackTrace();
                }
            }
        });

        cartOrderVo.setOrderStatus(Integer.valueOf(CustConstants.OrderStatus.PENDING.code));
        //创建订单
        purchaseCartMapper.insertOrder(cartOrderVo);
        //传入订单id与编号，根据当前品牌、系列作为快照，创建订单详情
        orderInfoVOS.stream().map((item)->{
            item.setOrderId(cartOrderVo.getId());
            item.setOrderCode(cartOrderVo.getOrderCode());
            item.setTotalAmount(String.valueOf(Double.valueOf(item.getPurchasePrice())*item.getNumber()));
            return  item;
        }).collect(Collectors.toList());
        purchaseCartMapper.insertOrderDetail(orderInfoVOS);
        QueryWrapper<PurchaseCart> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("id",list).eq("cust_id", loginCustId());

        //生成Excel文档并上传OSS
        String path = sendExcel(cartExportRequestDTOList);
        purchaseCartMapper.updateOrder(cartOrderVo.getId(),path);
        //创建成功，删除相应的购物车信息
        return remove(queryWrapper);
    }

    @Override
    public CartCountVO cartCount() {
        CartCountVO cartCountVO = purchaseCartMapper.selectCountAndSum(loginCustId());
        return cartCountVO;
    }

    @Override
    public boolean editCartIndex(List<EditCartIndexDTO> editCartIndexDTOS) {
        List<PurchaseCart> purchaseCarts = BeanUtil.copyToList(editCartIndexDTOS, PurchaseCart.class, null);
        return updateBatchById(purchaseCarts);
    }

    @Override
    public Boolean isPromptIndex(Integer promptCode) {
        if (promptCode == 0) {
            RedisUtil.StringOps.set("cart_prompt_index_" + loginCustId(), UUID.randomUUID().toString());
            return null;
        } else if (promptCode == 2) {
            String hasKey = RedisUtil.StringOps.get("cart_prompt_index_" + loginCustId());
            return StringUtils.isEmpty(hasKey);
        }
        return null;
    }

    private String sendExcel(List<CartExportRequestDTO> cartExportRequestDTOList)  {
        //获取数据
        String id = loginCustId();
        Map<Integer,CartExportRequestDTO> map = cartExportRequestDTOList.stream().collect(Collectors.toMap(CartExportRequestDTO::getId,e->e));
        List<Integer> ids = new ArrayList<>(map.keySet());
        List<CartListExcelVO> cartExport = purchaseCartMapper.cartExport(id,ids);
        AtomicInteger index = new AtomicInteger(0);
        CartPriceVO cartPriceVo = new CartPriceVO();
        cartPriceVo.setNumber(0);
        cartPriceVo.setTotalPrice(0.00);
        cartExport.forEach(e->{
            e.setDeliveryDate(map.get(e.id).getDeliveryTime());
            index.getAndIncrement();
            e.setIndex(index.intValue());
            e.purchasePrice = NumberUtil.decimalFormat("0.00",Double.valueOf(e.purchasePrice));
            e.price = NumberUtil.decimalFormat("0.00",Double.valueOf(e.price));
            cartPriceVo.setNumber(cartPriceVo.getNumber()+e.getNumber());
            //去除SubTotal千分号
            try {
                cartPriceVo.setTotalPrice(cartPriceVo.getTotalPrice()+ new DecimalFormat().parse(e.getSubTotal()).doubleValue());
            } catch (ParseException ex) {
                ex.printStackTrace();
            }
            e.setProductName((e.getPropName() == null ? "" : e.getPropName()) + e.getThreeCataName());
        });
        JSONObject jsonObject = StpUtil.getSession().getModel(UserSession.INFO, JSONObject.class);
        Map<String,Object> cartMap = new HashMap<>();
        cartMap.put("company",jsonObject.get("company"));
        cartMap.put("linkman",jsonObject.get("linkman"));
        cartMap.put("linkphone",jsonObject.get("linkphone"));
        cartMap.put("address",jsonObject.get("province")+" "+jsonObject.get("city")+" "+jsonObject.get("area")+jsonObject.get("address"));
        cartMap.put("number",cartPriceVo.getNumber());
        cartMap.put("price",String.valueOf(cartPriceVo.getTotalPrice()));
        //设置导出模板
        InputStream inputStream = null;
        try {
            inputStream = new ClassPathResource("template/cartList.xlsx").getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_READ_TEMPLATE);
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ExcelWriter writer = EasyExcel.write(byteArrayOutputStream).withTemplate(inputStream).excelType(ExcelTypeEnum.XLSX).build();
        WriteSheet sheet = EasyExcel.writerSheet(0).build();
        //将数据写入模板
        FillConfig fillConfig = FillConfig.builder().forceNewRow(true).build();
        writer.fill(cartMap,fillConfig,sheet);
        writer.fill(cartExport,fillConfig,sheet);
        writer.finish();
        MultipartFile multipartFile = new MockMultipartFile("购物清单-"+ DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now())+".xlsx",byteArrayOutputStream.toByteArray());
        AliyunOssUtils.OssPutResult ossPutResult = null;
        try {
            ossPutResult = aliyunOssService.putObjectV2(false,multipartFile,"购物清单-"+ DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now()),"xlsx","/cartOrder");
        } catch (IOException e) {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_OSS_EXPORT_CART);
        }
        String token = tokenUtil.getQyWXToken();
        String type = "file";
        File file = new File(System.getProperty("user.dir")+"/src/main/resources/template/file/购物清单-"+ DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now())+".xlsx");
        try {
            FileUtils.copyInputStreamToFile(multipartFile.getInputStream(), file);
        } catch (IOException e) {
            e.printStackTrace();
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_TEMP_FILE_QYWX);
        }
        JSONObject media = qyWXClient.mediaUpload(token,type,file);
        file.delete();
        if(!media.containsKey("media_id")){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.FORWARDING_ORDER_GENERATION_FAILED);
        }
        String mediaId = media.getString("media_id");
        String notice = "联营慧会员【"+StpUtil.getSession().getModel("info",JSONObject.class).getString("company")+"】提交了采购需求清单，请及时跟进处理";
        noticeUtils.sendQywx(notice,"text");
        noticeUtils.sendQywx(mediaId,type);
        return ossPutResult.getAbsolutePath();
    }
}
