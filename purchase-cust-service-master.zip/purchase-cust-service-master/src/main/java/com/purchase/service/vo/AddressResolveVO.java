package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * 地址解析返回类
 * @author jdl
 */
@Data
@Schema(description = "地址解析返回类")
public class AddressResolveVO {

    @Schema(description = "电话")
    private String mobile;
    @Schema(description = "姓名")
    private String name;
    @Schema(description = "省")
    private String provinceName;
    @Schema(description = "市")
    private String cityName;
    @Schema(description = "区")
    private String countyName;
    @Schema(description = "街道")
    private String townName;

}
