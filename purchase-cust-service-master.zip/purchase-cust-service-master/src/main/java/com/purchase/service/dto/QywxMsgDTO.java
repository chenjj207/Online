package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/9/13  11:35
 */
@Data
public class QywxMsgDTO {
    @Schema(description = "消息内容")
    private String content;
    @Schema(description = "链接路径")
    private String urlPath;
    //  例如：https://zyd-online-tenant-dev.oss-cn-shenzhen.aliyuncs.com/
    @Schema(description = "域名地址， 不填默认当前配置的 oss.ossUrl")
    private String domainUrl;
    @Schema(description = "文件名")
    private String fileName;

}
