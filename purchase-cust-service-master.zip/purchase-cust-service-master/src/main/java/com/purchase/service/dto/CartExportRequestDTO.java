package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class CartExportRequestDTO {

    @NotNull(message = "购物车id不能为空")
    @Schema(description = "购物车id")
    private Integer id;

    @NotBlank(message = "货期不可为空")
    @Schema(description = "货期")
    private String deliveryTime;
}
