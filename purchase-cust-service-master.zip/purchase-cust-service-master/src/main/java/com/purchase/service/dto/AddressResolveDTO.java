package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 * @author :jdl
 * @Description:
 */
@Data
@Slf4j
public class AddressResolveDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @Schema(description = "文本内容")
    @NotEmpty(message = "文本内容不能为空")
    private String text;
}
