package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/5/25  9:35
 */
@Data
public class CartCountVO {
    @Schema(description = "类型数量")
    private int typeCount;
    @Schema(description = "商品总量")
    private int allCount;
}
