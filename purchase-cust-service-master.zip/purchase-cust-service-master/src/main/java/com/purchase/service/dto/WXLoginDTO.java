package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/5/5  11:56
 */
@Data
public class WXLoginDTO extends LoginAuthDTO{

    @NotNull(message = "jscode不能为空")
    @Schema(description = "微信扫码登录参数")
    private String jsCode;
}
