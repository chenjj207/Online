package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * @author jidonglin
 * @Description: key关联用户
 * @date 2023/5/17  16:03
 */
@Data
@Schema(title = "注册码关联用户")
public class RelateKeyDTO {
    @NotEmpty(message = "注册随机码不能为空")
    @Schema(description = "注册随机码")
    private String key;
    @NotEmpty(message = "微信openId不能为空")
    @Schema(description = "微信openId")
    private String openId;
    @NotEmpty(message = "微信unionId不能为空")
    @Schema(description = "微信unionId")
    private String unionId;
}
