package com.purchase.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.ErpCustomer;
import com.purchase.mapper.ErpCustomerMapper;
import com.purchase.service.ErpCustomerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.ErpCustomerPageDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-26
 */
@Service
public class ErpCustomerServiceImpl extends ServiceImpl<ErpCustomerMapper, ErpCustomer> implements ErpCustomerService {

    @Resource
    ErpCustomerMapper erpCustomerMapper;

    @Override
    public Page<ErpCustomer> selectPage(ErpCustomerPageDTO erpCusomerPageDTO) {
        QueryWrapper<ErpCustomer> wrapper = new QueryWrapper<>();
        wrapper.eq(StringUtils.isNotEmpty(erpCusomerPageDTO.getDisabled()), "disabled", erpCusomerPageDTO.getDisabled())
                .and(StringUtils.isNotBlank(erpCusomerPageDTO.getKey()),i->i
                        .or().like("erp_cust_bm", erpCusomerPageDTO.getKey())
                        .or().like("sec_cust_account", erpCusomerPageDTO.getKey())
                        .or().like("login_phone", erpCusomerPageDTO.getKey())
                ).orderByDesc("id");
        return erpCustomerMapper.selectPage(erpCusomerPageDTO.buildPage(), wrapper);
    }
}
