package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.purchase.client.ICClient;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.CustomerAddress;
import com.purchase.mapper.CustomerAddressMapper;
import com.purchase.service.CustomerAddressService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.AddressResolveDTO;
import com.purchase.service.dto.CustomerAddressAddDTO;
import com.purchase.service.dto.CustomerAddressEditDTO;
import com.purchase.service.vo.AddressResolveVO;
import com.zyd.framework.utils.exception.BusinessException;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 客户地址表 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-12-19
 */
@Service
public class CustomerAddressServiceImpl extends ServiceImpl<CustomerAddressMapper, CustomerAddress> implements CustomerAddressService {

    @Resource
    CustomerAddressMapper customerAddressMapper;

    @Resource
    ICClient icClient;

    @Value("${ic.address.token}")
    String icToken;

    //获取慧采商城端
    public String loginCustId(){
        String[] loginIds = StpUtil.getLoginIdAsString().split("-");
        String custId = loginIds[1];
        if (StringUtils.equalsIgnoreCase(custId, "NULL")){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_CUSTOMER_INFO);
        }
        return custId;
    }

    @Override
    @Transactional
    public Integer add(CustomerAddressAddDTO customerAddressAddDTO) {
        if (customerAddressAddDTO.getIsDefault() != null && (customerAddressAddDTO.getIsDefault().intValue() == 1)){
            UpdateWrapper<CustomerAddress> customerAddressUpdateWrapper = new UpdateWrapper<>();
            customerAddressUpdateWrapper.set("is_default", 0).eq("cust_id", loginCustId());
            this.update(customerAddressUpdateWrapper);
        }

        CustomerAddress customerAddress = BeanUtil.copyProperties(customerAddressAddDTO, CustomerAddress.class);
        customerAddress.setCustId(Integer.valueOf(loginCustId()));
        customerAddress.setCreatedAt(LocalDateTime.now());
        customerAddress.setCreatedBy(loginCustId());
        if (customerAddress.getIsDefault() == null){
            customerAddress.setIsDefault(0);
        }
        this.save(customerAddress);

        return customerAddress.getId();
    }

    @Override
    @Transactional
    public Boolean edit(CustomerAddressEditDTO customerAddressEditDTO) {
        UpdateWrapper<CustomerAddress> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set(StringUtils.isNotBlank(customerAddressEditDTO.getCountry()), "country", customerAddressEditDTO.getCountry())
                .set(StringUtils.isNotBlank(customerAddressEditDTO.getProvince()), "province", customerAddressEditDTO.getProvince())
                .set(StringUtils.isNotBlank(customerAddressEditDTO.getCity()), "city", customerAddressEditDTO.getCity())
                .set(StringUtils.isNotBlank(customerAddressEditDTO.getArea()), "area", customerAddressEditDTO.getArea())
                .set(StringUtils.isNotBlank(customerAddressEditDTO.getStreet()), "street", customerAddressEditDTO.getStreet())
                .set(StringUtils.isNotBlank(customerAddressEditDTO.getDetailAddress()), "detail_address", customerAddressEditDTO.getDetailAddress())
                .set(StringUtils.isNotBlank(customerAddressEditDTO.getZipcode()), "zipcode", customerAddressEditDTO.getZipcode())
                .set(customerAddressEditDTO.getIsDefault() != null, "is_default", customerAddressEditDTO.getIsDefault())
                .set(StringUtils.isNotBlank(customerAddressEditDTO.getPhone()), "phone", customerAddressEditDTO.getPhone())
                .set(StringUtils.isNotBlank(customerAddressEditDTO.getContact()), "contact", customerAddressEditDTO.getContact())
                .set("updated_at", LocalDateTime.now())
                .set("updated_by", loginCustId())
                .eq("id", customerAddressEditDTO.getId());
        boolean result = this.update(updateWrapper);
        if (!result){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_EDIT_ADDRESS);
        }

        if (customerAddressEditDTO.getIsDefault() != null && (customerAddressEditDTO.getIsDefault().intValue() == 1)){
            UpdateWrapper<CustomerAddress> customerAddressUpdateWrapper = new UpdateWrapper<>();
            customerAddressUpdateWrapper.set("is_default", 0).ne("id", customerAddressEditDTO.getId()).eq("cust_id", loginCustId());
            this.update(customerAddressUpdateWrapper);
        }
        return result;
    }

    @Override
    public List<CustomerAddress> listByCustId() {
        QueryWrapper<CustomerAddress> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("cust_id", loginCustId()).orderByDesc("is_default", "created_at");
        return this.list(queryWrapper);
    }

    @Override
    public AddressResolveVO addressResolve(AddressResolveDTO addressResolveDTO) {
        JSONObject jsonObject = icClient.addressResolve(icToken, addressResolveDTO.getText());
        if (jsonObject == null || jsonObject.getInteger("code") != 0){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_PARSE_ADDRESS);
        }
        JSONArray dataList = (JSONArray) jsonObject.get("data");
        if (dataList == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_PARSE_ADDRESS_NULL);
        }
        AddressResolveVO addressResolve = JSONObject.toJavaObject(JSONObject.parseObject(JSONObject.toJSONString(dataList.get(0))), AddressResolveVO.class);
        return addressResolve;
    }
}
