package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class AddCartProductDTO {

    @NotNull(message = "产品不能为空")
    @Schema(description ="产品id" )
    private Long productId;

    @NotNull(message = "数量不能为空")
    @Schema(description = "添加产品数量")
    private Integer number;
}
