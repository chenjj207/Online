package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import com.alibaba.fastjson.JSONObject;
import com.purchase.client.UserClient;
import com.purchase.client.WXClient;
import com.purchase.client.param.InnerLoginDTO;
import com.purchase.client.param.JsonResult;
import com.purchase.common.CustConstants;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.mapper.CustomerMapper;
import com.purchase.service.LoginService;
import com.purchase.service.dto.CustomerDTO;
import com.purchase.service.dto.CustomerPageDTO;
import com.purchase.service.dto.SMSLoginDTO;
import com.purchase.service.dto.WXLoginDTO;
import com.purchase.service.vo.CheckCodeVO;
import com.purchase.service.vo.UdeskInfoVO;
import com.zyd.framework.utils.constant.UserSession;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.redis.RedisUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static cn.hutool.crypto.SecureUtil.sha1;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/5/18  15:26
 */
@Service
public class LoginServiceImpl implements LoginService {

    private Logger logger = LoggerFactory.getLogger(LoginServiceImpl.class);

    @Resource
    CustomerMapper customerMapper;

    @Value("${app.ali.sms.code.phoneLogin}")
    String phoneLogin;
    @Value("${registCode:registCode}")
    private String registCode;

    @Value("${wx.web.appid}")
    private String wxWebAppid;
    @Value("${wx.web.secret}")
    private String wxWebSecret;
    @Value("${udesk.im_user_key}")
    private String udeskImUserKey;

    @Autowired
    AliSmsService aliSmsService;


    @Resource
    WXClient wxClient;
    @Resource
    UserClient userClient;

    private String saLogin(CustomerDTO customerDTO) {
        //设置角色，默认ALL
        Set roles = new HashSet();
        roles.add("ALL");
        //设置权限，默认ALL
        Set permissions = new HashSet();
        permissions.add("ALL");

        String custId = customerDTO.getId() == null ? "NULL" : customerDTO.getId().toString();
        String loginId = CustConstants.PRE_LOGIN + custId + "-" + customerDTO.getMemberId();

        StpUtil.login(loginId, "PC");
        StpUtil.getSession().set(UserSession.INFO, (JSONObject) JSONObject.toJSON(customerDTO));
        StpUtil.getSession().set(UserSession.ROLES, roles);
        StpUtil.getSession().set(UserSession.PERMISSIONS, permissions);
        return StpUtil.getTokenValue();
    }

    @Override
    public String smslogin(SMSLoginDTO smsLoginDTO) {
        if (StringUtils.equals(smsLoginDTO.getAuthorization(), CustConstants.LOGIN_AUTH)){
            CustomerDTO customerDTO = customerMapper.selectMember(null, null, smsLoginDTO.getLinkphone());
            if (customerDTO == null){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_CUSTOMER_INFO);
            }
            //校验验证码
            aliSmsService.valid("LOGIN", smsLoginDTO.getLinkphone(), smsLoginDTO.getSmsCode());
            return saLogin(customerDTO);
        }else {
            CustomerPageDTO customerPageDTO = new CustomerPageDTO();
            customerPageDTO.setLinkphone(smsLoginDTO.getLinkphone());
            List<CustomerDTO> customerDTOList = customerMapper.search(customerPageDTO);
            if (CollectionUtils.isEmpty(customerDTOList)) {
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_CUSTOMER_INFO);
            }
            //校验验证码
            aliSmsService.valid("LOGIN", smsLoginDTO.getLinkphone(), smsLoginDTO.getSmsCode());
            CustomerDTO customerDTO = customerDTOList.get(0);
            if (customerDTO.getState().intValue() != CustConstants.MemberState.PASS.code.intValue()) {
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_MEMBER_STATE);
            }
            return saLogin(customerDTO);
        }
    }

    @Override
    public String wxlogin(WXLoginDTO wxLoginDTO) {
        JSONObject jsonObject = wxClient.oauth(wxWebAppid, wxWebSecret, wxLoginDTO.getJsCode());
        if (jsonObject.containsKey("errcode") && jsonObject.getInteger("errcode") != 0){
            logger.error("微信扫码登录: "+jsonObject.getString("errmsg"));
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.WX_LOGIN_ERROR);
        }
        String unionid = jsonObject.getString("unionid");
        CustomerDTO customerDTO = customerMapper.selectMember(null, unionid, null);
        if (customerDTO == null){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_CUSTOMER);
        }
        if (StringUtils.equals(wxLoginDTO.getAuthorization(), CustConstants.LOGIN_AUTH)){
            return saLogin(customerDTO);
        }else {
            if (customerDTO.getId() == null){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_PASS_MEMBER);
            }
            if (CustConstants.MemberState.PASS.code.intValue() != customerDTO.getState().intValue()){
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_PASS_MEMBER);
            }
            return saLogin(customerDTO);
        }
    }

    @Override
    public CheckCodeVO checkCode(String key) {
        String value1 = RedisUtil.StringOps.get(registCode + "-" + key);
        if (StringUtils.isEmpty(value1)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.CODE_NOT_EXIST);
        }
        String value = RedisUtil.StringOps.get(registCode + "-" + key);
        if (StringUtils.isNotEmpty(value) && "initValue".equals(value)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NO_RELATE_OPENID_UNIONID);
        }
        CheckCodeVO checkCodeVO = new CheckCodeVO();
        String[] infos = value.split(",");
        String openId = infos[0];
        String unionId = infos[1];
        CustomerDTO customerDTO = customerMapper.selectMember(openId, unionId, null);
        if (customerDTO == null){
            //不存在会员信息
            checkCodeVO.setState(CustConstants.CodeState.NOT_REG.code);
            checkCodeVO.setTipMsg("扫码成功，请在手机端完成注册");
        }else {
            Integer state = customerDTO.getState();
            if (CustConstants.MemberState.PASS.getCode().intValue() == state.intValue() && customerDTO.getId() != null){
                //会员已通过
                String token = saLogin(customerDTO);
                checkCodeVO.setState(CustConstants.CodeState.PASS.code);
                checkCodeVO.setTipMsg("登录成功");
                checkCodeVO.setToken(token);
            }else if (CustConstants.MemberState.PASS.getCode().intValue() != state.intValue()){
                //会员未通过
                checkCodeVO.setState(CustConstants.CodeState.REFER.code);
                checkCodeVO.setTipMsg("用户会员认证中，请验证通过后再登录");
            }
        }
        return checkCodeVO;
    }

    @Override
    public JsonResult<?> tokenLogin() {
        String[] loginIds = StpUtil.getLoginIdAsString().split("-");
        String custId = loginIds[1];
        String memberId = loginIds[2];
        InnerLoginDTO innerLoginDTO = new InnerLoginDTO();
        innerLoginDTO.setCustId(Integer.valueOf(custId));
        innerLoginDTO.setMemberId(Integer.valueOf(memberId));
        return userClient.innerLogin(innerLoginDTO);
    }

    @Override
    public UdeskInfoVO udeskInfo() {
        JSONObject jsonObject = StpUtil.getSession().getModel(UserSession.INFO,JSONObject.class);
        UdeskInfoVO udeskInfoVO = new UdeskInfoVO();
        udeskInfoVO.setUserId(String.valueOf(jsonObject.getInteger("memberId")));
        udeskInfoVO.setCompany(jsonObject.getString("company"));
        udeskInfoVO.setLinkman(jsonObject.getString("linkman"));
        udeskInfoVO.setMobile(jsonObject.getString("linkphone"));

        String snonce = java.util.UUID.randomUUID().toString().replace("-", "");
        String stimestamp = String.valueOf(new Date().getTime());
        String signature = getUdeskSignature(snonce, stimestamp, udeskInfoVO.getUserId());

        udeskInfoVO.setNonce(snonce);
        udeskInfoVO.setTimestamp(stimestamp);
        udeskInfoVO.setWeb_token(udeskInfoVO.getUserId());
        udeskInfoVO.setSignature(signature);

        return udeskInfoVO;
    }

    public String getUdeskSignature(String snonce, String stimestamp, String swebToken) {
        String str = "nonce=" + snonce + "&timestamp=" + stimestamp + "&web_token=" + swebToken + "&" + udeskImUserKey;
        str = sha1(str);
        str = str.toUpperCase();
        return str;
    }
}
