package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/12/19  14:46
 */
@Data
public class CustomerAddressEditDTO {

    @Schema(description = "主键")
    @NotNull(message = "主键不能为空")
    private Integer id;

    @Schema(description = "国家")
    private String country;

    @Schema(description = "省")
    private String province;

    @Schema(description = "市")
    private String city;

    @Schema(description = "区")
    private String area;

    @Schema(description = "街道")
    private String street;

    @Schema(description = "详细地址")
    private String detailAddress;

    @Schema(description = "邮编")
    private String zipcode;

    @Schema(description = "是否默认地址")
    private Integer isDefault;

    @Schema(description = "收货人")
    private String contact;

    @Schema(description = "手机号")
    private String phone;
}
