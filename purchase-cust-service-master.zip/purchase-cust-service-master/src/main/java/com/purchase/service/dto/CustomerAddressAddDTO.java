package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/12/19  14:46
 */
@Data
public class CustomerAddressAddDTO {

    @Schema(description = "国家")
    private String country;

    @Schema(description = "省")
    @NotEmpty(message = "省 不能为空")
    private String province;

    @Schema(description = "市")
    @NotEmpty(message = "市 不能为空")
    private String city;

    @Schema(description = "区")
    @NotEmpty(message = "区 不能为空")
    private String area;

    @Schema(description = "街道")
    private String street;

    @NotEmpty(message = "详细地址 不能为空")
    @Schema(description = "详细地址")
    private String detailAddress;

    @Schema(description = "邮编")
    private String zipcode;

    @Schema(description = "是否默认地址")
    private Integer isDefault;

    @Schema(description = "收货人")
    @NotEmpty(message = "收货人 不能为空")
    private String contact;

    @Schema(description = "手机号")
    @NotEmpty(message = "手机号 不能为空")
    private String phone;
}
