package com.purchase.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.OSSObject;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dtflys.forest.Forest;
import com.purchase.client.MsgClient;
import com.purchase.client.QyWXClient;
import com.purchase.client.UserClient;
import com.purchase.client.dto.TriggerMsgRequest;
import com.purchase.client.param.JsonResult;
import com.purchase.client.param.SupplierDTO;
import com.purchase.common.CustConstants;
import com.purchase.config.OssConf;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.entity.Customer;
import com.purchase.mapper.CustomerMapper;
import com.purchase.mapper.ErpCustomerMapper;
import com.purchase.service.CustomerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.purchase.service.dto.*;
import com.purchase.service.vo.CustomerInfoVO;
import com.purchase.utils.NoticeUtils;
import com.purchase.utils.TokenUtils;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.response.CommonResponse;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-24
 */
@Service
public class CustomerServiceImpl extends ServiceImpl<CustomerMapper, Customer> implements CustomerService {

    private static Logger logger = LoggerFactory.getLogger(CustomerServiceImpl.class);
    @Resource
    CustomerMapper customerMapper;
    @Resource
    ErpCustomerMapper erpCustomerMapper;
    @Resource
    UserClient userClient;

    @Value("${app.ali.sms.code.phoneLogin}")
    String phoneLogin;
    @Value("${registCode: registCode}")
    private String registCode;

    @Autowired
    AliSmsService aliSmsService;

    @Autowired
    TokenUtils tokenUtil;
    @Autowired
    NoticeUtils noticeUtils;
    @Resource
    MsgClient msgClient;
    @Autowired
    OssConf ossConfig;

    @Resource
    public StringRedisTemplate stringRedisTemplate;
    @Override
    public Page<CustomerDTO> selectPage(CustomerPageDTO customerPageDTO) {
        return customerMapper.search(customerPageDTO, customerPageDTO.buildPage());
    }

    @Override
    public boolean bindErpBm(BindErpBmDTO bindErpBmDTO) {
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("erp_cust_bm", bindErpBmDTO.getCode());
        List customerList = erpCustomerMapper.selectList(queryWrapper);
        if (CollectionUtils.isEmpty(customerList)) {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_ERP_BM);
        }
        Customer customer = new Customer();
        customer.setErpCustBm(bindErpBmDTO.getCode());
        customer.setId(bindErpBmDTO.getCustId());
        customer.setUpdatedAt(LocalDateTime.now());
        customer.setUpdatedBy(bindErpBmDTO.getUpdatedBy());
        int result = customerMapper.updateById(customer);
        if (result == 1) {
            return true;
        }
        throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROR_BIND_ERP_BM);
    }


    @Override
    public boolean suppilerApply() {
        String[] loginIds = StpUtil.getLoginIdAsString().split("-");
        int custId = Integer.parseInt(loginIds[1]);
        CustomerPageDTO customerPageDTO = new CustomerPageDTO();
        customerPageDTO.setId(custId);
        List<CustomerDTO> customerDTOS = customerMapper.search(customerPageDTO);
        if (customerDTOS == null) {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_CUSTOMER);
        }
        CustomerDTO customerDTO = customerDTOS.get(0);
        LocalDateTime now = LocalDateTime.now();
        //供应商添加
        SupplierDTO supplierDTO = new SupplierDTO();
        supplierDTO.setName(customerDTO.getCompany());
        supplierDTO.setCode(customerDTO.getLinkphone());
        supplierDTO.setCustId(custId);
        supplierDTO.setType(CustConstants.SupplierSourceType.SUPPLIER_APPLY.code);
        supplierDTO.setErpCustBm(customerDTO.getErpCustBm());
        supplierDTO.setMemberId(customerDTO.getMemberId());
        supplierDTO.setCreatedAt(now);
        //用户服务接口，新增供应商和用户
        JsonResult jsonResult = userClient.add(supplierDTO);
        if (jsonResult == null) {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROT_APPLY_SUPPLIER);
        }
        if (jsonResult.isSuccess()) {
            //用户点击【申请成为供应商】 埋点
            TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
            triggerMsgRequest.setBusiness("regist");
            triggerMsgRequest.setScene("supplierApply");
            JSONObject qywxParam = new JSONObject();
            qywxParam.put("msgtype", "template_card");

            JSONObject templateCard = new JSONObject();
            templateCard.put("card_type", "text_notice");

            JSONObject mainTitle = new JSONObject();
            mainTitle.put("title", "供应商待审核");
            mainTitle.put("desc", "供应商管理");
            templateCard.put("main_title", mainTitle);

            List<JSONObject> horizontalContentList = new ArrayList<>();
            JSONObject keyName1 = new JSONObject();
            keyName1.put("keyname", "供应商");
            keyName1.put("value", customerDTO.getCompany());
            horizontalContentList.add(keyName1);
            JSONObject keyName2 = new JSONObject();
            keyName2.put("keyname", "账号");
            keyName2.put("value", customerDTO.getLinkphone());
            horizontalContentList.add(keyName2);
            JSONObject keyName3 = new JSONObject();
            keyName3.put("keyname", "提交时间");
            keyName3.put("value", DateUtil.format(now, "yyyy/MM/dd HH:mm:ss"));
            horizontalContentList.add(keyName3);
            JSONObject keyName4 = new JSONObject();
            keyName4.put("keyname", "备注");
            keyName4.put("value", "您有一个新供应商提交资料申请，赶快去查看并审核吧。");
            horizontalContentList.add(keyName4);
            templateCard.put("horizontal_content_list", horizontalContentList);

            List<JSONObject> jumpList = new ArrayList<>();
            JSONObject jumpList1 = new JSONObject();
            jumpList1.put("type", 1);
            jumpList1.put("title", "跳转惠采");
            jumpList1.put("url", "https://huicai.zydonline.com/admin/#/supply-manager/supply-chain/supplier-manage/list");
            jumpList.add(jumpList1);
            templateCard.put("jump_list", jumpList);

            JSONObject cardAction = new JSONObject();
            cardAction.put("type", 1);
            cardAction.put("url",  "https://huicai.zydonline.com/admin/#/supply-manager/supply-chain/supplier-manage/list");
            templateCard.put("card_action", cardAction);
            qywxParam.put("template_card", templateCard);
            triggerMsgRequest.setQywxParam(qywxParam);

            JSONObject smsParam = new JSONObject();
            smsParam.put("phone", customerDTO.getLinkphone());
            triggerMsgRequest.setSmsParam(smsParam);

            msgClient.triggerMsg(triggerMsgRequest);
            return true;
        } else {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.ERROT_APPLY_SUPPLIER, jsonResult.getMsg());
        }
    }

    @Override
    public boolean add(CustomerAddDTO customerAddDTO) {
        //判断会员是否已经绑定了客户
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("member_id", customerAddDTO.getMemberId());
        List<Customer> customerExists = customerMapper.selectList(queryWrapper);
        if (CollectionUtils.isNotEmpty(customerExists) && customerExists.size() == 1) {
            return true;
        }else if (CollectionUtils.isEmpty(customerExists)){
            Customer customer = BeanUtil.copyProperties(customerAddDTO, Customer.class);
            customer.setCreatedAt(LocalDateTime.now());
            int i = customerMapper.insert(customer);
            if (i == 1) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Boolean sendSmsCode(SendSmsCodeDTO sendSmsCodeDTO) {
        TriggerMsgRequest triggerMsgRequest = new TriggerMsgRequest();
        String type = "";
        if (CustConstants.SmsCodeType.LOGIN.getCode() == sendSmsCodeDTO.getType()) {
            type = "LOGIN";
            CustomerPageDTO customerPageDTO = new CustomerPageDTO();
            customerPageDTO.setLinkphone(sendSmsCodeDTO.getPhone());
            List<CustomerDTO> customerDTOList = customerMapper.search(customerPageDTO);
            if (CollectionUtils.isEmpty(customerDTOList)) {
                throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_CUSTOMER_INFO);
            }
            triggerMsgRequest.setBusiness("login");
            triggerMsgRequest.setScene("memberLoginCode");
        } else {
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_SMS_TYPE);
        }
        String random = aliSmsService.getRandomCode();
        JSONObject smsParam = new JSONObject();
        smsParam.put("phone", sendSmsCodeDTO.getPhone());
        smsParam.put("code", random);
        triggerMsgRequest.setSmsParam(smsParam);
        CommonResponse<Boolean> commonResponse = msgClient.triggerMsg(triggerMsgRequest);
        if(commonResponse.getData()){
            //缓存验证码10分钟有效期
            String key = String.format("ZYD_ONLINE_CAPTCHA_%s_%s", type, sendSmsCodeDTO.getPhone());
            stringRedisTemplate.opsForValue().set(key, random, 10, TimeUnit.MINUTES);
        }
        return commonResponse.getData();
    }

    @Override
    public CustomerInfoVO queryInfo() {
        CustomerInfoVO customerInfoVo = JSONObject.toJavaObject(StpUtil.getSession().getModel("info", JSONObject.class), CustomerInfoVO.class);
        BeanUtil.copyProperties(customerMapper.searchSuppiler(customerInfoVo.getMemberId()),customerInfoVo, new CopyOptions().ignoreNullValue());
        if (StringUtils.isNotEmpty(customerInfoVo.getUnionId())){
            CommonResponse<Boolean> commonResponse = msgClient.queryWxSubscribeByUnionid(customerInfoVo.getUnionId());
            if (commonResponse.getData()){
                customerInfoVo.setSubscribe(true);
            }
        }
        return customerInfoVo;
    }

    @Override
    public boolean sendQyMsgWithFile(QywxMsgDTO qywxMsgDTO) {
        String token = tokenUtil.getQyWXToken();
        String type = "file";
        //同步到oss
        OSS ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
        OSSObject object = ossClient.getObject(ossConfig.getBucketName(), qywxMsgDTO.getUrlPath());
        InputStream inputStream = object.getObjectContent();

        Forest.post("https://qyapi.weixin.qq.com/cgi-bin/media/upload").addQuery("access_token", token).addQuery("type", type)
                // 指定请求体为Multipart格式
                .contentTypeMultipartFormData()
                // 添加InputStream对象
                .addFile("file", inputStream, qywxMsgDTO.getFileName())
                .onSuccess(((data, req, res) -> {
                    JSONObject jsonObject = JSON.parseObject(data.toString());
                    if(!jsonObject.containsKey("media_id")){
                        throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.FORWARDING_ORDER_GENERATION_FAILED);
                    }
                    String mediaId = jsonObject.getString("media_id");
                    if (StringUtils.isNotEmpty(qywxMsgDTO.getContent())){
                        noticeUtils.sendQywx(qywxMsgDTO.getContent(),"text");
                    }
                    noticeUtils.sendQywx(mediaId,type);
                }))
                // onError回调函数: 请求失败时被调用
                .onError(((ex, req, res) -> {
                    logger.info("企业微信上传临时素材异常" + ex.getMessage());
                    throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.NOT_EXIST_SMS_TYPE);
                }))
                // 执行请求，请求成功则执行onSuccess, 失败则执行onError
                .execute();

        return true;
    }
}
