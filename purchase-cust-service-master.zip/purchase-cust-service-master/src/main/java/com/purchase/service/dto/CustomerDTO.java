package com.purchase.service.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
* <p>
* 
* </p>
*
* @author jidonglin
* @since 2023-04-24
*/
@Data
@Schema(title = "客户信息")
public class CustomerDTO extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Schema(description = "会员id")
    private int memberId;

    @Schema(description = "erp客户编码")
    private String erpCustBm;

    @Schema(description = "会员公司")
    private String company;

    @Schema(description = "对应服务行业")
    private String industry;

    @Schema(description = "核心能力")
    private String competence;

    @Schema(description = "核心能力描述")
    private String competenceInfo;

    @Schema(description = "联系人")
    private String linkman;

    @Schema(description = "联系方式")
    private String linkphone;

    @Schema(description = "省")
    private String province;

    @Schema(description = "市")
    private String city;

    @Schema(description = "区")
    private String area;

    @Schema(description = "详细地址")
    private String address;

    @Schema(description = "微信在同一开放平台下的唯一身份标识")
    private String unionId;

    @Schema(description = "微信用户在当前小程序的唯一身份标识")
    private String openId;

    @Schema(description = "状态（0=待审核，1=通过，2=未通过）")
    private Integer state;

    @Schema(description = "推广人")
    private String promoter;

    @Schema(description = "推广人所属公司名称")
    private String companyName;

    @Schema(description = "未通过原因")
    private String reason;

    @Schema(description = "图片地址")
    private String memberUrl;

    @Schema(description = "会员头像地址")
    private String iconUrl;

    @Schema(description = "备注")
    private String remark;

    @Schema(description = "审核时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    private LocalDateTime auditTime;

    @Schema(description = "注册时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class,
            as = LocalDateTime.class
    )
    private LocalDateTime registTime;

    @Schema(description = "供应商id")
    private String supplierId;

    @Schema(description = "供应商状态 状态（WAIT_AUDIT: 待审核、NO_PASS: 未通过、PASS: 已通过）")
    private String supplierStatus;
}
