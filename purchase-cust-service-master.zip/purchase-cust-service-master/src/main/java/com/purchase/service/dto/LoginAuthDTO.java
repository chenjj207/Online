package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Pattern;

/**
 * @author jidonglin
 * @Description: 授权登录
 * @date 2023/10/16  10:50
 */
@Data
public class LoginAuthDTO {
    @Schema(description = "联营慧授权标识")
    private String authorization;
}
