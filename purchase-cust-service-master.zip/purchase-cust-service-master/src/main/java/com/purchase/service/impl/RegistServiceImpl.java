package com.purchase.service.impl;

import com.purchase.client.WXClient;
import com.purchase.config.PurchaseBusinessExceptionDesc;
import com.purchase.service.RegistService;
import com.purchase.service.dto.RelateKeyDTO;
import com.purchase.service.vo.RegistCodeVO;
import com.purchase.utils.TokenUtils;
import com.zyd.framework.utils.exception.BusinessException;
import com.zyd.framework.utils.redis.RedisUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Base64;
import java.util.concurrent.TimeUnit;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/5/16  14:36
 */
@Service
public class RegistServiceImpl implements RegistService {

    @Resource
    private WXClient wxClient;
    @Autowired
    private TokenUtils tokenUtils;

    @Value("${registCode:registCode}")
    private String registCode;

    /**
     * 创建注册二维码
     * @return
     */
    @Override
    public RegistCodeVO registCode() {
        String key = String.valueOf(System.currentTimeMillis());
        RedisUtil.StringOps.setEx(registCode + "-" + key, "initValue", 30, TimeUnit.MINUTES);
        String wxToken = tokenUtils.getWXMinigramToken();
        byte[] result = wxClient.getwxacodeunlimit(wxToken, "key="+ key, "pages/member-join/index");
        String codeBuffer = Base64.getEncoder().encodeToString(result);
        RegistCodeVO registCodeVO = new RegistCodeVO();
        registCodeVO.setCodeBuffer(codeBuffer);
        registCodeVO.setKey(key);
        return registCodeVO;
    }

    /**
     * key关联用户信息
     * @param relateKeyDTO
     * @return
     */
    @Override
    public boolean relateKey(RelateKeyDTO relateKeyDTO) {
        String value1 = RedisUtil.StringOps.get(registCode + "-" + relateKeyDTO.getKey());
        if (StringUtils.isEmpty(value1)){
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.CODE_NOT_EXIST);
        }
        String value = RedisUtil.StringOps.get(registCode + "-" + relateKeyDTO.getKey());
        if (StringUtils.isNotEmpty(value) && !"initValue".equals(value)){
            //异常
            throw BusinessException.newInstance(PurchaseBusinessExceptionDesc.RELATE_OPENID_UNIONID);
        }
        //绑定随机码 与 openId 和 unionId 的关系
        RedisUtil.StringOps.setEx(registCode + "-" + relateKeyDTO.getKey(), relateKeyDTO.getOpenId() + "," + relateKeyDTO.getUnionId(), 30, TimeUnit.MINUTES);
        return true;
    }


}
