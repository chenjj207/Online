package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description: 注册扫码校验DTO
 * @date 2023/5/18  15:22
 */
@Data
public class CheckCodeVO {
    @Schema(description = "状态码：0、客户未注册 1、客户已通过 2、客户已注册，未通过")
    private String state;
    @Schema(description = "提示信息")
    private String tipMsg;
    @Schema(description = "已完成注册用户响应，登录token")
    private String token;
}
