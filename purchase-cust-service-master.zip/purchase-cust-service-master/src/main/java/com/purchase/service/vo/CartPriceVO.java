package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CartPriceVO {

    @Schema(description = "行数")
    private Integer lineNumber;

    @Schema(description = "总数")
    private Integer number;

    @Schema(description = "总价")
    private Double totalPrice;
}
