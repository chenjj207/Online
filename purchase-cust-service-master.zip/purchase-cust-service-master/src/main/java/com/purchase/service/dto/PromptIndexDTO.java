package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author jidonglin
 * @Description: 提示拖动排序顺序
 * @date 2023/5/26  10:08
 */
@Data
@Schema(title = "提示拖动排序顺序")
public class PromptIndexDTO {
    @Schema(description = "是否继续提示（0-不再提示，1-继续提示，2-首次请求）")
    @NotNull(message = "提示码不能为空")
    private Integer promptCode;
}
