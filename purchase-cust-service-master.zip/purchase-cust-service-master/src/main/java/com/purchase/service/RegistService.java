package com.purchase.service;

import com.purchase.service.dto.RelateKeyDTO;
import com.purchase.service.vo.RegistCodeVO;

/**
 * @author jidonglin
 * @Description: 注册服务层
 * @date 2023/5/16  13:45
 */
public interface RegistService {
    public RegistCodeVO registCode();

    public boolean relateKey(RelateKeyDTO relateKeyDTO);
}
