package com.purchase.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

@Data
public class CustomerPageDTO extends PageDTO {

    @Schema(description = "客户id")
    private Integer id;

    @Schema(description = "会员id")
    private Integer memberId;

    @Schema(description = "状态（0=待审核，1=通过，2=未通过）")
    private Integer state;

    @Schema(description = "搜索关键字")
    private String key;

    @Schema(description = "会员公司")
    private String company;

    @Schema(description = "对应服务行业")
    private String industry;

    @Schema(description = "核心能力")
    private String competence;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "开始时间")
    private Date beginTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "结束时间")
    private Date endTime;

    @Schema(description = "所属公司")
    private String companyName;

    @Schema(description = "是否绑定erp客户编码")
    private Boolean isBindErp;

    @Schema(description = "联系方式")
    private String linkphone;

}
