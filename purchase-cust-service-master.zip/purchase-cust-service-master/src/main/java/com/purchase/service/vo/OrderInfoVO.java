package com.purchase.service.vo;

import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class OrderInfoVO extends BaseEntity {

    @Schema(description = "订单编号")
    private String orderCode;

    @Schema(description = "订单号")
    private Integer orderId;

    @Schema(description = "型号")
    private String productType;

    @Schema(description = "订货号")
    private String skuCode;

    @Schema(description = "数量")
    private Integer number;

    @Schema(description = "品牌名")
    private String brandName;

    @Schema(description = "系列名")
    private String propName;

    @Schema(description = "慧采价")
    private String purchasePrice;

    @Schema(description = "货期")
    private String deliveryTime;

    @Schema(description = "面价")
    private String amount;

    @Schema(description = "总价")
    private String totalAmount;
}
