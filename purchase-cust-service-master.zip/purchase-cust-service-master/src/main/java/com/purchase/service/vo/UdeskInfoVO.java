package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description: udesk 信息
 * @date 2024/7/10  10:30
 */
@Data
public class UdeskInfoVO {
    @Schema(description ="用户id")
    private String userId;
    @Schema(description ="公司")
    private String company;
    @Schema(description ="联系人")
    private String linkman;
    @Schema(description ="手机号")
    private String mobile;

    @Schema(description ="随机数")
    String nonce;
    @Schema(description ="时间戳")
    String timestamp;
    @Schema(description ="客户ID")
    String web_token;
    @Schema(description ="加密签名")
    String signature;

}
