package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * @author jidonglin
 * @Description:
 * @date 2023/4/24  14:06
 */
@Data
public class BindErpBmDTO extends BaseEntity {
    @Schema(description = "客户id")
    @NotNull(message = "客户id不能为空")
    private Integer custId;

    @Schema(description = "erp客户编码")
    @NotEmpty(message = "ERP客户编码必填!")
    private String code;

}
