package com.purchase.service.vo;

import lombok.Data;

@Data
public class CartListExcelVO {

    public Integer index;

    public Integer id;

    public String brandName;

    public String productName;

    public String productType;

    public String price;

    public String skuCode;

    public Integer number;

    public String purchasePrice;

    public String subTotal;

    public String deliveryDate;

    private String threeCataName;

    private String propName;
}
