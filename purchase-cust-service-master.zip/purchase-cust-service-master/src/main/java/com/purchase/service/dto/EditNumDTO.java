package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Data
public class EditNumDTO {

    @Max(value = 99999,message = "数量最大值为99999")
    @Min(value = 1,message = "数量低于最低要求")
    @NotNull(message = "数量不能为空")
    @Schema(description = "本次新增或减少数量")
    private Integer num;

    @NotNull(message = "产品不能为空")
    @Schema(description = "产品id")
    private Long productId;
}
