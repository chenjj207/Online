package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@Schema(title = "购物车编辑排序")
public class EditCartIndexDTO {

    @Schema(description = "购物车id")
    @NotNull(message = "购物车id不能为空")
    private Integer id;

    @Schema(description = "购物车序号索引（从1开始，连续）")
    @NotNull(message = "购物车序号不能为空")
    private Integer cartIndex;
}