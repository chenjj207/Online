package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * 短信发送
 */
@Data
public class SendSmsCodeDTO {

    @Schema(description = "手机号")
    @NotEmpty(message = "手机号有误")
    @Pattern(regexp = "^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\\d{8}$",message = "手机号有误")
    private String phone;

    @Schema(description = "发送类型:1=登录")
    @NotNull(message = "发送类型不能为空")
    private Integer type;

}
