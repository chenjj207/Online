package com.purchase.service.dto;

import com.zyd.framework.boot.config.base.PageDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * erp分页查询对象
 */
@Data
public class ErpCustomerPageDTO extends PageDTO {

    @Schema(description = "搜索关键字")
    private String key;

    @Schema(description = "客户名称")
    private String custName;

    @Schema(description = "姓名")
    private String nickName;

    @Schema(description = "ERP客户编码")
    private String erpCustBm;

    @Schema(description = "商城账号")
    private String secCustAccount;

    @Schema(description = "初始密码")
    private String secInitPwd;

    @Schema(description = "会员类型")
    private String authType;

    @Schema(description = "绑定手机号")
    private String loginPhone;

    @Schema(description = "关联业务")
    private String salemanName;

    @Schema(description = "关联商务")
    private String svrSwManName;

    @Schema(description = "分公司名称")
    private String shortName;

    @Schema(description = "真实姓名")
    private String erpName;

    @Schema(description = "客户联系人")
    private String custLinkMan;

    @Schema(description = "客户联系方式")
    private String custLinkTel;

    @Schema(description = "客户地址")
    private String custAddress;

    @Schema(description = "注册状态")
    private String auditStatus;

    @Schema(description = "客户启停用")
    private String secDisabled;

    @Schema(description = "账号启停用")
    private String disabled;

}
