package com.purchase.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author jidonglin
 * @Description: 注册扫码校验DTO
 * @date 2023/5/18  15:22
 */
@Data
public class CheckCodeDTO {
    @NotNull(message = "轮询key不能为空")
    @Schema(description = "轮询key")
    private String key;
}
