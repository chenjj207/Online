package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author jidonglin
 * @Description: 注册二维码响应
 * @date 2023/5/16  14:31
 */
@Data
public class RegistCodeVO {
    @Schema(description = "二维码临时key")
    private String key;
    @Schema(description = "二维码图片")
    private String codeBuffer;
}
