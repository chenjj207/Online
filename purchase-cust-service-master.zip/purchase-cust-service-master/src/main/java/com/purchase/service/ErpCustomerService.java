package com.purchase.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.purchase.entity.ErpCustomer;
import com.baomidou.mybatisplus.extension.service.IService;
import com.purchase.service.dto.ErpCustomerPageDTO;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jidonglin
 * @since 2023-04-26
 */
public interface ErpCustomerService extends IService<ErpCustomer> {

    Page<ErpCustomer> selectPage(ErpCustomerPageDTO erpCusomerPageDTO);

}
