package com.purchase.service.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CartListVO {

    @Schema(description = "购物车id")
    private Integer Id;

    @Schema(description = "客户id")
    private Integer custId;

    @Schema(description = "产品id")
    private Long productId;

    @Schema(description = "型号")
    private String productType;

    @Schema(description = "订货号")
    private String skuCode;

    @Schema(description = "品牌名")
    private String brandName;

    @Schema(description = "数量")
    private Integer number;

    @Schema(description = "是否为选中（0为不选中，1为选中）")
    private Integer isSelect;

    @Schema(description = "购物车序号索引（从1开始，连续）")
    private Integer cartIndex;

    @Schema(description = "货期")
    private String deliveryDate;

    @Schema(description = "库存")
    private String stock;

    @Schema(description = "慧采价")
    private String purchasePrice;

    @Schema(description = "面价")
    private String Price;

    @Schema(description = "小计")
    private String subTotal;

    @Schema(description = "状态")
    private String type;
}
